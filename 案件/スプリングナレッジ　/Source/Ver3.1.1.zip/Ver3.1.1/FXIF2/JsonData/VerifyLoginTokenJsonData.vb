﻿Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json

<DataContract()>
Public Class VerifyLoginTokenJsonData
    <DataMember()>
    Public returnCode As Integer
    <DataMember()>
    Public description As String
    <DataMember()>
    Public traderID As String
    <DataMember()>
    Public company As String
End Class
