﻿Imports System.Web.Mvc
Imports System.Web.Routing

Public Class MvcApplication
    Inherits System.Web.HttpApplication

    Shared Sub RegisterGlobalFilters(ByVal filters As GlobalFilterCollection)
        filters.Add(New HandleErrorAttribute())
    End Sub

    Shared Sub RegisterRoutes(ByVal routes As RouteCollection)
        routes.IgnoreRoute("{resource}.axd/{*pathInfo}")
        routes.MapRoute("Default", "{controller}")
        routes.MapRoute("Token", "Token/{controller}")
        routes.MapRoute("Account", "Account/{controller}")
    End Sub

    Sub Application_Start()
        SystemLog.Information("初期処理開始")

        AreaRegistration.RegisterAllAreas()
        RegisterRoutes(RouteTable.Routes)

        SystemLog.Information("初期処理終了")
    End Sub

    Sub Application_End()
        SystemLog.Information("終了処理開始")

        SystemLog.Information("終了処理終了")
    End Sub

End Class
