﻿Module EventLogAlertTester

    Private Const EVENT_SOURCE As String = "LionBO"
    Private Const ALERT_MESSAGE As String = "LionBO ALERT"

    Sub Main(CmdArgs As String())
        Dim ProcessID As String = CmdArgs(0)
        Dim AlertType As String = CmdArgs(1)
        Dim AlertMsg As String = CmdArgs(2)
        EventLog.WriteEntry(EVENT_SOURCE, String.Format("{0} {1}:Error Process ""{2}"" {3}", ALERT_MESSAGE, AlertType, ProcessID, AlertMsg), EventLogEntryType.Error)
    End Sub

End Module
