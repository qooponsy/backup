﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.tbInterval = New System.Windows.Forms.TextBox()
        Me.CreateList = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbTimeZone = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbStartTime = New System.Windows.Forms.TextBox()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.rbMinutesSelect = New System.Windows.Forms.RadioButton()
        Me.rbSecondsSelect = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(163, 120)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(75, 23)
        Me.btnCreate.TabIndex = 0
        Me.btnCreate.Text = "作成"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'tbInterval
        '
        Me.tbInterval.Location = New System.Drawing.Point(33, 48)
        Me.tbInterval.Name = "tbInterval"
        Me.tbInterval.Size = New System.Drawing.Size(100, 19)
        Me.tbInterval.TabIndex = 1
        Me.tbInterval.Text = "5"
        '
        'CreateList
        '
        Me.CreateList.FormattingEnabled = True
        Me.CreateList.ItemHeight = 12
        Me.CreateList.Location = New System.Drawing.Point(33, 172)
        Me.CreateList.Name = "CreateList"
        Me.CreateList.Size = New System.Drawing.Size(205, 136)
        Me.CreateList.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 12)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "インターバル時間"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "タイムゾーン"
        '
        'tbTimeZone
        '
        Me.tbTimeZone.Location = New System.Drawing.Point(33, 85)
        Me.tbTimeZone.Name = "tbTimeZone"
        Me.tbTimeZone.Size = New System.Drawing.Size(100, 19)
        Me.tbTimeZone.TabIndex = 5
        Me.tbTimeZone.Text = "540"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "生成開始時間(JST)"
        '
        'tbStartTime
        '
        Me.tbStartTime.Location = New System.Drawing.Point(33, 124)
        Me.tbStartTime.Name = "tbStartTime"
        Me.tbStartTime.Size = New System.Drawing.Size(100, 19)
        Me.tbStartTime.TabIndex = 7
        Me.tbStartTime.Text = "00:00:00"
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.Location = New System.Drawing.Point(35, 151)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(0, 12)
        Me.lblTime.TabIndex = 8
        '
        'rbMinutesSelect
        '
        Me.rbMinutesSelect.AutoSize = True
        Me.rbMinutesSelect.Location = New System.Drawing.Point(145, 40)
        Me.rbMinutesSelect.Name = "rbMinutesSelect"
        Me.rbMinutesSelect.Size = New System.Drawing.Size(47, 16)
        Me.rbMinutesSelect.TabIndex = 9
        Me.rbMinutesSelect.Text = "分足"
        Me.rbMinutesSelect.UseVisualStyleBackColor = True
        '
        'rbSecondsSelect
        '
        Me.rbSecondsSelect.AutoSize = True
        Me.rbSecondsSelect.Checked = True
        Me.rbSecondsSelect.Location = New System.Drawing.Point(145, 61)
        Me.rbSecondsSelect.Name = "rbSecondsSelect"
        Me.rbSecondsSelect.Size = New System.Drawing.Size(47, 16)
        Me.rbSecondsSelect.TabIndex = 10
        Me.rbSecondsSelect.TabStop = True
        Me.rbSecondsSelect.Text = "秒足"
        Me.rbSecondsSelect.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(270, 318)
        Me.Controls.Add(Me.rbSecondsSelect)
        Me.Controls.Add(Me.rbMinutesSelect)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.tbStartTime)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbTimeZone)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CreateList)
        Me.Controls.Add(Me.tbInterval)
        Me.Controls.Add(Me.btnCreate)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCreate As Button
    Friend WithEvents tbInterval As TextBox
    Friend WithEvents CreateList As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbTimeZone As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents tbStartTime As TextBox
    Friend WithEvents lblTime As Label
    Friend WithEvents rbMinutesSelect As RadioButton
    Friend WithEvents rbSecondsSelect As RadioButton
End Class
