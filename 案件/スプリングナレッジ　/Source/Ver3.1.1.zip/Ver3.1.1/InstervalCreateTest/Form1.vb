﻿Public Class Form1

    Private Enum IntervalType
        FUNSOKU
        BYOUSOKU
    End Enum

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click

        Dim intervalTime As Integer = tbInterval.Text

        Dim ashi As IntervalType = Nothing
        If rbMinutesSelect.Checked Then
            ashi = IntervalType.FUNSOKU
        ElseIf rbSecondsSelect.Checked Then
            ashi = IntervalType.BYOUSOKU
        End If

        Dim timeZone As Integer = tbTimeZone.Text
        Dim chartTimeView As String = ""
        Dim success As Boolean = True


        lblTime.Text = "押下時間：" & Now.ToString("HH:mm:ss")
        success = GetCreateList(intervalTime, ashi, timeZone, chartTimeView)

        If success Then
            CreateList.Items.Add(chartTimeView)
        End If

    End Sub

    Private Function GetCreateList(ByVal intervalTime As Integer, ByVal ashi As IntervalType, ByVal timeZone As Integer, ByRef chartTimeView As String) As Boolean
        Dim ret As Boolean = True

        Try
            Dim dt As DateTime = Now

            Dim tsInterval As TimeSpan = Nothing
            Select Case ashi
                Case IntervalType.FUNSOKU
                    tsInterval = TimeSpan.FromMinutes(intervalTime)
                Case IntervalType.BYOUSOKU
                    tsInterval = TimeSpan.FromSeconds(intervalTime)
            End Select

            Dim tsTimeZone As TimeSpan = TimeSpan.FromMinutes(timeZone)

            Dim utcNowTime As DateTime = DateTime.UtcNow
            Dim times As String() = Split(tbStartTime.Text, ":")
            'Dim startTime As DateTime = New DateTime(Now.Year, Now.Month, Now.Day, 0, 0, 0).Add(-tsTimeZone)
            Dim startTime As DateTime = New DateTime(Now.Year, Now.Month, Now.Day, Integer.Parse(times(0)), Integer.Parse(times(1)), Integer.Parse(times(2))).Add(-tsTimeZone)

            Dim ticksToday As Long = utcNowTime.Ticks - startTime.Ticks
            Dim ticksYesterdayUntil As Long = utcNowTime.Ticks - ticksToday


            '' 切り上げ用ロジック
            'Dim upDateTime As DateTime = RoundUP(dt, tsInterval)

            '' 切り下げ用ロジック
            'Dim downDateTime As DateTime = RoundDOWN(dt, tsInterval)

            Dim downDateTimeStartCust As DateTime = Nothing
            Dim ashiStr As String = ""
            Select Case ashi
                Case IntervalType.FUNSOKU
                    ' 切り下げ（分足）
                    downDateTimeStartCust = RoundDownStartCustemerFUNSOKU(ticksToday, ticksYesterdayUntil, tsInterval)
                    ashiStr = "分"
                Case IntervalType.BYOUSOKU
                    ' 切り下げ（秒足）
                    downDateTimeStartCust = RoundDownStartCustemerBYOUSOKU(ticksToday, ticksYesterdayUntil, tsInterval)
                    ashiStr = "秒"
            End Select

            chartTimeView = downDateTimeStartCust.ToString & "  (インターバル：" & intervalTime & ashiStr & ")"

        Catch ex As Exception
            ret = False
            Dim err As String = "message: " & ex.Message & vbCrLf _
                & "stackTrace:" & vbCrLf & ex.StackTrace

            MessageBox.Show(err,
                "エラー",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error)
        End Try

        Return ret
    End Function

    ''' <summary>
    ''' 切り上げ用ロジック
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <param name="interval"></param>
    ''' <returns></returns>
    Private Function RoundUP(ByVal dt As DateTime, ByVal interval As TimeSpan) As DateTime
        Dim ret As DateTime

        Dim a1 As Long = dt.Ticks + interval.Ticks
        Dim b1 As Long = a1 - 1
        Dim c1 As Long = b1 / interval.Ticks
        Dim d1 As Long = c1 * interval.Ticks

        Dim e1 As New DateTime(d1)
        Dim f1 As New DateTime(d1, DateTimeKind.Utc)

        ret = e1

        Return ret
    End Function

    ''' <summary>
    ''' 切り下げ用ロジック
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <param name="interval"></param>
    ''' <returns></returns>
    Private Function RoundDOWN(ByVal dt As DateTime, ByVal interval As TimeSpan) As DateTime
        Dim ret As DateTime

        Dim a2 As Long = dt.Ticks + interval.Ticks
        Dim b2 As Long = a2 / interval.Ticks
        Dim c2 As Long = b2 - 1
        Dim d2 As Long = c2 * interval.Ticks

        Dim e2 As New DateTime(d2)
        Dim f2 As New DateTime(d2, DateTimeKind.Utc)

        ret = e2

        Return ret
    End Function

    ''' <summary>
    ''' 分足用切り下げ用（生成開始時間カスタマイズ可）
    ''' </summary>
    ''' <param name="ticksToday"></param>
    ''' <param name="ticksYesterdayUntil"></param>
    ''' <param name="interval"></param>
    ''' <returns></returns>
    Private Function RoundDownStartCustemerFUNSOKU(ByVal ticksToday As Long, ByVal ticksYesterdayUntil As Long, ByVal interval As TimeSpan) As DateTime
        Dim ret As DateTime

        Dim a2 As Long = ticksToday + interval.Ticks
        Dim b2 As Long = Math.Floor(a2 / interval.Ticks)
        Dim c2 As Long = b2 - 1
        Dim d2 As Long = c2 * interval.Ticks

        Dim e2 As New DateTime(d2 + ticksYesterdayUntil)

        ret = e2

        Return ret
    End Function

    ''' <summary>
    ''' 秒足用切り下げ用（生成開始時間カスタマイズ可）
    ''' </summary>
    ''' <param name="ticksToday"></param>
    ''' <param name="ticksYesterdayUntil"></param>
    ''' <param name="interval"></param>
    ''' <returns></returns>
    Private Function RoundDownStartCustemerBYOUSOKU(ByVal ticksToday As Long, ByVal ticksYesterdayUntil As Long, ByVal interval As TimeSpan) As DateTime
        Dim ret As DateTime

        Dim a2 As Long = ticksToday + interval.Ticks
        Dim b2 As Long = Math.Floor(a2 / interval.Ticks)
        Dim c2 As Long = b2 - 1
        Dim d2 As Long = c2 * interval.Ticks

        Dim e2 As New DateTime(d2 + ticksYesterdayUntil)

        ret = e2

        Return ret
    End Function

End Class
