﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DataDeliveryTest
	Inherits System.Windows.Forms.Form

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblProcess = New System.Windows.Forms.Label()
        Me.btnStopService = New System.Windows.Forms.Button()
        Me.btnStartService = New System.Windows.Forms.Button()
        Me.timWatch = New System.Windows.Forms.Timer(Me.components)
        Me.tbTest = New System.Windows.Forms.Button()
        Me.nudTimeZone = New System.Windows.Forms.NumericUpDown()
        Me.dtpTestTime = New System.Windows.Forms.DateTimePicker()
        CType(Me.nudTimeZone, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblProcess
        '
        Me.lblProcess.Location = New System.Drawing.Point(13, 6)
        Me.lblProcess.Name = "lblProcess"
        Me.lblProcess.Size = New System.Drawing.Size(288, 23)
        Me.lblProcess.TabIndex = 5
        Me.lblProcess.Text = "ID:Slave"
        '
        'btnStopService
        '
        Me.btnStopService.Location = New System.Drawing.Point(168, 29)
        Me.btnStopService.Name = "btnStopService"
        Me.btnStopService.Size = New System.Drawing.Size(133, 23)
        Me.btnStopService.TabIndex = 4
        Me.btnStopService.Text = "Stop Service"
        Me.btnStopService.UseVisualStyleBackColor = True
        '
        'btnStartService
        '
        Me.btnStartService.Location = New System.Drawing.Point(12, 29)
        Me.btnStartService.Name = "btnStartService"
        Me.btnStartService.Size = New System.Drawing.Size(133, 23)
        Me.btnStartService.TabIndex = 3
        Me.btnStartService.Text = "Start Service"
        Me.btnStartService.UseVisualStyleBackColor = True
        '
        'timWatch
        '
        '
        'tbTest
        '
        Me.tbTest.Location = New System.Drawing.Point(18, 75)
        Me.tbTest.Name = "tbTest"
        Me.tbTest.Size = New System.Drawing.Size(80, 23)
        Me.tbTest.TabIndex = 17
        Me.tbTest.Text = "TestTime"
        Me.tbTest.UseVisualStyleBackColor = True
        '
        'nudTimeZone
        '
        Me.nudTimeZone.Location = New System.Drawing.Point(270, 78)
        Me.nudTimeZone.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudTimeZone.Minimum = New Decimal(New Integer() {10000, 0, 0, -2147483648})
        Me.nudTimeZone.Name = "nudTimeZone"
        Me.nudTimeZone.Size = New System.Drawing.Size(37, 19)
        Me.nudTimeZone.TabIndex = 16
        Me.nudTimeZone.Value = New Decimal(New Integer() {540, 0, 0, 0})
        '
        'dtpTestTime
        '
        Me.dtpTestTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTestTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTestTime.Location = New System.Drawing.Point(104, 78)
        Me.dtpTestTime.Name = "dtpTestTime"
        Me.dtpTestTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpTestTime.TabIndex = 15
        '
        'DataDeliveryTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 127)
        Me.Controls.Add(Me.tbTest)
        Me.Controls.Add(Me.nudTimeZone)
        Me.Controls.Add(Me.dtpTestTime)
        Me.Controls.Add(Me.lblProcess)
        Me.Controls.Add(Me.btnStopService)
        Me.Controls.Add(Me.btnStartService)
        Me.Name = "DataDeliveryTest"
        Me.Text = "DataDeliveryService Test Application"
        CType(Me.nudTimeZone, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents lblProcess As System.Windows.Forms.Label
	Friend WithEvents btnStopService As System.Windows.Forms.Button
	Friend WithEvents btnStartService As System.Windows.Forms.Button
    Friend WithEvents timWatch As System.Windows.Forms.Timer
    Friend WithEvents tbTest As System.Windows.Forms.Button
    Friend WithEvents nudTimeZone As System.Windows.Forms.NumericUpDown
    Friend WithEvents dtpTestTime As System.Windows.Forms.DateTimePicker

End Class
