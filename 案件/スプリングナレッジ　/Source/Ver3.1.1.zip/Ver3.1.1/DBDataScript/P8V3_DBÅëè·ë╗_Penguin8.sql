--TABLE:M_ProductSub
print 'M_ProductSub'
truncate table M_ProductSub

go

--TABLE:S_Session
print 'S_Session'
truncate table S_Session

go

--TABLE:T_LossLimitLog
print 'T_LossLimitLog'
truncate table T_LossLimitLog

go

--TABLE:T_OperationHist
print 'T_OperationHist'
truncate table T_OperationHist

go

--TABLE:T_PriceChartHist
print 'T_PriceChartHist'
truncate table T_PriceChartHist

go

--TABLE:T_RateChartHist
print 'T_RateChartHist'
truncate table T_RateChartHist

go

--TABLE:T_RateHist
print 'T_RateHist'
truncate table T_RateHist

go
