--TABLE:S_WebServiceInfo
print 'S_WebServiceInfo'
truncate table S_WebServiceInfo
insert into S_WebServiceInfo
select
	 [NowDate]
	,[ServerName]
	,[ProcessID]
	,dateadd(minute, -540, [InitTime]) [InitTime]
	,dateadd(minute, -540, [LastUpdateTime]) [LastUpdateTime]
	,[AdminUserCount]
	,[AdminUserCountMax]
	,[CustUserCount]
	,[CustUserCountMax]
from V1Penguin8SysInfo..S_WebServiceInfo with ( nolock )

go
