--TABLE:M_CalcParam
print 'M_CalcParam'
truncate table M_CalcParam
insert into M_CalcParam
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ComCode]
	,[InterestRate]
	,[SwapRate]
	,[VolatilityAdjust]
	,[Volatility]
	,[DeltaVariation]
	,[GammaVariation]
	,[VegaVariation]
	,[ThetaVariation]
	,[RhoVariation]
from V1Penguin8..M_CalcParam with ( nolock )

go

--TABLE:M_CalcParamHist
print 'M_CalcParamHist'
truncate table M_CalcParamHist
insert into M_CalcParamHist
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[SysDate]
	,[ComCode]
	,[InterestRate]
	,[SwapRate]
	,[VolatilityAdjust]
	,[Volatility]
	,[DeltaVariation]
	,[GammaVariation]
	,[VegaVariation]
	,[ThetaVariation]
	,[RhoVariation]
from V1Penguin8..M_CalcParamHist with ( nolock )

go

--TABLE:M_CalcParamSettings
print 'M_CalcParamSettings'
truncate table M_CalcParamSettings
insert into M_CalcParamSettings
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ComCode]
	,[InterestRate]
	,[SwapRate]
	,[VolatilityAdjust]
from V1Penguin8..M_CalcParamSettings with ( nolock )

go

--TABLE:M_Customer
print 'M_Customer'
truncate table M_Customer
insert into M_Customer
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[CustCode]
	,[CustName]
	,[CmpCode]
	,'JPY' [CurCode]
	,'0' [DealDisabled]
	,200000 [LossLimit]
	,0 [TestValue]
from V1Penguin8..M_Customer with ( nolock )

go

--TABLE:M_Product
print 'M_Product'
truncate table M_Product
insert into M_Product (
	 [InsTime]
	,[InsUser]
	,[UpdTime]
	,[UpdUser]
	,[ProductCode]
	,[Enabled]
	,[ProductBaseCode]
	,[SysDate]
	,[ComCode]
	,[OpType]
	,[StartTime]
	,[ExercTime]
	,[TradeLimitTime]
	,[PayoutRate]
	,[ExercStatus]
	,[ExercPriceStatus]
	,[ExercRateSeq]
	,[ExercRate]
	)
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ProductCode]
	,[Enabled]
	,[ProductBaseCode]
	,[SysDate]
	,[ComCode]
	,[OpType]
	,DATEADD(minute, -540, [StartTime]) [StartTime]
	,DATEADD(minute, -540, [ExercTime]) [ExercTime]
	,DATEADD(minute, -540, [TradeLimitTime]) [TradeLimitTime]
	,[PayoutRate]
	,[ExercStatus]
	,'0' [ExercPriceStatus]	
	,[ExercRateSeq]
	,[ExercRate]
from V1Penguin8..M_Product with ( nolock )

go

--TABLE:M_ProductBase
print 'M_ProductBase'
truncate table M_ProductBase
insert into M_ProductBase (
	 [InsTime]
	,[InsUser]
	,[UpdTime]
	,[UpdUser]
	,[ProductBaseCode]
	,[Enabled]
	,[ComCode]
	,[OpType]
	,[OptionTime]
	,[CreateTime]
	,[StartTime]
	,[ExercTime]
	,[PayoutRate]
	)
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ProductBaseCode]
	,[Enabled]
	,[ComCode]
	,[OpType]
	,[OptionTime]
	,[CreateTime]
	,[StartTime]
	,[ExercTime]
	,[PayoutRate]
from V1Penguin8..M_ProductBase with ( nolock )

go

--TABLE:M_RateFilter
print 'M_RateFilter'
truncate table M_RateFilter
insert into M_RateFilter
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ComCode]
	,[RateFilterDiff]
	,[RateFilterCountMax]
	,[AnomalyRateDiff]
from V1Penguin8..M_RateFilter with ( nolock )

go

--TABLE:M_User
print 'M_User'
truncate table M_User
insert into M_User
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[UserId]
	,[Enabled]
	,[UserName]
	,[Password]
	,[UserType]
	,[CmpCode]
	,DATEADD(minute, -540, [LastAuthTime]) [LastAuthTime]
from V1Penguin8..M_User with ( nolock )

go

--TABLE:S_BulkTask
print 'S_BulkTask'
truncate table S_BulkTask
insert into S_BulkTask
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[TaskSeq]
	,[TaskStatus]
	,[TaskType]
	,[TaskParam]
	,[LastStep]
	,[ExecStep]
	,DATEADD(minute, -540, [ExecStartTime]) [ExecStartTime]
	,DATEADD(minute, -540, [ExecEndTime]) [ExecEndTime]
	,[TaskResult]
from V1Penguin8..S_BulkTask with ( nolock )

go

--TABLE:S_ClientSettings
print 'S_ClientSettings'
truncate table S_ClientSettings
insert into S_ClientSettings
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[AuthType]
	,[UserID]
	,[ClientType]
	,[Settings]
from V1Penguin8..S_ClientSettings with ( nolock )

go

--TABLE:S_SalesPerformance
print 'S_SalesPerformance'
truncate table S_SalesPerformance
insert into S_SalesPerformance
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[SysDate]
	,[CmpCode]
	,[AccountCount]
	,[AccountCountEnabled]
	,[NewAccountCount]
	,[TradeAccountCount]
	,[TradeCount]
	,[TradeAmount]
	,[TotalMoney]
	,[TotalPAndL]
	,[CashInCount]
	,[CashInMoney]
	,[CashOutCount]
	,[CashOutMoney]
from V1Penguin8..S_SalesPerformance with ( nolock )

go

--TABLE:T_Cash
print 'T_Cash'
truncate table T_Cash
insert into T_Cash
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[CashCode]
	,[Enabled]
	,[SysDate]
	,DATEADD(minute, -540, [ExecTime]) [ExecTime]
	,[CustCode]
	,[CmpCode]
	,[CashType]
	,'JPY' [CurCode]
	,[Money]
	,[TotalMoney]
from V1Penguin8..T_Cash with ( nolock )

go

--TABLE:T_Account
print 'T_Account'
truncate table T_Account
insert into T_Account
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[CustCode]
	,[CmpCode]
	,'JPY' [CurCode]
	,[TotalMoney]
	,0 [PAndLMonthly]
from V1Penguin8..T_CashSpot with ( nolock )

go

--TABLE:T_CustHistSpot
print 'T_CustHistSpot'
truncate table T_CustHistSpot
insert into T_CustHistSpot
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,[SysDate]
	,[CustCode]
	,[CmpCode]
	,'JPY' [CurCode]
	,'0' [DealDisabled]
	,null [LossLimit]
	,[TotalMoney]
	,null [PAndLMonthly]
from V1Penguin8..T_CustHistSpot with ( nolock )

go

--TABLE:T_ProductTradeSum
print 'T_ProductTradeSum'
truncate table T_ProductTradeSum
insert into T_ProductTradeSum
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ProductCode]
	,[TradeCount]
	,[AbandCount]
	,[ExercITMCount]
	,[ExercATMCount]
	,[ExercOTMCount]
from V1Penguin8..T_ProductTradeSum with ( nolock )

go

--TABLE:T_ProductTradeSumCur
print 'T_ProductTradeSumCur'
truncate table T_ProductTradeSumCur
insert into T_ProductTradeSumCur
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ProductCode]
	,'JPY' [CurCode]
	,[PremiumSum]
	,0
from V1Penguin8..T_ProductTradeSum with ( nolock )

go

--TABLE:T_RateDayClose
print 'T_RateDayClose'
truncate table T_RateDayClose
insert into T_RateDayClose
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[ComCode]
	,[SysDate]
	,[RateSeq]
	,DATEADD(minute, -540, [RateTime]) [RateTime]
	,DATEADD(minute, -540, [RateTimeSource]) [RateTimeSource]
	,[Rate]
	,[RateProviderID]
	,[RateProviderSeq]
from V1Penguin8..T_RateDayClose with ( nolock )

go

--TABLE:T_RateFilterLog
print 'T_RateFilterLog'
truncate table T_RateFilterLog
set identity_insert T_RateFilterLog on 
insert into T_RateFilterLog (
	 [InsTime]
	,[InsUser]
	,[UpdTime]
	,[UpdUser]
	,[LogID]
	,[LogTime]
	,[ComCode]
	,[LogType]
	,[LogText]
	)
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[LogID]
	,DATEADD(minute, -540, [LogTime])[LogTime]
	,[ComCode]
	,[LogType]
	,[LogText]
from V1Penguin8..T_RateFilterLog with ( nolock )
set identity_insert T_RateFilterLog off

declare @initid_T_RateFilterLog bigint
SELECT @initid_T_RateFilterLog=IDENT_CURRENT('V1Penguin8..T_RateFilterLog')
DBCC CHECKIDENT( T_RateFilterLog, RESEED, @initid_T_RateFilterLog) 

go

--TABLE:T_RateHistExerc
print 'T_RateHistExerc'
truncate table T_RateHistExerc
insert into T_RateHistExerc
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,DATEADD(minute, -540, [UpdTime]) [UpdTime]
	,[UpdUser]
	,[RateSeq]
	,[Enabled]
	,[ComCode]
	,DATEADD(minute, -540, [RateTime]) [RateTime]
	,DATEADD(minute, -540, [RateTimeSource]) [RateTimeSource]
	,[Rate]
	,[Exerc]
	,DATEADD(minute, -540, [ExercTime]) [ExercTime]
	,[ViewSeq]
	,[RateProviderID]
	,[RateProviderSeq]
from V1Penguin8..T_RateHistExerc with ( nolock )

go

--TABLE:T_RateHistSpot
print 'T_RateHistSpot'
update T_RateHistSpot set
	 [UpdTime] = V1.[UpdTime]
	,[UpdUser] = V1.[UpdUser]
	,[RateSeq] = V1.[RateSeq]
	,[Enabled] = V1.[Enabled]
	,[ComCode] = V1.[ComCode]
	,[RateTime] = DATEADD(minute, -540, V1.[RateTime])
	,[RateTimeSource] = DATEADD(minute, -540, V1.[RateTimeSource])
	,[Rate] = V1.[Rate]
	,[Exerc] = V1.[Exerc]
	,[ExercTime] = DATEADD(minute, -540, V1.[ExercTime])
	,[ViewSeq] = V1.[ViewSeq]
	,[RateProviderID] = V1.[RateProviderID]
	,[RateProviderSeq] = V1.[RateProviderSeq]
from T_RateHistSpot V3
inner join V1Penguin8..T_RateHistSpot V1 on V3.[ComCode] = V1.[ComCode]

go

--TABLE:T_Trade
print 'T_Trade'
truncate table T_Trade
insert into T_Trade (
	 [InsTime]
	,[InsUser]
	,[UpdTime]
	,[UpdUser]
	,[TradeSeq]
	,[TradeSubSeq]
	,[SysDate]
	,[ProductCode]
	,[ComCode]
	,[OpType]
	,[PayoutRate]
	,[CurCode]
	,[TradeType]
	,[Premium]
	,[Commission]
	,[CustCode]
	,[CmpCode]
	,[TradeStatus]
	,[OrderReqTime]
	,[OrderClientRateSeq]
	,[OrderClientRateTime]
	,[OrderClientRate]
	,[AbandReqTime]
	,[AbandClientRateSeq]
	,[AbandClientRateTime]
	,[AbandClientRate]
	,[TradeTime]
	,[TradeRateSeq]
	,[TradeRateTime]
	,[TradeRate]
	,[ExercPrice]
	,[StartTime]
	,[ExercTime]
	,[ExercProcTime]
	,[ExercRateSeq]
	,[ExercRateTime]
	,[ExercRate]
	,[ExercPayoutRate]
	,[Payout]
	,[PAndL]
	,[Memo]
	,[InfoTitle]
	,[Info]
	)
select
	 DATEADD(minute, -540, T.[InsTime]) [InsTime]
	,T.[InsUser]
	,DATEADD(minute, -540, T.[UpdTime]) [UpdTime]
	,T.[UpdUser]
	,T.[TradeSeq]
	,T.[TradeSubSeq]
	,T.[SysDate]
	,T.[ProductCode]
	,T.[ComCode]
	,T.[OpType]
	,T.[PayoutRate]
	,'JPY' [CurCode]
	,T.[TradeType]
	,T.[Premium]
	,T.[Commission]
	,T.[CustCode]
	,T.[CmpCode]
	,T.[TradeStatus]
	,DATEADD(minute, -540, T.[OrderReqTime]) [OrderReqTime]
	,T.[OrderClientRateSeq]
	,DATEADD(minute, -540, T.[OrderClientRateTime]) [OrderClientRateTime]
	,T.[OrderClientRate]
	,DATEADD(minute, -540, T.[AbandReqTime]) [AbandReqTime]
	,T.[AbandClientRateSeq]
	,DATEADD(minute, -540, T.[AbandClientRateTime]) [AbandClientRateTime]
	,T.[AbandClientRate]
	,DATEADD(minute, -540, T.[TradeTime]) [TradeTime]
	,T.[TradeRateSeq]
	,DATEADD(minute, -540, T.[TradeRateTime]) [TradeRateTime]
	,T.[TradeRate]
	,T.[ExercPrice]
	,DATEADD(minute, -540, M.[StartTime]) [StartTime]
	,DATEADD(minute, -540, T.[ExercTime]) [ExercTime]
	,DATEADD(minute, -540, T.[ExercProcTime]) [ExercProcTime]
	,T.[ExercRateSeq]
	,DATEADD(minute, -540, T.[ExercRateTime]) [ExercRateTime]
	,T.[ExercRate]
	,T.[ExercPayoutRate]
	,T.[Payout]
	,T.[PAndL]
	,T.[Memo]
	,T.[InfoTitle]
	,T.[Info]
from V1Penguin8..T_Trade T with ( nolock )
inner join V1Penguin8..M_Product M with ( nolock ) on T.[ProductCode] = M.[ProductCode]

go

--TABLE:T_TradeNew
print 'T_TradeNew'
truncate table T_TradeNew
set identity_insert T_TradeNew on 
insert into T_TradeNew (
	 [InsTime]
	,[Seq]
	,[TradeSeq]
	,[TradeSubSeq]
	,[TradeStatus]
	)
select
	 DATEADD(minute, -540, [InsTime]) [InsTime]
	,[Seq]
	,[TradeSeq]
	,[TradeSubSeq]
	,[TradeStatus]
from V1Penguin8..T_TradeNew with ( nolock )
set identity_insert T_TradeNew off

declare @initid_T_TradeNew bigint
SELECT @initid_T_TradeNew=IDENT_CURRENT('V1Penguin8..T_TradeNew')
DBCC CHECKIDENT( T_TradeNew, RESEED, @initid_T_TradeNew) 

go
