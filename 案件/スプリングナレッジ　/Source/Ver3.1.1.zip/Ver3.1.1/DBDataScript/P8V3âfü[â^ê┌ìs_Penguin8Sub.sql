--TABLE:T_CustHist
print 'T_CustHist'
truncate table T_CustHist
insert into T_CustHist
select
	 dateadd(minute, -540, [InsTime]) [InsTime]
	,[InsUser]
	,[SysDate]
	,[CustCode]
	,'0' [DealDisabled]
	,null [LossLimit]
	,[TotalMoney]
	,null [PAndLMonthly]
from V1Penguin8Sub..T_CustHist with ( nolock )

go
