--TABLE:M_CalcParamSettings
print 'M_CalcParamSettings'
update M_CalcParamSettings set
	 UpdTime = SYSUTCDATETIME()
	,UpdUser = 'S:Sys Admin'
	,VolatilityAdjust = 1

go

--TABLE:M_CurrencyPair
print 'M_CurrencyPair'

update M_CurrencyPair set
	 UpdTime = SYSUTCDATETIME()
	,UpdUser = 'S:Sys Admin'
	,LimitOrderRate = 50
	,LimitAbandRate = 50
where ComCode = 'USDJPY'

update M_CurrencyPair set
	 UpdTime = SYSUTCDATETIME()
	,UpdUser = 'S:Sys Admin'
	,LimitOrderRate = 50
	,LimitAbandRate = 50
where ComCode = 'EURJPY'

update M_CurrencyPair set
	 UpdTime = SYSUTCDATETIME()
	,UpdUser = 'S:Sys Admin'
	,LimitOrderRate = 50
	,LimitAbandRate = 50
where ComCode = 'EURUSD'

go

/*
--�q���Z�ʏ��l�ɂĖ����ݒ�̖����������{�ς�
--TABLE:M_ProductBase
print 'M_ProductBase'
update M_ProductBase set
	 UpdTime = SYSUTCDATETIME()
	,UpdUser = 'S:Sys Admin'
	,Enabled = '0'

go
*/

--TABLE:M_SysSettings
print 'M_SysSettings'
truncate table M_SysSettings
insert into M_SysSettings
values (
	 SYSUTCDATETIME()	--[InsTime]
	,'S:Sys Admin'		--[InsUser]
	,SYSUTCDATETIME()	--[UpdTime]
	,'S:Sys Admin'		--[UpdUser]
    ,'0'				--[SysCode]
    ,120				--[StopTradeTime]
    ,5					--[StartAbandTime]
    ,0					--[AbandPriceDiff]
    ,0					--[Commission]
    ,0					--[AbandMargine]
    ,0					--[TradeMoneyMin]
    ,0					--[TradeLotMin]
    ,0					--[TradeMoneyMax]
    ,0					--[TradeLotMax]
    ,0					--[ProductMoneyMax]
    ,0					--[ProductLotMax]
    ,20					--[CustCountMax]
    ,0					--[CustMoneyMax]
    ,50					--[CustLotMax]
    ,0					--[CustProductMoneyMax]
    ,50					--[CustProductLotMax]
    ,0					--[CashInMoneyMin]
    ,200000				--[CashInMoneyDayMin]
    ,0					--[CashOutMoneyMax]
    ,200000				--[CashOutMoneyDayMax]
    ,300				--[ProductStartPreTime]
    ,30					--[ProductEndLossTime]
    ,30					--[RateEnableTime]
    ,540				--[TimeZone]
    ,120				--[SysDateTimeZone]
)

go

--TABLE:S_ClientSettings
print 'S_ClientSettings'
delete S_ClientSettings where [AuthType] = '1'

go

--TABLE:S_SysStatus
print 'S_SysStatus'
update S_SysStatus set SysUpdateSeq = 1

go
