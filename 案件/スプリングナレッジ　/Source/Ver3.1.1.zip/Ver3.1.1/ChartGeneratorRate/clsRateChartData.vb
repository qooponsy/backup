﻿Public Enum DBUpdateFlg
    NoUpdate = 0
    Update = 1
    Insert = 2
End Enum

Public Class clsRateChartData
    Public UpdFlg As Integer
    Public RateChartSeq As String
    Public ComCode As String
    Public ChartType As Integer
    Public RateSeq As String
    Public RateChartTime As DateTime
    Public OpenRate As Decimal
    Public HighRate As Decimal
    Public LowRate As Decimal
    Public CloseRate As Decimal
    Public CloseTime As DateTime
End Class
