﻿Imports System.Runtime.Serialization

<DataContract()> _
Public Class ResponseInitPriceList

    <DataMember()> _
    Public result As String = Nothing
    <DataMember()> _
    Public message As String = Nothing
    <DataMember()> _
    Public operationNumber As String = Nothing
    <DataMember()> _
    Public priceAndQuotationDtosCnt As String = Nothing
    <DataMember()> _
    Public priceAndQuotationDtos As ResponsePriceAndQuotationDto() = Nothing

End Class
