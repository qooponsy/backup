﻿Imports System.Runtime.Serialization

<DataContract()> _
Public Class ResponsePriceAndQuotationDto

    <DataMember()> _
    Public symbolCode As String = Nothing
    <DataMember()> _
    Public seq As String = Nothing
    <DataMember()> _
    Public bidRate As String = Nothing
    <DataMember()> _
    Public askRate As String = Nothing
    <DataMember()> _
    Public changeRatio As String = Nothing
    <DataMember()> _
    Public openPrice As String = Nothing
    <DataMember()> _
    Public highPrice As String = Nothing
    <DataMember()> _
    Public lowPrice As String = Nothing
    <DataMember()> _
    Public highTime As String = Nothing
    <DataMember()> _
    Public lowTime As String = Nothing
    <DataMember()> _
    Public previousClosePrice As String = Nothing
    <DataMember()> _
    Public calcTime As String = Nothing
    <DataMember()> _
    Public autoTime As String = Nothing

End Class
