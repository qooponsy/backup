﻿Imports System.Data.SqlClient

Public Class TickChartServlet
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim reqComCode As String = Request("comcode")
        Dim reqCount As String = Request("count")
        Dim reqBid As String = Request("bid")
        Dim reqAsk As String = Request("ask")
        Dim reqFrom As String = Request("from")

        Dim success As Boolean = False
        Dim ErrorMsg As String = ""

        Dim ComCode As String = ""
        Dim Bid As Boolean = False
        Dim Ask As Boolean = False
        Dim FromValue As Integer = 0
        Dim DataCount As Integer = 0
        Dim TimeList As New List(Of DateTime)
        Dim BidList As New List(Of Decimal)
        Dim AskList As New List(Of Decimal)

        Do
            If reqComCode Is Nothing OrElse reqComCode.Length <> 6 Then
                ErrorMsg = "通貨ペアコードの指定が間違っています。"
                Exit Do
            End If
            Select Case reqComCode
                Case "EURUSD"
                Case "USDJPY"
                Case "EURJPY"
                Case "GBPUSD"
                Case "GBPJPY"
                Case "AUDJPY"
                Case Else
                    ErrorMsg = "通貨ペアコードの指定が間違っています。"
                    Exit Do
            End Select
            ComCode = reqComCode

            If reqCount Is Nothing OrElse reqCount.Length = 0 Then
                ErrorMsg = "取得本数の指定が間違っています。"
                Exit Do
            End If
            Dim Count As Integer = 0
            If Not Integer.TryParse(reqCount, Count) Then
                ErrorMsg = "取得本数の指定が間違っています。"
                Exit Do
            End If
            If Count < 0 Then
                ErrorMsg = "取得本数の指定が間違っています。"
                Exit Do
            End If
            If Count > 400 Then
                Count = 400
            End If

            If reqBid Is Nothing OrElse reqBid.Length <> 1 Then
                ErrorMsg = "BIDの取得有無の指定が間違っています。"
                Exit Do
            End If
            Select Case reqBid
                Case "t" : Bid = True
                Case "f" : Bid = False
                Case Else
                    ErrorMsg = "BIDの取得有無の指定が間違っています。"
                    Exit Do
            End Select

            If reqAsk Is Nothing OrElse reqAsk.Length <> 1 Then
                ErrorMsg = "ASKの取得有無の指定が間違っています。"
                Exit Do
            End If
            Select Case reqAsk
                Case "t" : Ask = True
                Case "f" : Ask = False
                Case Else
                    ErrorMsg = "ASKの取得有無の指定が間違っています。"
                    Exit Do
            End Select

            If reqFrom Is Nothing OrElse reqFrom.Length = 0 Then
                ErrorMsg = "通番の指定が間違っています。"
                Exit Do
            End If
            If Not Integer.TryParse(reqFrom, FromValue) Then
                ErrorMsg = "通番の指定が間違っています。"
                Exit Do
            End If

            Using con As New SqlConnection(My.Settings.DB)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = String.Format("select top {0} * from [Rate] where [ComCode] = @ComCode and [ProviderID]>=@From order by [ProviderID] desc", reqCount)
                    cmd.Parameters.Add("@ComCode", SqlDbType.Char, 6).Value = ComCode
                    cmd.Parameters.Add("@From", SqlDbType.Int).Value = fromValue
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read
                            DataCount += 1
                            TimeList.Add(reader("RateTime"))
                            BidList.Add(reader("Bid"))
                            AskList.Add(reader("Ask"))
                            FromValue = reader("ProviderID") + 1
                        End While
                    End Using
                End Using
            End Using

            success = True
        Loop While False

        If success Then
            Response.Write("," & vbLf)
            Response.Write(ComCode & "," & IIf(Bid, "t", "f") & "," & IIf(Ask, "t", "f") & "," & FromValue.ToString() & vbLf)
            Response.Write(DataCount.ToString() & vbLf)
            For fa As Integer = 0 To TimeList.Count - 1
                Response.Write(TimeList(fa).ToString("yyyyMMddHHmmss") & "," & IIf(Bid, BidList(fa).ToString("######0.000#####"), "") & "," & IIf(Ask, AskList(fa).ToString("######0.000#####"), "") & vbLf)
            Next
        Else
            Response.Write("ERROR00001," & ErrorMsg & vbLf)
        End If
    End Sub

End Class