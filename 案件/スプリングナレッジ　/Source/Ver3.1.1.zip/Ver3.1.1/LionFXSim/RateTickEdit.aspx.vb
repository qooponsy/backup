﻿Imports System.Data.SqlClient

Public Class RateTickEdit
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim reqComCode As String = Request("comcode")

        Dim reqProviderID0 As String = Request("id0")
        Dim reqProviderID1 As String = Request("id1")
        Dim reqProviderID2 As String = Request("id2")
        Dim reqProviderID3 As String = Request("id3")
        Dim reqProviderID4 As String = Request("id4")
        Dim reqProviderID5 As String = Request("id5")
        Dim reqProviderID6 As String = Request("id6")
        Dim reqProviderID7 As String = Request("id7")
        Dim reqProviderID8 As String = Request("id8")
        Dim reqProviderID9 As String = Request("id9")

        Dim reqBid0 As String = Request("bid0")
        Dim reqBid1 As String = Request("bid1")
        Dim reqBid2 As String = Request("bid2")
        Dim reqBid3 As String = Request("bid3")
        Dim reqBid4 As String = Request("bid4")
        Dim reqBid5 As String = Request("bid5")
        Dim reqBid6 As String = Request("bid6")
        Dim reqBid7 As String = Request("bid7")
        Dim reqBid8 As String = Request("bid8")
        Dim reqBid9 As String = Request("bid9")

        Dim reqAsk0 As String = Request("ask0")
        Dim reqAsk1 As String = Request("ask1")
        Dim reqAsk2 As String = Request("ask2")
        Dim reqAsk3 As String = Request("ask3")
        Dim reqAsk4 As String = Request("ask4")
        Dim reqAsk5 As String = Request("ask5")
        Dim reqAsk6 As String = Request("ask6")
        Dim reqAsk7 As String = Request("ask7")
        Dim reqAsk8 As String = Request("ask8")
        Dim reqAsk9 As String = Request("ask9")

        Dim reqTime0 As String = Request("time0")
        Dim reqTime1 As String = Request("time1")
        Dim reqTime2 As String = Request("time2")
        Dim reqTime3 As String = Request("time3")
        Dim reqTime4 As String = Request("time4")
        Dim reqTime5 As String = Request("time5")
        Dim reqTime6 As String = Request("time6")
        Dim reqTime7 As String = Request("time7")
        Dim reqTime8 As String = Request("time8")
        Dim reqTime9 As String = Request("time9")

        Dim success As Boolean = False
        Dim result As New ResResult
        Dim list As New List(Of List(Of Object))

        Do
            If reqComCode Is Nothing OrElse reqComCode.Length <> 6 Then
                result.Code = "X00001"
                result.Text = "通貨ペアコードの指定が間違っています。"
                Exit Do
            End If
            Select Case reqComCode
                Case "EURUSD"
                Case "USDJPY"
                Case "EURJPY"
                Case "GBPUSD"
                Case "GBPJPY"
                Case "AUDJPY"
                Case Else
                    result.Code = "X00001"
                    result.Text = "通貨ペアコードの指定が間違っています。"
                    Exit Do
            End Select
            Dim ComCode As String = reqComCode

            EditRow(ComCode, 0, reqProviderID0, reqBid0, reqAsk0, reqTime0)
            EditRow(ComCode, 1, reqProviderID1, reqBid1, reqAsk1, reqTime1)
            EditRow(ComCode, 2, reqProviderID2, reqBid2, reqAsk2, reqTime2)
            EditRow(ComCode, 3, reqProviderID3, reqBid3, reqAsk3, reqTime3)
            EditRow(ComCode, 4, reqProviderID4, reqBid4, reqAsk4, reqTime4)
            EditRow(ComCode, 5, reqProviderID5, reqBid5, reqAsk5, reqTime5)
            EditRow(ComCode, 6, reqProviderID6, reqBid6, reqAsk6, reqTime6)
            EditRow(ComCode, 7, reqProviderID7, reqBid7, reqAsk7, reqTime7)
            EditRow(ComCode, 8, reqProviderID8, reqBid8, reqAsk8, reqTime8)
            EditRow(ComCode, 9, reqProviderID9, reqBid9, reqAsk9, reqTime9)

            success = True
        Loop While False

        Dim res As New ResBuilder
        res.result = result
        If success Then
            res.Append(list)
        End If

        Response.Write(res.GetResponse())
    End Sub

    Private Sub EditRow(ComCode As String, RowID As Integer, reqProviderID As String, reqBid As String, reqAsk As String, reqTime As String)
        If reqProviderID Is Nothing OrElse reqProviderID.Length = 0 Then Exit Sub
        Dim ProviderID As Integer
        If Not Integer.TryParse(reqProviderID, ProviderID) Then Exit Sub
        If ProviderID < 0 Then Exit Sub

        If reqBid Is Nothing OrElse reqBid.Length = 0 Then Exit Sub
        Dim Bid As Decimal
        If Not Decimal.TryParse(reqBid, Bid) Then Exit Sub
        If Bid < 0 Then Exit Sub

        If reqAsk Is Nothing OrElse reqAsk.Length = 0 Then Exit Sub
        Dim Ask As Decimal
        If Not Decimal.TryParse(reqAsk, Ask) Then Exit Sub
        If Ask < 0 Then Exit Sub

        If reqTime Is Nothing OrElse reqTime.Length = 0 Then Exit Sub
        Dim RateTime As DateTime
        If Not DateTimeUtil.ConvToDateTime(reqTime, DateTimeUtil.ComplementMode.fromTime, RateTime) Then Exit Sub

        Using con As New SqlConnection(My.Settings.DB)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                cmd.CommandText = "update [Rate] set [ProviderID]=@ProviderID, [Bid]=@Bid, [Ask]=@Ask, [RateTime]=@RateTime where [ComCode] = @ComCode and [RowID]=@RowID"
                Dim param As SqlParameter
                cmd.Parameters.Add("@ComCode", SqlDbType.Char, 6).Value = ComCode
                cmd.Parameters.Add("@RowID", SqlDbType.Int).Value = RowID
                cmd.Parameters.Add("@ProviderID", SqlDbType.Int).Value = ProviderID
                param = cmd.Parameters.Add("@Bid", SqlDbType.Decimal)
                param.Precision = 15
                param.Scale = 8
                param.Value = Bid
                param = cmd.Parameters.Add("@Ask", SqlDbType.Decimal)
                param.Precision = 15
                param.Scale = 8
                param.Value = Ask
                cmd.Parameters.Add("@RateTime", SqlDbType.DateTime).Value = RateTime
                cmd.ExecuteNonQuery()
            End Using
        End Using

    End Sub

End Class