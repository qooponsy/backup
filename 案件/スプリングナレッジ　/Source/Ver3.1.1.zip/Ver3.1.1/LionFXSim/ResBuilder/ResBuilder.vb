﻿Imports System.Text

Public Class ResBuilder

    Public result As ResResult
    Public csvheader As String = Nothing

    Public Sub Append(ByVal resdata As Object)
        resDataList.Add(resdata)
    End Sub

    Public Function GetResponse() As String
        Dim res As New StringBuilder
        res.Append(result.Code & "," & encodeString(result.Text))
        For Each resdata In resDataList
            res.Append(vbLf)
            If TypeOf resdata Is List(Of Object) Then
                Dim line As List(Of Object) = resdata
                appendCol(res, line)
            ElseIf TypeOf resdata Is List(Of List(Of Object)) Then
                Dim resList As List(Of List(Of Object)) = resdata
                res.Append(resList.Count)
                For Each linedata In resList
                    res.Append(vbLf)
                    appendCol(res, linedata)
                Next
            Else
                res.Append(getString(resdata))
            End If
        Next
        Return res.ToString()
    End Function

    Public Function GetResponseCsv() As String
        Dim res As New StringBuilder
        If csvheader IsNot Nothing Then
            res.AppendLine(csvheader)
        End If
        For Each resdata In resDataList
            For Each resline In resdata
                Dim line As List(Of Object) = resline
                appendCsvLine(res, line)
            Next
        Next
        Return res.ToString()
    End Function

    Private resDataList As New List(Of Object)

    Private Sub appendCol(ByVal res As StringBuilder, ByVal colList As List(Of Object))
        Dim colDelimiter As String = ""
        For Each coldata In colList
            res.Append(colDelimiter)
            colDelimiter = ","
            res.Append(getString(coldata))
        Next
    End Sub

    Private Sub appendCsvLine(ByVal res As StringBuilder, ByVal colList As List(Of Object))
        Dim colDelimiter As String = ""
        For Each coldata In colList
            res.Append(colDelimiter)
            colDelimiter = ","
            res.Append("""" & getCsvString(coldata) & """")
        Next
        res.AppendLine()
    End Sub

    Private Function getString(ByVal data As Object) As String
        If data Is Nothing Then
            Return vbNullString
        Else
            Select Case TypeName(data)
                Case "Byte", "Char", "Decimal", "Double", "Integer", "Long", "SByte", "Short", "Single", "UInteger", "ULong", "UShort"
                    Return data
                Case "String"
                    Return encodeString(data)
                Case "Date"
                    Return String.Format("{0:yyyyMMddHHmmssfff}", data)
                Case Else
                    Throw New Exception("Invalid Data Type(" & TypeName(data) & ")")
            End Select
        End If
    End Function

    Private Function encodeString(ByVal src As String) As String
        Dim dest As String = src
        dest = Replace(dest, "\", "\0")
        dest = Replace(dest, ",", "\1")
        dest = Replace(dest, vbCr, "\2")
        dest = Replace(dest, vbLf, "\3")
        Return dest
    End Function

    Private Function getCsvString(ByVal data As Object) As String
        If data Is Nothing Then
            Return vbNullString
        Else
            Select Case TypeName(data)
                Case "Byte", "Char", "Decimal", "Double", "Integer", "Long", "SByte", "Short", "Single", "UInteger", "ULong", "UShort"
                    Return data
                Case "String"
                    Return encodeCsvString(data)
                Case "Date"
                    Return String.Format("{0:yyyy/MM/dd HH:mm:ss.fff}", data)
                Case Else
                    Throw New Exception("Invalid Data Type(" & TypeName(data) & ")")
            End Select
        End If
    End Function

    Private Function encodeCsvString(ByVal src As String) As String
        Dim dest As String = src
        dest = Replace(dest, """", """""")
        Return dest
    End Function

End Class
