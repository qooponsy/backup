﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
Imports System.Text

'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsService
    Private strServiceName As String
	Private blnServiceStopFlag As Boolean
	Private blnMasterMode As Boolean

    Private MasterHB() As Byte
	Private SlaveHB() As Byte
	Private HeartBeatUDP As UdpClient
	Private MasterWatch As Stopwatch

    Private Const DefaultChartType As Integer = 1   'チャート種別 1分足

    Private PreTime As Integer

    '開始レート通番
    Private SertchRateSeq As String

    '--------------------------------------------------------------------------
    ' クラスコンストラクタ
    '--------------------------------------------------------------------------
	Public Sub New()
		blnServiceStopFlag = False
        strServiceName = "ChartGeneratorPrice"
#If REL_DEMO Then
        strServiceName = "ChartGeneratorPriceDemo"
#End If
#If REL_TEST Then
        strServiceName = "ChartGeneratorPriceTest"
#End If
#If REL_NEXT Then
        strServiceName = "ChartGeneratorPriceNext"
#End If
#If REL_V3 Then
        strServiceName = "ChartGeneratorPriceV3"
#End If
        blnMasterMode = False
    End Sub

	'--------------------------------------------------------------------------
	' マスターモード稼動判定
	'--------------------------------------------------------------------------
	Public Function IsMasterMode() As Boolean
		Return blnMasterMode
	End Function

	'--------------------------------------------------------------------------
	' サービス制御スレッドの初期設定
	'--------------------------------------------------------------------------
    Public Function InitializeService() As Boolean
        Dim ret As Boolean = False

        ' ハートビート電文の編集
        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)

        ProcTimeInfo.Initialization()

        ret = True

        Return ret
    End Function

	'--------------------------------------------------------------------------
	' サービス制御スレッド
	'--------------------------------------------------------------------------
	Public Sub ServiceThread()
        Dim HeartBeatWatch As Stopwatch

        Dim DataBase As clsPenguinDB = Nothing
        Dim ProductPriceChartList As List(Of clsProductPriceChartData) = Nothing
        Dim CurrencyPairCalcParamList As List(Of clsCurrencyPairCalcParamData) = Nothing
        Dim PriceChartUpdateList As List(Of clsPriceChartData) = Nothing
        Dim PriceChartInsCnt As Integer = 0
        Dim procTimeWatch As Stopwatch = Nothing
        Dim IniFlg As Boolean = True

        Logging("ServiceThread Start.", EventLogEntryType.Information)

        RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTimeWeekEnd)
        Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
		MasterWatch = Stopwatch.StartNew

        Dim iHeartBeatCycle As Integer = My.Settings.HeartBeatCycle
        '-----------------------------------------------------------------
        ' 初期状態としてSlaveモードに設定
        '-----------------------------------------------------------------
        OnSlaveMode()

        '-----------------------------------------------------------------
        ' 生存確認のStopWatch開始
        '-----------------------------------------------------------------
        HeartBeatWatch = Stopwatch.StartNew

        '-----------------------------------------------------------------
        ' 停止フラグ=Trueになるまでサービス処理をLoop
        '-----------------------------------------------------------------
        While Not blnServiceStopFlag
            If HeartBeatWatch.ElapsedMilliseconds() >= iHeartBeatCycle Then
                CheckMasterAlive()
                HeartBeatWatch.Stop()
                HeartBeatWatch.Reset()
                HeartBeatWatch.Start()
            End If

            If RunningContoroller.check() Then
                Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
            End If
            If RunningContoroller.Running Then
                If blnMasterMode Then
                    Try
                        DataBase = New clsPenguinDB

                        If Not DataBase.GetSqlConnection(My.Settings.DB) Then
                            IniFlg = True
                            Exit Try
                        End If

                        If IniFlg Then
                            If Not IsNothing(ProductPriceChartList) Then
                                ProductPriceChartList.Clear()
                                ProductPriceChartList = Nothing
                            End If
                            ProductPriceChartList = New List(Of clsProductPriceChartData)(6 * 2)
                            If Not IsNothing(CurrencyPairCalcParamList) Then
                                CurrencyPairCalcParamList.Clear()
                                CurrencyPairCalcParamList = Nothing
                            End If
                            CurrencyPairCalcParamList = New List(Of clsCurrencyPairCalcParamData)(6)
                            If Not IsNothing(PriceChartUpdateList) Then
                                PriceChartUpdateList.Clear()
                                PriceChartUpdateList = Nothing
                            End If
                            PriceChartUpdateList = New List(Of clsPriceChartData)(6 * 11 * 5 * 2)
                            SertchRateSeq = "99999999999999999"
                        End If

                        PriceChartInsCnt = 0
                        IniFlg = True

                        If DataBase.GetCurrencyPairCalcParamData(CurrencyPairCalcParamList) Then
                            If My.Settings.ProcTimeInfo > 0 Then
                                procTimeWatch = Stopwatch.StartNew()
                            End If
                            If DataBase.SetProductData(ProductPriceChartList, DefaultChartType) Then
                                If My.Settings.ProcTimeInfo > 0 Then
                                    procTimeWatch.Stop()
                                    Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                    ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_READ_PRODUCT_PRODUCTSUB, resTime)
                                    procTimeWatch = Stopwatch.StartNew()
                                End If
                                If DataBase.SetLastPriceChartPriceAll(ProductPriceChartList, SertchRateSeq) Then
                                    If My.Settings.ProcTimeInfo > 0 Then
                                        procTimeWatch.Stop()
                                        Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                        ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_READ_LAST_PRICECHARTHIST, resTime)
                                        procTimeWatch = Stopwatch.StartNew()
                                    End If
                                    If DataBase.CreateRegistPriceChartList(CurrencyPairCalcParamList, SertchRateSeq, ProductPriceChartList, PriceChartUpdateList, PriceChartInsCnt) Then
                                        If My.Settings.ProcTimeInfo > 0 Then
                                            procTimeWatch.Stop()
                                            Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                            ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_READ_RATEHIST, resTime)
                                            procTimeWatch = Stopwatch.StartNew()
                                        End If
                                        If DataBase.RegistPriceChartData(PriceChartUpdateList, My.Settings.ProcessID, PriceChartInsCnt) Then
                                            If My.Settings.ProcTimeInfo > 0 Then
                                                procTimeWatch.Stop()
                                                Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                                ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_UPDATE, resTime)
                                            End If
                                            ProductPriceChartDataMaintenance(ProductPriceChartList)
                                            IniFlg = False
                                        Else
                                            If My.Settings.ProcTimeInfo > 0 Then
                                                procTimeWatch.Stop()
                                                Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                                ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_UPDATE, resTime)
                                            End If
                                        End If
                                    Else
                                        If My.Settings.ProcTimeInfo > 0 Then
                                            procTimeWatch.Stop()
                                            Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                            ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_READ_RATEHIST, resTime)
                                        End If
                                    End If
                                Else
                                    If My.Settings.ProcTimeInfo > 0 Then
                                        procTimeWatch.Stop()
                                        Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                        ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_READ_LAST_PRICECHARTHIST, resTime)
                                    End If
                                End If
                            Else
                                If My.Settings.ProcTimeInfo > 0 Then
                                    procTimeWatch.Stop()
                                    Dim resTime As Integer = procTimeWatch.ElapsedMilliseconds
                                    ProcTimeInfo.AddTimeData(ProcTimeInfo.DataType.DB_READ_PRODUCT_PRODUCTSUB, resTime)
                                End If
                            End If
                        End If

                        outputMinuteLog(False)
                    Catch ex As Exception
                        Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
                        IniFlg = True
                    Finally
                        If Not IsNothing(DataBase) Then
                            DataBase.EndSqlConnection()
                        End If
                        DataBase = Nothing
                        If Not IsNothing(CurrencyPairCalcParamList) Then
                            CurrencyPairCalcParamList.Clear()
                        End If
                        If Not IsNothing(PriceChartUpdateList) Then
                            PriceChartUpdateList.Clear()
                        End If
                        procTimeWatch = Nothing
                    End Try
                Else
                    IniFlg = True
                End If
            Else
                IniFlg = True
            End If

            Thread.Sleep(My.Settings.ServiceInterval)
        End While
        If Not IsNothing(ProductPriceChartList) Then
            ProductPriceChartList.Clear()
            ProductPriceChartList = Nothing
        End If
        If Not IsNothing(CurrencyPairCalcParamList) Then
            CurrencyPairCalcParamList.Clear()
            CurrencyPairCalcParamList = Nothing
        End If
        If Not IsNothing(PriceChartUpdateList) Then
            PriceChartUpdateList.Clear()
            PriceChartUpdateList = Nothing
        End If

        MasterWatch.Stop()
        HeartBeatUDP.Close()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
	End Sub

	'--------------------------------------------------------------------------
	' サービス制御スレッド、及びワーカースレッドの停止要求
	'--------------------------------------------------------------------------
	Public Sub StopService()
        blnServiceStopFlag = True
    End Sub

	'--------------------------------------------------------------------------
	' Slave->Master移行イベント
	'--------------------------------------------------------------------------
	Public Sub OnMasterMode()
        blnMasterMode = True

		Logging("Master Mode Start.", EventLogEntryType.Information)
	End Sub

	'--------------------------------------------------------------------------
	' Master->Slave移行イベント
	'--------------------------------------------------------------------------
	Public Sub OnSlaveMode()
        blnMasterMode = False

		Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' ハートビート送受信による、生存確認とモードの切替(Master/Slave)
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        bMasterRecv = False
        bSlaveRecv = False
        iHeartBeatPriority = 9
        If HeartBeatUDP.Available() > 0 Then
            Dim sDataHB As String
            Dim DataHB() As Byte

            RemoteEP = Nothing
            Try
                DataHB = Nothing
                While HeartBeatUDP.Available() > 0
                    DataHB = HeartBeatUDP.Receive(RemoteEP)
                End While
                sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                Do
                    Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                    If NextIndex = -1 Then Exit Do
                    If sDataHB.Length - NextIndex < 3 Then Exit Do
                    sDataHB = sDataHB.Substring(NextIndex)
                Loop While True
                If My.Settings.HeartBeatLog Then SystemLog.Information(sDataHB)
                If sDataHB.Length >= 3 Then
                    sHeartBeatMode = sDataHB.Substring(1, 1)
                    iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                    If sHeartBeatMode.Equals("M") = True Then
                        bMasterRecv = True
                        MasterWatch.Reset()
                        MasterWatch.Start()
                    End If
                    If sHeartBeatMode.Equals("S") = True Then
                        bSlaveRecv = True
                    End If
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
            End Try
        End If

        If blnMasterMode = True Then
            If bMasterRecv = True Then
                ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                If iHeartBeatPriority < My.Settings.MasterPriority Then
                    OnSlaveMode()
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        Else
            If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                OnMasterMode()
                MasterWatch.Reset()
                MasterWatch.Start()
            ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                If SystemLog.GetDBErrorCount() > 0 Then
                    If My.Settings.HeartBeatLog Then SystemLog.Information("DB Error Now.")
                Else
                    OnMasterMode()
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        End If

        Try
            If blnMasterMode Then
                HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            Else
                HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            End If
        Catch ex As Exception
            If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
        End Try

        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' ログ出力
    '--------------------------------------------------------------------------
	Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
		Dim eLog As EventLog

		Try
			Debug.Print(sMessage)
			eLog = New EventLog()
			eLog.Source = strServiceName
			eLog.WriteEntry(sMessage, entryType)
			eLog = Nothing
		Catch ex As Exception
			Debug.Print(ex.Message)
		End Try
	End Sub

    Private Sub ProductPriceChartDataMaintenance(ByRef ProductPriceChartList As List(Of clsProductPriceChartData))
        Dim ProductIndex As Integer
        Dim ProductMax As Integer
        Dim ProductSubIndex As Integer
        Dim ProductSubMax As Integer

        ' 検索対象外データ削除
        ProductIndex = 0
        ProductMax = ProductPriceChartList.Count
        Do Until ProductIndex >= ProductMax
            If Not ProductPriceChartList.Item(ProductIndex).DBSearchFlg Then
                ProductPriceChartList.Item(ProductIndex).ProductSubPriceChartList.Clear()
                ProductPriceChartList.Item(ProductIndex).ProductSubPriceChartList = Nothing
                ProductPriceChartList.RemoveAt(ProductIndex)
                ProductMax = ProductPriceChartList.Count
            Else
                ProductPriceChartList.Item(ProductIndex).DBSearchFlg = False
                ProductSubIndex = 0
                ProductSubMax = ProductPriceChartList.Item(ProductIndex).ProductSubPriceChartList.Count
                Do Until ProductSubIndex >= ProductSubMax
                    'プライスチャートデータ更新フラグクリア
                    ProductPriceChartList.Item(ProductIndex).ProductSubPriceChartList.Item(ProductSubIndex).PriceChartData.UpdFlg = DBUpdateFlg.NoUpdate
                    ProductSubIndex += 1
                Loop
                ProductIndex += 1
            End If
        Loop
    End Sub

    ''' <summary>
    ''' 通信時間、DB読み込み時間、DB更新時間をログ出力
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub outputMinuteLog(force As Boolean)
        If My.Settings.ProcTimeInfo = 0 Then
            Exit Sub
        End If
        Dim NowTime As DateTime = Now
        Dim NowMinute As Integer = Math.Floor((NowTime.Hour * 60 + NowTime.Minute) / My.Settings.ProcTimeInfo)
        If force OrElse NowMinute <> PreTime Then
            Dim readCount1 As Integer
            Dim readAvgTime1 As Integer
            Dim readMaxTime1 As Integer
            Dim readDisList1 As List(Of KeyValuePair(Of Integer, Integer)) = Nothing
            Dim readCount2 As Integer
            Dim readAvgTime2 As Integer
            Dim readMaxTime2 As Integer
            Dim readDisList2 As List(Of KeyValuePair(Of Integer, Integer)) = Nothing
            Dim readCount3 As Integer
            Dim readAvgTime3 As Integer
            Dim readMaxTime3 As Integer
            Dim readDisList3 As List(Of KeyValuePair(Of Integer, Integer)) = Nothing
            Dim updCount As Integer
            Dim updAvgTime As Integer
            Dim updMaxTime As Integer
            Dim updDisList As List(Of KeyValuePair(Of Integer, Integer)) = Nothing
            '処理時間情報の取得
            ProcTimeInfo.GetProcTimeInfo(ProcTimeInfo.DataType.DB_READ_PRODUCT_PRODUCTSUB, readCount1, readAvgTime1, readMaxTime1, readDisList1)
            ProcTimeInfo.GetProcTimeInfo(ProcTimeInfo.DataType.DB_READ_LAST_PRICECHARTHIST, readCount2, readAvgTime2, readMaxTime2, readDisList2)
            ProcTimeInfo.GetProcTimeInfo(ProcTimeInfo.DataType.DB_READ_RATEHIST, readCount3, readAvgTime3, readMaxTime3, readDisList3)
            ProcTimeInfo.GetProcTimeInfo(ProcTimeInfo.DataType.DB_UPDATE, updCount, updAvgTime, updMaxTime, updDisList)
            'ログを出力
            EventLog.WriteEntry(strServiceName,
                                String.Format("Time Info" & vbCrLf &
                                " [readDBTime1] CNT : {0}  AVG : {1}ms  MAX : {2}ms  Distribution : {3}" & vbCrLf &
                                " [readDBTime2] CNT : {4}  AVG : {5}ms  MAX : {6}ms  Distribution : {7}" & vbCrLf &
                                " [readDBTime3] CNT : {8}  AVG : {9}ms  MAX : {10}ms  Distribution : {11}" & vbCrLf &
                                " [updDBTime]   CNT : {12}  AVG : {13}ms  MAX : {14}ms  Distribution : {15}",
                                readCount1, readAvgTime1, readMaxTime1, GetDistributionText(readDisList1),
                                readCount2, readAvgTime2, readMaxTime2, GetDistributionText(readDisList2),
                                readCount3, readAvgTime3, readMaxTime3, GetDistributionText(readDisList3),
                                updCount, updAvgTime, updMaxTime, GetDistributionText(updDisList)))
            '初期化
            PreTime = NowMinute
            ProcTimeInfo.Initialization()

        End If
    End Sub

    ''' <summary>
    ''' 処理時間分布(秒単位)テキスト取得
    ''' </summary>
    ''' <param name="disList">処理時間分布(秒単位)</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDistributionText(disList As List(Of KeyValuePair(Of Integer, Integer))) As String
        Dim sb As New StringBuilder()
        Dim delimiter As String = ""
        For Each keyvalue As KeyValuePair(Of Integer, Integer) In disList
            sb.Append(delimiter)
            sb.AppendFormat("{0}s({1})", keyvalue.Key, keyvalue.Value)
            delimiter = " "
        Next
        Return sb.ToString()
    End Function
End Class
