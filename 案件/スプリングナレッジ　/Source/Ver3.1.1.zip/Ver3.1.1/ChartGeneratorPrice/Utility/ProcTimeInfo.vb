﻿Public Class ProcTimeInfo

    ''' <summary>
    ''' データ種別
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum DataType
        ''' <summary>
        ''' DBデータ取得時間
        ''' </summary>
        ''' <remarks></remarks>
        DB_READ_PRODUCT_PRODUCTSUB
        ''' <summary>
        ''' DBデータ取得時間
        ''' </summary>
        ''' <remarks></remarks>
        DB_READ_LAST_PRICECHARTHIST
        ''' <summary>
        ''' DBデータ取得時間
        ''' </summary>
        ''' <remarks></remarks>
        DB_READ_RATEHIST
        ''' <summary>
        ''' DB更新時間
        ''' </summary>
        ''' <remarks></remarks>
        DB_UPDATE
    End Enum

    '処理回数カウンタ
    Private Shared CountDic As New Dictionary(Of DataType, Integer)
    '合計処理時間
    Private Shared TotalTimeDic As New Dictionary(Of DataType, Long)
    '処理時間最大値
    Private Shared MaxTimeDic As New Dictionary(Of DataType, Integer)
    '処理時間分布(秒単位)
    Private Shared DisListDic As New Dictionary(Of DataType, Dictionary(Of Integer, Integer))

    ''' <summary>
    ''' 値の初期化
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub Initialization()
        CountDic.Clear()
        TotalTimeDic.Clear()
        MaxTimeDic.Clear()
        DisListDic.Clear()

        '全データ種別について初期値を設定する
        For Each dt In [Enum].GetValues(GetType(DataType))
            CountDic.Add(dt, 0)
            TotalTimeDic.Add(dt, 0)
            MaxTimeDic.Add(dt, 0)
            DisListDic.Add(dt, New Dictionary(Of Integer, Integer))
        Next
    End Sub

    ''' <summary>
    ''' 処理時間追加
    ''' </summary>
    ''' <param name="dt">データ種別</param>
    ''' <param name="procTime">処理時間</param>
    ''' <remarks></remarks>
    Public Shared Sub AddTimeData(dt As DataType, procTime As Integer)
        '処理回数
        CountDic(dt) += 1
        '合計処理時間
        TotalTimeDic(dt) += procTime
        '最大処理時間の判定と更新
        If procTime > MaxTimeDic(dt) Then
            MaxTimeDic(dt) = procTime
        End If
        '処理時間分布(秒単位)
        Dim procTimeSec As Integer = Math.Floor(procTime / 1000)
        If Not DisListDic(dt).ContainsKey(procTimeSec) Then
            DisListDic(dt)(procTimeSec) = 1
        Else
            DisListDic(dt)(procTimeSec) += 1
        End If
    End Sub

    ''' <summary>
    ''' 処理時間情報取得
    ''' </summary>
    ''' <param name="dt">データ種別</param>
    ''' <param name="Count">処理回数</param>
    ''' <param name="AvgTime">平均処理時間</param>
    ''' <param name="MaxTime">最大処理時間</param>
    ''' <param name="DisList">処理時間分布(秒単位)</param>
    ''' <remarks></remarks>
    Public Shared Sub GetProcTimeInfo(dt As DataType, ByRef Count As Integer, ByRef AvgTime As Integer, ByRef MaxTime As Integer, ByRef DisList As List(Of KeyValuePair(Of Integer, Integer)))
        '処理回数
        Count = CountDic(dt)
        '平均処理時間
        If Count = 0 Then
            AvgTime = 0
        Else
            AvgTime = TotalTimeDic(dt) / CountDic(dt)
        End If
        '最大処理時間
        MaxTime = MaxTimeDic(dt)
        '処理時間分布(秒単位)
        DisList = New List(Of KeyValuePair(Of Integer, Integer))
        Dim maxProcTimeSec As Integer = Math.Floor(MaxTime / 1000)
        For procTimeSec As Integer = 0 To maxProcTimeSec
            If DisListDic(dt).ContainsKey(procTimeSec) Then
                DisList.Add(New KeyValuePair(Of Integer, Integer)(procTimeSec, DisListDic(dt)(procTimeSec)))
            End If
        Next
    End Sub

End Class
