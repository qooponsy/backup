'*******************************************************************************
'
'
'
'
'
'*******************************************************************************

Imports System.Text
Imports System.Security.Cryptography

''' <summary>
''' ���[�e�B���e�B
''' </summary>
''' <remarks></remarks>
Public Class clsUtil
    Public Shared Function GetRateDPFormat(DecimalPlaces As Integer) As String
        If DecimalPlaces <= 0 Then
            Return "######0.########"
        End If
        Select Case DecimalPlaces
            Case 0 : Return "######0.########"
            Case 1 : Return "######0.0#######"
            Case 2 : Return "######0.00######"
            Case 3 : Return "######0.000#####"
            Case 4 : Return "######0.0000####"
            Case 5 : Return "######0.00000###"
            Case 6 : Return "######0.000000##"
            Case 7 : Return "######0.0000000#"
        End Select
        Return "######0.00000000"
    End Function
End Class
