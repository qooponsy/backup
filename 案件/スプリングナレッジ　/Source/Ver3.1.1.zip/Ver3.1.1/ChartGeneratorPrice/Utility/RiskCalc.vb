﻿Public Class RiskCalc

#Region "正規分布表 0-8 step 0.1"
    Shared NormSDistArray As Double() =
    {
        0.5,
        0.539827837277029,
        0.579259709439103,
        0.617911422188953,
        0.655421741610324,
        0.691462461274013,
        0.725746882249926,
        0.758036347776927,
        0.788144601416603,
        0.81593987465324,
        0.841344746068543,
        0.864333939053617,
        0.884930329778292,
        0.90319951541439,
        0.919243340766229,
        0.933192798731142,
        0.945200708300442,
        0.955434537241457,
        0.964069680887074,
        0.971283440183998,
        0.977249868051821,
        0.982135579437183,
        0.986096552486501,
        0.989275889978324,
        0.991802464075404,
        0.993790334674224,
        0.995338811976281,
        0.996533026196959,
        0.997444869669572,
        0.998134186699616,
        0.99865010196837,
        0.999032396786782,
        0.999312862062084,
        0.999516575857616,
        0.999663070734323,
        0.999767370920964,
        0.999840891409842,
        0.999892200266523,
        0.999927651956075,
        0.999951903655982,
        0.999968328758167,
        0.999979342493088,
        0.999986654250984,
        0.999991460094529,
        0.999994587456092,
        0.999996602326875,
        0.999997887545298,
        0.999998699192546,
        0.999999206671848,
        0.999999520816723,
        0.999999713348428,
        0.999999830173259,
        0.999999900355737,
        0.99999994209866,
        0.999999966679551,
        0.999999981010438,
        0.99999998928241,
        0.999999994009629,
        0.999999996684254,
        0.999999998182492,
        0.999999999013412,
        0.999999999469658,
        0.999999999717684,
        0.999999999851177,
        0.999999999922311,
        0.99999999995984,
        0.999999999979442,
        0.999999999989579,
        0.999999999994769,
        0.9999999999974,
        0.99999999999872,
        0.999999999999376,
        0.999999999999699,
        0.999999999999856,
        0.999999999999932,
        0.999999999999968,
        0.999999999999985,
        0.999999999999993,
        0.999999999999997,
        0.999999999999999,
        0.999999999999999
    }
#End Region

    '標準正規分布の確率密度関数
    Private Shared r2PI As Double = Math.Sqrt(2 * Math.PI)
    Public Shared Function fx(x As Double) As Double
        Return Math.Exp(-x * x / 2) / r2PI
    End Function

    '[NORMSDIST()]  標準正規分布の累積分布関数
    Public Shared Function NORMSDIST(ByVal x As Double) As Double
        Const N As Integer = 4
        Dim d As Double = Math.Abs(x)
        Dim r As Double
        If d > 8 Then
            r = 1
        Else
            Dim ni As Integer = Math.Floor(d * 10)
            If ni >= NormSDistArray.Count Then
                ni = NormSDistArray.Count - 1
            End If
            Dim c As Double = ni / 10
            Dim h As Double = (d - c) / N / 4
            Dim s As Double = 0
            For i As Integer = 0 To N - 1
                Dim x0 As Double = c + 4 * i * h
                Dim x1 As Double = x0 + h
                Dim x2 As Double = x1 + h
                Dim x3 As Double = x2 + h
                Dim x4 As Double = x3 + h
                s += 7 * fx(x0) + 32 * fx(x1) + 12 * fx(x2) + 32 * fx(x3) + 7 * fx(x4)
            Next
            s *= 2 * h / 45
            r = NormSDistArray(ni) + s
        End If
        If x < 0 Then
            r = 1 - r
        End If
        If r < 0 Then r = 0
        If r > 1 Then r = 1

        'Debug.Print(x & vbTab & r)
        Return r
    End Function

    '[Premium()]    Premiumの計算
    Public Shared Function Premium(
            Amount As Double,
            PayoutRate As Double,
            OpExeType As String,
            S As Double,
            k As Double,
            r As Double,
            rf As Double,
            sigma As Double,
            StdDt As DateTime,
            ExpireDt As DateTime
        ) As Double

        Dim retValue As Double = 0

        Dim t1 As DateTime = StdDt
        Dim t2 As DateTime = ExpireDt
        If t1 >= t2 Then
            If S = k Then
                retValue = Amount
            Else
                If (OpExeType = "01" And S > k) Or (OpExeType = "02" And S < k) Then
                    retValue = Amount * (1 + PayoutRate)
                Else
                    retValue = 0
                End If
            End If
        Else
            Dim t As Double = t2.Subtract(t1).TotalDays / 250
            Dim d2 As Double = (Math.Log(S / k) + (-rf - sigma * sigma / 2) * t) / (sigma * Math.Sqrt(t))

            Dim premiumRate As Double = 0
            Select Case OpExeType
                Case "01"   'CALL (UP)
                    premiumRate = Math.Exp(-r * t) * NORMSDIST(d2)
                Case "02"   'PUT (DOWN)
                    premiumRate = Math.Exp(-r * t) * NORMSDIST(-d2)
            End Select

            retValue = Amount * (1 + PayoutRate) * premiumRate
        End If

        Return retValue
    End Function

    Public Shared Function AbandPayout(
            Amount As Double,
            AbandMargine As Double,
            PayoutRate As Double,
            OpExeType As String,
            S As Double,
            k As Double,
            r As Double,
            rf As Double,
            sigma As Double,
            StdDt As DateTime,
            ExpireDt As DateTime,
            DecimalPlaces As Integer
        ) As Decimal

        Dim RawValue = (1 - AbandMargine) * Premium(Amount, PayoutRate, OpExeType, S, k, r, rf, sigma, StdDt, ExpireDt)
        Dim RoundValue As Decimal = Math.Floor(RawValue * Math.Pow(10, DecimalPlaces)) * Math.Pow(10, -DecimalPlaces)
        Return Math.Round(RoundValue, DecimalPlaces, MidpointRounding.AwayFromZero)
    End Function

End Class
