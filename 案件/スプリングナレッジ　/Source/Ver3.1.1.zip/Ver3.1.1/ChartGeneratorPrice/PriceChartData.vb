﻿Public Enum DBUpdateFlg
    NoData = 0
    NoUpdate = 1
    Update = 2
    Insert = 3
End Enum

Public Class PriceType
    Public Const TypeCall As String = "01"
    Public Const TypePut As String = "02"
End Class

'通貨ペア計算パラメータデータ
Public Class clsCurrencyPairCalcParamData
    Public ComCode As String
    Public DecimalPlaces As Integer
    Public InterestRate As Decimal
    Public SwapRate As Decimal
    Public Volatility As Decimal
    Public VolatilityRatio As Decimal
End Class

'プライスチャートデータ
Public Class clsPriceChartData
    Public ChkLastFlg As Boolean
    Public UpdFlg As DBUpdateFlg
    Public ProductCode As String
    Public ProductSubCode As String
    Public PriceChartSeq As String
    Public ComCode As String
    Public ChartType As Integer
    Public RateSeq As String
    Public PriceChartTime As DateTime
    Public OpenAskPriceCall As Decimal
    Public HighAskPriceCall As Decimal
    Public LowAskPriceCall As Decimal
    Public CloseAskPriceCall As Decimal
    Public OpenAskPricePut As Decimal
    Public HighAskPricePut As Decimal
    Public LowAskPricePut As Decimal
    Public CloseAskPricePut As Decimal
    Public OpenBidPriceCall As Decimal
    Public HighBidPriceCall As Decimal
    Public LowBidPriceCall As Decimal
    Public CloseBidPriceCall As Decimal
    Public OpenBidPricePut As Decimal
    Public HighBidPricePut As Decimal
    Public LowBidPricePut As Decimal
    Public CloseBidPricePut As Decimal
    Public CloseTime As DateTime
End Class

'銘柄データ
Public Class clsProductPriceChartData
    Public Sub New()
        ProductSubPriceChartList = New List(Of clsProductSubPriceChartData)(15)
        DBSearchFlg = False
    End Sub

    Public DBSearchFlg As Boolean
    Public ProductCode As String
    Public ComCode As String
    Public StartTime As DateTime
    Public ExercTime As DateTime
    Public TradeLimitTime As DateTime
    Public ExercPriceTimespan As Integer
    Public CreateStartTime As DateTime
    Public CreateEndTime As DateTime
    Public ProductSubPriceChartList As List(Of clsProductSubPriceChartData)
End Class

'銘柄詳細データ
Public Class clsProductSubPriceChartData
    Public Sub New()
        PriceChartData = New clsPriceChartData
        PriceChartData.PriceChartSeq = "00000000000000000"
        PriceChartData.RateSeq = "00000000000000000"
        PriceChartData.ChkLastFlg = False
        PriceChartData.UpdFlg = DBUpdateFlg.NoUpdate
    End Sub

    Public Enabled As String
    Public ProductSubCode As String
    Public ProductSubStatus As Decimal
    Public ExercPrice As Decimal
    Public VolatilityRatio1Call As Decimal
    Public VolatilityRatio1Put As Decimal
    Public VolatilityRatio2Call As Decimal
    Public VolatilityRatio2Put As Decimal
    Public VolatilitySmileACall As Decimal
    Public VolatilitySmileAPut As Decimal
    Public VolatilitySmileBCall As Decimal
    Public VolatilitySmileBPut As Decimal
    Public VolatilitySpread As Decimal
    Public VolatilitySpreadITMCall As Decimal
    Public VolatilitySpreadITMPut As Decimal
    Public VolatilitySpreadOTMCall As Decimal
    Public VolatilitySpreadOTMPut As Decimal
    Public AskFeePriceCall As Decimal
    Public AskFeePricePut As Decimal
    Public AskBidSpreadMinCall As Decimal
    Public AskBidSpreadMinPut As Decimal
    Public BidFeeRateCall As Decimal
    Public BidFeeRatePut As Decimal
    Public AskPriceMaxCall As Decimal
    Public AskPriceMaxPut As Decimal
    Public AskPriceMinCall As Decimal
    Public AskPriceMinPut As Decimal
    Public BidPriceMaxCall As Decimal
    Public BidPriceMaxPut As Decimal
    Public BidPriceMinCall As Decimal
    Public BidPriceMinPut As Decimal
    Public PriceChartData As clsPriceChartData
End Class
