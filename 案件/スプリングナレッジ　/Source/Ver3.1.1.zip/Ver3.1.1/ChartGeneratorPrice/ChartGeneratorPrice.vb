﻿Imports System
Imports System.Threading
'------------------------------------------------------------------------------
' ChartGeneratorPrice サービス
'------------------------------------------------------------------------------
Public Class ChartGeneratorPrice
    Private service As clsService
	Private serviceThread As Thread

	'--------------------------------------------------------------------------
	' サービス開始
	'--------------------------------------------------------------------------
	Protected Overrides Sub OnStart(ByVal args() As String)
		service = New clsService()
		serviceThread = New Thread(AddressOf service.ServiceThread)
        service.InitializeService()
		serviceThread.Start()
	End Sub

	'--------------------------------------------------------------------------
	' サービス停止
	'--------------------------------------------------------------------------
	Protected Overrides Sub OnStop()
		If Not IsNothing(serviceThread) Then
			If serviceThread.IsAlive Then
				service.StopService()
				serviceThread.Join()
			End If
			serviceThread = Nothing
			service = Nothing
		End If
	End Sub

End Class
