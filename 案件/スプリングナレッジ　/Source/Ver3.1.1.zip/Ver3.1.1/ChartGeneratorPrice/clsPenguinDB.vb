﻿Imports System.IO
Imports System.Text
Imports System.Data.SqlClient

Public Class clsPenguinDB
	Private ConnDB As SqlConnection
	Private strError As String
	Private blnError As Boolean

    Private Const SQL_SELECT_ALL_M_CURRENCYPAIR_CALCPARAM As String = "select " & _
                                                                  "CUP.[ComCode], " & _
                                                                  "CUP.[DecimalPlaces], " & _
                                                                  "CAP.[InterestRate], " & _
                                                                  "CAP.[SwapRate], " & _
                                                                  "CAP.[Volatility], " & _
                                                                  "CAP.[VolatilityAdjust] " & _
                                                                  "from " & _
                                                                  "[M_CurrencyPair] CUP with ( nolock ) inner join [M_CalcParam] CAP with ( nolock ) on CUP.[ComCode]=CAP.[ComCode]"

    Private ReadOnly SQL_SELECT_RATEHIST As String = "declare @StartTime datetime2" & vbCrLf & _
                                                 "select @StartTime=DATEADD(hour, -2, SYSUTCDATETIME());" & vbCrLf & _
                                                 "select @StartTime=DATEADD(second, -DATEPART(second, @StartTime), @StartTime);" & vbCrLf & _
                                                 "select @StartTime=DATEADD(millisecond, -DATEPART(millisecond, @StartTime), @StartTime);" & vbCrLf & _
                                                 "select @StartTime=DATEADD(microsecond, -DATEPART(microsecond, @StartTime), @StartTime);" & vbCrLf & _
                                                 "select @StartTime=DATEADD(nanosecond, -DATEPART(nanosecond, @StartTime), @StartTime);" & vbCrLf & _
                                                 "select top 500 [ComCode], [RateSeq], [RateTime], [Rate] " & _
                                                 "from T_RateHist with ( nolock ) " & _
                                                 "where " & _
                                                 "[Enabled]='1' and " & _
                                                 "[RateTime]>=@StartTime and " & _
                                                 "[RateSeq]>@SertchRateSeq " & _
                                                 "order by [RateSeq] asc"

    Private ReadOnly SQL_SELECT_RATEHIST_GETSERTCHRATESEQ As String = "select top 1 [RateSeq] " & _
                                                                      "from T_RateHist with ( nolock ) " & _
                                                                      "where " & _
                                                                      "[Enabled]='1' and " & _
                                                                      "[RateTime]<=@CreateStartTime " & _
                                                                      "order by [RateSeq] desc"

    Private Const SQL_SELECT_M_PRODUCT_PRODUCTSUB As String = "declare @SysUTCDateTime datetime2=SYSUTCDATETIME()" & vbCrLf & _
                                                              "select " & _
                                                              "MN.[ProductCode], " & _
                                                              "MN.[ComCode], " & _
                                                              "MN.[StartTime], " & _
                                                              "MN.[ExercTime], " & _
                                                              "MN.[TradeLimitTime], " & _
                                                              "MN.[ExercPriceTimeSpan], " & _
                                                              "SB.[ProductSubCode], " & _
                                                              "SB.[ExercPrice], " & _
                                                              "SB.[ProductSubStatus], " & _
                                                              "SB.[VolatilityRatio1Call], " & _
                                                              "SB.[VolatilityRatio1Put], " & _
                                                              "SB.[VolatilityRatio2Call], " & _
                                                              "SB.[VolatilityRatio2Put], " & _
                                                              "SB.[VolatilitySmileACall], " & _
                                                              "SB.[VolatilitySmileAPut], " & _
                                                              "SB.[VolatilitySmileBCall], " & _
                                                              "SB.[VolatilitySmileBPut], " & _
                                                              "SB.[VolatilitySpread], " & _
                                                              "SB.[VolatilitySpreadITMCall], " & _
                                                              "SB.[VolatilitySpreadITMPut], " & _
                                                              "SB.[VolatilitySpreadOTMCall], " & _
                                                              "SB.[VolatilitySpreadOTMPut], " & _
                                                              "SB.[AskFeePriceCall], " & _
                                                              "SB.[AskFeePricePut], " & _
                                                              "SB.[AskBidSpreadMinCall], " & _
                                                              "SB.[AskBidSpreadMinPut], " & _
                                                              "SB.[BidFeeRateCall], " & _
                                                              "SB.[BidFeeRatePut], " & _
                                                              "SB.[AskPriceMaxCall], " & _
                                                              "SB.[AskPriceMaxPut], " & _
                                                              "SB.[AskPriceMinCall], " & _
                                                              "SB.[AskPriceMinPut], " & _
                                                              "SB.[BidPriceMaxCall], " & _
                                                              "SB.[BidPriceMaxPut], " & _
                                                              "SB.[BidPriceMinCall], " & _
                                                              "SB.[BidPriceMinPut] " & _
                                                              "from " & _
                                                              "[M_Product] MN with ( nolock ) inner join [M_ProductSub] SB with ( nolock ) on MN.[ProductCode]=SB.[ProductCode] " & _
                                                              "where " & _
                                                              "MN.[OpType]='02' and " & _
                                                              "@SysUTCDateTime>=DATEADD(second, -MN.[ExercPriceTimespan], MN.[StartTime]) and " & _
                                                              "@SysUTCDateTime<=MN.[ExercTime]"

    Private Const SQL_SELECT_T_PRICECHARTHIST_LAST As String = "select top 1 * " & _
                                                                 "from [T_PriceChartHist] with ( nolock ) " & _
                                                                 "where " & _
                                                                 "[Enabled]='1' and " & _
                                                                 "[ProductSubCode]=@ProductSubCode and " & _
                                                                 "[ChartType]=@ChartType " & _
                                                                 "order by " & _
                                                                 "[PriceChartTime] desc"

    Private Const SQL_INSERT_T_PRICECHARTHIST As String = "insert into [T_PriceChartHist] " & _
                                                            "values (" & _
                                                            "SYSUTCDATETIME(), @InsUser, SYSUTCDATETIME(), @InsUser, @PriceChartSeq, " & _
                                                            "'1', @ComCode, @ProductCode, @ProductSubCode, " & _
                                                            "@ChartType, @RateSeq, @PriceChartTime, " & _
                                                            "@OpenAskPriceCall, @HighAskPriceCall, @LowAskPriceCall, @CloseAskPriceCall, " & _
                                                            "@OpenAskPricePut, @HighAskPricePut, @LowAskPricePut, @CloseAskPricePut, " & _
                                                            "@OpenBidPriceCall, @HighBidPriceCall, @LowBidPriceCall, @CloseBidPriceCall, " & _
                                                            "@OpenBidPricePut, @HighBidPricePut, @LowBidPricePut, @CloseBidPricePut, " & _
                                                            "@CloseTime " & _
                                                            ")"

    Private Const SQL_UPDATE_T_PRICECHARTHIST As String = "update [T_PriceChartHist] " & _
                                                            "set " & _
                                                            "[UpdTime]=SYSUTCDATETIME(), " & _
                                                            "[UpdUser]=@InsUser, " & _
                                                            "[RateSeq]=@RateSeq, " & _
                                                            "[HighAskPriceCall]=@HighAskPriceCall, " & _
                                                            "[LowAskPriceCall]=@LowAskPriceCall, " & _
                                                            "[CloseAskPriceCall]=@CloseAskPriceCall, " & _
                                                            "[HighAskPricePut]=@HighAskPricePut, " & _
                                                            "[LowAskPricePut]=@LowAskPricePut, " & _
                                                            "[CloseAskPricePut]=@CloseAskPricePut, " & _
                                                            "[HighBidPriceCall]=@HighBidPriceCall, " & _
                                                            "[LowBidPriceCall]=@LowBidPriceCall, " & _
                                                            "[CloseBidPriceCall]=@CloseBidPriceCall, " & _
                                                            "[HighBidPricePut]=@HighBidPricePut, " & _
                                                            "[LowBidPricePut]=@LowBidPricePut, " & _
                                                            "[CloseBidPricePut]=@CloseBidPricePut, " & _
                                                            "[CloseTime]=@CloseTime " & _
                                                            "where " & _
                                                            "[PriceChartSeq]=@PriceChartSeq"

    Private Const SQL_SELECT_T_PRICE As String = "select " & _
                                                 "* " & _
                                                 "from " & _
                                                 "[T_Price] " & _
                                                 "where " & _
                                                 "[ProductCode]=@ProductCode and " & _
                                                 "[ProductSubCode]=@ProductSubCode"

    Private Const SQL_UPDATE_T_PRICE As String = "update " & _
                                                 "[T_Price] " & _
                                                 "set " & _
                                                 "[UpdTime]=SYSUTCDATETIME(), " & _
                                                 "[UpdUser]=@InsUser, " & _
                                                 "[ExercTime]=@ExercTime, " & _
                                                 "[ExercPrice]=@ExercPrice, " & _
                                                 "[RateSeq]=@RateSeq, " & _
                                                 "[Rate]=@Rate, " & _
                                                 "[RateTime]=@RateTime, " & _
                                                 "[CalcTime]=@CalcTime, " & _
                                                 "[AskCall]=@AskCall, " & _
                                                 "[BidCall]=@BidCall, " & _
                                                 "[AskPut]=@AskPut, " & _
                                                 "[BidPut]=@BidPut, " & _
                                                 "[VolatilityCall]=@VolatilityCall, " & _
                                                 "[VolatilityPut]=@VolatilityPut " & _
                                                 "where " & _
                                                 "[ProductCode]=@ProductCode and " & _
                                                 "[ProductSubCode]=@ProductSubCode"

    Private Const SQL_INSERT_T_PRICE As String = "insert into [T_Price]" & _
                                                 "values (" & _
                                                 "SYSUTCDATETIME(), @InsUser, SYSUTCDATETIME(), @InsUser, @ProductCode, " & _
                                                 "@ProductSubCode, @ComCode, @OpType, @ExercTime, @ExercPrice, " & _
                                                 "@RateSeq, @Rate, @RateTime, @CalcTime, @AskCall, " & _
                                                 "@BidCall, @AskPut, @BidPut, @VolatilityCall, @VolatilityPut" & _
                                                 ")"

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Class SeqCounterCode
        Public Const Rate As String = "01"
        Public Const Chart As String = "02"
        Public Const ProductBase As String = "03"
        Public Const Product As String = "04"
        Public Const Trade As String = "05"
        Public Const Cash As String = "06"
        Public Const Task As String = "07"
        Public Const RateChart As String = "09"
        Public Const ProductSub As String = "11"
        Public Const PriceChart As String = "12"
    End Class

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Function GetSqlConnection(ByVal sConnectString As String) As Boolean
		Dim Result As Boolean

		strError = ""
		blnError = False
		Result = True
		Try
			ConnDB = New SqlConnection(sConnectString)
            ConnDB.Open()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)

            strError = "GetSqlConnection," & ex.Message
            ConnDB = Nothing
            Result = False
            blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Function IsError() As Boolean
		Return blnError
	End Function

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Function GetErrorMessage() As String
		Dim sErrMsg As String

		blnError = False
		sErrMsg = "DataBase Error:" & strError
		Return sErrMsg

	End Function

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Function EndSqlConnection() As Boolean
		Dim Result As Boolean

		Result = True
		Try
			ConnDB.Close()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "EndSqlConnection," & ex.Message
            Result = False
		End Try
		ConnDB = Nothing
		blnError = False

		Return Result
	End Function

    '--------------------------------------------------------------------------
    ' 検索レート通番取得
    '--------------------------------------------------------------------------
    Public Function GetSertchRateSeq(ByRef SertchRateSeq As String, ByVal ProductPriceChartList As List(Of clsProductPriceChartData)) As Boolean
        Dim ret As Boolean = True
        Dim LowCreateStartTime As DateTime = DateTime.MaxValue
        Dim hSertchRateSeq As String = SertchRateSeq

        If SertchRateSeq = "99999999999999999" Then
            hSertchRateSeq = SertchRateSeq
            For Each ProductPriceChartData As clsProductPriceChartData In ProductPriceChartList
                For Each ProductSubPriceChartData As clsProductSubPriceChartData In ProductPriceChartData.ProductSubPriceChartList
                    If ProductSubPriceChartData.PriceChartData.RateSeq <> "00000000000000000" AndAlso ProductSubPriceChartData.PriceChartData.RateSeq < hSertchRateSeq Then
                        hSertchRateSeq = ProductSubPriceChartData.PriceChartData.RateSeq
                    ElseIf ProductSubPriceChartData.PriceChartData.RateSeq = "00000000000000000" Then
                        If LowCreateStartTime > ProductPriceChartData.CreateStartTime Then
                            LowCreateStartTime = ProductPriceChartData.CreateStartTime
                        End If
                    End If
                Next
            Next
            If LowCreateStartTime < DateTime.MaxValue Then
                Try
                    Using CmdDB As New SqlCommand(SQL_SELECT_RATEHIST_GETSERTCHRATESEQ, ConnDB)
                        CmdDB.CommandTimeout = My.Settings.CommandTimeout
                        CmdDB.CommandType = CommandType.Text
                        CmdDB.Parameters.Add("@CreateStartTime", SqlDbType.DateTime2).Value = LowCreateStartTime

                        Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                            If Reader.Read Then
                                If hSertchRateSeq > Reader("RateSeq") Then
                                    SertchRateSeq = Reader("RateSeq")
                                Else
                                    SertchRateSeq = hSertchRateSeq
                                End If
                            Else
                                If hSertchRateSeq = "99999999999999999" Then
                                    SertchRateSeq = "00000000000000000"
                                Else
                                    SertchRateSeq = hSertchRateSeq
                                End If
                            End If
                        End Using
                    End Using
                    SystemLog.DBSuccess()
                Catch ex As Exception
                    SystemLog.DBError(ex)
                    strError = "GetSertchRateSeq," & ex.Message
                    blnError = True
                    ret = False
                End Try
            Else
                If hSertchRateSeq = "99999999999999999" Then
                    SertchRateSeq = "00000000000000000"
                Else
                    SertchRateSeq = hSertchRateSeq
                End If
            End If
        End If

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 通貨ペア取得処理
    '--------------------------------------------------------------------------
    Public Function GetCurrencyPairCalcParamData(ByRef CurrencyPairCalcParamList As List(Of clsCurrencyPairCalcParamData)) As Boolean
        Dim ret As Boolean = True

        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_ALL_M_CURRENCYPAIR_CALCPARAM, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    If Reader.HasRows Then
                        While Reader.Read
                            Dim CurrencyPairCalcParamData As New clsCurrencyPairCalcParamData

                            CurrencyPairCalcParamData.ComCode = Reader("ComCode")
                            CurrencyPairCalcParamData.DecimalPlaces = Reader("DecimalPlaces")
                            CurrencyPairCalcParamData.InterestRate = Reader("InterestRate")
                            CurrencyPairCalcParamData.SwapRate = Reader("SwapRate")
                            CurrencyPairCalcParamData.Volatility = Reader("Volatility")
                            CurrencyPairCalcParamData.VolatilityRatio = reader("VolatilityAdjust")
                            CurrencyPairCalcParamList.Add(CurrencyPairCalcParamData)
                        End While
                    Else
                        ret = False
                    End If
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetCurrencyPairCalcParamData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 通貨ペアIndex取得
    '--------------------------------------------------------------------------
    Public Function GetCurrencyPairCalcParamListIndex(ByVal CurrencyPairCalcParamList As List(Of clsCurrencyPairCalcParamData), ByVal ComCode As String) As Integer
        Dim i As Integer

        For i = CurrencyPairCalcParamList.Count - 1 To 0 Step -1
            If CurrencyPairCalcParamList.Item(i).ComCode = ComCode Then
                Exit For
            End If
        Next

        Return i
    End Function

    '--------------------------------------------------------------------------
    ' 最終プライスチャートデータ情報設定
    '--------------------------------------------------------------------------
    Public Function SetLastPriceChartData(ByRef PriceChartData As clsPriceChartData) As Boolean
        Dim ret As Boolean = True

        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_T_PRICECHARTHIST_LAST, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = PriceChartData.ProductCode
                CmdDB.Parameters.Add("@ProductSubCode", SqlDbType.Char, 17).Value = PriceChartData.ProductSubCode
                CmdDB.Parameters.Add("@ChartType", SqlDbType.Int).Value = PriceChartData.ChartType
                CmdDB.Prepare()

                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    If Reader.Read Then
                        PriceChartData.PriceChartSeq = Reader("PriceChartSeq")
                        PriceChartData.PriceChartTime = Reader("PriceChartTime")
                        PriceChartData.RateSeq = Reader("RateSeq")
                        PriceChartData.OpenAskPriceCall = Reader("OpenAskPriceCall")
                        PriceChartData.HighAskPriceCall = Reader("HighAskPriceCall")
                        PriceChartData.LowAskPriceCall = Reader("LowAskPriceCall")
                        PriceChartData.CloseAskPriceCall = Reader("CloseAskPriceCall")
                        PriceChartData.OpenAskPricePut = Reader("OpenAskPricePut")
                        PriceChartData.HighAskPricePut = Reader("HighAskPricePut")
                        PriceChartData.LowAskPricePut = Reader("LowAskPricePut")
                        PriceChartData.CloseAskPricePut = Reader("CloseAskPricePut")
                        PriceChartData.OpenBidPriceCall = Reader("OpenBidPriceCall")
                        PriceChartData.HighBidPriceCall = Reader("HighBidPriceCall")
                        PriceChartData.LowBidPriceCall = Reader("LowBidPriceCall")
                        PriceChartData.CloseBidPriceCall = Reader("CloseBidPriceCall")
                        PriceChartData.OpenBidPricePut = Reader("OpenBidPricePut")
                        PriceChartData.HighBidPricePut = Reader("HighBidPricePut")
                        PriceChartData.LowBidPricePut = Reader("LowBidPricePut")
                        PriceChartData.CloseBidPricePut = Reader("CloseBidPricePut")
                        PriceChartData.CloseTime = Reader("CloseTime")
                    End If
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "SetLastPriceChartData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 最終プライスチャート情報設定(該当銘柄詳細すべて)
    '--------------------------------------------------------------------------
    Public Function SetLastPriceChartPriceAll(ByRef ProductPriceChartList As List(Of clsProductPriceChartData), ByRef SertchRateSeq As String) As Boolean
        Dim ret As Boolean = True

        For Each ProductPriceChartData As clsProductPriceChartData In ProductPriceChartList
            For Each ProductSubPriceChartData As clsProductSubPriceChartData In ProductPriceChartData.ProductSubPriceChartList

                If Not ProductSubPriceChartData.PriceChartData.ChkLastFlg Then
                    ret = SetLastPriceChartData(ProductSubPriceChartData.PriceChartData)
                    If Not ret Then
                        Return ret
                    End If
                    ProductSubPriceChartData.PriceChartData.ChkLastFlg = True
                End If
            Next
        Next

        ret = GetSertchRateSeq(SertchRateSeq, ProductPriceChartList)

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 銘柄詳細設定
    '--------------------------------------------------------------------------
    Public Sub SetProductSub(ByRef ProductSubPriceChartData As clsProductSubPriceChartData, ByVal Reader As SqlDataReader)
        ProductSubPriceChartData.ProductSubCode = Reader(6)
        ProductSubPriceChartData.ExercPrice = Reader(7)
        ProductSubPriceChartData.ProductSubStatus = Reader(8)
        ProductSubPriceChartData.VolatilityRatio1Call = Reader(9)
        ProductSubPriceChartData.VolatilityRatio1Put = Reader(10)
        ProductSubPriceChartData.VolatilityRatio2Call = Reader(11)
        ProductSubPriceChartData.VolatilityRatio2Put = Reader(12)
        ProductSubPriceChartData.VolatilitySmileACall = Reader(13)
        ProductSubPriceChartData.VolatilitySmileAPut = Reader(14)
        ProductSubPriceChartData.VolatilitySmileBCall = Reader(15)
        ProductSubPriceChartData.VolatilitySmileBPut = Reader(16)
        ProductSubPriceChartData.VolatilitySpread = Reader(17)
        ProductSubPriceChartData.VolatilitySpreadITMCall = Reader(18)
        ProductSubPriceChartData.VolatilitySpreadITMPut = Reader(19)
        ProductSubPriceChartData.VolatilitySpreadOTMCall = Reader(20)
        ProductSubPriceChartData.VolatilitySpreadOTMPut = Reader(21)
        ProductSubPriceChartData.AskFeePriceCall = Reader(22)
        ProductSubPriceChartData.AskFeePricePut = Reader(23)
        ProductSubPriceChartData.AskBidSpreadMinCall = Reader(24)
        ProductSubPriceChartData.AskBidSpreadMinPut = Reader(25)
        ProductSubPriceChartData.BidFeeRateCall = Reader(26)
        ProductSubPriceChartData.BidFeeRatePut = Reader(27)
        ProductSubPriceChartData.AskPriceMaxCall = Reader(28)
        ProductSubPriceChartData.AskPriceMaxPut = Reader(29)
        ProductSubPriceChartData.AskPriceMinCall = Reader(30)
        ProductSubPriceChartData.AskPriceMinPut = Reader(31)
        ProductSubPriceChartData.BidPriceMaxCall = Reader(32)
        ProductSubPriceChartData.BidPriceMaxPut = Reader(33)
        ProductSubPriceChartData.BidPriceMinCall = Reader(34)
        ProductSubPriceChartData.BidPriceMinPut = Reader(35)
    End Sub

    '--------------------------------------------------------------------------
    ' 銘柄詳細・プライスチャートデータ設定
    '--------------------------------------------------------------------------
    Public Sub SetProductSubPriceChartData(ByRef ProductSubPriceChartData As clsProductSubPriceChartData, ByVal Reader As SqlDataReader, ByVal ChartType As Integer)

        SetProductSub(ProductSubPriceChartData, Reader)

        ProductSubPriceChartData.PriceChartData.ProductCode = Reader(0)
        ProductSubPriceChartData.PriceChartData.ComCode = Reader(1)
        ProductSubPriceChartData.PriceChartData.ProductSubCode = Reader(6)
        ProductSubPriceChartData.PriceChartData.PriceChartTime = DateTime.MinValue
        ProductSubPriceChartData.PriceChartData.ChartType = ChartType
    End Sub

    '--------------------------------------------------------------------------
    ' 銘柄・銘柄詳細・プライスチャートデータ取得設定
    '--------------------------------------------------------------------------
    Public Function SetProductData(ByRef ProductPriceChartList As List(Of clsProductPriceChartData), ByVal ChartType As Integer) As Boolean
        Dim ret As Boolean = True
        Dim ProductDataFlg As Boolean
        Dim ProductSubDataFlg As Boolean

        Try
            Using CmdDB As New SqlCommand
                CmdDB.Connection = ConnDB
                CmdDB.CommandText = SQL_SELECT_M_PRODUCT_PRODUCTSUB
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read()
                        ProductDataFlg = False
                        For Each ProductPriceChartData As clsProductPriceChartData In ProductPriceChartList
                            If ProductPriceChartData.ProductCode = Reader(0) Then
                                ProductPriceChartData.DBSearchFlg = True
                                ProductDataFlg = True
                                ProductSubDataFlg = False

                                ProductPriceChartData.StartTime = Reader(2)
                                ProductPriceChartData.ExercTime = Reader(3)
                                ProductPriceChartData.TradeLimitTime = Reader(4)
                                ProductPriceChartData.ExercPriceTimespan = Reader(5)
                                ProductPriceChartData.CreateStartTime = DateAdd(DateInterval.Second, -ProductPriceChartData.ExercPriceTimespan, ProductPriceChartData.StartTime)
                                ProductPriceChartData.CreateEndTime = ProductPriceChartData.ExercTime

                                For Each ProductSubPriceChartData As clsProductSubPriceChartData In ProductPriceChartData.ProductSubPriceChartList
                                    If ProductSubPriceChartData.ProductSubCode = Reader(6) Then
                                        ProductSubDataFlg = True

                                        SetProductSub(ProductSubPriceChartData, Reader)
                                    End If
                                Next
                                If Not ProductSubDataFlg Then
                                    Dim ProductSubPriceChartData As New clsProductSubPriceChartData

                                    SetProductSubPriceChartData(ProductSubPriceChartData, Reader, ChartType)
                                    ProductPriceChartData.ProductSubPriceChartList.Add(ProductSubPriceChartData)
                                End If
                            End If
                        Next
                        If Not ProductDataFlg Then
                            Dim ProductPriceChartData As New clsProductPriceChartData

                            ProductPriceChartData.DBSearchFlg = True
                            ProductPriceChartData.ProductCode = Reader(0)
                            ProductPriceChartData.ComCode = Reader(1)
                            ProductPriceChartData.StartTime = Reader(2)
                            ProductPriceChartData.ExercTime = Reader(3)
                            ProductPriceChartData.TradeLimitTime = Reader(4)
                            ProductPriceChartData.ExercPriceTimespan = Reader(5)
                            ProductPriceChartData.CreateStartTime = DateAdd(DateInterval.Second, -ProductPriceChartData.ExercPriceTimespan, ProductPriceChartData.StartTime)
                            ProductPriceChartData.CreateEndTime = ProductPriceChartData.ExercTime

                            Dim ProductSubPriceChartData As New clsProductSubPriceChartData

                            SetProductSubPriceChartData(ProductSubPriceChartData, Reader, ChartType)
                            ProductPriceChartData.ProductSubPriceChartList.Add(ProductSubPriceChartData)

                            ProductPriceChartList.Add(ProductPriceChartData)
                        End If
                    End While
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "SetProductData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' プライスチャートSeq一括取得
    '--------------------------------------------------------------------------
    Public Function GetSeqCounterSysDate(ByVal CounterCode As String, ByVal MaxCount As Integer) As String()
        Dim wBuf As String
        Dim CmdDB As SqlCommand
        Dim strSQL As String
        Dim NewSeq(MaxCount - 1) As String

        strSQL = "begin tran" & vbCrLf
        strSQL = strSQL & "select @Counter=[Counter] from [S_Counter] with (updlock) where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "update [S_Counter] set [Counter] = @Counter + @MaxCount where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "select convert(char(8), [SysDate], 112) from [S_SysStatus] where [SysCode] = '0'" & vbCrLf
        strSQL = strSQL & "commit tran"

        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@CounterCode", SqlDbType.Char, 2).Value = CounterCode
            CmdDB.Parameters.Add("@MaxCount", SqlDbType.Int).Value = MaxCount
            CmdDB.Parameters.Add("@Counter", SqlDbType.Int).Direction = ParameterDirection.InputOutput
            CmdDB.Parameters("@Counter").Value = 0

            wBuf = CmdDB.ExecuteScalar()
            For i As Integer = 0 To MaxCount - 1
                NewSeq(i) = wBuf & Format(CmdDB.Parameters("@Counter").Value + i, "000000000")
            Next
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSeqCounterSysDate," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return NewSeq
    End Function

    '--------------------------------------------------------------------------
    ' プライス計算用パラメータ設定
    '--------------------------------------------------------------------------
    Private Sub PremiumCalcParamSet(ByRef lo As LadderOption, ByVal Reader As SqlDataReader, ByVal CurrencyPairCalcParamData As clsCurrencyPairCalcParamData,
                                    ByVal ProductPriceChartData As clsProductPriceChartData, ByVal ProductSubPriceChartData As clsProductSubPriceChartData)
        lo.CalcTime = Reader("RateTime")
        lo.Rate = Reader("Rate")

        lo.InterestRate = CurrencyPairCalcParamData.InterestRate
        lo.SwapRate = CurrencyPairCalcParamData.SwapRate
        lo.HistVol = CurrencyPairCalcParamData.Volatility

        lo.ExercTime = ProductPriceChartData.ExercTime
        lo.ExercPrice = ProductSubPriceChartData.ExercPrice

        lo.VolatilityRatio1Call = ProductSubPriceChartData.VolatilityRatio1Call
        lo.VolatilityRatio1Put = ProductSubPriceChartData.VolatilityRatio1Put
        lo.VolatilityRatio2Call = ProductSubPriceChartData.VolatilityRatio2Call
        lo.VolatilityRatio2Put = ProductSubPriceChartData.VolatilityRatio2Put
        lo.VolatilitySmileACall = ProductSubPriceChartData.VolatilitySmileACall
        lo.VolatilitySmileAPut = ProductSubPriceChartData.VolatilitySmileAPut
        lo.VolatilitySmileBCall = ProductSubPriceChartData.VolatilitySmileBCall
        lo.VolatilitySmileBPut = ProductSubPriceChartData.VolatilitySmileBPut
        lo.VolatilitySpread = ProductSubPriceChartData.VolatilitySpread
        lo.VolatilitySpreadITMCall = ProductSubPriceChartData.VolatilitySpreadITMCall
        lo.VolatilitySpreadITMPut = ProductSubPriceChartData.VolatilitySpreadITMPut
        lo.VolatilitySpreadOTMCall = ProductSubPriceChartData.VolatilitySpreadOTMCall
        lo.VolatilitySpreadOTMPut = ProductSubPriceChartData.VolatilitySpreadOTMPut
        lo.AskFeePriceCall = ProductSubPriceChartData.AskFeePriceCall
        lo.AskFeePricePut = ProductSubPriceChartData.AskFeePricePut
        lo.AskBidSpreadMinCall = ProductSubPriceChartData.AskBidSpreadMinCall
        lo.AskBidSpreadMinPut = ProductSubPriceChartData.AskBidSpreadMinPut
        lo.BidFeeRateCall = ProductSubPriceChartData.BidFeeRateCall
        lo.BidFeeRatePut = ProductSubPriceChartData.BidFeeRatePut
        lo.AskPriceMaxCall = ProductSubPriceChartData.AskPriceMaxCall
        lo.AskPriceMaxPut = ProductSubPriceChartData.AskPriceMaxPut
        lo.AskPriceMinCall = ProductSubPriceChartData.AskPriceMinCall
        lo.AskPriceMinPut = ProductSubPriceChartData.AskPriceMinPut
        lo.BidPriceMaxCall = ProductSubPriceChartData.BidPriceMaxCall
        lo.BidPriceMaxPut = ProductSubPriceChartData.BidPriceMaxPut
        lo.BidPriceMinCall = ProductSubPriceChartData.BidPriceMinCall
        lo.BidPriceMinPut = ProductSubPriceChartData.BidPriceMinPut
    End Sub

    Public Function CreateRegistPriceChartList(ByVal CurrencyPairCalcParamList As List(Of clsCurrencyPairCalcParamData), _
                                                 ByRef SertchRateSeq As String, _
                                                 ByRef ProductPriceChartList As List(Of clsProductPriceChartData), _
                                                 ByRef PriceChartUpdateList As List(Of clsPriceChartData), _
                                                 ByRef PriceChartInsCnt As Integer) As Boolean
        Dim ret As Boolean = True
        Dim PriceChartTime As DateTime
        Dim ComCalcIndex As Integer

        Try
            Using CmdDB As New SqlCommand
                CmdDB.Connection = ConnDB
                CmdDB.CommandText = SQL_SELECT_RATEHIST
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Parameters.Add("@SertchRateSeq", SqlDbType.VarChar, 17).Value = SertchRateSeq
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read
                        SertchRateSeq = Reader("RateSeq")
                        For Each ProductPriceChartData As clsProductPriceChartData In ProductPriceChartList
                            If ProductPriceChartData.CreateStartTime > Reader("RateTime") Then
                                ProductPriceChartData.DBSearchFlg = True
                                Continue For
                            ElseIf ProductPriceChartData.CreateEndTime <= Reader("RateTime") Then
                                Continue For
                            End If

                            ProductPriceChartData.DBSearchFlg = True
                            If ProductPriceChartData.ComCode = Reader("ComCode") Then
                                For Each ProductSubPriceChartData As clsProductSubPriceChartData In ProductPriceChartData.ProductSubPriceChartList
                                    If ProductSubPriceChartData.PriceChartData.RateSeq.CompareTo(SertchRateSeq) >= 0 Then
                                        Continue For
                                    End If

                                    ComCalcIndex = GetCurrencyPairCalcParamListIndex(CurrencyPairCalcParamList, ProductPriceChartData.ComCode)

                                    Dim lo As New LadderOption

                                    PremiumCalcParamSet(lo, Reader, CurrencyPairCalcParamList.Item(ComCalcIndex), ProductPriceChartData, ProductSubPriceChartData)
                                    lo.CalcVolatility()
                                    lo.CalcPrice()

                                    PriceChartTime = ConvChartTime(Reader("RateTime"), ProductSubPriceChartData.PriceChartData.ChartType)
                                    If ProductSubPriceChartData.PriceChartData.PriceChartTime < PriceChartTime Then
                                        If ProductSubPriceChartData.PriceChartData.UpdFlg <> DBUpdateFlg.NoUpdate Then
                                            PriceChartUpdateList.Add(ProductSubPriceChartData.PriceChartData)
                                        End If

                                        Dim PriceChartData As New clsPriceChartData

                                        PriceChartData.UpdFlg = DBUpdateFlg.Insert
                                        PriceChartInsCnt += 1
                                        PriceChartData.ChkLastFlg = True
                                        PriceChartData.ComCode = ProductPriceChartData.ComCode
                                        PriceChartData.ProductCode = ProductPriceChartData.ProductCode
                                        PriceChartData.ProductSubCode = ProductSubPriceChartData.ProductSubCode
                                        PriceChartData.ChartType = ProductSubPriceChartData.PriceChartData.ChartType
                                        PriceChartData.PriceChartTime = PriceChartTime

                                        PriceChartData.OpenAskPriceCall = lo.AskCall
                                        PriceChartData.HighAskPriceCall = lo.AskCall
                                        PriceChartData.LowAskPriceCall = lo.AskCall

                                        PriceChartData.OpenAskPricePut = lo.AskPut
                                        PriceChartData.HighAskPricePut = lo.AskPut
                                        PriceChartData.LowAskPricePut = lo.AskPut

                                        PriceChartData.OpenBidPriceCall = lo.BidCall
                                        PriceChartData.HighBidPriceCall = lo.BidCall
                                        PriceChartData.LowBidPriceCall = lo.BidCall

                                        PriceChartData.OpenBidPricePut = lo.BidPut
                                        PriceChartData.HighBidPricePut = lo.BidPut
                                        PriceChartData.LowBidPricePut = lo.BidPut

                                        ProductSubPriceChartData.PriceChartData = PriceChartData
                                    ElseIf ProductSubPriceChartData.PriceChartData.PriceChartTime = PriceChartTime Then
                                        If ProductSubPriceChartData.PriceChartData.UpdFlg = DBUpdateFlg.NoUpdate Then
                                            ProductSubPriceChartData.PriceChartData.UpdFlg = DBUpdateFlg.Update
                                        End If
                                        If ProductSubPriceChartData.PriceChartData.HighAskPriceCall < lo.AskCall Then
                                            ProductSubPriceChartData.PriceChartData.HighAskPriceCall = lo.AskCall
                                        ElseIf ProductSubPriceChartData.PriceChartData.LowAskPriceCall > lo.AskCall Then
                                            ProductSubPriceChartData.PriceChartData.LowAskPriceCall = lo.AskCall
                                        End If

                                        If ProductSubPriceChartData.PriceChartData.HighAskPricePut < lo.AskPut Then
                                            ProductSubPriceChartData.PriceChartData.HighAskPricePut = lo.AskPut
                                        ElseIf ProductSubPriceChartData.PriceChartData.LowAskPricePut > lo.AskPut Then
                                            ProductSubPriceChartData.PriceChartData.LowAskPricePut = lo.AskPut
                                        End If

                                        If ProductSubPriceChartData.PriceChartData.HighBidPriceCall < lo.BidCall Then
                                            ProductSubPriceChartData.PriceChartData.HighBidPriceCall = lo.BidCall
                                        ElseIf ProductSubPriceChartData.PriceChartData.LowBidPriceCall > lo.BidCall Then
                                            ProductSubPriceChartData.PriceChartData.LowBidPriceCall = lo.BidCall
                                        End If

                                        If ProductSubPriceChartData.PriceChartData.HighBidPricePut < lo.BidPut Then
                                            ProductSubPriceChartData.PriceChartData.HighBidPricePut = lo.BidPut
                                        ElseIf ProductSubPriceChartData.PriceChartData.LowBidPricePut > lo.BidPut Then
                                            ProductSubPriceChartData.PriceChartData.LowBidPricePut = lo.BidPut
                                        End If
                                    Else 'チャート日付が過去の場合エラー出力
                                        ' TODO: エラー出力処理
                                        Continue While
                                    End If
                                    ProductSubPriceChartData.PriceChartData.RateSeq = SertchRateSeq
                                    ProductSubPriceChartData.PriceChartData.CloseAskPriceCall = lo.AskCall
                                    ProductSubPriceChartData.PriceChartData.CloseAskPricePut = lo.AskPut
                                    ProductSubPriceChartData.PriceChartData.CloseBidPriceCall = lo.BidCall
                                    ProductSubPriceChartData.PriceChartData.CloseBidPricePut = lo.BidPut
                                    ProductSubPriceChartData.PriceChartData.CloseTime = Reader("RateTime")

                                    lo = Nothing
                                Next
                            End If
                        Next
                    End While
                End Using
            End Using
            For Each ProductPriceChartData As clsProductPriceChartData In ProductPriceChartList
                For Each ProductSubPriceChartData As clsProductSubPriceChartData In ProductPriceChartData.ProductSubPriceChartList
                    If ProductSubPriceChartData.PriceChartData.UpdFlg <> DBUpdateFlg.NoUpdate Then
                        PriceChartUpdateList.Add(ProductSubPriceChartData.PriceChartData)
                    End If
                Next
            Next
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "CreateRegistPriceChartList," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' プライスチャートUpdate用パラメータ追加
    '--------------------------------------------------------------------------
    Private Sub PriceChartUpdateParamAdd(ByRef CmdUpdDB As SqlCommand)
        CmdUpdDB.Parameters.Add("@InsUser", SqlDbType.VarChar, 34).Value = ""
        CmdUpdDB.Parameters.Add("@PriceChartSeq", SqlDbType.Char, 17).Value = ""
        CmdUpdDB.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ""
        CmdUpdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = ""
        CmdUpdDB.Parameters.Add("@ProductSubCode", SqlDbType.Char, 17).Value = ""
        CmdUpdDB.Parameters.Add("@ChartType", SqlDbType.Int).Value = 0
        CmdUpdDB.Parameters.Add("@RateSeq", SqlDbType.Char, 17).Value = ""
        CmdUpdDB.Parameters.Add("@PriceChartTime", SqlDbType.DateTime2).Value = DateTime.MinValue
        CmdUpdDB.Parameters.Add("@OpenAskPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@HighAskPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@LowAskPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@CloseAskPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@OpenAskPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@HighAskPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@LowAskPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@CloseAskPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@OpenBidPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@HighBidPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@LowBidPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@CloseBidPriceCall", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@OpenBidPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@HighBidPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@LowBidPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@CloseBidPricePut", SqlDbType.Decimal).Value = 0
        CmdUpdDB.Parameters.Add("@CloseTime", SqlDbType.DateTime2).Value = DateTime.MinValue
    End Sub

    '--------------------------------------------------------------------------
    ' プライスチャートデータDBテーブル更新処理
    '--------------------------------------------------------------------------
    Public Function RegistPriceChartData(ByRef PriceChartUpdateList As List(Of clsPriceChartData), ByVal sProcessID As String, ByVal PriceChartInsCnt As Integer) As Boolean
        Dim ret As Boolean = True
        Dim newSeq() As String
        Dim newSeqCnt As Integer = 0

        Try
            Using CmdUpdDB As SqlCommand = New SqlCommand
                CmdUpdDB.Connection = ConnDB
                CmdUpdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdUpdDB.CommandType = CommandType.Text

                PriceChartUpdateParamAdd(CmdUpdDB)

                newSeq = GetSeqCounterSysDate(SeqCounterCode.PriceChart, PriceChartInsCnt)

                For Each PriceChartData As clsPriceChartData In PriceChartUpdateList
                    Select Case PriceChartData.UpdFlg
                        Case DBUpdateFlg.Update
                            CmdUpdDB.CommandText = SQL_UPDATE_T_PRICECHARTHIST

                        Case DBUpdateFlg.Insert
                            CmdUpdDB.CommandText = SQL_INSERT_T_PRICECHARTHIST
                            CmdUpdDB.Parameters("@ComCode").Value = PriceChartData.ComCode
                            CmdUpdDB.Parameters("@ProductCode").Value = PriceChartData.ProductCode
                            CmdUpdDB.Parameters("@ProductSubCode").Value = PriceChartData.ProductSubCode
                            CmdUpdDB.Parameters("@ChartType").Value = PriceChartData.ChartType
                            CmdUpdDB.Parameters("@PriceChartTime").Value = PriceChartData.PriceChartTime

                            If IsError() Then
                                ret = False
                                Exit Try
                            End If

                            PriceChartData.PriceChartSeq = newSeq(newSeqCnt)
                            newSeqCnt += 1
                        Case Else
                            Continue For
                    End Select

                    CmdUpdDB.Parameters("@InsUser").Value = "P:" + sProcessID
                    CmdUpdDB.Parameters("@RateSeq").Value = PriceChartData.RateSeq
                    CmdUpdDB.Parameters("@PriceChartSeq").Value = PriceChartData.PriceChartSeq

                    CmdUpdDB.Parameters("@OpenAskPriceCall").Value = PriceChartData.OpenAskPriceCall
                    CmdUpdDB.Parameters("@HighAskPriceCall").Value = PriceChartData.HighAskPriceCall
                    CmdUpdDB.Parameters("@LowAskPriceCall").Value = PriceChartData.LowAskPriceCall
                    CmdUpdDB.Parameters("@CloseAskPriceCall").Value = PriceChartData.CloseAskPriceCall

                    CmdUpdDB.Parameters("@OpenAskPricePut").Value = PriceChartData.OpenAskPricePut
                    CmdUpdDB.Parameters("@HighAskPricePut").Value = PriceChartData.HighAskPricePut
                    CmdUpdDB.Parameters("@LowAskPricePut").Value = PriceChartData.LowAskPricePut
                    CmdUpdDB.Parameters("@CloseAskPricePut").Value = PriceChartData.CloseAskPricePut

                    CmdUpdDB.Parameters("@OpenBidPriceCall").Value = PriceChartData.OpenBidPriceCall
                    CmdUpdDB.Parameters("@HighBidPriceCall").Value = PriceChartData.HighBidPriceCall
                    CmdUpdDB.Parameters("@LowBidPriceCall").Value = PriceChartData.LowBidPriceCall
                    CmdUpdDB.Parameters("@CloseBidPriceCall").Value = PriceChartData.CloseBidPriceCall

                    CmdUpdDB.Parameters("@OpenBidPricePut").Value = PriceChartData.OpenBidPricePut
                    CmdUpdDB.Parameters("@HighBidPricePut").Value = PriceChartData.HighBidPricePut
                    CmdUpdDB.Parameters("@LowBidPricePut").Value = PriceChartData.LowBidPricePut
                    CmdUpdDB.Parameters("@CloseBidPricePut").Value = PriceChartData.CloseBidPricePut

                    CmdUpdDB.Parameters("@CloseTime").Value = PriceChartData.CloseTime

                    CmdUpdDB.ExecuteNonQuery()
                Next
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "RegistPriceChartData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 日時をプライスチャート日時に変換
    '--------------------------------------------------------------------------
    Public Function ConvChartTime(ByVal TimeData As DateTime, ByVal ChartType As Integer) As DateTime
        Dim wDate As DateTime

        Select Case ChartType
            Case 1
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:mm:00.000"))
            Case 5
                wDate = DateAdd(DateInterval.Minute, -(Minute(TimeData) Mod 5), TimeData)
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:mm:00.000"))
            Case 10
                wDate = DateAdd(DateInterval.Minute, -(Minute(TimeData) Mod 10), TimeData)
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:mm:00.000"))
            Case 30
                wDate = DateAdd(DateInterval.Minute, -(Minute(TimeData) Mod 30), TimeData)
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:mm:00.000"))
            Case 60
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:00:00.000"))
            Case 1440
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd 00:00:00.000"))
            Case Else
                Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:mm:00.000"))
        End Select
    End Function
End Class
