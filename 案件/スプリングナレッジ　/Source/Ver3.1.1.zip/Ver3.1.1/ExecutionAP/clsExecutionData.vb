﻿'------------------------------------------------------------------------------
'
'------------------------------------------------------------------------------
Public Class clsExecutionData
	Public UserID As String					' "P:" + ProcessID
    Public SysDate As Date                  ' システム営業日（S_SysStatus.SysDate）
    Public CurrencyDecimalPlaces As Dictionary(Of String, Integer)  ' 通貨小数桁数
	Public ProductCode As String			' 対象銘柄：銘柄コード
	Public ExercTime As Date				' 対象銘柄：行使期日
    Public TradeSeq As String               ' 対象取引：取引番号Seq
    Public CurCode As String                ' 口座通貨コード
    Public Price As Decimal                 ' 対象取引：購入価格
    Public Lot As Integer                   ' 対象取引：ロット
    Public Premium As Decimal               ' 対象取引：プレミアム
    Public ExercRateSeq As String           ' 行使時レート：RateSeq
    Public ExercRateTime As Date            ' 行使時レート：RateTime
    Public ExercRate As Decimal             ' 行使時レート：Rate

    Public ExercPrice As Decimal            ' 対象取引：行使価格
    Public TradeType As String              ' 対象取引：取引種別 01:UP 02:DOWN

    Public PayoutPrice As Decimal           ' 取引：ペイアウト価格
    Public Payout As Decimal                ' 取引：ペイアウト金額
    Public TradeStatusPrev As String        ' 取引：取引ステータス(更新前)
    Public TradeStatus As String            ' 取引：取引ステータス

    Public CashType As String               ' 入出金：入出金種別
    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub New()
        UserID = ""
        SysDate = Nothing
        ProductCode = ""
        ExercTime = Nothing
        TradeSeq = ""
        ExercRateSeq = ""
        ExercRateTime = Nothing
        ExercRate = 0

        ExercPrice = 0
        TradeType = ""

        Payout = 0
        TradeStatus = ""

        CashType = ""
    End Sub

    '--------------------------------------------------------------------------
    ' Copy
    '--------------------------------------------------------------------------
    Public Sub Copy(item As clsExecutionData)
        Me.UserID = item.UserID
        Me.SysDate = item.SysDate
        Me.CurrencyDecimalPlaces = item.CurrencyDecimalPlaces
        Me.ProductCode = item.ProductCode
        Me.ExercTime = item.ExercTime
        Me.TradeSeq = item.TradeSeq
        Me.CurCode = item.CurCode
        Me.Price = item.Price
        Me.Lot = item.Lot
        Me.Premium = item.Premium
        Me.ExercRateSeq = item.ExercRateSeq
        Me.ExercRateTime = item.ExercRateTime
        Me.ExercRate = item.ExercRate

        Me.ExercPrice = item.ExercPrice
        Me.TradeType = item.TradeType

        Me.PayoutPrice = item.PayoutPrice
        Me.Payout = item.Payout
        Me.TradeStatusPrev = item.TradeStatusPrev
        Me.TradeStatus = item.TradeStatus

        Me.CashType = item.CashType
    End Sub

    '--------------------------------------------------------------------------
    ' ＡＴＭ判定
    '--------------------------------------------------------------------------
    Public Function IsExecutionATM() As Boolean
        Dim bATM As Boolean

        bATM = False
        'If ExercPrice = ExercRate Then
        '    bATM = True
        'End If

        Return bATM
    End Function

    '--------------------------------------------------------------------------
    ' ＵＰ判定
    '--------------------------------------------------------------------------
    Public Function IsExecutionUP() As Boolean
        Dim bUP As Boolean

        bUP = False
        If IsExecutionATM() = False And TradeType.Equals("01") And ExercPrice <= ExercRate Then
            bUP = True
        End If

        Return bUP
    End Function

    '--------------------------------------------------------------------------
    ' ＤＯＷＮ判定
    '--------------------------------------------------------------------------
    Public Function IsExecutionDOWN() As Boolean
        Dim bDOWN As Boolean

        bDOWN = False
        If IsExecutionATM() = False And IsExecutionUP() = False And TradeType.Equals("02") And ExercPrice > ExercRate Then
            bDOWN = True
        End If

        Return bDOWN
    End Function

    '--------------------------------------------------------------------------
    ' 消滅判定
    '--------------------------------------------------------------------------
    Public Function IsExtinction() As Boolean
        Dim bExtinct As Boolean

        bExtinct = False
        If IsExecutionATM() = False And IsExecutionUP() = False And IsExecutionDOWN() = False Then
            bExtinct = True
        End If

        Return bExtinct
    End Function

    '--------------------------------------------------------------------------
    ' ＡＴＭ行使　更新データの設定
    '--------------------------------------------------------------------------
    Public Sub SetExecutionATM()
        PayoutPrice = Price
        Payout = Premium
        TradeStatusPrev = "02"
        TradeStatus = "13"

        CashType = "07"
    End Sub

    '--------------------------------------------------------------------------
    ' 普通(UP/DOWN)行使　更新データの設定
    '--------------------------------------------------------------------------
    Public Sub SetExecution()
        PayoutPrice = 1000
        Payout = Lot * PayoutPrice
        TradeStatusPrev = "02"
        TradeStatus = "10"

        CashType = "05"
    End Sub

    '--------------------------------------------------------------------------
    ' 消滅　更新データの設定
    '--------------------------------------------------------------------------
    Public Sub SetExtinction()
        Payout = 0
        TradeStatusPrev = "02"
        TradeStatus = "12"

        CashType = "06"
    End Sub
End Class
