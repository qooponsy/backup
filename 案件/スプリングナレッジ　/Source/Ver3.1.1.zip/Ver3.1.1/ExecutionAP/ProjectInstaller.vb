﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'この呼び出しは、コンポーネント デザイナーで必要です。
        InitializeComponent()

        'InitializeComponent への呼び出し後、初期化コードを追加します
#If REL_DEMO Then
        Me.ServiceInstaller.Description = "ExecutionAPDemo"
        Me.ServiceInstaller.ServiceName = "ExecutionAPDemo"
#End If
#If REL_TEST Then
        Me.ServiceInstaller.Description = "ExecutionAPTest"
        Me.ServiceInstaller.ServiceName = "ExecutionAPTest"
#End If
#If REL_NEXT Then
        Me.ServiceInstaller.Description = "ExecutionAPNext"
        Me.ServiceInstaller.ServiceName = "ExecutionAPNext"
#End If
#If REL_UK Then
        Me.ServiceInstaller.Description = "ExecutionAPUK"
        Me.ServiceInstaller.ServiceName = "ExecutionAPUK"
#End If
#If REL_MT4 Then
        Me.ServiceInstaller.Description = "ExecutionAPMT4"
        Me.ServiceInstaller.ServiceName = "ExecutionAPMT4"
#End If
#If REL_V3 Then
        Me.ServiceInstaller.Description = "ExecutionAPV3"
        Me.ServiceInstaller.ServiceName = "ExecutionAPV3"
#End If
    End Sub

End Class
