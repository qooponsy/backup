﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics

Public Class ExecutionQueueItem
    Public Signal As New ManualResetEvent(False)
    Public ExecutionList As New List(Of clsExecutionData)
    Public Result As Boolean = False
End Class

'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsExecutionAP
    Private intThreadNum As Integer
    Private strServiceName As String
    Private blnServiceStopFlag As Boolean
    Private blnMasterMode As Boolean

    Private WorkerClass() As clsWorkerExecution
    Private WorkerWaitHandles() As WaitHandle

    Private MasterHB() As Byte
    Private SlaveHB() As Byte
    Private HeartBeatUDP As UdpClient
    Private MasterWatch As Stopwatch
    Private SocketErrMsg As String

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub New()
        intThreadNum = 0
        blnServiceStopFlag = False
        strServiceName = "ExecutionAP"
#If REL_DEMO Then
        strServiceName = "ExecutionAPDemo"
#End If
#If REL_TEST Then
        strServiceName = "ExecutionAPTest"
#End If
#If REL_NEXT Then
        strServiceName = "ExecutionAPNext"
#End If
#If REL_UK Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_MT4 Then
        strServiceName = "ExecutionAPMT4"
#End If
#If REL_V3 Then
        strServiceName = "ExecutionAPV3"
#End If
        blnMasterMode = False
    End Sub

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsMasterMode() As Boolean
        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッドの初期設定
    '--------------------------------------------------------------------------
    Public Function InitializeServiceThread() As Boolean
        Dim bInitRes As Boolean

        bInitRes = True

        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        intThreadNum = 0

        Return bInitRes
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッド
    '--------------------------------------------------------------------------
    Public Sub ServiceThread()
        Dim DataBase As clsPenguinDB
        Dim ComList As DataTable
        Dim ProductList As DataTable
        Dim indexComList As Integer
        Dim indexProductList As Integer
        Dim PairListCount As Integer
        Dim ProductListCount As Integer
        Dim ComCode As String
        Dim RateEnableTime As Integer
        Dim ProductCode As String
        Dim ExercTime As Date
        Dim IntervalStopWatch As Stopwatch
        Dim HeartBeatWatch As Stopwatch
        Dim iInterval As Integer
        Dim iHeartBeatCycle As Integer
        Dim IndexWorker As Integer
        Dim WorkerCount As Integer

        Logging("ServiceThread Start.", EventLogEntryType.Information)

        StartExecutionThread()

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew

        iInterval = 0
        iHeartBeatCycle = My.Settings.HeartBeatCycle

        OnSlaveMode()
        IntervalStopWatch = Stopwatch.StartNew()
        HeartBeatWatch = Stopwatch.StartNew

        RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTime)
        Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)

        While blnServiceStopFlag = False
            If HeartBeatWatch.ElapsedMilliseconds() >= iHeartBeatCycle Then
                CheckMasterAlive()
                HeartBeatWatch.Stop()
                HeartBeatWatch.Reset()
                HeartBeatWatch.Start()
            End If

            If IntervalStopWatch.ElapsedMilliseconds() >= iInterval Then
                iInterval = My.Settings.ExecutionInterval
                IntervalStopWatch.Stop()

                If RunningContoroller.check() Then
                    Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
                End If

                If RunningContoroller.Running Then
                    DataBase = New clsPenguinDB
                    ComList = Nothing
                    If DataBase.GetSqlConnection(My.Settings.DB) = True Then

                        If DataBase.GetCurrencyPairList(ComList) = True Then
                            PairListCount = ComList.Rows.Count
                        Else
                            PairListCount = 0
                            'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                        End If

                        ' 通貨ペア毎に行使対象該当銘を抽出
                        If PairListCount > 0 Then
                            indexComList = 0
                            While indexComList < PairListCount And blnServiceStopFlag = False
                                ComCode = ComList.Rows(indexComList).Item("ComCode")
                                RateEnableTime = ComList.Rows(indexComList).Item("EnableTime")

                                indexComList = indexComList + 1

                                ProductList = Nothing
                                If DataBase.GetExecutionProductList(ComCode, ProductList) = True Then
                                    ProductListCount = ProductList.Rows.Count
                                Else
                                    ProductListCount = 0
                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                End If

                                ' 行使対象銘柄単位にワーカースレッド生成
                                If ProductListCount > 0 Then
                                    '------------------------------
                                    ' 毎回Workerを再構築 Start
                                    '------------------------------
                                    ReDim WorkerClass(ProductListCount - 1)
                                    ReDim WorkerWaitHandles(ProductListCount - 1)

                                    For IndexWorker = 0 To ProductListCount - 1
                                        WorkerClass(IndexWorker) = New clsWorkerExecution
                                        WorkerWaitHandles(IndexWorker) = New AutoResetEvent(False)
                                    Next
                                    intThreadNum = ProductListCount
                                    '------------------------------
                                    ' 毎回Workerを再構築 End
                                    '------------------------------

                                    '----------------------------------------------------------------------
                                    ' Worker実行 同時稼動数(iThreadNum)
                                    ' ※ ProductListCount > intThreadNumの場合は
                                    ' 複数回に分けてWorker実行
                                    '----------------------------------------------------------------------
                                    indexProductList = 0
                                    While indexProductList < ProductListCount And blnServiceStopFlag = False
                                        For IndexWorker = 0 To intThreadNum - 1
                                            If indexProductList < ProductListCount Then
                                                ProductCode = ProductList.Rows(indexProductList).Item("ProductCode")
                                                ExercTime = CDate(ProductList.Rows(indexProductList).Item("ExercTime"))
                                                indexProductList = indexProductList + 1
                                            Else
                                                ProductCode = ""
                                                ExercTime = Nothing
                                            End If

                                            WorkerClass(IndexWorker).InitializeWorkerThread(ComCode, ProductCode, ExercTime, blnMasterMode, RateEnableTime)
                                            ThreadPool.QueueUserWorkItem(AddressOf WorkerClass(IndexWorker).WorkerThread, WorkerWaitHandles(IndexWorker))
                                        Next

                                        '-----------------------------
                                        ' ワーカースレッド停止待機
                                        '-----------------------------
                                        While Not WaitHandle.WaitAll(WorkerWaitHandles, My.Settings.HeartBeatCycle)
                                            CheckMasterAlive()
                                        End While

                                        '-----------------------------
                                        ' Workerからの停止要求判定
                                        '-----------------------------
                                        For IndexWorker = 0 To intThreadNum - 1
                                            If WorkerClass(IndexWorker).IsAbortRequest() = True Then
                                                blnServiceStopFlag = True
                                            End If
                                        Next
                                    End While

                                    '------------------------------------
                                    ' Worker-Objectの開放
                                    '------------------------------------
                                    WorkerCount = intThreadNum
                                    intThreadNum = 0
                                    For IndexWorker = 0 To WorkerCount - 1
                                        WorkerWaitHandles(IndexWorker) = Nothing
                                        WorkerClass(IndexWorker) = Nothing
                                    Next
                                End If
                            End While
                        End If

                        DataBase.EndSqlConnection()
                    Else
                        'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                    End If

                    DataBase = Nothing
                End If

                IntervalStopWatch.Reset()
                IntervalStopWatch.Start()
            End If
            Thread.Sleep(500)
        End While

        IntervalStopWatch.Stop()

        '------------------------------------
        ' Worker-Objectの開放
        '------------------------------------
        For IndexWorker = 0 To intThreadNum - 1
            WorkerWaitHandles(IndexWorker) = Nothing
            WorkerClass(IndexWorker) = Nothing
        Next

        MasterWatch.Stop()
        HeartBeatUDP.Close()

        StopExecutionThread()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド、及びワーカースレッドの停止要求
    '--------------------------------------------------------------------------
    Public Sub StopService()
        Dim IndexThread As Integer

        blnServiceStopFlag = True
        If intThreadNum > 0 Then
            For IndexThread = 0 To intThreadNum - 1
                WorkerClass(IndexThread).StopWorker()
            Next
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnMasterMode()
        Dim IndexWorker As Integer

        For IndexWorker = 0 To intThreadNum - 1
            WorkerClass(IndexWorker).OnWorkerMasterMode()
        Next

        Logging("Master Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnSlaveMode()
        Dim IndexWorker As Integer

        For IndexWorker = 0 To intThreadNum - 1
            WorkerClass(IndexWorker).OnWorkerSlaveMode()
        Next

        Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        bMasterRecv = False
        bSlaveRecv = False
        iHeartBeatPriority = 9
        If HeartBeatUDP.Available() > 0 Then
            Dim sDataHB As String
            Dim DataHB() As Byte

            RemoteEP = Nothing
            Try
                DataHB = Nothing
                While HeartBeatUDP.Available() > 0
                    DataHB = HeartBeatUDP.Receive(RemoteEP)
                End While
                sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                Do
                    Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                    If NextIndex = -1 Then Exit Do
                    If sDataHB.Length - NextIndex < 3 Then Exit Do
                    sDataHB = sDataHB.Substring(NextIndex)
                Loop While True
                If My.Settings.HeartBeatLog Then SystemLog.Information(sDataHB)
                If sDataHB.Length >= 3 Then
                    sHeartBeatMode = sDataHB.Substring(1, 1)
                    iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                    If sHeartBeatMode.Equals("M") = True Then
                        bMasterRecv = True
                        MasterWatch.Reset()
                        MasterWatch.Start()
                    End If
                    If sHeartBeatMode.Equals("S") = True Then
                        bSlaveRecv = True
                    End If
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
            End Try
        End If

        If blnMasterMode = True Then
            If bMasterRecv = True Then
                ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                If iHeartBeatPriority < My.Settings.MasterPriority Then
                    OnSlaveMode()
                    blnMasterMode = False
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        Else
            If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                OnMasterMode()
                blnMasterMode = True
                MasterWatch.Reset()
                MasterWatch.Start()
            ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                If SystemLog.GetDBErrorCount() > 0 Then
                    If My.Settings.HeartBeatLog Then SystemLog.Information("DB Error Now.")
                Else
                    OnMasterMode()
                    blnMasterMode = True
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        End If

        Try
            If blnMasterMode Then
                HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            Else
                HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            End If
        Catch ex As Exception
            If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
        End Try

        Return blnMasterMode
    End Function

    Private Function IsStartEndTimeReverse() As Boolean
        Return My.Settings.StartTime > My.Settings.EndTime
    End Function

    Private Function GetDateAjust(ByRef RunnableTime As Boolean) As DateTime
        Dim nowDateTime As DateTime = DateTime.Now
        Dim now As New TimeSpan(0, nowDateTime.Hour, nowDateTime.Minute, nowDateTime.Second, nowDateTime.Millisecond)
        If IsStartEndTimeReverse() Then
            RunnableTime = (My.Settings.StartTime < now) Or (My.Settings.EndTime > now)
            If My.Settings.EndTime < now Then
                Return nowDateTime.Date
            Else
                Return nowDateTime.AddDays(-1).Date
            End If
        Else
            RunnableTime = (My.Settings.StartTime < now) And (My.Settings.EndTime > now)
            If My.Settings.EndTime < now Then
                Return nowDateTime.AddDays(1).Date
            Else
                Return nowDateTime.Date
            End If
        End If
    End Function

    Private Function GetStopTime(ByVal WorkDate As DateTime) As DateTime
        Dim endTime As TimeSpan = My.Settings.EndTime
        Dim stopTime As New DateTime(WorkDate.Year, WorkDate.Month, WorkDate.Day, endTime.Hours, endTime.Minutes, endTime.Seconds)
        If IsStartEndTimeReverse() Then
            stopTime = stopTime.AddDays(1)
        End If
        Return stopTime
    End Function

    Private Function GetNextStartTime(ByVal NextDate As DateTime) As DateTime
        Dim startTime As TimeSpan = My.Settings.StartTime
        Dim nextStartTime As New DateTime(NextDate.Year, NextDate.Month, NextDate.Day, startTime.Hours, startTime.Minutes, startTime.Seconds)
        Return nextStartTime
    End Function

    '--------------------------------------------------------------------------
    ' 行使・消滅実行スレッドプール
    '--------------------------------------------------------------------------

    Private Shared ExecutionThread() As Thread
    Private Shared ExecutionTerm As New ManualResetEvent(False)
    Private Shared ExecutionListQueue As New Queue(Of ExecutionQueueItem)
    Private Shared ExecutionListQueueExist As New ManualResetEvent(False)

    Public Shared Sub AddExecutionQueue(item As ExecutionQueueItem)
        SyncLock ExecutionListQueue
            ExecutionListQueue.Enqueue(item)
            ExecutionListQueueExist.Set()
        End SyncLock
    End Sub

    Private Shared Sub StartExecutionThread()
        ReDim ExecutionThread(My.Settings.ExecutionThreadCount)
        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
            ExecutionThread(fa) = New Thread(AddressOf ExecutionThreadProc)
            ExecutionThread(fa).Start()
        Next
    End Sub

    Private Shared Sub StopExecutionThread()
        ExecutionTerm.Set()
        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
            ExecutionThread(fa).Join()
        Next
    End Sub

    Private Shared Sub ExecutionThreadProc()
        Dim WaitList As WaitHandle() = {ExecutionTerm, ExecutionListQueueExist}
        While True
            Try
                Dim WaitRet As Integer = WaitHandle.WaitAny(WaitList)
                If WaitRet = 0 Then Exit While
                If WaitRet = 1 Then
                    Dim item As ExecutionQueueItem = Nothing
                    SyncLock ExecutionListQueue
                        Try
                            item = ExecutionListQueue.Dequeue()
                            If ExecutionListQueue.Count = 0 Then
                                ExecutionListQueueExist.Reset()
                            Else
                                ExecutionListQueueExist.Set()
                            End If
                        Catch ex As InvalidOperationException
                            '空だった
                            ExecutionListQueueExist.Reset()
                        End Try
                    End SyncLock

                    If item IsNot Nothing Then
                        Dim ExecDataList As List(Of clsExecutionData) = item.ExecutionList
                        Dim bResultDB As Boolean = False
                        Dim DataBase As clsPenguinDB
                        Try
                            DataBase = New clsPenguinDB
                            bResultDB = DataBase.GetSqlConnection(My.Settings.DB)
                            If bResultDB Then
                                For Each ExecData As clsExecutionData In ExecDataList
                                    If ExecutionTerm.WaitOne(0) Then
                                        bResultDB = False
                                        Exit For
                                    End If

                                    If ExecData.IsExecutionATM() = True Then
                                        Debug.Print("Exec  ATM:" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                                        ExecData.SetExecutionATM()
                                    ElseIf ExecData.IsExecutionUP() = True Then
                                        Debug.Print("Exec   UP:" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                                        ExecData.SetExecution()
                                    ElseIf ExecData.IsExecutionDOWN() = True Then
                                        Debug.Print("Exec DOWN:" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                                        ExecData.SetExecution()
                                    Else
                                        Debug.Print("Extinct  :" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                                        ExecData.SetExtinction()
                                    End If

                                    Dim bResultDBUnit As Boolean = DataBase.UpdateExecution(ExecData)
                                    If bResultDB And Not bResultDBUnit Then
                                        bResultDB = False
                                    End If
                                Next
                                DataBase.EndSqlConnection()
                            End If
                        Finally
                            ExecDataList.Clear()
                            item.Result = bResultDB
                            item.Signal.Set()
                        End Try
                    End If
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
            End Try
        End While
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog

        Try
            Debug.Print(sMessage)
            eLog = New EventLog()
            eLog.Source = strServiceName
            eLog.WriteEntry(sMessage, entryType)
            eLog = Nothing
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
    End Sub

End Class
