﻿Imports System
Imports System.Threading

'------------------------------------------------------------------------------
' ExecutionAP サービス
'------------------------------------------------------------------------------
Public Class ExecutionAP
    Private serviceClass As clsExecutionAP
	Private serviceThread As Thread

	'--------------------------------------------------------------------------
	' サービス開始
	'--------------------------------------------------------------------------
	Protected Overrides Sub OnStart(ByVal args() As String)
		' ExecutionAP 用 制御メインスレッド作成、実行
        serviceClass = New clsExecutionAP()
		serviceThread = New Thread(AddressOf serviceClass.ServiceThread)

        serviceClass.InitializeServiceThread()
		serviceThread.Start()
	End Sub

	'--------------------------------------------------------------------------
	' サービス停止
	'--------------------------------------------------------------------------
	Protected Overrides Sub OnStop()
		If Not IsNothing(serviceThread) Then
			If serviceThread.IsAlive Then
				serviceClass.StopService()
				serviceThread.Join()
			End If
			serviceThread = Nothing
			serviceClass = Nothing
		End If
	End Sub

End Class
