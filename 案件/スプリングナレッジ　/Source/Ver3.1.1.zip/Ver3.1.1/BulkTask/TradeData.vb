﻿Public Class TradeData

    Public TradeSeq As String

End Class
