﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'この呼び出しは、コンポーネント デザイナーで必要です。
        InitializeComponent()

        'InitializeComponent への呼び出し後、初期化コードを追加します
#If REL_DEMO Then
        Me.ServiceInstaller.Description = "BulkTaskDemo"
        Me.ServiceInstaller.ServiceName = "BulkTaskDemo"
#End If
#If REL_TEST Then
        Me.ServiceInstaller.Description = "BulkTaskTest"
        Me.ServiceInstaller.ServiceName = "BulkTaskTest"
#End If
#If REL_NEXT Then
        Me.ServiceInstaller.Description = "BulkTaskNext"
        Me.ServiceInstaller.ServiceName = "BulkTaskNext"
#End If
#If REL_UK Then
        Me.ServiceInstaller.Description = "BulkTaskUK"
        Me.ServiceInstaller.ServiceName = "BulkTaskUK"
#End If
#If REL_MT4 Then
        Me.ServiceInstaller.Description = "BulkTaskMT4"
        Me.ServiceInstaller.ServiceName = "BulkTaskMT4"
#End If
#If REL_V3 Then
        Me.ServiceInstaller.Description = "BulkTaskV3"
        Me.ServiceInstaller.ServiceName = "BulkTaskV3"
#End If

    End Sub

End Class
