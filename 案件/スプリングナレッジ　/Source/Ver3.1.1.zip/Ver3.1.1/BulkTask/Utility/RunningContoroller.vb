﻿Imports System.Data.SqlClient

Public Class RunningContoroller

    Public Shared DBConnection As String

    Public Shared Running As Boolean
    Public Shared NextTime As DateTime

    Private Shared StartTime As TimeSpan
    Private Shared EndTime As TimeSpan
    Private Shared EndTimeWeekEnd As TimeSpan

    Private Shared SysDateTimeZone As Integer

    Public Shared TestTime As DateTime = DateTime.MinValue

    Public Shared Function initialize(pDBConnection As String, pStartTime As TimeSpan, pEndTime As TimeSpan, pEndTimeWeekEnd As TimeSpan) As Boolean
        DBConnection = pDBConnection
        StartTime = pStartTime
        EndTime = pEndTime
        EndTimeWeekEnd = pEndTimeWeekEnd
        Dim NowTime As DateTime = DateTime.UtcNow
        If TestTime <> DateTime.MinValue Then
            NowTime = TestTime
        End If
        If Not checkTime(NowTime) Then
            Return False
        End If
        Return True
    End Function

    Public Shared Function check() As Boolean
        Dim ret As Boolean = False

        Dim NowTime As DateTime = DateTime.UtcNow
        If TestTime <> DateTime.MinValue Then
            NowTime = TestTime
        End If
        If NowTime >= NextTime Then
            ret = checkTime(NowTime)
        End If
        Return ret
    End Function

    Private Shared Function checkTime(NowTime As DateTime) As Boolean
        Dim PrevRunning As Boolean = Running
        Dim PrevNextTime As DateTime = NextTime
        Dim NewRunning As Boolean = Running
        readSysDateTimeZone()

        Dim NowTimeSysDateTimeZone As DateTime = NowTime.AddMinutes(SysDateTimeZone)
        Dim NowDate As New DateTime(NowTimeSysDateTimeZone.Year, NowTimeSysDateTimeZone.Month, NowTimeSysDateTimeZone.Day)
        Dim NowTimeSpan As New TimeSpan(NowTimeSysDateTimeZone.Hour, NowTimeSysDateTimeZone.Minute, NowTimeSysDateTimeZone.Second)

        Dim SysDate As DateTime
        Dim Work As String = Nothing
        getSysDate(NowDate, SysDate, Work)

        Dim NextTimeSysDateTimeZone As DateTime
        If NowDate = SysDate AndAlso NowTimeSpan < StartTime Then
            NewRunning = False
            NextTimeSysDateTimeZone = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day).Add(StartTime)
        ElseIf NowDate = SysDate AndAlso Work = "1" AndAlso NowTimeSpan < EndTime Then
            NewRunning = True
            NextTimeSysDateTimeZone = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day).Add(EndTime)
        ElseIf NowDate = SysDate AndAlso Work = "2" AndAlso NowTimeSpan < EndTimeWeekEnd Then
            NewRunning = True
            NextTimeSysDateTimeZone = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day).Add(EndTimeWeekEnd)
        Else
            If NowDate <> SysDate Then
                NewRunning = False
                NextTimeSysDateTimeZone = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day).Add(StartTime)
            Else
                getSysDate(NowDate.AddDays(1), SysDate, Work)
                NewRunning = False
                NextTimeSysDateTimeZone = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day).Add(StartTime)
            End If
        End If
        Running = NewRunning
        NextTime = NextTimeSysDateTimeZone.AddMinutes(-SysDateTimeZone)

        Return PrevRunning <> Running OrElse PrevNextTime <> NextTime
    End Function

    Private Shared Sub readSysDateTimeZone()
        Using con As New SqlConnection(DBConnection)
            con.Open()
            Using cmd As New SqlCommand
                cmd.Connection = con
                cmd.CommandText = "select [SysDateTimeZone] from [M_SysSettings] with ( nolock ) where [SysCode]='0'"
                SysDateTimeZone = cmd.ExecuteScalar()
            End Using
            con.Close()
        End Using
    End Sub

    Private Shared Sub getSysDate(NowDate As DateTime, ByRef SysDate As DateTime, ByRef Work As String)
        Using con As New SqlConnection(DBConnection)
            con.Open()
            Using cmd As New SqlCommand
                cmd.Connection = con
                cmd.CommandText = My.Resources.SQL_System_CheckSysDate
                Dim param As SqlParameter
                param = cmd.Parameters.Add("@workdate", SqlDbType.Date)
                param.Direction = ParameterDirection.InputOutput
                param.Value = NowDate
                param = cmd.Parameters.Add("@work", SqlDbType.Char, 1)
                param.Direction = ParameterDirection.Output
                cmd.ExecuteNonQuery()
                SysDate = cmd.Parameters("@workdate").Value
                Work = cmd.Parameters("@work").Value
            End Using
            con.Close()
        End Using
    End Sub



End Class
