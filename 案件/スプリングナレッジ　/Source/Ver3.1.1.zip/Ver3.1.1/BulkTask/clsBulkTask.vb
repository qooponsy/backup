﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics

Public Class clsBulkTask

    Private strServiceName As String
    Private blnServiceStopFlag As Boolean
    Private blnMasterMode As Boolean

    Private MasterHB() As Byte
    Private SlaveHB() As Byte
    Private HeartBeatUDP As UdpClient
    Private MasterWatch As Stopwatch
    Private SocketErrMsg As String

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub New()
        blnServiceStopFlag = False
        strServiceName = "BulkTask"
#If REL_DEMO Then
        strServiceName = "BulkTaskDemo"
#End If
#If REL_TEST Then
        strServiceName = "BulkTaskTest"
#End If
#If REL_NEXT Then
        strServiceName = "BulkTaskNext"
#End If
#If REL_UK Then
        strServiceName = "BulkTaskUK"
#End If
#If REL_MT4 Then
        strServiceName = "BulkTaskMT4"
#End If
#If REL_V3 Then
        strServiceName = "BulkTaskV3"
#End If

        blnMasterMode = False
    End Sub

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsMasterMode() As Boolean
        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッドの初期設定
    '--------------------------------------------------------------------------
    Public Function InitializeServiceThread() As Boolean
        Dim bInitRes As Boolean

        bInitRes = True

        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)

        Return bInitRes
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッド
    '--------------------------------------------------------------------------
    Public Sub ServiceThread()
        Dim DataBase As clsPenguinDB
        Dim IntervalStopWatch As Stopwatch
        Dim HeartBeatWatch As Stopwatch
        Dim iInterval As Integer
        Dim iHeartBeatCycle As Integer

        Logging("ServiceThread Start.", EventLogEntryType.Information)

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew

        iInterval = 0
        iHeartBeatCycle = My.Settings.HeartBeatCycle

        OnSlaveMode()
        IntervalStopWatch = Stopwatch.StartNew()
        HeartBeatWatch = Stopwatch.StartNew

        RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTime)
        Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime), EventLogEntryType.Information)

        While blnServiceStopFlag = False
            If HeartBeatWatch.ElapsedMilliseconds() >= iHeartBeatCycle Then
                CheckMasterAlive()
                HeartBeatWatch.Stop()
                HeartBeatWatch.Reset()
                HeartBeatWatch.Start()
            End If

            If IntervalStopWatch.ElapsedMilliseconds() >= iInterval Then
                iInterval = My.Settings.ExecutionInterval
                IntervalStopWatch.Stop()

                If RunningContoroller.check() Then
                    Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime), EventLogEntryType.Information)
                End If

                If RunningContoroller.Running Then
                    DataBase = New clsPenguinDB
                    If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                        If blnMasterMode Then
                            Dim TaskList As List(Of BulkTaskData) = Nothing
                            If Not DataBase.GetBulkTaskList(TaskList) Then
                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                            Else
                                For Each item As BulkTaskData In TaskList
                                    Select Case item.TaskType
                                        Case "00"   '何もしない
                                            If item.TaskStatus = "0" Then
                                                DataBase.StartTask(item.TaskSeq, 0)
                                            End If
                                            DataBase.EndTask(item.TaskSeq, 0, "")
                                        Case "01", "02", "03"       '01:銘柄単位取引キャンセル　02:システム停止 全取引キャンセル　03:銘柄詳細単位取引キャンセル
                                            If item.TaskStatus = "0" Then
                                                Dim count As Integer = 0
                                                If Not DataBase.GetTradeCancelCount(item.TaskParam, count, item.TaskType) Then
                                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                    DataBase.ErrorTask(item.TaskSeq, "キャンセル件数取得失敗")
                                                    Continue For
                                                End If
                                                DataBase.StartTask(item.TaskSeq, count)
                                            End If

                                            Dim TradeList As List(Of TradeData) = Nothing
                                            If Not DataBase.GetTradeCancelList(item.TaskParam, TradeList, item.TaskType) Then
                                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                Continue For
                                            End If

                                            Dim CancelError As Boolean = False
                                            Dim CancelCount As Integer = 0
                                            Dim HBCount As Integer = 0
                                            For Each trade As TradeData In TradeList
                                                If HBCount Mod 50 = 0 Then
                                                    CheckMasterAlive()
                                                End If
                                                HBCount += 1
                                                If Not DataBase.CancelTask(trade.TradeSeq) Then
                                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                    CancelError = True
                                                    Continue For
                                                End If
                                                CancelCount += 1
                                            Next

                                            If Not CancelError Then
                                                DataBase.EndTask(item.TaskSeq, item.ExecStep + CancelCount, "")
                                            End If
                                    End Select
                                Next
                            End If

                        End If

                        DataBase.EndSqlConnection()
                    Else
                        'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                    End If

                    DataBase = Nothing
                End If

                IntervalStopWatch.Reset()
                IntervalStopWatch.Start()
            End If
            Thread.Sleep(500)
        End While

        IntervalStopWatch.Stop()

        MasterWatch.Stop()
        HeartBeatUDP.Close()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド、及びワーカースレッドの停止要求
    '--------------------------------------------------------------------------
    Public Sub StopService()
        blnServiceStopFlag = True
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnMasterMode()
        Logging("Master Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnSlaveMode()
        Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        bMasterRecv = False
        bSlaveRecv = False
        iHeartBeatPriority = 9
        If HeartBeatUDP.Available() > 0 Then
            Dim sDataHB As String
            Dim DataHB() As Byte

            RemoteEP = Nothing
            Try
                DataHB = Nothing
                While HeartBeatUDP.Available() > 0
                    DataHB = HeartBeatUDP.Receive(RemoteEP)
                End While
                sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                Do
                    Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                    If NextIndex = -1 Then Exit Do
                    If sDataHB.Length - NextIndex < 3 Then Exit Do
                    sDataHB = sDataHB.Substring(NextIndex)
                Loop While True
                If My.Settings.HeartBeatLog Then SystemLog.Information(sDataHB)
                If sDataHB.Length >= 3 Then
                    sHeartBeatMode = sDataHB.Substring(1, 1)
                    iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                    If sHeartBeatMode.Equals("M") = True Then
                        bMasterRecv = True
                        MasterWatch.Reset()
                        MasterWatch.Start()
                    End If
                    If sHeartBeatMode.Equals("S") = True Then
                        bSlaveRecv = True
                    End If
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
            End Try
        End If

        If blnMasterMode = True Then
            If bMasterRecv = True Then
                ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                If iHeartBeatPriority < My.Settings.MasterPriority Then
                    OnSlaveMode()
                    blnMasterMode = False
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        Else
            If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                OnMasterMode()
                blnMasterMode = True
                MasterWatch.Reset()
                MasterWatch.Start()
            ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                If SystemLog.GetDBErrorCount() > 0 Then
                    If My.Settings.HeartBeatLog Then SystemLog.Information("DB Error Now.")
                Else
                    OnMasterMode()
                    blnMasterMode = True
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        End If

        Try
            If blnMasterMode Then
                HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            Else
                HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            End If
        Catch ex As Exception
            If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
        End Try

        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog

        Try
            Debug.Print(sMessage)
            eLog = New EventLog()
            eLog.Source = strServiceName
            eLog.WriteEntry(sMessage, entryType)
            eLog = Nothing
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
    End Sub

End Class
