﻿Imports System
Imports System.Threading

Public Class BulkTask
    Private serviceClass As clsBulkTask
    Private serviceThread As Thread

    Protected Overrides Sub OnStart(ByVal args() As String)
        serviceClass = New clsBulkTask()
        serviceThread = New Thread(AddressOf serviceClass.ServiceThread)

        serviceClass.InitializeServiceThread()
        serviceThread.Start()
    End Sub

    Protected Overrides Sub OnStop()
        If Not IsNothing(serviceThread) Then
            If serviceThread.IsAlive Then
                serviceClass.StopService()
                serviceThread.Join()
            End If
            serviceThread = Nothing
            serviceClass = Nothing
        End If
    End Sub

End Class
