﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FXIFTester
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cbURL = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbCmpCode = New System.Windows.Forms.TextBox()
        Me.tbResponse = New System.Windows.Forms.TextBox()
        Me.btnCreateAccount = New System.Windows.Forms.Button()
        Me.btnUpdateAccount = New System.Windows.Forms.Button()
        Me.btnCreateLoginToken = New System.Windows.Forms.Button()
        Me.btnVerifyLoginToken = New System.Windows.Forms.Button()
        Me.btnGetAccountBalance = New System.Windows.Forms.Button()
        Me.btnDepositToAccount = New System.Windows.Forms.Button()
        Me.btnWithdrawFromAccount = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbLoginToken = New System.Windows.Forms.TextBox()
        Me.tbMoney = New System.Windows.Forms.TextBox()
        Me.chkNext = New System.Windows.Forms.CheckBox()
        Me.tbCurCode = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.chkUK = New System.Windows.Forms.CheckBox()
        Me.tbLossLimit = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.chkReg = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.tbRegCnt = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'cbURL
        '
        Me.cbURL.FormattingEnabled = True
        Me.cbURL.Items.AddRange(New Object() {"", "http://localhost:59002/FXIF2/", "http://192.168.0.161/FXIF2/", "http://192.168.0.162/FXIF2/", "http://fate-i.ddo.jp/FXIF2/", "http://fate-i.ddo.jp/FXIFNext/", "http://fate-i.ddo.jp/FXIFV3/"})
        Me.cbURL.Location = New System.Drawing.Point(68, 9)
        Me.cbURL.Name = "cbURL"
        Me.cbURL.Size = New System.Drawing.Size(501, 20)
        Me.cbURL.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "URL"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "委託者口座番号"
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(108, 42)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(83, 19)
        Me.tbCustCode.TabIndex = 3
        Me.tbCustCode.Text = "1000050"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(209, 45)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "会社コード"
        '
        'tbCmpCode
        '
        Me.tbCmpCode.Location = New System.Drawing.Point(271, 42)
        Me.tbCmpCode.Name = "tbCmpCode"
        Me.tbCmpCode.Size = New System.Drawing.Size(36, 19)
        Me.tbCmpCode.TabIndex = 5
        Me.tbCmpCode.Text = "0001"
        '
        'tbResponse
        '
        Me.tbResponse.Location = New System.Drawing.Point(15, 226)
        Me.tbResponse.Multiline = True
        Me.tbResponse.Name = "tbResponse"
        Me.tbResponse.Size = New System.Drawing.Size(554, 85)
        Me.tbResponse.TabIndex = 17
        '
        'btnCreateAccount
        '
        Me.btnCreateAccount.Location = New System.Drawing.Point(15, 158)
        Me.btnCreateAccount.Name = "btnCreateAccount"
        Me.btnCreateAccount.Size = New System.Drawing.Size(100, 23)
        Me.btnCreateAccount.TabIndex = 10
        Me.btnCreateAccount.Text = "口座登録"
        Me.btnCreateAccount.UseVisualStyleBackColor = True
        '
        'btnUpdateAccount
        '
        Me.btnUpdateAccount.Location = New System.Drawing.Point(15, 187)
        Me.btnUpdateAccount.Name = "btnUpdateAccount"
        Me.btnUpdateAccount.Size = New System.Drawing.Size(100, 23)
        Me.btnUpdateAccount.TabIndex = 11
        Me.btnUpdateAccount.Text = "口座更新"
        Me.btnUpdateAccount.UseVisualStyleBackColor = True
        '
        'btnCreateLoginToken
        '
        Me.btnCreateLoginToken.Location = New System.Drawing.Point(133, 158)
        Me.btnCreateLoginToken.Name = "btnCreateLoginToken"
        Me.btnCreateLoginToken.Size = New System.Drawing.Size(100, 23)
        Me.btnCreateLoginToken.TabIndex = 12
        Me.btnCreateLoginToken.Text = "認証キー作成"
        Me.btnCreateLoginToken.UseVisualStyleBackColor = True
        '
        'btnVerifyLoginToken
        '
        Me.btnVerifyLoginToken.Location = New System.Drawing.Point(133, 187)
        Me.btnVerifyLoginToken.Name = "btnVerifyLoginToken"
        Me.btnVerifyLoginToken.Size = New System.Drawing.Size(100, 23)
        Me.btnVerifyLoginToken.TabIndex = 13
        Me.btnVerifyLoginToken.Text = "認証キー検証"
        Me.btnVerifyLoginToken.UseVisualStyleBackColor = True
        '
        'btnGetAccountBalance
        '
        Me.btnGetAccountBalance.Location = New System.Drawing.Point(252, 158)
        Me.btnGetAccountBalance.Name = "btnGetAccountBalance"
        Me.btnGetAccountBalance.Size = New System.Drawing.Size(100, 23)
        Me.btnGetAccountBalance.TabIndex = 14
        Me.btnGetAccountBalance.Text = "残高取得"
        Me.btnGetAccountBalance.UseVisualStyleBackColor = True
        '
        'btnDepositToAccount
        '
        Me.btnDepositToAccount.Location = New System.Drawing.Point(369, 158)
        Me.btnDepositToAccount.Name = "btnDepositToAccount"
        Me.btnDepositToAccount.Size = New System.Drawing.Size(100, 23)
        Me.btnDepositToAccount.TabIndex = 15
        Me.btnDepositToAccount.Text = "入金"
        Me.btnDepositToAccount.UseVisualStyleBackColor = True
        '
        'btnWithdrawFromAccount
        '
        Me.btnWithdrawFromAccount.Location = New System.Drawing.Point(369, 187)
        Me.btnWithdrawFromAccount.Name = "btnWithdrawFromAccount"
        Me.btnWithdrawFromAccount.Size = New System.Drawing.Size(100, 23)
        Me.btnWithdrawFromAccount.TabIndex = 16
        Me.btnWithdrawFromAccount.Text = "出金"
        Me.btnWithdrawFromAccount.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 103)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "認証キー"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 129)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 12)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "入出金金額"
        '
        'tbLoginToken
        '
        Me.tbLoginToken.Location = New System.Drawing.Point(108, 100)
        Me.tbLoginToken.Name = "tbLoginToken"
        Me.tbLoginToken.Size = New System.Drawing.Size(461, 19)
        Me.tbLoginToken.TabIndex = 7
        '
        'tbMoney
        '
        Me.tbMoney.Location = New System.Drawing.Point(108, 126)
        Me.tbMoney.Name = "tbMoney"
        Me.tbMoney.Size = New System.Drawing.Size(100, 19)
        Me.tbMoney.TabIndex = 9
        Me.tbMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkNext
        '
        Me.chkNext.AutoSize = True
        Me.chkNext.Checked = True
        Me.chkNext.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNext.Location = New System.Drawing.Point(441, 44)
        Me.chkNext.Name = "chkNext"
        Me.chkNext.Size = New System.Drawing.Size(72, 16)
        Me.chkNext.TabIndex = 18
        Me.chkNext.Text = "次期環境"
        Me.chkNext.UseVisualStyleBackColor = True
        '
        'tbCurCode
        '
        Me.tbCurCode.Location = New System.Drawing.Point(387, 42)
        Me.tbCurCode.Name = "tbCurCode"
        Me.tbCurCode.Size = New System.Drawing.Size(36, 19)
        Me.tbCurCode.TabIndex = 20
        Me.tbCurCode.Text = "JPY"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(325, 45)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 12)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "通貨コード"
        '
        'chkUK
        '
        Me.chkUK.AutoSize = True
        Me.chkUK.Location = New System.Drawing.Point(519, 44)
        Me.chkUK.Name = "chkUK"
        Me.chkUK.Size = New System.Drawing.Size(39, 16)
        Me.chkUK.TabIndex = 21
        Me.chkUK.Text = "UK"
        Me.chkUK.UseVisualStyleBackColor = True
        '
        'tbLossLimit
        '
        Me.tbLossLimit.Location = New System.Drawing.Point(323, 126)
        Me.tbLossLimit.Name = "tbLossLimit"
        Me.tbLossLimit.Size = New System.Drawing.Size(100, 19)
        Me.tbLossLimit.TabIndex = 23
        Me.tbLossLimit.Text = "1000000"
        Me.tbLossLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(227, 129)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 12)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "損失限度枠"
        '
        'chkReg
        '
        Me.chkReg.AutoSize = True
        Me.chkReg.Location = New System.Drawing.Point(108, 70)
        Me.chkReg.Name = "chkReg"
        Me.chkReg.Size = New System.Drawing.Size(96, 16)
        Me.chkReg.TabIndex = 24
        Me.chkReg.Text = "連番複数登録"
        Me.chkReg.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Enabled = False
        Me.Label8.Location = New System.Drawing.Point(218, 70)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 12)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "登録数"
        '
        'tbRegCnt
        '
        Me.tbRegCnt.Enabled = False
        Me.tbRegCnt.Location = New System.Drawing.Point(271, 67)
        Me.tbRegCnt.Name = "tbRegCnt"
        Me.tbRegCnt.Size = New System.Drawing.Size(36, 19)
        Me.tbRegCnt.TabIndex = 26
        '
        'FXIFTester
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 372)
        Me.Controls.Add(Me.tbRegCnt)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.chkReg)
        Me.Controls.Add(Me.tbLossLimit)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.chkUK)
        Me.Controls.Add(Me.tbCurCode)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.chkNext)
        Me.Controls.Add(Me.tbMoney)
        Me.Controls.Add(Me.tbLoginToken)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnWithdrawFromAccount)
        Me.Controls.Add(Me.btnDepositToAccount)
        Me.Controls.Add(Me.btnGetAccountBalance)
        Me.Controls.Add(Me.btnVerifyLoginToken)
        Me.Controls.Add(Me.btnCreateLoginToken)
        Me.Controls.Add(Me.btnUpdateAccount)
        Me.Controls.Add(Me.btnCreateAccount)
        Me.Controls.Add(Me.tbResponse)
        Me.Controls.Add(Me.tbCmpCode)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbCustCode)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbURL)
        Me.Name = "FXIFTester"
        Me.Text = "FXIF Tester"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cbURL As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbCustCode As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbCmpCode As System.Windows.Forms.TextBox
    Friend WithEvents tbResponse As System.Windows.Forms.TextBox
    Friend WithEvents btnCreateAccount As System.Windows.Forms.Button
    Friend WithEvents btnUpdateAccount As System.Windows.Forms.Button
    Friend WithEvents btnCreateLoginToken As System.Windows.Forms.Button
    Friend WithEvents btnVerifyLoginToken As System.Windows.Forms.Button
    Friend WithEvents btnGetAccountBalance As System.Windows.Forms.Button
    Friend WithEvents btnDepositToAccount As System.Windows.Forms.Button
    Friend WithEvents btnWithdrawFromAccount As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tbLoginToken As System.Windows.Forms.TextBox
    Friend WithEvents tbMoney As System.Windows.Forms.TextBox
    Friend WithEvents chkNext As System.Windows.Forms.CheckBox
    Friend WithEvents tbCurCode As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents chkUK As System.Windows.Forms.CheckBox
    Friend WithEvents tbLossLimit As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkReg As System.Windows.Forms.CheckBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tbRegCnt As System.Windows.Forms.TextBox

End Class
