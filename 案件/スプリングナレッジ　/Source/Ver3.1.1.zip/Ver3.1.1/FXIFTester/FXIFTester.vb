﻿Imports System.Net
Imports System.Collections.Specialized
Imports System.Text
Imports System.Security.Cryptography

Public Class FXIFTester

    Private Sub FXIFTester_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        cbURL.Text = My.Settings.URL
        'cbURL.Text = My.Settings.tURL
    End Sub

    Private Sub Request(PageAddress As String, ValueList As NameValueCollection, QueryList As List(Of KeyValuePair(Of String, String)))
        Dim QueryString As New StringBuilder
        Dim Delimiter As String = ""
        For Each item As KeyValuePair(Of String, String) In QueryList
            If Not item.Value Is Nothing Then
                QueryString.AppendFormat("{0}{1}={2}", Delimiter, item.Key, item.Value)
                Delimiter = "&"
            End If
        Next

        Dim CRCKey As String = My.Settings.CRCKey
        If chkNext.Checked Then
            CRCKey = My.Settings.CRCKeyNext
        End If
        If chkUK.Checked Then
            CRCKey = My.Settings.CRCKeyUK
        End If
        Dim passbin As Byte() = Encoding.UTF8.GetBytes(CRCKey & QueryString.ToString())
        Dim md5 As New MD5CryptoServiceProvider()
        Dim passhash As Byte() = md5.ComputeHash(passbin)
        Dim passstr As String = BitConverter.ToString(passhash).ToUpper().Replace("-", "")
        ValueList.Add("CRC", passstr)

        Dim client As New WebClient
        client.BaseAddress = cbURL.Text
        Dim resdata As Byte() = client.UploadValues(PageAddress, ValueList)
        tbResponse.Text = Encoding.UTF8.GetString(resdata)
    End Sub

    Private Function GetEmail(CmpCode As String, CustCode As String) As String
        Return String.Format("{1}@{0}.qqq", CmpCode, CustCode)
    End Function

    Private Sub SetQueryParam(ValueList As NameValueCollection, QueryList As List(Of KeyValuePair(Of String, String)), Name As String, Value As String)
        ValueList.Add(Name, Value)
        QueryList.Add(New KeyValuePair(Of String, String)(Name, Value))
    End Sub

    Private Sub btnCreateAccount_Click(sender As System.Object, e As System.EventArgs) Handles btnCreateAccount.Click

        Dim CustCode As String = tbCustCode.Text
        Dim Company As String = tbCmpCode.Text
        Dim CurCode As String = tbCurCode.Text
        Dim LossLimit As String = tbLossLimit.Text

        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))

        If Not chkReg.Checked Then
            SetQueryParam(ValueList, QueryList, "username", CustCode)
            SetQueryParam(ValueList, QueryList, "company", Company)
            SetQueryParam(ValueList, QueryList, "traderID", CustCode)
            SetQueryParam(ValueList, QueryList, "currency", CurCode)
            SetQueryParam(ValueList, QueryList, "LossLimit", LossLimit)

            Request("Account/CreateAccount", ValueList, QueryList)
        Else
            If Not tbRegCnt.Text = "" Then
                For i As Integer = 0 To tbRegCnt.Text - 1
                    SetQueryParam(ValueList, QueryList, "username", CustCode)
                    SetQueryParam(ValueList, QueryList, "company", Company)
                    SetQueryParam(ValueList, QueryList, "traderID", CustCode)
                    SetQueryParam(ValueList, QueryList, "currency", CurCode)
                    SetQueryParam(ValueList, QueryList, "LossLimit", LossLimit)

                    Request("Account/CreateAccount", ValueList, QueryList)

                    Dim custIn As Integer = Integer.Parse(CustCode)
                    custIn += 1
                    CustCode = custIn.ToString()

                    ValueList.Clear()
                    QueryList.Clear()

                Next
            Else
                tbResponse.Text = "登録数を入力してください"
            End If
            
        End If
        
    End Sub

    Private Sub btnUpdateAccount_Click(sender As System.Object, e As System.EventArgs) Handles btnUpdateAccount.Click
        Dim CustCode As String = tbCustCode.Text
        Dim Email As String = GetEmail(tbCmpCode.Text, tbCustCode.Text)

        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))
        SetQueryParam(ValueList, QueryList, "username", CustCode)
        SetQueryParam(ValueList, QueryList, "traderID", CustCode)

        Request("Account/UpdateAccount", ValueList, QueryList)
    End Sub

    Private Sub btnCreateLoginToken_Click(sender As System.Object, e As System.EventArgs) Handles btnCreateLoginToken.Click
        Dim CustCode As String = tbCustCode.Text

        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))
        SetQueryParam(ValueList, QueryList, "traderID", CustCode)

        Request("Token/CreateLoginToken", ValueList, QueryList)
    End Sub

    Private Sub btnVerifyLoginToken_Click(sender As System.Object, e As System.EventArgs) Handles btnVerifyLoginToken.Click
        Dim Token As String = tbLoginToken.Text

        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))
        SetQueryParam(ValueList, QueryList, "token", Token)

        Request("Token/VerifyLoginToken", ValueList, QueryList)
    End Sub

    Private Sub btnGetAccountBalance_Click(sender As System.Object, e As System.EventArgs) Handles btnGetAccountBalance.Click
        Dim CustCode As String = tbCustCode.Text

        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))
        SetQueryParam(ValueList, QueryList, "traderID", CustCode)

        Request("Account/GetAccountBalance", ValueList, QueryList)
    End Sub

    Private Sub btnDepositToAccount_Click(sender As System.Object, e As System.EventArgs) Handles btnDepositToAccount.Click

        Dim CustCode As String = tbCustCode.Text
        Dim Amount As String = tbMoney.Text
        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))

        If Not chkReg.Checked Then
            SetQueryParam(ValueList, QueryList, "traderID", CustCode)
            SetQueryParam(ValueList, QueryList, "amount", Amount)

            Request("Account/DepositToAccount", ValueList, QueryList)
        Else
            If Not tbRegCnt.Text = "" Then
                For i As Integer = 0 To tbRegCnt.Text - 1
                    SetQueryParam(ValueList, QueryList, "traderID", CustCode)
                    SetQueryParam(ValueList, QueryList, "amount", Amount)

                    Request("Account/DepositToAccount", ValueList, QueryList)

                    Dim custIn As Integer = Integer.Parse(CustCode)
                    custIn += 1
                    CustCode = custIn.ToString()

                    ValueList.Clear()
                    QueryList.Clear()
                Next
            Else
                tbResponse.Text = "登録数を入力してください"
            End If
        End If

    End Sub

    Private Sub btnWithdrawFromAccount_Click(sender As System.Object, e As System.EventArgs) Handles btnWithdrawFromAccount.Click
        Dim CustCode As String = tbCustCode.Text
        Dim Amount As String = tbMoney.Text

        Dim ValueList As New NameValueCollection
        Dim QueryList As New List(Of KeyValuePair(Of String, String))
        SetQueryParam(ValueList, QueryList, "traderID", CustCode)
        SetQueryParam(ValueList, QueryList, "amount", Amount)

        Request("Account/WithdrawFromAccount", ValueList, QueryList)
    End Sub

    Private Sub chkReg_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkReg.CheckedChanged

        If chkReg.Checked Then
            Label8.Enabled = True
            tbRegCnt.Enabled = True
        Else
            Label8.Enabled = False
            tbRegCnt.Enabled = False
        End If

    End Sub
End Class
