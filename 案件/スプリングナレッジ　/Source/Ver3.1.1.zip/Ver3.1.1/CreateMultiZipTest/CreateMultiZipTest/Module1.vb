﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.IO.Compression
Imports System.Text

Module Module1

    Sub Main()

        Const DB_ACCESS As String = "Server=192.168.53.204;Database=Penguin8;UID=Penguin8;PWD=Penguin8"

        Try
            Using con As New SqlConnection(DB_ACCESS)

                con.Open()

                Using cmd As SqlCommand = con.CreateCommand
                    Dim sql As New StringBuilder

                    sql.AppendLine("select top 5 * from T_RateHist with ( nolock )")
                    sql.AppendLine("where SUBSTRING(RateSeq, 1, 8) = '20180124'")
                    sql.AppendLine("order by RateSeq desc")

                    cmd.CommandText = sql.ToString()

                    Using reader As SqlDataReader = cmd.ExecuteReader()

                        Using fs As New FileStream("test.zip", FileMode.Create)
                            ' メモリアーカイブ上にZipArchiveを作成
                            Using za As ZipArchive = New ZipArchive(fs, ZipArchiveMode.Create)

                                While reader.Read
                                    Dim BufferCSV As New StringBuilder

                                    Dim header As String() = {"RateSeq", "RateTime", "Rate"}
                                    'CSVファイル作成
                                    BufferCSV.Append(CreateCsvHeader(header))
                                    BufferCSV.Append("""" & reader("RateSeq") & """")
                                    BufferCSV.Append("," & """" & reader("RateTime") & """")
                                    BufferCSV.Append("," & """" & reader("Rate") & """")
                                    BufferCSV.Append(vbCrLf)

                                    'バイナリに変換
                                    Dim outByte() As Byte
                                    outByte = Encoding.UTF8.GetBytes(BufferCSV.ToString())

                                    'エントリの作成
                                    Dim entry As ZipArchiveEntry = za.CreateEntry(reader("RateSeq") & ".csv")
                                    Using es As Stream = entry.Open
                                        es.Write(outByte, 0, outByte.Length)
                                    End Using
                                End While

                            End Using

                        End Using

                        'Using ms As New MemoryStream
                        '    ' メモリアーカイブ上にZipArchiveを作成
                        '    Using za As ZipArchive = New ZipArchive(ms, ZipArchiveMode.Create)

                        '        While reader.Read
                        '            Dim BufferCSV As New StringBuilder

                        '            Dim header As String() = {"RateSeq", "RateTime", "Rate"}
                        '            'CSVファイル作成
                        '            BufferCSV.Append(CreateCsvHeader(header))
                        '            BufferCSV.Append("""" & reader("RateSeq") & """")
                        '            BufferCSV.Append("," & """" & reader("RateTime") & """")
                        '            BufferCSV.Append("," & """" & reader("Rate") & """")
                        '            BufferCSV.Append(vbCrLf)

                        '            'バイナリに変換
                        '            Dim outByte() As Byte
                        '            outByte = Encoding.UTF8.GetBytes(BufferCSV.ToString())

                        '            'エントリの作成
                        '            Dim entry As ZipArchiveEntry = za.CreateEntry(reader("RateSeq") & ".csv")
                        '            Using es As Stream = entry.Open
                        '                es.Write(outByte, 0, outByte.Length)
                        '            End Using
                        '        End While

                        '    End Using

                        '    ' メモリ上に作成したデータをzipファイルに保存
                        '    Using StreamFile As New FileStream("test.zip", FileMode.Create)
                        '        Using StreamZIP As New BinaryWriter(StreamFile)
                        '            StreamZIP.Write(ms.ToArray())
                        '        End Using
                        '    End Using

                        'End Using

                    End Using

                End Using

            End Using
        Catch ex As Exception
            Debug.Write(vbCrLf & ex.Message)
            Debug.Write(vbCrLf & ex.StackTrace)
        End Try

    End Sub

    Private Function CreateCsvHeader(ByVal calm As String()) As String
        Dim Result As New StringBuilder

        Dim init As Boolean = False
        For Each head In calm
            If init = False Then
                Result.Append("""" & head & """")
                init = True
            Else
                Result.Append("," & """" & head & """")
            End If

        Next
        Result.Append(vbCrLf)

        Return Result.ToString
    End Function

End Module
