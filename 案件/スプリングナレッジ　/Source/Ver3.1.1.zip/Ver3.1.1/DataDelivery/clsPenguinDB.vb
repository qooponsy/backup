﻿Imports System.IO
Imports System.Text
Imports System.Data.SqlClient

Public Class clsPenguinDB
	Private ConnDB As SqlConnection
	Private strError As String
	Private blnError As Boolean

	'--------------------------------------------------------------------------
	' ＤＢ接続
	'--------------------------------------------------------------------------
	Public Function GetSqlConnection(ByVal sConnectString As String) As Boolean
		Dim Result As Boolean

		strError = ""
		blnError = False
		Result = True
		Try
			ConnDB = New SqlConnection(sConnectString)
			ConnDB.Open()
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)

			strError = "GetSqlConnection," & ex.Message
			ConnDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ切断
	'--------------------------------------------------------------------------
	Public Function EndSqlConnection() As Boolean
		Dim Result As Boolean

		Result = True
		Try
			ConnDB.Close()
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "EndSqlConnection," & ex.Message
			Result = False
		End Try
		ConnDB = Nothing
		blnError = False

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' ＤＢエラー有無判定
	'--------------------------------------------------------------------------
	Public Function IsError() As Boolean
		Return blnError
	End Function

	'--------------------------------------------------------------------------
	' ＤＢエラーメッセージの取得＆エラーフラグクリア
	'--------------------------------------------------------------------------
	Public Function GetErrorMessage() As String
		Dim sErrMsg As String

		blnError = False
		sErrMsg = "DataBase Error:" & strError
		Return sErrMsg

	End Function

	'--------------------------------------------------------------------------
	' 営業日のチェック（曜日、祝祭日の考慮）
	'--------------------------------------------------------------------------
	Public Function CheckWorkDay(ByVal WorkDate As DateTime) As Boolean
		Dim CmdDB As SqlCommand
		Dim Result As Boolean = False
		Dim strSQL As New StringBuilder

		Result = False
		Try
			strSQL.AppendLine("declare @work char(1)")
			strSQL.AppendLine("declare @holiday date")
			strSQL.AppendLine("select @work = [Work] from [M_Weekday] where [WeekDay] = DATEPART(weekday, @workdate)")
			strSQL.AppendLine("if @work = '1'")
			strSQL.AppendLine("begin")
			strSQL.AppendLine("    select @holiday = [Holiday] from [M_Holiday] where [Holiday] = @workdate")
			strSQL.AppendLine("    if @@ROWCOUNT <> 0")
			strSQL.AppendLine("        set @work = '0'")
			strSQL.AppendLine("end")
			strSQL.AppendLine("select @work")
			CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text
			CmdDB.Parameters.Add("@workdate", SqlDbType.Date).Value = WorkDate
			CmdDB.Prepare()
			Dim work As String = CmdDB.ExecuteScalar()
			CmdDB = Nothing
			If work = "1" Then
				Result = True
			End If
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "CheckWorkDay," & ex.Message
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' 次営業日の取得（曜日、祝祭日の考慮）
	'--------------------------------------------------------------------------
	Public Function GetNextDate(ByVal WorkDate As DateTime) As DateTime
		Dim CmdDB As SqlCommand
		Dim Result As DateTime
		Dim strSQL As New StringBuilder

		Try
			strSQL.AppendLine("declare @work char(1)")
			strSQL.AppendLine("declare @holiday date")
			strSQL.AppendLine("while 1=1")
			strSQL.AppendLine("begin")
			strSQL.AppendLine("    select @work = [Work] from [M_Weekday] where [WeekDay] = DATEPART(weekday, @workdate)")
			strSQL.AppendLine("    if @work = '1'")
			strSQL.AppendLine("    begin")
			strSQL.AppendLine("        select @holiday = [Holiday] from [M_Holiday] where [Holiday] = @workdate")
			strSQL.AppendLine("        if @@ROWCOUNT = 0")
			strSQL.AppendLine("            break")
			strSQL.AppendLine("    end")
			strSQL.AppendLine("    set @workdate = DATEADD(day, 1, @workdate)")
			strSQL.AppendLine("end")
			strSQL.AppendLine("select @workdate")
			CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text
			CmdDB.Parameters.Add("@workdate", SqlDbType.Date).Value = WorkDate
			CmdDB.Prepare()
			Result = CmdDB.ExecuteScalar()
			CmdDB = Nothing
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetNextDate," & ex.Message
			CmdDB = Nothing
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ項目取得（文字列）
	'--------------------------------------------------------------------------
	Public Function GetDbString(ByVal obj As Object) As String
		Dim RetVal As String

		If IsDBNull(obj) Then
			RetVal = [String].Empty
		Else
			RetVal = CStr(obj)
		End If

		Return RetVal
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ項目取得（日付文字列）
	'--------------------------------------------------------------------------
	Public Function GetDbDate(ByVal obj As Object) As String
		Dim RetVal As String

		If IsDBNull(obj) Then
			RetVal = [String].Empty
		Else
			RetVal = Format(CDate(obj), "yyyy/MM/dd")
		End If

		Return RetVal
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ項目取得（日時文字列）
	'--------------------------------------------------------------------------
	Public Function GetDbDateTime(ByVal obj As Object) As String
		Dim RetVal As String

		If IsDBNull(obj) Then
			RetVal = [String].Empty
		Else
			RetVal = Format(CDate(obj), "yyyy/MM/dd HH:mm:ss.fff")
		End If

		Return RetVal
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ項目取得（Ｉｎｔ）
	'--------------------------------------------------------------------------
	Public Function GetDbInt(ByVal obj As Object) As Integer
		Dim RetVal As Integer

		If IsDBNull(obj) Then
			RetVal = 0
		Else
			RetVal = CInt(obj)
		End If

		Return RetVal
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ項目取得（Ｄｅｃｉｍａｌ）
	'--------------------------------------------------------------------------
	Public Function GetDbDec(ByVal obj As Object) As Decimal
		Dim RetVal As Decimal

		If IsDBNull(obj) Then
			RetVal = 0
		Else
			RetVal = CDec(obj)
		End If

		Return RetVal
	End Function

	'--------------------------------------------------------------------------
	' ＤＢ項目取得（Ｒａｔｅ：Ｄｅｃｉｍａｌ）
	'--------------------------------------------------------------------------
	Public Function GetDbRate(ByVal obj As Object) As Decimal
		Dim RetVal As Decimal
		Dim sDec As String

		If IsDBNull(obj) Then
			RetVal = 0
		Else
			sDec = Format(CDec(obj), "######0.00000000")
			RetVal = CDec(sDec)
		End If

		Return RetVal
	End Function

    '--------------------------------------------------------------------------
    ' ＤＢ項目取得（ＣａｌｃＶａｌｕｅ：Ｄｅｃｉｍａｌ）
    '--------------------------------------------------------------------------
    Public Function GetDbCalcValue(ByVal obj As Object) As Decimal
        Dim RetVal As Decimal
        Dim sDec As String

        If IsDBNull(obj) Then
            RetVal = 0
        Else
            sDec = Format(CDec(obj), "0.0#############")
            RetVal = CDec(sDec)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ項目取得（ＴｉｍｅＳｐａｎ）
    '--------------------------------------------------------------------------
	Public Function GetDbTime(ByVal obj As Object) As TimeSpan
		Dim RetVal As TimeSpan

		If IsDBNull(obj) Then
			RetVal = New TimeSpan(0, 0, 0)
		Else
			RetVal = obj
		End If

		Return RetVal
	End Function

	'--------------------------------------------------------------------------
	' ＤＢサーバーシステム日付取得
	'--------------------------------------------------------------------------
	Public Function GetServerDateTime(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable
			ListData.Columns.Add(New DataColumn("ServerDateTime"))

			SQL = New StringBuilder
            SQL.AppendLine("select SYSUTCDATETIME() as ServerDateTime")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("ServerDateTime") = GetDbDateTime(Reader.Item("ServerDateTime"))
				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetServerDateTime," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' 配信サービス接続先リストの取得
	'--------------------------------------------------------------------------
	Public Function GetDeliveryList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable
			ListData.Columns.Add(New DataColumn("ServerIP"))
			ListData.Columns.Add(New DataColumn("ServerPort"))
			ListData.Columns.Add(New DataColumn("Comment"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" D.[ServerIP] [ServerIP],")
			SQL.AppendLine(" D.[ServerPort] [ServerPort],")
			SQL.AppendLine(" D.[Comment] [Comment]")
			SQL.AppendLine(" from [S_DeliveryServer] D")
			SQL.AppendLine(" order by D.[ServerIP],D.[ServerPort]")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("ServerIP") = GetDbString(Reader.Item("ServerIP"))
				ListRow.Item("ServerPort") = GetDbInt(Reader.Item("ServerPort"))
				ListRow.Item("Comment") = GetDbString(Reader.Item("Comment"))
				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetDeliveryList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' セッションデータの取得
	'--------------------------------------------------------------------------
	Public Function GetSessionList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable
			ListData.Columns.Add(New DataColumn("DeliveryType"))
			ListData.Columns.Add(New DataColumn("SessionKey"))
			ListData.Columns.Add(New DataColumn("AuthType"))
			ListData.Columns.Add(New DataColumn("UserID"))
			ListData.Columns.Add(New DataColumn("ClientType"))
			ListData.Columns.Add(New DataColumn("ClientVersion"))
			ListData.Columns.Add(New DataColumn("LastCheckTime"))
            ListData.Columns.Add(New DataColumn("PrivateDataSeq"))
            ListData.Columns.Add(New DataColumn("TimeMode"))
            ListData.Columns.Add(New DataColumn("LangCode"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" S.[SessionKey] [SessionKey],")
			SQL.AppendLine(" S.[AuthType] [AuthType],")
			SQL.AppendLine(" S.[UserID] [UserID],")
			SQL.AppendLine(" S.[ClientType] [ClientType],")
			SQL.AppendLine(" S.[ClientVersion] [ClientVersion],")
			SQL.AppendLine(" S.[LastCheckTime] [LastCheckTime],")
            SQL.AppendLine(" S.[PrivateDataSeq] [PrivateDataSeq],")
            SQL.AppendLine(" S.[TimeMode] [TimeMode],")
            SQL.AppendLine(" S.[LangCode] [LangCode]")
            SQL.AppendLine(" from [S_Session] S with (nolock)")
			SQL.AppendLine(" order by S.[SessionKey]")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("DeliveryType") = "I"		' 差分データとフォーマット統一の為のダミー項目
				ListRow.Item("SessionKey") = GetDbString(Reader.Item("SessionKey"))
				ListRow.Item("AuthType") = GetDbString(Reader.Item("AuthType"))
				ListRow.Item("UserID") = GetDbString(Reader.Item("UserID"))
				ListRow.Item("ClientType") = GetDbString(Reader.Item("ClientType"))
				ListRow.Item("ClientVersion") = GetDbString(Reader.Item("ClientVersion"))
				ListRow.Item("LastCheckTime") = GetDbDateTime(Reader.Item("LastCheckTime"))
                ListRow.Item("PrivateDataSeq") = GetDbInt(Reader.Item("PrivateDataSeq"))
                ListRow.Item("TimeMode") = GetDbString(Reader.Item("TimeMode"))
                ListRow.Item("LangCode") = GetDbString(Reader.Item("LangCode"))

				' 差分の高負荷デバッグ Start
				'ListRow.Item("PrivateDataSeq") = (Now.Second * 100) + Now.Millisecond
				' 差分の高負荷デバッグ End

				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetSessionList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' 銘柄情報取得
	'--------------------------------------------------------------------------
	Public Function GetProductList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable

			ListData.Columns.Add(New DataColumn("DeliveryType"))
			ListData.Columns.Add(New DataColumn("ProductCode"))
			ListData.Columns.Add(New DataColumn("Enabled"))
			ListData.Columns.Add(New DataColumn("ProductBaseCode"))
			ListData.Columns.Add(New DataColumn("SysDate"))
			ListData.Columns.Add(New DataColumn("ComCode"))
			ListData.Columns.Add(New DataColumn("OpType"))
			ListData.Columns.Add(New DataColumn("StartTime"))
			ListData.Columns.Add(New DataColumn("ExercTime"))
			ListData.Columns.Add(New DataColumn("TradeLimitTime"))
			ListData.Columns.Add(New DataColumn("PayoutRate"))
			ListData.Columns.Add(New DataColumn("ExercStatus"))
			ListData.Columns.Add(New DataColumn("ExercRateSeq"))
			ListData.Columns.Add(New DataColumn("ExercRate"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" P.[ProductCode] [ProductCode],")
			SQL.AppendLine(" P.[Enabled] [Enabled],")
			SQL.AppendLine(" P.[ProductBaseCode] [ProductBaseCode],")
			SQL.AppendLine(" P.[SysDate] [SysDate],")
			SQL.AppendLine(" P.[ComCode] [ComCode],")
			SQL.AppendLine(" P.[OpType] [OpType],")
			SQL.AppendLine(" P.[StartTime] [StartTime],")
			SQL.AppendLine(" P.[ExercTime] [ExercTime],")
			SQL.AppendLine(" P.[TradeLimitTime] [TradeLimitTime],")
			SQL.AppendLine(" P.[PayoutRate] [PayoutRate],")
			SQL.AppendLine(" P.[ExercStatus] [ExercStatus],")
			SQL.AppendLine(" P.[ExercRateSeq] [ExercRateSeq],")
			SQL.AppendLine(" P.[ExercRate] [ExercRate]")
            SQL.AppendLine(" from [M_Product] P with (nolock)")
			SQL.AppendLine(" where P.[ExercStatus]='0' And P.[Enabled]='1'")
			SQL.AppendLine(" order by P.[ProductCode]")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("DeliveryType") = "I"		' 差分データとフォーマット統一の為のダミー項目
				ListRow.Item("ProductCode") = GetDbString(Reader.Item("ProductCode"))
				ListRow.Item("Enabled") = GetDbString(Reader.Item("Enabled"))
				ListRow.Item("ProductBaseCode") = GetDbString(Reader.Item("ProductBaseCode"))
				ListRow.Item("SysDate") = GetDbDate(Reader.Item("SysDate"))
				ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
				ListRow.Item("OpType") = GetDbString(Reader.Item("OpType"))
				ListRow.Item("StartTime") = GetDbDateTime(Reader.Item("StartTime"))
				ListRow.Item("ExercTime") = GetDbDateTime(Reader.Item("ExercTime"))
				ListRow.Item("TradeLimitTime") = GetDbDateTime(Reader.Item("TradeLimitTime"))
				ListRow.Item("PayoutRate") = GetDbDec(Reader.Item("PayoutRate"))
				ListRow.Item("ExercStatus") = GetDbString(Reader.Item("ExercStatus"))
				ListRow.Item("ExercRateSeq") = GetDbString(Reader.Item("ExercRateSeq"))
				ListRow.Item("ExercRate") = GetDbDec(Reader.Item("ExercRate"))
				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetProductList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' 銘柄基本情報取得
	'--------------------------------------------------------------------------
	Public Function GetProductBaseList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable

			ListData.Columns.Add(New DataColumn("DeliveryType"))
			ListData.Columns.Add(New DataColumn("ProductBaseCode"))
			ListData.Columns.Add(New DataColumn("Enabled"))
			ListData.Columns.Add(New DataColumn("ComCode"))
			ListData.Columns.Add(New DataColumn("OpType"))
			ListData.Columns.Add(New DataColumn("OptionTime"))
			ListData.Columns.Add(New DataColumn("CreateTime"))
			ListData.Columns.Add(New DataColumn("StartTime"))
			ListData.Columns.Add(New DataColumn("ExercTime"))
			ListData.Columns.Add(New DataColumn("PayoutRate"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" P.[ProductBaseCode] [ProductBaseCode],")
			SQL.AppendLine(" P.[Enabled] [Enabled],")
			SQL.AppendLine(" P.[ComCode] [ComCode],")
			SQL.AppendLine(" P.[OpType] [OpType],")
			SQL.AppendLine(" P.[OptionTime] [OptionTime],")
			SQL.AppendLine(" P.[CreateTime] [CreateTime],")
			SQL.AppendLine(" P.[StartTime] [StartTime],")
			SQL.AppendLine(" P.[ExercTime] [ExercTime],")
			SQL.AppendLine(" P.[PayoutRate] [PayoutRate]")
            SQL.AppendLine(" from [M_ProductBase] P with (nolock)")
			SQL.AppendLine(" where P.[Enabled] = '1'")
			SQL.AppendLine(" order by P.[ProductBaseCode]")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("DeliveryType") = "I"		' フォーマット統一の為のダミー項目
				ListRow.Item("ProductBaseCode") = GetDbString(Reader.Item("ProductBaseCode"))
				ListRow.Item("Enabled") = GetDbString(Reader.Item("Enabled"))
				ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
				ListRow.Item("OpType") = GetDbString(Reader.Item("OpType"))
				ListRow.Item("OptionTime") = GetDbInt(Reader.Item("OptionTime"))
				ListRow.Item("CreateTime") = GetDbInt(Reader.Item("CreateTime"))
				ListRow.Item("StartTime") = GetDbTime(Reader.Item("StartTime"))
				ListRow.Item("ExercTime") = GetDbTime(Reader.Item("ExercTime"))
				ListRow.Item("PayoutRate") = GetDbDec(Reader.Item("PayoutRate"))
				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetProductBaseList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' システム設定取得
	'--------------------------------------------------------------------------
	Public Function GetSysSettingsList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable

			ListData.Columns.Add(New DataColumn("DeliveryType"))
			ListData.Columns.Add(New DataColumn("StopTradeTime"))
			ListData.Columns.Add(New DataColumn("StartAbandTime"))
			ListData.Columns.Add(New DataColumn("AbandPriceDiff"))
			ListData.Columns.Add(New DataColumn("Commission"))
			ListData.Columns.Add(New DataColumn("AbandMargine"))
			ListData.Columns.Add(New DataColumn("TradeMoneyMin"))
            ListData.Columns.Add(New DataColumn("TradeLotMin"))
            ListData.Columns.Add(New DataColumn("TradeMoneyMax"))
            ListData.Columns.Add(New DataColumn("TradeLotMax"))
            ListData.Columns.Add(New DataColumn("ProductMoneyMax"))
            ListData.Columns.Add(New DataColumn("ProductLotMax"))
            ListData.Columns.Add(New DataColumn("CustCountMax"))
			ListData.Columns.Add(New DataColumn("CustMoneyMax"))
            ListData.Columns.Add(New DataColumn("CustLotMax"))
            ListData.Columns.Add(New DataColumn("CustProductMoneyMax"))
            ListData.Columns.Add(New DataColumn("CustProductLotMax"))
            ListData.Columns.Add(New DataColumn("CashInMoneyMin"))
			ListData.Columns.Add(New DataColumn("CashInMoneyDayMin"))
			ListData.Columns.Add(New DataColumn("CashOutMoneyMax"))
			ListData.Columns.Add(New DataColumn("CashOutMoneyDayMax"))
			ListData.Columns.Add(New DataColumn("ProductStartPreTime"))
			ListData.Columns.Add(New DataColumn("ProductEndLossTime"))
			ListData.Columns.Add(New DataColumn("RateEnableTime"))
            ListData.Columns.Add(New DataColumn("TimeZone"))
            ListData.Columns.Add(New DataColumn("SysDateTimeZone"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" S.[StopTradeTime] [StopTradeTime],")
			SQL.AppendLine(" S.[StartAbandTime] [StartAbandTime],")
			SQL.AppendLine(" S.[AbandPriceDiff] [AbandPriceDiff],")
			SQL.AppendLine(" S.[Commission] [Commission],")
			SQL.AppendLine(" S.[AbandMargine] [AbandMargine],")
			SQL.AppendLine(" S.[TradeMoneyMin] [TradeMoneyMin],")
            SQL.AppendLine(" S.[TradeLotMin] [TradeLotMin],")
            SQL.AppendLine(" S.[TradeMoneyMax] [TradeMoneyMax],")
            SQL.AppendLine(" S.[TradeLotMax] [TradeLotMax],")
            SQL.AppendLine(" S.[ProductMoneyMax] [ProductMoneyMax],")
            SQL.AppendLine(" S.[ProductLotMax] [ProductLotMax],")
            SQL.AppendLine(" S.[CustCountMax] [CustCountMax],")
			SQL.AppendLine(" S.[CustMoneyMax] [CustMoneyMax],")
            SQL.AppendLine(" S.[CustLotMax] [CustLotMax],")
            SQL.AppendLine(" S.[CustProductMoneyMax] [CustProductMoneyMax],")
            SQL.AppendLine(" S.[CustProductLotMax] [CustProductLotMax],")
            SQL.AppendLine(" S.[CashInMoneyMin] [CashInMoneyMin],")
			SQL.AppendLine(" S.[CashInMoneyDayMin] [CashInMoneyDayMin],")
			SQL.AppendLine(" S.[CashOutMoneyMax] [CashOutMoneyMax],")
			SQL.AppendLine(" S.[CashOutMoneyDayMax] [CashOutMoneyDayMax],")
			SQL.AppendLine(" S.[ProductStartPreTime] [ProductStartPreTime],")
			SQL.AppendLine(" S.[ProductEndLossTime] [ProductEndLossTime],")
            SQL.AppendLine(" S.[RateEnableTime] [RateEnableTime],")
            SQL.AppendLine(" S.[TimeZone] [TimeZone],")
            SQL.AppendLine(" S.[SysDateTimeZone] [SysDateTimeZone]")
            SQL.AppendLine(" from [M_SysSettings] S with (nolock)")
			SQL.AppendLine(" where S.[SysCode]='0'")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("DeliveryType") = "I"		' フォーマット統一の為のダミー項目
				ListRow.Item("StopTradeTime") = GetDbInt(Reader.Item("StopTradeTime"))
				ListRow.Item("StartAbandTime") = GetDbInt(Reader.Item("StartAbandTime"))
				ListRow.Item("AbandPriceDiff") = GetDbInt(Reader.Item("AbandPriceDiff"))
				ListRow.Item("Commission") = GetDbDec(Reader.Item("Commission"))
				ListRow.Item("AbandMargine") = GetDbDec(Reader.Item("AbandMargine"))
				ListRow.Item("TradeMoneyMin") = GetDbDec(Reader.Item("TradeMoneyMin"))
                ListRow.Item("TradeLotMin") = GetDbDec(Reader.Item("TradeLotMin"))
                ListRow.Item("TradeMoneyMax") = GetDbDec(Reader.Item("TradeMoneyMax"))
                ListRow.Item("TradeLotMax") = GetDbDec(Reader.Item("TradeLotMax"))
                ListRow.Item("TradeMoneyMax") = GetDbDec(Reader.Item("TradeMoneyMax"))
                ListRow.Item("TradeLotMax") = GetDbDec(Reader.Item("TradeLotMax"))
                ListRow.Item("ProductMoneyMax") = GetDbDec(Reader.Item("ProductMoneyMax"))
                ListRow.Item("ProductLotMax") = GetDbDec(Reader.Item("ProductLotMax"))
                ListRow.Item("CustCountMax") = GetDbInt(Reader.Item("CustCountMax"))
				ListRow.Item("CustMoneyMax") = GetDbDec(Reader.Item("CustMoneyMax"))
                ListRow.Item("CustLotMax") = GetDbDec(Reader.Item("CustLotMax"))
                ListRow.Item("CustProductMoneyMax") = GetDbDec(Reader.Item("CustProductMoneyMax"))
                ListRow.Item("CustProductLotMax") = GetDbDec(Reader.Item("CustProductLotMax"))
                ListRow.Item("CashInMoneyMin") = GetDbDec(Reader.Item("CashInMoneyMin"))
				ListRow.Item("CashInMoneyDayMin") = GetDbDec(Reader.Item("CashInMoneyDayMin"))
				ListRow.Item("CashOutMoneyMax") = GetDbDec(Reader.Item("CashOutMoneyMax"))
				ListRow.Item("CashOutMoneyDayMax") = GetDbDec(Reader.Item("CashOutMoneyDayMax"))
				ListRow.Item("ProductStartPreTime") = GetDbInt(Reader.Item("ProductStartPreTime"))
				ListRow.Item("ProductEndLossTime") = GetDbInt(Reader.Item("ProductEndLossTime"))
				ListRow.Item("RateEnableTime") = GetDbInt(Reader.Item("RateEnableTime"))
                ListRow.Item("TimeZone") = GetDbInt(Reader.Item("TimeZone"))
                ListRow.Item("SysDateTimeZone") = GetDbInt(Reader.Item("SysDateTimeZone"))
                ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetSysSettingsList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' システムステータス取得
	'--------------------------------------------------------------------------
	Public Function GetSysStatusList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable

			ListData.Columns.Add(New DataColumn("DeliveryType"))
			ListData.Columns.Add(New DataColumn("SysDate"))
			ListData.Columns.Add(New DataColumn("SysEnabled"))
			ListData.Columns.Add(New DataColumn("AbandEnabled"))
			ListData.Columns.Add(New DataColumn("CashOutEnabled"))
			ListData.Columns.Add(New DataColumn("CashInEnabled"))
			ListData.Columns.Add(New DataColumn("RateProviderID"))
			ListData.Columns.Add(New DataColumn("SysUpdateSeq"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" S.[SysDate] [SysDate],")
			SQL.AppendLine(" S.[SysEnabled] [SysEnabled],")
			SQL.AppendLine(" S.[AbandEnabled] [AbandEnabled],")
			SQL.AppendLine(" S.[CashOutEnabled] [CashOutEnabled],")
			SQL.AppendLine(" S.[CashInEnabled] [CashInEnabled],")
			SQL.AppendLine(" S.[RateProviderID] [RateProviderID],")
			SQL.AppendLine(" S.[SysUpdateSeq] [SysUpdateSeq]")
            SQL.AppendLine(" from [S_SysStatus] S with (nolock)")
			SQL.AppendLine(" where S.[SysCode]='0'")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("DeliveryType") = "I"		' フォーマット統一の為のダミー項目
				ListRow.Item("SysDate") = GetDbDate(Reader.Item("SysDate"))
				ListRow.Item("SysEnabled") = GetDbString(Reader.Item("SysEnabled"))
				ListRow.Item("AbandEnabled") = GetDbString(Reader.Item("AbandEnabled"))
				ListRow.Item("CashOutEnabled") = GetDbString(Reader.Item("CashOutEnabled"))
				ListRow.Item("CashInEnabled") = GetDbString(Reader.Item("CashInEnabled"))
				ListRow.Item("RateProviderID") = GetDbInt(Reader.Item("RateProviderID"))
				ListRow.Item("SysUpdateSeq") = GetDbInt(Reader.Item("SysUpdateSeq"))
				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetSysStatusList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

	'--------------------------------------------------------------------------
	' 計算パラメタ取得
	'--------------------------------------------------------------------------
	Public Function GetCalcParamList(ByRef ListData As DataTable) As Boolean
		Dim CmdDB As SqlCommand
		Dim Reader As SqlDataReader
		Dim Result As Boolean
		Dim ListRow As DataRow
		Dim SQL As StringBuilder

		ListData = Nothing

		Result = True
		Try
			ListData = New DataTable

			ListData.Columns.Add(New DataColumn("DeliveryType"))
			ListData.Columns.Add(New DataColumn("ComCode"))
            ListData.Columns.Add(New DataColumn("InterestRate"))
            ListData.Columns.Add(New DataColumn("SwapRate"))
            ListData.Columns.Add(New DataColumn("VolatilityAdjust"))
			ListData.Columns.Add(New DataColumn("Volatility"))
			ListData.Columns.Add(New DataColumn("DeltaVariation"))
			ListData.Columns.Add(New DataColumn("GammaVariation"))
			ListData.Columns.Add(New DataColumn("VegaVariation"))
			ListData.Columns.Add(New DataColumn("ThetaVariation"))
			ListData.Columns.Add(New DataColumn("RhoVariation"))

			SQL = New StringBuilder
			SQL.AppendLine("select")
			SQL.AppendLine(" P.[ComCode] [ComCode],")
            SQL.AppendLine(" P.[InterestRate] [InterestRate],")
            SQL.AppendLine(" P.[SwapRate] [SwapRate],")
            SQL.AppendLine(" P.[VolatilityAdjust] [VolatilityAdjust],")
			SQL.AppendLine(" P.[Volatility] [Volatility],")
			SQL.AppendLine(" P.[DeltaVariation] [DeltaVariation],")
			SQL.AppendLine(" P.[GammaVariation] [GammaVariation],")
			SQL.AppendLine(" P.[VegaVariation] [VegaVariation],")
			SQL.AppendLine(" P.[ThetaVariation] [ThetaVariation],")
			SQL.AppendLine(" P.[RhoVariation] [RhoVariation]")
            SQL.AppendLine(" from [M_CalcParam] P with (nolock)")
			SQL.AppendLine(" order by P.[ComCode]")
			CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
			CmdDB.CommandTimeout = My.Settings.CommandTimeout
			CmdDB.CommandType = CommandType.Text

			CmdDB.Prepare()
			Reader = CmdDB.ExecuteReader()
			While Reader.Read
				ListRow = ListData.NewRow()
				ListRow.Item("DeliveryType") = "I"		' フォーマット統一の為のダミー項目
				ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                ListRow.Item("InterestRate") = GetDbCalcValue(Reader.Item("InterestRate"))
                ListRow.Item("SwapRate") = GetDbCalcValue(Reader.Item("SwapRate"))
                ListRow.Item("VolatilityAdjust") = GetDbCalcValue(Reader.Item("VolatilityAdjust"))
                ListRow.Item("Volatility") = GetDbCalcValue(Reader.Item("Volatility"))
                ListRow.Item("DeltaVariation") = GetDbCalcValue(Reader.Item("DeltaVariation"))
                ListRow.Item("GammaVariation") = GetDbCalcValue(Reader.Item("GammaVariation"))
                ListRow.Item("VegaVariation") = GetDbCalcValue(Reader.Item("VegaVariation"))
                ListRow.Item("ThetaVariation") = GetDbCalcValue(Reader.Item("ThetaVariation"))
                ListRow.Item("RhoVariation") = GetDbCalcValue(Reader.Item("RhoVariation"))
				ListData.Rows.Add(ListRow)
				ListRow = Nothing
			End While
			Reader.Close()
			Reader = Nothing
			CmdDB = Nothing
			Result = True
			SystemLog.DBSuccess()
		Catch ex As Exception
			SystemLog.DBError(ex)
			strError = "GetCalcParamList," & ex.Message
			Reader = Nothing
			CmdDB = Nothing
			Result = False
			blnError = True
		End Try

		Return Result
	End Function

End Class
