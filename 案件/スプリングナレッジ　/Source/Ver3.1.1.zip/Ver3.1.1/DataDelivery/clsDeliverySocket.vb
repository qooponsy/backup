﻿Imports System.Threading
Imports System.Net
Imports System.Net.Sockets

'--------------------------------------------------------------------------
' データ配信 制御クラス
'--------------------------------------------------------------------------
Public Class clsDeliverySocket
	Private Client As TcpClient
	Private Telegram As clsDeliveryTelegram
	Private strServerIP As String
    Private ipaServerIP As IPAddress = Nothing
    Private intServerPort As Integer
    Private ConnectTimeoutCount As Integer = 0

	'--------------------------------------------------------------------------
	' コンストラクタ
	'--------------------------------------------------------------------------
	Public Sub New()
		Client = Nothing
		Telegram = New clsDeliveryTelegram()
	End Sub

	'--------------------------------------------------------------------------
	' 初期化
	'--------------------------------------------------------------------------
    Public Sub Initialize(ByVal sServerIP As String, ByVal iServerPort As Integer)
        strServerIP = sServerIP
        intServerPort = iServerPort
        Telegram.Initialize()
    End Sub

    Private Function GetIPAddress() As IPAddress
        If ipaServerIP Is Nothing Then
            Dim HostEntry As IPHostEntry = Dns.GetHostEntry(strServerIP)
            For Each Address As IPAddress In HostEntry.AddressList
                If Address.AddressFamily = AddressFamily.InterNetwork Then
                    ipaServerIP = Address
                    SystemLog.Information("IP Address:" & ipaServerIP.ToString())
                    Exit For
                End If
            Next
        End If

        Return ipaServerIP
    End Function

	'--------------------------------------------------------------------------
	' ＴＣＰデータ電文送信
	'--------------------------------------------------------------------------
	Public Function SendTelegram(ByVal Telegram() As Byte) As Boolean
		Dim stream As NetworkStream
		Dim bSend As Boolean

		bSend = False
		Try
			If IsConnect() = True Then
				stream = Client.GetStream()
				stream.Write(Telegram, 0, Telegram.Length())
				bSend = True
			End If
        Catch ex As Exception
            SystemLog.ExceptionError(ex)
        End Try

		Return bSend
	End Function

	'--------------------------------------------------------------------------
	' ＴＣＰデータ電文受信
	'--------------------------------------------------------------------------
	Public Function ReciveTelegram(ByRef sRecv As String) As Boolean
		Dim bRecv As Boolean
		Dim iLen As Integer
		Dim bytRecv() As Byte

		sRecv = ""
		If IsNothing(Client) = True Then
			bRecv = False
		Else
			If Client.Connected = True Then
				iLen = Client.Available
				If iLen > 0 Then
					bytRecv = New Byte(iLen - 1) {}
					iLen = Client.GetStream().Read(bytRecv, 0, bytRecv.Length)
					If iLen > 0 Then
						bRecv = Telegram.AddReceiveTelegram(bytRecv, iLen, sRecv)
					End If
				End If
			End If
		End If

		Return bRecv

	End Function

	'--------------------------------------------------------------------------
	' サーバーに接続されていなければ接続
	'--------------------------------------------------------------------------
	Public Function ConnectDelivery() As Boolean
		Dim bConnect As Boolean

		If IsNothing(Client) = False Then
			If Client.Connected = False Then
				Try
					Client.Close()
                Catch ex As Exception
                    SystemLog.AppError(ex)
                End Try
				Client = Nothing
			End If
		End If

		If IsNothing(Client) = True Then
            Try
                Dim tmpClient = New TcpClient()
                Dim ConnectEvent As New ManualResetEvent(False)
                Dim ar As IAsyncResult = tmpClient.BeginConnect(strServerIP, intServerPort, New AsyncCallback(AddressOf ConnectCallback), ConnectEvent)
                If Not ConnectEvent.WaitOne(My.Settings.ConnectTimeout) Then
                    ConnectTimeoutCount += 1
                    tmpClient.Close()
                    If ConnectTimeoutCount <= 3 Then
                        SystemLog.Information("Connect Timeout:" & strServerIP & ":" & intServerPort.ToString())
                    End If
                Else
                    tmpClient.EndConnect(ar)
                    tmpClient.SendTimeout = My.Settings.SendTimeout
                    SystemLog.Information("Connect:" & strServerIP & ":" & intServerPort.ToString())
                    Client = tmpClient
                    ConnectTimeoutCount = 0
                End If
            Catch ex As Exception
                'SystemLog.AppError(ex)
                Client = Nothing
            End Try
        End If

        If IsNothing(Client) = True Then
            bConnect = False
        Else
            bConnect = Client.Connected()
        End If

        Return bConnect

	End Function

    Private Shared Sub ConnectCallback(ar As IAsyncResult)
        Dim ConnectEvent As ManualResetEvent = CType(ar.AsyncState, ManualResetEvent)
        ConnectEvent.Set()
    End Sub

	'--------------------------------------------------------------------------
	' サーバー接続検査
	'--------------------------------------------------------------------------
	Public Function IsConnect() As Boolean
		Dim bConnect As Boolean

		If IsNothing(Client) = True Then
			bConnect = False
		Else
			bConnect = Client.Connected()
		End If

		Return bConnect

	End Function

	'--------------------------------------------------------------------------
	' サーバーに接続されていれば切断
	'--------------------------------------------------------------------------
	Public Sub DisconnectDelivery()
		If IsNothing(Client) = False Then
			Try
				If Client.Connected = True Then
					Client.Close()
				End If
				Telegram.ClearTelegram()
			Catch ex As Exception
			End Try
			Client = Nothing
		End If
	End Sub

End Class
