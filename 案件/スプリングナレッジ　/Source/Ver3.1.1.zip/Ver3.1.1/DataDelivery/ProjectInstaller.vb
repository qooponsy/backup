﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'この呼び出しは、コンポーネント デザイナーで必要です。
        InitializeComponent()

        'InitializeComponent への呼び出し後、初期化コードを追加します
#If REL_DEMO Then
        Me.ServiceInstaller.Description = "DataDeliveryDemo"
        Me.ServiceInstaller.ServiceName = "DataDeliveryDemo"
#End If
#If REL_TEST Then
        Me.ServiceInstaller.Description = "DataDeliveryTest"
        Me.ServiceInstaller.ServiceName = "DataDeliveryTest"
#End If
#If REL_NEXT Then
        Me.ServiceInstaller.Description = "DataDeliveryNext"
        Me.ServiceInstaller.ServiceName = "DataDeliveryNext"
#End If
#If REL_UK Then
        Me.ServiceInstaller.Description = "DataDeliveryUK"
        Me.ServiceInstaller.ServiceName = "DataDeliveryUK"
#End If
#If REL_MT4 Then
        Me.ServiceInstaller.Description = "DataDeliveryMT4"
        Me.ServiceInstaller.ServiceName = "DataDeliveryMT4"
#End If
#If REL_V3 Then
        Me.ServiceInstaller.Description = "DataDeliveryV3"
        Me.ServiceInstaller.ServiceName = "DataDeliveryV3"
#End If

    End Sub

End Class
