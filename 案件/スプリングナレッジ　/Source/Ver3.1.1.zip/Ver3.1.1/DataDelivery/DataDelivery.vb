﻿Imports System
Imports System.Threading
'------------------------------------------------------------------------------
' DataDelivery サービス
'------------------------------------------------------------------------------
Public Class DataDelivery
    Private svDelivery As clsDataDelivery
	Private thDelivery As Thread

	'--------------------------------------------------------------------------
	' サービス開始
	'--------------------------------------------------------------------------
	Protected Overrides Sub OnStart(ByVal args() As String)
        ' Service制御メインスレッド作成、実行
		svDelivery = New clsDataDelivery()
		thDelivery = New Thread(AddressOf svDelivery.ServiceThread)
        svDelivery.InitializeServiceThread()
		thDelivery.Start()
	End Sub

	'--------------------------------------------------------------------------
	' サービス停止
	'--------------------------------------------------------------------------
	Protected Overrides Sub OnStop()
		If Not IsNothing(thDelivery) Then
			If thDelivery.IsAlive Then
				svDelivery.StopService()
				thDelivery.Join()
			End If
			thDelivery = Nothing
			svDelivery = Nothing
		End If
	End Sub

End Class
