﻿'--------------------------------------------------------------------------
' データ配信電文の組立
'--------------------------------------------------------------------------
Public Class clsDeliveryTelegram
    Private RcvTelegram() As Byte

	'--------------------------------------------------------------------------
	' 電文種別コード
	'--------------------------------------------------------------------------
	Public Const TYPE_HB_MAIN As String = "000"			' Main ハートビート
	Public Const TYPE_HB_DELIVER As String = "001"		' 配信 ハートビート
	Public Const TYPE_INIT_RATE_TICK As String = "010"	' Rate G/W 最新Rate-Tick Seq 通知
	Public Const TYPE_NEW_RATE_TICK As String = "011"	' Rate G/W 新規Rate-Tick Data通知
	Public Const TYPE_INIT_SESSION As String = "020"	' DataDeliver 全件セッション情報
	Public Const TYPE_DIFF_SESSION As String = "021"	' DataDeliver 差分セッション情報
	Public Const TYPE_INIT_PRODUCT As String = "030"	' DataDeliver 全件銘柄情報
	Public Const TYPE_DIFF_PRODUCT As String = "031"	' DataDeliver 差分銘柄情報
	Public Const TYPE_PRODUCT_BASE As String = "071"	' DataDeliver 全件銘柄設定情報
	Public Const TYPE_SYS_SETTINGS As String = "072"	' DataDeliver 全件システム設定情報
	Public Const TYPE_SYS_STATUS As String = "073"		' DataDeliver 全件システムステータス情報
	Public Const TYPE_CALC_PARAM As String = "074"		' DataDeliver 全件計算パラメタ情報
	'--------------------------------------------------------------------------
	' 電文項目の型別項目長
	'--------------------------------------------------------------------------
	Public Const PAT_LEN_SIZE As Integer = 8
	Public Const PAT_LEN_DATETIME As Integer = 17
	Public Const PAT_LEN_DATE As Integer = 8
	Public Const PAT_LEN_TIME As Integer = 6
    Public Const PAT_LEN_INT As Integer = 11
    Public Const PAT_LEN_RATE As Integer = 17
	Public Const PAT_LEN_MONEY As Integer = 16
	'--------------------------------------------------------------------------
	' コンストラクタ
	'--------------------------------------------------------------------------
	Public Sub New()
		RcvTelegram = Nothing
	End Sub

	'--------------------------------------------------------------------------
	' 初期化
	'--------------------------------------------------------------------------
    Public Sub Initialize()
    End Sub

    '--------------------------------------------------------------------------
    ' ヘッダー電文組立
    '--------------------------------------------------------------------------
	Private Function CreateHeaderTelegram(ByVal sCode As String, ByVal iBodyLength As Integer) As Byte()
		Dim HeaderTelegram(65) As Byte

        SetTelegramCode(My.Settings.ProcessID, HeaderTelegram, 0, 32)
        SetTelegramCode(Format(DateTime.UtcNow, "yyyy/MM/dd HH:mm:ss.fff"), HeaderTelegram, 32, 23)
		SetTelegramCode(sCode, HeaderTelegram, 55, 3)
		SetTelegramCode(iBodyLength.ToString(), HeaderTelegram, 58, 8)

		Return HeaderTelegram
	End Function

	'--------------------------------------------------------------------------
	' 電文項目組立（ヘッダー＋ボディ）
	'--------------------------------------------------------------------------
	Private Function CreateTelegram(ByVal sCode As String, ByVal iBodyLength As Integer, ByVal Body() As Byte) As Byte()
		Dim iPosition As Integer
		Dim Header() As Byte
		Dim Telegram() As Byte
		Dim iTelegramLen As Integer

		Header = CreateHeaderTelegram(sCode, iBodyLength)

		iTelegramLen = 66 + iBodyLength + 2
		Telegram = New Byte(iTelegramLen - 1) {}

		Telegram(0) = &H2
		SetTelegramByte(Header, Telegram, 1, 66)
		If iBodyLength > 0 Then
			SetTelegramByte(Body, Telegram, 67, iBodyLength)
		End If
		iPosition = 67 + iBodyLength
		Telegram(iPosition) = &H3

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' ＭａｉｎＡＰハートビートの電文編集
	'--------------------------------------------------------------------------
	Public Function CreateMainHeartBeat() As Byte()
		Dim Telegram() As Byte

		Telegram = CreateTelegram(TYPE_HB_MAIN, 0, Nothing)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' データ配信サービスハートビートの電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryHeartBeat() As Byte()
		Dim Telegram() As Byte
        Dim Body() As Byte

        Body = System.Text.Encoding.UTF8.GetBytes(Format(DateTime.Now, "yyyyMMddHHmmssfff"))
        Telegram = CreateTelegram(TYPE_HB_DELIVER, Body.Count, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' レートティックのSeq番号の電文編集		未実装：ダミーでハートビート電文作成
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryInitRate(ByVal dtRate As DataTable) As Byte()
		Return CreateDeliveryHeartBeat()
	End Function

	'--------------------------------------------------------------------------
	' レートティックデータの電文編集　		未実装：ダミーでハートビート電文作成
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryNewRate(ByVal dtRate As DataTable) As Byte()
		Return CreateDeliveryHeartBeat()
	End Function

	'--------------------------------------------------------------------------
	' セッション情報全件の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryInitSession(ByVal dtSession As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim ListRow As DataRow
		Dim iIndex As Integer

        iBodyLen = 8 + (130 * dtSession.Rows.Count())
		Body = New Byte(iBodyLen - 1) {}

		iIndex = 0
		SetTelegramCode(dtSession.Rows.Count().ToString(), Body, iIndex, 8)
		iIndex = iIndex + 8
		For Each ListRow In dtSession.Rows
			SetTelegramCode(ListRow.Item("SessionKey").ToString(), Body, iIndex, 32)
			iIndex = iIndex + 32
			SetTelegramCode(ListRow.Item("AuthType").ToString(), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("UserID").ToString(), Body, iIndex, 32)
			iIndex = iIndex + 32
			SetTelegramCode(ListRow.Item("ClientType").ToString(), Body, iIndex, 2)
			iIndex = iIndex + 2
			SetTelegramCode(ListRow.Item("ClientVersion").ToString(), Body, iIndex, 32)
			iIndex = iIndex + 32
			SetTelegramDateTime(ListRow.Item("LastCheckTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramInt(ListRow.Item("PrivateDataSeq"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_INT
            SetTelegramCode(ListRow.Item("TimeMode").ToString(), Body, iIndex, 1)
            iIndex = iIndex + 1
            SetTelegramCode(ListRow.Item("LangCode").ToString(), Body, iIndex, 2)
            iIndex = iIndex + 2
        Next

		Telegram = CreateTelegram(TYPE_INIT_SESSION, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' セッション情報差分の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryDiffSession(ByVal dtSession As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim ListRow As DataRow
		Dim iIndex As Integer

        iBodyLen = 8 + (131 * dtSession.Rows.Count())
		Body = New Byte(iBodyLen - 1) {}

		iIndex = 0
		SetTelegramCode(dtSession.Rows.Count().ToString(), Body, iIndex, 8)
		iIndex = iIndex + 8
		For Each ListRow In dtSession.Rows
			SetTelegramCode(ListRow.Item("DeliveryType").ToString(), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("SessionKey").ToString(), Body, iIndex, 32)
			iIndex = iIndex + 32
			SetTelegramCode(ListRow.Item("AuthType").ToString(), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("UserID").ToString(), Body, iIndex, 32)
			iIndex = iIndex + 32
			SetTelegramCode(ListRow.Item("ClientType").ToString(), Body, iIndex, 2)
			iIndex = iIndex + 2
			SetTelegramCode(ListRow.Item("ClientVersion").ToString(), Body, iIndex, 32)
			iIndex = iIndex + 32
			SetTelegramDateTime(ListRow.Item("LastCheckTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramInt(ListRow.Item("PrivateDataSeq"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_INT
            SetTelegramCode(ListRow.Item("TimeMode").ToString(), Body, iIndex, 1)
            iIndex = iIndex + 1
            SetTelegramCode(ListRow.Item("LangCode").ToString(), Body, iIndex, 2)
            iIndex = iIndex + 2
        Next

		Telegram = CreateTelegram(TYPE_DIFF_SESSION, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' 銘柄情報全件の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryInitProduct(ByVal dtProduct As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim ListRow As DataRow
		Dim iIndex As Integer

        iBodyLen = 8 + (158 * dtProduct.Rows.Count())
		Body = New Byte(iBodyLen - 1) {}

		iIndex = 0
		SetTelegramCode(dtProduct.Rows.Count().ToString(), Body, iIndex, 8)
		iIndex = iIndex + 8
		For Each ListRow In dtProduct.Rows
			SetTelegramCode(ListRow.Item("ProductCode").ToString(), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramCode(ListRow.Item("Enabled").ToString(), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("ProductBaseCode").ToString(), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramDate(ListRow.Item("SysDate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATE
			SetTelegramCode(ListRow.Item("ComCode"), Body, iIndex, 10)
			iIndex = iIndex + 10
			SetTelegramCode(ListRow.Item("OpType"), Body, iIndex, 2)
			iIndex = iIndex + 2
			SetTelegramDateTime(ListRow.Item("StartTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramDateTime(ListRow.Item("ExercTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramDateTime(ListRow.Item("TradeLimitTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramRate(ListRow.Item("PayoutRate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
			SetTelegramCode(ListRow.Item("ExercStatus"), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("ExercRateSeq"), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramRate(ListRow.Item("ExercRate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
		Next

		Telegram = CreateTelegram(TYPE_INIT_PRODUCT, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' 銘柄情報差分の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryDiffProduct(ByVal dtProduct As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim ListRow As DataRow
		Dim iIndex As Integer

        iBodyLen = 8 + (159 * dtProduct.Rows.Count())
		Body = New Byte(iBodyLen - 1) {}

		iIndex = 0
		SetTelegramCode(dtProduct.Rows.Count().ToString(), Body, iIndex, 8)
		iIndex = iIndex + 8
		For Each ListRow In dtProduct.Rows
			SetTelegramCode(ListRow.Item("DeliveryType").ToString(), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("ProductCode").ToString(), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramCode(ListRow.Item("Enabled").ToString(), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("ProductBaseCode").ToString(), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramDate(ListRow.Item("SysDate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATE
			SetTelegramCode(ListRow.Item("ComCode"), Body, iIndex, 10)
			iIndex = iIndex + 10
			SetTelegramCode(ListRow.Item("OpType"), Body, iIndex, 2)
			iIndex = iIndex + 2
			SetTelegramDateTime(ListRow.Item("StartTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramDateTime(ListRow.Item("ExercTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramDateTime(ListRow.Item("TradeLimitTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_DATETIME
			SetTelegramRate(ListRow.Item("PayoutRate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
			SetTelegramCode(ListRow.Item("ExercStatus"), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("ExercRateSeq"), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramRate(ListRow.Item("ExercRate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
		Next

		Telegram = CreateTelegram(TYPE_DIFF_PRODUCT, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' 銘柄設定情報の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryProductBase(ByVal dtProductBase As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim ListRow As DataRow
		Dim iIndex As Integer

        iBodyLen = 8 + (81 * dtProductBase.Rows.Count())
		Body = New Byte(iBodyLen - 1) {}

		iIndex = 0
		SetTelegramCode(dtProductBase.Rows.Count().ToString(), Body, iIndex, 8)
		iIndex = iIndex + 8
		For Each ListRow In dtProductBase.Rows
			SetTelegramCode(ListRow.Item("ProductBaseCode").ToString(), Body, iIndex, 17)
			iIndex = iIndex + 17
			SetTelegramCode(ListRow.Item("Enabled"), Body, iIndex, 1)
			iIndex = iIndex + 1
			SetTelegramCode(ListRow.Item("ComCode"), Body, iIndex, 10)
			iIndex = iIndex + 10
			SetTelegramCode(ListRow.Item("OpType"), Body, iIndex, 2)
			iIndex = iIndex + 2
			SetTelegramInt(ListRow.Item("OptionTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_INT
			SetTelegramInt(ListRow.Item("CreateTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_INT
			SetTelegramTime(ListRow.Item("StartTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_TIME
			SetTelegramTime(ListRow.Item("ExercTime"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_TIME
			SetTelegramRate(ListRow.Item("PayoutRate"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
		Next

		Telegram = CreateTelegram(TYPE_PRODUCT_BASE, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' システム設定情報の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliverySysSettings(ByVal dtSysSettings As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim iIndex As Integer

        iBodyLen = 332
		Body = New Byte(iBodyLen - 1) {}

		SetTelegramInt(dtSysSettings.Rows(0).Item("StopTradeTime"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramInt(dtSysSettings.Rows(0).Item("StartAbandTime"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramInt(dtSysSettings.Rows(0).Item("AbandPriceDiff"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramRate(dtSysSettings.Rows(0).Item("Commission"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_RATE
		SetTelegramRate(dtSysSettings.Rows(0).Item("AbandMargine"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_RATE
		SetTelegramMoney(dtSysSettings.Rows(0).Item("TradeMoneyMin"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
        SetTelegramInt(dtSysSettings.Rows(0).Item("TradeLotMin"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT
        SetTelegramMoney(dtSysSettings.Rows(0).Item("TradeMoneyMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
        SetTelegramInt(dtSysSettings.Rows(0).Item("TradeLotMax"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT
        SetTelegramMoney(dtSysSettings.Rows(0).Item("ProductMoneyMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
        SetTelegramInt(dtSysSettings.Rows(0).Item("ProductLotMax"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT
        SetTelegramInt(dtSysSettings.Rows(0).Item("CustCountMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramMoney(dtSysSettings.Rows(0).Item("CustMoneyMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
        SetTelegramInt(dtSysSettings.Rows(0).Item("CustLotMax"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT
        SetTelegramMoney(dtSysSettings.Rows(0).Item("CustProductMoneyMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
        SetTelegramInt(dtSysSettings.Rows(0).Item("CustProductLotMax"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT
        SetTelegramMoney(dtSysSettings.Rows(0).Item("CashInMoneyMin"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
		SetTelegramMoney(dtSysSettings.Rows(0).Item("CashInMoneyDayMin"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
		SetTelegramMoney(dtSysSettings.Rows(0).Item("CashOutMoneyMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
		SetTelegramMoney(dtSysSettings.Rows(0).Item("CashOutMoneyDayMax"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_MONEY
		SetTelegramInt(dtSysSettings.Rows(0).Item("ProductStartPreTime"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramInt(dtSysSettings.Rows(0).Item("ProductEndLossTime"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramInt(dtSysSettings.Rows(0).Item("RateEnableTime"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
        SetTelegramInt(dtSysSettings.Rows(0).Item("TimeZone"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT
        SetTelegramInt(dtSysSettings.Rows(0).Item("SysDateTimeZone"), Body, iIndex)
        iIndex = iIndex + PAT_LEN_INT

		Telegram = CreateTelegram(TYPE_SYS_SETTINGS, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' システムステータス情報の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliverySysStatus(ByVal dtSysStatus As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim iIndex As Integer

        iBodyLen = 34
		Body = New Byte(iBodyLen - 1) {}

		SetTelegramDate(CDate(dtSysStatus.Rows(0).Item("SysDate")), Body, iIndex)
		iIndex = iIndex + PAT_LEN_DATE
		SetTelegramCode(dtSysStatus.Rows(0).Item("SysEnabled").ToString(), Body, iIndex, 1)
		iIndex = iIndex + 1
		SetTelegramCode(dtSysStatus.Rows(0).Item("AbandEnabled").ToString(), Body, iIndex, 1)
		iIndex = iIndex + 1
		SetTelegramCode(dtSysStatus.Rows(0).Item("CashOutEnabled").ToString(), Body, iIndex, 1)
		iIndex = iIndex + 1
		SetTelegramCode(dtSysStatus.Rows(0).Item("CashInEnabled").ToString(), Body, iIndex, 1)
		iIndex = iIndex + 1
		SetTelegramInt(dtSysStatus.Rows(0).Item("RateProviderID"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT
		SetTelegramInt(dtSysStatus.Rows(0).Item("SysUpdateSeq"), Body, iIndex)
		iIndex = iIndex + PAT_LEN_INT

		Telegram = CreateTelegram(TYPE_SYS_STATUS, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' 計算パラメータ情報の電文編集
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryCalcParam(ByVal dtCalcParam As DataTable) As Byte()
		Dim Telegram() As Byte
		Dim iBodyLen As Integer
		Dim Body() As Byte
		Dim ListRow As DataRow
		Dim iIndex As Integer

        iBodyLen = 8 + (163 * dtCalcParam.Rows.Count())
		Body = New Byte(iBodyLen - 1) {}

		iIndex = 0
		SetTelegramCode(dtCalcParam.Rows.Count().ToString(), Body, iIndex, 8)
		iIndex = iIndex + 8
		For Each ListRow In dtCalcParam.Rows
			SetTelegramCode(ListRow.Item("ComCode").ToString(), Body, iIndex, 10)
			iIndex = iIndex + 10
            SetTelegramCalcValue(ListRow.Item("InterestRate"), Body, iIndex)
            iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("SwapRate"), Body, iIndex)
            iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("VolatilityAdjust"), Body, iIndex)
            iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("Volatility"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("DeltaVariation"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("GammaVariation"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("VegaVariation"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("ThetaVariation"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
            SetTelegramCalcValue(ListRow.Item("RhoVariation"), Body, iIndex)
			iIndex = iIndex + PAT_LEN_RATE
		Next

		Telegram = CreateTelegram(TYPE_CALC_PARAM, iBodyLen, Body)

		Return Telegram
	End Function

	'--------------------------------------------------------------------------
	' 電文項目組立（コード）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramCode(ByVal sSource As String, ByRef bTelegram() As Byte, ByVal iOffset As Integer, ByVal iLength As Integer)
		Dim iPaddLen As Integer
		Dim bSource() As Byte

		iPaddLen = iLength - sSource.Length
		bSource = System.Text.Encoding.UTF8.GetBytes(sSource & StrDup(iPaddLen, " "))
		Array.Copy(bSource, 0, bTelegram, iOffset, bSource.Length)

	End Sub

	'--------------------------------------------------------------------------
	' 電文項目組立（Ｉｎｔ）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramInt(ByVal iData As Integer, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
		Dim sSource As String

		sSource = iData.ToString("#########0")
		SetTelegramCode(sSource, bTelegram, iOffset, PAT_LEN_INT)
	End Sub

	'--------------------------------------------------------------------------
	' 電文項目組立（Ｒａｔｅ）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramRate(ByVal dRate As Decimal, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
		Dim sSource As String

		sSource = dRate.ToString("######0.00000000")
		SetTelegramCode(sSource, bTelegram, iOffset, PAT_LEN_RATE)
	End Sub

    '--------------------------------------------------------------------------
    ' 電文項目組立（ＣａｌｃＲａｔｅ）
    '--------------------------------------------------------------------------
    Private Sub SetTelegramCalcValue(ByVal dValue As Decimal, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
        Dim sSource As String

        sSource = dValue.ToString("0.00000000000000")
        SetTelegramCode(sSource, bTelegram, iOffset, PAT_LEN_RATE)
    End Sub

    '--------------------------------------------------------------------------
    ' 電文項目組立（Ｍｏｎｅｙ）
    '--------------------------------------------------------------------------
	Private Sub SetTelegramMoney(ByVal dMoney As Decimal, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
		Dim sSource As String

		sSource = dMoney.ToString("##########0.0000")
		SetTelegramCode(sSource, bTelegram, iOffset, PAT_LEN_MONEY)
	End Sub

	'--------------------------------------------------------------------------
	' 電文項目組立（ＤａｔｅＴｉｍｅ）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramDateTime(ByVal dDateTime As Date, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
		Dim sSource As String

		sSource = Format(dDateTime, "yyyyMMddHHmmssfff")
		SetTelegramCode(sSource, bTelegram, iOffset, PAT_LEN_DATETIME)
	End Sub

	'--------------------------------------------------------------------------
	' 電文項目組立（Ｄａｔｅ）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramDate(ByVal dDate As Date, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
		Dim sSource As String

		sSource = Format(dDate, "yyyyMMdd")
		SetTelegramCode(sSource, bTelegram, iOffset, PAT_LEN_DATE)
	End Sub

	'--------------------------------------------------------------------------
	' 電文項目組立（Ｔｉｍｅ）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramTime(ByVal sTimeData As String, ByRef bTelegram() As Byte, ByVal iOffset As Integer)
		Dim sSource As String
		Dim tTimeData As TimeSpan

		If TimeSpan.TryParse(sTimeData, tTimeData) = True Then
			sSource = tTimeData.ToString("hhmmss")
		Else
			sSource = ""
		End If
		SetTelegramCode(sSource, bTelegram, iOffset, 6)
	End Sub

	'--------------------------------------------------------------------------
	' 電文項目組立（Ｂｙｔｅ配列）
	'--------------------------------------------------------------------------
	Private Sub SetTelegramByte(ByVal bSource() As Byte, ByRef bTelegram() As Byte, ByVal iOffset As Integer, ByVal iLength As Integer)
		Array.Copy(bSource, 0, bTelegram, iOffset, bSource.Length)
	End Sub

	'--------------------------------------------------------------------------
	' 配信データの生成
	'--------------------------------------------------------------------------
	Public Function CreateDeliveryTelegram(ByVal sType As String, ByVal dtDeliveryData As DataTable) As Byte()
		Dim bytData() As Byte

		Select Case sType
			Case TYPE_HB_MAIN									' Main ハートビート
				bytData = CreateMainHeartBeat()
			Case TYPE_HB_DELIVER								' 配信 ハートビート
				bytData = CreateDeliveryHeartBeat()
			Case TYPE_INIT_RATE_TICK							' Rate G/W 最新Rate-Tick Seq 通知
				bytData = CreateDeliveryInitRate(dtDeliveryData)
			Case TYPE_NEW_RATE_TICK								' Rate G/W 新規Rate-Tick Data通知
				bytData = CreateDeliveryNewRate(dtDeliveryData)
			Case TYPE_INIT_SESSION								' DataDeliver 全件セッション情報
				bytData = CreateDeliveryInitSession(dtDeliveryData)
			Case TYPE_DIFF_SESSION								' DataDeliver 差分セッション情報
				bytData = CreateDeliveryDiffSession(dtDeliveryData)
			Case TYPE_INIT_PRODUCT								' DataDeliver 全件銘柄情報
				bytData = CreateDeliveryInitProduct(dtDeliveryData)
			Case TYPE_DIFF_PRODUCT								' DataDeliver 差分銘柄情報
				bytData = CreateDeliveryDiffProduct(dtDeliveryData)
			Case TYPE_PRODUCT_BASE								' DataDeliver 全件銘柄設定情報
				bytData = CreateDeliveryProductBase(dtDeliveryData)
			Case TYPE_SYS_SETTINGS								' DataDeliver 全件システム設定情報
				bytData = CreateDeliverySysSettings(dtDeliveryData)
			Case TYPE_SYS_STATUS								' DataDeliver 全件システムステータス情報
				bytData = CreateDeliverySysStatus(dtDeliveryData)
			Case TYPE_CALC_PARAM								' DataDeliver 全件計算パラメタ情報
				bytData = CreateDeliveryCalcParam(dtDeliveryData)
			Case Else
				bytData = CreateDeliveryHeartBeat()
		End Select

		Return bytData
	End Function

	'--------------------------------------------------------------------------
	' 受信電文の結合と１電文の分離
	'--------------------------------------------------------------------------
	Public Function AddReceiveTelegram(ByVal bytRecv() As Byte, ByVal iRecvLen As Integer, ByRef sRecvText As String) As Boolean
		Dim recvTemp() As Byte
		Dim iNewLen As Integer
		Dim iTelegramLen As Integer
		Dim iOffset As Integer
		Dim iOffsetSTX As Integer
		Dim iOffsetETX As Integer
		Dim bETX As Boolean

		bETX = False

		recvTemp = Nothing
		'----------------------------------------------------------------------
		' 受信電文のマージ
		'----------------------------------------------------------------------
		If IsNothing(RcvTelegram) = True Then
			iOffset = 0
			iNewLen = iRecvLen
		Else
			recvTemp = RcvTelegram.Clone()
			iOffset = RcvTelegram.Length
			iNewLen = iOffset + iRecvLen
		End If
		If iRecvLen > 0 Then
			RcvTelegram = New Byte(iNewLen - 1) {}
			If iOffset > 0 Then
				Array.Copy(recvTemp, 0, RcvTelegram, 0, iOffset)
			End If
			Array.Copy(bytRecv, 0, RcvTelegram, iOffset, iRecvLen)
		End If

		'----------------------------------------------------------------------
		' STX-ETXの検査
		'----------------------------------------------------------------------
		iOffsetSTX = -1
		iOffsetETX = -1
		For iOffset = 0 To iNewLen - 1
			If iOffsetSTX < 0 Then
				If RcvTelegram(iOffset) = &H2 Then
					iOffsetSTX = iOffset
				End If
			Else
				If RcvTelegram(iOffset) = &H3 Then
					iOffsetETX = iOffset
					Exit For
				End If
			End If
		Next

		'----------------------------------------------------------------------
		'
		'----------------------------------------------------------------------
		If iNewLen > 0 Then
			If iOffsetSTX < 0 Then
				'--------------------------------------------------------------
				' STXの無い電文は破棄
				'--------------------------------------------------------------
				RcvTelegram = Nothing
			Else
				'--------------------------------------------------------------
				' ETXまでの電文をエンコード
				'--------------------------------------------------------------
				If iOffsetETX > iOffsetSTX Then
					iTelegramLen = iOffsetETX - iOffsetSTX - 1
					sRecvText = System.Text.Encoding.UTF8.GetString(RcvTelegram, iOffsetSTX + 1, iTelegramLen)
					bETX = True

					'--------------------------------------------------------------
					' ETX以降に電文があれば次回受信時に結合
					'--------------------------------------------------------------
					recvTemp = RcvTelegram.Clone()
					iNewLen = RcvTelegram.Length - iOffsetETX - 1
					If iNewLen > 0 Then
						RcvTelegram = New Byte(iNewLen - 1) {}
						Array.Copy(recvTemp, iOffsetETX + 1, RcvTelegram, 0, iNewLen)
					Else
						RcvTelegram = Nothing
					End If
				End If
			End If
		End If

		Return bETX
	End Function

	'--------------------------------------------------------------------------
	' 配信データの解析
	'--------------------------------------------------------------------------
	Public Function GetDeliveryData(ByVal sTelegram As String, ByRef dtDeliveryData As DataTable) As String
		Dim sSendProcess As String
		Dim sSendTime As String
		Dim sType As String
		Dim sTelegramBody As String
		Dim iBodyLen As Integer

		sSendProcess = sTelegram.Substring(0, 32)
		sSendTime = sTelegram.Substring(32, 23)
		sType = sTelegram.Substring(55, 3)
		iBodyLen = CInt(sTelegram.Substring(58, 8))
		sTelegramBody = sTelegram.Substring(66, iBodyLen)

		Select Case sType
			Case TYPE_HB_DELIVER								' 配信 ハートビート
				GetDeliveryDataHeartBeat(sTelegramBody, dtDeliveryData)
			Case TYPE_INIT_RATE_TICK							' Rate G/W 最新Rate-Tick Seq 通知
				GetDeliveryDataInitRate(sTelegramBody, dtDeliveryData)
			Case TYPE_NEW_RATE_TICK								' Rate G/W 新規Rate-Tick Data通知
				GetDeliveryDataNewRate(sTelegramBody, dtDeliveryData)
			Case TYPE_INIT_SESSION								' DataDeliver 全件セッション情報
				GetDeliveryDataInitSession(sTelegramBody, dtDeliveryData)
			Case TYPE_DIFF_SESSION								' DataDeliver 差分セッション情報
				GetDeliveryDataDiffSession(sTelegramBody, dtDeliveryData)
			Case TYPE_INIT_PRODUCT								' DataDeliver 全件銘柄情報
				GetDeliveryDataInitProduct(sTelegramBody, dtDeliveryData)
			Case TYPE_DIFF_PRODUCT								' DataDeliver 差分銘柄情報
				GetDeliveryDataDiffProduct(sTelegramBody, dtDeliveryData)
			Case TYPE_PRODUCT_BASE								' DataDeliver 全件銘柄設定情報
				GetDeliveryDataProductBase(sTelegramBody, dtDeliveryData)
			Case TYPE_SYS_SETTINGS								' DataDeliver 全件システム設定情報
				GetDeliveryDataSysSettings(sTelegramBody, dtDeliveryData)
			Case TYPE_SYS_STATUS								' DataDeliver 全件システムステータス情報
				GetDeliveryDataSysStatus(sTelegramBody, dtDeliveryData)
			Case TYPE_CALC_PARAM								' DataDeliver 全件計算パラメタ情報
				GetDeliveryDataCalcParam(sTelegramBody, dtDeliveryData)
			Case Else
				dtDeliveryData = Nothing
		End Select

		Return sType
	End Function

	'--------------------------------------------------------------------------
	' データ配信サービスハートビートの電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataHeartBeat(ByVal sBody As String, ByRef ListData As DataTable)
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("ServerDateTime"))

		ListRow = ListData.NewRow()
		ListRow.Item("ServerDateTime") = GetTelegramDateTime(sBody)
		ListData.Rows.Add(ListRow)

	End Sub

	'--------------------------------------------------------------------------
	' レートティックのSeq番号の電文解析		未実装
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataInitRate(ByVal sBody As String, ByRef ListData As DataTable)
		ListData = Nothing
	End Sub

	'--------------------------------------------------------------------------
	' レートティックデータの電文解析　		未実装
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataNewRate(ByVal sBody As String, ByRef ListData As DataTable)
		ListData = Nothing
	End Sub

	'--------------------------------------------------------------------------
	' セッション情報全件の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataInitSession(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim iListCount As Integer
		Dim iListIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("DeliveryType"))
		ListData.Columns.Add(New DataColumn("SessionKey"))
		ListData.Columns.Add(New DataColumn("AuthType"))
		ListData.Columns.Add(New DataColumn("UserID"))
		ListData.Columns.Add(New DataColumn("ClientType"))
		ListData.Columns.Add(New DataColumn("ClientVersion"))
		ListData.Columns.Add(New DataColumn("LastCheckTime"))
        ListData.Columns.Add(New DataColumn("PrivateDataSeq"))
        ListData.Columns.Add(New DataColumn("TimeMode"))
        ListData.Columns.Add(New DataColumn("LangCode"))

		iListCount = GetTelegramInt(sBody.Substring(0, PAT_LEN_SIZE))
		iIndex = PAT_LEN_SIZE
		For iListIndex = 0 To iListCount - 1
			ListRow = ListData.NewRow()
			ListRow.Item("DeliveryType") = "I"
			ListRow.Item("SessionKey") = sBody.Substring(iIndex, 32)
			iIndex = iIndex + 32
			ListRow.Item("AuthType") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
            ListRow.Item("UserID") = sBody.Substring(iIndex, 32).Trim()
			iIndex = iIndex + 32
			ListRow.Item("ClientType") = sBody.Substring(iIndex, 2)
			iIndex = iIndex + 2
            ListRow.Item("ClientVersion") = sBody.Substring(iIndex, 32).Trim()
			iIndex = iIndex + 32
			ListRow.Item("LastCheckTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("PrivateDataSeq") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
			iIndex = iIndex + PAT_LEN_INT
            ListRow.Item("TimeMode") = sBody.Substring(iIndex, 1)
            iIndex = iIndex + 1
            ListRow.Item("LangCode") = sBody.Substring(iIndex, 2)
            iIndex = iIndex + 2
            ListData.Rows.Add(ListRow)
		Next
	End Sub

	'--------------------------------------------------------------------------
	' セッション情報差分の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataDiffSession(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim iListCount As Integer
		Dim iListIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("DeliveryType"))
		ListData.Columns.Add(New DataColumn("SessionKey"))
		ListData.Columns.Add(New DataColumn("AuthType"))
		ListData.Columns.Add(New DataColumn("UserID"))
		ListData.Columns.Add(New DataColumn("ClientType"))
		ListData.Columns.Add(New DataColumn("ClientVersion"))
		ListData.Columns.Add(New DataColumn("LastCheckTime"))
        ListData.Columns.Add(New DataColumn("PrivateDataSeq"))
        ListData.Columns.Add(New DataColumn("TimeMode"))
        ListData.Columns.Add(New DataColumn("LangCode"))

		iListCount = GetTelegramInt(sBody.Substring(0, PAT_LEN_SIZE))
		iIndex = PAT_LEN_SIZE
		For iListIndex = 0 To iListCount - 1
			ListRow = ListData.NewRow()
			ListRow.Item("DeliveryType") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
			ListRow.Item("SessionKey") = sBody.Substring(iIndex, 32)
			iIndex = iIndex + 32
			ListRow.Item("AuthType") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
            ListRow.Item("UserID") = sBody.Substring(iIndex, 32).Trim()
			iIndex = iIndex + 32
			ListRow.Item("ClientType") = sBody.Substring(iIndex, 2)
			iIndex = iIndex + 2
            ListRow.Item("ClientVersion") = sBody.Substring(iIndex, 32).Trim()
			iIndex = iIndex + 32
			ListRow.Item("LastCheckTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("PrivateDataSeq") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
			iIndex = iIndex + PAT_LEN_INT
            ListRow.Item("TimeMode") = sBody.Substring(iIndex, 1)
            iIndex = iIndex + 1
            ListRow.Item("LangCode") = sBody.Substring(iIndex, 2)
            iIndex = iIndex + 2
            ListData.Rows.Add(ListRow)
		Next
	End Sub

	'--------------------------------------------------------------------------
	' 銘柄情報全件の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataInitProduct(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim iListCount As Integer
		Dim iListIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("DeliveryType"))
		ListData.Columns.Add(New DataColumn("ProductCode"))
		ListData.Columns.Add(New DataColumn("Enabled"))
		ListData.Columns.Add(New DataColumn("ProductBaseCode"))
		ListData.Columns.Add(New DataColumn("SysDate"))
		ListData.Columns.Add(New DataColumn("ComCode"))
		ListData.Columns.Add(New DataColumn("OpType"))
		ListData.Columns.Add(New DataColumn("StartTime"))
		ListData.Columns.Add(New DataColumn("ExercTime"))
		ListData.Columns.Add(New DataColumn("TradeLimitTime"))
		ListData.Columns.Add(New DataColumn("PayoutRate"))
		ListData.Columns.Add(New DataColumn("ExercStatus"))
		ListData.Columns.Add(New DataColumn("ExercRateSeq"))
		ListData.Columns.Add(New DataColumn("ExercRate"))

		iListCount = GetTelegramInt(sBody.Substring(0, PAT_LEN_SIZE))
		iIndex = PAT_LEN_SIZE
		For iListIndex = 0 To iListCount - 1
			ListRow = ListData.NewRow()
			ListRow.Item("DeliveryType") = "I"
			ListRow.Item("ProductCode") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("Enabled") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
			ListRow.Item("ProductBaseCode") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("SysDate") = GetTelegramDate(sBody.Substring(iIndex, PAT_LEN_DATE))
			iIndex = iIndex + PAT_LEN_DATE
            ListRow.Item("ComCode") = sBody.Substring(iIndex, 10).Trim()
			iIndex = iIndex + 10
			ListRow.Item("OpType") = sBody.Substring(iIndex, 2)
			iIndex = iIndex + 2
			ListRow.Item("StartTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("ExercTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("TradeLimitTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("PayoutRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("ExercStatus") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
			ListRow.Item("ExercRateSeq") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("ExercRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListData.Rows.Add(ListRow)
		Next
	End Sub

	'--------------------------------------------------------------------------
	' 銘柄情報差分の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataDiffProduct(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim iListCount As Integer
		Dim iListIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("DeliveryType"))
		ListData.Columns.Add(New DataColumn("ProductCode"))
		ListData.Columns.Add(New DataColumn("Enabled"))
		ListData.Columns.Add(New DataColumn("ProductBaseCode"))
		ListData.Columns.Add(New DataColumn("SysDate"))
		ListData.Columns.Add(New DataColumn("ComCode"))
		ListData.Columns.Add(New DataColumn("OpType"))
		ListData.Columns.Add(New DataColumn("StartTime"))
		ListData.Columns.Add(New DataColumn("ExercTime"))
		ListData.Columns.Add(New DataColumn("TradeLimitTime"))
		ListData.Columns.Add(New DataColumn("PayoutRate"))
		ListData.Columns.Add(New DataColumn("ExercStatus"))
		ListData.Columns.Add(New DataColumn("ExercRateSeq"))
		ListData.Columns.Add(New DataColumn("ExercRate"))

		iListCount = GetTelegramInt(sBody.Substring(0, PAT_LEN_SIZE))
		iIndex = PAT_LEN_SIZE
		For iListIndex = 0 To iListCount - 1
			ListRow = ListData.NewRow()
			ListRow.Item("DeliveryType") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
			ListRow.Item("ProductCode") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("Enabled") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
			ListRow.Item("ProductBaseCode") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("SysDate") = GetTelegramDate(sBody.Substring(iIndex, PAT_LEN_DATE))
			iIndex = iIndex + PAT_LEN_DATE
            ListRow.Item("ComCode") = sBody.Substring(iIndex, 10).Trim()
			iIndex = iIndex + 10
			ListRow.Item("OpType") = sBody.Substring(iIndex, 2)
			iIndex = iIndex + 2
			ListRow.Item("StartTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("ExercTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("TradeLimitTime") = GetTelegramDateTime(sBody.Substring(iIndex, PAT_LEN_DATETIME))
			iIndex = iIndex + PAT_LEN_DATETIME
			ListRow.Item("PayoutRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("ExercStatus") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
			ListRow.Item("ExercRateSeq") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("ExercRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListData.Rows.Add(ListRow)
		Next
	End Sub

	'--------------------------------------------------------------------------
	' 銘柄設定情報の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataProductBase(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim iListCount As Integer
		Dim iListIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("ProductBaseCode"))
		ListData.Columns.Add(New DataColumn("Enabled"))
		ListData.Columns.Add(New DataColumn("ComCode"))
		ListData.Columns.Add(New DataColumn("OpType"))
		ListData.Columns.Add(New DataColumn("OptionTime"))
		ListData.Columns.Add(New DataColumn("CreateTime"))
		ListData.Columns.Add(New DataColumn("StartTime"))
		ListData.Columns.Add(New DataColumn("ExercTime"))
		ListData.Columns.Add(New DataColumn("PayoutRate"))

		iListCount = GetTelegramInt(sBody.Substring(0, PAT_LEN_SIZE))
		iIndex = PAT_LEN_SIZE
		For iListIndex = 0 To iListCount - 1
			ListRow = ListData.NewRow()

			ListRow.Item("ProductBaseCode") = sBody.Substring(iIndex, 17)
			iIndex = iIndex + 17
			ListRow.Item("Enabled") = sBody.Substring(iIndex, 1)
			iIndex = iIndex + 1
            ListRow.Item("ComCode") = sBody.Substring(iIndex, 10).Trim()
			iIndex = iIndex + 10
			ListRow.Item("OpType") = sBody.Substring(iIndex, 2)
			iIndex = iIndex + 2
			ListRow.Item("OptionTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
			iIndex = iIndex + PAT_LEN_INT
			ListRow.Item("CreateTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
			iIndex = iIndex + PAT_LEN_INT
			ListRow.Item("StartTime") = GetTelegramTime(sBody.Substring(iIndex, PAT_LEN_TIME))
			iIndex = iIndex + PAT_LEN_TIME
			ListRow.Item("ExercTime") = GetTelegramTime(sBody.Substring(iIndex, PAT_LEN_TIME))
			iIndex = iIndex + PAT_LEN_TIME
			ListRow.Item("PayoutRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE

			ListData.Rows.Add(ListRow)
		Next
	End Sub

	'--------------------------------------------------------------------------
	' システム設定情報の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataSysSettings(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("StopTradeTime"))
		ListData.Columns.Add(New DataColumn("StartAbandTime"))
		ListData.Columns.Add(New DataColumn("AbandPriceDiff"))
		ListData.Columns.Add(New DataColumn("Commission"))
		ListData.Columns.Add(New DataColumn("AbandMargine"))
		ListData.Columns.Add(New DataColumn("TradeMoneyMin"))
        ListData.Columns.Add(New DataColumn("TradeLotMin"))
        ListData.Columns.Add(New DataColumn("TradeMoneyMax"))
        ListData.Columns.Add(New DataColumn("TradeLotMax"))
        ListData.Columns.Add(New DataColumn("ProductMoneyMax"))
        ListData.Columns.Add(New DataColumn("ProductLotMax"))
        ListData.Columns.Add(New DataColumn("CustCountMax"))
		ListData.Columns.Add(New DataColumn("CustMoneyMax"))
        ListData.Columns.Add(New DataColumn("CustLotMax"))
        ListData.Columns.Add(New DataColumn("CustProductMoneyMax"))
        ListData.Columns.Add(New DataColumn("CustProductLotMax"))
        ListData.Columns.Add(New DataColumn("CashInMoneyMin"))
		ListData.Columns.Add(New DataColumn("CashInMoneyDayMin"))
		ListData.Columns.Add(New DataColumn("CashOutMoneyMax"))
		ListData.Columns.Add(New DataColumn("CashOutMoneyDayMax"))
		ListData.Columns.Add(New DataColumn("ProductStartPreTime"))
		ListData.Columns.Add(New DataColumn("ProductEndLossTime"))
		ListData.Columns.Add(New DataColumn("RateEnableTime"))
        ListData.Columns.Add(New DataColumn("TimeZone"))
        ListData.Columns.Add(New DataColumn("SysDateTimeZone"))

		iIndex = 0
		ListRow = ListData.NewRow()

		ListRow.Item("StopTradeTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("StartAbandTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("AbandPriceDiff") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("Commission") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
		iIndex = iIndex + PAT_LEN_RATE
		ListRow.Item("AbandMargine") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
		iIndex = iIndex + PAT_LEN_RATE
		ListRow.Item("TradeMoneyMin") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
        ListRow.Item("TradeLotMin") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("TradeMoneyMax") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
        ListRow.Item("TradeLotMax") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("ProductMoneyMax") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
        ListRow.Item("ProductLotMax") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("CustCountMax") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("CustMoneyMax") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
        ListRow.Item("CustLotMax") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("CustProductMoneyMax") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
        ListRow.Item("CustProductLotMax") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("CashInMoneyMin") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
		ListRow.Item("CashInMoneyDayMin") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
		ListRow.Item("CashOutMoneyMax") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
		ListRow.Item("CashOutMoneyDayMax") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_MONEY))
		iIndex = iIndex + PAT_LEN_MONEY
		ListRow.Item("ProductStartPreTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("ProductEndLossTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("RateEnableTime") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("TimeZone") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT
        ListRow.Item("SysDateTimeZone") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
        iIndex = iIndex + PAT_LEN_INT

		ListData.Rows.Add(ListRow)
	End Sub

	'--------------------------------------------------------------------------
	' システムステータス情報の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataSysStatus(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("SysDate"))
		ListData.Columns.Add(New DataColumn("SysEnabled"))
		ListData.Columns.Add(New DataColumn("AbandEnabled"))
		ListData.Columns.Add(New DataColumn("CashOutEnabled"))
		ListData.Columns.Add(New DataColumn("CashInEnabled"))
		ListData.Columns.Add(New DataColumn("RateProviderID"))
		ListData.Columns.Add(New DataColumn("SysUpdateSeq"))

		iIndex = 0
		ListRow = ListData.NewRow()

		ListRow.Item("SysDate") = GetTelegramDate(sBody.Substring(iIndex, PAT_LEN_DATE))
		iIndex = iIndex + PAT_LEN_DATE
		ListRow.Item("SysEnabled") = sBody.Substring(iIndex, 1)
		iIndex = iIndex + 1
		ListRow.Item("AbandEnabled") = sBody.Substring(iIndex, 1)
		iIndex = iIndex + 1
		ListRow.Item("CashOutEnabled") = sBody.Substring(iIndex, 1)
		iIndex = iIndex + 1
		ListRow.Item("CashInEnabled") = sBody.Substring(iIndex, 1)
		iIndex = iIndex + 1
		ListRow.Item("RateProviderID") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT
		ListRow.Item("SysUpdateSeq") = GetTelegramInt(sBody.Substring(iIndex, PAT_LEN_INT))
		iIndex = iIndex + PAT_LEN_INT

		ListData.Rows.Add(ListRow)
	End Sub

	'--------------------------------------------------------------------------
	' 計算パラメータ情報の電文解析
	'--------------------------------------------------------------------------
	Public Sub GetDeliveryDataCalcParam(ByVal sBody As String, ByRef ListData As DataTable)
		Dim iIndex As Integer
		Dim iListCount As Integer
		Dim iListIndex As Integer
		Dim ListRow As DataRow

		ListData = New DataTable
		ListData.Columns.Add(New DataColumn("ComCode"))
        ListData.Columns.Add(New DataColumn("InterestRate"))
        ListData.Columns.Add(New DataColumn("SwapRate"))
        ListData.Columns.Add(New DataColumn("VolatilityAdjust"))
		ListData.Columns.Add(New DataColumn("Volatility"))
		ListData.Columns.Add(New DataColumn("DeltaVariation"))
		ListData.Columns.Add(New DataColumn("GammaVariation"))
		ListData.Columns.Add(New DataColumn("VegaVariation"))
		ListData.Columns.Add(New DataColumn("ThetaVariation"))
		ListData.Columns.Add(New DataColumn("RhoVariation"))

		iListCount = GetTelegramInt(sBody.Substring(0, PAT_LEN_SIZE))
		iIndex = PAT_LEN_SIZE
		For iListIndex = 0 To iListCount - 1
			ListRow = ListData.NewRow()

            ListRow.Item("ComCode") = sBody.Substring(iIndex, 10).Trim()
			iIndex = iIndex + 10
			ListRow.Item("InterestRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
            iIndex = iIndex + PAT_LEN_RATE
            ListRow.Item("SwapRate") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
            iIndex = iIndex + PAT_LEN_RATE
            ListRow.Item("VolatilityAdjust") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
            iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("Volatility") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
            iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("DeltaVariation") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("GammaVariation") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("VegaVariation") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("ThetaVariation") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE
			ListRow.Item("RhoVariation") = GetTelegramDecimal(sBody.Substring(iIndex, PAT_LEN_RATE))
			iIndex = iIndex + PAT_LEN_RATE

			ListData.Rows.Add(ListRow)
		Next

	End Sub

	'--------------------------------------------------------------------------
	' 電文項目解析（Ｉｎｔ）
	'--------------------------------------------------------------------------
	Private Function GetTelegramInt(ByVal sItem As String) As Integer
		Return CInt(sItem)
	End Function

	'--------------------------------------------------------------------------
	' 電文項目解析（Ｄｅｃｉｍａｌ）
	'--------------------------------------------------------------------------
	Private Function GetTelegramDecimal(ByVal sItem As String) As Decimal
		Return CDec(sItem)
	End Function

	'--------------------------------------------------------------------------
	' 電文項目解析（ＤａｔｅＴｉｍｅ文字列）
	'--------------------------------------------------------------------------
	Private Function GetTelegramDateTime(ByVal sItem As String) As String
		Dim sDate As String

		sDate = sItem.Substring(0, 4) & "/" & sItem.Substring(4, 2) & "/" & sItem.Substring(6, 2)
		sDate = sDate & " " & sItem.Substring(8, 2) & ":" & sItem.Substring(10, 2) & ":" & sItem.Substring(12, 2) & "." & sItem.Substring(14, 3)

		Return sDate
	End Function

	'--------------------------------------------------------------------------
	' 電文項目解析（Ｄａｔｅ）
	'--------------------------------------------------------------------------
	Private Function GetTelegramDate(ByVal sItem As String) As String
		Dim sDate As String

		sDate = sItem.Substring(0, 4) & "/" & sItem.Substring(4, 2) & "/" & sItem.Substring(6, 2)

		Return sDate
	End Function

	'--------------------------------------------------------------------------
	' 電文項目解析（Ｔｉｍｅ）
	'--------------------------------------------------------------------------
	Private Function GetTelegramTime(ByVal sItem As String) As TimeSpan
		Dim sTime As String

		sTime = sItem.Substring(0, 2) & ":" & sItem.Substring(2, 2) & ":" & sItem.Substring(4, 2)

		Return TimeSpan.Parse(sTime)
	End Function

	'--------------------------------------------------------------------------
	' 
	'--------------------------------------------------------------------------
	Public Sub ClearTelegram()
		RcvTelegram = Nothing
	End Sub

End Class
