﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsWorkerDeliver
    Private StopSignal As New ManualResetEvent(False)
    Private strServiceName As String
    Private DeliverySocket As clsDeliverySocket
	Private DeliveryTelegram As clsDeliveryTelegram
	Private strServerIP As String
	Private intServerPort As Integer
	Private HeartBeatWatch_S As Stopwatch
    Private ServerDateTime As Date
	Private SendTelegram() As Byte

	Private DeliveryQueue As Queue(Of clsDeliveryObject)		' 差分データＱｕｅｕｅ
	Private TelegramQueue As Queue(Of Byte())					' 差分配信電文Ｑｕｅｕｅ

	'--------------------------------------------------------------------------
	' 配信用データ・フラグ
	'--------------------------------------------------------------------------
	Private DataInitSession As clsDeliveryObject
	Private DataDiffSession As clsDeliveryObject
	Private DataInitProduct As clsDeliveryObject
	Private DataDiffProduct As clsDeliveryObject
	Private DataProductBase As clsDeliveryObject
	Private DataSysSettings As clsDeliveryObject
	Private DataSysStatus As clsDeliveryObject
	Private DataCalcParam As clsDeliveryObject
	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub New()
        strServiceName = "DataDelivery"
        DataInitSession = New clsDeliveryObject(clsDeliveryTelegram.TYPE_INIT_SESSION)
		DataInitProduct = New clsDeliveryObject(clsDeliveryTelegram.TYPE_INIT_PRODUCT)
		DataProductBase = New clsDeliveryObject(clsDeliveryTelegram.TYPE_PRODUCT_BASE)
		DataSysSettings = New clsDeliveryObject(clsDeliveryTelegram.TYPE_SYS_SETTINGS)
		DataSysStatus = New clsDeliveryObject(clsDeliveryTelegram.TYPE_SYS_STATUS)
		DataCalcParam = New clsDeliveryObject(clsDeliveryTelegram.TYPE_CALC_PARAM)
		DataDiffSession = New clsDeliveryObject(clsDeliveryTelegram.TYPE_DIFF_SESSION)
		DataDiffProduct = New clsDeliveryObject(clsDeliveryTelegram.TYPE_DIFF_PRODUCT)
		DeliveryQueue = New Queue(Of clsDeliveryObject)
		TelegramQueue = New Queue(Of Byte())
	End Sub

	'--------------------------------------------------------------------------
	' ワーカースレッドの初期設定
	'--------------------------------------------------------------------------
    Public Sub InitializeWorkerThread(ByVal sServerIP As String, ByVal iServerPort As Integer)
        strServerIP = sServerIP
        intServerPort = iServerPort
        DeliverySocket = New clsDeliverySocket()
        DeliverySocket.Initialize(strServerIP, intServerPort)
        DeliveryTelegram = New clsDeliveryTelegram()
        DeliveryTelegram.Initialize()
    End Sub

	'--------------------------------------------------------------------------
	' ワーカースレッドの初期配信データ設定
	'--------------------------------------------------------------------------
	Public Sub SetInitialDeliveryData(ByVal dtSession As DataTable, ByVal dtProduct As DataTable, ByVal dtProductBase As DataTable, ByVal dtSysSettings As DataTable, ByVal dtSysStatus As DataTable, ByVal dtCalcParam As DataTable)
		DataInitSession.SetDeliveryData(dtSession, True)
		DataInitProduct.SetDeliveryData(dtProduct, True)
		DataProductBase.SetDeliveryData(dtProductBase, True)
		DataSysSettings.SetDeliveryData(dtSysSettings, True)
		DataSysStatus.SetDeliveryData(dtSysStatus, True)
		DataCalcParam.SetDeliveryData(dtCalcParam, True)
	End Sub

    '--------------------------------------------------------------------------
    ' INITデータの配信FLAGをONに設定(初期データ配信)
    ' DIFFデータの配信FLAGをOFFに設定(初期データ配信の為、差分は不要になる)
    '--------------------------------------------------------------------------
	Private Sub SetInitialDeliveryFlag()
		DataDiffSession.ModifiedFlag = False
		DataDiffProduct.ModifiedFlag = False
		'----------------------------------------------------------------------
		' 未送信分の電文を破棄
		' ※差分適用済みのINITデータを再送信するので差分データは不要
		'----------------------------------------------------------------------
		TelegramQueue.Clear()

		'----------------------------------------------------------------------
		' INITデータ再送信フラグON
		'----------------------------------------------------------------------
		DataInitSession.ModifiedFlag = True
		DataInitProduct.ModifiedFlag = True
		DataProductBase.ModifiedFlag = True
		DataSysSettings.ModifiedFlag = True
		DataSysStatus.ModifiedFlag = True
		DataCalcParam.ModifiedFlag = True
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub WorkerThread(ByVal State As Object)
        Dim ARE As ManualResetEvent = CType(State, ManualResetEvent)

		Try
            SystemLog.Information("WorkerThread Start:" & strServerIP & ":" & intServerPort.ToString())
			HeartBeatWatch_S = Stopwatch.StartNew()

			'------------------------------------------------------------------
			' 全初期データの配信フラグをON
			'------------------------------------------------------------------
			SetInitialDeliveryFlag()

			'------------------------------------------------------------------
			' MainAPへソケット接続
			'------------------------------------------------------------------
			DeliverySocket.ConnectDelivery()

            While True
                WorkerProc()
                If StopSignal.WaitOne(My.Settings.WatchInterval) Then Exit While
            End While
			DeliverySocket.DisconnectDelivery()
            SystemLog.Information("WorkerThread:End" & strServerIP & ":" & intServerPort.ToString())
		Catch ex As Exception
			'Logging("WorkerThread Exception:" & ex.Message, EventLogEntryType.Error)
			SystemLog.AppError(ex)
            SystemLog.Information("WorkerThread Exception")
        Finally
            ARE.Set()
        End Try

    End Sub

	'--------------------------------------------------------------------------
	' ワーカースレッドの停止要求(サービス停止)
	'--------------------------------------------------------------------------
	Public Sub StopWorker()
        StopSignal.Set()
	End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
	Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
		Dim eLog As EventLog
		Dim sComMsg As String

		Try
			sComMsg = "(" & strServerIP & ":" & intServerPort.ToString() & ")-" & sMessage
			eLog = New EventLog()
			eLog.Source = strServiceName
			eLog.WriteEntry(sComMsg, entryType)
			eLog = Nothing
            Debug.Print(Format(Now, "MM/dd HH:mm:ss ") & sComMsg)
		Catch ex As Exception
			Debug.Print(ex.Message)
		End Try
	End Sub

	'--------------------------------------------------------------------------
	' 配信検査処理
	' ※実行,周期はWorkerThreadにより制御
	'--------------------------------------------------------------------------
	Private Sub WorkerProc()

        Try
            '----------------------------------------------------------
            ' 差分データＱｕｅｕｅ検査
            '----------------------------------------------------------
            While GetDeliveryQueue()

            End While

            '----------------------------------------------------------
            ' 配信ソケット検査
            '----------------------------------------------------------
            If DeliverySocket.IsConnect() = False Then
                '------------------------------------------------------
                ' ソケットが接続されていなければ(接続不可または切断)
                ' 全初期データの配信フラグをON
                '------------------------------------------------------
                SetInitialDeliveryFlag()
                '------------------------------------------------------
                ' ソケット接続のリトライ
                '------------------------------------------------------
                DeliverySocket.ConnectDelivery()
            End If

            If DeliverySocket.IsConnect() = True Then

                '----------------------------------------------------------
                ' Queue取得差分データを差分配信電文Ｑｕｅｕｅへ登録＆送信
                ' 送信完了時までＱｕｅｕｅでデータ管理
                '----------------------------------------------------------
                If Not SendDeliveryData() Then
                    DeliverySocket.DisconnectDelivery()

                Else
                    '----------------------------------------------------------
                    ' Deliver -> Main ハートビート送信処理
                    '----------------------------------------------------------
                    If HeartBeatWatch_S.ElapsedMilliseconds() >= My.Settings.DeliveryHeartBeat Then
                        SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_HB_DELIVER, Nothing)
                        If Not DeliverySocket.SendTelegram(SendTelegram) Then
                            DeliverySocket.DisconnectDelivery()
                        Else
                        End If
                        HeartBeatWatch_S.Restart()
                    End If
                End If

            End If

            If DeliverySocket.IsConnect() = True Then
                '----------------------------------------------------------
                ' Main -> Deliver 受信処理
                '----------------------------------------------------------
                While True
                    Dim sRecv As String = ""
                    If DeliverySocket.ReciveTelegram(sRecv) = True Then
                        If My.Settings.HeartBeatLog Then
                            SystemLog.Information("WorkerThread Receive:" & sRecv)
                        End If
                    End If
                    If sRecv = "" Then Exit While
                End While

            End If

        Catch ex As Exception
            SystemLog.ExceptionError(ex)
            Logging("WorkerThread Exception:" & ex.Message, EventLogEntryType.Error)
        End Try

	End Sub

	'--------------------------------------------------------------------------
	' Main-Threadより差分データＱｕｅｕｅへデータ追加（SyncLock:Queue）
	'--------------------------------------------------------------------------
	Public Sub AddDeliveryQueue(ByVal sType As String, ByVal DataList As DataTable)
		Dim QueueData As clsDeliveryObject

		SyncLock DeliveryQueue
			QueueData = New clsDeliveryObject(sType)
			QueueData.SetDeliveryData(DataList, False)
			DeliveryQueue.Enqueue(QueueData)
		End SyncLock
	End Sub

	'--------------------------------------------------------------------------
	' 差分データＱｕｅｕｅの取得（SyncLock:Queue)
	'--------------------------------------------------------------------------
	Private Function GetDeliveryQueue() As Boolean
		Dim QueueData As clsDeliveryObject
		Dim bQueue As Boolean

		bQueue = False
		SyncLock DeliveryQueue
			If DeliveryQueue.Count > 0 Then
				QueueData = DeliveryQueue.Dequeue()
				Select Case QueueData.DataType
                    Case clsDeliveryTelegram.TYPE_INIT_SESSION          ' DataDeliver 全件セッション情報
                        DataInitSession.SetDeliveryData(QueueData.DeliveryData, False)  ' 差分適用済みの全件セッション情報
					Case clsDeliveryTelegram.TYPE_INIT_PRODUCT			' DataDeliver 全件銘柄情報
						DataInitProduct.SetDeliveryData(QueueData.DeliveryData, False)	' 差分適用済みの全件銘柄情報
					Case clsDeliveryTelegram.TYPE_DIFF_SESSION			' DataDeliver 差分セッション情報
						DataDiffSession.SetDeliveryData(QueueData.DeliveryData, True)
					Case clsDeliveryTelegram.TYPE_DIFF_PRODUCT			' DataDeliver 差分銘柄情報
						DataDiffProduct.SetDeliveryData(QueueData.DeliveryData, True)
					Case clsDeliveryTelegram.TYPE_PRODUCT_BASE			' DataDeliver 全件銘柄設定情報
						DataProductBase.SetDeliveryData(QueueData.DeliveryData, True)
					Case clsDeliveryTelegram.TYPE_SYS_SETTINGS			' DataDeliver 全件システム設定情報
						DataSysSettings.SetDeliveryData(QueueData.DeliveryData, True)
					Case clsDeliveryTelegram.TYPE_SYS_STATUS			' DataDeliver 全件システムステータス情報
						DataSysStatus.SetDeliveryData(QueueData.DeliveryData, True)
					Case clsDeliveryTelegram.TYPE_CALC_PARAM			' DataDeliver 全件計算パラメタ情報
						DataCalcParam.SetDeliveryData(QueueData.DeliveryData, True)
				End Select
				bQueue = True
			End If
		End SyncLock

		Return bQueue
	End Function

	'--------------------------------------------------------------------------
	' 配信データの電文作成＆配信
	'--------------------------------------------------------------------------
    Private Function SendDeliveryData() As Boolean

        '--------------------------------------------------------------------------
        ' セッション情報配信（全件）
        '--------------------------------------------------------------------------
        If DataInitSession.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_INIT_SESSION, DataInitSession.DeliveryData)
            DataInitSession.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' 銘柄情報配信（全件）
        '--------------------------------------------------------------------------
        If DataInitProduct.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_INIT_PRODUCT, DataInitProduct.DeliveryData)
            DataInitProduct.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' 銘柄設定情報配信（全件）
        '--------------------------------------------------------------------------
        If DataProductBase.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_PRODUCT_BASE, DataProductBase.DeliveryData)
            DataProductBase.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' システム設定情報配信（全件）
        '--------------------------------------------------------------------------
        If DataSysSettings.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_SYS_SETTINGS, DataSysSettings.DeliveryData)
            DataSysSettings.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' システムステータス情報配信（全件）
        '--------------------------------------------------------------------------
        If DataSysStatus.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_SYS_STATUS, DataSysStatus.DeliveryData)
            DataSysStatus.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' 計算パラメタ情報配信（全件）
        '--------------------------------------------------------------------------
        If DataCalcParam.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_CALC_PARAM, DataCalcParam.DeliveryData)
            DataCalcParam.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' セッション情報配信（差分）
        '--------------------------------------------------------------------------
        If DataDiffSession.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_DIFF_SESSION, DataDiffSession.DeliveryData)
            DataDiffSession.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' 銘柄情報配信（差分）
        '--------------------------------------------------------------------------
        If DataDiffProduct.ModifiedFlag = True Then
            SendTelegram = DeliveryTelegram.CreateDeliveryTelegram(clsDeliveryTelegram.TYPE_DIFF_PRODUCT, DataDiffProduct.DeliveryData)
            DataDiffProduct.ModifiedFlag = False
            TelegramQueue.Enqueue(SendTelegram)
        End If

        '--------------------------------------------------------------------------
        ' 配信電文Ｑｕｅｕｅのデータを順次送信（正常送信の間）
        ' 送信エラー時はＱｕｅｕｅにデータを残し、次回に送信トライ
        '--------------------------------------------------------------------------
        Dim bSend As Boolean = True

        While TelegramQueue.Count() > 0
            SendTelegram = TelegramQueue.Peek()
            If DeliverySocket.SendTelegram(SendTelegram) = True Then
                TelegramQueue.Dequeue()
            Else
                bSend = False
                Exit While
            End If
        End While

        Return bSend
    End Function

End Class
