﻿Imports System.IO
Imports System.IO.Path
'------------------------------------------------------------------------------
' 
'------------------------------------------------------------------------------
Public Class clsZipFileSystem
    Private objShellFS As Object

    '--------------------------------------------------------------------------
    ' コンストラクタ
    '--------------------------------------------------------------------------
    Public Sub New()
        objShellFS = CreateObject("Shell.Application")
    End Sub

    '--------------------------------------------------------------------------
    ' 空のＺＩＰファイルを作成
    '--------------------------------------------------------------------------
    Public Sub CreateZipFile(ByVal sZipFileName As String)
        Dim fsZip As FileStream
        Dim b As Byte() = {&H50, &H4B, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        fsZip = File.Create(sZipFileName)
        If IsNothing(fsZip) = False Then
            fsZip.Write(b, 0, b.Length)
            fsZip.Close()
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' ＺＩＰファイルにエントリーを追加
    '--------------------------------------------------------------------------
    Public Function AddZipEntry(ByVal sZipFileName As String, ByRef sFileName As String) As Boolean
        Dim bAddZip As Boolean
        Dim oSourceFolder As Object
        Dim oZipFolder As Object
        Dim oSourceItem As Object
        Dim ZCount As Integer
        Dim WaitTimeWatch As Stopwatch = Nothing '2013-09-18 Add

        bAddZip = True
        Try
            If File.Exists(sFileName) = True Then
                oSourceFolder = objShellFS.NameSpace(GetDirectoryName(sFileName))
                oZipFolder = objShellFS.NameSpace(GetFullPath(sZipFileName))
                oSourceItem = oSourceFolder.ParseName(GetFileName(sFileName))

                ZCount = oZipFolder.Items().Count
                oZipFolder.CopyHere(oSourceItem)
                WaitTimeWatch = Stopwatch.StartNew()    '2013-09-18 Add
                Do While oZipFolder.Items().Count <= ZCount
                    Threading.Thread.Sleep(100)
                    '2013-09-18 Add Start
                    'Zip圧縮タイムアウト判定(20000ミリ秒)
                    If WaitTimeWatch.ElapsedMilliseconds >= My.Settings.ZipTimeOut Then
                        bAddZip = False
                        SystemLog.Information("タイムアウトエラー:" & sFileName)
                        Exit Do
                    End If
                    '2013-09-18 Add End
                Loop
            End If
        Catch ex As Exception
            SystemLog.Information("例外エラー:" & sFileName)
            SystemLog.ExceptionError(ex)
            bAddZip = False
        Finally
            If Not IsNothing(WaitTimeWatch) Then
                WaitTimeWatch.Stop()
                WaitTimeWatch = Nothing
            End If
        End Try

        Return bAddZip
    End Function

End Class
