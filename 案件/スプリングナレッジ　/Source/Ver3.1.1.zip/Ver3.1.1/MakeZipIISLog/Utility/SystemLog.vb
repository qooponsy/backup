﻿Imports System.Threading

Public Class SystemLog
	Private Const EVENT_SOURCE As String = "LionBO"
    Private Const ALERT_MESSAGE As String = "MakeZipIISLog ALERT:"
    Public Shared Sub InitConsoleApp()
        AddHandler AppDomain.CurrentDomain.UnhandledException, AddressOf ApplicationUnhandledException
    End Sub

    'UnhandledExceptionイベントハンドラ
    Private Shared Sub ApplicationUnhandledException(ByVal sender As Object, ByVal e As UnhandledExceptionEventArgs)
        Try
            EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE & "Error Process """ & My.Settings.ProcessID & """", EventLogEntryType.Error)
            Dim ex As Exception = CType(e.ExceptionObject, Exception)
            ExceptionError(ex)
        Finally
            End
        End Try
    End Sub

    Public Shared Sub AppError(ex As Exception)
        EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE & "Error Process """ & My.Settings.ProcessID & """", EventLogEntryType.Error)
        ExceptionError(ex)
    End Sub

    Public Shared Sub Information(Msg As String)
        EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Information)
    End Sub

    Public Shared Sub ErrorInfo(AlertMsg As String, Msg As String)
        EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE & "Error Process """ & My.Settings.ProcessID & """ " & AlertMsg, EventLogEntryType.Error)
        EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Warning)
    End Sub

    Public Shared Sub ExceptionError(ex As Exception)
        Dim objErr As Exception = ex
        While (objErr IsNot Nothing)
            Dim st As StackTrace = New StackTrace(3, True)
            EventLog.WriteEntry(EVENT_SOURCE,
                                "PROCESS:" & My.Settings.ProcessID & vbCrLf &
                                "SOURCE:" & objErr.Source & vbCrLf &
                                "MESSAGE:" & objErr.Message & vbCrLf &
                                "TARGET SITE:" & If(Not objErr.TargetSite Is Nothing, objErr.TargetSite.ToString(), "") & vbCrLf &
                                "STACK TRACE:" & If(Not objErr.StackTrace Is Nothing, vbCrLf & objErr.StackTrace.ToString(), "") & vbCrLf & st.ToString(),
                                EventLogEntryType.Warning)
            objErr = objErr.InnerException
        End While
    End Sub

End Class
