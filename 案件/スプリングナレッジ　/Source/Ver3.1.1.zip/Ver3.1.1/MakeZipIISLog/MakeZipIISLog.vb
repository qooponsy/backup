﻿Imports System.IO
Imports System.Text
'------------------------------------------------------------------------------
' Logを圧縮保存する機能
'   対象は前日までのLogファイル(毎週実施され1週間分の圧縮ファイルが作成される想定)
'   圧縮保存対象の元ファイルは削除される
'=================
'2014/04/28
'処理中に原因不明のエラーが発生する
'	(a)ZIPファイルがみつからないか、ファイルが空です。
'		⇒問題無し、発生しても作成されるZipファイルは正常
'	(b)ファイルが見つからないか、読み取りのアクセス許可がありません。
'		⇒再処理対応で問題無し(My.Settings.AddZipEntryTryLimitの回数(とりあえず9)まで再処理を行うようにしている)
'=================
'2014/04/28
'TestMode
'   ・Logファイルの削除を行わない
'   ・処理回数Logの出力
'------------------------------------------------------------------------------
Module MakeZipIISLog
    '--------------------------------------------------------------------------
    ' Main
    '--------------------------------------------------------------------------
    Sub Main()
        SystemLog.InitConsoleApp()

        ' Settings.WorkDateが設定されている場合は優先(Rerun対策)
        Dim dtSystemDate As Date
        If My.Settings.WorkDate <> "" Then
            dtSystemDate = Date.Parse(My.Settings.WorkDate)
        Else
            Dim dtNow As Date = Date.Now
            dtSystemDate = New Date(dtNow.Year, dtNow.Month, dtNow.Day)
        End If

        '出力対象日付作成
        Dim dtDateTo As Date = dtSystemDate
        'フォルダ(ZIPファイル)名称作成(取得するLog日付)
        Dim sZipFileName As String = dtDateTo.ToString("yyyyMMdd")

        'Zip対象Logフォルダと、Zipファイルを削除
        CleanFile(sZipFileName)

        '圧縮対象Logファイル準備
        SetLogFile(sZipFileName, dtDateTo)

        'ZIP圧縮
        CreateZip(sZipFileName)

        '圧縮ファイル作成用Logフォルダ削除
        DelLogFile(sZipFileName)
    End Sub

    ''' <summary>
    ''' Zip対象Logフォルダと、Zipファイルを削除
    ''' 【TestMode：Zipファイルのみ削除】
    ''' </summary>
    ''' <param name="sZipFileName">Zipファイル名</param>
    ''' <remarks></remarks>
    Private Sub CleanFile(ByVal sZipFileName As String)
        Dim sFolderName As String

        'Zip対象Logフォルダ削除
        If Not (My.Settings.TestMode) Then
            sFolderName = My.Settings.OutputPathZIP & sZipFileName & "\"
            If Directory.Exists(sFolderName) Then
                Directory.Delete(sFolderName, True)
            End If
        End If

        'Zipファイル削除
        Dim sFileNameZip As String
        sFileNameZip = My.Settings.OutputPathZIP & sZipFileName & ".zip"
        If File.Exists(sFileNameZip) Then
            File.Delete(sFileNameZip)
        End If
    End Sub

    ''' <summary>
    ''' 圧縮対象Logファイル準備
    ''' 【TestMode：処理なし】
    ''' </summary>
    ''' <param name="sZipFileName">作成フォルダ名称</param>
    ''' <param name="dtDateTo">対象条件ファイル日付(これ以前の更新日時ファイルが対象となる)</param>
    ''' <remarks></remarks>
    Private Sub SetLogFile(ByVal sZipFileName As String, ByVal dtDateTo As Date)
        If Directory.Exists(My.Settings.FilePathLog) Then
            '圧縮用ディレクトリ作成
            Dim sFolderName As String = My.Settings.OutputPathZIP & sZipFileName & "\"
            If Not Directory.Exists(sFolderName) Then
                Directory.CreateDirectory(sFolderName)
            End If

            '圧縮用ディレクトリへファイル移動
            For Each sTmpFileName In Directory.GetFiles(My.Settings.FilePathLog, "*.log")
                If File.GetLastWriteTime(sTmpFileName) <= dtDateTo.AddMinutes(1) Then
                    File.Move(sTmpFileName, sFolderName & Replace(sTmpFileName, My.Settings.FilePathLog, ""))
                End If
            Next
        End If
    End Sub

    ''' <summary>
    ''' Zipファイル作成用Logフォルダ削除
    ''' 【TestMode：処理なし】
    ''' </summary>
    ''' <param name="sFileName">Zipファイル名称</param>
    ''' <remarks></remarks>
    Private Sub DelLogFile(ByVal sFileName As String)
        If Not (My.Settings.TestMode) Then
            Dim sFolderName As String = My.Settings.OutputPathZIP & sFileName & "\"
            If Directory.Exists(sFolderName) Then
                Directory.Delete(sFolderName, True)
            End If
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' ZIP圧縮
    '--------------------------------------------------------------------------
    Private Sub CreateZip(ByVal sWorkDate As String)
        Dim zipFS As clsZipFileSystem
        Dim sFileNameZip As String
        Dim sFolderName As String
        Dim iAddZipEntryCnt As Integer
        Dim bAddZipEntryResult As Boolean

        sFolderName = My.Settings.OutputPathZIP & sWorkDate & "\"
        If Directory.Exists(sFolderName) Then
            zipFS = New clsZipFileSystem

            sFileNameZip = My.Settings.OutputPathZIP & sWorkDate & ".zip"

            zipFS.CreateZipFile(sFileNameZip)
            For Each sTmpFileName In Directory.GetFiles(sFolderName, "*.log")
                iAddZipEntryCnt = 0
                bAddZipEntryResult = False
                Do
                    '処理回数判定
                    iAddZipEntryCnt = iAddZipEntryCnt + 1
                    If iAddZipEntryCnt > My.Settings.AddZipEntryTryLimit Then
                        'ファイル追加処理が実施上限を超えた場合エラーとして扱う
                        Exit For
                    End If
                    '--
                    'debugMode時の判定用
                    If My.Settings.TestMode Then
                        Dim sTemp As String = sTmpFileName & ("  処理回数：" & iAddZipEntryCnt)
                        If iAddZipEntryCnt = 1 Then
                            Debug.Print(sTemp)
                        Else
                            Debug.Print(sTemp & "▲")
                        End If
                    End If
                    '--
                    'Zipにファイル追加
                    bAddZipEntryResult = zipFS.AddZipEntry(sFileNameZip, sTmpFileName)

                Loop Until bAddZipEntryResult
            Next
        End If
    End Sub

End Module
