﻿Public Class document
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim SessionKey As String = ""
        Dim CustCode As String = ""

        Dim cookie As HttpCookie = Request.Cookies("index")
        Dim token As String = ""

        Do
            If Not cookie Is Nothing Then
                token = cookie.Values("key").ToString
            End If
            If token Is Nothing AndAlso token.Length <> 32 Then
                Response.Redirect("error.aspx")
            Else
                'セッション認証
                If Not AuthSession.CheckSession(AuthSession.AuthTypeCode.Web, token, CustCode) Then
                    Response.Redirect("error.aspx")
                End If

                If Request.HttpMethod = "POST" Then

                    Dim chk1 As Boolean = Request("childcheck1")
                    Dim chk2 As Boolean = Request("childcheck2")
                    Dim chk3 As Boolean = Request("childcheck3")
                    Dim chk4 As Boolean = Request("childcheck4")

                    If chk1 And chk2 And chk3 And chk4 Then

                        'DB更新
                        If Not CustDocs.Update(CustCode) Then
                            Response.Redirect("error.aspx")
                        End If

                        If Not AuthSession.CreateSession(AuthSession.AuthTypeCode.FXIF, CustCode, "81", "", SessionKey) Then
                            Response.Redirect("error.aspx")
                        End If

                        '送られてきたセッション削除
                        If Not AuthSession.DeleteOneTimeSession(AuthSession.AuthTypeCode.Web, token) Then
                            Response.Redirect("error.aspx")
                        End If

                        Response.Redirect(My.Settings.ClientURL & "?token=" & SessionKey)

                    End If
                    Response.Redirect("document.aspx")
                End If
            End If
        Loop While False

    End Sub

End Class