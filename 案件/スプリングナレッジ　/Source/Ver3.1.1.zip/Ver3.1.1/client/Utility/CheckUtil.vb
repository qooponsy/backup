﻿Imports System.Security.Cryptography

Public Class CheckUtil

    Public Shared RegExMoney As New Regex("^\d{1,11}(\.\d{1,4}){0,1}$")
    Public Shared RegExMoney0 As New Regex("^\d{1,11}(\.0{1,4}){0,1}$")
    Public Shared RegExMoney1 As New Regex("^\d{1,11}(\.\d{1,1}){0,1}0{0,1}$")
    Public Shared RegExMoney2 As New Regex("^\d{1,11}(\.\d{1,2}){0,1}0{0,2}$")
    Public Shared RegExMoney3 As New Regex("^\d{1,11}(\.\d{1,3}){0,1}0{0,3}$")
    Public Shared RegExMoney4 As New Regex("^\d{1,11}(\.\d{1,4}){0,1}$")

    Public Shared Function CheckMoney(Value As String, DecimalPlaces As Integer) As Boolean
        Dim ret As Boolean = False
        Select Case DecimalPlaces
            Case 0 : ret = RegExMoney0.IsMatch(Value)
            Case 1 : ret = RegExMoney1.IsMatch(Value)
            Case 2 : ret = RegExMoney2.IsMatch(Value)
            Case 3 : ret = RegExMoney3.IsMatch(Value)
            Case 4 : ret = RegExMoney4.IsMatch(Value)
        End Select
        Return ret
    End Function

    Public Shared Function SetQueryParam(QueryList As List(Of KeyValuePair(Of String, String)), Request As HttpRequestBase, Name As String) As String
        Dim Value As String = Request(Name)
        QueryList.Add(New KeyValuePair(Of String, String)(Name, Value))
        Return Value
    End Function

End Class
