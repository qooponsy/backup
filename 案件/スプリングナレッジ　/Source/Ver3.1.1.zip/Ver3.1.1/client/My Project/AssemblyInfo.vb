﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は、以下の属性セットによって 
' 制御されます。 アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。

' アセンブリの属性値を確認します
<Assembly: AssemblyTitle("client")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("client")> 
<Assembly: AssemblyCopyright("Copyright ©  2013")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

' このプロジェクトが COM に公開される場合、次の GUID が typelib の ID になります
<Assembly: Guid("c71b68b5-26c9-49a9-8677-aa974f8d1afc")> 

' アセンブリのバージョン情報は、次の 4 つの値で構成されます:
'
'      メジャー バージョン
'      マイナー バージョン 
'      ビルド番号
'      リビジョン
'
' すべての値を指定するか、下のように '*' を使ってビルドおよびリビジョン番号を 
' 既定値にすることができます。
' <アセンブリ: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
