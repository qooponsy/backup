﻿Imports System.Data.SqlClient

Public Class CustDocs

    Public Shared Function AgreeCheck(ByVal custCode As String, ByRef agree As Integer) As Boolean
        Dim ret As Boolean = False

        Try
            Using con As New SqlConnection(My.Settings.DB)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    Dim SQL As New StringBuilder
                    SQL.AppendLine("select [Agree] from [M_CustDocs] where CustCode = @CustCode")
                    cmd.CommandText = SQL.ToString()
                    cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = custCode

                    Dim retAgree As Object = cmd.ExecuteScalar()

                    If retAgree Is Nothing OrElse IsDBNull(retAgree) Then
                        SystemLog.ErrorMAIL("AgreeCheck", "書面同意フラグの取得に失敗")
                        Exit Try
                    End If

                    agree = CType(retAgree, Integer)

                End Using
            End Using

            SystemLog.DBSuccess()
            ret = True
        Catch ex As Exception
            SystemLog.DBError(ex)
        End Try

        Return ret
    End Function

    Public Shared Function Update(ByVal CustCode As String) As Boolean
        Dim ret As Boolean = False

        Try
            Using con As New SqlConnection(My.Settings.DB)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    Dim SQL As New StringBuilder
                    SQL.AppendLine("Update [M_CustDocs] set [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@ProcUser, [AgreeDate]=SYSUTCDATETIME(),[Agree]=1 where [CustCode]=@CustCode")
                    cmd.CommandText = SQL.ToString()
                    cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = CustCode
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "1:" + CustCode
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            ret = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
        End Try
        
        Return ret
    End Function

End Class
