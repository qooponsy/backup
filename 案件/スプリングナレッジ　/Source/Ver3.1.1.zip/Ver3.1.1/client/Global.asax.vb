﻿Imports System.Web.SessionState

Public Class Global_asax
    Inherits System.Web.HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' アプリケーションの起動時に呼び出されます。
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' セッションの開始時に呼び出されます。
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' 各要求の開始時に呼び出されます。
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' 使用の認証時に呼び出されます。
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' エラーの発生時に呼び出されます。
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' セッションの終了時に呼び出されます。
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' アプリケーションの終了時に呼び出されます。
    End Sub

    Private Sub Global_asax_BeginRequest(sender As Object, e As System.EventArgs) Handles Me.BeginRequest
        Dim fullOrigionalpath As String = Request.Url.ToString()
        Dim array() As String = Split(fullOrigionalpath, "?")

        If array(0).ToLower().EndsWith(".html") Then
            Dim sUrl As String = array(0).Substring(0, array(0).Length - 4)
            sUrl &= "aspx"                                      '拡張子をaspxに変更。

            sUrl = sUrl.Substring(sUrl.IndexOf("//") + 2)       '最初のhttp://までを除去
            sUrl = sUrl.Substring(sUrl.IndexOf("/"))            '次のwww.hostname.comまでを除去

            If array.Length > 1 Then
                sUrl &= "?" & array(1)            'クエリーストリングがあれば最後に付加
            End If

            Context.RewritePath(sUrl)
        End If
    End Sub
End Class