﻿Public Class index
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'リクエストパラメータ
        Dim reqToken As String = Request("token")

        Dim agree As New Integer
        Dim Destination As mode = mode.err
        Dim SessionKey As String = ""
        Dim CustCode As String = ""
        Dim tokenFlg As Boolean = False

        Do
            '認証トークンチェック
            If reqToken Is Nothing Then
                Destination = mode.None
                Exit Do
            End If
            If reqToken.Length <> 32 Then
                Destination = mode.None
                tokenFlg = True
                Exit Do
            End If

            '認証
            If Not AuthSession.CheckOneTimeSession(AuthSession.AuthTypeCode.FXIF, reqToken, CustCode) Then
                Destination = mode.None
                tokenFlg = True
                Exit Do
            End If

            '同意チェック
            If Not CustDocs.AgreeCheck(CustCode, agree) Then
                Exit Do
            End If

            Destination = mode.success

        Loop While False

        If Destination = mode.err Then
            'エラー画面
            Response.Redirect("error.aspx")
        ElseIf Destination = mode.None Then
            '委託者クライアントログイン画面
            If tokenFlg Then
                Response.Redirect(My.Settings.ClientURL & "?token=")
            Else
                Response.Redirect(My.Settings.ClientURL)
            End If
        ElseIf Destination = mode.success Then
            Do
                If agree = 1 Then
                    'セッション作成
                    If Not AuthSession.CreateSession(AuthSession.AuthTypeCode.FXIF, CustCode, "81", "", SessionKey) Then
                        Exit Do
                    End If

                    '委託者クライアント
                    Response.Redirect(My.Settings.ClientURL & "?token=" & SessionKey)
                ElseIf agree = 0 Then
                    'セッション作成
                    If Not AuthSession.CreateSession(AuthSession.AuthTypeCode.Web, CustCode, "71", "", SessionKey) Then
                        Exit Do
                    End If

                    '同意書面
                    'SessionKeyをクッキーに設定
                    Dim cookie As New HttpCookie("index")
                    cookie.Values("key") = SessionKey
                    Response.SetCookie(cookie)
                    Response.Redirect("document.aspx")
                End If
            Loop While False

            Response.Redirect("error.aspx")
        End If
    End Sub

    Private Enum mode
        success
        err
        None
    End Enum

End Class