﻿Module DeleteEventSource

    Sub Main(ByVal CmdArgs() As String)
        Dim eventSourceName As String

        If CmdArgs.Length = 0 Then
            Console.WriteLine("イベントソース名を指定してください")
            Exit Sub
        Else
            eventSourceName = CmdArgs(0)
            If EventLog.SourceExists(eventSourceName) Then
                EventLog.DeleteEventSource(eventSourceName)
                Console.WriteLine("イベントソース削除:{0}", New Object() {eventSourceName})
                Exit Sub
            Else
                Console.WriteLine("イベントソース名:{0}は存在しません", New Object() {eventSourceName})
            End If
        End If
    End Sub

End Module
