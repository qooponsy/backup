﻿Imports System.Data.SqlClient

Public Class DayStart

    Public Shared Function SystemCheck(
                                      ByRef WeekdayCheck As Boolean,
                                      ByRef HolidayCheck As Boolean
                                      ) As Boolean
        Dim NowDateTime As DateTime
        Dim NowDate As DateTime
        Dim NowWeekday As Integer

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_SystemCheck
                    Dim param As SqlParameter
                    param = cmd.Parameters.Add("@NowDateTime", SqlDbType.DateTime2, 7)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@NowDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@NowWeekday", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@WeekdayCheck", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@HolidayCheck", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output

                    cmd.ExecuteNonQuery()

                    NowDateTime = cmd.Parameters("@NowDateTime").Value
                    NowDate = cmd.Parameters("@NowDate").Value
                    NowWeekday = cmd.Parameters("@NowWeekday").Value
                    WeekdayCheck = (cmd.Parameters("@WeekdayCheck").Value = 1)
                    HolidayCheck = (cmd.Parameters("@HolidayCheck").Value = 1)
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public Shared Function DayStartCheck(
                                      ByRef NowDate As DateTime,
                                      ByRef SysDate As DateTime,
                                      ByRef ProductCount As integer
                                      ) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_DayStartCheck
                    Dim param As SqlParameter
                    param = cmd.Parameters.Add("@NowDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@SysDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@ProductCount", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output

                    cmd.ExecuteNonQuery()

                    NowDate = cmd.Parameters("@NowDate").Value
                    SysDate = cmd.Parameters("@SysDate").Value
                    ProductCount = cmd.Parameters("@ProductCount").Value
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
