﻿Public Class LogUtil

    Public Const EVENT_SOURCE As String = "LionBO"
    Public Const PROCESS_NAME As String = "FXIF"
    Public Const KEY_INFO As String = "LionBO INFO:"

    Public Shared Sub Information(Msg As String)
        EventLog.WriteEntry(EVENT_SOURCE, KEY_INFO & "[" & PROCESS_NAME & "] " & Msg, EventLogEntryType.Information)
    End Sub

End Class
