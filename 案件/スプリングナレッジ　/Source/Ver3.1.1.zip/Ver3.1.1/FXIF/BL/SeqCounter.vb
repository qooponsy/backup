﻿Imports System.Data.SqlClient

Public Class SeqCounter

    Public Class SeqCounterCode
        Public Const Cash As String = "06"
    End Class

    Public Shared Function GetSeqSysDate(ByVal code As String) As String
        Dim result As String

        Using con As New SqlConnection(My.Settings.DB)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                cmd.CommandText = _
                    "declare @Counter int" & vbCrLf & _
                    "begin tran" & vbCrLf & _
                    "select" & vbCrLf & _
                    "	 @Counter = [Counter]" & vbCrLf & _
                    "	from [S_Counter] with (updlock)" & vbCrLf & _
                    "	where [CounterCode] = @CounterCode" & vbCrLf & _
                    "update [S_Counter] set" & vbCrLf & _
                    "	 [Counter] = @Counter + 1" & vbCrLf & _
                    "	where [CounterCode] = @CounterCode" & vbCrLf & _
                    "select" & vbCrLf & _
                    "	 convert(char(8), [SysDate], 112)" & vbCrLf & _
                    "	 + replicate('0' ,9 - len(@Counter))" & vbCrLf & _
                    "	 + convert(varchar(9),@Counter)" & vbCrLf & _
                    "	from [S_SysStatus] " & vbCrLf & _
                    "	where [SysCode] = '0'" & vbCrLf & _
                    "commit tran"
                cmd.Parameters.Add("@CounterCode", SqlDbType.Char, 2).Value = code
                result = cmd.ExecuteScalar()
            End Using
        End Using

        Return result
    End Function

End Class
