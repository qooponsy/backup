﻿Imports System.Threading
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Security.Cryptography

Public Class AuthSession

    Public Class AuthTypeCode
        ''' <summary>
        ''' 管理者認証
        ''' </summary>
        ''' <remarks></remarks>
        Public Const Admin As String = "0"
        ''' <summary>
        ''' 委託者認証
        ''' </summary>
        ''' <remarks></remarks>
        Public Const Cust As String = "1"
        ''' <summary>
        ''' FXIF認証
        ''' </summary>
        ''' <remarks></remarks>
        Public Const FXIF As String = "2"
    End Class

    Public Shared Function CreateSession(ByVal AuthType As String, ByVal UserID As String, ByVal ClientType As String, ByVal ClientVersion As String) As String
        Dim sessionKey As String = createSessionKey(UserID)

        Using con As New SqlConnection(My.Settings.DB)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                cmd.CommandText = "insert into S_Session values(SYSUTCDATETIME(), @InsUser, SYSUTCDATETIME(), @InsUser, @SessionKey, @AuthType, @UserID, @ClientType, @ClientVersion, SYSUTCDATETIME(), 0, '', '')"
                cmd.Parameters.Add("@InsUser", SqlDbType.VarChar, 34).Value = AuthType + ":" + UserID
                cmd.Parameters.Add("@SessionKey", SqlDbType.Char, 32).Value = sessionKey
                cmd.Parameters.Add("@AuthType", SqlDbType.Char, 1).Value = AuthType
                cmd.Parameters.Add("@UserID", SqlDbType.VarChar, 32).Value = UserID
                cmd.Parameters.Add("@ClientType", SqlDbType.Char, 2).Value = ClientType
                cmd.Parameters.Add("@ClientVersion", SqlDbType.VarChar, 32).Value = ClientVersion
                cmd.ExecuteNonQuery()
            End Using
        End Using

        Return sessionKey
    End Function

    Public Shared Function CheckOneTimeSession(ByVal AuthType As String, ByVal SessionKey As String, ByRef CustCode As String) As Boolean
        Using con As New SqlConnection(My.Settings.DB)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                Dim SQL As New StringBuilder
                SQL.AppendLine("select @CustCode=[UserID] from [S_Session] where [SessionKey]=@SessionKey and [AuthType]=@AuthType and DATEADD(SECOND, @EnableTime, [LastCheckTime])>SYSUTCDATETIME()")
                SQL.AppendLine("delete [S_Session] where [SessionKey]=@SessionKey and [AuthType]=@AuthType")
                cmd.CommandText = SQL.ToString()
                Dim param As SqlParameter
                cmd.Parameters.Add("@AuthType", SqlDbType.Char, 1).Value = AuthType
                param = cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32)
                param.Direction = ParameterDirection.Output
                cmd.Parameters.Add("@SessionKey", SqlDbType.NVarChar, 32).Value = SessionKey
                cmd.Parameters.Add("@EnableTime", SqlDbType.Int).Value = My.Settings.OneTimeTokenEnableTime
                cmd.ExecuteNonQuery()

                Dim CustCodeValue As Object = cmd.Parameters("@CustCode").Value
                If CustCodeValue Is Nothing OrElse IsDBNull(CustCodeValue) Then
                    Return False
                End If
                CustCode = CustCodeValue
            End Using
        End Using
        Return True
    End Function

    Private Const SESSIONKEY_MAGIC_CODE = "T/'uN[>a/<]Y(\5.+vYod!ac\1zEh$U6"

    Private Shared Function createSessionKey(ByVal UserID As String) As String
        Dim keyBase As String = _
            Stopwatch.GetTimestamp().ToString() & _
            Now.ToString("ffffffssmmhhddMMyyyy") & _
            UserID & _
            Environment.MachineName & _
            Thread.CurrentThread.ManagedThreadId.ToString() & _
            SESSIONKEY_MAGIC_CODE
        Debug.Print(keyBase)
        Dim data As Byte() = Encoding.UTF8.GetBytes(keyBase)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim bs As Byte() = md5.ComputeHash(data)
        Dim hex As New StringBuilder()
        For Each b In bs
            hex.Append(b.ToString("x2"))
        Next
        Return hex.ToString()
    End Function

End Class
