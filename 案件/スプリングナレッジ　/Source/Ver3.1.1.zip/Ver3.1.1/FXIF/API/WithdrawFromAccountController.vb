﻿Imports System.IO
Imports System.Text
Imports System.Web
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json

Namespace FXIF
    Public Class WithdrawFromAccountController
        Implements IController

        Public Sub Execute(requestContext As System.Web.Routing.RequestContext) Implements System.Web.Mvc.IController.Execute
            Dim Request As HttpRequestBase = requestContext.HttpContext.Request
            Dim Response As HttpResponseBase = requestContext.HttpContext.Response

            Dim QueryList As New List(Of KeyValuePair(Of String, String))
            Dim reqOperatorName As String = CheckUtil.SetQueryParam(QueryList, Request, "operatorName")
            Dim reqTraderID As String = CheckUtil.SetQueryParam(QueryList, Request, "traderID")
            Dim reqAmount As String = CheckUtil.SetQueryParam(QueryList, Request, "amount")
            Dim reqTimestamp As String = CheckUtil.SetQueryParam(QueryList, Request, "timestamp")
            Dim reqCRC As String = Request("CRC")

            Dim success As Boolean = False
            Dim returnCode As Integer
            Dim description As String

            Do
                If reqCRC Is Nothing OrElse reqCRC.Length = 0 Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If Not CheckUtil.CheckCRC(QueryList, reqCRC) Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If reqTraderID Is Nothing OrElse reqTraderID.Length = 0 OrElse reqTraderID.Length > 32 Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If reqAmount Is Nothing OrElse reqAmount.Length = 0 Then
                    returnCode = 2
                    description = "RequiredFieldMissing"
                    Exit Do
                End If

                If Not CheckUtil.RegExMoney.IsMatch(reqAmount) Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                Dim amount As Decimal
                If Not Decimal.TryParse(reqAmount, amount) Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                Using con As New SqlConnection(My.Settings.DB)
                    con.Open()

                    Dim CurCode As String = ""
                    Using cmd As SqlCommand = con.CreateCommand
                        cmd.CommandText = "select * from [M_Customer] where [CustCode]=@CustCode"
                        cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                        Using reader As SqlDataReader = cmd.ExecuteReader()
                            If Not reader.Read() Then
                                returnCode = 1
                                description = "No account was found with given id"
                                Exit Do
                            End If
                            CurCode = reader("CurCode")
                        End Using
                    End Using

                    Dim DecimalPlaces As Integer = 0
                    Using cmd As SqlCommand = con.CreateCommand
                        cmd.CommandText = "select * from [M_Currency] where [CurCode]=@CurCode"
                        cmd.Parameters.Add("@CurCode", SqlDbType.VarChar, 3).Value = CurCode
                        Using reader As SqlDataReader = cmd.ExecuteReader()
                            If Not reader.Read() Then
                                returnCode = 1
                                description = "No account was found with given id"
                                Exit Do
                            End If
                            DecimalPlaces = reader("DecimalPlaces")
                        End Using
                    End Using

                    If Not CheckUtil.CheckMoney(reqAmount, DecimalPlaces) Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    Dim CashCode As String = SeqCounter.GetSeqSysDate(SeqCounter.SeqCounterCode.Cash)

                    Using cmd As SqlCommand = con.CreateCommand
                        cmd.CommandText = My.Resources.SQL_Cash
                        Dim param As SqlParameter
                        param = cmd.Parameters.Add("@ErrorCode", SqlDbType.Int)
                        param.Direction = ParameterDirection.Output
                        cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                        cmd.Parameters.Add("@CashCode", SqlDbType.Char, 17).Value = CashCode
                        cmd.Parameters.Add("@CashType", SqlDbType.Char, 2).Value = "02"
                        cmd.Parameters.Add("@CurCode", SqlDbType.VarChar, 3).Value = CurCode
                        param = cmd.Parameters.Add("@Amount", SqlDbType.Decimal)
                        param.Precision = 15
                        param.Scale = 4
                        param.Value = -amount
                        cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                        cmd.ExecuteNonQuery()

                        Dim ErrorCode As Integer = cmd.Parameters("@ErrorCode").Value
                        If ErrorCode = -1 Then
                            returnCode = 10
                            description = "Amount requested for debit is higher than the amount of money in account"
                            Exit Do
                        End If
                        If ErrorCode <> 0 Then
                            returnCode = 100
                            description = "Unknown error"
                            Exit Do
                        End If

                    End Using
                End Using

                returnCode = 0
                description = "Successful call"
                success = True
            Loop While False

            Dim res As New WithdrawFromAccountJsonData
            Dim serializer As New DataContractJsonSerializer(GetType(WithdrawFromAccountJsonData))

            res.returnCode = returnCode
            res.description = description

            If success Then

            End If

            Dim ms As New MemoryStream
            serializer.WriteObject(ms, res)
            ms.Position = 0
            Dim sr As New StreamReader(ms)
            Response.ContentType = "application/json"
            Response.Charset = "utf-8"
            Response.Write(sr.ReadToEnd())
        End Sub

    End Class
End Namespace