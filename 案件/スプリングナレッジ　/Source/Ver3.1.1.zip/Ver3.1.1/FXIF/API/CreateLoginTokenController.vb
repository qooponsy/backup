﻿Imports System.IO
Imports System.Text
Imports System.Web
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json

Namespace FXIF
    Public Class CreateLoginTokenController
        Implements IController

        Public Sub Execute(requestContext As System.Web.Routing.RequestContext) Implements System.Web.Mvc.IController.Execute
            Dim Request As HttpRequestBase = requestContext.HttpContext.Request
            Dim Response As HttpResponseBase = requestContext.HttpContext.Response


            Dim QueryList As New List(Of KeyValuePair(Of String, String))
            Dim reqOperatorName As String = CheckUtil.SetQueryParam(QueryList, Request, "operatorName")
            Dim reqTraderID As String = CheckUtil.SetQueryParam(QueryList, Request, "traderID")
            Dim reqTimestamp As String = CheckUtil.SetQueryParam(QueryList, Request, "timestamp")
            Dim reqCRC As String = Request("CRC")

            Dim success As Boolean = False
            Dim returnCode As Integer
            Dim description As String
            Dim token As String = ""

            Do
                If reqCRC Is Nothing OrElse reqCRC.Length = 0 Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If Not CheckUtil.CheckCRC(QueryList, reqCRC) Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If reqTraderID Is Nothing OrElse reqTraderID.Length = 0 OrElse reqTraderID.Length > 32 Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                Using con As New SqlConnection(My.Settings.DB)
                    con.Open()
                    Using cmd As SqlCommand = con.CreateCommand
                        cmd.CommandText = "select * from [M_Customer] where [CustCode]=@CustCode"
                        cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                        Using reader As SqlDataReader = cmd.ExecuteReader()
                            If Not reader.Read() Then
                                returnCode = 1
                                description = "No account was found with given id"
                                Exit Do
                            End If
                        End Using
                    End Using

                    token = AuthSession.CreateSession(AuthSession.AuthTypeCode.FXIF, reqTraderID, "81", "")
                End Using

                returnCode = 0
                description = "Successful call"
                success = True
            Loop While False

            Dim res As New CreateLoginTokenJsonData
            Dim serializer As New DataContractJsonSerializer(GetType(CreateLoginTokenJsonData))

            res.returnCode = returnCode
            res.description = description

            If success Then
                res.token = token
            End If

            Dim ms As New MemoryStream
            serializer.WriteObject(ms, res)
            ms.Position = 0
            Dim sr As New StreamReader(ms)
            Response.ContentType = "application/json"
            Response.Charset = "utf-8"
            Response.Write(sr.ReadToEnd())
        End Sub
    End Class
End Namespace