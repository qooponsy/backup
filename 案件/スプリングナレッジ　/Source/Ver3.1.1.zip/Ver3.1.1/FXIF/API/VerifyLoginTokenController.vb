﻿Imports System.IO
Imports System.Text
Imports System.Web
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json

Namespace FXIF
    Public Class VerifyLoginTokenController
        Implements IController

        Public Sub Execute(requestContext As System.Web.Routing.RequestContext) Implements System.Web.Mvc.IController.Execute
            Dim Request As HttpRequestBase = requestContext.HttpContext.Request
            Dim Response As HttpResponseBase = requestContext.HttpContext.Response

            Dim QueryList As New List(Of KeyValuePair(Of String, String))
            Dim reqOperatorName As String = CheckUtil.SetQueryParam(QueryList, Request, "operatorName")
            Dim reqToken As String = CheckUtil.SetQueryParam(QueryList, Request, "token")
            Dim reqTimestamp As String = CheckUtil.SetQueryParam(QueryList, Request, "timestamp")
            Dim reqCRC As String = Request("CRC")

            Dim success As Boolean = False
            Dim returnCode As Integer
            Dim description As String
            Dim traderID As String = ""

            Do
                If reqCRC Is Nothing OrElse reqCRC.Length = 0 Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If Not CheckUtil.CheckCRC(QueryList, reqCRC) Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If reqToken Is Nothing OrElse reqToken.Length <> 32 Then
                    returnCode = 2
                    description = "Required field missing"
                    Exit Do
                End If

                If Not AuthSession.CheckOneTimeSession(AuthSession.AuthTypeCode.FXIF, reqToken, traderID) Then
                    returnCode = 7
                    description = "Invalid Token Used"
                    Exit Do
                End If

                returnCode = 0
                description = "Successful call"
                success = True
            Loop While False

            Dim res As New VerifyLoginTokenJsonData
            Dim serializer As New DataContractJsonSerializer(GetType(VerifyLoginTokenJsonData))

            res.returnCode = returnCode
            res.description = description

            If success Then
                res.traderID = traderID
            End If

            Dim ms As New MemoryStream
            serializer.WriteObject(ms, res)
            ms.Position = 0
            Dim sr As New StreamReader(ms)
            Response.ContentType = "application/json"
            Response.Charset = "utf-8"
            Response.Write(sr.ReadToEnd())
        End Sub
    End Class
End Namespace