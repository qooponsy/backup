﻿Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json

<DataContract()>
Public Class GetAccountBalanceJsonData
    <DataMember()>
    Public returnCode As Integer
    <DataMember()>
    Public description As String
    <DataMember()>
    Public balance As Decimal
End Class
