﻿Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json

<DataContract()>
Public Class UpdateAccountJsonData
    <DataMember()>
    Public returnCode As Integer
    <DataMember()>
    Public description As String
End Class
