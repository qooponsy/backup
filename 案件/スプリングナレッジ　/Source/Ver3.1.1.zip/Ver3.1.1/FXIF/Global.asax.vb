﻿' メモ: IIS6 または IIS7 のクラシック モードの詳細については、
' http://go.microsoft.com/?LinkId=9394802 を参照してください

Public Class MvcApplication
    Inherits System.Web.HttpApplication

    Shared Sub RegisterGlobalFilters(ByVal filters As GlobalFilterCollection)
        filters.Add(New HandleErrorAttribute())
    End Sub

    Shared Sub RegisterRoutes(ByVal routes As RouteCollection)
        routes.IgnoreRoute("{resource}.axd/{*pathInfo}")
        routes.MapRoute("Default", "{controller}")
        routes.MapRoute("Token", "Token/{controller}")
        routes.MapRoute("Account", "Account/{controller}")
    End Sub

    Sub Application_Start()
        LogUtil.Information("初期処理開始")

        AreaRegistration.RegisterAllAreas()
        RegisterRoutes(RouteTable.Routes)

        LogUtil.Information("初期処理終了")
    End Sub

    Sub Application_End()
        LogUtil.Information("終了処理開始")

        LogUtil.Information("終了処理終了")
    End Sub
End Class
