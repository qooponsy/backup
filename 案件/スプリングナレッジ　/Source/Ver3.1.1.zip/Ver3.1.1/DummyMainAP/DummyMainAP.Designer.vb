﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DummyMainAP
	Inherits System.Windows.Forms.Form

	'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Windows フォーム デザイナーで必要です。
	Private components As System.ComponentModel.IContainer

	'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
	'Windows フォーム デザイナーを使用して変更できます。  
	'コード エディターを使って変更しないでください。
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DummyMainAP))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkDiffSession = New System.Windows.Forms.CheckBox()
        Me.chkInitSession = New System.Windows.Forms.CheckBox()
        Me.chkDiffProduct = New System.Windows.Forms.CheckBox()
        Me.chkInitProduct = New System.Windows.Forms.CheckBox()
        Me.chkHeartBeat = New System.Windows.Forms.CheckBox()
        Me.lstLog = New System.Windows.Forms.ListBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnClear)
        Me.Panel1.Controls.Add(Me.chkDiffSession)
        Me.Panel1.Controls.Add(Me.chkInitSession)
        Me.Panel1.Controls.Add(Me.chkDiffProduct)
        Me.Panel1.Controls.Add(Me.chkInitProduct)
        Me.Panel1.Controls.Add(Me.chkHeartBeat)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(832, 41)
        Me.Panel1.TabIndex = 6
        '
        'chkDiffSession
        '
        Me.chkDiffSession.AutoSize = True
        Me.chkDiffSession.Location = New System.Drawing.Point(511, 14)
        Me.chkDiffSession.Name = "chkDiffSession"
        Me.chkDiffSession.Size = New System.Drawing.Size(107, 16)
        Me.chkDiffSession.TabIndex = 10
        Me.chkDiffSession.Text = "DiffSession表示"
        Me.chkDiffSession.UseVisualStyleBackColor = True
        '
        'chkInitSession
        '
        Me.chkInitSession.AutoSize = True
        Me.chkInitSession.Location = New System.Drawing.Point(251, 14)
        Me.chkInitSession.Name = "chkInitSession"
        Me.chkInitSession.Size = New System.Drawing.Size(104, 16)
        Me.chkInitSession.TabIndex = 9
        Me.chkInitSession.Text = "InitSession表示"
        Me.chkInitSession.UseVisualStyleBackColor = True
        '
        'chkDiffProduct
        '
        Me.chkDiffProduct.AutoSize = True
        Me.chkDiffProduct.Location = New System.Drawing.Point(372, 14)
        Me.chkDiffProduct.Name = "chkDiffProduct"
        Me.chkDiffProduct.Size = New System.Drawing.Size(106, 16)
        Me.chkDiffProduct.TabIndex = 8
        Me.chkDiffProduct.Text = "DiffProduct表示"
        Me.chkDiffProduct.UseVisualStyleBackColor = True
        '
        'chkInitProduct
        '
        Me.chkInitProduct.AutoSize = True
        Me.chkInitProduct.Location = New System.Drawing.Point(112, 14)
        Me.chkInitProduct.Name = "chkInitProduct"
        Me.chkInitProduct.Size = New System.Drawing.Size(103, 16)
        Me.chkInitProduct.TabIndex = 7
        Me.chkInitProduct.Text = "InitProduct表示"
        Me.chkInitProduct.UseVisualStyleBackColor = True
        '
        'chkHeartBeat
        '
        Me.chkHeartBeat.AutoSize = True
        Me.chkHeartBeat.Location = New System.Drawing.Point(12, 14)
        Me.chkHeartBeat.Name = "chkHeartBeat"
        Me.chkHeartBeat.Size = New System.Drawing.Size(64, 16)
        Me.chkHeartBeat.TabIndex = 6
        Me.chkHeartBeat.Text = "HB表示"
        Me.chkHeartBeat.UseVisualStyleBackColor = True
        '
        'lstLog
        '
        Me.lstLog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstLog.FormattingEnabled = True
        Me.lstLog.ItemHeight = 12
        Me.lstLog.Location = New System.Drawing.Point(0, 41)
        Me.lstLog.Name = "lstLog"
        Me.lstLog.Size = New System.Drawing.Size(832, 266)
        Me.lstLog.TabIndex = 7
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(634, 10)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 11
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'DummyMainAP
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(832, 307)
        Me.Controls.Add(Me.lstLog)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "DummyMainAP"
        Me.Text = "MainAP Dummy"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chkDiffSession As System.Windows.Forms.CheckBox
    Friend WithEvents chkInitSession As System.Windows.Forms.CheckBox
    Friend WithEvents chkDiffProduct As System.Windows.Forms.CheckBox
    Friend WithEvents chkInitProduct As System.Windows.Forms.CheckBox
    Friend WithEvents chkHeartBeat As System.Windows.Forms.CheckBox
    Friend WithEvents lstLog As System.Windows.Forms.ListBox
    Friend WithEvents btnClear As System.Windows.Forms.Button

End Class
