﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Threading

'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class DummyMainAP

	Public Listener As TcpListener
	Public bHeartBeat As Boolean
	Public bInitProduct As Boolean
	Public bDiffProduct As Boolean
	Public bInitSession As Boolean
	Public bDiffSession As Boolean
	Private MyIP As IPAddress

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Private Sub DummyMainAP_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		bHeartBeat = True
		bInitProduct = False
		bDiffProduct = False
		bInitSession = False
		bDiffSession = False

		chkHeartBeat.Checked = bHeartBeat
		chkInitProduct.Checked = bInitProduct
		chkDiffProduct.Checked = bDiffProduct
		chkInitSession.Checked = bInitSession
		chkDiffSession.Checked = bDiffSession

        MyIP = Dns.GetHostEntry("localhost").AddressList(0)
        MyIP = IPAddress.Any
		Listener = New TcpListener(MyIP, My.Settings.ListenPort)
		If IsNothing(Listener) = False Then
			Listener.Start()
			Listener.BeginAcceptTcpClient(New System.AsyncCallback(AddressOf OnAccept), Me)
		End If
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Delegate Sub DG_AddLogList(ByRef sLog)

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub AddLogList(ByRef sLog)
		If Me.lstLog.Items.Count > 2000 Then
			Me.lstLog.Items.RemoveAt(Me.lstLog.Items.Count - 1)
		End If
		Me.lstLog.Items.Insert(0, sLog)
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Private Sub OnAccept(ByVal ar As IAsyncResult)
		Logging("Start")

		Dim server As TcpListener
		Dim client As Socket = Nothing
		Dim bytRecv() As Byte
		Dim strBuff As String
		Dim sLog As String
		Dim iLen As Integer
		Dim sTypeCode As String
		Dim HeartBeatTimer As Stopwatch
		Dim DeliveryTelegram As clsDeliveryTelegram
		Dim ListData As DataTable
		Dim ListRow As DataRow
		Dim mainAP As DummyMainAP

		sLog = ""
		mainAP = CType(ar.AsyncState, DummyMainAP)
		server = mainAP.Listener

		bytRecv = New Byte(200000) {}

		DeliveryTelegram = New clsDeliveryTelegram()
		DeliveryTelegram.Initialize("DummpMainAP")

		Try
			client = server.EndAcceptSocket(ar)
		Catch
			Return
		End Try

		HeartBeatTimer = Stopwatch.StartNew()
		While True
			Try
				If client.Available() > 0 Then
					iLen = client.Receive(bytRecv)
				Else
					iLen = 0
				End If

				strBuff = ""
                While DeliveryTelegram.AddReceiveTelegram(bytRecv, iLen, strBuff)
                    ListData = Nothing
                    sTypeCode = DeliveryTelegram.GetDeliveryData(strBuff, ListData)
                    Select Case sTypeCode
                        Case clsDeliveryTelegram.TYPE_HB_DELIVER                                ' 配信 ハートビート
                            If mainAP.bHeartBeat = True Then
                                Logging("Receive[Deliver-HB:" & ListData.Rows(0).Item("ServerDateTime").ToString() & "]")
                            End If
                        Case clsDeliveryTelegram.TYPE_INIT_RATE_TICK                            ' Rate G/W 最新Rate-Tick Seq 通知
                            Logging("Receive[Rate-Tick-Seq:" & sTypeCode & "]")
                        Case clsDeliveryTelegram.TYPE_NEW_RATE_TICK                             ' Rate G/W 新規Rate-Tick Data通知
                            Logging("Receive[Rate-Tick-Data:" & sTypeCode & "]")
                        Case clsDeliveryTelegram.TYPE_INIT_SESSION                              ' DataDeliver 全件セッション情報
                            Logging("Receive[Init-Session:" & sTypeCode & "]")
                            If mainAP.bInitSession = True Then
                                For Each ListRow In ListData.Rows
                                    sLog = "SessionKey:" & ListRow.Item("SessionKey").ToString()
                                    Logging(sLog)
                                Next
                            End If
                        Case clsDeliveryTelegram.TYPE_DIFF_SESSION                              ' DataDeliver 差分セッション情報
                            Logging("Receive[Diff-Session:" & sTypeCode & "]")
                            If mainAP.bDiffSession = True Then
                                For Each ListRow In ListData.Rows
                                    sLog = "Type:" & ListRow.Item("DeliveryType").ToString() & " "
                                    sLog = sLog & "SessionKey:" & ListRow.Item("SessionKey").ToString()
                                    Logging(sLog)
                                Next
                            End If
                        Case clsDeliveryTelegram.TYPE_INIT_PRODUCT                              ' DataDeliver 全件銘柄情報
                            Logging("Receive[Init-Product:" & sTypeCode & "]")
                            If mainAP.bInitProduct = True Then
                                For Each ListRow In ListData.Rows
                                    sLog = "ProductCode:" & ListRow.Item("ProductCode").ToString()
                                    Logging(sLog)
                                Next
                            End If
                        Case clsDeliveryTelegram.TYPE_DIFF_PRODUCT                              ' DataDeliver 差分銘柄情報
                            Logging("Receive[Diff-Product:" & sTypeCode & "]")
                            If mainAP.bDiffProduct = True Then
                                For Each ListRow In ListData.Rows
                                    sLog = "Type:" & ListRow.Item("DeliveryType").ToString() & " "
                                    sLog = sLog & "ProductCode:" & ListRow.Item("ProductCode").ToString()
                                    Logging(sLog)
                                Next
                            End If
                        Case clsDeliveryTelegram.TYPE_PRODUCT_BASE                              ' DataDeliver 全件銘柄設定情報
                            Logging("Receive[ProductCode:" & sTypeCode & "]")
                        Case clsDeliveryTelegram.TYPE_SYS_SETTINGS                              ' DataDeliver 全件システム設定情報
                            Logging("Receive[SysSettings:" & sTypeCode & "]")
                        Case clsDeliveryTelegram.TYPE_SYS_STATUS                                ' DataDeliver 全件システムステータス情報
                            Logging("Receive[SysStatus:" & sTypeCode & "]")
                        Case clsDeliveryTelegram.TYPE_CALC_PARAM                                ' DataDeliver 全件計算パラメタ情報
                            Logging("Receive[CalcParam:" & sTypeCode & "]")
                        Case Else
                            Logging("Receive[???:" & sTypeCode & "]")
                    End Select

                    iLen = 0
                    strBuff = ""
                End While

                If HeartBeatTimer.ElapsedMilliseconds > 1000 Then
                    HeartBeatTimer.Restart()
                    client.Send(DeliveryTelegram.CreateMainHeartBeat())
                    If mainAP.bHeartBeat = True Then
                        Logging("Send HeartBeat")
                    End If
                Else
                    If client.Available() = 0 Then
                        Thread.Sleep(50)
                    End If
                End If
            Catch ex As Exception
                Exit While
            End Try
		End While

        client.Close()

		' 接続要求待機を再開する
		server.BeginAcceptTcpClient(New System.AsyncCallback(AddressOf OnAccept), mainAP)
		Logging("End")
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Private Sub Logging(ByVal sLog As String)
		Dim sLogText As String

		sLogText = Format(Now, "HH:mm:ss ") & sLog
		Invoke(New DG_AddLogList(AddressOf AddLogList), sLogText)
		'Debug.Print(sLogText)
	End Sub

    Private Sub chkHeartBeat_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkHeartBeat.CheckedChanged
        bHeartBeat = chkHeartBeat.Checked
    End Sub

    Private Sub chkInitProduct_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInitProduct.CheckedChanged
        bInitProduct = chkInitProduct.Checked
    End Sub

    Private Sub chkDiffProduct_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDiffProduct.CheckedChanged
        bDiffProduct = chkDiffProduct.Checked
    End Sub

    Private Sub chkInitSession_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkInitSession.CheckedChanged
        bInitSession = chkInitSession.Checked
    End Sub

    Private Sub chkDiffSession_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkDiffSession.CheckedChanged
        bDiffSession = chkDiffSession.Checked
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        lstLog.Items.Clear()
    End Sub

End Class
