﻿Imports System.Data.SqlClient
Imports System.Text

Public Class Form1

    Private Const DB_ACCESS As String = "Server=192.168.53.204;Database=Penguin8;UID=Penguin8;PWD=Penguin8"

    Private Sub btnTestSTart_Click(sender As Object, e As EventArgs) Handles btnSyncTest.Click

        lblData.Text = "同期処理実行中..."

        Using con As New SqlConnection(DB_ACCESS)

            con.Open()

            Using cmd As SqlCommand = con.CreateCommand
                Dim sql As New StringBuilder

                sql.AppendLine("select top 5000 * from T_RateHist with ( nolock )")
                sql.AppendLine("where SUBSTRING(RateSeq, 1, 8) = '20180124'")
                sql.AppendLine("order by RateSeq desc")

                cmd.CommandText = sql.ToString()

                Dim reader As SqlDataReader = cmd.ExecuteReader()

            End Using
        End Using

        lblData.Text = "同期処理終了"

    End Sub

    Private Async Sub btnNoSync_Click(sender As Object, e As EventArgs) Handles btnNoSync.Click

        lblData.Text = "非同期処理実行中..."

        Using con As New SqlConnection(DB_ACCESS)

            con.Open()

            Using cmd As SqlCommand = con.CreateCommand
                Dim sql As New StringBuilder

                sql.AppendLine("select top 5000 * from T_RateHist with ( nolock )")
                sql.AppendLine("where SUBSTRING(RateSeq, 1, 8) = '20180124'")
                sql.AppendLine("order by RateSeq desc")

                cmd.CommandText = sql.ToString()

                Dim reader As SqlDataReader = Await cmd.ExecuteReaderAsync()

            End Using
        End Using

        lblData.Text = "非期処理終了"

    End Sub

    Private Sub btnNoTask_Click(sender As Object, e As EventArgs) Handles btnNoTask.Click

        lblData.Text = "タスクなし処理実行中..."

        '重い処理
        Dim cnt As Integer = 0
        Test.HeavyRun(cnt)

        lblData.Text = "タスクなし処理終了"

    End Sub

    Private Async Sub btnTask_Click(sender As Object, e As EventArgs) Handles btnTask.Click

        lblData.Text = "タスクあり処理実行中..."

        Dim task As Task = Task.Run(
                Sub()
                    '重い処理
                    Dim cnt As Integer = 0
                    Test.HeavyRunTask(cnt)
                End Sub
        )
        Await task

        lblData.Text = "タスクあり処理終了"

    End Sub

    Private Async Sub btnReadCount_Click(sender As Object, e As EventArgs) Handles btnReadCount.Click

        lblData.Text = "カウント処理実行中..."
        btnReadCount.Enabled = False

        Dim list As New List(Of DBData)

        Try

            Using con As New SqlConnection(DB_ACCESS)

                con.Open()

                Using cmd As SqlCommand = con.CreateCommand
                    Dim sql As New StringBuilder

                    sql.AppendLine("select top 100 * from T_RateHist with ( nolock )")
                    sql.AppendLine("where SUBSTRING(RateSeq, 1, 8) = '20180124'")
                    sql.AppendLine("order by RateSeq desc")

                    cmd.CommandText = sql.ToString()

                    Using reader As SqlDataReader = Await cmd.ExecuteReaderAsync()

                        While Await reader.ReadAsync()
                            Dim item As New DBData
                            item.RateSeq = reader("RateSeq")
                            item.ComCode = reader("ComCode")
                            list.Add(item)
                        End While

                    End Using

                End Using

                Dim count As Integer = 0
                lblCount.Text = count & "/" & list.Count
                For Each item In list
                    Using cmd As SqlCommand = con.CreateCommand
                        Dim sql As New StringBuilder

                        'SQL文の作成
                        sql.AppendLine("select * from T_RateHist with ( nolock )")
                        sql.AppendLine("where SUBSTRING(RateSeq, 1, 8) = '20180124'")
                        sql.AppendLine(" and [ComCode] = @ComCode")

                        cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = item.ComCode

                        cmd.CommandText = sql.ToString()

                        Using reader As SqlDataReader = Await cmd.ExecuteReaderAsync()
                            'If Await reader.ReadAsync() Then
                            '    Dim str As String = reader("RateSeq")
                            '    'Dim obj As Object = Await reader.GetFieldValueAsync(Of Object)(0)
                            'End If

                            While Await reader.ReadAsync()
                                For i = 0 To reader.FieldCount - 1
                                    Dim obj As Object = Await reader.GetFieldValueAsync(Of Object)(i)
                                    If Not obj Is DBNull.Value Then
                                        Dim str As String = obj
                                    End If
                                Next
                            End While

                        End Using



                        count += 1
                        lblCount.Text = count & "/" & list.Count
                    End Using
                Next

            End Using

            btnReadCount.Enabled = True
            lblData.Text = "カウント処理終了"
        Catch ex As Exception

            MessageBox.Show(ex.Message & vbCrLf & ex.StackTrace)

        End Try


    End Sub

End Class
