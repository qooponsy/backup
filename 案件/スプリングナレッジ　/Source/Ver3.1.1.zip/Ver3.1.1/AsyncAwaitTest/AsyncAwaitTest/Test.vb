﻿Public Class Test

    Public Shared Function HeavyRun(ByRef count As Integer) As Boolean

        ' 重い処理
        For index = 0 To Integer.MaxValue - 1
            count = index
        Next

        Return True
    End Function

    Public Shared Function HeavyRunTask(ByRef count As Integer) As Boolean

        ' 重い処理
        For index = 0 To Integer.MaxValue - 1
            count = index
        Next

        Return True
    End Function

End Class
