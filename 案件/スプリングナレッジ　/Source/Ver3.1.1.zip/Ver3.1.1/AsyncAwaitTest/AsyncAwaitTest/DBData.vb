﻿Public Class DBData

    Property RateSeq As String
    Property ComCode As String

End Class
