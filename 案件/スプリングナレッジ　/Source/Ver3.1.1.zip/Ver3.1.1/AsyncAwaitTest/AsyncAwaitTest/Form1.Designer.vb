﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSyncTest = New System.Windows.Forms.Button()
        Me.lblData = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.btnNoSync = New System.Windows.Forms.Button()
        Me.btnNoTask = New System.Windows.Forms.Button()
        Me.btnTask = New System.Windows.Forms.Button()
        Me.btnReadCount = New System.Windows.Forms.Button()
        Me.lblCount = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnSyncTest
        '
        Me.btnSyncTest.Location = New System.Drawing.Point(29, 12)
        Me.btnSyncTest.Name = "btnSyncTest"
        Me.btnSyncTest.Size = New System.Drawing.Size(75, 23)
        Me.btnSyncTest.TabIndex = 0
        Me.btnSyncTest.Text = "同期テスト"
        Me.btnSyncTest.UseVisualStyleBackColor = True
        '
        'lblData
        '
        Me.lblData.AutoSize = True
        Me.lblData.Location = New System.Drawing.Point(119, 17)
        Me.lblData.Name = "lblData"
        Me.lblData.Size = New System.Drawing.Size(72, 12)
        Me.lblData.TabIndex = 1
        Me.lblData.Text = "ここに色々書く"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 211)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "↓非同期か確認する用"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(29, 226)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(193, 47)
        Me.TextBox1.TabIndex = 3
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(29, 279)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(92, 16)
        Me.RadioButton1.TabIndex = 4
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "RadioButton1"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(29, 301)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(92, 16)
        Me.RadioButton2.TabIndex = 5
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "RadioButton2"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'btnNoSync
        '
        Me.btnNoSync.Location = New System.Drawing.Point(28, 42)
        Me.btnNoSync.Name = "btnNoSync"
        Me.btnNoSync.Size = New System.Drawing.Size(75, 23)
        Me.btnNoSync.TabIndex = 6
        Me.btnNoSync.Text = "非同期テスト"
        Me.btnNoSync.UseVisualStyleBackColor = True
        '
        'btnNoTask
        '
        Me.btnNoTask.Location = New System.Drawing.Point(29, 71)
        Me.btnNoTask.Name = "btnNoTask"
        Me.btnNoTask.Size = New System.Drawing.Size(75, 23)
        Me.btnNoTask.TabIndex = 7
        Me.btnNoTask.Text = "タスクなし"
        Me.btnNoTask.UseVisualStyleBackColor = True
        '
        'btnTask
        '
        Me.btnTask.Location = New System.Drawing.Point(29, 100)
        Me.btnTask.Name = "btnTask"
        Me.btnTask.Size = New System.Drawing.Size(75, 23)
        Me.btnTask.TabIndex = 8
        Me.btnTask.Text = "タスクあり"
        Me.btnTask.UseVisualStyleBackColor = True
        '
        'btnReadCount
        '
        Me.btnReadCount.Location = New System.Drawing.Point(29, 144)
        Me.btnReadCount.Name = "btnReadCount"
        Me.btnReadCount.Size = New System.Drawing.Size(193, 23)
        Me.btnReadCount.TabIndex = 9
        Me.btnReadCount.Text = "カウントテスト"
        Me.btnReadCount.UseVisualStyleBackColor = True
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.Location = New System.Drawing.Point(119, 184)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(0, 12)
        Me.lblCount.TabIndex = 10
        Me.lblCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(234, 336)
        Me.Controls.Add(Me.lblCount)
        Me.Controls.Add(Me.btnReadCount)
        Me.Controls.Add(Me.btnTask)
        Me.Controls.Add(Me.btnNoTask)
        Me.Controls.Add(Me.btnNoSync)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblData)
        Me.Controls.Add(Me.btnSyncTest)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSyncTest As Button
    Friend WithEvents lblData As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents btnNoSync As Button
    Friend WithEvents btnNoTask As Button
    Friend WithEvents btnTask As Button
    Friend WithEvents btnReadCount As Button
    Friend WithEvents lblCount As Label
End Class
