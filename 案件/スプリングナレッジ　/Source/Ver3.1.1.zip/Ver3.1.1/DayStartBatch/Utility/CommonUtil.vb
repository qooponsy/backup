﻿Imports System.Data.SqlClient

Public Class CommonUtil

    Public Shared Function GetRateDPFormat(DecimalPlaces As Integer) As String
        If DecimalPlaces <= 0 Then
            Return "######0.########"
        End If
        Select Case DecimalPlaces
            Case 0 : Return "######0.########"
            Case 1 : Return "######0.0#######"
            Case 2 : Return "######0.00######"
            Case 3 : Return "######0.000#####"
            Case 4 : Return "######0.0000####"
            Case 5 : Return "######0.00000###"
            Case 6 : Return "######0.000000##"
            Case 7 : Return "######0.0000000#"
        End Select
        Return "######0.00000000"
    End Function

    Public Shared Sub ReadDBColumnNullable(Of T)(reader As SqlDataReader, ColumnName As String, ByRef Enabeld As Boolean, ByRef value As T)
        Dim dbValue As Object = reader(ColumnName)
        If dbValue Is Nothing OrElse IsDBNull(dbValue) Then
            Enabeld = False
        Else
            Enabeld = True
            value = dbValue
        End If
    End Sub

    Public Shared Sub AddDBParameterNullableDecimal(cmd As SqlCommand, ParamName As String, Precision As Byte, Scale As Byte, Enabled As Boolean, Value As Decimal)
        Dim param As SqlParameter
        param = cmd.Parameters.Add(ParamName, SqlDbType.Decimal)
        param.Precision = Precision
        param.Scale = Scale
        If Enabled Then
            param.Value = Value
        Else
            param.Value = DBNull.Value
        End If
    End Sub

    Public Shared Sub AddDBParameterNullableInt(cmd As SqlCommand, ParamName As String, Enabled As Boolean, Value As Integer)
        Dim param As SqlParameter
        param = cmd.Parameters.Add(ParamName, SqlDbType.Int)
        If Enabled Then
            param.Value = Value
        Else
            param.Value = DBNull.Value
        End If
    End Sub

    Public Shared Sub AddDBParameterNullableWithSize(cmd As SqlCommand, ParamName As String, ColType As SqlDbType, size As Integer, Enabled As Boolean, Value As Object)
        Dim param As SqlParameter
        param = cmd.Parameters.Add(ParamName, ColType, size)
        If Enabled Then
            param.Value = Value
        Else
            param.Value = DBNull.Value
        End If
    End Sub

End Class
