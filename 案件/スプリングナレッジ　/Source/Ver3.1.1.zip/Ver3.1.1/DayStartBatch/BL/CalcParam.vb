﻿Imports System.Text
Imports System.Data.SqlClient

Public Class CalcParam

    Public Shared Function Update(NewSysDate As DateTime, OldSysDate As DateTime) As Boolean
        '通貨ペアリスト取得
        Dim ComList As List(Of CurrencyPair) = Nothing
        If Not CurrencyPair.GetList(ComList) Then
            Return False
        End If
        '計算パラメータ設定取得
        Dim CalcParamList As Dictionary(Of String, CalcParamSettings) = Nothing
        If Not CalcParamSettings.GetList(CalcParamList) Then
            Return False
        End If
        '計算パラメータの更新
        For Each com As CurrencyPair In ComList
            'ヒストリカルボラティリティ算出用クローズレート取得
            Dim list As List(Of RateDayClose) = Nothing
            If Not RateDayClose.GetList(com.ComCode, OldSysDate, list) Then
                Return False
            End If
            Dim RateList As New List(Of Decimal)
            For Each item As RateDayClose In list
                RateList.Add(item.Rate)
            Next
            '計算パラメータ
            Dim interestRate As Decimal = 0
            Dim swapRate As Decimal = 0
            Dim volatilityAdjust As Decimal = 1
            If CalcParamList.ContainsKey(com.ComCode) Then
                Dim calcParamItem As CalcParamSettings = CalcParamList(com.ComCode)
                interestRate = calcParamItem.InterestRate
                swapRate = calcParamItem.SwapRate
                volatilityAdjust = calcParamItem.VolatilityAdjust
            End If
            'ヒストリカルボラティリティ算出
            Dim volatility As Decimal = RiskCalc.volatility(RateList) * volatilityAdjust
            '計算パラメータ更新
            If Not Update(com.ComCode, interestRate, swapRate, volatilityAdjust, volatility) Then
                Return False
            End If
        Next
        '計算パラメータ履歴登録
        If Not RegistHist(NewSysDate) Then
            Return False
        End If

        Return True
    End Function

    Public Shared Function Update(ComCode As String, InterestRate As Decimal, SwapRate As Decimal, VolatilityAdjust As Decimal, Volatility As Decimal) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "update [M_CalcParam] set [InterestRate]=@InterestRate, [SwapRate]=@SwapRate, [VolatilityAdjust]=@VolatilityAdjust, [Volatility]=@Volatility, [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@ProcUser where [ComCode]=@ComCode"
                    Dim param As SqlParameter
                    cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ComCode
                    param = cmd.Parameters.Add("@InterestRate", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 14
                    param.Value = InterestRate
                    param = cmd.Parameters.Add("@SwapRate", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 14
                    param.Value = SwapRate
                    param = cmd.Parameters.Add("@VolatilityAdjust", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 14
                    param.Value = VolatilityAdjust
                    param = cmd.Parameters.Add("@Volatility", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 14
                    param.Value = Volatility
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public Shared Function RegistHist(SysDate As DateTime) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    Dim sql As New StringBuilder
                    sql.AppendLine("delete [M_CalcParamHist] where [SysDate]=@SysDate")
                    sql.AppendLine("insert into [M_CalcParamHist] select SYSUTCDATETIME(), @ProcUser, SYSUTCDATETIME(), @ProcUser, @SysDate, [ComCode], [InterestRate], [SwapRate], [VolatilityAdjust], [Volatility], [DeltaVariation], [GammaVariation], [VegaVariation], [ThetaVariation], [RhoVariation] from [M_CalcParam]")
                    cmd.CommandText = sql.ToString()
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
