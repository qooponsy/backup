﻿Imports System.Data.SqlClient

Public Class SysStatus

    Public Shared SysDate As DateTime
    Public Shared SysEnabled As String
    Public Shared AbandEnabled As String
    Public Shared CashOutEnabled As String
    Public Shared CashInEnabled As String
    Public Shared RateProviderId As Integer
    Public Shared SysUpdateSeq As Integer

    Public Shared Function getDB() As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [S_SysStatus] with(nolock)  where [SysCode] = '0'"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            SysDate = reader("SysDate")
                            SysEnabled = reader("SysEnabled")
                            AbandEnabled = reader("AbandEnabled")
                            CashOutEnabled = reader("CashOutEnabled")
                            CashInEnabled = reader("CashInEnabled")
                            SysUpdateSeq = reader("SysUpdateSeq")
                        End If
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public Shared Function getSysDate(ByVal NowDate As DateTime, ByRef SysDate As DateTime) As Boolean
        Dim SysDateSuccess As Boolean = False

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_System_GetSysDate
                    Dim param As SqlParameter
                    param = cmd.Parameters.Add("@TempDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.InputOutput
                    param.Value = NowDate
                    cmd.ExecuteNonQuery()
                    Dim sysDateValue As Object = cmd.Parameters("@TempDate").Value
                    If IsDBNull(sysDateValue) Then
                        SystemLog.ErrorTEL("getSysDate is null", "getSysDate で営業日を取得できませんでした。")
                    Else
                        SysDate = sysDateValue
                        SysDateSuccess = True
                    End If
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        If Not DBSuccess Then
            Return False
        End If

        Return SysDateSuccess
    End Function

    Public Shared Function getPrevSysDate(ByVal NowDate As DateTime, ByRef SysDate As DateTime) As Boolean
        Dim SysDateSuccess As Boolean = False

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_System_GetPrevSysDate
                    Dim param As SqlParameter
                    param = cmd.Parameters.Add("@TempDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.InputOutput
                    param.Value = NowDate
                    cmd.ExecuteNonQuery()
                    Dim sysDateValue As Object = cmd.Parameters("@TempDate").Value
                    If IsDBNull(sysDateValue) Then
                        SystemLog.ErrorTEL("getSysDate is null", "getPrevSysDate で営業日を取得できませんでした。")
                    Else
                        SysDate = sysDateValue
                        SysDateSuccess = True
                    End If
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        If Not DBSuccess Then
            Return False
        End If

        Return SysDateSuccess
    End Function

    Public Shared Function updateSysUpdateSeq() As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "update [S_SysStatus] set [UpdTime] = SYSUTCDATETIME(), [UpdUser] = @ProcUser, [SysUpdateSeq] = [SysUpdateSeq] + 1 where [SysCode] = '0'"
                    cmd.Parameters.Add("@ProcUser", SqlDbType.Char, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
