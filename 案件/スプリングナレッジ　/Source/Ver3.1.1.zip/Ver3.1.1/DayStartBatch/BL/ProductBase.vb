﻿Imports System.Data.SqlClient

Public Class ProductBase

    Public Shared Function getList(ByRef list As List(Of ProductBase)) As Boolean
        list = New List(Of ProductBase)

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    Dim ratetime As DateTime = DateTime.Now
                    cmd.CommandText = "select * from [M_ProductBase] where [Enabled] = '1' order by [ProductBaseCode] desc"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            Dim newData As New ProductBase
                            newData.SetObjProductBase(reader)
                            list.Add(newData)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public ProductBaseCode As String
    Public ProductBaseEnabled As String
    Public ComCode As String
    Public OpType As String
    Public OptionTime As Integer
    Public CreateTime As Integer
    Public StartTime As TimeSpan
    Public ExercTime As TimeSpan
    Public PayoutRateEnabled As Boolean             'ペイアウト率
    Public PayoutRate As Decimal
    Public ExercPriceTimespanEnabled As Boolean     '行使価格決定時間
    Public ExercPriceTimespan As Integer
    Public ExercPriceUnitTypeEnabled As Boolean     '行使価格刻み幅種別
    Public ExercPriceUnitType As String
    Public ExercPriceUnitEnabled As Boolean         '行使価格刻み幅
    Public ExercPriceUnit As Decimal
    Public ExercPriceSettingsEnabled As Boolean     '行使価格設定
    Public ExercPriceSettings As String
    Public ExceptExercPriceEnabled As Boolean       '除外行使価格
    Public ExceptExercPrice As String
    Public VolatilityRatio1CallEnabled As Boolean   'ボラティリティレシオ１(Call)
    Public VolatilityRatio1Call As Decimal
    Public VolatilityRatio1PutEnabled As Boolean    'ボラティリティレシオ１(Put)
    Public VolatilityRatio1Put As Decimal
    Public VolatilityRatio2CallEnabled As Boolean   'ボラティリティレシオ２(Call)
    Public VolatilityRatio2Call As Decimal
    Public VolatilityRatio2PutEnabled As Boolean    'ボラティリティレシオ２(Put)
    Public VolatilityRatio2Put As Decimal
    Public VolatilitySmileACallEnabled As Boolean   'ボラティリティスマイルａ(Call)
    Public VolatilitySmileACall As Decimal
    Public VolatilitySmileAPutEnabled As Boolean    'ボラティリティスマイルａ(Put)
    Public VolatilitySmileAPut As Decimal
    Public VolatilitySmileBCallEnabled As Boolean   'ボラティリティスマイルｂ(Call)
    Public VolatilitySmileBCall As Decimal
    Public VolatilitySmileBPutEnabled As Boolean    'ボラティリティスマイルｂ(Put)
    Public VolatilitySmileBPut As Decimal
    Public VolatilitySpreadEnabled As Boolean       'ボラティリティスプレッド
    Public VolatilitySpread As Decimal
    Public VolatilitySpreadITMCallEnabled As Boolean   'ボラティリティスプレッドITM(Call)
    Public VolatilitySpreadITMCall As Decimal
    Public VolatilitySpreadITMPutEnabled As Boolean    'ボラティリティスプレッドITM(Put)
    Public VolatilitySpreadITMPut As Decimal
    Public VolatilitySpreadOTMCallEnabled As Boolean   'ボラティリティスプレッドOTM(Call)
    Public VolatilitySpreadOTMCall As Decimal
    Public VolatilitySpreadOTMPutEnabled As Boolean    'ボラティリティスプレッドOTM(Put)
    Public VolatilitySpreadOTMPut As Decimal
    Public AskFeePriceCallEnabled As Boolean       '購入手数料(Call)
    Public AskFeePriceCall As Decimal
    Public AskFeePricePutEnabled As Boolean        '購入手数料(Put)
    Public AskFeePricePut As Decimal
    Public AskBidSpreadMinCallEnabled As Boolean       '購入清算価格最小スプレッド(Call)
    Public AskBidSpreadMinCall As Decimal
    Public AskBidSpreadMinPutEnabled As Boolean        '購入清算価格最小スプレッド(Put)
    Public AskBidSpreadMinPut As Decimal
    Public BidFeeRateCallEnabled As Boolean       '清算手数料率(Call)
    Public BidFeeRateCall As Decimal
    Public BidFeeRatePutEnabled As Boolean        '清算手数料率(Put)
    Public BidFeeRatePut As Decimal
    Public AskPriceMaxCallEnabled As Boolean        '最高購入価格(Call)
    Public AskPriceMaxCall As Decimal
    Public AskPriceMaxPutEnabled As Boolean         '最高購入価格(Put)
    Public AskPriceMaxPut As Decimal
    Public AskPriceMinCallEnabled As Boolean        '最低購入価格(Call)
    Public AskPriceMinCall As Decimal
    Public AskPriceMinPutEnabled As Boolean         '最低購入価格(Put)	
    Public AskPriceMinPut As Decimal
    Public BidPriceMaxCallEnabled As Boolean        '最高清算価格(Call)
    Public BidPriceMaxCall As Decimal
    Public BidPriceMaxPutEnabled As Boolean         '最高清算価格(Put)
    Public BidPriceMaxPut As Decimal
    Public BidPriceMinCallEnabled As Boolean        '最低清算価格(Call)
    Public BidPriceMinCall As Decimal
    Public BidPriceMinPutEnabled As Boolean         '最低清算価格(Put)	
    Public BidPriceMinPut As Decimal

    Public Sub SetObjProductBase(ByVal reader As SqlDataReader)
        '銘柄設定コード
        ProductBaseCode = reader("ProductBaseCode")
        '有効フラグ
        ProductBaseEnabled = reader("Enabled")
        '通貨ペアコード
        ComCode = reader("ComCode")
        'オプション種別
        OpType = reader("OpType")
        'オプション期間
        OptionTime = reader("OptionTime")
        '生成間隔
        CreateTime = reader("CreateTime")
        '生成開始時間
        StartTime = reader("StartTime")
        '最終行使期日
        ExercTime = reader("ExercTime")
        'ペイアウト率
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "PayoutRate", PayoutRateEnabled, PayoutRate)
        '行使価格決定時間
        CommonUtil.ReadDBColumnNullable(Of Integer)(reader, "ExercPriceTimespan", ExercPriceTimespanEnabled, ExercPriceTimespan)
        '行使価格刻み幅種別
        CommonUtil.ReadDBColumnNullable(Of String)(reader, "ExercPriceUnitType", ExercPriceUnitTypeEnabled, ExercPriceUnitType)
        '行使価格刻み幅
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "ExercPriceUnit", ExercPriceUnitEnabled, ExercPriceUnit)
        '行使価格設定
        CommonUtil.ReadDBColumnNullable(Of String)(reader, "ExercPriceSettings", ExercPriceSettingsEnabled, ExercPriceSettings)
        '除外行使価格
        CommonUtil.ReadDBColumnNullable(Of String)(reader, "ExceptExercPrice", ExceptExercPriceEnabled, ExceptExercPrice)
        'ボラティリティレシオ１(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilityRatio1Call", VolatilityRatio1CallEnabled, VolatilityRatio1Call)
        'ボラティリティレシオ１(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilityRatio1Put", VolatilityRatio1PutEnabled, VolatilityRatio1Put)
        'ボラティリティレシオ２(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilityRatio2Call", VolatilityRatio2CallEnabled, VolatilityRatio2Call)
        'ボラティリティレシオ２(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilityRatio2Put", VolatilityRatio2PutEnabled, VolatilityRatio2Put)
        'ボラティリティスマイルａ(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySmileACall", VolatilitySmileACallEnabled, VolatilitySmileACall)
        'ボラティリティスマイルａ(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySmileAPut", VolatilitySmileAPutEnabled, VolatilitySmileAPut)
        'ボラティリティスマイルｂ(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySmileBCall", VolatilitySmileBCallEnabled, VolatilitySmileBCall)
        'ボラティリティスマイルｂ(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySmileBPut", VolatilitySmileBPutEnabled, VolatilitySmileBPut)
        'ボラティリティスプレッド
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySpread", VolatilitySpreadEnabled, VolatilitySpread)
        'ボラティリティスプレッドITM(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySpreadITMCall", VolatilitySpreadITMCallEnabled, VolatilitySpreadITMCall)
        'ボラティリティスプレッドITM(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySpreadITMPut", VolatilitySpreadITMPutEnabled, VolatilitySpreadITMPut)
        'ボラティリティスプレッドOTM(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySpreadOTMCall", VolatilitySpreadOTMCallEnabled, VolatilitySpreadOTMCall)
        'ボラティリティスプレッドOTM(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "VolatilitySpreadOTMPut", VolatilitySpreadOTMPutEnabled, VolatilitySpreadOTMPut)
        '購入手数料(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskFeePriceCall", AskFeePriceCallEnabled, AskFeePriceCall)
        '購入手数料(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskFeePricePut", AskFeePricePutEnabled, AskFeePricePut)
        '購入清算価格最小スプレッド(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskBidSpreadMinCall", AskBidSpreadMinCallEnabled, AskBidSpreadMinCall)
        '購入清算価格最小スプレッド(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskBidSpreadMinPut", AskBidSpreadMinPutEnabled, AskBidSpreadMinPut)
        '清算手数料率(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "BidFeeRateCall", BidFeeRateCallEnabled, BidFeeRateCall)
        '清算手数料率(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "BidFeeRatePut", BidFeeRatePutEnabled, BidFeeRatePut)
        '最高購入価格(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskPriceMaxCall", AskPriceMaxCallEnabled, AskPriceMaxCall)
        '最高購入価格(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskPriceMaxPut", AskPriceMaxPutEnabled, AskPriceMaxPut)
        '最低購入価格(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskPriceMinCall", AskPriceMinCallEnabled, AskPriceMinCall)
        '最低購入価格(Put)	
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "AskPriceMinPut", AskPriceMinPutEnabled, AskPriceMinPut)
        '最高清算価格(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "BidPriceMaxCall", BidPriceMaxCallEnabled, BidPriceMaxCall)
        '最高清算価格(Put)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "BidPriceMaxPut", BidPriceMaxPutEnabled, BidPriceMaxPut)
        '最低清算価格(Call)
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "BidPriceMinCall", BidPriceMinCallEnabled, BidPriceMinCall)
        '最低清算価格(Put)	
        CommonUtil.ReadDBColumnNullable(Of Decimal)(reader, "BidPriceMinPut", BidPriceMinPutEnabled, BidPriceMinPut)
    End Sub

End Class
