﻿Imports System.Data.SqlClient

Public Class DayStart

    Public Shared Function SystemCheck(
                                      ByRef NowDateTime As DateTime,
                                      ByRef NowDate As DateTime,
                                      ByRef NowWeekday As Integer,
                                      ByRef WeekdayCheck As Boolean,
                                      ByRef HolidayCheck As Boolean
                                      ) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_SystemCheck
                    Dim param As SqlParameter
                    param = cmd.Parameters.Add("@NowDateTime", SqlDbType.DateTime2, 7)
                    param.Direction = ParameterDirection.InputOutput
                    param.Value = NowDateTime
                    param = cmd.Parameters.Add("@NowDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@NowWeekday", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@WeekdayCheck", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@HolidayCheck", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output

                    cmd.ExecuteNonQuery()

                    NowDateTime = cmd.Parameters("@NowDateTime").Value
                    NowDate = cmd.Parameters("@NowDate").Value
                    NowWeekday = cmd.Parameters("@NowWeekday").Value
                    WeekdayCheck = (cmd.Parameters("@WeekdayCheck").Value = 1)
                    HolidayCheck = (cmd.Parameters("@HolidayCheck").Value = 1)
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public Shared Function UpdateSysDate(
                                        NowDate As DateTime,
                                        ByRef RunStartDay As Boolean,
                                        ByRef NowSysDate As DateTime,
                                        ByRef MonthlyStartFlg As Integer
                                        ) As Boolean                                '2013-09-05 Update 引数追加:MonthlyStartFlg
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_Update_SysDate
                    Dim param As SqlParameter
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.Parameters.Add("@NowDate", SqlDbType.Date).Value = NowDate
                    param = cmd.Parameters.Add("@RunStartDay", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@NowSysDate", SqlDbType.Date)
                    param.Direction = ParameterDirection.Output
                    param = cmd.Parameters.Add("@MonthlyStartFlg", SqlDbType.Int)   '2013-09-05 Add パラメータ追加
                    param.Direction = ParameterDirection.InputOutput                '2013-09-05 Add パラメータ追加
                    param.Value = MonthlyStartFlg                                   '2013-09-05 Add パラメータ追加

                    cmd.ExecuteNonQuery()

                    RunStartDay = (cmd.Parameters("@RunStartDay").Value = 1)
                    NowSysDate = cmd.Parameters("@NowSysDate").Value
                    MonthlyStartFlg = cmd.Parameters("@MonthlyStartFlg").Value      '2013-09-05 Add 戻り値:MonthlyStartFlg設定
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
