﻿Imports System.Data.SqlClient

Public Class Company

    Public Shared Function GetList(ByRef list As List(Of Company)) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [M_Company] order by [CmpCode]"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        list = New List(Of Company)
                        While reader.Read()
                            Dim objCompany As New Company
                            objCompany.CmpCode = reader("CmpCode")
                            objCompany.CmpName = reader("CmpName")

                            list.Add(objCompany)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public CmpCode As String
    Public CmpName As String
    
End Class
