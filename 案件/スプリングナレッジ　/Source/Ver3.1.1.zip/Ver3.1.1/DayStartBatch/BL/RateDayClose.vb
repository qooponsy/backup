﻿Imports System.Text
Imports System.Data.SqlClient

Public Class RateDayClose

    Public Shared Function GetList(ComCode As String, SysDate As DateTime, ByRef list As List(Of RateDayClose)) As Boolean
        list = New List(Of RateDayClose)

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select top 101 * from [T_RateDayClose] where [ComCode]=@ComCode and [SysDate] <= @SysDate order by [SysDate] desc"
                    cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ComCode
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    Using reader As SqlDataReader = cmd.ExecuteReader
                        While reader.Read
                            Dim item As New RateDayClose
                            item.ComCode = reader("ComCode")
                            item.SysDate = reader("SysDate")
                            item.RateSeq = reader("RateSeq")
                            item.RateTime = reader("RateTime")
                            item.Rate = reader("Rate")
                            list.Add(item)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public ComCode As String
    Public SysDate As DateTime
    Public RateSeq As String
    Public RateTime As DateTime
    Public Rate As Decimal

End Class
