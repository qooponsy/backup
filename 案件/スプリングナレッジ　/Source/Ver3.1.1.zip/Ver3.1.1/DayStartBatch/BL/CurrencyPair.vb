﻿Imports System.Data.SqlClient

Public Class CurrencyPair

    Public Shared Function GetList(ByRef list As List(Of CurrencyPair)) As Boolean
        list = New List(Of CurrencyPair)

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [M_CurrencyPair] order by [SortOrder]"
                    Using reader As SqlDataReader = cmd.ExecuteReader
                        While reader.Read
                            Dim item As New CurrencyPair
                            item.ComCode = reader("ComCode")
                            item.ComName = reader("ComName")
                            item.DecimalPlaces = reader("DecimalPlaces")
                            item.SortOrder = reader("SortOrder")
                            item.LimitOrderRate = reader("LimitOrderRate")
                            item.LimitAbandRate = reader("LimitAbandRate")
                            list.Add(item)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public ComCode As String
    Public ComName As String
    Public DecimalPlaces As Integer
    Public SortOrder As Integer
    Public LimitOrderRate As Decimal
    Public LimitAbandRate As Decimal

End Class
