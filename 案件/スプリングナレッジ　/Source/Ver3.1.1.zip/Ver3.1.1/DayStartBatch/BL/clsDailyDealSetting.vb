﻿Public Class clsDailyDealSetting
    Inherits clsDealSetting

    '取引停止対象取得SQL
    Private Const SELECT_T_CUSTHISTSPOT_DAILY_DEAL_STOP As String = "select " & _
                                                                    "[CustCode], [CmpCode] " & _
                                                                    "from " & _
                                                                    "[T_CustHistSpot] with ( nolock ) " & _
                                                                    "where " & _
                                                                    "[DealDisabled]='0' and " & _
                                                                    "[LossLimit] < -[PAndLMonthly]"

    '取引停止設定SQL
    Private Const UPDATE_M_CUSTOMER_DAILY_DEAL_STOP As String = "update [M_Customer] " & _
                                                                "set " & _
                                                                "[UpdTime]=SYSUTCDATETIME(), [UpdUser]=@InsUser, [DealDisabled]='1' " & _
                                                                "where " & _
                                                                "[CustCode]=@CustCode and " & _
                                                                "[DealDisabled]='0'"

    '取引停止解除対象取得SQL
    Private Const SELECT_T_CUSTHISTSPOT_DAILY_DEAL_STOP_CANCEL As String = "select " & _
                                                                           "[CustCode], [CmpCode] " & _
                                                                           "from " & _
                                                                           "[T_CustHistSpot] with ( nolock ) " & _
                                                                           "where " & _
                                                                           "[DealDisabled]='1' and " & _
                                                                           "[LossLimit] >= -[PAndLMonthly]"

    '取引停止解除設定SQL
    Private Const UPDATE_M_CUSTOMER_DAILY_DEAL_STOP_CANCEL As String = "update [M_Customer] " & _
                                                                       "set " & _
                                                                       "[UpdTime]=SYSUTCDATETIME(), [UpdUser]=@InsUser, [DealDisabled]='0' " & _
                                                                       "where " & _
                                                                       "[CustCode]=@CustCode and " & _
                                                                       "[DealDisabled]='1'"

    '取引停止処理
    Public Shared Function DealStop(ByVal NewSysDate As DateTime) As Boolean
        Dim ret As Boolean = False

        ret = DealSetting(NewSysDate, SELECT_T_CUSTHISTSPOT_DAILY_DEAL_STOP, UPDATE_M_CUSTOMER_DAILY_DEAL_STOP, "取引停止判定 委託者コード:{0} 停止(日次処理)")

        Return ret
    End Function

    '取引解除処理
    Public Shared Function DealStopCancel(ByVal NewSysDate As DateTime) As Boolean
        Dim ret As Boolean = False

        ret = DealSetting(NewSysDate, SELECT_T_CUSTHISTSPOT_DAILY_DEAL_STOP_CANCEL, UPDATE_M_CUSTOMER_DAILY_DEAL_STOP_CANCEL, "取引停止判定 委託者コード:{0} 解除(日次処理)")

        Return ret
    End Function
End Class
