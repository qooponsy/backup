﻿Imports System.Data.SqlClient

Public Class clsMonthlyDealSetting
    Inherits clsDealSetting

    '最終バッチ実行日の取得用SQL(月次処理実行状態確認用)
    Private Const SELECT_S_SYSSETTING As String = "select " & _
                                                  "[LastBatchSysDate], [LastMonthlyBatchSysDate] " & _
                                                  "from " & _
                                                  "[S_SysStatus] with ( nolock ) " & _
                                                  "where " & _
                                                  "[SysCode]='0'"

    '最終バッチ実行日の更新用SQL(月次処理実行状態確認用)
    Private Const UPDATE_S_SYSSETTING As String = "update [S_SysStatus] " & _
                                                  "set " & _
                                                  "[UpdTime]=SYSUTCDATETIME(), [UpdUser]=@InsUser, [LastBatchSysDate]=@LastBatchSysDate " & _
                                                  "where " & _
                                                  "[SysCode]='0'"

    '取引停止中の対象取得SQL
    Private Const SELECT_T_CUSTHISTSPOT_MONTHLY_DEAL_STOP_CANCEL As String = "select " & _
                                                                             "[CustCode], [CmpCode] " & _
                                                                             "from " & _
                                                                             "[T_CustHistSpot] with ( nolock ) " & _
                                                                             "where " & _
                                                                             "[DealDisabled]='1'"

    '取引停止中解除設定SQL
    Private Const UPDATE_M_CUSTOMER_MONTHLY_DEAL_STOP_CANCEL As String = "update [M_Customer] " & _
                                                                         "set " & _
                                                                         "[UpdTime]=SYSUTCDATETIME(), [UpdUser]=@InsUser, [DealDisabled]='0' " & _
                                                                         "where " & _
                                                                         "[CustCode]=@CustCode and " & _
                                                                         "[DealDisabled]='1'"

    '月次処理実行チェック
    Public Shared Function BeginMonthlyCheck(ByVal NewSysDate As Date, ByRef MonthlyStartFlg As Integer) As Boolean
        Dim DBSuccess As Boolean = True
        Dim DBConnStr As String = My.Settings.DB
        Dim LastBatchSysDate As Date = Date.MaxValue
        Dim LastMonthlyBatchSysDate As Date = Date.MinValue

        Try
            If MonthlyStartFlg <> 0 Then
                Exit Try
            End If

            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = SELECT_S_SYSSETTING

                    Using Reader As SqlDataReader = cmd.ExecuteReader()
                        While Reader.Read
                            LastBatchSysDate = Reader.GetDateTime(0)
                            LastMonthlyBatchSysDate = Reader.GetDateTime(1)
                        End While
                    End Using
                End Using
            End Using

            If NewSysDate = LastMonthlyBatchSysDate OrElse LastBatchSysDate < LastMonthlyBatchSysDate Then '最終月次バッチ実行日とシステム営業日が同一または最終バッチ処理日が最終月次バッチ処理日より前
                '月次処理実行
                MonthlyStartFlg = 1
            End If

            SystemLog.DBSuccess(DBConnStr)
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
            DBSuccess = False
        End Try

        Return DBSuccess
    End Function

    '最終バッチ実行日更新
    Public Shared Function LastBatchSysDateUpdate(ByVal NewSysDate As Date) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB

        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = UPDATE_S_SYSSETTING
                    cmd.Parameters.Add("@LastBatchSysDate", SqlDbType.Date).Value = NewSysDate
                    cmd.Parameters.Add("@InsUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using
            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    '取引停止解除処理
    Public Shared Function DealStopCancel(ByVal NewSysDate As DateTime) As Boolean
        Dim ret As Boolean

        ret = DealSetting(NewSysDate, SELECT_T_CUSTHISTSPOT_MONTHLY_DEAL_STOP_CANCEL, UPDATE_M_CUSTOMER_MONTHLY_DEAL_STOP_CANCEL, "取引停止判定 委託者コード:{0} 解除(月次処理)")

        Return ret
    End Function
End Class
