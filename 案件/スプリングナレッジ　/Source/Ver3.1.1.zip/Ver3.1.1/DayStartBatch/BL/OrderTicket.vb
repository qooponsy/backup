﻿Imports System.Data.SqlClient

Public Class OrderTicket
    Public Shared Function Regist(SysDate As DateTime) As Boolean
        Dim RegistOrderTicketSuccess As Boolean = False

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_OrderTicketRegist
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            RegistOrderTicketSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return RegistOrderTicketSuccess
    End Function
End Class
