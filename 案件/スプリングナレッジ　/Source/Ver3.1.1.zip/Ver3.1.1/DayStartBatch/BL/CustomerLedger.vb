﻿Imports System.Data.SqlClient

Public Class CustomerLedger
    Public Shared Function Regist(SysDate As DateTime) As Boolean
        Dim RegistCustomerLedgerSuccess As Boolean = False

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = My.Resources.SQL_CustomerLedgerRegist
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            RegistCustomerLedgerSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return RegistCustomerLedgerSuccess
    End Function
End Class
