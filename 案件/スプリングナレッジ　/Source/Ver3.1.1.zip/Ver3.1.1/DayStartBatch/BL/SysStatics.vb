﻿Imports System.Data.SqlClient

Public Class SysStatics

    Public Shared SysDateStartTime As TimeSpan
    
    Public Shared Function getDB() As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [M_SysStatics] where [SysCode] = '0'"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            SysDateStartTime = reader("SysDateStartTime")
                        End If
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
