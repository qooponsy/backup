﻿Imports System.Data.SqlClient

Public Class clsDealSetting
    Private Class clsCustData
        Public CmpCode As String
        Public CustCode As String
    End Class

    '限度枠管理ログ追加用SQL
    Private Const INSERT_T_LOSSLIMITLOG As String = vbCrLf & "if @@ROWCOUNT > 0" & vbCrLf & _
                                                    "insert into [T_LossLimitLog] " & _
                                                    "( " & _
                                                    "[InsTime], [InsUser], [UpdTime], [UpdUser], [LogTime], " & _
                                                    "[SysDate], [CmpCode], [CustCode], [LogType], [LogText] " & _
                                                    ") " & _
                                                    "values " & _
                                                    "( " & _
                                                    "SYSUTCDATETIME(), @InsUser, SYSUTCDATETIME(), @InsUser, SYSUTCDATETIME(), " & _
                                                    "@SysDate, @CmpCode, @CustCode, '02', @LogText " & _
                                                    ")"

    '取引設定更新処理
    Protected Shared Function DealSetting(ByVal NewSysDate As DateTime, ByVal GetDealSettingCustSQL As String, ByVal UpdateDealSettingSQL As String, ByVal LogTextFormat As String) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Dim CustDataList As New List(Of clsCustData)

        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    '取引設定更新対象取得
                    cmd.CommandText = GetDealSettingCustSQL
                    Using Reader As SqlDataReader = cmd.ExecuteReader()
                        While Reader.Read
                            Dim CustData = New clsCustData
                            CustData.CustCode = Reader(0)
                            CustData.CmpCode = Reader(1)
                            CustDataList.Add(CustData)
                        End While
                    End Using

                    CmdParamAdd(cmd)
                    cmd.CommandText = UpdateDealSettingSQL & INSERT_T_LOSSLIMITLOG
                    cmd.Parameters("@InsUser").Value = "P:" + My.Settings.ProcessID
                    cmd.Parameters("@SysDate").Value = NewSysDate
                    For Each CustData As clsCustData In CustDataList
                        cmd.Parameters("@CustCode").Value = CustData.CustCode
                        cmd.Parameters("@CmpCode").Value = CustData.CmpCode
                        cmd.Parameters("@LogText").Value = String.Format(LogTextFormat, CustData.CustCode)
                        cmd.ExecuteNonQuery()
                    Next
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        CustDataList.Clear()
        CustDataList = Nothing

        Return DBSuccess
    End Function

    '取引設定、限度枠管理更新用パラメータ追加
    Private Shared Sub CmdParamAdd(ByRef cmd As SqlCommand)
        cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = ""
        cmd.Parameters.Add("@InsUser", SqlDbType.VarChar, 34).Value = ""
        cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = Date.MinValue
        cmd.Parameters.Add("@CmpCode", SqlDbType.VarChar, 10).Value = ""
        cmd.Parameters.Add("@LogText", SqlDbType.VarChar, 256).Value = ""
    End Sub
End Class
