﻿Imports System.Text
Imports System.Data.SqlClient

Public Class ProductGenerator

    Public Shared Function Generate(CreateDate As DateTime, PrevDate As DateTime, ByRef UpdateCount As Integer, ByRef GeneratedCount As Integer) As Boolean
        UpdateCount = 0

        Dim ret As Boolean = False

        While True
            '対象システム営業日の銘柄生成状況チェック
            If Not getCountSysDate(CreateDate, GeneratedCount) Then
                Exit While
            End If
            If GeneratedCount > 0 Then
                '生成済みの為終了
                SystemLog.Information(String.Format("Exist Product SysDate:{0:yyyy/MM/dd} Count:{1}", CreateDate, GeneratedCount))
                ret = True
                Exit While
            End If

            Dim sysDate As DateTime = CreateDate
            Dim sysDateStartTime As TimeSpan = SysStatics.SysDateStartTime
            Dim stopTradeTime As Integer = SysSettings.StopTradeTime
            Dim pbList As List(Of ProductBase) = Nothing
            If Not ProductBase.getList(pbList) Then
                Exit While
            End If

            Dim DBSuccess As Boolean = False
            Dim DBConnStr As String = My.Settings.DB
            Try
                Using con As New SqlConnection(DBConnStr)
                    con.Open()
                    Using tran As SqlTransaction = con.BeginTransaction()
                        Try
                            For Each pb As ProductBase In pbList
                                Dim startTime As New DateTime(sysDate.Year, sysDate.Month, sysDate.Day, pb.StartTime.Hours, pb.StartTime.Minutes, pb.StartTime.Seconds)
                                If pb.StartTime < sysDateStartTime Then
                                    startTime = startTime.AddDays(1)
                                End If

                                Dim endtime As New DateTime(sysDate.Year, sysDate.Month, sysDate.Day, pb.ExercTime.Hours, pb.ExercTime.Minutes, pb.ExercTime.Seconds)
                                If pb.ExercTime < sysDateStartTime Then
                                    endtime = endtime.AddDays(1)
                                End If

                                Dim exercTime As DateTime = startTime.AddMinutes(pb.OptionTime)

                                While exercTime <= endtime
                                    regist(
                                        con,
                                        tran,
                                        pb.ProductBaseCode,
                                        CreateDate,
                                        pb.ComCode,
                                        pb.OpType,
                                        startTime,
                                        exercTime,
                                        stopTradeTime,
                                        pb.PayoutRateEnabled, pb.PayoutRate,
                                        pb.ExercPriceTimespanEnabled, pb.ExercPriceTimespan,
                                        pb.ExercPriceUnitTypeEnabled, pb.ExercPriceUnitType,
                                        pb.ExercPriceUnitEnabled, pb.ExercPriceUnit,
                                        pb.ExercPriceSettingsEnabled, pb.ExercPriceSettings,
                                        pb.ExceptExercPriceEnabled, pb.ExceptExercPrice,
                                        pb.VolatilityRatio1CallEnabled, pb.VolatilityRatio1Call,
                                        pb.VolatilityRatio1PutEnabled, pb.VolatilityRatio1Put,
                                        pb.VolatilityRatio2CallEnabled, pb.VolatilityRatio2Call,
                                        pb.VolatilityRatio2PutEnabled, pb.VolatilityRatio2Put,
                                        pb.VolatilitySmileACallEnabled, pb.VolatilitySmileACall,
                                        pb.VolatilitySmileAPutEnabled, pb.VolatilitySmileAPut,
                                        pb.VolatilitySmileBCallEnabled, pb.VolatilitySmileBCall,
                                        pb.VolatilitySmileBPutEnabled, pb.VolatilitySmileBPut,
                                        pb.VolatilitySpreadEnabled, pb.VolatilitySpread,
                                        pb.VolatilitySpreadITMCallEnabled, pb.VolatilitySpreadITMCall,
                                        pb.VolatilitySpreadITMPutEnabled, pb.VolatilitySpreadITMPut,
                                        pb.VolatilitySpreadOTMCallEnabled, pb.VolatilitySpreadOTMCall,
                                        pb.VolatilitySpreadOTMPutEnabled, pb.VolatilitySpreadOTMPut,
                                        pb.AskFeePriceCallEnabled, pb.AskFeePriceCall,
                                        pb.AskFeePricePutEnabled, pb.AskFeePricePut,
                                        pb.AskBidSpreadMinCallEnabled, pb.AskBidSpreadMinCall,
                                        pb.AskBidSpreadMinPutEnabled, pb.AskBidSpreadMinPut,
                                        pb.BidFeeRateCallEnabled, pb.BidFeeRateCall,
                                        pb.BidFeeRatePutEnabled, pb.BidFeeRatePut,
                                        pb.AskPriceMaxCallEnabled, pb.AskPriceMaxCall,
                                        pb.AskPriceMaxPutEnabled, pb.AskPriceMaxPut,
                                        pb.AskPriceMinCallEnabled, pb.AskPriceMinCall,
                                        pb.AskPriceMinPutEnabled, pb.AskPriceMinPut,
                                        pb.BidPriceMaxCallEnabled, pb.BidPriceMaxCall,
                                        pb.BidPriceMaxPutEnabled, pb.BidPriceMaxPut,
                                        pb.BidPriceMinCallEnabled, pb.BidPriceMinCall,
                                        pb.BidPriceMinPutEnabled, pb.BidPriceMinPut)
                                    UpdateCount += 1
                                    startTime = startTime.AddMinutes(pb.CreateTime)
                                    exercTime = startTime.AddMinutes(pb.OptionTime)
                                End While
                            Next

                            tran.Commit()
                        Catch ex As Exception
                            SystemLog.AppError(ex)
                            Try
                                tran.Rollback()
                            Catch ex2 As Exception
                                SystemLog.AppError(ex2)
                            End Try
                            Throw
                        End Try
                    End Using
                End Using

                SystemLog.DBSuccess(DBConnStr)
                DBSuccess = True
            Catch ex As Exception
                SystemLog.DBError(DBConnStr, ex)
            End Try

            Return DBSuccess

            ret = True
            Exit While
        End While

        Return ret
    End Function

    Public Shared Function getCountSysDate(ByVal SysDate As DateTime, ByRef ProductCount As Integer) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            ProductCount = 0
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select COUNT(*) from [M_Product] with (nolock) where [SysDate] = @SysDate and [Enabled] = '1'"
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    ProductCount = cmd.ExecuteScalar()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public Shared Sub regist(
                            con As SqlConnection,
                            tran As SqlTransaction,
                            ProductBaseCode As String,
                            SysDate As DateTime,
                            ComCode As String,
                            OpType As String,
                            StartTime As DateTime,
                            ExercTime As DateTime,
                            StopTradeTime As Integer,
                            PayoutRateEnabled As Boolean, PayoutRate As Decimal,
                            ExercPriceTimespanEnabled As Boolean, ExercPriceTimespan As Integer,
                            ExercPriceUnitTypeEnabled As Boolean, ExercPriceUnitType As String,
                            ExercPriceUnitEnabled As Boolean, ExercPriceUnit As Decimal,
                            ExercPriceSettingsEnabled As Boolean, ExercPriceSettings As String,
                            ExceptExercPriceEnabled As Boolean, ExceptExercPrice As String,
                            VolatilityRatio1CallEnabled As Boolean, VolatilityRatio1Call As Decimal,
                            VolatilityRatio1PutEnabled As Boolean, VolatilityRatio1Put As Decimal,
                            VolatilityRatio2CallEnabled As Boolean, VolatilityRatio2Call As Decimal,
                            VolatilityRatio2PutEnabled As Boolean, VolatilityRatio2Put As Decimal,
                            VolatilitySmileACallEnabled As Boolean, VolatilitySmileACall As Decimal,
                            VolatilitySmileAPutEnabled As Boolean, VolatilitySmileAPut As Decimal,
                            VolatilitySmileBCallEnabled As Boolean, VolatilitySmileBCall As Decimal,
                            VolatilitySmileBPutEnabled As Boolean, VolatilitySmileBPut As Decimal,
                            VolatilitySpreadEnabled As Boolean, VolatilitySpread As Decimal,
                            VolatilitySpreadITMCallEnabled As Boolean, VolatilitySpreadITMCall As Decimal,
                            VolatilitySpreadITMPutEnabled As Boolean, VolatilitySpreadITMPut As Decimal,
                            VolatilitySpreadOTMCallEnabled As Boolean, VolatilitySpreadOTMCall As Decimal,
                            VolatilitySpreadOTMPutEnabled As Boolean, VolatilitySpreadOTMPut As Decimal,
                            AskFeePriceCallEnabled As Boolean, AskFeePriceCall As Decimal,
                            AskFeePricePutEnabled As Boolean, AskFeePricePut As Decimal,
                            AskBidSpreadMinCallEnabled As Boolean, AskBidSpreadMinCall As Decimal,
                            AskBidSpreadMinPutEnabled As Boolean, AskBidSpreadMinPut As Decimal,
                            BidFeeRateCallEnabled As Boolean, BidFeeRateCall As Decimal,
                            BidFeeRatePutEnabled As Boolean, BidFeeRatePut As Decimal,
                            AskPriceMaxCallEnabled As Boolean, AskPriceMaxCall As Decimal,
                            AskPriceMaxPutEnabled As Boolean, AskPriceMaxPut As Decimal,
                            AskPriceMinCallEnabled As Boolean, AskPriceMinCall As Decimal,
                            AskPriceMinPutEnabled As Boolean, AskPriceMinPut As Decimal,
                            BidPriceMaxCallEnabled As Boolean, BidPriceMaxCall As Decimal,
                            BidPriceMaxPutEnabled As Boolean, BidPriceMaxPut As Decimal,
                            BidPriceMinCallEnabled As Boolean, BidPriceMinCall As Decimal,
                            BidPriceMinPutEnabled As Boolean, BidPriceMinPut As Decimal)

        Dim newSeq As String = NewProductCode(con, tran)

        Using cmd As SqlCommand = con.CreateCommand
            cmd.Transaction = tran
            Dim ratetime As DateTime = DateTime.Now
            cmd.CommandText = My.Resources.SQL_Product_Regist
            cmd.Parameters.Add("@User", SqlDbType.Char, 34).Value = "P:" + My.Settings.ProcessID
            cmd.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = newSeq
            cmd.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = IIf(ProductBaseCode Is Nothing, DBNull.Value, ProductBaseCode)
            cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ComCode
            cmd.Parameters.Add("@OpType", SqlDbType.Char, 2).Value = OpType
            cmd.Parameters.Add("@StartTime", SqlDbType.DateTime2, 7).Value = StartTime.AddMinutes(-SysSettings.TimeZone)
            cmd.Parameters.Add("@ExercTime", SqlDbType.DateTime2, 7).Value = ExercTime.AddMinutes(-SysSettings.TimeZone)
            cmd.Parameters.Add("@StopTradeTime", SqlDbType.Int).Value = StopTradeTime
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@PayoutRate", 15, 8, PayoutRateEnabled, PayoutRate)
            CommonUtil.AddDBParameterNullableInt(cmd, "@ExercPriceTimespan", ExercPriceTimespanEnabled, ExercPriceTimespan)
            CommonUtil.AddDBParameterNullableWithSize(cmd, "@ExercPriceUnitType", SqlDbType.Char, 1, ExercPriceUnitTypeEnabled, ExercPriceUnitType)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@ExercPriceUnit", 15, 8, ExercPriceUnitEnabled, ExercPriceUnit)
            CommonUtil.AddDBParameterNullableWithSize(cmd, "@ExercPriceSettings", SqlDbType.VarChar, 256, ExercPriceSettingsEnabled, ExercPriceSettings)
            CommonUtil.AddDBParameterNullableWithSize(cmd, "@ExceptExercPrice", SqlDbType.VarChar, 256, ExceptExercPriceEnabled, ExceptExercPrice)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilityRatio1Call", 15, 8, VolatilityRatio1CallEnabled, VolatilityRatio1Call)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilityRatio1Put", 15, 8, VolatilityRatio1PutEnabled, VolatilityRatio1Put)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilityRatio2Call", 15, 8, VolatilityRatio2CallEnabled, VolatilityRatio2Call)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilityRatio2Put", 15, 8, VolatilityRatio2PutEnabled, VolatilityRatio2Put)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySmileACall", 15, 8, VolatilitySmileACallEnabled, VolatilitySmileACall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySmileAPut", 15, 8, VolatilitySmileAPutEnabled, VolatilitySmileAPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySmileBCall", 15, 8, VolatilitySmileBCallEnabled, VolatilitySmileBCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySmileBPut", 15, 8, VolatilitySmileBPutEnabled, VolatilitySmileBPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySpread", 15, 8, VolatilitySpreadEnabled, VolatilitySpread)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySpreadITMCall", 15, 8, VolatilitySpreadITMCallEnabled, VolatilitySpreadITMCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySpreadITMPut", 15, 8, VolatilitySpreadITMPutEnabled, VolatilitySpreadITMPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySpreadOTMCall", 15, 8, VolatilitySpreadOTMCallEnabled, VolatilitySpreadOTMCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@VolatilitySpreadOTMPut", 15, 8, VolatilitySpreadOTMPutEnabled, VolatilitySpreadOTMPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskFeePriceCall", 15, 8, AskFeePriceCallEnabled, AskFeePriceCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskFeePricePut", 15, 8, AskFeePricePutEnabled, AskFeePricePut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskBidSpreadMinCall", 15, 8, AskBidSpreadMinCallEnabled, AskBidSpreadMinCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskBidSpreadMinPut", 15, 8, AskBidSpreadMinPutEnabled, AskBidSpreadMinPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@BidFeeRateCall", 15, 8, BidFeeRateCallEnabled, BidFeeRateCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@BidFeeRatePut", 15, 8, BidFeeRatePutEnabled, BidFeeRatePut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskPriceMaxCall", 15, 8, AskPriceMaxCallEnabled, AskPriceMaxCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskPriceMaxPut", 15, 8, AskPriceMaxPutEnabled, AskPriceMaxPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskPriceMinCall", 15, 8, AskPriceMinCallEnabled, AskPriceMinCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@AskPriceMinPut", 15, 8, AskPriceMinPutEnabled, AskPriceMinPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@BidPriceMaxCall", 15, 8, BidPriceMaxCallEnabled, BidPriceMaxCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@BidPriceMaxPut", 15, 8, BidPriceMaxPutEnabled, BidPriceMaxPut)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@BidPriceMinCall", 15, 8, BidPriceMinCallEnabled, BidPriceMinCall)
            CommonUtil.AddDBParameterNullableDecimal(cmd, "@BidPriceMinPut", 15, 8, BidPriceMinPutEnabled, BidPriceMinPut)
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Function NewProductCode(con As SqlConnection, tran As SqlTransaction) As String
        Dim result As String

        Using cmd As SqlCommand = con.CreateCommand
            cmd.Transaction = tran
            Dim sql As New StringBuilder
            sql.AppendLine("declare @Counter int")
            sql.AppendLine("select")
            sql.AppendLine("	 @Counter = [Counter]")
            sql.AppendLine("	from [S_Counter] with (updlock)")
            sql.AppendLine("	where [CounterCode] = '04'")
            sql.AppendLine("update [S_Counter] set")
            sql.AppendLine("	 [Counter] = @Counter + 1")
            sql.AppendLine("	where [CounterCode] = '04'")
            sql.AppendLine("select")
            sql.AppendLine("	 convert(char(8), [SysDate], 112)")
            sql.AppendLine("	 + replicate('0' ,9 - len(@Counter))")
            sql.AppendLine("	 + convert(varchar(9),@Counter)")
            sql.AppendLine("	from [S_SysStatus] ")
            sql.AppendLine("	where [SysCode] = '0'")
            cmd.CommandText = sql.ToString()
            result = cmd.ExecuteScalar()
        End Using

        Return result
    End Function

End Class
