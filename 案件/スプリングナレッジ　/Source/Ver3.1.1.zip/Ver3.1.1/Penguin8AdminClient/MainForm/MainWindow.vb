Imports System.Threading

''' <summary>
''' メインメニュー
''' </summary>
''' <remarks></remarks>
Public Class MainWindow
    Public SubFormProductBase As Boolean = False
    Public SubFormProduct As Boolean = False
    Public SubFormRateHist As Boolean = False
    Public SubFormRateChartHist As Boolean = False
    Public SubFormCust As Boolean = False
    Public SubFormCustAttrForm As Boolean = False
    Public SubFormCustAccountForm As Boolean = False
    Public SubFormTrade As Boolean = False
    Public SubFormCash As Boolean = False
    Public SubFormSysSettingsForm As Boolean = False
    Public SubFormSysControlForm As Boolean = False
    Public SubFormRiskMonitor As Boolean = False
    Public SubFormRiskSimulate As Boolean = False
    Public SubFormPrisingParamList As Boolean = False
    Public SubFormSalesPerformance As Boolean = False
    Public SubFormNowStatus As Boolean = False
    Public SubFormUser As Boolean = False
    Public SubFormOperationHistClientList As Boolean = False

    Public SubFormProductBaseForm As Boolean = False
    Public SubFormProductForm As Boolean = False
    Public SubFormProductList As Boolean = False
    Public SubFormProductSubForm As Boolean = False
    Public SubFormRateHistForm As Boolean = False
    Public SubFormTradeForm As Boolean = False
    Public SubFormCashForm As Boolean = False
    Public SubFormUserForm As Boolean = False
    Public SubFormUserChangePasswordForm As Boolean = False

    Public SubFormRateFilterForm As Boolean = False
    Public SubFormRateMonitor As Boolean = False
    Public SubFormRateFilterLogList As Boolean = False
    Public SubFormPriceMonitor As Boolean = False

    Public SubFormCalcParamSettingsForm As Boolean = False

    Public SubFormLossLimitLogList As Boolean = False
    Public SubFormRateChartForm As Boolean = False
    Public SubFormPremiumChartHistList As Boolean = False
    Public SubFormExercResultList As Boolean = False

    Public SubFormOrderTicketList As Boolean = False
    Public SubFormTradeDiaryList As Boolean = False
    Public SubFormCustomerLedgerListList As Boolean = False

    Public SubFormFileDownloadList As Boolean = False

    Private WithEvents serviceDDD As DDDService = Nothing
    Private WithEvents serviceRateLog As RateFilterLogService = Nothing

    Private RateFilterUpdateSeq As Long = Long.MaxValue
    Private LastAlertSoundTime As DateTime = DateTime.MinValue
    Friend Shared SubFormPremiumChartForm As Boolean

    ''' <summary>
    ''' フォームロードイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainMenu_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        Dim EnvTitle As String = clsUtil.GetEnvTitle()
        If EnvTitle <> "" Then
            Me.Text = Me.Text & "(" & EnvTitle & ")"
        End If
        'Me.Hide()

        Init()
        LoadSettings()

        'Me.Show()
    End Sub

    Private Sub MainWindow_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        UserSettings.getInstance().DataSaved.MainWindow_SubFormProductBase = SubFormProductBase
        UserSettings.getInstance().DataSaved.MainWindow_SubFormProduct = SubFormProduct
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateHist = SubFormRateHist
        UserSettings.getInstance().DataSaved.MainWindow_SubFormCust = SubFormCust
        UserSettings.getInstance().DataSaved.MainWindow_SubFormTrade = SubFormTrade
        UserSettings.getInstance().DataSaved.MainWindow_SubFormCash = SubFormCash
        UserSettings.getInstance().DataSaved.MainWindow_SubFormSysSettingsForm = SubFormSysSettingsForm
        UserSettings.getInstance().DataSaved.MainWindow_SubFormSysControlForm = SubFormSysControlForm
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskMonitor = SubFormRiskMonitor
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskSimulate = SubFormRiskSimulate
        UserSettings.getInstance().DataSaved.MainWindow_SubFormPrisingParamList = SubFormPrisingParamList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormSalesPerformance = SubFormSalesPerformance
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateMonitor = SubFormRateMonitor
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateFilterLogList = SubFormRateFilterLogList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormNowStatus = SubFormNowStatus
        UserSettings.getInstance().DataSaved.MainWindow_SubFormUser = SubFormUser
        UserSettings.getInstance().DataSaved.MainWindow_SubFormUser = SubFormCalcParamSettingsForm
        UserSettings.getInstance().DataSaved.MainWindow_subFormLossLimitLogList = SubFormLossLimitLogList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateChartHist = SubFormRateChartHist
        UserSettings.getInstance().DataSaved.MainWindow_SubFormPremiumChartHist = SubFormPremiumChartHistList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormPriceMonitor = SubFormPriceMonitor
        UserSettings.getInstance().DataSaved.MainWindow_SubFormOrderTicketList = SubFormOrderTicketList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormTradeDiaryList = SubFormTradeDiaryList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormCustomerLedgerList = SubFormCustomerLedgerListList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormOperationHistClientList = SubFormOperationHistClientList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormFileDownloadList = SubFormFileDownloadList
    End Sub

    ''' <summary>
    ''' フォームクローズイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainMenu_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        term()

        'アプリケーション終了処理
        If e.CloseReason <> CloseReason.ApplicationExitCall Then
            'メニュー以外からの終了時はApplication.Exit()を実行することで開いているフォームのFormClosedイベントを発生させる
            Application.Exit()
        End If
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadFormSettings(Me,
            False,
            UserSettings.getInstance().DataSaved.MainWindow_FormSize,
            UserSettings.getInstance().DataSaved.MainWindow_FormLocation)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me,
            UserSettings.getInstance().DataSaved.MainWindow_FormMaximized,
            UserSettings.getInstance().DataSaved.MainWindow_FormSize,
            UserSettings.getInstance().DataSaved.MainWindow_FormLocation)
        UserSettings.getInstance().save()
    End Sub

    ''' <summary>
    ''' 初期化処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainMenu_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If UserSettings.getInstance().DataSaved.MainWindow_FormMaximized Then
            Me.WindowState = FormWindowState.Maximized
        End If
        InitSubForm()
    End Sub

    Private Sub InitSubForm()

        Dim whitelabel As Boolean = UserTypeManager.IsWL(SessionService.UserType)

        If UserSettings.getInstance().DataSaved.MainWindow_SubFormProductBase Then
            ProductBaseList.MdiParent = Me
            ProductBaseList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormProduct Then
            ProductList.MdiParent = Me
            ProductList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormRateHist Then
            RateHistList.MdiParent = Me
            RateHistList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormCust Then
            CustList.MdiParent = Me
            CustList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormTrade Then
            TradeList.MdiParent = Me
            TradeList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormCash Then
            CashList.MdiParent = Me
            CashList.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormSysSettingsForm Then
            SysSettingsForm.MdiParent = Me
            SysSettingsForm.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormSysControlForm Then
            SysControlForm.MdiParent = Me
            SysControlForm.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskMonitor Then
            RiskMonitor.MdiParent = Me
            RiskMonitor.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskSimulate Then
            RiskSimulate.MdiParent = Me
            RiskSimulate.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormPrisingParamList Then
            CalcParamHist.MdiParent = Me
            CalcParamHist.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormSalesPerformance Then
            SalesPerformanceList.MdiParent = Me
            SalesPerformanceList.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRateMonitor Then
            RateMonitor.MdiParent = Me
            RateMonitor.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRateFilterLogList Then
            RateFilterLogList.MdiParent = Me
            RateFilterLogList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormNowStatus Then
            NowStatusForm.MdiParent = Me
            NowStatusForm.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormUser Then
            UserList.MdiParent = Me
            UserList.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_subFormLossLimitLogList Then
            LossLimitLogList.MdiParent = Me
            LossLimitLogList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormRateChartHist Then
            RateChartHistList.MdiParent = Me
            RateChartHistList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormPremiumChartHist Then
            PriceChartHistList.MdiParent = Me
            PriceChartHistList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormPriceMonitor Then
            PriceMonitor.MdiParent = Me
            PriceMonitor.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormOrderTicketList Then
            OrderTicketList.MdiParent = Me
            OrderTicketList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormTradeDiaryList Then
            TradeDiaryList.MdiParent = Me
            TradeDiaryList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormCustomerLedgerList Then
            CustomerLedgerList.MdiParent = Me
            CustomerLedgerList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormOperationHistClientList Then
            OperationHistClientList.MdiParent = Me
            OperationHistClientList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormFileDownloadList Then
            FileDownloadList.MdiParent = Me
            FileDownloadList.Show()
        End If
        serviceDDD = New DDDService
    End Sub

    Private Sub Init()
        SetUserInfo()
        SetMenu()
        setTickInfo()
        RateFilterUpdateSeq = DDDService.RateFilterUpdateSeq
        SetAlertMessage(Nothing)
    End Sub

    Private Sub term()
        serviceDDD = Nothing

        'フォーム設定の保存
        SaveSettings()

        SessionService.LogoutAdmin()
    End Sub

    Private NewTickErrorCount As Integer = 0
    Private Sub serviceDDD_NewDDD() Handles serviceDDD.NewDDD
        NewTickErrorCount = 0
        setTickInfo()
        setRateLog()
    End Sub

    Private Sub serviceDDD_NewDDDError(ErrorMessage As String) Handles serviceDDD.NewDDDError
        NewTickErrorCount += 1
        If (NewTickErrorCount >= 10) Then
            SessionService.ChangeConnectMode()
            NewTickErrorCount = 0
        End If
    End Sub

    Private Sub setTickInfo()
        Dim StatusName As String = ""
        Dim NextTimeTitle As String = ""
        If DDDService.ProductStatus = 1 Then
            StatusName = "取引中"
            NextTimeTitle = "停止日時 "
        Else
            StatusName = "停止中"
            NextTimeTitle = "開始日時 "
        End If
        slServerTime.Text = String.Format("サーバー時刻 {0:HH:mm:ss}", DDDService.ServerTime)
        slServerStatus.Text = String.Format("　ステータス:{0}", StatusName)
        slServerNextTime.Text = String.Format("　{0} {1:yyyy/MM/dd HH:mm:ss}", NextTimeTitle, DDDService.NextTime)
        slServer.Text = String.Format("　接続先 {0}", SessionService.GetConnectText())
    End Sub

    Private Sub setRateLog()
        If Me.RateFilterUpdateSeq < DDDService.RateFilterUpdateSeq Then
            serviceRateLog = New RateFilterLogService
            serviceRateLog.Read(Me.RateFilterUpdateSeq)
            Me.RateFilterUpdateSeq = DDDService.RateFilterUpdateSeq
        End If
    End Sub

    Private Sub SetAlertMessage(item As RateFilterLogData)
        If item Is Nothing Then
            PanelAlert.Visible = False
            lblAlertMessage.Text = ""
        Else
            PanelAlert.Visible = True
            lblAlertMessage.Text = String.Format("{0:yyyy/MM/dd HH:mm:ss.fff}　{1}", item.LogTime, item.LogText)
            'System.Media.SystemSounds.Asterisk.Play()
            'System.Media.SystemSounds.Beep.Play()
            If Now.Subtract(LastAlertSoundTime).TotalSeconds() > 5 Then
                System.Media.SystemSounds.Exclamation.Play()
                LastAlertSoundTime = Now
            End If
        End If
    End Sub

    Private Sub SetUserInfo()
        slServer.Text = String.Format("　接続先 {0}", SessionService.GetConnectText())
        slUser.Text = String.Format("　UserID:{0}  Name:{1}", SessionService.UserID, SessionService.UserName)
    End Sub

    Private Sub SetMenu()
        Dim admin As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        Dim adminview As Boolean = UserTypeManager.IsAdminView(SessionService.UserType)
        Dim edit As Boolean = UserTypeManager.IsEdit(SessionService.UserType)
        Dim referrer As Boolean = UserTypeManager.IsReferrer(SessionService.UserType)
        Dim whitelabel As Boolean = UserTypeManager.IsWL(SessionService.UserType)
        miProductBaseReg.Enabled = admin
        miProductReg.Enabled = admin
        miRateList.Enabled = edit Or referrer
        miRateReg.Enabled = admin
        miRateFilterLog.Enabled = edit Or referrer
        miUserList.Enabled = adminview Or whitelabel
        miTradeReg.Enabled = edit
        miCashReg.Enabled = edit
    End Sub

    Private Sub miFileLogout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miFileLogout.Click
        Me.Close()
    End Sub

    Private Sub miVersion_Click(sender As System.Object, e As System.EventArgs) Handles miVersion.Click
        Using VI As frmVersionInformation = New frmVersionInformation()
            VI.ShowDialog()
        End Using
    End Sub

    Private Sub miProductList_Click(sender As System.Object, e As System.EventArgs) Handles miProductList.Click
        If SubFormProduct Then
            ProductList.Activate()
        Else
            ProductList.MdiParent = Me
            ProductList.Show()
        End If
    End Sub

    Private Sub miRateList_Click(sender As System.Object, e As System.EventArgs) Handles miRateList.Click
        If SubFormRateHist Then
            RateHistList.Activate()
        Else
            RateHistList.MdiParent = Me
            RateHistList.Show()
        End If
    End Sub

    Private Sub miRateChartList_Click(sender As System.Object, e As System.EventArgs) Handles miRateChartList.Click
        If SubFormRateChartHist Then
            RateChartHistList.Activate()
        Else
            RateChartHistList.MdiParent = Me
            RateChartHistList.Show()
        End If
    End Sub

    Private Sub miSysSettingsForm_Click(sender As System.Object, e As System.EventArgs) Handles miSysSettingsForm.Click
        If SubFormSysSettingsForm Then
            SysSettingsForm.Activate()
        Else
            SysSettingsForm.MdiParent = Me
            SysSettingsForm.Show()
        End If
    End Sub

    Private Sub miProductBaseList_Click(sender As System.Object, e As System.EventArgs) Handles miProductBaseList.Click
        If SubFormProductBase Then
            ProductBaseList.Activate()
        Else
            ProductBaseList.MdiParent = Me
            ProductBaseList.Show()
        End If
    End Sub

    Private Sub miSysControlForm_Click(sender As System.Object, e As System.EventArgs) Handles miSysControlForm.Click
        If SubFormSysControlForm Then
            SysControlForm.Activate()
        Else
            SysControlForm.MdiParent = Me
            SysControlForm.Show()
        End If
    End Sub

    Private Sub miTradeList_Click(sender As System.Object, e As System.EventArgs) Handles miTradeList.Click
        If SubFormTrade Then
            TradeList.Activate()
        Else
            TradeList.MdiParent = Me
            TradeList.Show()
        End If
    End Sub

    Private Sub miCashList_Click(sender As System.Object, e As System.EventArgs) Handles miCashList.Click
        If SubFormCash Then
            CashList.Activate()
        Else
            CashList.MdiParent = Me
            CashList.Show()
        End If
    End Sub

    Private Sub miRiskMonitor_Click(sender As System.Object, e As System.EventArgs) Handles miRiskMonitor.Click
        If SubFormRiskMonitor Then
            RiskMonitor.Activate()
        Else
            RiskMonitor.MdiParent = Me
            RiskMonitor.Show()
        End If
    End Sub

    Private Sub miRiskSimulate_Click(sender As System.Object, e As System.EventArgs) Handles miRiskSimulate.Click
        If SubFormRiskSimulate Then
            RiskSimulate.Activate()
        Else
            RiskSimulate.MdiParent = Me
            RiskSimulate.Show()
        End If
    End Sub

    Private Sub miPrisingParamList_Click(sender As System.Object, e As System.EventArgs) Handles miPrisingParamList.Click
        If SubFormPrisingParamList Then
            CalcParamHist.Activate()
        Else
            CalcParamHist.MdiParent = Me
            CalcParamHist.Show()
        End If
    End Sub

    Private Sub miSalesPerformance_Click(sender As System.Object, e As System.EventArgs) Handles miSalesPerformance.Click
        If SubFormSalesPerformance Then
            SalesPerformanceList.Activate()
        Else
            SalesPerformanceList.MdiParent = Me
            SalesPerformanceList.Show()
        End If
    End Sub

    Private Sub miProductBaseReg_Click(sender As System.Object, e As System.EventArgs) Handles miProductBaseReg.Click
        If SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = Me
        ProductBaseForm.Code = ""
        ProductBaseForm.Show()
    End Sub

    Private Sub miProductReg_Click(sender As System.Object, e As System.EventArgs) Handles miProductReg.Click
        If SubFormProductForm Then
            ProductForm.Close()
        End If
        ProductForm.MdiParent = Me
        ProductForm.Code = ""
        ProductForm.Show()
    End Sub

    Private Sub miRateReg_Click(sender As System.Object, e As System.EventArgs) Handles miRateReg.Click
        If SubFormRateHistForm Then
            RateHistForm.Close()
        End If
        RateHistForm.MdiParent = Me
        RateHistForm.Code = ""
        RateHistForm.Show()
    End Sub

    Private Sub miTradeReg_Click(sender As System.Object, e As System.EventArgs) Handles miTradeReg.Click
        If SubFormTradeForm Then
            TradeForm.Close()
        End If
        TradeForm.MdiParent = Me
        TradeForm.Code = ""
        TradeForm.Show()
    End Sub

    Private Sub miCashReg_Click(sender As System.Object, e As System.EventArgs) Handles miCashReg.Click
        If SubFormCashForm Then
            CashForm.Close()
        End If
        CashForm.MdiParent = Me
        CashForm.Code = ""
        CashForm.Show()
    End Sub

    Private Sub miRateFilterLog_Click(sender As System.Object, e As System.EventArgs) Handles miRateFilterLog.Click
        If SubFormRateFilterLogList Then
            RateFilterLogList.Close()
        End If
        RateFilterLogList.MdiParent = Me
        RateFilterLogList.Show()
    End Sub

    Private Sub miRateMonitor_Click(sender As System.Object, e As System.EventArgs) Handles miRateMonitor.Click
        If SubFormRateMonitor Then
            RateMonitor.Close()
        End If
        RateMonitor.MdiParent = Me
        RateMonitor.Show()
    End Sub

    Private Sub miPriceMonitor_Click(sender As System.Object, e As System.EventArgs) Handles miPriceMonitor.Click
        If SubFormPriceMonitor Then
            PriceMonitor.Close()
        End If
        PriceMonitor.MdiParent = Me
        PriceMonitor.Show()
    End Sub

    Private Sub miLossLimitLogList_Click(sender As System.Object, e As System.EventArgs) Handles miLossLimitLogList.Click
        If SubFormLossLimitLogList Then
            LossLimitLogList.Close()
        End If
        LossLimitLogList.MdiParent = Me
        LossLimitLogList.Show()
    End Sub

    Private Sub miNowStatusForm_Click(sender As System.Object, e As System.EventArgs) Handles miNowStatusForm.Click
        If SubFormNowStatus Then
            NowStatusForm.Activate()
        Else
            NowStatusForm.MdiParent = Me
            NowStatusForm.Show()
        End If
    End Sub

    Private Sub miCustList_Click(sender As System.Object, e As System.EventArgs) Handles miCustList.Click
        If SubFormCust Then
            CustList.Activate()
        Else
            CustList.MdiParent = Me
            CustList.Show()
        End If
    End Sub

    Private Sub miPremiumChartHistList_Click(sender As System.Object, e As System.EventArgs) Handles miPremiumChartList.Click
        If SubFormPremiumChartHistList Then
            PriceChartHistList.Activate()
        Else
            PriceChartHistList.MdiParent = Me
            PriceChartHistList.Show()
        End If
    End Sub

    Private Sub miExercResultList_Click() Handles miExercResultList.Click
        If SubFormExercResultList Then
            ExercResultList.Activate()
        Else
            ExercResultList.MdiParent = Me
            ExercResultList.Show()
        End If
    End Sub

    Private Sub miUserList_Click(sender As System.Object, e As System.EventArgs) Handles miUserList.Click
        If SubFormUser Then
            UserList.Activate()
        Else
            UserList.MdiParent = Me
            UserList.Show()
        End If
    End Sub

    Private Sub miChangePassword_Click(sender As System.Object, e As System.EventArgs) Handles miChangePassword.Click
        Dim dlg As New ChangePassword
        dlg.ShowDialog(Me)
    End Sub

    Private Sub miTestA_Click(sender As System.Object, e As System.EventArgs) Handles miTestA.Click
        TestA.MdiParent = Me
        TestA.Show()
    End Sub

    Private Sub miTestB_Click(sender As System.Object, e As System.EventArgs) Handles miTestB.Click
        TestB.MdiParent = Me
        TestB.Show()
    End Sub

    Private Sub miTestC_Click(sender As System.Object, e As System.EventArgs) Handles miTestC.Click
        ProductList.MdiParent = Me
        ProductList.Show()
    End Sub

    Private Sub miTestD_Click(sender As System.Object, e As System.EventArgs) Handles miTestD.Click
        TestD.MdiParent = Me
        TestD.Show()
    End Sub

    Private Sub miTestE_Click(sender As System.Object, e As System.EventArgs) Handles miTestE.Click
        TestE.MdiParent = Me
        TestE.Show()
    End Sub

    Private Sub serviceRateLog_ReadCancel() Handles serviceRateLog.ReadCancel
        serviceRateLog = Nothing
    End Sub

    Private Sub serviceRateLog_ReadError(ErrorMessage As String) Handles serviceRateLog.ReadError
        serviceRateLog = Nothing
    End Sub

    Private Sub serviceRateLog_ReadSuccess(list As System.Collections.Generic.List(Of RateFilterLogData), ExistNextFlag As Boolean, RateFilterUpdateSeq As Long) Handles serviceRateLog.ReadSuccess
        serviceRateLog = Nothing
        For Each item As RateFilterLogData In list
            If isAlertType(item.LogType) Then
                SetAlertMessage(item)
                Exit For
            End If
        Next
    End Sub

    Private Function isAlertType(LogType As String) As Boolean
        Select Case LogType
            Case "01" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterSettings
            Case "11" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateFilter
            Case "12" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterCounterClear
            Case "13" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateChanged
            Case "14" : Return UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRate
            Case "15" : Return UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRateClear
            Case "21" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiff
            Case "22" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiffClear
        End Select
        Return False
    End Function

    Private Sub btnAlertClose_Click(sender As System.Object, e As System.EventArgs) Handles btnAlertClose.Click
        PanelAlert.Visible = False
    End Sub



    Private Sub miPricingSim1_Click(sender As System.Object, e As System.EventArgs) Handles miPricingSim1.Click
        PricingSim1.Show()
    End Sub

    Private Sub miPricingSim2_Click(sender As System.Object, e As System.EventArgs) Handles miPricingSim2.Click
        PricingSim2.Show()
    End Sub

    Private Sub miOrderTicket_Click(sender As System.Object, e As System.EventArgs) Handles miOrderTicket.Click
        If SubFormOrderTicketList Then
            OrderTicketList.Activate()
        Else
            OrderTicketList.MdiParent = Me
            OrderTicketList.Show()
        End If
    End Sub

    Private Sub miTradeDiary_Click(sender As System.Object, e As System.EventArgs) Handles miTradeDiary.Click
        If SubFormTradeDiaryList Then
            TradeDiaryList.Activate()
        Else
            TradeDiaryList.MdiParent = Me
            TradeDiaryList.Show()
        End If
    End Sub

    Private Sub miCostomerLedger_Click(sender As System.Object, e As System.EventArgs) Handles miCostomerLedger.Click
        If SubFormCustomerLedgerListList Then
            CustomerLedgerList.Activate()
        Else
            CustomerLedgerList.MdiParent = Me
            CustomerLedgerList.Show()
        End If
    End Sub

    Private Sub miOperationHistClient_Click(sender As Object, e As EventArgs) Handles miOperationHistClient.Click
        If SubFormOperationHistClientList Then
            OperationHistClientList.Activate()
        Else
            OperationHistClientList.MdiParent = Me
            OperationHistClientList.Show()
        End If
    End Sub

    Private Sub miFileDownload_Click(sender As Object, e As EventArgs) Handles miFileDownload.Click
        If SubFormFileDownloadList Then
            FileDownloadList.Activate()
        Else
            FileDownloadList.MdiParent = Me
            FileDownloadList.Show()
        End If
    End Sub

End Class
