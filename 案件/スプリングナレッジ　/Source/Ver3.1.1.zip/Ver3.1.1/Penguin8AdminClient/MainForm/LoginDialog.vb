''' <summary>
''' ���O�C����ʃN���X
''' </summary>
''' <remarks></remarks>
Public Class LoginDialog
    Public UserSettingInit As Boolean = False

    Private WithEvents service As New SessionService

    Private CursorOrg As Cursor

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SSLUtil.Init()
        Dim EnvTitle As String = clsUtil.GetEnvTitle()
        If EnvTitle <> "" Then
            Me.Text = Me.Text & "(" & EnvTitle & ")"
        End If
        Me.Text = String.Format("{0} - V{1}", Me.Text, clsUtil.GetVersionString())
        setRequestMode(False)
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim UserID As String = Me.txtUserID.Text
        If (UserID Is Nothing) OrElse (UserID.Length.Equals(0)) Then
            MessageBox.Show(Me, "���[�U�[ID�������͂ł��B" & vbCrLf & "���͒l���m�F���ĉ������B", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Dim Pass As String = Me.txtPassword.Text
        If (Pass Is Nothing) OrElse (Pass.Length.Equals(0)) Then
            MessageBox.Show(Me, "�p�X���[�h�������͂ł��B" & vbCrLf & "���͒l���m�F���ĉ������B", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Dim success As Boolean = False
        CursorOrg = Cursor.Current
        Try
            setRequestMode(True)
            Cursor.Current = Cursors.WaitCursor
            Me.Update()

            UserSettingInit = Me.chkUserSettingInit.Checked
            service.Login(UserID, Pass)
            success = True
        Finally
            If Not success Then
                setRequestMode(False)
                Cursor.Current = CursorOrg
            End If
        End Try

    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        service.CancelLogin()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub service_LoginCancel() Handles service.LoginCancel
        Cursor.Current = CursorOrg
        MessageBox.Show(Me, "�L�����Z�����܂����B", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setRequestMode(False)
    End Sub

    Private Sub service_LoginError(ErrorMessage As String) Handles service.LoginError
        Cursor.Current = CursorOrg
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setRequestMode(False)
    End Sub

    Private Sub service_LoginSuccess() Handles service.LoginSuccess
        Cursor.Current = CursorOrg
        service = Nothing
        SplashScreen.Show()
        SplashScreen.UserSettingInit = UserSettingInit
        Me.Close()
        Me.Update()
    End Sub

    Private Sub setRequestMode(mode As Boolean)
        txtUserID.Enabled = Not mode
        txtPassword.Enabled = Not mode
        btnLogin.Enabled = Not mode
        btnClose.Enabled = Not mode
        chkUserSettingInit.Enabled = Not mode
        btnCancel.Visible = mode
    End Sub

End Class
