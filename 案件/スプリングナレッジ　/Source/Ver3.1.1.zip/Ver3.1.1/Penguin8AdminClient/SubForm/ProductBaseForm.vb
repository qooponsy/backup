﻿Public Class ProductBaseForm
    Public Property Code As String

    Private WithEvents service As New ProductBaseService

    Private Const MAX_PRICE As Integer = 1000

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private CalcExercPriceList As CalcExercPriceListProductBase = Nothing

    Private Sub ProductBaseForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        setTitle()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbOpType.DisplayMember = "OpName"
        cbOpType.ValueMember = "OpType"
        cbOpType.DataSource = OptionInfoService.GetList()

        cbExercPriceUnitType.DisplayMember = "Name"
        cbExercPriceUnitType.ValueMember = "Code"
        cbExercPriceUnitType.DataSource = ExercPriceUnitTypeManager.GetList(True, False)
        cbExercPriceUnitType.SelectedValue = "0"

        MainWindow.SubFormProductBaseForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub ProductBaseForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormProductBaseForm = False
        If CalcExercPriceList IsNot Nothing Then
            If CalcExercPriceList.SourceForm IsNot Nothing Then
                CalcExercPriceList.Close()
            End If
            CalcExercPriceList = Nothing
        End If
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "銘柄設定登録"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "銘柄設定編集"
            Else
                Me.Text = "銘柄設定参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbComCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbOpType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        pnlOpTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        nudOpTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        pnlCreateTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        nudCreateTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpStartTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpEndTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbPayoutRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceTimeSpan.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceUnit.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceSettings.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBulkSetUnit.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        nudBulkSetCount.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnBulkSet.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExceptExercPrice.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnExercPricePreview.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbVolRatio1Call.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskBidSpreadMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskPriceMaxCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskPriceMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBidPriceMaxCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBidPriceMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        cbEnabled.SelectedValue = ""
        cbComCode.SelectedValue = ""
        cbOpType.SelectedValue = "02"
        rbOpTermHour.Checked = True
        nudOpTerm.Value = 0
        rbCreateTermHour.Checked = True
        nudCreateTerm.Value = 0
        dtpStartTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        tbPayoutRate.Text = ""
        tbExercPriceTimeSpan.Text = ""
        cbExercPriceUnitType.SelectedValue = "0"
        tbExercPriceUnit.Text = ""
        tbExercPriceSettings.Text = ""
        tbExceptExercPrice.Text = ""
        tbVolRatio1Call.Text = ""
        tbAskBidSpreadMinCall.Text = ""
        tbAskPriceMaxCall.Text = ""
        tbAskPriceMinCall.Text = ""
        tbBidPriceMaxCall.Text = "999"  '999固定
        tbBidPriceMinCall.Text = "1"    '1固定
        tbBulkSetUnit.Text = ""

    End Sub

    Private Sub initEdit()
        cbEnabled.SelectedValue = ""
        cbComCode.SelectedValue = ""
        cbOpType.SelectedValue = ""
        dtpStartTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        tbBulkSetUnit.Text = ""
        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of ProductBaseData)) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "銘柄設定の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).ProductBaseCode <> Code Then
            MessageBox.Show(Me, "銘柄設定の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As ProductBaseData)
        cbEnabled.SelectedValue = data.ProductBaseEnabled
        cbComCode.SelectedValue = data.ComCode
        cbOpType.SelectedValue = data.OpType
        If data.OptionTime Mod 60 = 0 Then
            rbOpTermHour.Checked = True
            nudOpTerm.Value = data.OptionTime / 60
        Else
            rbOpTermMinutes.Checked = True
            nudOpTerm.Value = data.OptionTime
        End If
        If data.CreateTime Mod 60 = 0 Then
            rbCreateTermHour.Checked = True
            nudCreateTerm.Value = data.CreateTime / 60
        Else
            rbCreateTermMinutes.Checked = True
            nudCreateTerm.Value = data.CreateTime
        End If
        dtpStartTime.Value = New Date(2012, 1, 1, data.StartTime.Hours, data.StartTime.Minutes, 0)
        dtpEndTime.Value = New Date(2012, 1, 1, data.ExercTime.Hours, data.ExercTime.Minutes, 0)
        tbPayoutRate.Text = If(data.PayoutRateEnabled, data.PayoutRate.ToString("######0.########"), "")
        tbExercPriceTimeSpan.Text = If(data.ExercPriceTimespanEnabled, data.ExercPriceTimespan, "")
        cbExercPriceUnitType.SelectedValue = If(data.ExercPriceUnitTypeEnabled, data.ExercPriceUnitType, "")
        tbExercPriceUnit.Text = If(data.ExercPriceUnitEnabled, data.ExercPriceUnit.ToString("######0.########"), "")
        tbExercPriceSettings.Text = If(data.ExercPriceSettingsEnabled, data.ExercPriceSettings, "")
        tbExceptExercPrice.Text = If(data.ExceptExercPriceEnabled, data.ExceptExercPrice, "")
        tbVolRatio1Call.Text = If(data.VolatilityRatio1CallEnabled, data.VolatilityRatio1Call.ToString("######0.########"), "")
        tbAskBidSpreadMinCall.Text = If(data.AskBidSpreadMinCallEnabled, (data.AskBidSpreadMinCall).ToString("######0.########"), "")
        tbAskPriceMaxCall.Text = If(data.AskPriceMaxCallEnabled, data.AskPriceMaxCall.ToString("######0.########"), "")
        tbAskPriceMinCall.Text = If(data.AskPriceMinCallEnabled, data.AskPriceMinCall.ToString("######0.########"), "")
        tbBidPriceMaxCall.Text = If(data.BidPriceMaxCallEnabled, data.BidPriceMaxCall.ToString("######0.########"), "")
        tbBidPriceMinCall.Text = If(data.BidPriceMinCallEnabled, data.BidPriceMinCall.ToString("######0.########"), "")
    End Sub

    Public Function getDataFromControl() As ProductBaseData
        Dim ret As New ProductBaseData

        ret.ProductBaseCode = Code
        ret.ProductBaseEnabled = cbEnabled.SelectedValue
        ret.ComCode = cbComCode.SelectedValue
        ret.OpType = cbOpType.SelectedValue
        ret.OptionTime = IIf(rbOpTermHour.Checked, nudOpTerm.Value * 60, nudOpTerm.Value)
        ret.CreateTime = IIf(rbCreateTermHour.Checked, nudCreateTerm.Value * 60, nudCreateTerm.Value)
        ret.StartTime = New TimeSpan(dtpStartTime.Value.Hour, dtpStartTime.Value.Minute, 0)
        ret.ExercTime = New TimeSpan(dtpEndTime.Value.Hour, dtpEndTime.Value.Minute, 0)
        If tbPayoutRate.Text.Length = 0 Then
            ret.PayoutRateEnabled = False
        Else
            ret.PayoutRateEnabled = True
            ret.PayoutRate = Decimal.Parse(tbPayoutRate.Text)
        End If
        If tbExercPriceTimeSpan.Text.Length = 0 Then
            ret.ExercPriceTimespanEnabled = False
        Else
            ret.ExercPriceTimespanEnabled = True
            ret.ExercPriceTimespan = Integer.Parse(tbExercPriceTimeSpan.Text)
        End If
        If cbExercPriceUnitType.SelectedValue = "" Then
            ret.ExercPriceUnitTypeEnabled = False
        Else
            ret.ExercPriceUnitTypeEnabled = True
            ret.ExercPriceUnitType = cbExercPriceUnitType.SelectedValue
        End If
        If tbExercPriceUnit.Text.Length = 0 Then
            ret.ExercPriceUnitEnabled = False
        Else
            ret.ExercPriceUnitEnabled = True
            ret.ExercPriceUnit = Decimal.Parse(tbExercPriceUnit.Text)
        End If
        If tbExercPriceSettings.Text.Length = 0 Then
            ret.ExercPriceSettingsEnabled = False
        Else
            ret.ExercPriceSettingsEnabled = True
            ret.ExercPriceSettings = tbExercPriceSettings.Text
        End If
        If tbExceptExercPrice.Text.Length = 0 Then
            ret.ExceptExercPriceEnabled = False
        Else
            ret.ExceptExercPriceEnabled = True
            ret.ExceptExercPrice = tbExceptExercPrice.Text
        End If
        If tbVolRatio1Call.Text.Length = 0 Then
            ret.VolatilityRatio1CallEnabled = False
        Else
            ret.VolatilityRatio1CallEnabled = True
            ret.VolatilityRatio1Call = Decimal.Parse(tbVolRatio1Call.Text)
        End If
        If tbAskBidSpreadMinCall.Text.Length = 0 Then
            ret.AskBidSpreadMinCallEnabled = False
        Else
            ret.AskBidSpreadMinCallEnabled = True
            ret.AskBidSpreadMinCall = Decimal.Parse(tbAskBidSpreadMinCall.Text)
        End If
        If tbAskPriceMaxCall.Text.Length = 0 Then
            ret.AskPriceMaxCallEnabled = False
        Else
            ret.AskPriceMaxCallEnabled = True
            ret.AskPriceMaxCall = Decimal.Parse(tbAskPriceMaxCall.Text)
        End If
        If tbAskPriceMinCall.Text.Length = 0 Then
            ret.AskPriceMinCallEnabled = False
        Else
            ret.AskPriceMinCallEnabled = True
            ret.AskPriceMinCall = Decimal.Parse(tbAskPriceMinCall.Text)
        End If
        If tbBidPriceMaxCall.Text.Length = 0 Then
            ret.BidPriceMaxCallEnabled = False
        Else
            ret.BidPriceMaxCallEnabled = True
            ret.BidPriceMaxCall = Decimal.Parse(tbBidPriceMaxCall.Text)
        End If
        If tbBidPriceMinCall.Text.Length = 0 Then
            ret.BidPriceMinCallEnabled = False
        Else
            ret.BidPriceMinCallEnabled = True
            ret.BidPriceMinCall = Decimal.Parse(tbBidPriceMinCall.Text)
        End If

        Return ret
    End Function


    Private Function checkInput() As Boolean
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not rbOpTermHour.Checked And Not rbOpTermMinutes.Checked Then
            MessageBox.Show(Me, "オプション期間を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If rbOpTermHour.Checked = True Then
            '時間が選択されている場合
            If nudOpTerm.Value < 2 Or nudOpTerm.Value > 12 Then
                MessageBox.Show(Me, "オプション期間には2以上かつ12以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        Else
            '分が選択されている場合
            If nudOpTerm.Value < 120 Or nudOpTerm.Value > 720 Then
                MessageBox.Show(Me, "オプション期間には120以上かつ720以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        If Not rbCreateTermHour.Checked And Not rbCreateTermMinutes.Checked Then
            MessageBox.Show(Me, "生成間隔を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If rbCreateTermHour.Checked = True Then
            '時間が選択されている場合
            If nudCreateTerm.Value < 2 Or nudCreateTerm.Value > 12 Then
                MessageBox.Show(Me, "生成間隔には2以上かつ12以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        Else
            '分が選択されている場合
            If nudCreateTerm.Value < 120 Or nudCreateTerm.Value > 720 Then
                MessageBox.Show(Me, "生成間隔には120以上かつ720以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        'hh:mmフォーマットチェック
        If Not CheckUtil.IsTimeFormatCheck(dtpStartTime.Text) Then
            MessageBox.Show(Me, "生成開始時間にはhh:mm形式を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        'hh:mmフォーマットチェック
        If Not CheckUtil.IsTimeFormatCheck(dtpEndTime.Text) Then
            MessageBox.Show(Me, "最終行使期日にはhh:mm形式を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbPayoutRate.Text.Length > 0 Then
            If Not CheckUtil.RegExRate2.IsMatch(tbPayoutRate.Text) Then
                MessageBox.Show(Me, "ペイアウト率には0.01以上の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            Dim payoutRate As Decimal
            If Not Decimal.TryParse(tbPayoutRate.Text, payoutRate) Then
                MessageBox.Show(Me, "ペイアウト率には0.01以上の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If payoutRate < 0.01 Or payoutRate >= 1 Then
                MessageBox.Show(Me, "ペイアウト率には0.01以上の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '有効フラグ
        If FormModeStatus = FormMode.REGIST Then
            If cbEnabled.SelectedValue = "" Then
                MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '行使価格決定時間
        If tbExercPriceTimeSpan IsNot Nothing AndAlso tbExercPriceTimeSpan.Text.Length > 0 Then
            If Not CheckUtil.RegExInt.IsMatch(tbExercPriceTimeSpan.Text) Then
                MessageBox.Show(Me, "行使価格決定時間(秒)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbExercPriceTimeSpan.Text < 10 Or tbExercPriceTimeSpan.Text > 600 Then
                MessageBox.Show(Me, "行使価格決定時間(秒)には10以上かつ600以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        If tbExercPriceUnit IsNot Nothing AndAlso tbExercPriceUnit.Text.Length > 0 Then
            If Not CheckUtil.RegExRate8.IsMatch(tbExercPriceUnit.Text) Then
                MessageBox.Show(Me, "行使価格刻み幅には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            Dim ExercPriceUnit As Decimal
            If Not Decimal.TryParse(tbExercPriceUnit.Text, ExercPriceUnit) Then
                MessageBox.Show(Me, "行使価格刻み幅には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If ExercPriceUnit <= 0 Then
                MessageBox.Show(Me, "行使価格刻み幅には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        'ボラティリティレシオ１(Call)
        If tbVolRatio1Call IsNot Nothing AndAlso tbVolRatio1Call.Text.Length > 0 Then
            If Not CheckUtil.RegExSignRate.IsMatch(tbVolRatio1Call.Text) Then
                MessageBox.Show(Me, "ボラティリティレシオ１には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbVolRatio1Call.Text < 0.1 Or tbVolRatio1Call.Text > 10 Then
                MessageBox.Show(Me, "ボラティリティレシオ１には0.1以上かつ10以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Call)
        If tbAskBidSpreadMinCall IsNot Nothing AndAlso tbAskBidSpreadMinCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbAskBidSpreadMinCall.Text) Then
                MessageBox.Show(Me, "購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbAskBidSpreadMinCall.Text < 10 Or tbAskBidSpreadMinCall.Text > 500 Then
                MessageBox.Show(Me, "購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸには10以上かつ500以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最高購入価格(Call)
        If tbAskPriceMaxCall IsNot Nothing AndAlso tbAskPriceMaxCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbAskPriceMaxCall.Text) Then
                MessageBox.Show(Me, "最高購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbAskPriceMaxCall.Text < 999 Or tbAskPriceMaxCall.Text > 1000 Then
                MessageBox.Show(Me, "最高購入価格には999以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最低購入価格(Call)
        If tbAskPriceMinCall IsNot Nothing AndAlso tbAskPriceMinCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbAskPriceMinCall.Text) Then
                MessageBox.Show(Me, "最低購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbAskPriceMinCall.Text < 10 Or tbAskPriceMinCall.Text > 200 Then
                MessageBox.Show(Me, "最低購入価格には10以上かつ200以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最高清算価格
        ' 固定値のためチェックなし

        '最低清算価格
        ' 固定値のためチェックなし

        Return True
    End Function

    Private Sub registData()
        Dim data As ProductBaseData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As ProductBaseData = getDataFromControl()

        service.Update(data)
    End Sub

    Private Sub btnBulkSet_Click(sender As System.Object, e As System.EventArgs) Handles btnBulkSet.Click
        Dim Unit As Decimal
        If Not Decimal.TryParse(tbBulkSetUnit.Text, Unit) Then
            Exit Sub
        End If
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(cbComCode.SelectedValue).DecimalPlaces
        tbExercPriceSettings.Text = LadderOption.buildExercPriceSettings(Unit, nudBulkSetCount.Value, DecimalPlaces)
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(cbComCode.SelectedValue).DecimalPlaces
        Dim Unit As Decimal = 5 / clsUtil.Power(DecimalPlaces)
        tbBulkSetUnit.Text = Unit.ToString(clsUtil.GetRateDPFormat(DecimalPlaces))
    End Sub

    Private Sub btnExercPricePreview_Click(sender As System.Object, e As System.EventArgs) Handles btnExercPricePreview.Click
        If Not checkInput() Then
            Return
        End If
        If cbComCode.SelectedValue IsNot Nothing AndAlso cbComCode.SelectedValue <> "" Then
            If CalcExercPriceList Is Nothing OrElse CalcExercPriceList.SourceForm Is Nothing Then
                CalcExercPriceList = New CalcExercPriceListProductBase With {.SourceForm = Me, .ComCode = cbComCode.SelectedValue}
                CalcExercPriceList.MdiParent = Me.MdiParent
                CalcExercPriceList.Show()
            Else
                CalcExercPriceList.request()
            End If
        End If
    End Sub

    ' 最大最小清算価格の値が固定になったため未使用
    Private Sub tbBidPriceMaxCall_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMaxCall.TextChanged

        If tbBidPriceMaxCall.Text <> "" Then
            Dim bidPriceMin As Integer = MAX_PRICE - tbBidPriceMaxCall.Text
            tbBidPriceMinCall.Text = bidPriceMin
        End If

    End Sub

End Class