﻿Imports Penguin8AdminClient

Public Class OperationHistClientList

    Private WithEvents service As New OperationHistClientService

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private Sub OperationHistClientList_Load(sender As Object, e As EventArgs) Handles Me.Load

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbDataType.DisplayMember = "DataTypeName"
        cbDataType.ValueMember = "DataTypeCode"
        cbDataType.DataSource = OperationCustDataManager.GetDataTypeListWithAll()

        cbChannelName.DisplayMember = "ChannelName"
        cbChannelName.ValueMember = "ClientType"
        cbChannelName.DataSource = ClientVersionService.GetListWithAll()

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        dtpFromDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day, SysStaticsService.SysDateStartTime.Hours, SysStaticsService.SysDateStartTime.Minutes, SysStaticsService.SysDateStartTime.Seconds)
        dtpToDateTime.Value = DateTime.Now
        dtpToDateTime.Checked = False

        MainWindow.SubFormOperationHistClientList = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)

    End Sub

    Private Sub OperationHistClientList_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormOperationHistClientList = False
    End Sub

    Private Sub LoadSettings()
        [clsUtil].LoadFormSettings(Me,
           UserSettings.getInstance().DataSaved.OperationHistClientList_FormMaximized,
           UserSettings.getInstance().DataSaved.OperationHistClientList_FormSize,
           UserSettings.getInstance().DataSaved.OperationHistClientList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.OperationHistClientList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.OperationHistClientList_CmpCode
        cbDataType.SelectedValue = UserSettings.getInstance().DataSaved.OperationHistClientList_DataType
        cbChannelName.SelectedValue = UserSettings.getInstance().DataSaved.OperationHistClientList_ChannelName
        tbCustCode.Text = UserSettings.getInstance().DataSaved.OperationHistClientList_CustCode
        tbCode.Text = UserSettings.getInstance().DataSaved.OperationHistClientList_Code
        tbClientIP.Text = UserSettings.getInstance().DataSaved.OperationHistClientList_IPAddress
    End Sub

    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me,
            UserSettings.getInstance().DataSaved.OperationHistClientList_FormMaximized,
            UserSettings.getInstance().DataSaved.OperationHistClientList_FormSize,
            UserSettings.getInstance().DataSaved.OperationHistClientList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.OperationHistClientList_Columns)
        UserSettings.getInstance().DataSaved.OperationHistClientList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.OperationHistClientList_DataType = cbDataType.SelectedValue
        UserSettings.getInstance().DataSaved.OperationHistClientList_ChannelName = cbChannelName.SelectedValue
        UserSettings.getInstance().DataSaved.OperationHistClientList_CustCode = tbCustCode.Text
        UserSettings.getInstance().DataSaved.OperationHistClientList_Code = tbCode.Text
        UserSettings.getInstance().DataSaved.OperationHistClientList_IPAddress = tbClientIP.Text
    End Sub


    Private Sub initGrid()
        'gridの表示文字の改行
        grid.Columns(1).HeaderText = "システム" & vbCrLf & "営業日"

        'grid設定
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("LogTime", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("CmpCode", GetType(String))
        Table.Columns.Add("CmpName", GetType(String))
        Table.Columns.Add("CustCode", GetType(String))
        Table.Columns.Add("ClientType", GetType(String))
        Table.Columns.Add("ChannelName", GetType(String))
        Table.Columns.Add("ClientIP", GetType(String))
        Table.Columns.Add("DataType", GetType(String))
        Table.Columns.Add("DataTypeName", GetType(String))
        Table.Columns.Add("LogType", GetType(String))
        Table.Columns.Add("LogTypeName", GetType(String))
        Table.Columns.Add("Code", GetType(String))
        Table.Columns.Add("LogText", GetType(String))
        grid.DataSource = Table

    End Sub

    Private Sub setGrid(ByVal list As List(Of OperationHistClientData))

        For Each item As OperationHistClientData In list
            Dim row As DataRow = Table.NewRow()
            row("LogTime") = item.LogTime
            row("SysDate") = item.SysDate
            row("CmpCode") = item.CmpCode
            row("CmpName") = CompanyService.GetName(item.CmpCode)
            row("CustCode") = item.CustCode
            row("ClientType") = item.ClientType
            row("ChannelName") = ClientVersionService.getName(item.ClientType)
            row("ClientIP") = item.ClientIP
            row("DataType") = item.DataType
            row("DataTypeName") = OperationCustDataManager.GetDataTypeName(item.DataType)
            row("LogType") = item.LogType
            row("LogTypeName") = OperationCustDataManager.GetLogTypeName(item.LogType)
            row("Code") = item.Code
            row("LogText") = item.LogText
            Table.Rows.Add(row)
        Next

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.cancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearchAdd_Click(sender As Object, e As EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim DataType As String = Me.cbDataType.SelectedValue
        Dim ChannelName As String = Me.cbChannelName.SelectedValue
        Dim CustCode As String = Me.tbCustCode.Text
        Dim Code As String = Me.tbCode.Text
        Dim ClientIP As String = tbClientIP.Text
        Dim FormDatetime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")

        service.ReadList(CmpCode, DataType, ChannelName, CustCode, Code, ClientIP, FormDatetime, ToDateTime, "", Start)

        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of OperationHistClientData), ExistNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(ExistNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

    Private Sub btnCSV_Click(sender As Object, e As EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlcustomeroperation"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

End Class
