﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateFilterLogList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkAlertRateTimeDiffClear = New System.Windows.Forms.CheckBox()
        Me.chkAlertRateTimeDiff = New System.Windows.Forms.CheckBox()
        Me.chkAlertAnomalyRateClear = New System.Windows.Forms.CheckBox()
        Me.chkAlertAnomalyRate = New System.Windows.Forms.CheckBox()
        Me.chkAlertRateChanged = New System.Windows.Forms.CheckBox()
        Me.chkAlertRateFilterCounterClear = New System.Windows.Forms.CheckBox()
        Me.chkAlertRateFilter = New System.Windows.Forms.CheckBox()
        Me.chkAlertRateFilterSettings = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.cbLogType = New System.Windows.Forms.ComboBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbDataType = New System.Windows.Forms.ComboBox()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.LogTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogText = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.chkAlertRateTimeDiffClear)
        Me.Panel1.Controls.Add(Me.chkAlertRateTimeDiff)
        Me.Panel1.Controls.Add(Me.chkAlertAnomalyRateClear)
        Me.Panel1.Controls.Add(Me.chkAlertAnomalyRate)
        Me.Panel1.Controls.Add(Me.chkAlertRateChanged)
        Me.Panel1.Controls.Add(Me.chkAlertRateFilterCounterClear)
        Me.Panel1.Controls.Add(Me.chkAlertRateFilter)
        Me.Panel1.Controls.Add(Me.chkAlertRateFilterSettings)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.cbLogType)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Controls.Add(Me.cbDataType)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 58)
        Me.Panel1.TabIndex = 7
        '
        'chkAlertRateTimeDiffClear
        '
        Me.chkAlertRateTimeDiffClear.AutoSize = True
        Me.chkAlertRateTimeDiffClear.Location = New System.Drawing.Point(853, 21)
        Me.chkAlertRateTimeDiffClear.Name = "chkAlertRateTimeDiffClear"
        Me.chkAlertRateTimeDiffClear.Size = New System.Drawing.Size(123, 16)
        Me.chkAlertRateTimeDiffClear.TabIndex = 15
        Me.chkAlertRateTimeDiffClear.Text = "レート時間乖離復旧"
        Me.chkAlertRateTimeDiffClear.UseVisualStyleBackColor = True
        '
        'chkAlertRateTimeDiff
        '
        Me.chkAlertRateTimeDiff.AutoSize = True
        Me.chkAlertRateTimeDiff.Location = New System.Drawing.Point(853, 6)
        Me.chkAlertRateTimeDiff.Name = "chkAlertRateTimeDiff"
        Me.chkAlertRateTimeDiff.Size = New System.Drawing.Size(99, 16)
        Me.chkAlertRateTimeDiff.TabIndex = 14
        Me.chkAlertRateTimeDiff.Text = "レート時間乖離"
        Me.chkAlertRateTimeDiff.UseVisualStyleBackColor = True
        '
        'chkAlertAnomalyRateClear
        '
        Me.chkAlertAnomalyRateClear.AutoSize = True
        Me.chkAlertAnomalyRateClear.Location = New System.Drawing.Point(728, 37)
        Me.chkAlertAnomalyRateClear.Name = "chkAlertAnomalyRateClear"
        Me.chkAlertAnomalyRateClear.Size = New System.Drawing.Size(123, 16)
        Me.chkAlertAnomalyRateClear.TabIndex = 13
        Me.chkAlertAnomalyRateClear.Text = "異常レート状態解除"
        Me.chkAlertAnomalyRateClear.UseVisualStyleBackColor = True
        '
        'chkAlertAnomalyRate
        '
        Me.chkAlertAnomalyRate.AutoSize = True
        Me.chkAlertAnomalyRate.Location = New System.Drawing.Point(728, 21)
        Me.chkAlertAnomalyRate.Name = "chkAlertAnomalyRate"
        Me.chkAlertAnomalyRate.Size = New System.Drawing.Size(75, 16)
        Me.chkAlertAnomalyRate.TabIndex = 12
        Me.chkAlertAnomalyRate.Text = "異常レート"
        Me.chkAlertAnomalyRate.UseVisualStyleBackColor = True
        '
        'chkAlertRateChanged
        '
        Me.chkAlertRateChanged.AutoSize = True
        Me.chkAlertRateChanged.Location = New System.Drawing.Point(728, 6)
        Me.chkAlertRateChanged.Name = "chkAlertRateChanged"
        Me.chkAlertRateChanged.Size = New System.Drawing.Size(96, 16)
        Me.chkAlertRateChanged.TabIndex = 11
        Me.chkAlertRateChanged.Text = "相場水準変更"
        Me.chkAlertRateChanged.UseVisualStyleBackColor = True
        '
        'chkAlertRateFilterCounterClear
        '
        Me.chkAlertRateFilterCounterClear.AutoSize = True
        Me.chkAlertRateFilterCounterClear.Location = New System.Drawing.Point(568, 37)
        Me.chkAlertRateFilterCounterClear.Name = "chkAlertRateFilterCounterClear"
        Me.chkAlertRateFilterCounterClear.Size = New System.Drawing.Size(153, 16)
        Me.chkAlertRateFilterCounterClear.TabIndex = 10
        Me.chkAlertRateFilterCounterClear.Text = "レートフィルターカウンタクリア"
        Me.chkAlertRateFilterCounterClear.UseVisualStyleBackColor = True
        '
        'chkAlertRateFilter
        '
        Me.chkAlertRateFilter.AutoSize = True
        Me.chkAlertRateFilter.Location = New System.Drawing.Point(568, 21)
        Me.chkAlertRateFilter.Name = "chkAlertRateFilter"
        Me.chkAlertRateFilter.Size = New System.Drawing.Size(94, 16)
        Me.chkAlertRateFilter.TabIndex = 9
        Me.chkAlertRateFilter.Text = "レートフィルター"
        Me.chkAlertRateFilter.UseVisualStyleBackColor = True
        '
        'chkAlertRateFilterSettings
        '
        Me.chkAlertRateFilterSettings.AutoSize = True
        Me.chkAlertRateFilterSettings.Location = New System.Drawing.Point(568, 6)
        Me.chkAlertRateFilterSettings.Name = "chkAlertRateFilterSettings"
        Me.chkAlertRateFilterSettings.Size = New System.Drawing.Size(142, 16)
        Me.chkAlertRateFilterSettings.TabIndex = 8
        Me.chkAlertRateFilterSettings.Text = "レートフィルター設定変更"
        Me.chkAlertRateFilterSettings.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(521, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 12)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "アラート"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "～"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(419, 22)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 6
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 32)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 5
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 32)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 3
        '
        'cbLogType
        '
        Me.cbLogType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbLogType.FormattingEnabled = True
        Me.cbLogType.Location = New System.Drawing.Point(266, 6)
        Me.cbLogType.Name = "cbLogType"
        Me.cbLogType.Size = New System.Drawing.Size(140, 20)
        Me.cbLogType.TabIndex = 2
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(139, 6)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 1
        '
        'cbDataType
        '
        Me.cbDataType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDataType.FormattingEnabled = True
        Me.cbDataType.Location = New System.Drawing.Point(12, 6)
        Me.cbDataType.Name = "cbDataType"
        Me.cbDataType.Size = New System.Drawing.Size(121, 20)
        Me.cbDataType.TabIndex = 0
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 460)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(984, 32)
        Me.pnlSearchAdd.TabIndex = 10
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 9
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LogTime, Me.ComCode, Me.ComName, Me.LogType, Me.LogText})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 58)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(984, 402)
        Me.grid.TabIndex = 8
        '
        'LogTime
        '
        Me.LogTime.DataPropertyName = "LogTime"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.LogTime.DefaultCellStyle = DataGridViewCellStyle2
        Me.LogTime.HeaderText = "日時"
        Me.LogTime.Name = "LogTime"
        Me.LogTime.ReadOnly = True
        Me.LogTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LogTime.Width = 120
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.ComCode.HeaderText = "通貨ペア(code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle4
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComName.Width = 75
        '
        'LogType
        '
        Me.LogType.DataPropertyName = "LogType"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.LogType.DefaultCellStyle = DataGridViewCellStyle5
        Me.LogType.HeaderText = "ログ種別"
        Me.LogType.Name = "LogType"
        Me.LogType.ReadOnly = True
        Me.LogType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LogType.Width = 150
        '
        'LogText
        '
        Me.LogText.DataPropertyName = "LogText"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.LogText.DefaultCellStyle = DataGridViewCellStyle6
        Me.LogText.HeaderText = "ログ"
        Me.LogText.Name = "LogText"
        Me.LogText.ReadOnly = True
        Me.LogText.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LogText.Width = 1000
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(374, 215)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(213, 63)
        Me.lblNoData.TabIndex = 17
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RateFilterLogList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 492)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "RateFilterLogList"
        Me.Text = "レートログ"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cbLogType As System.Windows.Forms.ComboBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbDataType As System.Windows.Forms.ComboBox
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents LogTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LogType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LogText As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkAlertRateFilter As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlertRateFilterSettings As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents chkAlertRateFilterCounterClear As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlertAnomalyRateClear As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlertAnomalyRate As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlertRateChanged As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlertRateTimeDiffClear As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlertRateTimeDiff As System.Windows.Forms.CheckBox
    Friend WithEvents lblNoData As System.Windows.Forms.Label
End Class
