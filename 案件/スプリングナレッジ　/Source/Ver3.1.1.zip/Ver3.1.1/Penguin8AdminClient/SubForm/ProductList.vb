﻿Public Class ProductList

    Private WithEvents service As New ProductService
    Private WithEvents serviceDDD As DDDService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable

    Private Start As Integer = 1

    Private Sub ProductList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Premium.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PAndL.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        btnRegist.Enabled = editable
        miEdit.Text = IIf(editable, "編集", "参照")

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        '通貨ペアドロップダウンリストの作成
        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Me.cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        Me.cbExercState.DisplayMember = "Name"
        Me.cbExercState.ValueMember = "Code"
        Me.cbExercState.DataSource = ExercStatusManager.GetList(False, True)

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        dtpFromDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day, SysStaticsService.SysDateStartTime.Hours, SysStaticsService.SysDateStartTime.Minutes, SysStaticsService.SysDateStartTime.Seconds)
        dtpToDateTime.Value = DateTime.Now
        dtpToDateTime.Checked = False

        MainWindow.SubFormProduct = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        setTotalPremium(0)
        setTotalPAndL(0)
        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)

        serviceDDD = New DDDService
    End Sub

    Private Sub ProductList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceDDD = Nothing

        SaveSettings()
        MainWindow.SubFormProduct = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_CmpCode
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_ComCode
        cbExercState.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_ExercStatus
        chkEnabled.Checked = UserSettings.getInstance().DataSaved.ProductList_Enabled
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductList_Columns)
        UserSettings.getInstance().DataSaved.ProductList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_ExercStatus = cbExercState.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_Enabled = chkEnabled.Checked
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("ResidualTime", GetType(String))
        Table.Columns.Add("PayoutRate", GetType(Decimal))
        Table.Columns.Add("Rate", GetType(Decimal))
        Table.Columns.Add("RateArrowCount", GetType(Integer))
        Table.Columns.Add("ProductCode", GetType(String))
        Table.Columns.Add("OpType", GetType(String))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("StartTime", GetType(DateTime))
        Table.Columns.Add("TradeLimitTime", GetType(DateTime))
        Table.Columns.Add("ProductEnabled", GetType(String))
        Table.Columns.Add("ExercStatusCode", GetType(String))
        Table.Columns.Add("ExercStatus", GetType(String))
        Table.Columns.Add("ExercPriceStatusCode", GetType(String))
        Table.Columns.Add("ExercPriceStatus", GetType(String))
        Table.Columns.Add("ProductBaseCode", GetType(String))
        Table.Columns.Add("ExercRateSeq", GetType(String))
        Table.Columns.Add("ExercRate", GetType(Decimal))
        Table.Columns.Add("Premium", GetType(Decimal))
        Table.Columns.Add("PAndL", GetType(Decimal))
        '▼add 2014/05 fukushima 時価検証シート用列追加
        Table.Columns.Add("VolatilityRatio1Call", GetType(Decimal))
        Table.Columns.Add("AskFeePriceCall", GetType(Decimal))
        Table.Columns.Add("AskBidSpreadMinCall", GetType(Decimal))
        Table.Columns.Add("BidFeeRateCall", GetType(Decimal))
        Table.Columns.Add("AskPriceMaxCall", GetType(Decimal))
        Table.Columns.Add("AskPriceMinCall", GetType(Decimal))
        Table.Columns.Add("BidPriceMaxCall", GetType(Decimal))
        Table.Columns.Add("BidPriceMinCall", GetType(Decimal))
        Table.Columns.Add("VolatilityRatio1Put", GetType(Decimal))
        Table.Columns.Add("AskFeePricePut", GetType(Decimal))
        Table.Columns.Add("AskBidSpreadMinPut", GetType(Decimal))
        Table.Columns.Add("BidFeeRatePut", GetType(Decimal))
        Table.Columns.Add("AskPriceMaxPut", GetType(Decimal))
        Table.Columns.Add("AskPriceMinPut", GetType(Decimal))
        Table.Columns.Add("BidPriceMaxPut", GetType(Decimal))
        Table.Columns.Add("BidPriceMinPut", GetType(Decimal))
        '▲add 2014/05 fukushima 時価検証シート用列追加
        grid.DataSource = Table
    End Sub

    Private Sub setTotalPAndL(TotalPAndL As Decimal)
        lblTotalPAndL.Text = TotalPAndL.ToString(clsUtil.GetMoneyFormatDisp())
        If TotalPAndL >= 0 Then
            lblTotalPAndL.ForeColor = Color.Black
        Else
            lblTotalPAndL.ForeColor = Color.Red
        End If
    End Sub

    Private Sub setTotalPremium(TotalPremium As Decimal)
        lblTotalPremium.Text = TotalPremium.ToString(clsUtil.GetMoneyFormatDisp())
        If TotalPremium >= 0 Then
            lblTotalPremium.ForeColor = Color.Black
        Else
            lblTotalPremium.ForeColor = Color.Red
        End If
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of ProductData))
        For Each item As ProductData In list
            Dim row As DataRow = Table.NewRow()
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("ExercTime") = item.ExercTime
            row("ResidualTime") = DateTimeUtil.TimeSpanText(item.ExercTime, DDDService.ServerTime)
            row("PayoutRate") = If(item.PayoutRateEnabled, item.PayoutRate, Nothing)
            If item.ExercStatus = "0" And item.ProductEnabled = "1" Then
                row("Rate") = DDDService.GetLastRate(item.ComCode).Rate
                row("RateArrowCount") = DDDService.GetLastRate(item.ComCode).RateArrowCount
            End If
            row("ProductCode") = item.ProductCode
            row("OpType") = item.OpTypeName
            row("SysDate") = item.SysDate
            row("StartTime") = item.StartTime
            row("TradeLimitTime") = item.TradeLimitTime
            row("ProductEnabled") = item.ProductEnabledName
            row("ExercStatusCode") = item.ExercStatus
            row("ExercStatus") = item.ExercStatusName
            row("ExercPriceStatusCode") = item.ExercPriceStatus
            row("ExercPriceStatus") = item.ExercPriceStatsuName
            row("ProductBaseCode") = item.ProductBaseCode
            row("ExercRateSeq") = item.ExercRateSeq
            row("ExercRate") = IIf(item.ExercRateEnabled, item.ExercRate, DBNull.Value)
            row("Premium") = item.Premium
            row("PAndL") = item.PAndL
            '▼add 2014/05 fukushima 時価検証シート用列追加
            row("VolatilityRatio1Call") = item.VolatilityRatio1Call
            row("AskFeePriceCall") = item.AskFeePriceCall
            row("AskBidSpreadMinCall") = item.AskBidSpreadMinCall
            row("BidFeeRateCall") = item.BidFeeRateCall * 100
            row("AskPriceMaxCall") = item.AskPriceMaxCall
            row("AskPriceMinCall") = item.AskPriceMinCall
            row("BidPriceMaxCall") = item.BidPriceMaxCall
            row("BidPriceMinCall") = item.BidPriceMinCall
            row("VolatilityRatio1Put") = item.VolatilityRatio1Put
            row("AskFeePricePut") = item.AskFeePricePut
            row("AskBidSpreadMinPut") = item.AskBidSpreadMinPut
            row("BidFeeRatePut") = item.BidFeeRatePut * 100
            row("AskPriceMaxPut") = item.AskPriceMaxPut
            row("AskPriceMinPut") = item.AskPriceMinPut
            row("BidPriceMaxPut") = item.BidPriceMaxPut
            row("BidPriceMinPut") = item.BidPriceMinPut
            '▲add 2014/05 fukushima 時価検証シート用列追加
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    '''  [新規]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("ProductCode").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductCode").Value
        edit(code)
    End Sub

    Private Sub miProductSubList_Click() Handles miProductSubList.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductCode").Value
        Dim comcode As String = grid.SelectedRows(0).Cells("ComCode").Value
        Dim optiontype As String = grid.SelectedRows(0).Cells("OpType").Value
        Dim exerctime As String = grid.SelectedRows(0).Cells("ExercTime").Value
        listView(code, comcode, optiontype, ExercTime)
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim Exerc As String = If(Me.cbExercState.SelectedValue = "ALL", "", Me.cbExercState.SelectedValue)
        Dim EnabledFlg As String = IIf(Me.chkEnabled.Checked, "1", "")
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim SortKey As String = ""
        If grid.SortedColumn IsNot Nothing Then
            SortKey = convSortKeyName(grid.SortedColumn.Name)
            If SortKey <> "" Then
                If grid.SortedColumn.Name = "ResidualTime" Then
                    If grid.SortOrder <> SortOrder.Descending Then
                        SortKey &= " DESC"
                    End If
                Else
                    If grid.SortOrder = SortOrder.Descending Then
                        SortKey &= " DESC"
                    End If
                End If
            End If
        End If

        service.ReadList(CmpCode, ComCode, Exerc, EnabledFlg, FromDateTime, ToDateTime, "", Start, SortKey)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of ProductData), existNextFlag As Boolean, TotalPAndL As Decimal, TotalPremium As Decimal) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setTotalPremium(TotalPremium)
        setTotalPAndL(TotalPAndL)
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormProductForm Then
            ProductForm.Close()
        End If
        ProductForm.MdiParent = MainWindow
        ProductForm.Code = ""
        ProductForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormProductForm Then
            ProductForm.Close()
        End If
        ProductForm.MdiParent = MainWindow
        ProductForm.Code = code
        ProductForm.Show()
    End Sub

    Private Sub listView(code As String, comcode As String, optiontype As String, exerctime As String)
        If MainWindow.SubFormProductList Then
            ProductSubList.Close()
        End If
        ProductSubList.MdiParent = MainWindow
        ProductSubList.Code = code
        ProductSubList.ComCode = comcode
        ProductSubList.OptionType = optiontype
        ProductSubList.ExercTime = exerctime
        ProductSubList.Show()
    End Sub

    Private Sub serviceDDD_NewDDD() Handles serviceDDD.NewDDD
        For Each row As DataRow In Table.Rows
            Dim ExercStatusCode As String = row("ExercStatusCode")
            Dim ProductEnabled As String = row("ProductEnabled")
            If ExercStatusCode = "0" And ProductEnabled = "有効" Then
                row("ResidualTime") = DateTimeUtil.TimeSpanText(row("ExercTime"), DDDService.ServerTime)
                row("Rate") = DDDService.GetLastRate(row("ComCode")).Rate
                row("RateArrowCount") = DDDService.GetLastRate(row("ComCode")).RateArrowCount
            End If
        Next
    End Sub

    Private Function convSortKeyName(columnName As String) As String
        Dim ret As String = ""
        Select Case columnName
            Case "ComName"
                ret = "COMCODE"
            Case "ExercTime"
                ret = "EXERCTIME"
            Case "ResidualTime"
                ret = "EXERCTIME"
            Case "PayoutRate"
                ret = "PAYOUTRATE"
            Case "ProductCode"
                ret = "PRODUCTCODE"
            Case "OpType"
                ret = "OPTYPE"
            Case "StartTime"
                ret = "STARTTIME"
            Case "TradeLimitTime"
                ret = "TRADELIMITTIME"
            Case "ProductEnabled"
                ret = "ENABLED"
            Case "ExercStatus"
                ret = "EXERCSTATUS"
            Case "ProductBaseCode"
                ret = "PRODUCTBASECODE"
            Case "ExercRateSeq"
                ret = "EXERCRATESEQ"
            Case "ExercRate"
                ret = "EXERCRATE"
        End Select
        Return ret
    End Function

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            If grid.Columns(e.ColumnIndex).DataPropertyName = "Rate" Then
                Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComCode").Value
                Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End If
        End If
    End Sub

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grid.CellPainting
        If e.RowIndex >= 0 Then
            If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                Dim ColName As String = grid.Columns(e.ColumnIndex).Name
                If ColName = "Rate" Then
                    Dim ExercStatusCode As String = grid.Rows(e.RowIndex).Cells("ExercStatusCode").Value
                    Dim ProductEnabled As String = grid.Rows(e.RowIndex).Cells("ProductEnabled").Value
                    If ExercStatusCode = "0" And ProductEnabled = "有効" Then
                        Dim ArrowCount As Integer = grid.Rows(e.RowIndex).Cells("RateArrowCount").Value
                        If ArrowCount <> 0 Then
                            e.Paint(e.CellBounds, e.PaintParts)
                            Dim ArrowChar As String
                            Dim ArrowColor As Color
                            If ArrowCount > 0 Then
                                ArrowChar = "▲"
                                ArrowColor = Color.Red
                            Else
                                ArrowChar = "▼"
                                ArrowColor = Color.Blue
                            End If
                            e.Paint(e.CellBounds, e.PaintParts)
                            TextRenderer.DrawText(e.Graphics, ArrowChar, e.CellStyle.Font, e.CellBounds, ArrowColor, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                            e.Handled = True
                        End If
                    End If
                ElseIf ColName = "Premium" Or ColName = "PAndL" Then
                    If Not IsDBNull(e.Value) AndAlso e.Value < 0 Then
                        e.Paint(e.CellBounds, e.PaintParts And Not DataGridViewPaintParts.ContentForeground)
                        TextRenderer.DrawText(e.Graphics, e.FormattedValue, e.CellStyle.Font, e.CellBounds, Color.Red, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlproduct"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)

                '不要な項目を取り除くための削除対象リスト作成(残す項目はコメントアウト)
                Dim vDelCollumnList As New List(Of String)
                'vDelCollumnList.Add("ComCode")
                'vDelCollumnList.Add("ComName")
                'vDelCollumnList.Add("ExercTime")
                vDelCollumnList.Add("ResidualTime")
                'vDelCollumnList.Add("PayoutRate")
                vDelCollumnList.Add("Rate")
                vDelCollumnList.Add("RateArrowCount")
                'vDelCollumnList.Add("ProductCode")
                'vDelCollumnList.Add("OpType")
                'vDelCollumnList.Add("SysDate")
                'vDelCollumnList.Add("StartTime")
                'vDelCollumnList.Add("TradeLimitTime")
                'vDelCollumnList.Add("ProductEnabled")
                'vDelCollumnList.Add("ExercStatusCode")
                'vDelCollumnList.Add("ExercStatus")
                'vDelCollumnList.Add("ExercPriceStatusCode")
                'vDelCollumnList.Add("ExercPriceStatus")
                'vDelCollumnList.Add("ProductBaseCode")
                'vDelCollumnList.Add("ExercRateSeq")
                'vDelCollumnList.Add("ExercRate")
                'vDelCollumnList.Add("Premium")
                'vDelCollumnList.Add("PAndL")
                vDelCollumnList.Add("VolatilityRatio1Call")
                vDelCollumnList.Add("AskFeePriceCall")
                vDelCollumnList.Add("AskBidSpreadMinCall")
                vDelCollumnList.Add("BidFeeRateCall")
                vDelCollumnList.Add("AskPriceMaxCall")
                vDelCollumnList.Add("AskPriceMinCall")
                vDelCollumnList.Add("BidPriceMaxCall")
                vDelCollumnList.Add("BidPriceMinCall")
                vDelCollumnList.Add("VolatilityRatio1Put")
                vDelCollumnList.Add("AskFeePricePut")
                vDelCollumnList.Add("AskBidSpreadMinPut")
                vDelCollumnList.Add("BidFeeRatePut")
                vDelCollumnList.Add("AskPriceMaxPut")
                vDelCollumnList.Add("AskPriceMinPut")
                vDelCollumnList.Add("BidPriceMaxPut")
                vDelCollumnList.Add("BidPriceMinPut")
                '不要な項目を取り除く
                For Each sDelCollumn As String In vDelCollumnList
                    For Each col As List(Of String) In columnList
                        If col(0) = sDelCollumn Then
                            columnList.Remove(col)
                            Exit For
                        End If
                    Next
                Next

                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub btnPricingCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnPricingCSV.Click

        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlpricing"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)

                '不要な項目を取り除くための削除対象リスト作成(残す項目はコメントアウト)
                Dim vDelCollumnList As New List(Of String)
                vDelCollumnList.Add("ComCode")
                'vDelCollumnList.Add("ComName")
                vDelCollumnList.Add("ExercTime")
                vDelCollumnList.Add("ResidualTime")
                vDelCollumnList.Add("PayoutRate")
                vDelCollumnList.Add("Rate")
                vDelCollumnList.Add("RateArrowCount")
                'vDelCollumnList.Add("ProductCode")
                vDelCollumnList.Add("OpType")
                vDelCollumnList.Add("SysDate")
                vDelCollumnList.Add("StartTime")
                vDelCollumnList.Add("TradeLimitTime")
                vDelCollumnList.Add("ProductEnabled")
                vDelCollumnList.Add("ExercStatusCode")
                vDelCollumnList.Add("ExercStatus")
                vDelCollumnList.Add("ExercPriceStatusCode")
                vDelCollumnList.Add("ExercPriceStatus")
                vDelCollumnList.Add("ProductBaseCode")
                vDelCollumnList.Add("ExercRateSeq")
                vDelCollumnList.Add("ExercRate")
                vDelCollumnList.Add("Premium")
                vDelCollumnList.Add("PAndL")
                'vDelCollumnList.Add("VolatilityRatio1Call")
                'vDelCollumnList.Add("AskFeePriceCall")
                'vDelCollumnList.Add("AskBidSpreadMinCall")
                'vDelCollumnList.Add("BidFeeRateCall")
                'vDelCollumnList.Add("AskPriceMaxCall")
                'vDelCollumnList.Add("AskPriceMinCall")
                'vDelCollumnList.Add("BidPriceMaxCall")
                'vDelCollumnList.Add("BidPriceMinCall")
                'vDelCollumnList.Add("VolatilityRatio1Put")
                'vDelCollumnList.Add("AskFeePricePut")
                'vDelCollumnList.Add("AskBidSpreadMinPut")
                'vDelCollumnList.Add("BidFeeRatePut")
                'vDelCollumnList.Add("AskPriceMaxPut")
                'vDelCollumnList.Add("AskPriceMinPut")
                'vDelCollumnList.Add("BidPriceMaxPut")
                'vDelCollumnList.Add("BidPriceMinPut")
                '不要な項目を取り除く
                For Each sDelCollumn As String In vDelCollumnList
                    For Each col As List(Of String) In columnList
                        If col(0) = sDelCollumn Then
                            columnList.Remove(col)
                            Exit For
                        End If
                    Next
                Next
                '項目の並びを入替える
                Call [clsUtil].SwapCsvColumnList(columnList, "ComName", "ProductCode")

                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub
End Class