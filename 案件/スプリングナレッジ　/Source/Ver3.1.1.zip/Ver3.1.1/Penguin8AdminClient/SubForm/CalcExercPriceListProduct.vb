﻿Public Class CalcExercPriceListProduct

    Public SourceForm As ProductForm = Nothing
    Public ComCode As String = Nothing

    Private WithEvents service As New CalcExercPriceService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As New DataTable

    Private Sub ProductBaseList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        initGrid()

        SetRate()
        request()
    End Sub

    Private Sub ProductBaseList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SourceForm = Nothing
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("ExercPriceSetting", GetType(String))
        Table.Columns.Add("ExercRate", GetType(Decimal))
        Table.Columns.Add("ProductSubstatusCode", GetType(String))
        Table.Columns.Add("ProductSubstatus", GetType(String))
        grid.DataSource = Table
    End Sub

    Private Sub setControlFromData(list As List(Of CalcExercPriceData))
        Table.Clear()
        For Each item In list
            Dim row As DataRow = Table.NewRow()
            row("ExercPriceSetting") = item.ExercPriceSetting
            row("ExercRate") = If(item.ExercPriceEnabled, item.ExercPrice, Nothing)
            row("ProductSubStatusCode") = item.ProductSubStatus
            row("ProductSubStatus") = item.ProductSubStatsuName
            Table.Rows.Add(row)
        Next

    End Sub

    Private Sub btnReflesh_Click(sender As System.Object, e As System.EventArgs) Handles btnReflesh.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                request()
            Case FormMode.READ
                service.CancelCalc()
        End Select
    End Sub

    Public Sub request()
        Dim item = SourceForm.getDataFromControl()
        If ComCode <> item.ComCode Then
            ComCode = item.ComCode
            SetRate()
        End If
        service.ClacList(item, nudRate.Value)
        formModeStatus = FormMode.READ
        btnReflesh.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnReflesh.Text = "更新"
    End Sub

    Private Sub service_ReadCancel() Handles service.CalcCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.CalcError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of CalcExercPriceData)) Handles service.CalcSuccess
        setControlFromData(list)
        requestEnd()
    End Sub

    Private Sub SetRate()
        Dim item = CurrencyPairService.GetData(ComCode)
        Dim rate = DDDService.GetLastRate(ComCode)
        nudRate.Value = rate.Rate
        nudRate.Increment = clsUtil.Pips(item.DecimalPlaces)
        nudRate.DecimalPlaces = item.DecimalPlaces
        ColExercRate.DefaultCellStyle.Format = clsUtil.GetRateDPFormat(item.DecimalPlaces)
    End Sub

End Class