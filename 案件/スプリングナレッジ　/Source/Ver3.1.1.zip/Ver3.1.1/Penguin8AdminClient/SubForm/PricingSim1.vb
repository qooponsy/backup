﻿Public Class PricingSim1

    Private Table As New DataTable

    Private Sub PricingSim1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()
        cbComCode.SelectedIndex = 0

        cbExercPriceUnitType.DisplayMember = "Name"
        cbExercPriceUnitType.ValueMember = "Code"
        cbExercPriceUnitType.DataSource = ExercPriceUnitTypeManager.GetList(True, False)
        cbExercPriceUnitType.SelectedValue = ""

        initGrid()

        LoadSettings()

        setGrid()
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        Dim settings As PricingSim1Settings = PricingSim1Settings.Load()
        [clsUtil].LoadSubFormSettings(Me, settings.FormMaximized, settings.FormSize, settings.FormLocation)

        cbComCode.SelectedValue = settings.ComCode
        cbExercPriceUnitType.SelectedValue = settings.ExercPriceUnitType
        chkAuto.Checked = settings.AutoCalc
        tbVolRatio1Call.Text = settings.VolRatio1Call
        tbVolRatio1Put.Text = settings.VolRatio1Put
        tbCallPutSpread.Text = settings.CallPutSpread
        tbVolRatio2Call.Text = settings.VolRatio2Call
        tbVolRatio2Put.Text = settings.VolRatio2Put
        tbVolSmileACall.Text = settings.VolSmileACall
        tbVolSmileAPut.Text = settings.VolSmileAPut
        tbVolSmileBCall.Text = settings.VolSmileBCall
        tbVolSmileBPut.Text = settings.VolSmileBPut
        tbVolSpreadCall.Text = settings.VolSpreadCall
        tbVolSpreadPut.Text = settings.VolSpreadPut
        tbAskFeePriceCall.Text = settings.AskFeePriceCall
        tbAskFeePricePut.Text = settings.AskFeePricePut
        tbAskBidSpreadMinCall.Text = settings.AskBidSpreadMinCall
        tbAskBidSpreadMinPut.Text = settings.AskBidSpreadMinPut
        tbBidFeeRateCall.Text = settings.BidFeeRateCall
        tbBidFeeRatePut.Text = settings.BidFeeRatePut
        tbAskPriceMaxCall.Text = settings.AskPriceMaxCall
        tbAskPriceMinCall.Text = settings.AskPriceMinCall
        tbBidPriceMaxCall.Text = settings.BidPriceMaxCall
        tbBidPriceMinCall.Text = settings.BidPriceMinCall
        tbAskPriceMaxPut.Text = settings.AskPriceMaxPut
        tbAskPriceMinPut.Text = settings.AskPriceMinPut
        tbBidPriceMaxPut.Text = settings.BidPriceMaxPut
        tbBidPriceMinPut.Text = settings.BidPriceMinPut
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        Dim settings As New PricingSim1Settings
        clsUtil.SaveFormSettings(Me, settings.FormMaximized, settings.FormSize, settings.FormLocation)

        settings.ComCode = cbComCode.SelectedValue
        settings.ExercPriceUnitType = cbExercPriceUnitType.SelectedValue
        settings.AutoCalc = chkAuto.Checked
        settings.VolRatio1Call = tbVolRatio1Call.Text
        settings.VolRatio1Put = tbVolRatio1Put.Text
        settings.CallPutSpread = tbCallPutSpread.Text
        settings.VolRatio2Call = tbVolRatio2Call.Text
        settings.VolRatio2Put = tbVolRatio2Put.Text
        settings.VolSmileACall = tbVolSmileACall.Text
        settings.VolSmileAPut = tbVolSmileAPut.Text
        settings.VolSmileBCall = tbVolSmileBCall.Text
        settings.VolSmileBPut = tbVolSmileBPut.Text
        settings.VolSpreadCall = tbVolSpreadCall.Text
        settings.VolSpreadPut = tbVolSpreadPut.Text
        settings.AskFeePriceCall = tbAskFeePriceCall.Text
        settings.AskFeePricePut = tbAskFeePricePut.Text
        settings.AskBidSpreadMinCall = tbAskBidSpreadMinCall.Text
        settings.AskBidSpreadMinPut = tbAskBidSpreadMinPut.Text
        settings.BidFeeRateCall = tbBidFeeRateCall.Text
        settings.BidFeeRatePut = tbBidFeeRatePut.Text
        settings.AskPriceMaxCall = tbAskPriceMaxCall.Text
        settings.AskPriceMinCall = tbAskPriceMinCall.Text
        settings.BidPriceMaxCall = tbBidPriceMaxCall.Text
        settings.BidPriceMinCall = tbBidPriceMinCall.Text
        settings.AskPriceMaxPut = tbAskPriceMaxPut.Text
        settings.AskPriceMinPut = tbAskPriceMinPut.Text
        settings.BidPriceMaxPut = tbBidPriceMaxPut.Text
        settings.BidPriceMinPut = tbBidPriceMinPut.Text

        PricingSim1Settings.Save(settings)
    End Sub

    Private Sub PricingSim1_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        For Each col As DataGridViewTextBoxColumn In grid.Columns
            col.HeaderText = col.HeaderText.Replace("\n", vbCrLf)
        Next

        Table = New DataTable
        Table.Columns.Add("ExercPriceSetting", GetType(String))
        Table.Columns.Add("ExercPrice", GetType(Decimal))
        Table.Columns.Add("PriceAskCall", GetType(Decimal))
        Table.Columns.Add("PriceBidCall", GetType(Decimal))
        Table.Columns.Add("PriceAskPut", GetType(Decimal))
        Table.Columns.Add("PriceBidPut", GetType(Decimal))
        Table.Columns.Add("VolAskCall", GetType(Decimal))
        Table.Columns.Add("VolBidCall", GetType(Decimal))
        Table.Columns.Add("VolAskPut", GetType(Decimal))
        Table.Columns.Add("VolBidPut", GetType(Decimal))

        grid.DataSource = Table
    End Sub

    Private Sub setGrid()

    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs)
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "simprice"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                For Each item In columnList
                    Select Case item(0)
                        Case Else
                            item(1) = item(1).Replace(vbCrLf, " ")
                    End Select
                Next
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).Name
                Case colExercPrice.Name
                    Dim ComCode As String = cbComCode.SelectedValue
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim ComCode As String = cbComCode.SelectedValue
        Dim Rate As Decimal = DDDService.GetLastRate(ComCode).Rate
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(ComCode).DecimalPlaces
        Dim Unit As Decimal = 5 / clsUtil.Power(DecimalPlaces)
        Dim IncUnit As Decimal = 1 / clsUtil.Power(DecimalPlaces)

        tbBulkSetUnit.Text = Unit.ToString(clsUtil.GetRateDPFormat(DecimalPlaces))

        nudExercPriceUnit.DecimalPlaces = DecimalPlaces
        nudExercPriceUnit.Value = IncUnit
        nudExercPriceUnit.Increment = IncUnit

        nudExercPriceRate.DecimalPlaces = DecimalPlaces
        nudExercPriceRate.Value = Rate
        nudExercPriceRate.Increment = IncUnit

        nudRate.DecimalPlaces = DecimalPlaces
        nudRate.Value = Rate
        nudRate.Increment = IncUnit

        tbHV.Text = CalcParamService.GetData(ComCode).Volatility.ToString("0.##############")
        tbInterestRate.Text = (CalcParamService.GetData(ComCode).InterestRate * 100).ToString("0.############")
        tbSwapRate.Text = (CalcParamService.GetData(ComCode).SwapRate * 100).ToString("0.############")

    End Sub

    Private Sub btnBulkSet_Click(sender As System.Object, e As System.EventArgs) Handles btnBulkSet.Click
        Dim Unit As Decimal
        If Not Decimal.TryParse(tbBulkSetUnit.Text, Unit) Then
            Exit Sub
        End If
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(cbComCode.SelectedValue).DecimalPlaces
        tbExercPriceSettings.Text = LadderOption.buildExercPriceSettings(Unit, nudBulkSetCount.Value, DecimalPlaces)
    End Sub


    Private Sub setting()

        '行使価格決定レートの刻み幅補正
        Dim RateBase As Decimal = Round(nudExercPriceRate.Value, nudExercPriceUnit.Value, cbExercPriceUnitType.SelectedValue)

        Dim list As New List(Of List(Of Object))
        Dim wBuf As String
        Dim ExercPriceSettings() As String
        wBuf = tbExercPriceSettings.Text.Replace(vbCrLf, ",")
        ExercPriceSettings = wBuf.Split(",")

        Dim ExistErrorData As Boolean = False
        For i As Integer = 0 To ExercPriceSettings.Length - 1
            Dim line As New List(Of Object)

            line.Add(ExercPriceSettings(i))
            Dim wDec As Decimal = Decimal.MaxValue
            If Decimal.TryParse(ExercPriceSettings(i), wDec) Then
                Dim ExercPrice As Decimal = RateBase + wDec
                line.Add(ExercPrice)
            Else
                ' TODO: 行使価格設定の10進数データ型変換失敗。
                ExistErrorData = True
                line.Add(Nothing)
            End If

            List.Add(line)
        Next
        If Not ExistErrorData Then
            Dim sortList As New SortedList(Of Decimal, List(Of Object))
            For Each item In List
                sortList.Add(-item(1), item)
            Next
            List.Clear()
            For Each item In sortList
                List.Add(item.Value)
            Next
        End If

        Table.Clear()

        For Each line In list
            Dim row = Table.NewRow()
            row("ExercPriceSetting") = line(0)
            If line(1) IsNot Nothing Then row("ExercPrice") = line(1)
            Table.Rows.Add(row)
        Next

        calc()
    End Sub

    Private Function Round(ByVal dividend As Decimal, ByVal divisor As Decimal, ByVal UnitType As String) As Decimal
        Dim wDec As Decimal
        Dim amari As Decimal

        Select Case UnitType
            Case "0"
                wDec = dividend
            Case "1"
                amari = dividend Mod divisor
                wDec = dividend - amari + IIf(amari > 0, divisor, 0)
            Case "2"
                amari = dividend Mod divisor
                wDec = dividend - amari
            Case Else
                wDec = dividend
        End Select

        Return wDec
    End Function

    Private Sub btnCreate_Click(sender As System.Object, e As System.EventArgs) Handles btnCreate.Click
        setting()
    End Sub

    Private Sub dtpLife_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpLife.ValueChanged
        If chkAuto.Checked Then
            calc()
        End If
    End Sub

    Private Sub nudRate_ValueChanged(sender As System.Object, e As System.EventArgs) Handles nudRate.ValueChanged
        If chkAuto.Checked Then
            calc()
        End If
    End Sub

    Private Sub btnRate_Click(sender As System.Object, e As System.EventArgs) Handles btnRate.Click
        nudRate.Value = DDDService.GetLastRate(cbComCode.SelectedValue).Rate
    End Sub

    Private Sub calc()
        Dim opt As New LadderOption
        If Not Decimal.TryParse(tbPriceUnit.Text, opt.PriceUnit) Then Exit Sub
        opt.CalcTime = DateTime.UtcNow
        If Not Decimal.TryParse(tbInterestRate.Text, opt.InterestRate) Then Exit Sub
        opt.InterestRate /= 100
        If Not Decimal.TryParse(tbSwapRate.Text, opt.SwapRate) Then Exit Sub
        opt.SwapRate /= 100
        If Not Decimal.TryParse(tbHV.Text, opt.HistVol) Then Exit Sub
        opt.ExercTime = opt.CalcTime.AddHours(dtpLife.Value.Hour).AddMinutes(dtpLife.Value.Minute).AddSeconds(dtpLife.Value.Second)
        opt.Rate = nudRate.Value
        If Not Decimal.TryParse(tbVolRatio1Call.Text, opt.VolatilityRatio1Call) Then Exit Sub
        If Not Decimal.TryParse(tbVolRatio1Put.Text, opt.VolatilityRatio1Put) Then Exit Sub
        If Not Decimal.TryParse(tbCallPutSpread.Text, opt.VolatilitySpread) Then Exit Sub
        If Not Decimal.TryParse(tbVolRatio2Call.Text, opt.VolatilityRatio2Call) Then Exit Sub
        If Not Decimal.TryParse(tbVolRatio2Put.Text, opt.VolatilityRatio2Put) Then Exit Sub
        If Not Decimal.TryParse(tbVolSmileACall.Text, opt.VolatilitySmileACall) Then Exit Sub
        If Not Decimal.TryParse(tbVolSmileAPut.Text, opt.VolatilitySmileAPut) Then Exit Sub
        If Not Decimal.TryParse(tbVolSmileBCall.Text, opt.VolatilitySmileBCall) Then Exit Sub
        If Not Decimal.TryParse(tbVolSmileBPut.Text, opt.VolatilitySmileBPut) Then Exit Sub
        If Not Decimal.TryParse(tbVolSpreadCall.Text, opt.VolatilitySpreadITMCall) Then Exit Sub
        opt.VolatilitySpreadOTMCall = opt.VolatilitySpreadITMCall
        If Not Decimal.TryParse(tbVolSpreadPut.Text, opt.VolatilitySpreadITMPut) Then Exit Sub
        opt.VolatilitySpreadOTMPut = opt.VolatilitySpreadITMPut
        If Not Decimal.TryParse(tbAskFeePriceCall.Text, opt.AskFeePriceCall) Then Exit Sub
        If Not Decimal.TryParse(tbAskBidSpreadMinCall.Text, opt.AskBidSpreadMinCall) Then Exit Sub
        If Not Decimal.TryParse(tbBidFeeRateCall.Text, opt.BidFeeRateCall) Then Exit Sub
        opt.BidFeeRateCall /= 100
        If Not Decimal.TryParse(tbAskFeePricePut.Text, opt.AskFeePricePut) Then Exit Sub
        If Not Decimal.TryParse(tbAskBidSpreadMinPut.Text, opt.AskBidSpreadMinPut) Then Exit Sub
        If Not Decimal.TryParse(tbBidFeeRatePut.Text, opt.BidFeeRatePut) Then Exit Sub
        opt.BidFeeRatePut /= 100
        If Not Decimal.TryParse(tbAskPriceMaxCall.Text, opt.AskPriceMaxCall) Then Exit Sub
        If Not Decimal.TryParse(tbAskPriceMinCall.Text, opt.AskPriceMinCall) Then Exit Sub
        If Not Decimal.TryParse(tbBidPriceMaxCall.Text, opt.BidPriceMaxCall) Then Exit Sub
        If Not Decimal.TryParse(tbBidPriceMinCall.Text, opt.BidPriceMinCall) Then Exit Sub
        If Not Decimal.TryParse(tbAskPriceMaxPut.Text, opt.AskPriceMaxPut) Then Exit Sub
        If Not Decimal.TryParse(tbAskPriceMinPut.Text, opt.AskPriceMinPut) Then Exit Sub
        If Not Decimal.TryParse(tbBidPriceMaxPut.Text, opt.BidPriceMaxPut) Then Exit Sub
        If Not Decimal.TryParse(tbBidPriceMinPut.Text, opt.BidPriceMinPut) Then Exit Sub

        For Each row In Table.Rows
            If IsDBNull(row("ExercPrice")) Then Continue For
            opt.ExercPrice = row("ExercPrice")

            opt.CalcVolatility()
            opt.CalcPrice()

            row("PriceAskCall") = opt.AskCall
            row("PriceBidCall") = opt.BidCall
            row("PriceAskPut") = opt.AskPut
            row("PriceBidPut") = opt.BidPut

            row("VolAskCall") = opt.VolAskCall
            row("VolBidCall") = opt.VolBidCall
            row("VolAskPut") = opt.VolAskPut
            row("VolBidPut") = opt.VolBidPut
        Next

    End Sub

    Private Sub miCopy_Click(sender As System.Object, e As System.EventArgs) Handles miCopy.Click
        Clipboard.SetDataObject(grid.GetClipboardContent())
    End Sub

    Private Sub grid_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles grid.KeyDown
        If e.Control And e.KeyCode = Keys.A Then
            grid.SelectAll()
        End If
    End Sub

    Private Sub btnCalc_Click(sender As System.Object, e As System.EventArgs) Handles btnCalc.Click
        calc()
    End Sub

    Private Sub miSelectAll_Click(sender As System.Object, e As System.EventArgs) Handles miSelectAll.Click
        grid.SelectAll()
    End Sub

    Private Sub tbBidFeeRateCall_TextChanged(sender As Object, e As EventArgs) Handles tbBidFeeRateCall.TextChanged
        tbBidFeeRatePut.Text = tbBidFeeRateCall.Text
    End Sub

    Private Sub tbBidPriceMaxCall_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMaxCall.TextChanged
        tbBidPriceMaxPut.Text = tbBidPriceMaxCall.Text
    End Sub

    Private Sub tbBidPriceMinCall_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMinCall.TextChanged
        tbBidPriceMinPut.Text = tbBidPriceMinCall.Text
    End Sub


End Class