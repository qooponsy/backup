﻿Public Class CustAttrForm

    Public Property Code As String

    Private WithEvents service As New CustService

    Private Enum FormMode
        INIT = 0
        READ = 1
        EDIT = 3
        REFERENCE = 4
        EDITCONF = 6
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private data As CustData = Nothing

    Private Sub CustListForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        MainWindow.SubFormCustAttrForm = True

        setFormMode(FormMode.READ)
        lblCustCode.Text = Code
        initEdit()
    End Sub

    Private Sub CustListForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormCustAttrForm = False
    End Sub

    Private Sub btnOk_Click(sender As System.Object, e As System.EventArgs) Handles btnOk.Click
        Select Case FormModeStatus
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.EDITRUN
                service.CancelUpdAttr()
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If UserTypeManager.IsEdit(SessionService.UserType) Or UserTypeManager.IsWL(SessionService.UserType) Then
            Me.Text = "委託者属性編集"
        Else
            Me.Text = "委託者属性参照"
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        txtLossLimit.Enabled = (status = FormMode.EDIT)

        btnOk.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.EDITCONF, FormMode.EDITRUN
                btnOk.Text = "登録"
            Case Else
                btnOk.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select

    End Sub

    Private Sub initEdit()
        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_UpdateAttrCancel() Handles service.UpdateAttrCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_UpdateAttrError(ErrorMessage As String) Handles service.UpdateAttrError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub serviceRead_ReadSuccess(list As System.Collections.Generic.List(Of CustData), existNextFlag As Boolean, TotalMoney As Decimal) Handles service.ReadSuccess
        If list.Count > 0 Then
            data = list(0)
            setControlFromData()
            If UserTypeManager.IsEdit(SessionService.UserType) Or UserTypeManager.IsWL(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_UpdateAttrSuccess() Handles service.UpdateAttrSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData()
        Me.lblCustCode.Text = data.CustCode
        Dim DealDisabledName As String = ""
        If data.DealDisabled <> "0" Then
            DealDisabledName = "停止"
        End If
        Me.lblDealDisabled.Text = DealDisabledName
        Me.lblAccountStart.Text = data.RegTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.lblTotalMoney.Text = data.TotalMoney.ToString(clsUtil.GetMoneyFormatDisp())
        Me.txtLossLimit.Text = data.LossLimit.ToString(clsUtil.GetMoneyFormatEdit())
        Me.lblPAndLMonthly.Text = data.PAndLMonthly.ToString(clsUtil.GetMoneyFormatDisp())
    End Sub

    Private Function getDataFromControl() As CustData
        Dim ret As New CustData With {
            .CmpCode = data.CmpCode,
            .CurCode = data.CurCode,
            .CustCode = data.CustCode,
            .DealDisabled = data.DealDisabled,
            .PAndLMonthly = data.PAndLMonthly,
            .RegTime = data.RegTime,
            .TotalMoney = data.TotalMoney}

        ret.LossLimit = Me.txtLossLimit.Text

        Return ret
    End Function

    Private Function checkInput() As Boolean
        Dim rate As Decimal
        If Not Decimal.TryParse(txtLossLimit.Text, rate) Then
            MessageBox.Show(Me, "損失限度枠には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub updateData()
        Dim data As CustData = getDataFromControl()

        service.UpdAttr(data)
    End Sub

End Class