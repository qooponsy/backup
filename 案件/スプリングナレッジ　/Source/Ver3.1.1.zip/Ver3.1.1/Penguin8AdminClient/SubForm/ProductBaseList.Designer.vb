﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductBaseList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnReflesh = New System.Windows.Forms.Button()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.ProductBaseCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductBaseEnabledCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductBaseEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OptionTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CreateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnReflesh)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(758, 40)
        Me.Panel1.TabIndex = 4
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(385, 6)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 3
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnReflesh
        '
        Me.btnReflesh.Location = New System.Drawing.Point(296, 6)
        Me.btnReflesh.Name = "btnReflesh"
        Me.btnReflesh.Size = New System.Drawing.Size(89, 29)
        Me.btnReflesh.TabIndex = 2
        Me.btnReflesh.Text = "更新"
        Me.btnReflesh.UseVisualStyleBackColor = True
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(144, 14)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 1
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(12, 12)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 0
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ProductBaseCode, Me.ProductBaseEnabledCode, Me.ProductBaseEnabled, Me.ComCode, Me.ComName, Me.OpType, Me.OptionTime, Me.CreateTime, Me.StartTime, Me.ExercTime})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 40)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle24
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(758, 197)
        Me.grid.TabIndex = 5
        '
        'ProductBaseCode
        '
        Me.ProductBaseCode.DataPropertyName = "ProductBaseCode"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseCode.DefaultCellStyle = DataGridViewCellStyle14
        Me.ProductBaseCode.HeaderText = "銘柄設定コード"
        Me.ProductBaseCode.Name = "ProductBaseCode"
        Me.ProductBaseCode.ReadOnly = True
        Me.ProductBaseCode.Width = 108
        '
        'ProductBaseEnabledCode
        '
        Me.ProductBaseEnabledCode.DataPropertyName = "ProductBaseEnabledCode"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseEnabledCode.DefaultCellStyle = DataGridViewCellStyle15
        Me.ProductBaseEnabledCode.HeaderText = "有効フラグ(Code)"
        Me.ProductBaseEnabledCode.Name = "ProductBaseEnabledCode"
        Me.ProductBaseEnabledCode.ReadOnly = True
        Me.ProductBaseEnabledCode.Visible = False
        '
        'ProductBaseEnabled
        '
        Me.ProductBaseEnabled.DataPropertyName = "ProductBaseEnabled"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseEnabled.DefaultCellStyle = DataGridViewCellStyle16
        Me.ProductBaseEnabled.HeaderText = "有効フラグ"
        Me.ProductBaseEnabled.Name = "ProductBaseEnabled"
        Me.ProductBaseEnabled.ReadOnly = True
        Me.ProductBaseEnabled.Width = 79
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle17
        Me.ComCode.HeaderText = "通貨ペア(code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.Visible = False
        Me.ComCode.Width = 80
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle18
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 73
        '
        'OpType
        '
        Me.OpType.DataPropertyName = "OpType"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OpType.DefaultCellStyle = DataGridViewCellStyle19
        Me.OpType.HeaderText = "オプション種別"
        Me.OpType.Name = "OpType"
        Me.OpType.ReadOnly = True
        Me.OpType.Width = 97
        '
        'OptionTime
        '
        Me.OptionTime.DataPropertyName = "OptionTime"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle20.Format = "####分"
        DataGridViewCellStyle20.NullValue = Nothing
        Me.OptionTime.DefaultCellStyle = DataGridViewCellStyle20
        Me.OptionTime.HeaderText = "オプション期間"
        Me.OptionTime.Name = "OptionTime"
        Me.OptionTime.ReadOnly = True
        Me.OptionTime.Width = 97
        '
        'CreateTime
        '
        Me.CreateTime.DataPropertyName = "CreateTime"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle21.Format = "####分"
        DataGridViewCellStyle21.NullValue = Nothing
        Me.CreateTime.DefaultCellStyle = DataGridViewCellStyle21
        Me.CreateTime.HeaderText = "生成間隔"
        Me.CreateTime.Name = "CreateTime"
        Me.CreateTime.ReadOnly = True
        Me.CreateTime.Width = 78
        '
        'StartTime
        '
        Me.StartTime.DataPropertyName = "StartTime"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle22.NullValue = Nothing
        Me.StartTime.DefaultCellStyle = DataGridViewCellStyle22
        Me.StartTime.HeaderText = "生成開始時間"
        Me.StartTime.Name = "StartTime"
        Me.StartTime.ReadOnly = True
        Me.StartTime.Width = 102
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle23.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle23
        Me.ExercTime.HeaderText = "最終行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        Me.ExercTime.Width = 102
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(296, 87)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(203, 63)
        Me.lblNoData.TabIndex = 16
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProductBaseList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(758, 237)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "ProductBaseList"
        Me.Text = "銘柄設定一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents btnReflesh As System.Windows.Forms.Button
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents ProductBaseCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductBaseEnabledCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductBaseEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OpType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OptionTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CreateTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
