﻿Public Class CustomerLedgerList
    Private WithEvents service As New CustomerLedgerService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1
    Private Count As Integer = 1000

    Private ConditionString As String = ""          ' 印刷用抽出条件文字列

    Private Sub CustomerLedgerList_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        
        clsUtil.SetGridDoubleBuffered(grid)

        ExercPrice.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Price.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PayoutPrice.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PremiumOrPayout.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Payout.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        TotalMoneyPrev.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Money.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        TotalMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        '初期値の設定
        Dim SysDate As DateTime = clsUtil.GetPrevWorkDay(SysStatusService.GetData().SysDate)
        dtpSysDateFrom.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
        dtpSysDateTo.Value = DateTime.Now
        dtpSysDateTo.Checked = False

        MainWindow.SubFormCustomerLedgerListList = True
        LoadSettings()

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub CustomerLedgerList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormCustomerLedgerListList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.CustomerLedgerList_FormMaximized, _
            UserSettings.getInstance().DataSaved.CustomerLedgerList_FormSize, _
            UserSettings.getInstance().DataSaved.CustomerLedgerList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.CustomerLedgerList_Columns)
        tbCustCode.Text = UserSettings.getInstance().DataSaved.CustomerLedgerList_CustCode
        chkMovementOfFundsDisp.Checked = UserSettings.getInstance().DataSaved.CustomerLedgerList_MovementOfFundsDisp
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.CustomerLedgerList_FormMaximized, _
            UserSettings.getInstance().DataSaved.CustomerLedgerList_FormSize, _
            UserSettings.getInstance().DataSaved.CustomerLedgerList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.CustomerLedgerList_Columns)
        UserSettings.getInstance().DataSaved.CustomerLedgerList_CustCode = tbCustCode.Text
        UserSettings.getInstance().DataSaved.CustomerLedgerList_MovementOfFundsDisp = chkMovementOfFundsDisp.Checked
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False
        Table = New DataTable
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("CustCode", GetType(String))
        Table.Columns.Add("CustName", GetType(String))
        Table.Columns.Add("ExecTime", GetType(DateTime))
        Table.Columns.Add("TypeOfTrading", GetType(String))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("ExercPrice", GetType(Decimal))
        Table.Columns.Add("BuySell", GetType(String))
        Table.Columns.Add("TradeType", GetType(String))
        Table.Columns.Add("TradeTypeName", GetType(String))
        Table.Columns.Add("CashTypeName", GetType(String))
        Table.Columns.Add("TradeStatusName", GetType(String))
        Table.Columns.Add("Lot", GetType(Integer))
        Table.Columns.Add("Price", GetType(Decimal))
        Table.Columns.Add("PayoutPrice", GetType(Decimal))
        Table.Columns.Add("PremiumOrPayout", GetType(Decimal))
        Table.Columns.Add("Payout", GetType(Decimal))
        Table.Columns.Add("TotalMoneyPrev", GetType(Decimal))
        Table.Columns.Add("Money", GetType(Decimal))
        Table.Columns.Add("TotalMoney", GetType(Decimal))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of CustomerLedgerData))
        For Each item As CustomerLedgerData In list
            Dim row As DataRow = Table.NewRow()
            row("SysDate") = item.SysDate
            row("CustCode") = IIf(item.CustCodeEnabled, item.CustCode, DBNull.Value)
            row("CustName") = IIf(item.CustNameEnabled, item.CustName, DBNull.Value)
            row("ExecTime") = IIf(item.ExecTimeEnabled, item.ExecTime, DBNull.Value)
            row("TypeOfTrading") = IIf(item.TypeOfTradingEnabled, item.TypeOfTrading, DBNull.Value)
            row("ComCode") = IIf(item.ComCodeEnabled, item.ComCode, DBNull.Value)
            If (item.ComCodeEnabled) Then
                row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            Else
                row("ComName") = DBNull.Value
            End If
            row("ExercTime") = IIf(item.ExercTimeEnabled, item.ExercTime, DBNull.Value)
            row("ExercPrice") = IIf(item.ExercPriceEnabled, item.ExercPrice, DBNull.Value)
            row("BuySell") = IIf(item.BuySellEnabled, item.BuySell, DBNull.Value)
            row("TradeType") = IIf(item.TradeTypeEnabled, item.TradeType, DBNull.Value)
            row("TradeTypeName") = item.TradeTypeName
            row("CashTypeName") = IIf(item.CashTypeNameEnabled, item.CashTypeName, DBNull.Value)
            row("TradeStatusName") = IIf(item.TradeStatusNameEnabled, item.TradeStatusName, DBNull.Value)
            row("Lot") = IIf(item.LotEnabled, item.Lot, DBNull.Value)
            row("Price") = IIf(item.PriceEnabled, item.Price, DBNull.Value)
            row("PayoutPrice") = IIf(item.PayoutPriceEnabled, item.PayoutPrice, DBNull.Value)
            row("PremiumOrPayout") = IIf(item.PremiumOrPayoutEnabled, item.PremiumOrPayout, DBNull.Value)
            row("Payout") = IIf(item.PayoutEnabled, item.Payout, DBNull.Value)
            row("TotalMoneyPrev") = IIf(item.TotalMoneyPrevEnabled, item.TotalMoneyPrev, DBNull.Value)
            row("Money") = IIf(item.MoneyEnabled, item.Money, DBNull.Value)
            row("TotalMoney") = IIf(item.TotalMoneyEnabled, item.TotalMoney, DBNull.Value)
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        '----------------------------------------------------------------------
        ' 印刷用　抽出条件編集
        '----------------------------------------------------------------------
        Dim SortKey As String = ""

        ConditionString = ""
        If dtpSysDateFrom.Checked Or dtpSysDateTo.Checked Then
            If dtpSysDateFrom.Checked Then
                ConditionString = ConditionString & dtpSysDateFrom.Value.ToString("yyyy/MM/dd")
            End If
            ConditionString = ConditionString & "　～　"
            If dtpSysDateTo.Checked Then
                ConditionString = ConditionString & dtpSysDateTo.Value.ToString("yyyy/MM/dd")
            End If
        End If
        '--
        If chkMovementOfFundsDisp.Checked Then
            ConditionString = ConditionString & vbTab
            ConditionString = ConditionString & "　　資金移動が無くても表示する"
        End If
        '--
        ConditionString = ConditionString & vbTab
        ConditionString = ConditionString & "　　委託者コード:" & tbCustCode.Text

        service.ReadList(dtpSysDateFrom.Checked,
                         dtpSysDateFrom.Value,
                         dtpSysDateTo.Checked,
                         dtpSysDateTo.Value,
                         IIf(Me.chkMovementOfFundsDisp.Checked, "1", ""),
                         tbCustCode.Text,
                         Count,
                         Start,
                         SortKey)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of CustomerLedgerData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 And list.Count = 0)
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlcustomerledger"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)

                '不要な項目を取り除く
                For Each col As List(Of String) In columnList
                    If col(0) = "ComCode" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next
                For Each col As List(Of String) In columnList
                    If col(0) = "TradeType" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next

                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).DataPropertyName
                Case "ExercPrice"
                    If Not IsDBNull(grid.Rows(e.RowIndex).Cells("ComCode").Value) Then  '入金・出金データなどはDBNullが入るためFormat設定しない
                        Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComCode").Value
                        Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                        e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
                    End If
            End Select
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' 印刷 2012/06/28 H.S
    '--------------------------------------------------------------------------
    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
        Dim PrtUtil As PrintUtil

        Try
            PrtUtil = New PrintUtil()
            PrtUtil.PrintReport(grid, PrintUtil.Reports.CustomerLedger, ConditionString)
        Catch ex As Exception
        End Try
    End Sub

End Class