﻿Imports System.Net
Imports System.Collections.Specialized

Public Class LossLimitLogList
    Private WithEvents service As LossLimitLogService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private View As DataView
    Private Start As Integer = 1

    Private Sub LossLimitLogList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        SysDate.HeaderText = "システム" & vbCrLf & "営業日"
        CustCode.HeaderText = "委託者" & vbCrLf & "コード"

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbLogType.DisplayMember = "Name"
        cbLogType.ValueMember = "Code"
        cbLogType.DataSource = LossLimitLogTypeManager.GetLogTypeList()


        grid.AutoGenerateColumns = False

        '初期値の設定
        dtpFromDate.Value = SysStatusService.GetData().SysDate
        dtpFromDate.Checked = True
        dtpToDate.Value = SysStatusService.GetData().SysDate
        dtpToDate.Checked = False


        MainWindow.SubFormLossLimitLogList = True

        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()

        formModeStatus = FormMode.NORMAL

        setWindowLayout(False)

    End Sub

    Private Sub RateFilterLogList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormLossLimitLogList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.LossLimitLogList_FormMaximized, _
            UserSettings.getInstance().DataSaved.LossLimitLogList_FormSize, _
            UserSettings.getInstance().DataSaved.LossLimitLogList_FormLocation)
        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.LossLimitLogList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.LossLimitLogList_CmpCode
        cbLogType.SelectedValue = UserSettings.getInstance().DataSaved.LossLimitLogList_LogType
        tbCustCode.Text = UserSettings.getInstance().DataSaved.LossLimitLogList_CustCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.LossLimitLogList_FormMaximized, _
            UserSettings.getInstance().DataSaved.LossLimitLogList_FormSize, _
            UserSettings.getInstance().DataSaved.LossLimitLogList_FormLocation)
        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.LossLimitLogList_Columns)
        UserSettings.getInstance().DataSaved.LossLimitLogList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.LossLimitLogList_LogType = cbLogType.SelectedValue
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("LogTime", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(Date))
        Table.Columns.Add("CmpCode", GetType(String))
        Table.Columns.Add("CmpName", GetType(String))
        Table.Columns.Add("CustCode", GetType(String))
        Table.Columns.Add("LogType", GetType(String))
        Table.Columns.Add("LogText", GetType(String))
        View = New DataView(Table)
        grid.DataSource = View
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of LossLimitLogData))
        For Each item As LossLimitLogData In list
            Dim row As DataRow = Table.NewRow()
            row("LogTime") = item.LogTime
            row("SysDate") = item.SysDate
            row("CmpCode") = item.CmpCode
            row("CmpName") = CompanyService.GetName(item.CmpCode)
            row("CustCode") = item.CsutCode
            row("LogType") = item.LogTypeName
            row("LogText") = item.LogText.Replace("\1", ",")
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                setWindowLayout(False)
                request()
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlLossLimit"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As List(Of LossLimitLogData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 And list.Count = 0)
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim CustCode As String = Me.tbCustCode.Text
        Dim FromDate As String = IIf(dtpFromDate.Checked, dtpFromDate.Value.ToString("yyyyMMdd"), "")
        Dim ToDate As String = IIf(dtpToDate.Checked, dtpToDate.Value.ToString("yyyyMMdd"), "")
        Dim LogType As String = Me.cbLogType.SelectedValue

        service = New LossLimitLogService
        service.ReadList(CmpCode, FromDate, ToDate, CustCode, LogType, "", Start)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        service = Nothing
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub


End Class