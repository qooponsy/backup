﻿Imports System.Net
Imports System.Collections.Specialized

Public Class CashList
    Private WithEvents service As New CashService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Count As Integer = 100
    Private Start As Integer = 1

	Private ConditionString As String = ""			' 印刷用抽出条件文字列

    Private Sub CashList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Money.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        TotalMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        Dim editable As Boolean = UserTypeManager.IsEdit(SessionService.UserType)
        btnRegist.Enabled = editable
        miEdit.Text = IIf(editable, "編集", "参照")

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbCashType.DisplayMember = "Name"
        cbCashType.ValueMember = "Code"
        cbCashType.DataSource = CashTypeManager.GetListWithAll()

        cbDateType.DisplayMember = "Name"
        cbDateType.ValueMember = "Code"
        cbDateType.DataSource = DateTypeManager.GetCashList()

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        dtpFromDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day, SysStaticsService.SysDateStartTime.Hours, SysStaticsService.SysDateStartTime.Minutes, SysStaticsService.SysDateStartTime.Seconds)
        dtpToDateTime.Value = DateTime.Now
        dtpToDateTime.Checked = False

        MainWindow.SubFormCash = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)

    End Sub

    Private Sub CashList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormCash = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.CashList_FormMaximized, _
            UserSettings.getInstance().DataSaved.CashList_FormSize, _
            UserSettings.getInstance().DataSaved.CashList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.CashList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.CashList_CmpCode
        cbCashType.SelectedValue = UserSettings.getInstance().DataSaved.CashList_CashType
        cbDateType.SelectedIndex = UserSettings.getInstance().DataSaved.CashList_DateType
        tbCustCode.Text = UserSettings.getInstance().DataSaved.CashList_CustCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.CashList_FormMaximized, _
            UserSettings.getInstance().DataSaved.CashList_FormSize, _
            UserSettings.getInstance().DataSaved.CashList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.CashList_Columns)
        UserSettings.getInstance().DataSaved.CashList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.CashList_CashType = cbCashType.SelectedValue
        UserSettings.getInstance().DataSaved.CashList_DateType = cbDateType.SelectedIndex
        UserSettings.getInstance().DataSaved.CashList_CustCode = tbCustCode.Text
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("CashCode", GetType(String))
        Table.Columns.Add("CashEnabled", GetType(String))
        Table.Columns.Add("CashEnabledName", GetType(String))
        Table.Columns.Add("ExecTime", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("CashType", GetType(String))
        Table.Columns.Add("CashTypeName", GetType(String))
        Table.Columns.Add("Money", GetType(Decimal))
        Table.Columns.Add("TotalMoney", GetType(Decimal))
        Table.Columns.Add("CustCode", GetType(String))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of CashData))
        For Each item As CashData In list
            Dim row As DataRow = Table.NewRow()
            row("CashCode") = item.CashCode
            row("CashEnabled") = item.Enabled
            row("CashEnabledName") = item.EnabledName
            row("ExecTime") = item.ExecTime
            row("SysDate") = item.SysDate
            row("CashType") = item.CashType
            row("CashTypeName") = item.CashTypeName
            row("Money") = item.Money
            row("TotalMoney") = item.TotalMoney
            row("CustCode") = item.CustCode
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    '''  [新規]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("CashCode").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("CashCode").Value
        edit(code)
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim CashType As String = Me.cbCashType.SelectedValue
        Dim DateType As String = Me.cbDateType.SelectedValue
        Dim CustCode As String = Me.tbCustCode.Text
        Dim SortKey As String = ""

        Dim SysDateFrom As String = ""
        Dim SysDateTo As String = ""
        Dim ExecTimeFrom As String = ""
        Dim ExecTimeTo As String = ""
        If DateType = "1" Then
            ExecTimeFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
            ExecTimeTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Else
            SysDateFrom = IIf(dtpFromDateTime.Checked, dtpFromDateTime.Value.ToString("yyyyMMdd"), "")
            SysDateTo = IIf(dtpToDateTime.Checked, dtpToDateTime.Value.ToString("yyyyMMdd"), "")
        End If

		'----------------------------------------------------------------------
		' 印刷用　抽出条件編集
		'----------------------------------------------------------------------
		ConditionString = ""
        If dtpFromDateTime.Checked Or dtpToDateTime.Checked Then
            ConditionString = ConditionString & "　" & Me.cbDateType.Text & "　"
            If dtpFromDateTime.Checked Then
                ConditionString = ConditionString & dtpFromDateTime.Value.ToString("yyyy/MM/dd")
            End If
            ConditionString = ConditionString & "　～　"
            If dtpToDateTime.Checked Then
                ConditionString = ConditionString & dtpToDateTime.Value.ToString("yyyy/MM/dd")
            End If
        End If
        ConditionString = ConditionString & vbTab
        ConditionString = ConditionString & "　　会社：" & cbCmpCode.Text
        If Me.cbCashType.SelectedValue <> "" Then
            ConditionString = ConditionString & "　　取引種別：" & Me.cbCashType.Text
        End If
        If CustCode <> "" Then
            ConditionString = ConditionString & "　　委託者コード：" & CustCode
        End If

		service.ReadList(CustCode, CmpCode, SysDateFrom, SysDateTo, ExecTimeFrom, ExecTimeTo, CashType, "", Start.ToString(), SortKey)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of CashData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 And list.Count = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormCashForm Then
            CashForm.Close()
        End If
        CashForm.MdiParent = MainWindow
        CashForm.Code = ""
        CashForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormCashForm Then
            CashForm.Close()
        End If
        CashForm.MdiParent = MainWindow
        CashForm.Code = code
        CashForm.Show()
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlcash"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grid.CellPainting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).Name
                Case "Money", "TotalMoney"
                    If e.Value < 0 Then
                        If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                            e.Paint(e.CellBounds, e.PaintParts And Not DataGridViewPaintParts.ContentForeground)
                            TextRenderer.DrawText(e.Graphics, e.FormattedValue, e.CellStyle.Font, e.CellBounds, Color.Red, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                            e.Handled = True
                        End If
                    End If
            End Select
        End If
    End Sub

	'--------------------------------------------------------------------------
	' 印刷 2012/06/28 H.S
	'--------------------------------------------------------------------------
	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		Dim PrtUtil As PrintUtil

		Try
			PrtUtil = New PrintUtil()
			PrtUtil.PrintReport(grid, PrintUtil.Reports.CashList, ConditionString)
		Catch ex As Exception
		End Try
	End Sub
End Class