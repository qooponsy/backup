﻿Public Class RateHistForm
    Public Property Code As String

    Private WithEvents service As New RateHistService
    Private WithEvents serviceViewSeq As ViewSeqService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub RateHistForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbExercFlag.DisplayMember = "Name"
        cbExercFlag.ValueMember = "Code"
        cbExercFlag.DataSource = ExercFlagManager.GetList()

        MainWindow.SubFormRateHistForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub RateHistForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormRateHistForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "レート登録"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "レート編集"
            Else
                Me.Text = "レート参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbComCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpRateTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbRateTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpRateTimeSource.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbRateTimeSourceMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbExercFlag.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        If cbExercFlag.SelectedValue = "1" Then
            dtpExercTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
            tbRateDispSeq.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
            btnNewViewSeq.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        Else
            dtpExercTime.Enabled = False
            tbRateDispSeq.Enabled = False
            btnNewViewSeq.Enabled = False
        End If
        If dtpExercTime.Enabled Then
            dtpExercTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Else
            dtpExercTime.CustomFormat = " "
        End If

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        cbComCode.SelectedValue = ""
        dtpRateTime.Value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        tbRateTimeMilliseconds.Text = ""
        dtpRateTimeSource.Value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        tbRateTimeSourceMilliseconds.Text = ""
        tbRate.Text = ""
        cbEnabled.SelectedValue = ""
        cbExercFlag.SelectedValue = ""
        dtpExercTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        tbRateDispSeq.Text = ""
    End Sub

    Private Sub initEdit()
        cbComCode.SelectedValue = ""
        dtpRateTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        dtpRateTimeSource.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        tbRateTimeMilliseconds.Text = ""
        tbRateTimeSourceMilliseconds.Text = ""
        tbRate.Text = ""
        cbEnabled.SelectedValue = ""
        cbExercFlag.SelectedValue = ""
        dtpExercTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        tbRateDispSeq.Text = ""

        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of RateHistData), existNextFlag As Boolean) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "レートの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).RateSeq <> Code Then
            MessageBox.Show(Me, "レートの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As RateHistData)
        Me.lblCode.Text = data.RateSeq
        Me.cbComCode.SelectedValue = data.ComCode
        Me.dtpRateTime.Value = data.RateTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbRateTimeMilliseconds.Text = data.RateTime.ToString("fff")
        Me.dtpRateTimeSource.Value = data.RateTimeSource.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbRateTimeSourceMilliseconds.Text = data.RateTimeSource.ToString("fff")
        Me.tbRate.Text = data.Rate.ToString("######0.########")
        Me.cbEnabled.SelectedValue = data.Enabled
        Me.cbExercFlag.SelectedValue = data.Exerc
        Me.dtpExercTime.Value = IIf(data.ExercTimeEnabled, data.ExercTime, DateTime.Now)
        Me.tbRateDispSeq.Text = data.ViewSeq
    End Sub

    Private Function getDataFromControl() As RateHistData
        Dim ret As New RateHistData

        ret.RateSeq = Me.lblCode.Text
        ret.ComCode = Me.cbComCode.SelectedValue
        ret.RateTime = dtpRateTime.Value
        If tbRateTimeMilliseconds.Text <> "" Then
            ret.RateTime = ret.RateTime.AddMilliseconds(Integer.Parse(tbRateTimeMilliseconds.Text))
        End If
        ret.RateTimeSource = dtpRateTimeSource.Value
        If tbRateTimeSourceMilliseconds.Text <> "" Then
            ret.RateTimeSource = ret.RateTimeSource.AddMilliseconds(Integer.Parse(tbRateTimeSourceMilliseconds.Text))
        End If
        ret.Rate = Decimal.Parse(Me.tbRate.Text)
        ret.Enabled = cbEnabled.SelectedValue
        ret.Exerc = Me.cbExercFlag.SelectedValue
        If ret.Exerc = "1" Then
            ret.ExercTimeEnabled = True
            ret.ExercTime = Me.dtpExercTime.Value
        Else
            ret.ExercTimeEnabled = False
        End If
        ret.ViewSeq = Me.tbRateDispSeq.Text

        Return ret
    End Function

    Private Function checkInput() As Boolean
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbRateTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "日時には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbRateTimeSourceMilliseconds.Text) Then
            MessageBox.Show(Me, "日時(ソース)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExRate.IsMatch(tbRate.Text) Then
            MessageBox.Show(Me, "レートには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim com As CurrencyPairData = CurrencyPairService.GetData(cbComCode.SelectedValue)
        If Not CheckUtil.GetRegRateDecimalPlaces(com.DecimalPlaces).IsMatch(tbRate.Text) Then
            MessageBox.Show(Me, String.Format("レートは小数{0}桁以内で入力してください。", com.DecimalPlaces), My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim rate As Decimal
        If Not Decimal.TryParse(tbRate.Text, rate) Then
            MessageBox.Show(Me, "レートには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If cbExercFlag.SelectedValue = "" Then
            MessageBox.Show(Me, "行使フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As RateHistData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As RateHistData = getDataFromControl()

        service.Update(data)
    End Sub

    Private Sub getNewViewSeq()
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Dim ComCode As String = cbComCode.SelectedValue
        Dim ExercTime As DateTime = dtpExercTime.Value

        serviceViewSeq = New ViewSeqService
        serviceViewSeq.Request(ComCode, ExercTime)
    End Sub

    Private Sub cbExercFlag_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbExercFlag.SelectedIndexChanged
        setFormMode(FormModeStatus)
    End Sub

    Private Sub btnNewViewSeq_Click(sender As System.Object, e As System.EventArgs) Handles btnNewViewSeq.Click
        getNewViewSeq()
    End Sub

    Private Sub serviceViewSeq_RequestCancel() Handles serviceViewSeq.RequestCancel
        serviceViewSeq = Nothing
    End Sub

    Private Sub serviceViewSeq_RequestError(ErrorMessage As String) Handles serviceViewSeq.RequestError
        serviceViewSeq = Nothing
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub serviceViewSeq_RequestSuccess(Data As String) Handles serviceViewSeq.RequestSuccess
        tbRateDispSeq.Text = Data

        serviceViewSeq = Nothing
    End Sub
End Class
