﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductSubForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDisabled = New System.Windows.Forms.Button()
        Me.btnEnabled = New System.Windows.Forms.Button()
        Me.lblProductCode = New System.Windows.Forms.Label()
        Me.lblProductSubCode = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbProductSubStatus = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.tbExercPrice = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lblProductDetail = New System.Windows.Forms.Label()
        Me.tbVolRatio1Call = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMinCall = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.tbExercRate = New System.Windows.Forms.TextBox()
        Me.tbExercRateSeq = New System.Windows.Forms.TextBox()
        Me.cbExercStatus = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbExercResultPut = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbExercResultCall = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.tbExercPriceSetting = New System.Windows.Forms.TextBox()
        Me.dtpExercRateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblEnabled = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.tbAskBidSpreadMinCall = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMinCall = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnDisabled
        '
        Me.btnDisabled.Location = New System.Drawing.Point(192, 12)
        Me.btnDisabled.Name = "btnDisabled"
        Me.btnDisabled.Size = New System.Drawing.Size(98, 29)
        Me.btnDisabled.TabIndex = 38
        Me.btnDisabled.Text = "銘柄無効化"
        Me.btnDisabled.UseVisualStyleBackColor = True
        '
        'btnEnabled
        '
        Me.btnEnabled.Location = New System.Drawing.Point(88, 12)
        Me.btnEnabled.Name = "btnEnabled"
        Me.btnEnabled.Size = New System.Drawing.Size(98, 29)
        Me.btnEnabled.TabIndex = 37
        Me.btnEnabled.Text = "銘柄有効化"
        Me.btnEnabled.UseVisualStyleBackColor = True
        '
        'lblProductCode
        '
        Me.lblProductCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProductCode.Location = New System.Drawing.Point(159, 114)
        Me.lblProductCode.Name = "lblProductCode"
        Me.lblProductCode.Size = New System.Drawing.Size(131, 23)
        Me.lblProductCode.TabIndex = 31
        Me.lblProductCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblProductSubCode
        '
        Me.lblProductSubCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProductSubCode.Location = New System.Drawing.Point(159, 55)
        Me.lblProductSubCode.Name = "lblProductSubCode"
        Me.lblProductSubCode.Size = New System.Drawing.Size(131, 23)
        Me.lblProductSubCode.TabIndex = 27
        Me.lblProductSubCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(30, 119)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 12)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "銘柄コード"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 89)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 12)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "有効フラグ"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 12)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "銘柄詳細コード"
        '
        'cbProductSubStatus
        '
        Me.cbProductSubStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbProductSubStatus.FormattingEnabled = True
        Me.cbProductSubStatus.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbProductSubStatus.Location = New System.Drawing.Point(462, 116)
        Me.cbProductSubStatus.Name = "cbProductSubStatus"
        Me.cbProductSubStatus.Size = New System.Drawing.Size(131, 20)
        Me.cbProductSubStatus.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(333, 119)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 12)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "ステータス"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(325, 419)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 36
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(192, 419)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 35
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'tbExercPrice
        '
        Me.tbExercPrice.Location = New System.Drawing.Point(462, 86)
        Me.tbExercPrice.Name = "tbExercPrice"
        Me.tbExercPrice.Size = New System.Drawing.Size(131, 19)
        Me.tbExercPrice.TabIndex = 1
        Me.tbExercPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(333, 87)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 12)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "行使価格"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(333, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 12)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "行使価格設定"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(330, 192)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 12)
        Me.Label2.TabIndex = 78
        Me.Label2.Text = "最低購入価格"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(330, 220)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(77, 12)
        Me.Label19.TabIndex = 76
        Me.Label19.Text = "最高清算価格"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(31, 164)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(98, 12)
        Me.Label23.TabIndex = 70
        Me.Label23.Text = "ボラティリティレシオ１"
        '
        'lblProductDetail
        '
        Me.lblProductDetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblProductDetail.Location = New System.Drawing.Point(335, 18)
        Me.lblProductDetail.Name = "lblProductDetail"
        Me.lblProductDetail.Size = New System.Drawing.Size(258, 23)
        Me.lblProductDetail.TabIndex = 80
        Me.lblProductDetail.Text = "USD/JPY ラダー CALL 11:00 "
        Me.lblProductDetail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbVolRatio1Call
        '
        Me.tbVolRatio1Call.Location = New System.Drawing.Point(231, 161)
        Me.tbVolRatio1Call.Name = "tbVolRatio1Call"
        Me.tbVolRatio1Call.Size = New System.Drawing.Size(60, 19)
        Me.tbVolRatio1Call.TabIndex = 3
        Me.tbVolRatio1Call.Text = "0.5"
        Me.tbVolRatio1Call.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMinCall
        '
        Me.tbAskPriceMinCall.Location = New System.Drawing.Point(462, 188)
        Me.tbAskPriceMinCall.Name = "tbAskPriceMinCall"
        Me.tbAskPriceMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskPriceMinCall.TabIndex = 23
        Me.tbAskPriceMinCall.Text = "40"
        Me.tbAskPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMaxCall
        '
        Me.tbBidPriceMaxCall.Location = New System.Drawing.Point(462, 216)
        Me.tbBidPriceMaxCall.Name = "tbBidPriceMaxCall"
        Me.tbBidPriceMaxCall.Size = New System.Drawing.Size(60, 19)
        Me.tbBidPriceMaxCall.TabIndex = 25
        Me.tbBidPriceMaxCall.Text = "960"
        Me.tbBidPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbExercRate
        '
        Me.tbExercRate.Location = New System.Drawing.Point(148, 385)
        Me.tbExercRate.Name = "tbExercRate"
        Me.tbExercRate.Size = New System.Drawing.Size(142, 19)
        Me.tbExercRate.TabIndex = 32
        Me.tbExercRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbExercRateSeq
        '
        Me.tbExercRateSeq.Location = New System.Drawing.Point(148, 325)
        Me.tbExercRateSeq.MaxLength = 17
        Me.tbExercRateSeq.Name = "tbExercRateSeq"
        Me.tbExercRateSeq.Size = New System.Drawing.Size(142, 19)
        Me.tbExercRateSeq.TabIndex = 30
        '
        'cbExercStatus
        '
        Me.cbExercStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercStatus.FormattingEnabled = True
        Me.cbExercStatus.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercStatus.Location = New System.Drawing.Point(148, 295)
        Me.cbExercStatus.Name = "cbExercStatus"
        Me.cbExercStatus.Size = New System.Drawing.Size(142, 20)
        Me.cbExercStatus.TabIndex = 29
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(31, 390)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 12)
        Me.Label6.TabIndex = 103
        Me.Label6.Text = "行使時価格"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(31, 330)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(84, 12)
        Me.Label11.TabIndex = 101
        Me.Label11.Text = "行使時価格Seq"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(31, 299)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 12)
        Me.Label7.TabIndex = 99
        Me.Label7.Text = "行使フラグ"
        '
        'cbExercResultPut
        '
        Me.cbExercResultPut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercResultPut.FormattingEnabled = True
        Me.cbExercResultPut.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercResultPut.Location = New System.Drawing.Point(462, 326)
        Me.cbExercResultPut.Name = "cbExercResultPut"
        Me.cbExercResultPut.Size = New System.Drawing.Size(131, 20)
        Me.cbExercResultPut.TabIndex = 34
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(331, 330)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 12)
        Me.Label5.TabIndex = 105
        Me.Label5.Text = "行使結果(Put)"
        '
        'cbExercResultCall
        '
        Me.cbExercResultCall.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercResultCall.FormattingEnabled = True
        Me.cbExercResultCall.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercResultCall.Location = New System.Drawing.Point(462, 294)
        Me.cbExercResultCall.Name = "cbExercResultCall"
        Me.cbExercResultCall.Size = New System.Drawing.Size(131, 20)
        Me.cbExercResultCall.TabIndex = 33
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(330, 301)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(81, 12)
        Me.Label13.TabIndex = 107
        Me.Label13.Text = "行使結果(Call)"
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(160, 84)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(131, 20)
        Me.cbEnabled.TabIndex = 110
        '
        'tbExercPriceSetting
        '
        Me.tbExercPriceSetting.Location = New System.Drawing.Point(462, 56)
        Me.tbExercPriceSetting.MaxLength = 32
        Me.tbExercPriceSetting.Name = "tbExercPriceSetting"
        Me.tbExercPriceSetting.Size = New System.Drawing.Size(131, 19)
        Me.tbExercPriceSetting.TabIndex = 0
        Me.tbExercPriceSetting.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpExercRateTime
        '
        Me.dtpExercRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpExercRateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercRateTime.Location = New System.Drawing.Point(148, 355)
        Me.dtpExercRateTime.Name = "dtpExercRateTime"
        Me.dtpExercRateTime.Size = New System.Drawing.Size(142, 19)
        Me.dtpExercRateTime.TabIndex = 31
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(31, 360)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(92, 12)
        Me.Label17.TabIndex = 138
        Me.Label17.Text = "行使時レート時刻"
        '
        'lblEnabled
        '
        Me.lblEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblEnabled.Location = New System.Drawing.Point(159, 84)
        Me.lblEnabled.Name = "lblEnabled"
        Me.lblEnabled.Size = New System.Drawing.Size(131, 23)
        Me.lblEnabled.TabIndex = 140
        Me.lblEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(31, 192)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(137, 12)
        Me.Label20.TabIndex = 141
        Me.Label20.Text = "購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(330, 164)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(77, 12)
        Me.Label22.TabIndex = 143
        Me.Label22.Text = "最高購入価格"
        '
        'tbAskBidSpreadMinCall
        '
        Me.tbAskBidSpreadMinCall.Location = New System.Drawing.Point(230, 189)
        Me.tbAskBidSpreadMinCall.Name = "tbAskBidSpreadMinCall"
        Me.tbAskBidSpreadMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskBidSpreadMinCall.TabIndex = 17
        Me.tbAskBidSpreadMinCall.Text = "0"
        Me.tbAskBidSpreadMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMaxCall
        '
        Me.tbAskPriceMaxCall.Location = New System.Drawing.Point(462, 161)
        Me.tbAskPriceMaxCall.Name = "tbAskPriceMaxCall"
        Me.tbAskPriceMaxCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskPriceMaxCall.TabIndex = 21
        Me.tbAskPriceMaxCall.Text = "1000"
        Me.tbAskPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMinCall
        '
        Me.tbBidPriceMinCall.Location = New System.Drawing.Point(462, 243)
        Me.tbBidPriceMinCall.Name = "tbBidPriceMinCall"
        Me.tbBidPriceMinCall.ReadOnly = True
        Me.tbBidPriceMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbBidPriceMinCall.TabIndex = 27
        Me.tbBidPriceMinCall.Text = "0"
        Me.tbBidPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(330, 246)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(77, 12)
        Me.Label24.TabIndex = 152
        Me.Label24.Text = "最低清算価格"
        '
        'ProductSubForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(634, 462)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.tbBidPriceMinCall)
        Me.Controls.Add(Me.tbAskPriceMaxCall)
        Me.Controls.Add(Me.tbAskBidSpreadMinCall)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.lblEnabled)
        Me.Controls.Add(Me.dtpExercRateTime)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.tbExercPriceSetting)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.cbExercResultCall)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.cbExercResultPut)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbExercRate)
        Me.Controls.Add(Me.tbExercRateSeq)
        Me.Controls.Add(Me.cbExercStatus)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.tbAskPriceMinCall)
        Me.Controls.Add(Me.tbBidPriceMaxCall)
        Me.Controls.Add(Me.tbVolRatio1Call)
        Me.Controls.Add(Me.lblProductDetail)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbExercPrice)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.cbProductSubStatus)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.btnDisabled)
        Me.Controls.Add(Me.btnEnabled)
        Me.Controls.Add(Me.lblProductCode)
        Me.Controls.Add(Me.lblProductSubCode)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "ProductSubForm"
        Me.Text = "銘柄詳細編集"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDisabled As System.Windows.Forms.Button
    Friend WithEvents btnEnabled As System.Windows.Forms.Button
    Friend WithEvents lblProductCode As System.Windows.Forms.Label
    Friend WithEvents lblProductSubCode As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbProductSubStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents tbExercPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents lblProductDetail As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio1Call As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMinCall As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents tbExercRate As System.Windows.Forms.TextBox
    Friend WithEvents tbExercRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents cbExercStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbExercResultPut As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cbExercResultCall As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents tbExercPriceSetting As System.Windows.Forms.TextBox
    Friend WithEvents dtpExercRateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblEnabled As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents tbAskBidSpreadMinCall As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMinCall As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
End Class
