﻿Public Class RateMonitor

    Private WithEvents serviceRateFilter As RateFilterService
    Private WithEvents serviceRateFilterStatus As RateFilterStatusService
    Private WithEvents serviceDDD As DDDService

    Private Table As New DataTable
    Private view As New DataView

    Private Sub RateMonitor_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        miEdit.Text = IIf(editable, "編集", "参照")

        MainWindow.SubFormRateMonitor = True
        grid.AutoGenerateColumns = False
        LoadSettings()

        initGrid()
        setGrid()

        serviceDDD = New DDDService
        serviceRateFilter = New RateFilterService
        serviceRateFilterStatus = New RateFilterStatusService
    End Sub

    Private Sub RateMonitor_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceDDD = Nothing
        serviceRateFilter = Nothing
        serviceRateFilterStatus = Nothing

        SaveSettings()
        MainWindow.SubFormRateMonitor = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RateMonitor_FormMaximized, _
            UserSettings.getInstance().DataSaved.RateMonitor_FormSize, _
            UserSettings.getInstance().DataSaved.RateMonitor_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RateMonitorList_Columns)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        clsUtil.SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RateMonitor_FormMaximized, _
            UserSettings.getInstance().DataSaved.RateMonitor_FormSize, _
            UserSettings.getInstance().DataSaved.RateMonitor_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RateMonitorList_Columns)

    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        grid.Columns(RateFilterDiff.Name).HeaderText = "レートフィルター" & vbCrLf & "乖離値"
        grid.Columns(RateFilterCountMax.Name).HeaderText = "レートフィルター" & vbCrLf & "カウント閾値"
        grid.Columns(AnomalyRateDiff.Name).HeaderText = "異常レート" & vbCrLf & "乖離値"
        grid.Columns(RateFilterCounter.Name).HeaderText = "レートフィルター" & vbCrLf & "カウンター"
        grid.Columns(LastFilteringRate.Name).HeaderText = "最終" & vbCrLf & "フィルターレート"
        grid.Columns(LastAnomalyRate.Name).HeaderText = "最終" & vbCrLf & "異常レート"

        Table = New DataTable
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("RateTime", GetType(DateTime))
        Table.Columns.Add("Rate", GetType(Decimal))
        Table.Columns.Add("RateArrowCount", GetType(Integer))
        Table.Columns.Add("RateFilterDiff", GetType(String))
        Table.Columns.Add("RateFilterCountMax", GetType(Integer))
        Table.Columns.Add("AnomalyRateDiff", GetType(Decimal))
        Table.Columns.Add("Status", GetType(String))
        Table.Columns.Add("RateFilterCounter", GetType(Integer))
        Table.Columns.Add("LastFilteringTime", GetType(DateTime))
        Table.Columns.Add("LastFilteringRate", GetType(Decimal))
        Table.Columns.Add("LastAnomalyTime", GetType(DateTime))
        Table.Columns.Add("LastAnomalyRate", GetType(Decimal))

        view = New DataView(Table)
        grid.DataSource = view

    End Sub

    Private Sub setGrid()
        Dim list As List(Of CurrencyPairData) = CurrencyPairService.GetList()
        For Each item As CurrencyPairData In list
            Dim itemRate As RateTickData = DDDService.GetLastRate(item.ComCode)
            Dim itemRateFilter As RateFilterData = RateFilterService.GetData(item.ComCode)
            Dim itemRateFilterStatus As RateFilterStatusData = RateFilterStatusService.GetData(item.ComCode)
            Dim row As DataRow = Table.NewRow()
            Dim intRateFilterDiff As Integer
            Dim intAnomalyRateDiff As Integer

            '現在レート
            row("ComCode") = item.ComCode
            row("ComName") = item.ComName
            row("RateTime") = itemRate.RateTime
            row("Rate") = itemRate.Rate
            row("RateArrowCount") = itemRate.RateArrowCount
            'レートフィルター設定
            intRateFilterDiff = (itemRateFilter.RateFilterDiff) * Math.Pow(10, item.DecimalPlaces)
            row("RateFilterDiff") = intRateFilterDiff
            row("RateFilterCountMax") = itemRateFilter.RateFilterCountMax
            intAnomalyRateDiff = (itemRateFilter.AnomalyRateDiff) * Math.Pow(10, item.DecimalPlaces)
            row("AnomalyRateDiff") = intAnomalyRateDiff
            'レートフィルターステータス
            row("Status") = RateFilterStatusManager.GetStatusName(itemRateFilterStatus.Status)
            row("RateFilterCounter") = itemRateFilterStatus.RateFilterCounter
            row("LastFilteringTime") = IIf(itemRateFilterStatus.LastFilteringTimeEnabled, itemRateFilterStatus.LastFilteringTime, DBNull.Value)
            row("LastFilteringRate") = IIf(itemRateFilterStatus.LastFilteringRateEnabled, itemRateFilterStatus.LastFilteringRate, DBNull.Value)
            row("LastAnomalyTime") = IIf(itemRateFilterStatus.LastAnomalyTimeEnabled, itemRateFilterStatus.LastAnomalyTime, DBNull.Value)
            row("LastAnomalyRate") = IIf(itemRateFilterStatus.LastAnomalyRateEnabled, itemRateFilterStatus.LastAnomalyRate, DBNull.Value)

            Table.Rows.Add(row)
        Next
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("ComCode").Value
        edit(code)
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("ComCode").Value
        edit(code)
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormRateFilterForm Then
            RateFilterForm.Close()
        End If
        RateFilterForm.MdiParent = MainWindow
        RateFilterForm.Code = code
        RateFilterForm.Show()
    End Sub

    Private Sub serviceDDD_NewDDD() Handles serviceDDD.NewDDD
        '現在レートのリアルタイム更新処理
        For Each row As DataRow In Table.Rows
            Dim item = DDDService.GetLastRate(row("ComCode"))
            row("Rate") = item.Rate
            row("RateTime") = item.RateTime
            row("RateArrowCount") = item.RateArrowCount
        Next
    End Sub

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).DataPropertyName
                Case "Rate", "LastFilteringRate", "LastAnomalyRate"
                    Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComCode").Value
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grid.CellPainting
        If e.RowIndex >= 0 Then
            If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                If grid.Columns(e.ColumnIndex).Name = "Rate" Then
                    Dim ArrowCount As Integer = grid.Rows(e.RowIndex).Cells("RateArrowCount").Value
                    If ArrowCount <> 0 Then
                        e.Paint(e.CellBounds, e.PaintParts)
                        Dim ArrowChar As String
                        Dim ArrowColor As Color
                        If ArrowCount > 0 Then
                            ArrowChar = "▲"
                            ArrowColor = Color.Red
                        Else
                            ArrowChar = "▼"
                            ArrowColor = Color.Blue
                        End If
                        e.Paint(e.CellBounds, e.PaintParts)
                        TextRenderer.DrawText(e.Graphics, ArrowChar, e.CellStyle.Font, e.CellBounds, ArrowColor, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub serviceRateFilterStatus_DataChanged() Handles serviceRateFilterStatus.DataChanged
        For Each row As DataRow In Table.Rows
            Dim item As RateFilterStatusData = RateFilterStatusService.GetData(row("ComCode"))

            'レートフィルターステータスのリアルタイム更新処理
            row("Status") = RateFilterStatusManager.GetStatusName(item.Status)
            row("RateFilterCounter") = item.RateFilterCounter
            row("LastFilteringTime") = IIf(item.LastFilteringTimeEnabled, item.LastFilteringTime, DBNull.Value)
            row("LastFilteringRate") = IIf(item.LastFilteringRateEnabled, item.LastFilteringRate, DBNull.Value)
            row("LastAnomalyTime") = IIf(item.LastAnomalyTimeEnabled, item.LastAnomalyTime, DBNull.Value)
            row("LastAnomalyRate") = IIf(item.LastAnomalyRateEnabled, item.LastAnomalyRate, DBNull.Value)
        Next
    End Sub

    Private Sub serviceRateFilter_DataChanged() Handles serviceRateFilter.DataChanged
        For Each row As DataRow In Table.Rows
            Dim item As RateFilterData = RateFilterService.GetData(row("ComCode"))
            Dim ComItem As CurrencyPairData = CurrencyPairService.GetData(row("ComCode"))
            Dim intRateFilterDiff As Integer
            Dim intAnomalyRateDiff As Integer

            'レートフィルター設定のリアルタイム更新処理
            intRateFilterDiff = (item.RateFilterDiff) * Math.Pow(10, ComItem.DecimalPlaces)
            row("RateFilterDiff") = intRateFilterDiff
            row("RateFilterCountMax") = item.RateFilterCountMax
            intAnomalyRateDiff = (item.AnomalyRateDiff) * Math.Pow(10, ComItem.DecimalPlaces)
            row("AnomalyRateDiff") = intAnomalyRateDiff
        Next
    End Sub

End Class