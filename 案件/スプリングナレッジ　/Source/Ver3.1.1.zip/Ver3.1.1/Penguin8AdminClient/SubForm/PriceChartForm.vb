﻿Public Class PriceChartForm

    Public Code As String

    Private WithEvents service As New PriceChartHistService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub RateChartForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbChartType.DisplayMember = "ChartTypeName"
        cbChartType.ValueMember = "ChartType"
        cbChartType.DataSource = ChartTypeService.GetList()

        MainWindow.SubFormPremiumChartForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblPriceChartCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub PremiumChartForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormPremiumChartForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "プライスチャート登録"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "プライスチャート編集"
            Else
                Me.Text = "プライスチャート参照"
            End If
        End If
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of PriceChartHistData), existNextFlag As Boolean) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "プライスチャートデータの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).PriceChartSeq <> Code Then
            MessageBox.Show(Me, "プライスチャートデータの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If UserTypeManager.IsEdit(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbComCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbChartType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbProductCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbProductSubCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpCloseTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpChartTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbChartTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOpenAskPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbHighAskPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbLowAskPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseAskPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOpenAskPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbHighAskPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbLowAskPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseAskPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOpenBidPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbHighBidPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbLowBidPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseBidPriceCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOpenBidPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbHighBidPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbLowBidPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseBidPricePut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        Me.cbComCode.SelectedValue = ""
        Me.dtpCloseTime.Value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbCloseTimeMilliseconds.Text = ""
        Me.dtpChartTime.Value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbChartTimeMilliseconds.Text = ""
        Me.tbOpenAskPriceCall.Text = ""
        Me.tbHighAskPriceCall.Text = ""
        Me.tbLowAskPriceCall.Text = ""
        Me.tbCloseAskPriceCall.Text = ""
        Me.tbOpenAskPricePut.Text = ""
        Me.tbHighAskPricePut.Text = ""
        Me.tbLowAskPricePut.Text = ""
        Me.tbCloseAskPricePut.Text = ""
        Me.tbOpenBidPriceCall.Text = ""
        Me.tbHighBidPriceCall.Text = ""
        Me.tbLowBidPriceCall.Text = ""
        Me.tbCloseBidPriceCall.Text = ""
        Me.tbOpenBidPricePut.Text = ""
        Me.tbHighBidPricePut.Text = ""
        Me.tbLowBidPricePut.Text = ""
        Me.tbCloseBidPricePut.Text = ""
        Me.cbEnabled.SelectedValue = ""
        Me.cbChartType.SelectedValue = ""
        Me.lblRateCode.Text = ""
        Me.lblPriceChartCode.Text = ""
        Me.tbProductCode.Text = ""
        Me.tbProductSubCode.Text = ""
    End Sub

    Private Sub initEdit()
        Me.cbComCode.SelectedValue = ""
        Me.dtpCloseTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        Me.dtpChartTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        Me.tbCloseTimeMilliseconds.Text = ""
        Me.tbChartTimeMilliseconds.Text = ""
        Me.tbOpenAskPriceCall.Text = ""
        Me.tbHighAskPriceCall.Text = ""
        Me.tbLowAskPriceCall.Text = ""
        Me.tbCloseAskPriceCall.Text = ""
        Me.tbOpenAskPricePut.Text = ""
        Me.tbHighAskPricePut.Text = ""
        Me.tbLowAskPricePut.Text = ""
        Me.tbCloseAskPricePut.Text = ""
        Me.tbOpenBidPriceCall.Text = ""
        Me.tbHighBidPriceCall.Text = ""
        Me.tbLowBidPriceCall.Text = ""
        Me.tbCloseBidPriceCall.Text = ""
        Me.tbOpenBidPricePut.Text = ""
        Me.tbHighBidPricePut.Text = ""
        Me.tbLowBidPricePut.Text = ""
        Me.tbCloseBidPricePut.Text = ""
        Me.cbEnabled.SelectedValue = ""
        Me.cbChartType.SelectedValue = ""
        Me.lblRateCode.Text = ""
        Me.tbProductCode.Text = ""
        Me.tbProductSubCode.Text = ""

        service.Read(Code)
    End Sub

    Private Function checkInput() As Boolean
        If cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If cbChartType.SelectedValue = "" Then
            MessageBox.Show(Me, "チャート種別を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbChartTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "チャート日時には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbCloseTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "レート日時には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbOpenAskPriceCall.Text = "" Then
            MessageBox.Show(Me, "Openには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbHighAskPriceCall.Text = "" Then
            MessageBox.Show(Me, "Highには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbLowAskPriceCall.Text = "" Then
            MessageBox.Show(Me, "Lowには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbCloseAskPriceCall.Text = "" Then
            MessageBox.Show(Me, "Closeには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbProductCode.Text = "" Then
            MessageBox.Show(Me, "銘柄コードには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbProductSubCode.Text = "" Then
            MessageBox.Show(Me, "銘柄サブコードには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub setControlFromData(data As PriceChartHistData)

        Me.lblPriceChartCode.Text = data.PriceChartSeq
        Me.cbEnabled.SelectedValue = data.Enabled
        Me.cbComCode.SelectedValue = data.ComCode
        Me.tbProductCode.Text = data.ProductCode
        Me.tbProductSubCode.Text = data.ProductSubCode
        Me.cbChartType.SelectedValue = data.ChartType
        Me.dtpChartTime.Value = data.PriceChartTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbChartTimeMilliseconds.Text = data.PriceChartTime.ToString("fff")
        Me.tbOpenAskPriceCall.Text = data.OpenAskPriceCall.ToString("######0.########")
        Me.tbHighAskPriceCall.Text = data.HighAskPriceCall.ToString("######0.########")
        Me.tbLowAskPriceCall.Text = data.LowAskPriceCall.ToString("######0.########")
        Me.tbCloseAskPriceCall.Text = data.CloseAskPriceCall.ToString("######0.########")
        Me.tbOpenAskPricePut.Text = data.OpenAskPricePut.ToString("######0.########")
        Me.tbHighAskPricePut.Text = data.HighAskPricePut.ToString("######0.########")
        Me.tbLowAskPricePut.Text = data.LowAskPricePut.ToString("######0.########")
        Me.tbCloseAskPricePut.Text = data.CloseAskPricePut.ToString("######0.########")
        Me.tbOpenBidPriceCall.Text = data.OpenBidPriceCall.ToString("######0.########")
        Me.tbHighBidPriceCall.Text = data.HighBidPriceCall.ToString("######0.########")
        Me.tbLowBidPriceCall.Text = data.LowBidPriceCall.ToString("######0.########")
        Me.tbCloseBidPriceCall.Text = data.CloseBidPriceCall.ToString("######0.########")
        Me.tbOpenBidPricePut.Text = data.OpenBidPricePut.ToString("######0.########")
        Me.tbHighBidPricePut.Text = data.HighBidPricePut.ToString("######0.########")
        Me.tbLowBidPricePut.Text = data.LowBidPricePut.ToString("######0.########")
        Me.tbCloseBidPricePut.Text = data.CloseBidPricePut.ToString("######0.########")
        Me.lblRateCode.Text = data.RateSeq
        Me.dtpCloseTime.Value = data.CloseTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbCloseTimeMilliseconds.Text = data.CloseTime.ToString("fff")

    End Sub

    Private Function getDataFromControl() As PriceChartHistData
        Dim ret As New PriceChartHistData

        ret.PriceChartSeq = Me.lblPriceChartCode.Text
        ret.ComCode = Me.cbComCode.SelectedValue
        ret.Enabled = Me.cbEnabled.SelectedValue
        ret.ChartType = Me.cbChartType.SelectedValue
        ret.ProductCode = Me.tbProductCode.Text
        ret.ProductSubCode = Me.tbProductSubCode.Text
        ret.PriceChartTime = dtpChartTime.Value
        ret.RateSeq = Me.lblRateCode.Text
        If tbChartTimeMilliseconds.Text <> "" Then
            ret.PriceChartTime = ret.PriceChartTime.AddMilliseconds(Integer.Parse(tbChartTimeMilliseconds.Text))
        End If
        ret.CloseTime = dtpCloseTime.Value
        If tbCloseTimeMilliseconds.Text <> "" Then
            ret.CloseTime = ret.CloseTime.AddMilliseconds(Integer.Parse(tbCloseTimeMilliseconds.Text))
        End If
        ret.OpenAskPriceCall = Decimal.Parse(Me.tbOpenAskPriceCall.Text)
        ret.HighAskPriceCall = Decimal.Parse(Me.tbHighAskPriceCall.Text)
        ret.LowAskPriceCall = Decimal.Parse(Me.tbLowAskPriceCall.Text)
        ret.CloseAskPriceCall = Decimal.Parse(Me.tbCloseAskPriceCall.Text)
        ret.OpenAskPricePut = Decimal.Parse(Me.tbOpenAskPricePut.Text)
        ret.HighAskPricePut = Decimal.Parse(Me.tbHighAskPricePut.Text)
        ret.LowAskPricePut = Decimal.Parse(Me.tbLowAskPricePut.Text)
        ret.CloseAskPricePut = Decimal.Parse(Me.tbCloseAskPricePut.Text)
        ret.OpenBidPriceCall = Decimal.Parse(Me.tbOpenBidPriceCall.Text)
        ret.HighBidPriceCall = Decimal.Parse(Me.tbHighBidPriceCall.Text)
        ret.LowBidPriceCall = Decimal.Parse(Me.tbLowBidPriceCall.Text)
        ret.CloseBidPriceCall = Decimal.Parse(Me.tbCloseBidPriceCall.Text)
        ret.OpenBidPricePut = Decimal.Parse(Me.tbOpenBidPricePut.Text)
        ret.HighBidPricePut = Decimal.Parse(Me.tbHighBidPricePut.Text)
        ret.LowBidPricePut = Decimal.Parse(Me.tbLowBidPricePut.Text)
        ret.CloseBidPricePut = Decimal.Parse(Me.tbCloseBidPricePut.Text)

        Return ret
    End Function

    Private Sub registData()
        Dim data As PriceChartHistData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As PriceChartHistData = getDataFromControl()

        service.Update(data)
    End Sub

End Class