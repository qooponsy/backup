﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CashForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbTotalMoney = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.dtpSysDate = New System.Windows.Forms.DateTimePicker()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.cbCashType = New System.Windows.Forms.ComboBox()
        Me.tbMoney = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.dtpExecTime = New System.Windows.Forms.DateTimePicker()
        Me.tbExecTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tbTradeSeq = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 222)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 12)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "取引後残高"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(30, 148)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 12)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "取引日"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 171)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 12)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "取引種別"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 12)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "有効フラグ"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 197)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "金額"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "処理時間"
        '
        'tbTotalMoney
        '
        Me.tbTotalMoney.Location = New System.Drawing.Point(159, 219)
        Me.tbTotalMoney.Name = "tbTotalMoney"
        Me.tbTotalMoney.Size = New System.Drawing.Size(160, 19)
        Me.tbTotalMoney.TabIndex = 15
        Me.tbTotalMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "処理Seq"
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(159, 65)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(160, 20)
        Me.cbEnabled.TabIndex = 3
        '
        'dtpSysDate
        '
        Me.dtpSysDate.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDate.Location = New System.Drawing.Point(159, 143)
        Me.dtpSysDate.Name = "dtpSysDate"
        Me.dtpSysDate.Size = New System.Drawing.Size(160, 19)
        Me.dtpSysDate.TabIndex = 9
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(159, 14)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(160, 23)
        Me.lblCode.TabIndex = 1
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cbCashType
        '
        Me.cbCashType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCashType.FormattingEnabled = True
        Me.cbCashType.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbCashType.Location = New System.Drawing.Point(159, 168)
        Me.cbCashType.Name = "cbCashType"
        Me.cbCashType.Size = New System.Drawing.Size(160, 20)
        Me.cbCashType.TabIndex = 11
        '
        'tbMoney
        '
        Me.tbMoney.Location = New System.Drawing.Point(159, 194)
        Me.tbMoney.Name = "tbMoney"
        Me.tbMoney.Size = New System.Drawing.Size(160, 19)
        Me.tbMoney.TabIndex = 13
        Me.tbMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(200, 273)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 19
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(47, 273)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 18
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 246)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 12)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "委託者コード"
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(159, 243)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(160, 19)
        Me.tbCustCode.TabIndex = 17
        '
        'dtpExecTime
        '
        Me.dtpExecTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpExecTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExecTime.Location = New System.Drawing.Point(159, 91)
        Me.dtpExecTime.Name = "dtpExecTime"
        Me.dtpExecTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpExecTime.TabIndex = 5
        '
        'tbExecTimeMilliseconds
        '
        Me.tbExecTimeMilliseconds.Location = New System.Drawing.Point(249, 117)
        Me.tbExecTimeMilliseconds.Name = "tbExecTimeMilliseconds"
        Me.tbExecTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbExecTimeMilliseconds.TabIndex = 6
        Me.tbExecTimeMilliseconds.Text = "999"
        Me.tbExecTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(288, 120)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 12)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "ミリ秒"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(30, 43)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 12)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "取引Seq"
        '
        'tbTradeSeq
        '
        Me.tbTradeSeq.Location = New System.Drawing.Point(159, 40)
        Me.tbTradeSeq.Name = "tbTradeSeq"
        Me.tbTradeSeq.Size = New System.Drawing.Size(160, 19)
        Me.tbTradeSeq.TabIndex = 21
        '
        'CashForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(355, 318)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.tbTradeSeq)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tbExecTimeMilliseconds)
        Me.Controls.Add(Me.dtpExecTime)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbCustCode)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbTotalMoney)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.dtpSysDate)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.cbCashType)
        Me.Controls.Add(Me.tbMoney)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "CashForm"
        Me.Text = "入出金データ登録"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbTotalMoney As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents dtpSysDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents cbCashType As System.Windows.Forms.ComboBox
    Friend WithEvents tbMoney As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbCustCode As System.Windows.Forms.TextBox
    Friend WithEvents dtpExecTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbExecTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tbTradeSeq As System.Windows.Forms.TextBox
End Class
