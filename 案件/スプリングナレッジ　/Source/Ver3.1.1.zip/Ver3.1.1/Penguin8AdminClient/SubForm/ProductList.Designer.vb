﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle38 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle36 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle37 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnPricingCSV = New System.Windows.Forms.Button()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.lblTotalPremium = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.lblTotalPAndL = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbExercState = New System.Windows.Forms.ComboBox()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.miProductSubList = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ResidualTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateArrowCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeLimitTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercStatusCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPriceStatusCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPriceStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductBaseCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Premium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VolatilityRatio1Call = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskFeePriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskBidSpreadMinCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BidFeeRateCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskPriceMaxCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskPriceMinCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BidPriceMaxCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BidPriceMinCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VolatilityRatio1Put = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskFeePricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskBidSpreadMinPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BidFeeRatePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskPriceMaxPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AskPriceMinPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BidPriceMaxPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BidPriceMinPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.Panel1.SuspendLayout()
        Me.cmGrid.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(603, 28)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 7
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "～"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnPricingCSV)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.lblTotalPremium)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.lblTotalPAndL)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.cbExercState)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(950, 62)
        Me.Panel1.TabIndex = 8
        '
        'btnPricingCSV
        '
        Me.btnPricingCSV.Location = New System.Drawing.Point(870, 28)
        Me.btnPricingCSV.Name = "btnPricingCSV"
        Me.btnPricingCSV.Size = New System.Drawing.Size(169, 29)
        Me.btnPricingCSV.TabIndex = 16
        Me.btnPricingCSV.Text = "プライシングパラメータCSV出力"
        Me.btnPricingCSV.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(781, 28)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 15
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'lblTotalPremium
        '
        Me.lblTotalPremium.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalPremium.Location = New System.Drawing.Point(478, 5)
        Me.lblTotalPremium.Name = "lblTotalPremium"
        Me.lblTotalPremium.Size = New System.Drawing.Size(109, 23)
        Me.lblTotalPremium.TabIndex = 11
        Me.lblTotalPremium.Text = "0"
        Me.lblTotalPremium.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(394, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 12)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "取引金額合計"
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 6)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'lblTotalPAndL
        '
        Me.lblTotalPAndL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalPAndL.Location = New System.Drawing.Point(478, 33)
        Me.lblTotalPAndL.Name = "lblTotalPAndL"
        Me.lblTotalPAndL.Size = New System.Drawing.Size(109, 23)
        Me.lblTotalPAndL.TabIndex = 9
        Me.lblTotalPAndL.Text = "0"
        Me.lblTotalPAndL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(394, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "損益合計"
        '
        'cbExercState
        '
        Me.cbExercState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercState.FormattingEnabled = True
        Me.cbExercState.Location = New System.Drawing.Point(265, 6)
        Me.cbExercState.Name = "cbExercState"
        Me.cbExercState.Size = New System.Drawing.Size(121, 20)
        Me.cbExercState.TabIndex = 2
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 36)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 6
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 36)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 4
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(692, 28)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 8
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(606, 7)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 3
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(138, 6)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 1
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit, Me.miProductSubList})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(149, 48)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(148, 22)
        Me.miEdit.Text = "編集"
        '
        'miProductSubList
        '
        Me.miProductSubList.Name = "miProductSubList"
        Me.miProductSubList.Size = New System.Drawing.Size(148, 22)
        Me.miProductSubList.Text = "銘柄詳細一覧"
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 408)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(950, 32)
        Me.pnlSearchAdd.TabIndex = 11
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 10
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ComCode, Me.ComName, Me.ExercTime, Me.ResidualTime, Me.PayoutRate, Me.Rate, Me.RateArrowCount, Me.ProductCode, Me.OpType, Me.SysDate, Me.StartTime, Me.TradeLimitTime, Me.ProductEnabled, Me.ExercStatusCode, Me.ExercStatus, Me.ExercPriceStatusCode, Me.ExercPriceStatus, Me.ProductBaseCode, Me.ExercRateSeq, Me.ExercRate, Me.Premium, Me.PAndL, Me.VolatilityRatio1Call, Me.AskFeePriceCall, Me.AskBidSpreadMinCall, Me.BidFeeRateCall, Me.AskPriceMaxCall, Me.AskPriceMinCall, Me.BidPriceMaxCall, Me.BidPriceMinCall, Me.VolatilityRatio1Put, Me.AskFeePricePut, Me.AskBidSpreadMinPut, Me.BidFeeRatePut, Me.AskPriceMaxPut, Me.AskPriceMinPut, Me.BidPriceMaxPut, Me.BidPriceMinPut})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 62)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle38.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle38
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(950, 346)
        Me.grid.TabIndex = 9
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.ComCode.HeaderText = "通貨ペア(Code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle3
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComName.Width = 65
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle4
        Me.ExercTime.HeaderText = "行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        Me.ExercTime.Width = 96
        '
        'ResidualTime
        '
        Me.ResidualTime.DataPropertyName = "ResidualTime"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.ResidualTime.DefaultCellStyle = DataGridViewCellStyle5
        Me.ResidualTime.HeaderText = "残存期間"
        Me.ResidualTime.Name = "ResidualTime"
        Me.ResidualTime.ReadOnly = True
        Me.ResidualTime.Width = 96
        '
        'PayoutRate
        '
        Me.PayoutRate.DataPropertyName = "PayoutRate"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.Format = "######0.00######"
        DataGridViewCellStyle6.NullValue = Nothing
        Me.PayoutRate.DefaultCellStyle = DataGridViewCellStyle6
        Me.PayoutRate.HeaderText = "ペイアウト率"
        Me.PayoutRate.Name = "PayoutRate"
        Me.PayoutRate.ReadOnly = True
        Me.PayoutRate.Width = 87
        '
        'Rate
        '
        Me.Rate.DataPropertyName = "Rate"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle7.Format = "######0.000#####"
        DataGridViewCellStyle7.NullValue = Nothing
        DataGridViewCellStyle7.Padding = New System.Windows.Forms.Padding(0, 0, 18, 0)
        Me.Rate.DefaultCellStyle = DataGridViewCellStyle7
        Me.Rate.HeaderText = "レート"
        Me.Rate.Name = "Rate"
        Me.Rate.ReadOnly = True
        Me.Rate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Rate.Width = 80
        '
        'RateArrowCount
        '
        Me.RateArrowCount.DataPropertyName = "RateArrowCount"
        Me.RateArrowCount.HeaderText = "レート矢印カウント"
        Me.RateArrowCount.Name = "RateArrowCount"
        Me.RateArrowCount.ReadOnly = True
        Me.RateArrowCount.Visible = False
        '
        'ProductCode
        '
        Me.ProductCode.DataPropertyName = "ProductCode"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductCode.DefaultCellStyle = DataGridViewCellStyle8
        Me.ProductCode.HeaderText = "銘柄コード"
        Me.ProductCode.Name = "ProductCode"
        Me.ProductCode.ReadOnly = True
        Me.ProductCode.Width = 108
        '
        'OpType
        '
        Me.OpType.DataPropertyName = "OpType"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OpType.DefaultCellStyle = DataGridViewCellStyle9
        Me.OpType.HeaderText = "オプション種別"
        Me.OpType.Name = "OpType"
        Me.OpType.ReadOnly = True
        Me.OpType.Width = 79
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle10
        Me.SysDate.HeaderText = "システム営業日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 72
        '
        'StartTime
        '
        Me.StartTime.DataPropertyName = "StartTime"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle11.NullValue = Nothing
        Me.StartTime.DefaultCellStyle = DataGridViewCellStyle11
        Me.StartTime.HeaderText = "取引開始日"
        Me.StartTime.Name = "StartTime"
        Me.StartTime.ReadOnly = True
        Me.StartTime.Width = 110
        '
        'TradeLimitTime
        '
        Me.TradeLimitTime.DataPropertyName = "TradeLimitTime"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle12.NullValue = Nothing
        Me.TradeLimitTime.DefaultCellStyle = DataGridViewCellStyle12
        Me.TradeLimitTime.HeaderText = "取引可能期日"
        Me.TradeLimitTime.Name = "TradeLimitTime"
        Me.TradeLimitTime.ReadOnly = True
        Me.TradeLimitTime.Width = 110
        '
        'ProductEnabled
        '
        Me.ProductEnabled.DataPropertyName = "ProductEnabled"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductEnabled.DefaultCellStyle = DataGridViewCellStyle13
        Me.ProductEnabled.HeaderText = "有効フラグ"
        Me.ProductEnabled.Name = "ProductEnabled"
        Me.ProductEnabled.ReadOnly = True
        Me.ProductEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ProductEnabled.Width = 60
        '
        'ExercStatusCode
        '
        Me.ExercStatusCode.DataPropertyName = "ExercStatusCode"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercStatusCode.DefaultCellStyle = DataGridViewCellStyle14
        Me.ExercStatusCode.HeaderText = "行使フラグ(Code)"
        Me.ExercStatusCode.Name = "ExercStatusCode"
        Me.ExercStatusCode.ReadOnly = True
        Me.ExercStatusCode.Visible = False
        '
        'ExercStatus
        '
        Me.ExercStatus.DataPropertyName = "ExercStatus"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercStatus.DefaultCellStyle = DataGridViewCellStyle15
        Me.ExercStatus.HeaderText = "行使フラグ"
        Me.ExercStatus.Name = "ExercStatus"
        Me.ExercStatus.ReadOnly = True
        Me.ExercStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ExercStatus.Width = 60
        '
        'ExercPriceStatusCode
        '
        Me.ExercPriceStatusCode.DataPropertyName = "ExercPriceStatusCode"
        Me.ExercPriceStatusCode.HeaderText = "行使価格ステータスコード"
        Me.ExercPriceStatusCode.Name = "ExercPriceStatusCode"
        Me.ExercPriceStatusCode.ReadOnly = True
        Me.ExercPriceStatusCode.Visible = False
        '
        'ExercPriceStatus
        '
        Me.ExercPriceStatus.DataPropertyName = "ExercPriceStatus"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercPriceStatus.DefaultCellStyle = DataGridViewCellStyle16
        Me.ExercPriceStatus.HeaderText = "行使価格" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ステータス"
        Me.ExercPriceStatus.Name = "ExercPriceStatus"
        Me.ExercPriceStatus.ReadOnly = True
        Me.ExercPriceStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'ProductBaseCode
        '
        Me.ProductBaseCode.DataPropertyName = "ProductBaseCode"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseCode.DefaultCellStyle = DataGridViewCellStyle17
        Me.ProductBaseCode.HeaderText = "銘柄設定コード"
        Me.ProductBaseCode.Name = "ProductBaseCode"
        Me.ProductBaseCode.ReadOnly = True
        Me.ProductBaseCode.Width = 108
        '
        'ExercRateSeq
        '
        Me.ExercRateSeq.DataPropertyName = "ExercRateSeq"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercRateSeq.DefaultCellStyle = DataGridViewCellStyle18
        Me.ExercRateSeq.HeaderText = "行使時価格Seq"
        Me.ExercRateSeq.Name = "ExercRateSeq"
        Me.ExercRateSeq.ReadOnly = True
        Me.ExercRateSeq.Width = 109
        '
        'ExercRate
        '
        Me.ExercRate.DataPropertyName = "ExercRate"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle19.Format = "######0.000#####"
        DataGridViewCellStyle19.NullValue = Nothing
        Me.ExercRate.DefaultCellStyle = DataGridViewCellStyle19
        Me.ExercRate.HeaderText = "行使時価格"
        Me.ExercRate.Name = "ExercRate"
        Me.ExercRate.ReadOnly = True
        Me.ExercRate.Width = 90
        '
        'Premium
        '
        Me.Premium.DataPropertyName = "Premium"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle20.Format = "###,###,###,###,##0"
        Me.Premium.DefaultCellStyle = DataGridViewCellStyle20
        Me.Premium.HeaderText = "取引金額"
        Me.Premium.Name = "Premium"
        Me.Premium.ReadOnly = True
        '
        'PAndL
        '
        Me.PAndL.DataPropertyName = "PAndL"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle21.Format = "###,###,###,###,##0"
        DataGridViewCellStyle21.NullValue = Nothing
        Me.PAndL.DefaultCellStyle = DataGridViewCellStyle21
        Me.PAndL.HeaderText = "損益"
        Me.PAndL.Name = "PAndL"
        Me.PAndL.ReadOnly = True
        '
        'VolatilityRatio1Call
        '
        Me.VolatilityRatio1Call.DataPropertyName = "VolatilityRatio1Call"
        DataGridViewCellStyle22.Format = "######0.########"
        Me.VolatilityRatio1Call.DefaultCellStyle = DataGridViewCellStyle22
        Me.VolatilityRatio1Call.HeaderText = "Call_ボラティリティレシオ"
        Me.VolatilityRatio1Call.Name = "VolatilityRatio1Call"
        Me.VolatilityRatio1Call.ReadOnly = True
        Me.VolatilityRatio1Call.Visible = False
        '
        'AskFeePriceCall
        '
        Me.AskFeePriceCall.DataPropertyName = "AskFeePriceCall"
        DataGridViewCellStyle23.Format = "######0.########"
        Me.AskFeePriceCall.DefaultCellStyle = DataGridViewCellStyle23
        Me.AskFeePriceCall.HeaderText = "Call_購入価格リスク"
        Me.AskFeePriceCall.Name = "AskFeePriceCall"
        Me.AskFeePriceCall.ReadOnly = True
        Me.AskFeePriceCall.Visible = False
        '
        'AskBidSpreadMinCall
        '
        Me.AskBidSpreadMinCall.DataPropertyName = "AskBidSpreadMinCall"
        DataGridViewCellStyle24.Format = "######0.########"
        Me.AskBidSpreadMinCall.DefaultCellStyle = DataGridViewCellStyle24
        Me.AskBidSpreadMinCall.HeaderText = "Call_購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        Me.AskBidSpreadMinCall.Name = "AskBidSpreadMinCall"
        Me.AskBidSpreadMinCall.ReadOnly = True
        Me.AskBidSpreadMinCall.Visible = False
        '
        'BidFeeRateCall
        '
        Me.BidFeeRateCall.DataPropertyName = "BidFeeRateCall"
        DataGridViewCellStyle25.Format = "######0.########"
        Me.BidFeeRateCall.DefaultCellStyle = DataGridViewCellStyle25
        Me.BidFeeRateCall.HeaderText = "Call_清算価格リスク(%)"
        Me.BidFeeRateCall.Name = "BidFeeRateCall"
        Me.BidFeeRateCall.ReadOnly = True
        Me.BidFeeRateCall.Visible = False
        '
        'AskPriceMaxCall
        '
        Me.AskPriceMaxCall.DataPropertyName = "AskPriceMaxCall"
        DataGridViewCellStyle26.Format = "######0.########"
        Me.AskPriceMaxCall.DefaultCellStyle = DataGridViewCellStyle26
        Me.AskPriceMaxCall.HeaderText = "Call_最高購入価格"
        Me.AskPriceMaxCall.Name = "AskPriceMaxCall"
        Me.AskPriceMaxCall.ReadOnly = True
        Me.AskPriceMaxCall.Visible = False
        '
        'AskPriceMinCall
        '
        Me.AskPriceMinCall.DataPropertyName = "AskPriceMinCall"
        DataGridViewCellStyle27.Format = "######0.########"
        Me.AskPriceMinCall.DefaultCellStyle = DataGridViewCellStyle27
        Me.AskPriceMinCall.HeaderText = "Call_最低購入価格"
        Me.AskPriceMinCall.Name = "AskPriceMinCall"
        Me.AskPriceMinCall.ReadOnly = True
        Me.AskPriceMinCall.Visible = False
        '
        'BidPriceMaxCall
        '
        Me.BidPriceMaxCall.DataPropertyName = "BidPriceMaxCall"
        DataGridViewCellStyle28.Format = "######0.########"
        Me.BidPriceMaxCall.DefaultCellStyle = DataGridViewCellStyle28
        Me.BidPriceMaxCall.HeaderText = "Call_最高清算価格"
        Me.BidPriceMaxCall.Name = "BidPriceMaxCall"
        Me.BidPriceMaxCall.ReadOnly = True
        Me.BidPriceMaxCall.Visible = False
        '
        'BidPriceMinCall
        '
        Me.BidPriceMinCall.DataPropertyName = "BidPriceMinCall"
        DataGridViewCellStyle29.Format = "######0.########"
        Me.BidPriceMinCall.DefaultCellStyle = DataGridViewCellStyle29
        Me.BidPriceMinCall.HeaderText = "Call_最低清算価格"
        Me.BidPriceMinCall.Name = "BidPriceMinCall"
        Me.BidPriceMinCall.ReadOnly = True
        Me.BidPriceMinCall.Visible = False
        '
        'VolatilityRatio1Put
        '
        Me.VolatilityRatio1Put.DataPropertyName = "VolatilityRatio1Put"
        DataGridViewCellStyle30.Format = "######0.########"
        Me.VolatilityRatio1Put.DefaultCellStyle = DataGridViewCellStyle30
        Me.VolatilityRatio1Put.HeaderText = "Put_ボラティリティレシオ"
        Me.VolatilityRatio1Put.Name = "VolatilityRatio1Put"
        Me.VolatilityRatio1Put.ReadOnly = True
        Me.VolatilityRatio1Put.Visible = False
        '
        'AskFeePricePut
        '
        Me.AskFeePricePut.DataPropertyName = "AskFeePricePut"
        DataGridViewCellStyle31.Format = "######0.########"
        Me.AskFeePricePut.DefaultCellStyle = DataGridViewCellStyle31
        Me.AskFeePricePut.HeaderText = "Put_購入価格リスク"
        Me.AskFeePricePut.Name = "AskFeePricePut"
        Me.AskFeePricePut.ReadOnly = True
        Me.AskFeePricePut.Visible = False
        '
        'AskBidSpreadMinPut
        '
        Me.AskBidSpreadMinPut.DataPropertyName = "AskBidSpreadMinPut"
        DataGridViewCellStyle32.Format = "######0.########"
        Me.AskBidSpreadMinPut.DefaultCellStyle = DataGridViewCellStyle32
        Me.AskBidSpreadMinPut.HeaderText = "Put_購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        Me.AskBidSpreadMinPut.Name = "AskBidSpreadMinPut"
        Me.AskBidSpreadMinPut.ReadOnly = True
        Me.AskBidSpreadMinPut.Visible = False
        '
        'BidFeeRatePut
        '
        Me.BidFeeRatePut.DataPropertyName = "BidFeeRatePut"
        DataGridViewCellStyle33.Format = "######0.########"
        Me.BidFeeRatePut.DefaultCellStyle = DataGridViewCellStyle33
        Me.BidFeeRatePut.HeaderText = "Put_清算価格リスク(%)"
        Me.BidFeeRatePut.Name = "BidFeeRatePut"
        Me.BidFeeRatePut.ReadOnly = True
        Me.BidFeeRatePut.Visible = False
        '
        'AskPriceMaxPut
        '
        Me.AskPriceMaxPut.DataPropertyName = "AskPriceMaxPut"
        DataGridViewCellStyle34.Format = "######0.########"
        Me.AskPriceMaxPut.DefaultCellStyle = DataGridViewCellStyle34
        Me.AskPriceMaxPut.HeaderText = "Put_最高購入価格"
        Me.AskPriceMaxPut.Name = "AskPriceMaxPut"
        Me.AskPriceMaxPut.ReadOnly = True
        Me.AskPriceMaxPut.Visible = False
        '
        'AskPriceMinPut
        '
        Me.AskPriceMinPut.DataPropertyName = "AskPriceMinPut"
        DataGridViewCellStyle35.Format = "######0.########"
        Me.AskPriceMinPut.DefaultCellStyle = DataGridViewCellStyle35
        Me.AskPriceMinPut.HeaderText = "Put_最低購入価格"
        Me.AskPriceMinPut.Name = "AskPriceMinPut"
        Me.AskPriceMinPut.ReadOnly = True
        Me.AskPriceMinPut.Visible = False
        '
        'BidPriceMaxPut
        '
        Me.BidPriceMaxPut.DataPropertyName = "BidPriceMaxPut"
        DataGridViewCellStyle36.Format = "######0.########"
        Me.BidPriceMaxPut.DefaultCellStyle = DataGridViewCellStyle36
        Me.BidPriceMaxPut.HeaderText = "Put_最高清算価格"
        Me.BidPriceMaxPut.Name = "BidPriceMaxPut"
        Me.BidPriceMaxPut.ReadOnly = True
        Me.BidPriceMaxPut.Visible = False
        '
        'BidPriceMinPut
        '
        Me.BidPriceMinPut.DataPropertyName = "BidPriceMinPut"
        DataGridViewCellStyle37.Format = "######0.########"
        Me.BidPriceMinPut.DefaultCellStyle = DataGridViewCellStyle37
        Me.BidPriceMinPut.HeaderText = "Put_最低清算価格"
        Me.BidPriceMinPut.Name = "BidPriceMinPut"
        Me.BidPriceMinPut.ReadOnly = True
        Me.BidPriceMinPut.Visible = False
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(366, 194)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(211, 63)
        Me.lblNoData.TabIndex = 12
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'ProductList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(950, 440)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "ProductList"
        Me.Text = "銘柄一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.cmGrid.ResumeLayout(False)
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents dgvEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents cbExercState As System.Windows.Forms.ComboBox
    Friend WithEvents lblTotalPAndL As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents lblTotalPremium As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents miProductSubList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnPricingCSV As System.Windows.Forms.Button
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ResidualTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PayoutRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateArrowCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OpType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SysDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StartTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeLimitTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercStatusCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercPriceStatusCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercPriceStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductBaseCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercRateSeq As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Premium As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PAndL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VolatilityRatio1Call As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskFeePriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskBidSpreadMinCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BidFeeRateCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskPriceMaxCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskPriceMinCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BidPriceMaxCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BidPriceMinCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VolatilityRatio1Put As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskFeePricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskBidSpreadMinPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BidFeeRatePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskPriceMaxPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AskPriceMinPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BidPriceMaxPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BidPriceMinPut As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
