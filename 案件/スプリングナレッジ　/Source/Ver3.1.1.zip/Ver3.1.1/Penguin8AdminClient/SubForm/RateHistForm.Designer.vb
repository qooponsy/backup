﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateHistForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpExercTime = New System.Windows.Forms.DateTimePicker()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.cbExercFlag = New System.Windows.Forms.ComboBox()
        Me.tbRate = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbRateDispSeq = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dtpStartTime = New System.Windows.Forms.DateTimePicker()
        Me.btnNewViewSeq = New System.Windows.Forms.Button()
        Me.tbRateTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.dtpRateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpRateTimeSource = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tbRateTimeSourceMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dtpExercTime
        '
        Me.dtpExercTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpExercTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercTime.Location = New System.Drawing.Point(159, 249)
        Me.dtpExercTime.Name = "dtpExercTime"
        Me.dtpExercTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpExercTime.TabIndex = 15
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(159, 14)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(160, 23)
        Me.lblCode.TabIndex = 1
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cbExercFlag
        '
        Me.cbExercFlag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercFlag.FormattingEnabled = True
        Me.cbExercFlag.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercFlag.Location = New System.Drawing.Point(159, 223)
        Me.cbExercFlag.Name = "cbExercFlag"
        Me.cbExercFlag.Size = New System.Drawing.Size(160, 20)
        Me.cbExercFlag.TabIndex = 13
        '
        'tbRate
        '
        Me.tbRate.Location = New System.Drawing.Point(159, 172)
        Me.tbRate.Name = "tbRate"
        Me.tbRate.Size = New System.Drawing.Size(160, 19)
        Me.tbRate.TabIndex = 9
        Me.tbRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(200, 340)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 20
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(47, 340)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 19
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(159, 44)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(160, 20)
        Me.cbComCode.TabIndex = 3
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(159, 197)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(160, 20)
        Me.cbEnabled.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "レートSeq"
        '
        'tbRateDispSeq
        '
        Me.tbRateDispSeq.Location = New System.Drawing.Point(159, 274)
        Me.tbRateDispSeq.Name = "tbRateDispSeq"
        Me.tbRateDispSeq.Size = New System.Drawing.Size(160, 19)
        Me.tbRateDispSeq.TabIndex = 17
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "通貨ペア"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "日時"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 175)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 12)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "レート"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 200)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 12)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "有効フラグ"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 226)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 12)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "行使フラグ"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(30, 254)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 12)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "行使期日"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 277)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 12)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "表示採番Seq"
        '
        'dtpStartTime
        '
        Me.dtpStartTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartTime.Location = New System.Drawing.Point(159, 70)
        Me.dtpStartTime.Name = "dtpStartTime"
        Me.dtpStartTime.Size = New System.Drawing.Size(131, 19)
        Me.dtpStartTime.TabIndex = 5
        '
        'btnNewViewSeq
        '
        Me.btnNewViewSeq.Location = New System.Drawing.Point(159, 297)
        Me.btnNewViewSeq.Name = "btnNewViewSeq"
        Me.btnNewViewSeq.Size = New System.Drawing.Size(107, 23)
        Me.btnNewViewSeq.TabIndex = 18
        Me.btnNewViewSeq.Text = "自動採番"
        Me.btnNewViewSeq.UseVisualStyleBackColor = True
        '
        'tbRateTimeMilliseconds
        '
        Me.tbRateTimeMilliseconds.Location = New System.Drawing.Point(249, 94)
        Me.tbRateTimeMilliseconds.Name = "tbRateTimeMilliseconds"
        Me.tbRateTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbRateTimeMilliseconds.TabIndex = 6
        Me.tbRateTimeMilliseconds.Text = "999"
        Me.tbRateTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(288, 97)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 12)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "ミリ秒"
        '
        'dtpRateTime
        '
        Me.dtpRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpRateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpRateTime.Location = New System.Drawing.Point(159, 69)
        Me.dtpRateTime.Name = "dtpRateTime"
        Me.dtpRateTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpRateTime.TabIndex = 5
        '
        'dtpRateTimeSource
        '
        Me.dtpRateTimeSource.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpRateTimeSource.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpRateTimeSource.Location = New System.Drawing.Point(159, 120)
        Me.dtpRateTimeSource.Name = "dtpRateTimeSource"
        Me.dtpRateTimeSource.Size = New System.Drawing.Size(160, 19)
        Me.dtpRateTimeSource.TabIndex = 7
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(288, 148)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 12)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "ミリ秒"
        '
        'tbRateTimeSourceMilliseconds
        '
        Me.tbRateTimeSourceMilliseconds.Location = New System.Drawing.Point(249, 145)
        Me.tbRateTimeSourceMilliseconds.Name = "tbRateTimeSourceMilliseconds"
        Me.tbRateTimeSourceMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbRateTimeSourceMilliseconds.TabIndex = 8
        Me.tbRateTimeSourceMilliseconds.Text = "999"
        Me.tbRateTimeSourceMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(30, 123)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 12)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "日時(ソース)"
        '
        'RateHistForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(355, 390)
        Me.Controls.Add(Me.dtpRateTimeSource)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.tbRateTimeSourceMilliseconds)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.dtpRateTime)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tbRateTimeMilliseconds)
        Me.Controls.Add(Me.btnNewViewSeq)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbRateDispSeq)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.dtpExercTime)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.cbExercFlag)
        Me.Controls.Add(Me.tbRate)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.cbComCode)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "RateHistForm"
        Me.Text = "レート登録"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dtpExercTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents cbExercFlag As System.Windows.Forms.ComboBox
    Friend WithEvents tbRate As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbRateDispSeq As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dtpStartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnNewViewSeq As System.Windows.Forms.Button
    Friend WithEvents tbRateTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents dtpRateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpRateTimeSource As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tbRateTimeSourceMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
