﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustAttrForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblCustCode = New System.Windows.Forms.Label()
        Me.lblDealDisabled = New System.Windows.Forms.Label()
        Me.lblAccountStart = New System.Windows.Forms.Label()
        Me.lblTotalMoney = New System.Windows.Forms.Label()
        Me.lblPAndLMonthly = New System.Windows.Forms.Label()
        Me.txtLossLimit = New System.Windows.Forms.TextBox()
        Me.btnOk = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "委託者コード"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "取引停止"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(37, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "口座開設日時"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(37, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 12)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "残高"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(37, 184)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 12)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "損失限度枠"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(37, 218)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 12)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "当月収益"
        '
        'lblCustCode
        '
        Me.lblCustCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCustCode.Location = New System.Drawing.Point(129, 37)
        Me.lblCustCode.Name = "lblCustCode"
        Me.lblCustCode.Size = New System.Drawing.Size(131, 23)
        Me.lblCustCode.TabIndex = 6
        Me.lblCustCode.Text = "1000050"
        Me.lblCustCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDealDisabled
        '
        Me.lblDealDisabled.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDealDisabled.Location = New System.Drawing.Point(129, 73)
        Me.lblDealDisabled.Name = "lblDealDisabled"
        Me.lblDealDisabled.Size = New System.Drawing.Size(131, 23)
        Me.lblDealDisabled.TabIndex = 7
        Me.lblDealDisabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAccountStart
        '
        Me.lblAccountStart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAccountStart.Location = New System.Drawing.Point(129, 109)
        Me.lblAccountStart.Name = "lblAccountStart"
        Me.lblAccountStart.Size = New System.Drawing.Size(131, 23)
        Me.lblAccountStart.TabIndex = 8
        Me.lblAccountStart.Text = "yyyy/mm/dd hh:dd"
        Me.lblAccountStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalMoney
        '
        Me.lblTotalMoney.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalMoney.Location = New System.Drawing.Point(129, 145)
        Me.lblTotalMoney.Name = "lblTotalMoney"
        Me.lblTotalMoney.Size = New System.Drawing.Size(131, 23)
        Me.lblTotalMoney.TabIndex = 9
        Me.lblTotalMoney.Text = "1,000,000"
        Me.lblTotalMoney.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPAndLMonthly
        '
        Me.lblPAndLMonthly.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPAndLMonthly.Location = New System.Drawing.Point(129, 213)
        Me.lblPAndLMonthly.Name = "lblPAndLMonthly"
        Me.lblPAndLMonthly.Size = New System.Drawing.Size(131, 23)
        Me.lblPAndLMonthly.TabIndex = 10
        Me.lblPAndLMonthly.Text = "1,000,000"
        Me.lblPAndLMonthly.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtLossLimit
        '
        Me.txtLossLimit.Location = New System.Drawing.Point(129, 181)
        Me.txtLossLimit.Name = "txtLossLimit"
        Me.txtLossLimit.Size = New System.Drawing.Size(131, 19)
        Me.txtLossLimit.TabIndex = 11
        Me.txtLossLimit.Text = "1,000,000"
        Me.txtLossLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(50, 258)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(98, 29)
        Me.btnOk.TabIndex = 12
        Me.btnOk.Text = "内容確認"
        Me.btnOk.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(165, 258)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 13
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'CustListForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(300, 312)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.txtLossLimit)
        Me.Controls.Add(Me.lblPAndLMonthly)
        Me.Controls.Add(Me.lblTotalMoney)
        Me.Controls.Add(Me.lblAccountStart)
        Me.Controls.Add(Me.lblDealDisabled)
        Me.Controls.Add(Me.lblCustCode)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "CustListForm"
        Me.Text = "委託者属性編集"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblCustCode As System.Windows.Forms.Label
    Friend WithEvents lblDealDisabled As System.Windows.Forms.Label
    Friend WithEvents lblAccountStart As System.Windows.Forms.Label
    Friend WithEvents lblTotalMoney As System.Windows.Forms.Label
    Friend WithEvents lblPAndLMonthly As System.Windows.Forms.Label
    Friend WithEvents txtLossLimit As System.Windows.Forms.TextBox
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
End Class
