﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbPayoutRate = New System.Windows.Forms.TextBox()
        Me.cbExercStatus = New System.Windows.Forms.ComboBox()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.lblProductBaseCode = New System.Windows.Forms.Label()
        Me.dtpStartTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpExercTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpTradeLimitTime = New System.Windows.Forms.DateTimePicker()
        Me.lblEnabled = New System.Windows.Forms.Label()
        Me.btnDisabled = New System.Windows.Forms.Button()
        Me.btnEnabled = New System.Windows.Forms.Button()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dtpSysDate = New System.Windows.Forms.DateTimePicker()
        Me.tbExercRateSeq = New System.Windows.Forms.TextBox()
        Me.tbExercRate = New System.Windows.Forms.TextBox()
        Me.tbExercPriceRate = New System.Windows.Forms.TextBox()
        Me.tbExercPriceRateSeq = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.btnExercPricePreview = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.cbExercPriceUnitType = New System.Windows.Forms.ComboBox()
        Me.tbExercPriceUnit = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.tbExercPriceTimeSpan = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.tbExceptExercPrice = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.tbExercPriceSettings = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.tbVolRatio1Call = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMinCall = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.cbExercPriceStatus = New System.Windows.Forms.ComboBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.tbBulkSetUnit = New System.Windows.Forms.TextBox()
        Me.nudBulkSetCount = New System.Windows.Forms.NumericUpDown()
        Me.btnBulkSet = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.tbAskBidSpreadMinCall = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMinCall = New System.Windows.Forms.TextBox()
        CType(Me.nudBulkSetCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "銘柄コード"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 144)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "通貨ペア"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 171)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 12)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "オプション種別"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 228)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 12)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "取引開始日"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 254)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "行使期日"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 280)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "取引可能期日"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(159, 141)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(131, 20)
        Me.cbComCode.TabIndex = 7
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Items.AddRange(New Object() {"バイナリ"})
        Me.cbOpType.Location = New System.Drawing.Point(159, 168)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(131, 20)
        Me.cbOpType.TabIndex = 8
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(192, 546)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 54
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(325, 546)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 55
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(30, 303)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 12)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "ペイアウト率"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 88)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 12)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "有効フラグ"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(30, 457)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 12)
        Me.Label9.TabIndex = 83
        Me.Label9.Text = "行使フラグ"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(30, 116)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 12)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "銘柄設定コード"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(338, 484)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(84, 12)
        Me.Label11.TabIndex = 90
        Me.Label11.Text = "行使時価格Seq"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(338, 512)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 12)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "行使時価格"
        '
        'tbPayoutRate
        '
        Me.tbPayoutRate.Location = New System.Drawing.Point(159, 300)
        Me.tbPayoutRate.Name = "tbPayoutRate"
        Me.tbPayoutRate.ReadOnly = True
        Me.tbPayoutRate.Size = New System.Drawing.Size(131, 19)
        Me.tbPayoutRate.TabIndex = 13
        Me.tbPayoutRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbExercStatus
        '
        Me.cbExercStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercStatus.FormattingEnabled = True
        Me.cbExercStatus.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercStatus.Location = New System.Drawing.Point(159, 454)
        Me.cbExercStatus.Name = "cbExercStatus"
        Me.cbExercStatus.Size = New System.Drawing.Size(131, 20)
        Me.cbExercStatus.TabIndex = 49
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(159, 55)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(131, 23)
        Me.lblCode.TabIndex = 1
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblProductBaseCode
        '
        Me.lblProductBaseCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProductBaseCode.Location = New System.Drawing.Point(159, 111)
        Me.lblProductBaseCode.Name = "lblProductBaseCode"
        Me.lblProductBaseCode.Size = New System.Drawing.Size(131, 23)
        Me.lblProductBaseCode.TabIndex = 7
        Me.lblProductBaseCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dtpStartTime
        '
        Me.dtpStartTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartTime.Location = New System.Drawing.Point(159, 223)
        Me.dtpStartTime.Name = "dtpStartTime"
        Me.dtpStartTime.Size = New System.Drawing.Size(131, 19)
        Me.dtpStartTime.TabIndex = 10
        '
        'dtpExercTime
        '
        Me.dtpExercTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpExercTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercTime.Location = New System.Drawing.Point(159, 249)
        Me.dtpExercTime.Name = "dtpExercTime"
        Me.dtpExercTime.Size = New System.Drawing.Size(131, 19)
        Me.dtpExercTime.TabIndex = 11
        '
        'dtpTradeLimitTime
        '
        Me.dtpTradeLimitTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpTradeLimitTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTradeLimitTime.Location = New System.Drawing.Point(159, 275)
        Me.dtpTradeLimitTime.Name = "dtpTradeLimitTime"
        Me.dtpTradeLimitTime.Size = New System.Drawing.Size(131, 19)
        Me.dtpTradeLimitTime.TabIndex = 12
        '
        'lblEnabled
        '
        Me.lblEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblEnabled.Location = New System.Drawing.Point(159, 83)
        Me.lblEnabled.Name = "lblEnabled"
        Me.lblEnabled.Size = New System.Drawing.Size(131, 23)
        Me.lblEnabled.TabIndex = 5
        Me.lblEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnDisabled
        '
        Me.btnDisabled.Location = New System.Drawing.Point(192, 12)
        Me.btnDisabled.Name = "btnDisabled"
        Me.btnDisabled.Size = New System.Drawing.Size(98, 29)
        Me.btnDisabled.TabIndex = 57
        Me.btnDisabled.Text = "銘柄無効化"
        Me.btnDisabled.UseVisualStyleBackColor = True
        '
        'btnEnabled
        '
        Me.btnEnabled.Location = New System.Drawing.Point(88, 12)
        Me.btnEnabled.Name = "btnEnabled"
        Me.btnEnabled.Size = New System.Drawing.Size(98, 29)
        Me.btnEnabled.TabIndex = 56
        Me.btnEnabled.Text = "銘柄有効化"
        Me.btnEnabled.UseVisualStyleBackColor = True
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(159, 84)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(131, 20)
        Me.cbEnabled.TabIndex = 6
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(30, 201)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(79, 12)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "システム営業日"
        '
        'dtpSysDate
        '
        Me.dtpSysDate.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDate.Location = New System.Drawing.Point(159, 198)
        Me.dtpSysDate.Name = "dtpSysDate"
        Me.dtpSysDate.Size = New System.Drawing.Size(131, 19)
        Me.dtpSysDate.TabIndex = 9
        '
        'tbExercRateSeq
        '
        Me.tbExercRateSeq.Location = New System.Drawing.Point(467, 481)
        Me.tbExercRateSeq.MaxLength = 17
        Me.tbExercRateSeq.Name = "tbExercRateSeq"
        Me.tbExercRateSeq.Size = New System.Drawing.Size(131, 19)
        Me.tbExercRateSeq.TabIndex = 52
        '
        'tbExercRate
        '
        Me.tbExercRate.Location = New System.Drawing.Point(467, 509)
        Me.tbExercRate.Name = "tbExercRate"
        Me.tbExercRate.Size = New System.Drawing.Size(131, 19)
        Me.tbExercRate.TabIndex = 53
        Me.tbExercRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbExercPriceRate
        '
        Me.tbExercPriceRate.Location = New System.Drawing.Point(159, 506)
        Me.tbExercPriceRate.Name = "tbExercPriceRate"
        Me.tbExercPriceRate.Size = New System.Drawing.Size(131, 19)
        Me.tbExercPriceRate.TabIndex = 51
        Me.tbExercPriceRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbExercPriceRateSeq
        '
        Me.tbExercPriceRateSeq.Location = New System.Drawing.Point(159, 481)
        Me.tbExercPriceRateSeq.MaxLength = 17
        Me.tbExercPriceRateSeq.Name = "tbExercPriceRateSeq"
        Me.tbExercPriceRateSeq.Size = New System.Drawing.Size(131, 19)
        Me.tbExercPriceRateSeq.TabIndex = 50
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(30, 510)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(116, 12)
        Me.Label20.TabIndex = 88
        Me.Label20.Text = "行使価格決定時レート"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(30, 484)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(108, 12)
        Me.Label21.TabIndex = 85
        Me.Label21.Text = "行使価格決定時Seq"
        '
        'btnExercPricePreview
        '
        Me.btnExercPricePreview.Location = New System.Drawing.Point(453, 268)
        Me.btnExercPricePreview.Name = "btnExercPricePreview"
        Me.btnExercPricePreview.Size = New System.Drawing.Size(147, 23)
        Me.btnExercPricePreview.TabIndex = 22
        Me.btnExercPricePreview.Text = "行使価格プレビュー"
        Me.btnExercPricePreview.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(338, 376)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(77, 12)
        Me.Label15.TabIndex = 73
        Me.Label15.Text = "最低購入価格"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(338, 402)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(77, 12)
        Me.Label19.TabIndex = 77
        Me.Label19.Text = "最高清算価格"
        '
        'cbExercPriceUnitType
        '
        Me.cbExercPriceUnitType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercPriceUnitType.Enabled = False
        Me.cbExercPriceUnitType.FormattingEnabled = True
        Me.cbExercPriceUnitType.Items.AddRange(New Object() {"なし", "切り上げ", "切り捨て"})
        Me.cbExercPriceUnitType.Location = New System.Drawing.Point(468, 44)
        Me.cbExercPriceUnitType.Name = "cbExercPriceUnitType"
        Me.cbExercPriceUnitType.Size = New System.Drawing.Size(78, 20)
        Me.cbExercPriceUnitType.TabIndex = 15
        '
        'tbExercPriceUnit
        '
        Me.tbExercPriceUnit.Location = New System.Drawing.Point(553, 45)
        Me.tbExercPriceUnit.Name = "tbExercPriceUnit"
        Me.tbExercPriceUnit.ReadOnly = True
        Me.tbExercPriceUnit.Size = New System.Drawing.Size(47, 19)
        Me.tbExercPriceUnit.TabIndex = 16
        Me.tbExercPriceUnit.Text = "0.01"
        Me.tbExercPriceUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(338, 48)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(88, 12)
        Me.Label17.TabIndex = 26
        Me.Label17.Text = "行使価格刻み幅"
        '
        'tbExercPriceTimeSpan
        '
        Me.tbExercPriceTimeSpan.Location = New System.Drawing.Point(468, 18)
        Me.tbExercPriceTimeSpan.Name = "tbExercPriceTimeSpan"
        Me.tbExercPriceTimeSpan.Size = New System.Drawing.Size(131, 19)
        Me.tbExercPriceTimeSpan.TabIndex = 14
        Me.tbExercPriceTimeSpan.Text = "300"
        Me.tbExercPriceTimeSpan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(30, 351)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(98, 12)
        Me.Label23.TabIndex = 41
        Me.Label23.Text = "ボラティリティレシオ１"
        '
        'tbExceptExercPrice
        '
        Me.tbExceptExercPrice.Location = New System.Drawing.Point(340, 206)
        Me.tbExceptExercPrice.Multiline = True
        Me.tbExceptExercPrice.Name = "tbExceptExercPrice"
        Me.tbExceptExercPrice.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbExceptExercPrice.Size = New System.Drawing.Size(260, 57)
        Me.tbExceptExercPrice.TabIndex = 21
        Me.tbExceptExercPrice.Text = "95,96,97,98,99,100,101,102,103,104,105"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(338, 192)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(77, 12)
        Me.Label24.TabIndex = 34
        Me.Label24.Text = "除外行使価格"
        '
        'tbExercPriceSettings
        '
        Me.tbExercPriceSettings.Location = New System.Drawing.Point(340, 87)
        Me.tbExercPriceSettings.Multiline = True
        Me.tbExercPriceSettings.Name = "tbExercPriceSettings"
        Me.tbExercPriceSettings.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbExercPriceSettings.Size = New System.Drawing.Size(260, 70)
        Me.tbExercPriceSettings.TabIndex = 17
        Me.tbExercPriceSettings.Text = "+0.01,+0.02,+0.03,+0.04,+0.05" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "-0.01,-0.02,-0.03,-0.04,-0.05"
        Me.tbExercPriceSettings.WordWrap = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(338, 72)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(77, 12)
        Me.Label25.TabIndex = 30
        Me.Label25.Text = "行使価格設定"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(338, 21)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(121, 12)
        Me.Label26.TabIndex = 24
        Me.Label26.Text = "行使価格決定時間(秒)"
        '
        'tbVolRatio1Call
        '
        Me.tbVolRatio1Call.Location = New System.Drawing.Point(230, 348)
        Me.tbVolRatio1Call.Name = "tbVolRatio1Call"
        Me.tbVolRatio1Call.Size = New System.Drawing.Size(60, 19)
        Me.tbVolRatio1Call.TabIndex = 24
        Me.tbVolRatio1Call.Text = "0.5"
        Me.tbVolRatio1Call.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMinCall
        '
        Me.tbAskPriceMinCall.Location = New System.Drawing.Point(453, 373)
        Me.tbAskPriceMinCall.Name = "tbAskPriceMinCall"
        Me.tbAskPriceMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskPriceMinCall.TabIndex = 43
        Me.tbAskPriceMinCall.Text = "40"
        Me.tbAskPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMaxCall
        '
        Me.tbBidPriceMaxCall.Location = New System.Drawing.Point(453, 399)
        Me.tbBidPriceMaxCall.Name = "tbBidPriceMaxCall"
        Me.tbBidPriceMaxCall.ReadOnly = True
        Me.tbBidPriceMaxCall.Size = New System.Drawing.Size(60, 19)
        Me.tbBidPriceMaxCall.TabIndex = 45
        Me.tbBidPriceMaxCall.Text = "960"
        Me.tbBidPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbExercPriceStatus
        '
        Me.cbExercPriceStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercPriceStatus.FormattingEnabled = True
        Me.cbExercPriceStatus.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercPriceStatus.Location = New System.Drawing.Point(453, 298)
        Me.cbExercPriceStatus.Name = "cbExercPriceStatus"
        Me.cbExercPriceStatus.Size = New System.Drawing.Size(147, 20)
        Me.cbExercPriceStatus.TabIndex = 23
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(338, 304)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(98, 12)
        Me.Label31.TabIndex = 37
        Me.Label31.Text = "行使価格ステータス"
        '
        'tbBulkSetUnit
        '
        Me.tbBulkSetUnit.Location = New System.Drawing.Point(417, 161)
        Me.tbBulkSetUnit.Name = "tbBulkSetUnit"
        Me.tbBulkSetUnit.Size = New System.Drawing.Size(62, 19)
        Me.tbBulkSetUnit.TabIndex = 18
        Me.tbBulkSetUnit.TabStop = False
        Me.tbBulkSetUnit.Text = "0.00005"
        Me.tbBulkSetUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudBulkSetCount
        '
        Me.nudBulkSetCount.Location = New System.Drawing.Point(485, 161)
        Me.nudBulkSetCount.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.nudBulkSetCount.Name = "nudBulkSetCount"
        Me.nudBulkSetCount.Size = New System.Drawing.Size(31, 19)
        Me.nudBulkSetCount.TabIndex = 19
        Me.nudBulkSetCount.TabStop = False
        Me.nudBulkSetCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudBulkSetCount.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'btnBulkSet
        '
        Me.btnBulkSet.Location = New System.Drawing.Point(522, 159)
        Me.btnBulkSet.Name = "btnBulkSet"
        Me.btnBulkSet.Size = New System.Drawing.Size(77, 23)
        Me.btnBulkSet.TabIndex = 20
        Me.btnBulkSet.TabStop = False
        Me.btnBulkSet.Text = "一括設定"
        Me.btnBulkSet.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(30, 374)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(137, 12)
        Me.Label33.TabIndex = 63
        Me.Label33.Text = "購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(338, 351)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(77, 12)
        Me.Label34.TabIndex = 70
        Me.Label34.Text = "最高購入価格"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(338, 428)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(77, 12)
        Me.Label35.TabIndex = 80
        Me.Label35.Text = "最低清算価格"
        '
        'tbAskBidSpreadMinCall
        '
        Me.tbAskBidSpreadMinCall.Location = New System.Drawing.Point(230, 377)
        Me.tbAskBidSpreadMinCall.Name = "tbAskBidSpreadMinCall"
        Me.tbAskBidSpreadMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskBidSpreadMinCall.TabIndex = 37
        Me.tbAskBidSpreadMinCall.Text = "0"
        Me.tbAskBidSpreadMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMaxCall
        '
        Me.tbAskPriceMaxCall.Location = New System.Drawing.Point(453, 348)
        Me.tbAskPriceMaxCall.Name = "tbAskPriceMaxCall"
        Me.tbAskPriceMaxCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskPriceMaxCall.TabIndex = 41
        Me.tbAskPriceMaxCall.Text = "1000"
        Me.tbAskPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMinCall
        '
        Me.tbBidPriceMinCall.Location = New System.Drawing.Point(453, 425)
        Me.tbBidPriceMinCall.Name = "tbBidPriceMinCall"
        Me.tbBidPriceMinCall.ReadOnly = True
        Me.tbBidPriceMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbBidPriceMinCall.TabIndex = 47
        Me.tbBidPriceMinCall.Text = "0"
        Me.tbBidPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ProductForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(634, 590)
        Me.Controls.Add(Me.tbBidPriceMinCall)
        Me.Controls.Add(Me.tbAskPriceMaxCall)
        Me.Controls.Add(Me.tbAskBidSpreadMinCall)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.tbBulkSetUnit)
        Me.Controls.Add(Me.nudBulkSetCount)
        Me.Controls.Add(Me.btnBulkSet)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.cbExercPriceStatus)
        Me.Controls.Add(Me.tbAskPriceMinCall)
        Me.Controls.Add(Me.tbBidPriceMaxCall)
        Me.Controls.Add(Me.tbVolRatio1Call)
        Me.Controls.Add(Me.btnExercPricePreview)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.cbExercPriceUnitType)
        Me.Controls.Add(Me.tbExercPriceUnit)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.tbExercPriceTimeSpan)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.tbExceptExercPrice)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.tbExercPriceSettings)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.tbExercPriceRate)
        Me.Controls.Add(Me.tbExercPriceRateSeq)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.tbExercRate)
        Me.Controls.Add(Me.tbExercRateSeq)
        Me.Controls.Add(Me.dtpSysDate)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.btnDisabled)
        Me.Controls.Add(Me.btnEnabled)
        Me.Controls.Add(Me.lblEnabled)
        Me.Controls.Add(Me.dtpTradeLimitTime)
        Me.Controls.Add(Me.dtpExercTime)
        Me.Controls.Add(Me.dtpStartTime)
        Me.Controls.Add(Me.lblProductBaseCode)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.cbExercStatus)
        Me.Controls.Add(Me.tbPayoutRate)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.cbOpType)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "ProductForm"
        Me.Text = "銘柄登録"
        CType(Me.nudBulkSetCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbOpType As System.Windows.Forms.ComboBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbPayoutRate As System.Windows.Forms.TextBox
    Friend WithEvents cbExercStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents lblProductBaseCode As System.Windows.Forms.Label
    Friend WithEvents dtpStartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpExercTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpTradeLimitTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblEnabled As System.Windows.Forms.Label
    Friend WithEvents btnDisabled As System.Windows.Forms.Button
    Friend WithEvents btnEnabled As System.Windows.Forms.Button
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dtpSysDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbExercRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents tbExercRate As System.Windows.Forms.TextBox
    Friend WithEvents tbExercPriceRate As System.Windows.Forms.TextBox
    Friend WithEvents tbExercPriceRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btnExercPricePreview As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents cbExercPriceUnitType As System.Windows.Forms.ComboBox
    Friend WithEvents tbExercPriceUnit As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents tbExercPriceTimeSpan As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents tbExceptExercPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents tbExercPriceSettings As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio1Call As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMinCall As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents cbExercPriceStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents tbBulkSetUnit As System.Windows.Forms.TextBox
    Friend WithEvents nudBulkSetCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnBulkSet As System.Windows.Forms.Button
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents tbAskBidSpreadMinCall As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMinCall As System.Windows.Forms.TextBox
End Class
