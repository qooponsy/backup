﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PriceChartHistList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnCSV = New System.Windows.Forms.Button()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbChartType = New System.Windows.Forms.ComboBox()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSarchAdd = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.PriceChartSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Enabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductSubCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ChartType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PriceChartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpenAskPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HighAskPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LowAskPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseAskPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpenAskPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HighAskPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LowAskPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseAskPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpenBidPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HighBidPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LowBidPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseBidPriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpenBidPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HighBidPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LowBidPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseBidPricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCSV)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Controls.Add(Me.cbChartType)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(902, 58)
        Me.Panel1.TabIndex = 25
        '
        'BtnCSV
        '
        Me.BtnCSV.Location = New System.Drawing.Point(528, 22)
        Me.BtnCSV.Name = "BtnCSV"
        Me.BtnCSV.Size = New System.Drawing.Size(89, 29)
        Me.BtnCSV.TabIndex = 8
        Me.BtnCSV.Text = "CSV"
        Me.BtnCSV.UseVisualStyleBackColor = True
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(439, 22)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 7
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(350, 22)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 6
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 32)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 5
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 32)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "～"
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(361, 8)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 2
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(12, 6)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 0
        '
        'cbChartType
        '
        Me.cbChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbChartType.FormattingEnabled = True
        Me.cbChartType.Location = New System.Drawing.Point(139, 6)
        Me.cbChartType.Name = "cbChartType"
        Me.cbChartType.Size = New System.Drawing.Size(121, 20)
        Me.cbChartType.TabIndex = 1
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSarchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 432)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(902, 32)
        Me.pnlSearchAdd.TabIndex = 27
        '
        'btnSarchAdd
        '
        Me.btnSarchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSarchAdd.Name = "btnSarchAdd"
        Me.btnSarchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSarchAdd.TabIndex = 10
        Me.btnSarchAdd.Text = "さらに読み込む"
        Me.btnSarchAdd.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PriceChartSeq, Me.Enabled, Me.ComName, Me.ProductCode, Me.ProductSubCode, Me.ChartType, Me.PriceChartTime, Me.OpenAskPriceCall, Me.HighAskPriceCall, Me.LowAskPriceCall, Me.CloseAskPriceCall, Me.OpenAskPricePut, Me.HighAskPricePut, Me.LowAskPricePut, Me.CloseAskPricePut, Me.OpenBidPriceCall, Me.HighBidPriceCall, Me.LowBidPriceCall, Me.CloseBidPriceCall, Me.OpenBidPricePut, Me.HighBidPricePut, Me.LowBidPricePut, Me.CloseBidPricePut, Me.RateSeq, Me.CloseTime})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 58)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle25.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle25
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(902, 374)
        Me.grid.TabIndex = 28
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(338, 201)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(226, 63)
        Me.lblNoData.TabIndex = 29
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'PriceChartSeq
        '
        Me.PriceChartSeq.DataPropertyName = "PriceChartSeq"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.PriceChartSeq.DefaultCellStyle = DataGridViewCellStyle2
        Me.PriceChartSeq.HeaderText = "チャートSeq"
        Me.PriceChartSeq.Name = "PriceChartSeq"
        Me.PriceChartSeq.ReadOnly = True
        Me.PriceChartSeq.Width = 110
        '
        'Enabled
        '
        Me.Enabled.DataPropertyName = "Enabled"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Enabled.DefaultCellStyle = DataGridViewCellStyle3
        Me.Enabled.HeaderText = "有効フラグ"
        Me.Enabled.Name = "Enabled"
        Me.Enabled.ReadOnly = True
        Me.Enabled.Width = 79
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle4
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 73
        '
        'ProductCode
        '
        Me.ProductCode.DataPropertyName = "ProductCode"
        Me.ProductCode.HeaderText = "銘柄コード"
        Me.ProductCode.Name = "ProductCode"
        Me.ProductCode.ReadOnly = True
        Me.ProductCode.Width = 110
        '
        'ProductSubCode
        '
        Me.ProductSubCode.DataPropertyName = "ProductSubCode"
        Me.ProductSubCode.HeaderText = "銘柄サブコード"
        Me.ProductSubCode.Name = "ProductSubCode"
        Me.ProductSubCode.ReadOnly = True
        Me.ProductSubCode.Width = 110
        '
        'ChartType
        '
        Me.ChartType.DataPropertyName = "ChartType"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ChartType.DefaultCellStyle = DataGridViewCellStyle5
        Me.ChartType.HeaderText = "チャート種別"
        Me.ChartType.Name = "ChartType"
        Me.ChartType.ReadOnly = True
        Me.ChartType.Width = 65
        '
        'PriceChartTime
        '
        Me.PriceChartTime.DataPropertyName = "PriceChartTime"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle6.NullValue = Nothing
        Me.PriceChartTime.DefaultCellStyle = DataGridViewCellStyle6
        Me.PriceChartTime.HeaderText = "チャート日時"
        Me.PriceChartTime.Name = "PriceChartTime"
        Me.PriceChartTime.ReadOnly = True
        '
        'OpenAskPriceCall
        '
        Me.OpenAskPriceCall.DataPropertyName = "OpenAskPriceCall"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle7.Format = "######0.000#####"
        DataGridViewCellStyle7.NullValue = Nothing
        Me.OpenAskPriceCall.DefaultCellStyle = DataGridViewCellStyle7
        Me.OpenAskPriceCall.HeaderText = "Call購入Open"
        Me.OpenAskPriceCall.Name = "OpenAskPriceCall"
        Me.OpenAskPriceCall.ReadOnly = True
        Me.OpenAskPriceCall.Width = 55
        '
        'HighAskPriceCall
        '
        Me.HighAskPriceCall.DataPropertyName = "HighAskPriceCall"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "######0.000#####"
        Me.HighAskPriceCall.DefaultCellStyle = DataGridViewCellStyle8
        Me.HighAskPriceCall.HeaderText = "Call購入HIGH"
        Me.HighAskPriceCall.Name = "HighAskPriceCall"
        Me.HighAskPriceCall.ReadOnly = True
        Me.HighAskPriceCall.Width = 55
        '
        'LowAskPriceCall
        '
        Me.LowAskPriceCall.DataPropertyName = "LowAskPriceCall"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "######0.000#####"
        Me.LowAskPriceCall.DefaultCellStyle = DataGridViewCellStyle9
        Me.LowAskPriceCall.HeaderText = "Call購入Low"
        Me.LowAskPriceCall.Name = "LowAskPriceCall"
        Me.LowAskPriceCall.ReadOnly = True
        Me.LowAskPriceCall.Width = 55
        '
        'CloseAskPriceCall
        '
        Me.CloseAskPriceCall.DataPropertyName = "CloseAskPriceCall"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "######0.000#####"
        Me.CloseAskPriceCall.DefaultCellStyle = DataGridViewCellStyle10
        Me.CloseAskPriceCall.HeaderText = "Call購入Close"
        Me.CloseAskPriceCall.Name = "CloseAskPriceCall"
        Me.CloseAskPriceCall.ReadOnly = True
        Me.CloseAskPriceCall.Width = 55
        '
        'OpenAskPricePut
        '
        Me.OpenAskPricePut.DataPropertyName = "OpenAskPricePut"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle11.Format = "######0.000#####"
        Me.OpenAskPricePut.DefaultCellStyle = DataGridViewCellStyle11
        Me.OpenAskPricePut.HeaderText = "Put購入Open"
        Me.OpenAskPricePut.Name = "OpenAskPricePut"
        Me.OpenAskPricePut.ReadOnly = True
        Me.OpenAskPricePut.Width = 55
        '
        'HighAskPricePut
        '
        Me.HighAskPricePut.DataPropertyName = "HighAskPricePut"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle12.Format = "######0.000#####"
        Me.HighAskPricePut.DefaultCellStyle = DataGridViewCellStyle12
        Me.HighAskPricePut.HeaderText = "Put購入High"
        Me.HighAskPricePut.Name = "HighAskPricePut"
        Me.HighAskPricePut.ReadOnly = True
        Me.HighAskPricePut.Width = 55
        '
        'LowAskPricePut
        '
        Me.LowAskPricePut.DataPropertyName = "LowAskPricePut"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle13.Format = "######0.000#####"
        Me.LowAskPricePut.DefaultCellStyle = DataGridViewCellStyle13
        Me.LowAskPricePut.HeaderText = "Put購入Low"
        Me.LowAskPricePut.Name = "LowAskPricePut"
        Me.LowAskPricePut.ReadOnly = True
        Me.LowAskPricePut.Width = 55
        '
        'CloseAskPricePut
        '
        Me.CloseAskPricePut.DataPropertyName = "CloseAskPricePut"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle14.Format = "######0.000#####"
        Me.CloseAskPricePut.DefaultCellStyle = DataGridViewCellStyle14
        Me.CloseAskPricePut.HeaderText = "Put購入Close"
        Me.CloseAskPricePut.Name = "CloseAskPricePut"
        Me.CloseAskPricePut.ReadOnly = True
        Me.CloseAskPricePut.Width = 55
        '
        'OpenBidPriceCall
        '
        Me.OpenBidPriceCall.DataPropertyName = "OpenBidPriceCall"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle15.Format = "######0.000#####"
        Me.OpenBidPriceCall.DefaultCellStyle = DataGridViewCellStyle15
        Me.OpenBidPriceCall.HeaderText = "Call清算Open"
        Me.OpenBidPriceCall.Name = "OpenBidPriceCall"
        Me.OpenBidPriceCall.ReadOnly = True
        Me.OpenBidPriceCall.Width = 55
        '
        'HighBidPriceCall
        '
        Me.HighBidPriceCall.DataPropertyName = "HighBidPriceCall"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle16.Format = "######0.000#####"
        Me.HighBidPriceCall.DefaultCellStyle = DataGridViewCellStyle16
        Me.HighBidPriceCall.HeaderText = "Call清算High"
        Me.HighBidPriceCall.Name = "HighBidPriceCall"
        Me.HighBidPriceCall.ReadOnly = True
        Me.HighBidPriceCall.Width = 55
        '
        'LowBidPriceCall
        '
        Me.LowBidPriceCall.DataPropertyName = "LowBidPriceCall"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle17.Format = "######0.000#####"
        Me.LowBidPriceCall.DefaultCellStyle = DataGridViewCellStyle17
        Me.LowBidPriceCall.HeaderText = "Call清算Low"
        Me.LowBidPriceCall.Name = "LowBidPriceCall"
        Me.LowBidPriceCall.ReadOnly = True
        Me.LowBidPriceCall.Width = 55
        '
        'CloseBidPriceCall
        '
        Me.CloseBidPriceCall.DataPropertyName = "CloseBidPriceCall"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle18.Format = "######0.000#####"
        Me.CloseBidPriceCall.DefaultCellStyle = DataGridViewCellStyle18
        Me.CloseBidPriceCall.HeaderText = "Call清算Close"
        Me.CloseBidPriceCall.Name = "CloseBidPriceCall"
        Me.CloseBidPriceCall.ReadOnly = True
        Me.CloseBidPriceCall.Width = 55
        '
        'OpenBidPricePut
        '
        Me.OpenBidPricePut.DataPropertyName = "OpenBidPricePut"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle19.Format = "######0.000#####"
        Me.OpenBidPricePut.DefaultCellStyle = DataGridViewCellStyle19
        Me.OpenBidPricePut.HeaderText = "Put清算Open"
        Me.OpenBidPricePut.Name = "OpenBidPricePut"
        Me.OpenBidPricePut.ReadOnly = True
        Me.OpenBidPricePut.Width = 55
        '
        'HighBidPricePut
        '
        Me.HighBidPricePut.DataPropertyName = "HighBidPricePut"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle20.Format = "######0.000#####"
        Me.HighBidPricePut.DefaultCellStyle = DataGridViewCellStyle20
        Me.HighBidPricePut.HeaderText = "Put清算High"
        Me.HighBidPricePut.Name = "HighBidPricePut"
        Me.HighBidPricePut.ReadOnly = True
        Me.HighBidPricePut.Width = 55
        '
        'LowBidPricePut
        '
        Me.LowBidPricePut.DataPropertyName = "LowBidPricePut"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle21.Format = "######0.000#####"
        Me.LowBidPricePut.DefaultCellStyle = DataGridViewCellStyle21
        Me.LowBidPricePut.HeaderText = "Put清算Low"
        Me.LowBidPricePut.Name = "LowBidPricePut"
        Me.LowBidPricePut.ReadOnly = True
        Me.LowBidPricePut.Width = 55
        '
        'CloseBidPricePut
        '
        Me.CloseBidPricePut.DataPropertyName = "CloseBidPricePut"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle22.Format = "######0.000#####"
        Me.CloseBidPricePut.DefaultCellStyle = DataGridViewCellStyle22
        Me.CloseBidPricePut.HeaderText = "Put清算Close"
        Me.CloseBidPricePut.Name = "CloseBidPricePut"
        Me.CloseBidPricePut.ReadOnly = True
        Me.CloseBidPricePut.Width = 55
        '
        'RateSeq
        '
        Me.RateSeq.DataPropertyName = "RateSeq"
        DataGridViewCellStyle23.Format = "yyyy/MM/dd HH:mm:ss"
        Me.RateSeq.DefaultCellStyle = DataGridViewCellStyle23
        Me.RateSeq.HeaderText = "レートSeq"
        Me.RateSeq.Name = "RateSeq"
        Me.RateSeq.ReadOnly = True
        Me.RateSeq.Visible = False
        Me.RateSeq.Width = 110
        '
        'CloseTime
        '
        Me.CloseTime.DataPropertyName = "CloseTime"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CloseTime.DefaultCellStyle = DataGridViewCellStyle24
        Me.CloseTime.HeaderText = "レート日時"
        Me.CloseTime.Name = "CloseTime"
        Me.CloseTime.ReadOnly = True
        Me.CloseTime.Width = 110
        '
        'PriceChartHistList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(902, 464)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "PriceChartHistList"
        Me.Text = "時価チャート一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BtnCSV As System.Windows.Forms.Button
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbChartType As System.Windows.Forms.ComboBox
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents btnSarchAdd As System.Windows.Forms.Button
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents colEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PriceChartSeq As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Enabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductSubCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ChartType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PriceChartTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OpenAskPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HighAskPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LowAskPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CloseAskPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OpenAskPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HighAskPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LowAskPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CloseAskPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OpenBidPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HighBidPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LowBidPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CloseBidPriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OpenBidPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents HighBidPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LowBidPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CloseBidPricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateSeq As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CloseTime As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
