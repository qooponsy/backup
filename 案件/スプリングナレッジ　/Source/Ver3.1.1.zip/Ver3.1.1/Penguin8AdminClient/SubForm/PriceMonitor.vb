﻿Imports System.Text

Public Class PriceMonitor

    Private WithEvents serviceNowProduct As NowProductService
    Private WithEvents serviceDDD As DDDService

    Private Table As New DataTable
    Private view As New DataView

    Private Sub PriceMonitor_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Dim ComList = CurrencyPairService.GetListWithAll()
        Me.cbComCode.DataSource = ComList
        Me.cbComCode.SelectedIndex = ComList.Count - 1

        Me.cbOpType.DisplayMember = "OpName"
        Me.cbOpType.ValueMember = "OpType"
        Dim OpList = OptionInfoService.GetListWithAll()
        Me.cbOpType.DataSource = OpList
        Me.cbOpType.SelectedIndex = OpList.Count - 1

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        miEdit.Text = IIf(editable, "編集", "参照")

        MainWindow.SubFormPriceMonitor = True

        LoadSettings()

        initGrid()
        setGrid()
        SetColumnVisible()
        SetFilter()

        serviceNowProduct = New NowProductService
        serviceDDD = New DDDService

    End Sub

    Private Sub PriceMonitor_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceNowProduct = Nothing
        serviceDDD = Nothing

        SaveSettings()
        MainWindow.SubFormPriceMonitor = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.PriceMonitor_FormMaximized, _
            UserSettings.getInstance().DataSaved.PriceMonitor_FormSize, _
            UserSettings.getInstance().DataSaved.PriceMonitor_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.PriceMonitorList_Columns)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        clsUtil.SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.PriceMonitor_FormMaximized, _
            UserSettings.getInstance().DataSaved.PriceMonitor_FormSize, _
            UserSettings.getInstance().DataSaved.PriceMonitor_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.PriceMonitorList_Columns)
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        For Each col As DataGridViewTextBoxColumn In grid.Columns
            col.HeaderText = col.HeaderText.Replace("\n", vbCrLf)
        Next

        Table = New DataTable
        Table.Columns.Add("ProductCode", GetType(String))
        Table.Columns.Add("ProductSubCode", GetType(String))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("ComOrder", GetType(Integer))
        Table.Columns.Add("OpType", GetType(String))
        Table.Columns.Add("OpName", GetType(String))
        Table.Columns.Add("StartTime", GetType(DateTime))
        Table.Columns.Add("TradeLimitTime", GetType(DateTime))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("ExercPriceTimespan", GetType(Integer))
        Table.Columns.Add("ExercPriceRate", GetType(Decimal))
        Table.Columns.Add("ExercPriceUnitType", GetType(String))
        Table.Columns.Add("ExercPriceUnitTypeName", GetType(String))
        Table.Columns.Add("ExercPriceUnit", GetType(Decimal))
        Table.Columns.Add("ExercPriceSetting", GetType(String))
        Table.Columns.Add("ExercPrice", GetType(Decimal))
        Table.Columns.Add("ProductEnabled", GetType(String))
        Table.Columns.Add("ProductSubEnabled", GetType(String))
        Table.Columns.Add("ProductSubStatus", GetType(String))
        Table.Columns.Add("Status", GetType(String))
        Table.Columns.Add("RateSeq", GetType(String))
        Table.Columns.Add("Rate", GetType(Decimal))
        Table.Columns.Add("RateTime", GetType(DateTime))
        Table.Columns.Add("CalcTime", GetType(DateTime))
        Table.Columns.Add("PriceAskCall", GetType(Decimal))
        Table.Columns.Add("PriceBidCall", GetType(Decimal))
        Table.Columns.Add("PriceAskPut", GetType(Decimal))
        Table.Columns.Add("PriceBidPut", GetType(Decimal))
        Table.Columns.Add("VolAskCall", GetType(Decimal))
        Table.Columns.Add("VolBidCall", GetType(Decimal))
        Table.Columns.Add("VolAskPut", GetType(Decimal))
        Table.Columns.Add("VolBidPut", GetType(Decimal))
        Table.Columns.Add("HVol", GetType(Decimal))
        Table.Columns.Add("InterestRate", GetType(Decimal))
        Table.Columns.Add("SwapRate", GetType(Decimal))
        Table.Columns.Add("VolRatio1Call", GetType(Decimal))
        Table.Columns.Add("VolRatio1Put", GetType(Decimal))
        Table.Columns.Add("VolRatio2Call", GetType(Decimal))
        Table.Columns.Add("VolRatio2Put", GetType(Decimal))
        Table.Columns.Add("VolSpread", GetType(Decimal))
        Table.Columns.Add("VolSmileACall", GetType(Decimal))
        Table.Columns.Add("VolSmileAPut", GetType(Decimal))
        Table.Columns.Add("VolSmileBCall", GetType(Decimal))
        Table.Columns.Add("VolSmileBPut", GetType(Decimal))
        Table.Columns.Add("VolSpreadITMCall", GetType(Decimal))
        Table.Columns.Add("VolSpreadITMPut", GetType(Decimal))
        Table.Columns.Add("VolSpreadOTMCall", GetType(Decimal))
        Table.Columns.Add("VolSpreadOTMPut", GetType(Decimal))
        Table.Columns.Add("AskFeePriceCall", GetType(Decimal))
        Table.Columns.Add("AskFeePricePut", GetType(Decimal))
        Table.Columns.Add("AskBidSpreadMinCall", GetType(Decimal))
        Table.Columns.Add("AskBidSpreadMinPut", GetType(Decimal))
        Table.Columns.Add("BidFeeRateCall", GetType(Decimal))
        Table.Columns.Add("BidFeeRatePut", GetType(Decimal))
        Table.Columns.Add("AskPriceMaxCall", GetType(Decimal))
        Table.Columns.Add("AskPriceMaxPut", GetType(Decimal))
        Table.Columns.Add("AskPriceMinCall", GetType(Decimal))
        Table.Columns.Add("AskPriceMinPut", GetType(Decimal))
        Table.Columns.Add("BidPriceMaxCall", GetType(Decimal))
        Table.Columns.Add("BidPriceMaxPut", GetType(Decimal))
        Table.Columns.Add("BidPriceMinCall", GetType(Decimal))
        Table.Columns.Add("BidPriceMinPut", GetType(Decimal))

        view = New DataView(Table)
        view.Sort = "ExercTime, ComOrder, ExercPrice desc"
        grid.DataSource = view

    End Sub

    Private Sub setGrid()
        Dim selectedRow As Boolean = (grid.SelectedRows.Count > 0)

        Dim codeHash As New HashSet(Of String)
        Dim delRows As New List(Of DataRow)

        For Each row In Table.Rows
            Dim code As String = row("ProductSubCode")
            If NowProductService.DataList.ContainsKey(code) Then
                codeHash.Add(code)
                Dim item = NowProductService.DataList(code)
                Dim com = CurrencyPairService.GetData(item.ComCode)
                Dim calc = CalcParamService.GetData(item.ComCode)
                setRowProduct(com, calc, item, row)
                setRowPrice(com, code, row)
            Else
                delRows.Add(row)
            End If
        Next

        For Each item In NowProductService.DataList.Values
            Dim code = item.ProductSubCode
            If Not codeHash.Contains(code) Then
                Dim row = Table.NewRow()
                Dim com = CurrencyPairService.GetData(item.ComCode)
                Dim calc = CalcParamService.GetData(item.ComCode)
                setRowProduct(com, calc, item, row)
                setRowPrice(com, code, row)
                Table.Rows.Add(row)
            End If
        Next

        For Each row In delRows
            Table.Rows.Remove(row)
        Next

        If Not selectedRow Then
            For fa As Integer = 0 To grid.Rows.Count - 1
                If grid.Rows(fa).Selected Then
                    Dim a = 0
                    a += 1
                End If
                grid.Rows(fa).Selected = False
            Next
            If grid.Rows.Count > 0 Then
                Try
                    grid.CurrentCell = grid(0, 0)
                Catch ex As Exception
                    Debug.Print("Ignore Exception PriceMonitor.setGrid:" & ex.Message)
                End Try
            End If
        End If

    End Sub

    Private Sub updatePrice()
        For Each row In Table.Rows
            Dim code As String = row("ProductSubCode")
            Dim comcode As String = row("ComCode")
            Dim com = CurrencyPairService.GetData(comcode)
            setRowPrice(com, code, row)
        Next
    End Sub

    Private Sub setRowProduct(com As CurrencyPairData, calc As CalcParamData, item As NowProductData, row As DataRow)
        row("ProductCode") = item.ProductCode
        row("ProductSubCode") = item.ProductSubCode
        row("ComCode") = item.ComCode
        row("ComName") = com.ComName
        row("ComOrder") = com.SortOrder
        row("OpType") = item.OpType
        row("OpName") = "ラダー"
        row("StartTime") = item.StartTime
        row("ExercTime") = item.ExercTime
        row("TradeLimitTime") = item.TradeLimitTime
        row("ExercPriceTimespan") = If(item.ExercPriceTimespanEnabled, item.ExercPriceTimespan, DBNull.Value)
        row("ExercPriceRate") = If(item.ExercPriceRateEnabled, item.ExercPriceRate, DBNull.Value)
        row("ExercPriceUnitType") = If(item.ExercPriceUnitTypeEnabled, item.ExercPriceUnitType, DBNull.Value)
        row("ExercPriceUnitTypeName") = If(item.ExercPriceUnitTypeEnabled, ExercPriceUnitTypeManager.GetName(item.ExercPriceUnitType), DBNull.Value)
        row("ExercPriceUnit") = If(item.ExercPriceUnitEnabled, item.ExercPriceUnit, DBNull.Value)
        row("ExercPriceSetting") = If(item.ExercPriceSettingEnabled, item.ExercPriceSetting, DBNull.Value)
        row("ExercPrice") = If(item.ExercPriceEnabled, item.ExercPrice, DBNull.Value)
        row("ProductEnabled") = item.ProductEnabled
        row("ProductSubEnabled") = item.ProductSubEnabled
        row("ProductSubStatus") = item.ProductSubStatus
        row("Status") = item.Status
        row("HVol") = calc.Volatility
        row("InterestRate") = calc.InterestRate * 100
        row("SwapRate") = calc.SwapRate * 100
        row("VolRatio1Call") = If(item.VolRatio1CallEnabled, item.VolRatio1Call, DBNull.Value)
        row("VolRatio1Put") = If(item.VolRatio1PutEnabled, item.VolRatio1Put, DBNull.Value)
        row("VolRatio2Call") = If(item.VolRatio2CallEnabled, item.VolRatio2Call, DBNull.Value)
        row("VolRatio2Put") = If(item.VolRatio2PutEnabled, item.VolRatio2Put, DBNull.Value)
        row("VolSpread") = If(item.VolSpreadEnabled, item.VolSpread, DBNull.Value)
        row("VolSmileACall") = If(item.VolSmileACallEnabled, item.VolSmileACall, DBNull.Value)
        row("VolSmileAPut") = If(item.VolSmileAPutEnabled, item.VolSmileAPut, DBNull.Value)
        row("VolSmileBCall") = If(item.VolSmileBCallEnabled, item.VolSmileBCall, DBNull.Value)
        row("VolSmileBPut") = If(item.VolSmileBPutEnabled, item.VolSmileBPut, DBNull.Value)
        row("VolSpreadITMCall") = If(item.VolSpreadITMCallEnabled, item.VolSpreadITMCall, DBNull.Value)
        row("VolSpreadITMPut") = If(item.VolSpreadITMPutEnabled, item.VolSpreadITMPut, DBNull.Value)
        row("VolSpreadOTMCall") = If(item.VolSpreadOTMCallEnabled, item.VolSpreadOTMCall, DBNull.Value)
        row("VolSpreadOTMPut") = If(item.VolSpreadOTMPutEnabled, item.VolSpreadOTMPut, DBNull.Value)
        row("AskFeePriceCall") = If(item.AskFeePriceCallEnabled, item.AskFeePriceCall * 100, DBNull.Value)
        row("AskFeePricePut") = If(item.AskFeePricePutEnabled, item.AskFeePricePut * 100, DBNull.Value)
        row("AskBidSpreadMinCall") = If(item.AskBidSpreadMinCallEnabled, item.AskBidSpreadMinCall * 100, DBNull.Value)
        row("AskBidSpreadMinPut") = If(item.AskBidSpreadMinPutEnabled, item.AskBidSpreadMinPut * 100, DBNull.Value)
        row("BidFeeRateCall") = If(item.BidFeeRateCallEnabled, item.BidFeeRateCall * 100, DBNull.Value)
        row("BidFeeRatePut") = If(item.BidFeeRatePutEnabled, item.BidFeeRatePut * 100, DBNull.Value)
        row("AskPriceMaxCall") = If(item.AskPriceMaxCallEnabled, item.AskPriceMaxCall, DBNull.Value)
        row("AskPriceMaxPut") = If(item.AskPriceMaxPutEnabled, item.AskPriceMaxPut, DBNull.Value)
        row("AskPriceMinCall") = If(item.AskPriceMinCallEnabled, item.AskPriceMinCall, DBNull.Value)
        row("AskPriceMinPut") = If(item.AskPriceMinPutEnabled, item.AskPriceMinPut, DBNull.Value)
        row("BidPriceMaxCall") = If(item.BidPriceMaxCallEnabled, item.BidPriceMaxCall, DBNull.Value)
        row("BidPriceMaxPut") = If(item.BidPriceMaxPutEnabled, item.BidPriceMaxPut, DBNull.Value)
        row("BidPriceMinCall") = If(item.BidPriceMinCallEnabled, item.BidPriceMinCall, DBNull.Value)
        row("BidPriceMinPut") = If(item.BidPriceMinPutEnabled, item.BidPriceMinPut, DBNull.Value)
    End Sub

    Private Sub setRowPrice(com As CurrencyPairData, code As String, row As DataRow)
        Dim rate = DDDService.GetLastRate(com.ComCode)
        If rate IsNot Nothing Then
            row("RateSeq") = rate.RateSeq
            row("Rate") = rate.Rate
            row("RateTime") = rate.RateTime
        End If
        Dim price = DDDService.GetPrice(code)
        If price IsNot Nothing Then
            row("CalcTime") = price.CalcTime
            row("PriceAskCall") = price.PriceAskCall
            row("PriceBidCall") = price.PriceBidCall
            row("PriceAskPut") = price.PriceAskPut
            row("PriceBidPut") = price.PriceBidPut
            row("VolAskCall") = price.VolAskCall
            row("VolBidCall") = price.VolBidCall
            row("VolAskPut") = price.VolAskPut
            row("VolBidPut") = price.VolBidPut
        End If
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "nowprice"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                For Each item In columnList
                    Select Case item(0)
                        Case Else
                            item(1) = item(1).Replace(vbCrLf, " ")
                    End Select
                Next
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs)
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs)
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs)
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells(colProductSubCode.Name).Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells(colProductSubCode.Name).Value
        edit(code)
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormProductSubForm Then
            ProductSubForm.Close()
        End If
        ProductSubForm.MdiParent = MainWindow
        ProductSubForm.Code = code
        ProductSubForm.SubCode = grid.SelectedRows(0).Cells(colProductSubCode.Name).Value
        ProductSubForm.Show()
    End Sub

    Private Sub serviceDDD_NewDDD() Handles serviceDDD.NewDDD

        updatePrice()
    End Sub

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).Name
                Case colRate.Name, colExercPriceUnit.Name, colExercPrice.Name, colExercPriceRate.Name
                    Dim ComCode As String = grid.Rows(e.RowIndex).Cells(colComCode.Name).Value
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

    Private Sub chkViewColumns_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkViewColumns.CheckedChanged
        SetColumnVisible()
    End Sub

    Private Sub SetFilter()
        Dim filterString As New StringBuilder
        Dim condDelimiter As String = ""
        If cbComCode.SelectedValue <> "" Then
            filterString.Append(condDelimiter)
            condDelimiter = " and "
            filterString.AppendFormat("ComCode='{0}'", cbComCode.SelectedValue)
        End If
        If cbOpType.SelectedValue <> "" Then
            filterString.Append(condDelimiter)
            condDelimiter = " and "
            filterString.AppendFormat("OpType='{0}'", cbOpType.SelectedValue)
        End If
        view.RowFilter = filterString.ToString()
    End Sub


    Private Sub SetColumnVisible()
        Dim viewL1 As Boolean = True
        Dim viewL2 As Boolean = chkViewColumns.Checked
        Dim viewL3 As Boolean = False

        colComName.Visible = viewL1
        colExercTime.Visible = viewL1
        colExercPriceSetting.Visible = viewL1
        colExercPrice.Visible = viewL1
        colStatus.Visible = viewL1
        colRate.Visible = viewL1
        colRateTime.Visible = viewL1
        colCalcTime.Visible = viewL1
        colPriceAskCall.Visible = viewL1
        colPriceBidCall.Visible = viewL1
        colPriceAskPut.Visible = viewL1
        colPriceBidPut.Visible = viewL1
        colVolAskCall.Visible = viewL1
        colVolBidCall.Visible = viewL1
        colVolAskPut.Visible = viewL1
        colVolBidPut.Visible = viewL1

        colProductSubCode.Visible = viewL2
        colOpName.Visible = viewL2
        colStartTime.Visible = viewL2
        colTradeLimitTime.Visible = viewL2
        colHVol.Visible = viewL2
        colInterestRate.Visible = viewL2
        colSwapRate.Visible = viewL2
        colVolRatio1Call.Visible = viewL2
        colVolRatio1Put.Visible = viewL2
        colVolRatio2Call.Visible = viewL2
        colVolRatio2Put.Visible = viewL2
        colVolSpread.Visible = viewL2
        colVolSmileACall.Visible = viewL2
        colVolSmileAPut.Visible = viewL2
        colVolSmileBCall.Visible = viewL2
        colVolSmileBPut.Visible = viewL2
        colVolSpreadITMCall.Visible = viewL2
        colVolSpreadITMPut.Visible = viewL2
        colVolSpreadOTMCall.Visible = viewL3
        colVolSpreadOTMPut.Visible = viewL3
        colAskFeePriceCall.Visible = viewL2
        colAskFeePricePut.Visible = viewL2
        colAskBidSpreadMinCall.Visible = viewL2
        colAskBidSpreadMinPut.Visible = viewL2
        colBidFeeRateCall.Visible = viewL2
        colBidFeeRatePut.Visible = viewL2
        colAskPriceMaxCall.Visible = viewL2
        colAskPriceMaxPut.Visible = viewL2
        colAskPriceMinCall.Visible = viewL2
        colAskPriceMinPut.Visible = viewL2
        colBidPriceMaxCall.Visible = viewL2
        colBidPriceMaxPut.Visible = viewL2
        colBidPriceMinCall.Visible = viewL2
        colBidPriceMinPut.Visible = viewL2

        colProductCode.Visible = viewL3
        colComCode.Visible = viewL3
        colOpType.Visible = viewL3
        colExercPriceTimespan.Visible = viewL3
        colExercPriceRate.Visible = viewL3
        colExercPriceUnitType.Visible = viewL3
        colExercPriceUnitTypeName.Visible = viewL3
        colExercPriceUnit.Visible = viewL3
        colProductEnabled.Visible = viewL3
        colProductSubEnabled.Visible = viewL3
        colProductSubStatus.Visible = viewL3
        colRateSeq.Visible = viewL3
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        SetFilter()
    End Sub

    Private Sub cbOpType_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbOpType.SelectedIndexChanged
        SetFilter()
    End Sub

    Private Sub serviceNowProduct_DataChanged() Handles serviceNowProduct.DataChanged
        setGrid()
    End Sub

End Class