﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateChartForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblRateChartCode = New System.Windows.Forms.Label()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbChartType = New System.Windows.Forms.ComboBox()
        Me.dtpChartTime = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbChartTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.tbOpenRate = New System.Windows.Forms.TextBox()
        Me.tbHighRate = New System.Windows.Forms.TextBox()
        Me.tbLowRate = New System.Windows.Forms.TextBox()
        Me.tbCloseRate = New System.Windows.Forms.TextBox()
        Me.lblRateCode = New System.Windows.Forms.Label()
        Me.dtpCloseTime = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbCloseTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "チャートSeq"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "有効フラグ"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "通貨ペア"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 158)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 12)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "チャート種別"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 197)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 12)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "チャート日時"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(274, 128)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 12)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Open"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(274, 160)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 12)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "High"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(274, 192)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(25, 12)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Low"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(274, 224)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 12)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Close"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(274, 41)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 12)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "レートSeq"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(274, 80)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 12)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "レート日時"
        '
        'lblRateChartCode
        '
        Me.lblRateChartCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRateChartCode.Location = New System.Drawing.Point(86, 36)
        Me.lblRateChartCode.Name = "lblRateChartCode"
        Me.lblRateChartCode.Size = New System.Drawing.Size(160, 23)
        Me.lblRateChartCode.TabIndex = 11
        Me.lblRateChartCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(86, 77)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(160, 20)
        Me.cbEnabled.TabIndex = 12
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(86, 116)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(160, 20)
        Me.cbComCode.TabIndex = 13
        '
        'cbChartType
        '
        Me.cbChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbChartType.FormattingEnabled = True
        Me.cbChartType.Location = New System.Drawing.Point(86, 155)
        Me.cbChartType.Name = "cbChartType"
        Me.cbChartType.Size = New System.Drawing.Size(160, 20)
        Me.cbChartType.TabIndex = 14
        '
        'dtpChartTime
        '
        Me.dtpChartTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpChartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpChartTime.Location = New System.Drawing.Point(86, 192)
        Me.dtpChartTime.Name = "dtpChartTime"
        Me.dtpChartTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpChartTime.TabIndex = 15
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(215, 220)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 12)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "ミリ秒"
        '
        'tbChartTimeMilliseconds
        '
        Me.tbChartTimeMilliseconds.Location = New System.Drawing.Point(176, 217)
        Me.tbChartTimeMilliseconds.Name = "tbChartTimeMilliseconds"
        Me.tbChartTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbChartTimeMilliseconds.TabIndex = 16
        Me.tbChartTimeMilliseconds.Text = "999"
        Me.tbChartTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbOpenRate
        '
        Me.tbOpenRate.Location = New System.Drawing.Point(348, 125)
        Me.tbOpenRate.Name = "tbOpenRate"
        Me.tbOpenRate.Size = New System.Drawing.Size(160, 19)
        Me.tbOpenRate.TabIndex = 18
        Me.tbOpenRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHighRate
        '
        Me.tbHighRate.Location = New System.Drawing.Point(348, 157)
        Me.tbHighRate.Name = "tbHighRate"
        Me.tbHighRate.Size = New System.Drawing.Size(160, 19)
        Me.tbHighRate.TabIndex = 19
        Me.tbHighRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbLowRate
        '
        Me.tbLowRate.Location = New System.Drawing.Point(348, 189)
        Me.tbLowRate.Name = "tbLowRate"
        Me.tbLowRate.Size = New System.Drawing.Size(160, 19)
        Me.tbLowRate.TabIndex = 20
        Me.tbLowRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCloseRate
        '
        Me.tbCloseRate.Location = New System.Drawing.Point(348, 221)
        Me.tbCloseRate.Name = "tbCloseRate"
        Me.tbCloseRate.Size = New System.Drawing.Size(160, 19)
        Me.tbCloseRate.TabIndex = 21
        Me.tbCloseRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblRateCode
        '
        Me.lblRateCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRateCode.Location = New System.Drawing.Point(348, 36)
        Me.lblRateCode.Name = "lblRateCode"
        Me.lblRateCode.Size = New System.Drawing.Size(160, 23)
        Me.lblRateCode.TabIndex = 22
        Me.lblRateCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dtpCloseTime
        '
        Me.dtpCloseTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpCloseTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpCloseTime.Location = New System.Drawing.Point(348, 75)
        Me.dtpCloseTime.Name = "dtpCloseTime"
        Me.dtpCloseTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpCloseTime.TabIndex = 23
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(477, 103)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 12)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "ミリ秒"
        '
        'tbCloseTimeMilliseconds
        '
        Me.tbCloseTimeMilliseconds.Location = New System.Drawing.Point(438, 100)
        Me.tbCloseTimeMilliseconds.Name = "tbCloseTimeMilliseconds"
        Me.tbCloseTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbCloseTimeMilliseconds.TabIndex = 24
        Me.tbCloseTimeMilliseconds.Text = "999"
        Me.tbCloseTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(276, 263)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 28
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(148, 263)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 27
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'RateChartForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(532, 318)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.dtpCloseTime)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.tbCloseTimeMilliseconds)
        Me.Controls.Add(Me.lblRateCode)
        Me.Controls.Add(Me.tbCloseRate)
        Me.Controls.Add(Me.tbLowRate)
        Me.Controls.Add(Me.tbHighRate)
        Me.Controls.Add(Me.tbOpenRate)
        Me.Controls.Add(Me.dtpChartTime)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.tbChartTimeMilliseconds)
        Me.Controls.Add(Me.cbChartType)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.lblRateChartCode)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "RateChartForm"
        Me.Text = "レートチャート編集"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblRateChartCode As System.Windows.Forms.Label
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbChartType As System.Windows.Forms.ComboBox
    Friend WithEvents dtpChartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbChartTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents tbOpenRate As System.Windows.Forms.TextBox
    Friend WithEvents tbHighRate As System.Windows.Forms.TextBox
    Friend WithEvents tbLowRate As System.Windows.Forms.TextBox
    Friend WithEvents tbCloseRate As System.Windows.Forms.TextBox
    Friend WithEvents lblRateCode As System.Windows.Forms.Label
    Friend WithEvents dtpCloseTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tbCloseTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
End Class
