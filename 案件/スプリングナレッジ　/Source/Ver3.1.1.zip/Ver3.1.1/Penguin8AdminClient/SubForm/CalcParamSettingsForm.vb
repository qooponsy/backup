﻿Public Class CalcParamSettingsForm
    Public Property Code As String

    Private WithEvents service As New CalcParamSettingsService

    Private Enum FormMode
        INIT = 0
        READ = 1
        EDIT = 3
        REFERENCE = 4
        EDITCONF = 6
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub CalcParamSettingsForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        setTitle()

        MainWindow.SubFormCalcParamSettingsForm = True

        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub CalcParamSettingsForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormCalcParamSettingsForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If UserTypeManager.IsAdmin(SessionService.UserType) Then
            Me.Text = "プレミアムパラメーター変更"
        Else
            Me.Text = "プレミアムパラメーター参照"
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        tbVolatilityAdjust.Enabled = (status = FormMode.EDIT)
        tbInterestRate.Enabled = (status = FormMode.EDIT)
        tbSwapRate.Enabled = (status = FormMode.EDIT)
        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.EDITCONF, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initEdit()
        service.ReadList()
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of CalcParamSettingsData)) Handles service.ReadSuccess

        For Each item As CalcParamSettingsData In list
            If item.ComCode = Code Then
                setControlFromData(item)
                If UserTypeManager.IsAdmin(SessionService.UserType) Then
                    setFormMode(FormMode.EDIT)
                Else
                    setFormMode(FormMode.REFERENCE)
                End If

                Return
            End If
        Next

        MessageBox.Show(Me, "通貨ペアの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As CalcParamSettingsData)
        lblComName.Text = CurrencyPairService.GetData(data.ComCode).ComName

        lblInterestRate.Text = (CalcParamService.GetData(data.ComCode).InterestRate * 100).ToString("0.##############")              '計算パラメータ(短期金利)
        lblSwapRate.Text = (CalcParamService.GetData(data.ComCode).SwapRate * 100).ToString("0.##############")                      '計算パラメータ(スワップ金利)
        lblVolatilityAdjust.Text = (CalcParamService.GetData(data.ComCode).VolatilityAdjust * 100).ToString("0.##############")      '計算パラメータ(ボラティリティレシオ)
        lblVolatility.Text = (CalcParamService.GetData(data.ComCode).Volatility).ToString("0.00000000000000")                        '計算パラメータ(ボラティリティ)
        tbInterestRate.Text = (data.InterestRate * 100).ToString("0.##############")                                                 '計算パラメータ設定(短期金利)
        tbSwapRate.Text = (data.SwapRate * 100).ToString("0.##############")                                                         '計算パラメータ設定(スワップ金利)
        tbVolatilityAdjust.Text = (data.VolatilityAdjust * 100).ToString("0.##############")                                         '計算パラメータ設定(ボラティリティレシオ)
    End Sub

    Private Function getDataFromControl() As CalcParamSettingsData
        Dim ret As New CalcParamSettingsData

        ret.ComCode = Code
        ret.InterestRate = (Decimal.Parse(tbInterestRate.Text)) / 100.0
        ret.SwapRate = (Decimal.Parse(tbSwapRate.Text)) / 100.0
        ret.VolatilityAdjust = (Decimal.Parse(tbVolatilityAdjust.Text)) / 100.0

        Return ret
    End Function

    Private Function checkInput() As Boolean

        If Not CheckUtil.RegExSignRate12.IsMatch(tbInterestRate.Text) Then
            MessageBox.Show(Me, "短期金利(%)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim interestRate As Decimal
        If Not Decimal.TryParse(tbInterestRate.Text, interestRate) Then
            MessageBox.Show(Me, "短期金利(%)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If interestRate < -5 Or interestRate > 15 Then
            MessageBox.Show(Me, "短期金利(%)には-5以上かつ15以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExSignRate12.IsMatch(tbSwapRate.Text) Then
            MessageBox.Show(Me, "スワップ金利(%)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim swapRate As Decimal
        If Not Decimal.TryParse(tbSwapRate.Text, swapRate) Then
            MessageBox.Show(Me, "スワップ金利(%)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If swapRate < -15 Or swapRate > 15 Then
            MessageBox.Show(Me, "スワップ金利(%)には-15以上かつ15以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate12.IsMatch(tbVolatilityAdjust.Text) Then
            MessageBox.Show(Me, "ボラティリティレシオ(%)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim volatilityAdjust As Decimal
        If Not Decimal.TryParse(tbVolatilityAdjust.Text, volatilityAdjust) Then
            MessageBox.Show(Me, "ボラティリティレシオ(%)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If volatilityAdjust < 1 Or volatilityAdjust > 100 Then
            MessageBox.Show(Me, "ボラティリティレシオ(%)には1以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub updateData()
        Dim data As CalcParamSettingsData = getDataFromControl()

        service.Update(data)
    End Sub

End Class