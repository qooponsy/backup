﻿Public Class ProductForm
    Public Property Code As String

    Private WithEvents service As New ProductService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT
    Private ProductEnabled As Boolean = False

    Private Const MAX_PRICE As Integer = 1000

    Private CalcExercPriceList As CalcExercPriceListProduct = Nothing

    Private Sub ProductForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        setTitle()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbExercStatus.DisplayMember = "Name"
        cbExercStatus.ValueMember = "Code"
        cbExercStatus.DataSource = ExercStatusManager.GetList(True, False)

        cbOpType.DisplayMember = "OpName"
        cbOpType.ValueMember = "OpType"
        cbOpType.DataSource = OptionInfoService.GetList()

        cbExercPriceStatus.DisplayMember = "Name"
        cbExercPriceStatus.ValueMember = "Code"
        cbExercPriceStatus.DataSource = ExercPriceStatusManager.GetList(True, False)

        cbExercPriceUnitType.DisplayMember = "Name"
        cbExercPriceUnitType.ValueMember = "Code"
        cbExercPriceUnitType.DataSource = ExercPriceUnitTypeManager.GetList(True, False)
        cbExercPriceUnitType.SelectedValue = "0"

        MainWindow.SubFormProductForm = True
        ProductEnabled = False

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub ProductForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormProductForm = False
        If CalcExercPriceList IsNot Nothing Then
            If CalcExercPriceList.SourceForm IsNot Nothing Then
                CalcExercPriceList.Close()
            End If
            CalcExercPriceList = Nothing
        End If
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "銘柄登録"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "銘柄編集"
            Else
                Me.Text = "銘柄参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbComCode.Enabled = (status = FormMode.REGIST)
        cbOpType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpSysDate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpStartTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpExercTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpTradeLimitTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbPayoutRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbExercStatus.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbEnabled.Visible = (status = FormMode.REGIST Or status = FormMode.REGISTCONF Or status = FormMode.REGISTRUN)
        cbEnabled.Enabled = (status = FormMode.REGIST)
        lblEnabled.Visible = Not (status = FormMode.REGIST Or status = FormMode.REGISTCONF Or status = FormMode.REGISTRUN)
        tbExercRateSeq.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceTimeSpan.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceUnit.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnExercPricePreview.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbExercPriceStatus.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        tbVolRatio1Call.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskBidSpreadMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskPriceMaxCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskPriceMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBidPriceMaxCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBidPriceMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbExercStatus.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceSettings.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnBulkSet.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        nudBulkSetCount.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBulkSetUnit.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExceptExercPrice.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceRateSeq.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPriceRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select

        btnEnabled.Enabled = (status = FormMode.EDIT And Not ProductEnabled)
        btnDisabled.Enabled = (status = FormMode.EDIT And ProductEnabled)

    End Sub

    Private Sub initRegist()
        cbComCode.SelectedValue = ""
        cbOpType.SelectedValue = "02"
        cbEnabled.SelectedValue = ""
        cbExercStatus.SelectedValue = ""
        cbExercPriceStatus.SelectedValue = ""
        dtpSysDate.Value = New DateTime(SysStatusService.GetData().SysDate.Year, SysStatusService.GetData().SysDate.Month, SysStatusService.GetData().SysDate.Day)
        dtpStartTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        dtpExercTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        dtpTradeLimitTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)

        tbExercPriceTimeSpan.Text = ""
        tbExercPriceUnit.Text = ""
        tbExercPriceSettings.Text = ""
        tbVolRatio1Call.Text = ""
        tbAskBidSpreadMinCall.Text = ""
        tbAskPriceMaxCall.Text = ""
        tbAskPriceMinCall.Text = ""
        tbBidPriceMaxCall.Text = "999"  '999固定
        tbBidPriceMinCall.Text = "1"    '1固定
        tbExceptExercPrice.Text = ""
        tbExercPriceRate.Text = ""

    End Sub

    Private Sub initEdit()
        cbComCode.SelectedValue = ""
        cbOpType.SelectedValue = ""
        cbExercStatus.SelectedValue = ""

        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of ProductData), existNextFlag As Boolean, TotalPAndL As Decimal, TotalPremium As Decimal) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "銘柄の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).ProductCode <> Code Then
            MessageBox.Show(Me, "銘柄の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As ProductData)
        Me.lblCode.Text = data.ProductCode
        Me.cbComCode.SelectedValue = data.ComCode
        Me.cbOpType.SelectedValue = data.OpType
        Me.dtpSysDate.Value = data.SysDate
        Me.dtpStartTime.Value = data.StartTime
        Me.dtpExercTime.Value = data.ExercTime
        Me.dtpTradeLimitTime.Value = data.TradeLimitTime
        Me.tbPayoutRate.Text = If(data.PayoutRateEnabled, data.PayoutRate.ToString("######0.########"), "")
        Me.ProductEnabled = data.ProductEnabled
        Me.lblEnabled.Text = data.ProductEnabledName
        Me.lblProductBaseCode.Text = data.ProductBaseCode

        Me.tbExercPriceTimeSpan.Text = If(data.ExercPriceTimespanEnabled, data.ExercPriceTimespan, "")
        Me.cbExercPriceUnitType.SelectedValue = If(data.ExercPriceUnitTypeEnabled, data.ExercPriceUnitType, "")
        Me.tbExercPriceUnit.Text = If(data.ExercPriceUnitEnabled, data.ExercPriceUnit.ToString("######0.########"), "")
        Me.tbExercPriceSettings.Text = If(data.ExercPriceSettingsEnabled, data.ExercPriceSettings, "")
        Me.tbExceptExercPrice.Text = If(data.ExceptExercPriceEnabled, data.ExceptExercPrice, "")
        Me.cbExercPriceStatus.SelectedValue = data.ExercPriceStatus

        Me.tbVolRatio1Call.Text = If(data.VolatilityRatio1CallEnabled, data.VolatilityRatio1Call.ToString("######0.########"), "")
        Me.tbAskBidSpreadMinCall.Text = If(data.AskBidSpreadMinCallEnabled, (data.AskBidSpreadMinCall).ToString("######0.########"), "")
        Me.tbAskPriceMaxCall.Text = If(data.AskPriceMaxCallEnabled, data.AskPriceMaxCall.ToString("######0.########"), "")
        Me.tbAskPriceMinCall.Text = If(data.AskPriceMinCallEnabled, data.AskPriceMinCall.ToString("######0.########"), "")
        Me.tbBidPriceMaxCall.Text = If(data.BidPriceMaxCallEnabled, data.BidPriceMaxCall.ToString("######0.########"), "")
        Me.tbBidPriceMinCall.Text = If(data.BidPriceMinCallEnabled, data.BidPriceMinCall.ToString("######0.########"), "")

        Me.cbExercStatus.SelectedValue = data.ExercStatus
        Me.tbExercPriceRateSeq.Text = If(data.ExercPriceRateSeqEnabled, data.ExercPriceRateSeq, "")
        Me.tbExercPriceRate.Text = If(data.ExercPriceRateEnabled, data.ExercPriceRate.ToString("######0.########"), "")
        Me.tbExercRateSeq.Text = data.ExercRateSeq
        Me.tbExercRate.Text = IIf(data.ExercRateEnabled, data.ExercRate.ToString("######0.########"), "")

    End Sub

    Public Function getDataFromControl() As ProductData
        Dim ret As New ProductData

        ret.ProductCode = Me.lblCode.Text
        ret.ProductBaseCode = Me.lblProductBaseCode.Text
        ret.ComCode = Me.cbComCode.SelectedValue
        ret.OpType = Me.cbOpType.SelectedValue
        ret.SysDate = Me.dtpSysDate.Value
        ret.StartTime = Me.dtpStartTime.Value
        ret.ExercTime = Me.dtpExercTime.Value
        ret.TradeLimitTime = Me.dtpTradeLimitTime.Value
        If Me.tbPayoutRate.Text = "" Then
            ret.PayoutRateEnabled = False
        Else
            ret.PayoutRateEnabled = True
            ret.PayoutRate = Decimal.Parse(Me.tbPayoutRate.Text)
        End If
        'ret.ExercRateSeq = IIf(ret.ExercStatus = "2", Me.tbExercRateSeq.Text, "")
        'If ret.ExercStatus = "2" Then
        '    If tbExercRate.Enabled Then
        '        ret.ExercRateEnabled = False
        '    Else
        '        ret.ExercRateEnabled = True
        '        ret.ExercRate = Decimal.Parse(Me.tbExercRate.Text)
        '    End If
        'Else
        '    ret.ExercRateEnabled = False
        'End If

        If tbExercPriceTimeSpan.Text.Length = 0 Then
            ret.ExercPriceTimespanEnabled = False
        Else
            ret.ExercPriceTimespanEnabled = True
            ret.ExercPriceTimespan = Integer.Parse(tbExercPriceTimeSpan.Text)
        End If
        If cbExercPriceUnitType.SelectedValue Is Nothing OrElse cbExercPriceUnitType.SelectedValue = "" Then
            ret.ExercPriceUnitTypeEnabled = False
        Else
            ret.ExercPriceUnitTypeEnabled = True
            ret.ExercPriceUnitType = cbExercPriceUnitType.SelectedValue
        End If
        If tbExercPriceUnit.Text.Length = 0 Then
            ret.ExercPriceUnitEnabled = False
        Else
            ret.ExercPriceUnitEnabled = True
            ret.ExercPriceUnit = Decimal.Parse(tbExercPriceUnit.Text)
        End If
        If tbExercPriceSettings.Text.Length = 0 Then
            ret.ExercPriceSettingsEnabled = False
        Else
            ret.ExercPriceSettingsEnabled = True
            ret.ExercPriceSettings = tbExercPriceSettings.Text
        End If
        If tbExceptExercPrice.Text.Length = 0 Then
            ret.ExceptExercPriceEnabled = False
        Else
            ret.ExceptExercPriceEnabled = True
            ret.ExceptExercPrice = tbExceptExercPrice.Text
        End If
        ret.ExercPriceStatus = cbExercPriceStatus.SelectedValue

        If tbVolRatio1Call.Text.Length = 0 Then
            ret.VolatilityRatio1CallEnabled = False
        Else
            ret.VolatilityRatio1CallEnabled = True
            ret.VolatilityRatio1Call = Decimal.Parse(tbVolRatio1Call.Text)
        End If
        If tbAskBidSpreadMinCall.Text.Length = 0 Then
            ret.AskBidSpreadMinCallEnabled = False
        Else
            ret.AskBidSpreadMinCallEnabled = True
            ret.AskBidSpreadMinCall = Decimal.Parse(tbAskBidSpreadMinCall.Text)
        End If
        If tbAskPriceMaxCall.Text.Length = 0 Then
            ret.AskPriceMaxCallEnabled = False
        Else
            ret.AskPriceMaxCallEnabled = True
            ret.AskPriceMaxCall = Decimal.Parse(tbAskPriceMaxCall.Text)
        End If
        If tbAskPriceMinCall.Text.Length = 0 Then
            ret.AskPriceMinCallEnabled = False
        Else
            ret.AskPriceMinCallEnabled = True
            ret.AskPriceMinCall = Decimal.Parse(tbAskPriceMinCall.Text)
        End If
        If tbBidPriceMaxCall.Text.Length = 0 Then
            ret.BidPriceMaxCallEnabled = False
        Else
            ret.BidPriceMaxCallEnabled = True
            ret.BidPriceMaxCall = Decimal.Parse(tbBidPriceMaxCall.Text)
        End If
        If tbBidPriceMinCall.Text.Length = 0 Then
            ret.BidPriceMinCallEnabled = False
        Else
            ret.BidPriceMinCallEnabled = True
            ret.BidPriceMinCall = Decimal.Parse(tbBidPriceMinCall.Text)
        End If
        ret.ExercPriceStatus = cbExercPriceStatus.SelectedValue
        ret.ExercStatus = Me.cbExercStatus.SelectedValue
        If tbExercRateSeq.Text.Length = 0 Then
            ret.ExercRateSeqEnabled = False
        Else
            ret.ExercRateSeqEnabled = True
            ret.ExercRateSeq = Me.tbExercRateSeq.Text
        End If
        If tbExercRate.Text.Length = 0 Then
            ret.ExercRateEnabled = False
        Else
            ret.ExercRateEnabled = True
            ret.ExercRate = Decimal.Parse(Me.tbExercRate.Text)
        End If

        If tbExercPriceRateSeq.Text.Length = 0 Then
            ret.ExercPriceRateSeqEnabled = False
        Else
            ret.ExercPriceRateSeqEnabled = True
            ret.ExercPriceRateSeq = tbExercPriceRateSeq.Text
        End If
        If tbExercPriceRate.Text.Length = 0 Then
            ret.ExercPriceRateEnabled = False
        Else
            ret.ExercPriceRateEnabled = True
            ret.ExercPriceRate = Decimal.Parse(tbExercPriceRate.Text)
        End If

        Select Case FormModeStatus
            Case FormMode.REGIST, FormMode.REGISTCONF, FormMode.REGISTRUN
                ret.ProductEnabled = cbEnabled.SelectedValue
        End Select

        Return ret
    End Function

    Private Function checkInput() As Boolean
        '通貨ペア
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        'ペイアウト率
        If tbPayoutRate.Text <> "" Then
            If Not CheckUtil.RegExRate2.IsMatch(tbPayoutRate.Text) Then
                MessageBox.Show(Me, "ペイアウト率には0.01以上の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            Dim payoutRate As Decimal
            If Not Decimal.TryParse(tbPayoutRate.Text, payoutRate) Then
                MessageBox.Show(Me, "ペイアウト率には0.01以上の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If payoutRate < 0.01 Or payoutRate >= 1 Then
                MessageBox.Show(Me, "ペイアウト率には0.01以上の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '有効フラグ
        If FormModeStatus = FormMode.REGIST Then
            If cbEnabled.SelectedValue = "" Then
                MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        'オプション種別
        If cbOpType.SelectedValue = "" Then
            MessageBox.Show(Me, "オプション種別を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        '行使価格決定時間
        If tbExercPriceTimeSpan IsNot Nothing AndAlso tbExercPriceTimeSpan.Text.Length > 0 Then
            If Not CheckUtil.RegExInt.IsMatch(tbExercPriceTimeSpan.Text) Then
                MessageBox.Show(Me, "行使価格決定時間(秒)には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbExercPriceTimeSpan.Text < 10 Or tbExercPriceTimeSpan.Text > 600 Then
                MessageBox.Show(Me, "行使価格決定時間(秒)には10以上かつ600以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '行使価格刻み幅
        If tbExercPriceUnit IsNot Nothing AndAlso tbExercPriceUnit.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbExercPriceUnit.Text) Then
                MessageBox.Show(Me, "行使価格刻み幅には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            Dim ExercPriceUnit As Decimal
            If Not Decimal.TryParse(tbExercPriceUnit.Text, ExercPriceUnit) Then
                MessageBox.Show(Me, "行使価格刻み幅には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If ExercPriceUnit <= 0 Then
                MessageBox.Show(Me, "行使価格刻み幅には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        'ボラティリティレシオ１(Call)
        If tbVolRatio1Call IsNot Nothing AndAlso tbVolRatio1Call.Text.Length > 0 Then
            If Not CheckUtil.RegExSignRate.IsMatch(tbVolRatio1Call.Text) Then
                MessageBox.Show(Me, "ボラティリティレシオ１には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbVolRatio1Call.Text < 0.1 Or tbVolRatio1Call.Text > 10 Then
                MessageBox.Show(Me, "ボラティリティレシオ１には0.1以上かつ10以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Call)
        If tbAskBidSpreadMinCall IsNot Nothing AndAlso tbAskBidSpreadMinCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbAskBidSpreadMinCall.Text) Then
                MessageBox.Show(Me, "購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbAskBidSpreadMinCall.Text < 10 Or tbAskBidSpreadMinCall.Text > 500 Then
                MessageBox.Show(Me, "購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸには10以上かつ500以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最高購入価格(Call)
        If tbAskPriceMaxCall IsNot Nothing AndAlso tbAskPriceMaxCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbAskPriceMaxCall.Text) Then
                MessageBox.Show(Me, "最高購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbAskPriceMaxCall.Text < 999 Or tbAskPriceMaxCall.Text > 1000 Then
                MessageBox.Show(Me, "最高購入価格には999以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最低購入価格(Call)
        If tbAskPriceMinCall IsNot Nothing AndAlso tbAskPriceMinCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbAskPriceMinCall.Text) Then
                MessageBox.Show(Me, "最低購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbAskPriceMinCall.Text < 10 Or tbAskPriceMinCall.Text > 200 Then
                MessageBox.Show(Me, "最低購入価格には10以上かつ200以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最高清算価格(Call)
        ' 固定値のためチェック未使用
        If tbBidPriceMaxCall IsNot Nothing AndAlso tbBidPriceMaxCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbBidPriceMaxCall.Text) Then
                MessageBox.Show(Me, "最高清算価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbBidPriceMaxCall.Text < 0 Or tbBidPriceMaxCall.Text > 1000 Then
                MessageBox.Show(Me, "最高清算価格には0以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '最低清算価格(Call)
        ' 固定値のためチェック未使用
        If tbBidPriceMinCall IsNot Nothing AndAlso tbBidPriceMinCall.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbBidPriceMinCall.Text) Then
                MessageBox.Show(Me, "最低清算価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If tbBidPriceMinCall.Text < 0 Or tbBidPriceMinCall.Text > 1000 Then
                MessageBox.Show(Me, "最低清算価格には0以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '行使フラグ
        Dim ExercStatus As String = Me.cbExercStatus.SelectedValue
        If (ExercStatus Is Nothing) OrElse (ExercStatus.Length.Equals(0)) Then
            MessageBox.Show("行使フラグが未入力です。" & vbCrLf & "入力値を確認して下さい。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        '行使価格決定時Seq
        If tbExercPriceRateSeq IsNot Nothing AndAlso tbExercPriceRateSeq.Text.Length > 0 Then
            If tbExercPriceRateSeq.Text.Length < 17 Then
                MessageBox.Show(Me, "行使価格決定時Seqには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '行使価格決定時レート
        Dim com As CurrencyPairData = CurrencyPairService.GetData(cbComCode.SelectedValue)
        If tbExercPriceRate IsNot Nothing AndAlso tbExercPriceRate.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbExercPriceRate.Text) Then
                MessageBox.Show(Me, "行使価格決定時レートには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If Not CheckUtil.GetRegRateDecimalPlaces(com.DecimalPlaces).IsMatch(tbExercPriceRate.Text) Then
                MessageBox.Show(Me, String.Format("行使価格決定時レートは小数{0}桁以内で入力してください。", com.DecimalPlaces), My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            Dim exercPriceRate As Decimal
            If Not Decimal.TryParse(tbExercPriceRate.Text, exercPriceRate) Then
                MessageBox.Show(Me, "行使価格決定時レートには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If exercPriceRate < 0.00001 Or exercPriceRate > 9999 Then
                MessageBox.Show(Me, "行使価格決定時レートには0.00001以上かつ9999以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '行使時価格Seq
        If tbExercRateSeq IsNot Nothing AndAlso tbExercRateSeq.Text.Length > 0 Then
            If tbExercRateSeq.Text.Length < 17 Then
                MessageBox.Show(Me, "行使時価格Seqには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        '行使時価格
        If tbExercRate.Text.Length > 0 Then
            If Not CheckUtil.RegExRate.IsMatch(tbExercRate.Text) Then
                MessageBox.Show(Me, "行使時価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If Not CheckUtil.GetRegRateDecimalPlaces(com.DecimalPlaces).IsMatch(tbExercRate.Text) Then
                MessageBox.Show(Me, String.Format("行使時価格は小数{0}桁以内で入力してください。", com.DecimalPlaces), My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            Dim exercRate As Decimal
            If Not Decimal.TryParse(tbExercRate.Text, exercRate) Then
                MessageBox.Show(Me, "行使時価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If exercRate < 0.00001 Or exercRate > 9999 Then
                MessageBox.Show(Me, "行使時価格には0.00001以上かつ9999以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As ProductData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As ProductData = getDataFromControl()

        service.Update(data)
    End Sub

    Private Sub btnEnabled_Click(sender As System.Object, e As System.EventArgs) Handles btnEnabled.Click
        Dim dlg As New ProductEnabled With {.Code = Code}
        dlg.ShowDialog(Me)
        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub btnDisabled_Click(sender As System.Object, e As System.EventArgs) Handles btnDisabled.Click
        Dim dlg As New ProductDisabled With {.Code = Code}
        dlg.ShowDialog(Me)
        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub cbExercStatus_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbExercStatus.SelectedIndexChanged
        setFormMode(FormModeStatus)
    End Sub

    Private Function isExerc() As Boolean
        If cbExercStatus.SelectedValue = "2" Then
            Return True
        End If
        Return False
    End Function

    Private Sub btnBulkSet_Click(sender As System.Object, e As System.EventArgs) Handles btnBulkSet.Click
        Dim Unit As Decimal
        If Not Decimal.TryParse(tbBulkSetUnit.Text, Unit) Then
            Exit Sub
        End If
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(cbComCode.SelectedValue).DecimalPlaces
        tbExercPriceSettings.Text = LadderOption.buildExercPriceSettings(Unit, nudBulkSetCount.Value, DecimalPlaces)
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(cbComCode.SelectedValue).DecimalPlaces
        Dim Unit As Decimal = 5 / clsUtil.Power(DecimalPlaces)
        tbBulkSetUnit.Text = Unit.ToString(clsUtil.GetRateDPFormat(DecimalPlaces))
    End Sub

    Private Sub btnExercPricePreview_Click(sender As System.Object, e As System.EventArgs) Handles btnExercPricePreview.Click
        If Not checkInput() Then
            Return
        End If
        If cbComCode.SelectedValue IsNot Nothing AndAlso cbComCode.SelectedValue <> "" Then
            If CalcExercPriceList Is Nothing OrElse CalcExercPriceList.SourceForm Is Nothing Then
                CalcExercPriceList = New CalcExercPriceListProduct With {.SourceForm = Me, .ComCode = cbComCode.SelectedValue}
                CalcExercPriceList.MdiParent = Me.MdiParent
                CalcExercPriceList.Show()
            Else
                CalcExercPriceList.request()
            End If
        End If
    End Sub

    Private Sub tbBidPriceMaxCall_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMaxCall.TextChanged

        If tbBidPriceMaxCall.Text <> "" Then
            Dim bidPriceMin As Integer = MAX_PRICE - tbBidPriceMaxCall.Text
            tbBidPriceMinCall.Text = bidPriceMin
        End If

    End Sub
End Class