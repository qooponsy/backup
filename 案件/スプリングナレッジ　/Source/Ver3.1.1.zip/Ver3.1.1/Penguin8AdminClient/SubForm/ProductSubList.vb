﻿Public Class ProductSubList

    Public Code As String
    Public ComCode As String
    Public OptionType As String
    Public ExercTime As Date

    Private Table As DataTable

    Private WithEvents service As New ProductSubListService

    Private Sub ProductSubList_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Premium.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PAndL.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        btnRegist.Enabled = editable
        miEdit.Text = IIf(editable, "編集", "参照")

        setTotalPremium(0)
        setTotalPAndL(0)

        grid.Columns(2).HeaderText = "有効" + vbCrLf + "フラグ"
        grid.Columns(3).HeaderText = "行使価格" + vbCrLf + "設定"

        MainWindow.SubFormProductList = True
        LoadSettings()

        lblProductCode.Text = Code
        lblProductDeatails.Text = CurrencyPairService.GetData(ComCode).ComName + " " + OptionType + " " + Format(ExercTime, "yyyy/MM/dd hh:mm")

        initGrid()
        initEdit()

    End Sub

    Private Sub ProductSubLsit_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormProductList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductSubList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductSubList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductSubList_FormLocation)

    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductSubList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductSubList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductSubList_FormLocation)

    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("ProductSubCode", GetType(String))
        Table.Columns.Add("ProductEnabledCode", GetType(String))
        Table.Columns.Add("ProductEnabled", GetType(String))
        Table.Columns.Add("ExercPriceSetting", GetType(String))
        Table.Columns.Add("ExercRate", GetType(Decimal))
        Table.Columns.Add("ProductSubstatusCode", GetType(String))
        Table.Columns.Add("ProductSubstatus", GetType(String))
        Table.Columns.Add("Premium", GetType(Decimal))
        Table.Columns.Add("PAndL", GetType(Decimal))
        grid.DataSource = Table
    End Sub

    Private Sub initEdit()
        'cbCmpCode.SelectedValue = ""
        'lblTotalPAndL.Text = "0"
        'lblTotalPremium.Text = "0"

        service.ReadList(Code)
    End Sub

    ''' <summary>
    '''  [新規]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("ProductSubCode").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductSubCode").Value
        edit(code)
    End Sub


    Private Sub service_ReadCancel() Handles service.ReadListCancel
        Me.Close()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadListError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_ReadSuccess(list As List(Of ProductSubData)) Handles service.ReadListSuccess
        If list.Count = 0 OrElse list(0).ProductCode <> Code Then
            MessageBox.Show(Me, "銘柄コードの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list)
        End If
    End Sub

    Private Sub setTotalPAndL(TotalPAndL As Decimal)
        'lblTotalPAndL.Text = TotalPAndL.ToString(clsUtil.GetMoneyFormatDisp())
        'If TotalPAndL >= 0 Then
        '    lblTotalPAndL.ForeColor = Color.Black
        'Else
        '    lblTotalPAndL.ForeColor = Color.Red
        'End If
    End Sub

    Private Sub setTotalPremium(TotalPremium As Decimal)
        'lblTotalPremium.Text = TotalPremium.ToString(clsUtil.GetMoneyFormatDisp())
        'If TotalPremium >= 0 Then
        '    lblTotalPremium.ForeColor = Color.Black
        'Else
        '    lblTotalPremium.ForeColor = Color.Red
        'End If
    End Sub

    Private Sub setControlFromData(list As List(Of ProductSubData))
        Table.Clear()
        For Each item As ProductSubData In list
            Dim row As DataRow = Table.NewRow()
            row("ProductSubCode") = item.ProductSubCode
            row("ProductEnabledCode") = item.ProductEnabled
            row("ProductEnabled") = item.ProductEnabledName
            row("ExercPriceSetting") = item.ExercPriceSetting
            row("ExercRate") = item.ExercPrice
            row("ProductSubStatusCode") = item.ProductSubStatus
            row("ProductSubStatus") = item.ProductSubStatsuName
            'row("Premium") = item.Premium
            'row("PAndL") = item.PAndL
            row("Premium") = 0
            row("PAndL") = 0
            Table.Rows.Add(row)
        Next

    End Sub

    Private Sub regist()
        If MainWindow.SubFormProductSubForm Then
            ProductSubForm.Close()
        End If
        ProductSubForm.MdiParent = MainWindow
        ProductSubForm.Code = Code
        ProductSubForm.SubCode = ""
        ProductSubForm.ComCode = ComCode
        ProductSubForm.ProductDeatail = lblProductDeatails.Text
        ProductSubForm.Show()
    End Sub


    Private Sub edit(code As String)
        If MainWindow.SubFormProductSubForm Then
            ProductSubForm.Close()
        End If
        ProductSubForm.MdiParent = MainWindow
        ProductSubForm.Code = code
        ProductSubForm.SubCode = grid.SelectedRows(0).Cells("ProductSubCode").Value
        ProductSubForm.ComCode = ComCode
        ProductSubForm.ProductDeatail = lblProductDeatails.Text
        ProductSubForm.Show()
    End Sub

    Private Sub btnUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnUpdate.Click

        'ProductSubList_Load(Me, Nothing)

        service.ReadList(Code)

    End Sub
End Class