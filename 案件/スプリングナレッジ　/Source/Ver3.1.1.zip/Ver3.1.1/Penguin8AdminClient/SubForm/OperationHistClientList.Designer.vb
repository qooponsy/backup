﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OperationHistClientList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.tbClientIP = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbChannelName = New System.Windows.Forms.ComboBox()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbCode = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbDataType = New System.Windows.Forms.ComboBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.LogTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClientType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ChannelName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClientIP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Code = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogText = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.tbClientIP)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.cbChannelName)
        Me.Panel1.Controls.Add(Me.tbCustCode)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.tbCode)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cbDataType)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(915, 87)
        Me.Panel1.TabIndex = 0
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(776, 53)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 22
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(668, 53)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 21
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'tbClientIP
        '
        Me.tbClientIP.Location = New System.Drawing.Point(503, 63)
        Me.tbClientIP.Name = "tbClientIP"
        Me.tbClientIP.Size = New System.Drawing.Size(123, 19)
        Me.tbClientIP.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(449, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 12)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "IPアドレス"
        '
        'cbChannelName
        '
        Me.cbChannelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbChannelName.FormattingEnabled = True
        Me.cbChannelName.Location = New System.Drawing.Point(293, 12)
        Me.cbChannelName.Name = "cbChannelName"
        Me.cbChannelName.Size = New System.Drawing.Size(133, 20)
        Me.cbChannelName.TabIndex = 17
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(503, 12)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(123, 19)
        Me.tbCustCode.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(432, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(68, 12)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "委託者コード"
        '
        'tbCode
        '
        Me.tbCode.Location = New System.Drawing.Point(503, 37)
        Me.tbCode.Name = "tbCode"
        Me.tbCode.Size = New System.Drawing.Size(123, 19)
        Me.tbCode.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(468, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 12)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "コード"
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 38)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 8
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 38)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "～"
        '
        'cbDataType
        '
        Me.cbDataType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDataType.FormattingEnabled = True
        Me.cbDataType.Location = New System.Drawing.Point(154, 12)
        Me.cbDataType.Name = "cbDataType"
        Me.cbDataType.Size = New System.Drawing.Size(121, 20)
        Me.cbDataType.TabIndex = 1
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 12)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 432)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(915, 32)
        Me.pnlSearchAdd.TabIndex = 25
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(3, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 10
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(344, 201)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(226, 63)
        Me.lblNoData.TabIndex = 26
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LogTime, Me.SysDate, Me.CmpCode, Me.CmpName, Me.CustCode, Me.ClientType, Me.ChannelName, Me.ClientIP, Me.DataType, Me.DataTypeName, Me.LogType, Me.LogTypeName, Me.Code, Me.LogText})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 87)
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(915, 345)
        Me.grid.TabIndex = 27
        '
        'LogTime
        '
        Me.LogTime.DataPropertyName = "LogTime"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.Format = "yyyy/MM/dd HH:mm:ss.fff"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.LogTime.DefaultCellStyle = DataGridViewCellStyle2
        Me.LogTime.HeaderText = "日時"
        Me.LogTime.Name = "LogTime"
        Me.LogTime.ReadOnly = True
        Me.LogTime.Width = 130
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle3
        Me.SysDate.HeaderText = "システム営業日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 66
        '
        'CmpCode
        '
        Me.CmpCode.DataPropertyName = "CmpCode"
        Me.CmpCode.HeaderText = "会社コード"
        Me.CmpCode.Name = "CmpCode"
        Me.CmpCode.ReadOnly = True
        Me.CmpCode.Visible = False
        '
        'CmpName
        '
        Me.CmpName.DataPropertyName = "CmpName"
        Me.CmpName.HeaderText = "会社"
        Me.CmpName.Name = "CmpName"
        Me.CmpName.ReadOnly = True
        '
        'CustCode
        '
        Me.CustCode.DataPropertyName = "CustCode"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.CustCode.DefaultCellStyle = DataGridViewCellStyle4
        Me.CustCode.HeaderText = "委託者コード"
        Me.CustCode.Name = "CustCode"
        Me.CustCode.ReadOnly = True
        '
        'ClientType
        '
        Me.ClientType.DataPropertyName = "ClientType"
        Me.ClientType.HeaderText = "クライアントタイプ"
        Me.ClientType.Name = "ClientType"
        Me.ClientType.ReadOnly = True
        Me.ClientType.Visible = False
        '
        'ChannelName
        '
        Me.ChannelName.DataPropertyName = "ChannelName"
        Me.ChannelName.HeaderText = "チャネル名"
        Me.ChannelName.Name = "ChannelName"
        Me.ChannelName.ReadOnly = True
        '
        'ClientIP
        '
        Me.ClientIP.DataPropertyName = "ClientIP"
        Me.ClientIP.HeaderText = "IPアドレス"
        Me.ClientIP.Name = "ClientIP"
        Me.ClientIP.ReadOnly = True
        '
        'DataType
        '
        Me.DataType.DataPropertyName = "DataType"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataType.DefaultCellStyle = DataGridViewCellStyle5
        Me.DataType.HeaderText = "操作対象コード"
        Me.DataType.Name = "DataType"
        Me.DataType.ReadOnly = True
        Me.DataType.Visible = False
        '
        'DataTypeName
        '
        Me.DataTypeName.DataPropertyName = "DataTypeName"
        Me.DataTypeName.HeaderText = "操作対象"
        Me.DataTypeName.Name = "DataTypeName"
        Me.DataTypeName.ReadOnly = True
        '
        'LogType
        '
        Me.LogType.DataPropertyName = "LogType"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle6.Format = "######0.000#####"
        DataGridViewCellStyle6.NullValue = Nothing
        Me.LogType.DefaultCellStyle = DataGridViewCellStyle6
        Me.LogType.HeaderText = "操作種別コード"
        Me.LogType.Name = "LogType"
        Me.LogType.ReadOnly = True
        Me.LogType.Visible = False
        Me.LogType.Width = 78
        '
        'LogTypeName
        '
        Me.LogTypeName.DataPropertyName = "LogTypeName"
        Me.LogTypeName.HeaderText = "操作種別"
        Me.LogTypeName.Name = "LogTypeName"
        Me.LogTypeName.ReadOnly = True
        '
        'Code
        '
        Me.Code.DataPropertyName = "Code"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle7.NullValue = Nothing
        Me.Code.DefaultCellStyle = DataGridViewCellStyle7
        Me.Code.FillWeight = 160.0!
        Me.Code.HeaderText = "コード"
        Me.Code.Name = "Code"
        Me.Code.ReadOnly = True
        Me.Code.Width = 120
        '
        'LogText
        '
        Me.LogText.DataPropertyName = "LogText"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.LogText.DefaultCellStyle = DataGridViewCellStyle8
        Me.LogText.HeaderText = "ログ"
        Me.LogText.Name = "LogText"
        Me.LogText.ReadOnly = True
        Me.LogText.Width = 200
        '
        'OperationHistClientList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(915, 464)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "OperationHistClientList"
        Me.Text = "委託者操作ログ"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents cbCmpCode As ComboBox
    Friend WithEvents cbDataType As ComboBox
    Friend WithEvents tbCustCode As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents tbCode As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpToDateTime As DateTimePicker
    Friend WithEvents dtpFromDateTime As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCSV As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents tbClientIP As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cbChannelName As ComboBox
    Friend WithEvents pnlSearchAdd As Panel
    Friend WithEvents btnSearchAdd As Button
    Friend WithEvents lblNoData As Label
    Friend WithEvents sfdCsvFile As SaveFileDialog
    Private WithEvents grid As DataGridView
    Friend WithEvents LogTime As DataGridViewTextBoxColumn
    Friend WithEvents SysDate As DataGridViewTextBoxColumn
    Friend WithEvents CmpCode As DataGridViewTextBoxColumn
    Friend WithEvents CmpName As DataGridViewTextBoxColumn
    Friend WithEvents CustCode As DataGridViewTextBoxColumn
    Friend WithEvents ClientType As DataGridViewTextBoxColumn
    Friend WithEvents ChannelName As DataGridViewTextBoxColumn
    Friend WithEvents ClientIP As DataGridViewTextBoxColumn
    Friend WithEvents DataType As DataGridViewTextBoxColumn
    Friend WithEvents DataTypeName As DataGridViewTextBoxColumn
    Friend WithEvents LogType As DataGridViewTextBoxColumn
    Friend WithEvents LogTypeName As DataGridViewTextBoxColumn
    Friend WithEvents Code As DataGridViewTextBoxColumn
    Friend WithEvents LogText As DataGridViewTextBoxColumn
End Class
