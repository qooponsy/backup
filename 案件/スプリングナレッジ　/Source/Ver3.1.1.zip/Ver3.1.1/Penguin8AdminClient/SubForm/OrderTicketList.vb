﻿Imports System.Net
Imports System.Collections.Specialized
Public Class OrderTicketList

    Private WithEvents service As New OrderTicketService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1
    Private Count As Integer = 1000

    Private ConditionString As String = ""          ' 印刷用抽出条件文字列

    Private Sub OrderTicketList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        ExercPrice.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Price.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Premium.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PayoutPrice2.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Payout2.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PayoutPrice.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Payout.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        '初期値の設定
        Dim SysDate As DateTime = clsUtil.GetPrevWorkDay(SysStatusService.GetData().SysDate)
        dtpSysDateFrom.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
        dtpSysDateTo.Value = DateTime.Now
        dtpSysDateTo.Checked = False

        MainWindow.SubFormOrderTicketList = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub OrderTicketList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormOrderTicketList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.OrderTicketList_FormMaximized, _
            UserSettings.getInstance().DataSaved.OrderTicketList_FormSize, _
            UserSettings.getInstance().DataSaved.OrderTicketList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.OrderTicketList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.OrderTicketList_CmpCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.OrderTicketList_FormMaximized, _
            UserSettings.getInstance().DataSaved.OrderTicketList_FormSize, _
            UserSettings.getInstance().DataSaved.OrderTicketList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.OrderTicketList_Columns)
        UserSettings.getInstance().DataSaved.OrderTicketList_CmpCode = cbCmpCode.SelectedValue
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("OrderReqTime2", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("TradeSeq", GetType(String))
        Table.Columns.Add("SubSeqCount", GetType(String))
        Table.Columns.Add("CustCode", GetType(String))
        Table.Columns.Add("CustName", GetType(String))
        Table.Columns.Add("OrderReqTime", GetType(DateTime))
        Table.Columns.Add("Own", GetType(String))
        Table.Columns.Add("BuySell", GetType(String))
        Table.Columns.Add("TypeOfTrading", GetType(String))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("TradeType", GetType(String))
        Table.Columns.Add("TradeTypeName", GetType(String))
        Table.Columns.Add("ExercPrice", GetType(Decimal))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("Classification", GetType(String))
        Table.Columns.Add("ExecutionDevision", GetType(String))
        Table.Columns.Add("TradeTime", GetType(DateTime))
        Table.Columns.Add("Lot", GetType(Integer))
        Table.Columns.Add("Price", GetType(Decimal))
        Table.Columns.Add("Premium", GetType(Decimal))
        Table.Columns.Add("AbandReqTime", GetType(DateTime))
        Table.Columns.Add("ExercProcTime2", GetType(DateTime))
        Table.Columns.Add("ExercProcTime", GetType(DateTime))
        Table.Columns.Add("PayoutPrice2", GetType(Decimal))
        Table.Columns.Add("Payout2", GetType(Decimal))
        Table.Columns.Add("PayoutPrice", GetType(Decimal))
        Table.Columns.Add("Payout", GetType(Decimal))
        'Table.Columns.Add("TradeStatus", GetType(String))  'TradeStatusは名称をDBに保持してるのでCodeは不要
        Table.Columns.Add("TradeStatusName", GetType(String))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of OrderTicketData))
        For Each item As OrderTicketData In list
            Dim row As DataRow = Table.NewRow()
            row("OrderReqTime2") = IIf(item.OrderReqTime2Enabled, item.OrderReqTime2, DBNull.Value)
            row("SysDate") = item.SysDate
            row("TradeSeq") = item.TradeSeq
            row("SubSeqCount") = item.SubSeqCount
            row("CustCode") = item.CustCode
            row("CustName") = item.CustName
            row("OrderReqTime") = IIf(item.OrderReqTimeEnabled, item.OrderReqTime, DBNull.Value)
            row("Own") = item.Own
            row("BuySell") = item.BuySell
            row("TypeOfTrading") = item.TypeOfTrading
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("TradeType") = item.TradeType
            row("TradeTypeName") = item.TradeTypeName
            row("ExercPrice") = IIf(item.ExercPriceEnabled, item.ExercPrice, DBNull.Value)
            row("ExercTime") = IIf(item.ExercTimeEnabled, item.ExercTime, DBNull.Value)
            row("Classification") = item.Classification
            row("ExecutionDevision") = item.ExecutionDevision
            row("TradeTime") = IIf(item.TradeTimeEnabled, item.TradeTime, DBNull.Value)
            row("Lot") = IIf(item.LotEnabled, item.Lot, DBNull.Value)
            row("Price") = IIf(item.PriceEnabled, item.Price, DBNull.Value)
            row("Premium") = item.Premium
            row("AbandReqTime") = IIf(item.AbandReqTimeEnabled, item.AbandReqTime, DBNull.Value)
            row("ExercProcTime2") = IIf(item.ExercProcTime2Enabled, item.ExercProcTime2, DBNull.Value)
            row("ExercProcTime") = IIf(item.ExercProcTimeEnabled, item.ExercProcTime, DBNull.Value)
            row("PayoutPrice2") = IIf(item.PayoutPrice2Enabled, item.PayoutPrice2, DBNull.Value)
            row("Payout2") = IIf(item.Payout2Enabled, item.Payout2, DBNull.Value)
            row("PayoutPrice") = IIf(item.PayoutPriceEnabled, item.PayoutPrice, DBNull.Value)
            row("Payout") = IIf(item.PayoutEnabled, item.Payout, DBNull.Value)
            'row("TradeStatus") = item.TradeStatus  'TradeStatusは名称をDBに保持してるのでCodeは不要
            row("TradeStatusName") = item.TradeStatusName
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        '----------------------------------------------------------------------
        ' 印刷用　抽出条件編集
        '----------------------------------------------------------------------
        Dim SortKey As String = ""

        ConditionString = ""
        If dtpSysDateFrom.Checked Or dtpSysDateTo.Checked Then
            If dtpSysDateFrom.Checked Then
                ConditionString = ConditionString & dtpSysDateFrom.Value.ToString("yyyy/MM/dd")
            End If
            ConditionString = ConditionString & "　～　"
            If dtpSysDateTo.Checked Then
                ConditionString = ConditionString & dtpSysDateTo.Value.ToString("yyyy/MM/dd")
            End If
        End If
        ConditionString = ConditionString & vbTab
        ConditionString = ConditionString & "　　会社:" & cbCmpCode.Text

        service.ReadList(dtpSysDateFrom.Checked,
                         dtpSysDateFrom.Value,
                         dtpSysDateTo.Checked,
                         dtpSysDateTo.Value,
                         cbCmpCode.SelectedValue,
                         Count,
                         Start,
                         SortKey)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of OrderTicketData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 And list.Count = 0)
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlorderticket"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)

                '不要な項目を取り除く
                For Each col As List(Of String) In columnList
                    '通貨ペアコード
                    If col(0) = "ComCode" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next
                For Each col As List(Of String) In columnList
                    '種別コード
                    If col(0) = "TradeType" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next

                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub
    
    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).DataPropertyName
                Case "ExercPrice"
                    Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComCode").Value
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub
    
    '--------------------------------------------------------------------------
    ' 印刷 2012/06/28 H.S
    '--------------------------------------------------------------------------
    Private Sub btnPrint_Click(sender As System.Object, e As System.EventArgs) Handles btnPrint.Click
        Dim PrtUtil As PrintUtil

        Try
            PrtUtil = New PrintUtil()
            PrtUtil.PrintReport(grid, PrintUtil.Reports.OrderTicketList, ConditionString)
        Catch ex As Exception
        End Try
    End Sub

End Class