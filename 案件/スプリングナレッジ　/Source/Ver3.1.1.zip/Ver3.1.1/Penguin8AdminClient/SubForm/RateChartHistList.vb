﻿Imports System.Net
Imports System.Collections.Specialized
Imports System.Text

Public Class RateChartHistList

    Private WithEvents service As New RateChartHistService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1

    Private Sub RateChartHistForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        If UserTypeManager.IsAdmin(SessionService.UserType) Then
            '新規登録は管理者のみ
            btnRegist.Enabled = True
        Else
            btnRegist.Enabled = False
        End If
        miEdit.Text = IIf(UserTypeManager.IsEdit(SessionService.UserType), "編集", "参照")

        '通貨ペアドロップダウンリストの作成
        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Me.cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        'チャート種別ドロップダウンリストの作成
        Me.cbChartType.DisplayMember = "ChartTypeName"
        Me.cbChartType.ValueMember = "ChartType"
        Me.cbChartType.DataSource = ChartTypeService.GetListWithAll()

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        dtpFromDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day, SysStaticsService.SysDateStartTime.Hours, SysStaticsService.SysDateStartTime.Minutes, SysStaticsService.SysDateStartTime.Seconds)
        dtpToDateTime.Value = DateTime.Now
        dtpToDateTime.Checked = False

        MainWindow.SubFormRateChartHist = True
        LoadSettings()

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub RateChartHistForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormRateChartHist = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RateChartHistList_FormMaximized, _
            UserSettings.getInstance().DataSaved.RateChartHistList_FormSize, _
            UserSettings.getInstance().DataSaved.RateChartHistList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RateChartHistList_Columns)
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.RateChartHistList_ComCode
        chkEnabled.Checked = UserSettings.getInstance().DataSaved.RateChartHistList_Enabled
        cbChartType.SelectedValue = UserSettings.getInstance().DataSaved.RateChartHistList_ChartType
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RateChartHistList_FormMaximized, _
            UserSettings.getInstance().DataSaved.RateChartHistList_FormSize, _
            UserSettings.getInstance().DataSaved.RateChartHistList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RateChartHistList_Columns)
        UserSettings.getInstance().DataSaved.RateChartHistList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.RateChartHistList_Enabled = chkEnabled.Checked
        UserSettings.getInstance().DataSaved.RateChartHistList_ChartType = cbChartType.SelectedValue
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("RateChartSeq", GetType(String))
        Table.Columns.Add("gEnabled", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("ChartType", GetType(String))
        Table.Columns.Add("RateSeq", GetType(String))
        Table.Columns.Add("RateChartTime", GetType(DateTime))
        Table.Columns.Add("OpenRate", GetType(Decimal))
        Table.Columns.Add("HighRate", GetType(Decimal))
        Table.Columns.Add("LowRate", GetType(Decimal))
        Table.Columns.Add("CloseRate", GetType(Decimal))
        Table.Columns.Add("CloseTime", GetType(DateTime))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of RateChartHistData))
        For Each item As RateChartHistData In list
            Dim row As DataRow = Table.NewRow()
            row("RateChartSeq") = item.RateChartSeq
            row("gEnabled") = item.EnabledName
            row("ComName") = item.ComCode
            row("ChartType") = ChartTypeService.getName(item.ChartType)
            row("RateSeq") = item.RateSeq
            row("RateChartTime") = item.RateChartTime
            row("OpenRate") = item.OpenRate
            row("HighRate") = item.HighRate
            row("LowRate") = item.LowRate
            row("CloseRate") = item.CloseRate
            row("CloseTime") = item.CloseTime
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSarchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [CSV]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnCSV_Click(sender As System.Object, e As System.EventArgs) Handles BtnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlRateChart"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub request()
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim EnabledFlg As String = IIf(Me.chkEnabled.Checked, "1", "")
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ChartType As String = Me.cbChartType.SelectedValue

        service.ReadList(EnabledFlg, ComCode, FromDateTime, ToDateTime, ChartType, "", Start)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of RateChartHistData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

    Private Function ChartTypeName(ByRef ChartType As String) As String
        Select Case ChartType
            Case "1分足"
                ChartType = "1"
        End Select
        Return ChartType
    End Function

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("RateChartSeq").Value
        edit(code)
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("RateChartSeq").Value
        edit(code)
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormRateChartForm Then
            RateChartForm.Close()
        End If
        RateChartForm.MdiParent = MainWindow
        RateChartForm.Code = code
        RateChartForm.Show()
    End Sub

    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        Dim code As String = ""
        edit(code)
    End Sub

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).DataPropertyName
                Case "OpenRate", "HighRate", "LowRate", "CloseRate"
                    Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComName").Value
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

End Class