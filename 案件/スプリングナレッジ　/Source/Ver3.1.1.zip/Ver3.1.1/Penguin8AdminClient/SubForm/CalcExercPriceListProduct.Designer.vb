﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CalcExercPriceListProduct
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nudRate = New System.Windows.Forms.NumericUpDown()
        Me.btnReflesh = New System.Windows.Forms.Button()
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.ColExercPriceSetting = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColExercRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColProductSubstatusCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColProductSubstatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.nudRate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.nudRate)
        Me.Panel1.Controls.Add(Me.btnReflesh)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(305, 40)
        Me.Panel1.TabIndex = 17
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 12)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "レート"
        '
        'nudRate
        '
        Me.nudRate.DecimalPlaces = 3
        Me.nudRate.Increment = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.nudRate.Location = New System.Drawing.Point(52, 10)
        Me.nudRate.Maximum = New Decimal(New Integer() {9999999, 0, 0, 196608})
        Me.nudRate.Name = "nudRate"
        Me.nudRate.Size = New System.Drawing.Size(79, 19)
        Me.nudRate.TabIndex = 3
        Me.nudRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudRate.Value = New Decimal(New Integer() {99955, 0, 0, 196608})
        '
        'btnReflesh
        '
        Me.btnReflesh.Location = New System.Drawing.Point(202, 5)
        Me.btnReflesh.Name = "btnReflesh"
        Me.btnReflesh.Size = New System.Drawing.Size(89, 29)
        Me.btnReflesh.TabIndex = 2
        Me.btnReflesh.Text = "更新"
        Me.btnReflesh.UseVisualStyleBackColor = True
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(53, 117)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(203, 63)
        Me.lblNoData.TabIndex = 19
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ColExercPriceSetting, Me.ColExercRate, Me.ColProductSubstatusCode, Me.ColProductSubstatus})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 40)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(305, 410)
        Me.grid.TabIndex = 20
        '
        'ColExercPriceSetting
        '
        Me.ColExercPriceSetting.DataPropertyName = "ExercPriceSetting"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ColExercPriceSetting.DefaultCellStyle = DataGridViewCellStyle7
        Me.ColExercPriceSetting.HeaderText = "行使価格設定"
        Me.ColExercPriceSetting.Name = "ColExercPriceSetting"
        Me.ColExercPriceSetting.ReadOnly = True
        Me.ColExercPriceSetting.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'ColExercRate
        '
        Me.ColExercRate.DataPropertyName = "ExercRate"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.NullValue = """"""
        Me.ColExercRate.DefaultCellStyle = DataGridViewCellStyle8
        Me.ColExercRate.HeaderText = "行使価格"
        Me.ColExercRate.Name = "ColExercRate"
        Me.ColExercRate.ReadOnly = True
        Me.ColExercRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'ColProductSubstatusCode
        '
        Me.ColProductSubstatusCode.DataPropertyName = "ProductSubstatusCode"
        Me.ColProductSubstatusCode.HeaderText = "ステータス(Code)"
        Me.ColProductSubstatusCode.Name = "ColProductSubstatusCode"
        Me.ColProductSubstatusCode.ReadOnly = True
        Me.ColProductSubstatusCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ColProductSubstatusCode.Visible = False
        '
        'ColProductSubstatus
        '
        Me.ColProductSubstatus.DataPropertyName = "ProductSubstatus"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ColProductSubstatus.DefaultCellStyle = DataGridViewCellStyle9
        Me.ColProductSubstatus.HeaderText = "ステータス"
        Me.ColProductSubstatus.Name = "ColProductSubstatus"
        Me.ColProductSubstatus.ReadOnly = True
        Me.ColProductSubstatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'CalcExercPriceListProductBase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(305, 450)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CalcExercPriceListProductBase"
        Me.Text = "行使価格プレビュー"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.nudRate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnReflesh As System.Windows.Forms.Button
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents nudRate As System.Windows.Forms.NumericUpDown
    Friend WithEvents ColExercPriceSetting As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColExercRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColProductSubstatusCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColProductSubstatus As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
