﻿Public Class PricingSim2

    Const PRICE_COUNT As Integer = 9

    Private WithEvents service As New RateChartHistService

    Private Table As DataTable

    Private chkChart(PRICE_COUNT - 1) As CheckBox
    Private nudExercPrice(PRICE_COUNT - 1) As NumericUpDown
    Private tbVolRatio1Call(PRICE_COUNT - 1) As TextBox
    Private tbVolRatio1Put(PRICE_COUNT - 1) As TextBox
    Private tbCallPutSpread(PRICE_COUNT - 1) As TextBox
    Private tbVolRatio2Call(PRICE_COUNT - 1) As TextBox
    Private tbVolRatio2Put(PRICE_COUNT - 1) As TextBox
    Private tbVolSmileACall(PRICE_COUNT - 1) As TextBox
    Private tbVolSmileAPut(PRICE_COUNT - 1) As TextBox
    Private tbVolSmileBCall(PRICE_COUNT - 1) As TextBox
    Private tbVolSmileBPut(PRICE_COUNT - 1) As TextBox
    Private tbVolSpreadCall(PRICE_COUNT - 1) As TextBox
    Private tbVolSpreadPut(PRICE_COUNT - 1) As TextBox
    Private tbAskFeePriceCall(PRICE_COUNT - 1) As TextBox
    Private tbAskFeePricePut(PRICE_COUNT - 1) As TextBox
    Private tbAskBidSpreadMinCall(PRICE_COUNT - 1) As TextBox
    Private tbAskBidSpreadMinPut(PRICE_COUNT - 1) As TextBox
    Private tbBidFeeRateCall(PRICE_COUNT - 1) As TextBox
    Private tbBidFeeRatePut(PRICE_COUNT - 1) As TextBox
    Private tbAskPriceMaxCall(PRICE_COUNT - 1) As TextBox
    Private tbAskPriceMinCall(PRICE_COUNT - 1) As TextBox
    Private tbBidPriceMaxCall(PRICE_COUNT - 1) As TextBox
    Private tbBidPriceMinCall(PRICE_COUNT - 1) As TextBox
    Private tbAskPriceMaxPut(PRICE_COUNT - 1) As TextBox
    Private tbAskPriceMinPut(PRICE_COUNT - 1) As TextBox
    Private tbBidPriceMaxPut(PRICE_COUNT - 1) As TextBox
    Private tbBidPriceMinPut(PRICE_COUNT - 1) As TextBox
    Private tbInterestRate(PRICE_COUNT - 1) As TextBox
    Private tbSwapRate(PRICE_COUNT - 1) As TextBox
    Private tbHV(PRICE_COUNT - 1) As TextBox
    Private chkChartView(PRICE_COUNT - 1) As CheckBox

    Private Sub PricingSim2_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setControlArray()

        setChart()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()
        cbComCode.SelectedIndex = 0

        dtpExercTime.Value = New DateTime(DDDService.ServerTime.Year, DDDService.ServerTime.Month, DDDService.ServerTime.Day, DDDService.ServerTime.Hour, 0, 0)

        Table = New DataTable
        Table.Columns.Add("RateChartTime", GetType(DateTime))
        Table.Columns.Add("OpenRate", GetType(Decimal))
        Table.Columns.Add("HighRate", GetType(Decimal))
        Table.Columns.Add("LowRate", GetType(Decimal))
        Table.Columns.Add("CloseRate", GetType(Decimal))

        For fa As Integer = 1 To PRICE_COUNT
            Table.Columns.Add("PriceCallAskHigh" & fa, GetType(Decimal))
            Table.Columns.Add("PriceCallAskLow" & fa, GetType(Decimal))
            Table.Columns.Add("PriceCallBidHigh" & fa, GetType(Decimal))
            Table.Columns.Add("PriceCallBidLow" & fa, GetType(Decimal))
            Table.Columns.Add("PricePutAskHigh" & fa, GetType(Decimal))
            Table.Columns.Add("PricePutAskLow" & fa, GetType(Decimal))
            Table.Columns.Add("PricePutBidHigh" & fa, GetType(Decimal))
            Table.Columns.Add("PricePutBidLow" & fa, GetType(Decimal))
        Next

        chartRate.DataSource = Table
        chartRate.DataBind()

        chartPrice.DataSource = Table
        chartPrice.DataBind()

        'PricingSim2Settings.Save(New PricingSim2Settings)

        LoadSettings()

        setPriceChartView()
        setChartColor()

        request()
    End Sub

    Private Sub PricingSim2_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        Dim settings As PricingSim2Settings = PricingSim2Settings.Load()
        [clsUtil].LoadSubFormSettings(Me, settings.FormMaximized, settings.FormSize, settings.FormLocation)

        SplitContainer1.SplitterDistance = settings.SplitterDistance
        cbComCode.SelectedValue = settings.ComCode
        chkVolatility.Checked = settings.Volatility
        chkCallAskHigh.Checked = settings.CallAskHigh
        chkCallAskLow.Checked = settings.CallAskLow
        chkCallBidHigh.Checked = settings.CallBidHigh
        chkCallBidLow.Checked = settings.CallBidLow
        chkPutAskHigh.Checked = settings.PutAskHigh
        chkPutAskLow.Checked = settings.PutAskLow
        chkPutBidHigh.Checked = settings.PutBidHigh
        chkPutBidLow.Checked = settings.PutBidLow
        chkCallAskHighView.Checked = settings.CallAskHighView
        chkCallAskLowView.Checked = settings.CallAskLowView
        chkCallBidHighView.Checked = settings.CallBidHighView
        chkCallBidLowView.Checked = settings.CallBidLowView
        chkPutAskHighView.Checked = settings.PutAskHighView
        chkPutAskLowView.Checked = settings.PutAskLowView
        chkPutBidHighView.Checked = settings.PutBidHighView
        chkPutBidLowView.Checked = settings.PutBidLowView
        chkSettingMulti.Checked = settings.SettingMulti
        rbColorType.Checked = settings.ColorType
        If Not rbColorType.Checked Then
            rbColorPrice.Checked = True
        End If
        For fa As Integer = 0 To PRICE_COUNT - 1
            chkChart(fa).Checked = settings.Chart(fa)
            chkChartView(fa).Checked = settings.ChartView(fa)
        Next
        tbVolRatio1Call(0).Text = settings.VolRatio1Call(0)
        tbVolRatio1Put(0).Text = settings.VolRatio1Put(0)
        tbCallPutSpread(0).Text = settings.CallPutSpread(0)
        tbVolRatio2Call(0).Text = settings.VolRatio2Call(0)
        tbVolRatio2Put(0).Text = settings.VolRatio2Put(0)
        tbVolSmileACall(0).Text = settings.VolSmileACall(0)
        tbVolSmileAPut(0).Text = settings.VolSmileAPut(0)
        tbVolSmileBCall(0).Text = settings.VolSmileBCall(0)
        tbVolSmileBPut(0).Text = settings.VolSmileBPut(0)
        tbVolSpreadCall(0).Text = settings.VolSpreadCall(0)
        tbVolSpreadPut(0).Text = settings.VolSpreadPut(0)
        tbAskFeePriceCall(0).Text = settings.AskFeePriceCall(0)
        tbAskFeePricePut(0).Text = settings.AskFeePricePut(0)
        tbAskBidSpreadMinCall(0).Text = settings.AskBidSpreadMinCall(0)
        tbAskBidSpreadMinPut(0).Text = settings.AskBidSpreadMinPut(0)
        tbBidFeeRateCall(0).Text = settings.BidFeeRateCall(0)
        tbBidFeeRatePut(0).Text = settings.BidFeeRatePut(0)
        tbAskPriceMaxCall(0).Text = settings.AskPriceMaxCall(0)
        tbAskPriceMinCall(0).Text = settings.AskPriceMinCall(0)
        tbBidPriceMaxCall(0).Text = settings.BidPriceMaxCall(0)
        tbBidPriceMinCall(0).Text = settings.BidPriceMinCall(0)
        tbAskPriceMaxPut(0).Text = settings.AskPriceMaxPut(0)
        tbAskPriceMinPut(0).Text = settings.AskPriceMinPut(0)
        tbBidPriceMaxPut(0).Text = settings.BidPriceMaxPut(0)
        tbBidPriceMinPut(0).Text = settings.BidPriceMinPut(0)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        Dim settings As New PricingSim2Settings
        clsUtil.SaveFormSettings(Me, settings.FormMaximized, settings.FormSize, settings.FormLocation)

        settings.SplitterDistance = SplitContainer1.SplitterDistance
        settings.ComCode = cbComCode.SelectedValue
        settings.Volatility = chkVolatility.Checked
        settings.CallAskHigh = chkCallAskHigh.Checked
        settings.CallAskLow = chkCallAskLow.Checked
        settings.CallBidHigh = chkCallBidHigh.Checked
        settings.CallBidLow = chkCallBidLow.Checked
        settings.PutAskHigh = chkPutAskHigh.Checked
        settings.PutAskLow = chkPutAskLow.Checked
        settings.PutBidHigh = chkPutBidHigh.Checked
        settings.PutBidLow = chkPutBidLow.Checked
        settings.CallAskHighView = chkCallAskHighView.Checked
        settings.CallAskLowView = chkCallAskLowView.Checked
        settings.CallBidHighView = chkCallBidHighView.Checked
        settings.CallBidLowView = chkCallBidLowView.Checked
        settings.PutAskHighView = chkPutAskHighView.Checked
        settings.PutAskLowView = chkPutAskLowView.Checked
        settings.PutBidHighView = chkPutBidHighView.Checked
        settings.PutBidLowView = chkPutBidLowView.Checked
        settings.SettingMulti = chkSettingMulti.Checked
        settings.ColorType = rbColorType.Checked
        For fa As Integer = 0 To PRICE_COUNT - 1
            settings.Chart(fa) = chkChart(fa).Checked
            settings.ChartView(fa) = chkChartView(fa).Checked
        Next
        settings.VolRatio1Call(0) = tbVolRatio1Call(0).Text
        settings.VolRatio1Put(0) = tbVolRatio1Put(0).Text
        settings.CallPutSpread(0) = tbCallPutSpread(0).Text
        settings.VolRatio2Call(0) = tbVolRatio2Call(0).Text
        settings.VolRatio2Put(0) = tbVolRatio2Put(0).Text
        settings.VolSmileACall(0) = tbVolSmileACall(0).Text
        settings.VolSmileAPut(0) = tbVolSmileAPut(0).Text
        settings.VolSmileBCall(0) = tbVolSmileBCall(0).Text
        settings.VolSmileBPut(0) = tbVolSmileBPut(0).Text
        settings.VolSpreadCall(0) = tbVolSpreadCall(0).Text
        settings.VolSpreadPut(0) = tbVolSpreadPut(0).Text
        settings.AskFeePriceCall(0) = tbAskFeePriceCall(0).Text
        settings.AskFeePricePut(0) = tbAskFeePricePut(0).Text
        settings.AskBidSpreadMinCall(0) = tbAskBidSpreadMinCall(0).Text
        settings.AskBidSpreadMinPut(0) = tbAskBidSpreadMinPut(0).Text
        settings.BidFeeRateCall(0) = tbBidFeeRateCall(0).Text
        settings.BidFeeRatePut(0) = tbBidFeeRatePut(0).Text
        settings.AskPriceMaxCall(0) = tbAskPriceMaxCall(0).Text
        settings.AskPriceMinCall(0) = tbAskPriceMinCall(0).Text
        settings.BidPriceMaxCall(0) = tbBidPriceMaxCall(0).Text
        settings.BidPriceMinCall(0) = tbBidPriceMinCall(0).Text
        settings.AskPriceMaxPut(0) = tbAskPriceMaxPut(0).Text
        settings.AskPriceMinPut(0) = tbAskPriceMinPut(0).Text
        settings.BidPriceMaxPut(0) = tbBidPriceMaxPut(0).Text
        settings.BidPriceMinPut(0) = tbBidPriceMinPut(0).Text

        PricingSim2Settings.Save(settings)
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        If cbComCode.SelectedValue Is Nothing OrElse cbComCode.SelectedValue = "" Then
            Exit Sub
        End If
        Dim ComCode As String = cbComCode.SelectedValue
        Dim Rate As Decimal = DDDService.GetLastRate(ComCode).Rate
        Dim DecimalPlaces As Integer = CurrencyPairService.GetData(ComCode).DecimalPlaces
        Dim IncUnit As Decimal = 1 / clsUtil.Power(DecimalPlaces)
        Dim HV As String = CalcParamService.GetData(ComCode).Volatility.ToString("0.##############")
        Dim InterestRate As String = (CalcParamService.GetData(ComCode).InterestRate * 100).ToString("0.############")
        Dim SwapRate As String = (CalcParamService.GetData(ComCode).SwapRate * 100).ToString("0.############")

        For fa As Integer = 1 To PRICE_COUNT
            nudExercPrice(fa - 1).DecimalPlaces = DecimalPlaces
            nudExercPrice(fa - 1).Value = Rate
            nudExercPrice(fa - 1).Increment = IncUnit
        Next
        tbHV(0).Text = HV
        tbInterestRate(0).Text = InterestRate
        tbSwapRate(0).Text = SwapRate
    End Sub

    Private Sub request()
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim FromDateTime As String = dtpExercTime.Value.AddHours(-Me.nudTerm.Value).AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm")
        Dim ToDateTime As String = dtpExercTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm")
        Dim ChartType As String = "1"

        service.ReadList("1", ComCode, FromDateTime, ToDateTime, ChartType, "", 1)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of RateChartHistData), existNextFlag As Boolean) Handles service.ReadSuccess

        If list.Count > 0 Then
            Dim ComCode As String = cbComCode.SelectedValue
            Dim CP As CurrencyPairData = CurrencyPairService.GetData(ComCode)

            Table.Clear()
            Dim ratemax As Decimal = Decimal.MinValue
            Dim ratemin As Decimal = Decimal.MaxValue

            For Each item As RateChartHistData In list
                Dim row As DataRow = Table.NewRow()
                row("RateChartTime") = item.RateChartTime
                row("OpenRate") = item.OpenRate
                row("HighRate") = item.HighRate
                row("LowRate") = item.LowRate
                row("CloseRate") = item.CloseRate

                Table.Rows.Add(row)

                If ratemax < item.HighRate Then ratemax = item.HighRate
                If ratemin > item.LowRate Then ratemin = item.LowRate
            Next
            chartRate.DataBind()
            chartRate.ChartAreas(0).AxisY.Maximum = Math.Round(ratemax + (ratemax - ratemin) * 0.05, CP.DecimalPlaces - 1)
            chartRate.ChartAreas(0).AxisY.Minimum = Math.Round(ratemin - (ratemax - ratemin) * 0.05, CP.DecimalPlaces - 1)

            calcPrice()
        End If

    End Sub

    Private Sub calcPrice()
        Dim opt As New LadderOption
        Dim pricemax As Decimal = Decimal.MinValue
        Dim pricemin As Decimal = Decimal.MaxValue

        opt.ExercTime = dtpExercTime.Value

        If chkCallAskHigh.Checked Then
            chkCallAskHighView.Enabled = True
        Else
            chkCallAskHighView.Checked = False
            chkCallAskHighView.Enabled = False
        End If
        If chkCallAskLow.Checked Then
            chkCallAskLowView.Enabled = True
        Else
            chkCallAskLowView.Checked = False
            chkCallAskLowView.Enabled = False
        End If
        If chkCallBidHigh.Checked Then
            chkCallBidHighView.Enabled = True
        Else
            chkCallBidHighView.Checked = False
            chkCallBidHighView.Enabled = False
        End If
        If chkCallBidLow.Checked Then
            chkCallBidLowView.Enabled = True
        Else
            chkCallBidLowView.Checked = False
            chkCallBidLowView.Enabled = False
        End If
        If chkPutAskHigh.Checked Then
            chkPutAskHighView.Enabled = True
        Else
            chkPutAskHighView.Checked = False
            chkPutAskHighView.Enabled = False
        End If
        If chkPutAskLow.Checked Then
            chkPutAskLowView.Enabled = True
        Else
            chkPutAskLowView.Checked = False
            chkPutAskLowView.Enabled = False
        End If
        If chkPutBidHigh.Checked Then
            chkPutBidHighView.Enabled = True
        Else
            chkPutBidHighView.Checked = False
            chkPutBidHighView.Enabled = False
        End If
        If chkPutBidLow.Checked Then
            chkPutBidLowView.Enabled = True
        Else
            chkPutBidLowView.Checked = False
            chkPutBidLowView.Enabled = False
        End If

        For fa As Integer = 1 To PRICE_COUNT
            If chkChart(fa - 1).Checked Then
                chkChartView(fa - 1).Enabled = True
            Else
                chkChartView(fa - 1).Checked = False
                chkChartView(fa - 1).Enabled = False
                Continue For
            End If

            Dim SettingIndex As Integer = fa - 1
            If Not chkSettingMulti.Checked Then
                SettingIndex = 0
            End If

            If Not Decimal.TryParse(tbInterestRate(SettingIndex).Text, opt.InterestRate) Then Continue For
            opt.InterestRate /= 100
            If Not Decimal.TryParse(tbSwapRate(SettingIndex).Text, opt.SwapRate) Then Continue For
            opt.SwapRate /= 100
            If Not Decimal.TryParse(tbHV(SettingIndex).Text, opt.HistVol) Then Continue For
            If Not Decimal.TryParse(tbVolRatio1Call(SettingIndex).Text, opt.VolatilityRatio1Call) Then Continue For
            If Not Decimal.TryParse(tbVolRatio1Put(SettingIndex).Text, opt.VolatilityRatio1Put) Then Continue For
            If Not Decimal.TryParse(tbCallPutSpread(SettingIndex).Text, opt.VolatilitySpread) Then Continue For
            If Not Decimal.TryParse(tbVolRatio2Call(SettingIndex).Text, opt.VolatilityRatio2Call) Then Continue For
            If Not Decimal.TryParse(tbVolRatio2Put(SettingIndex).Text, opt.VolatilityRatio2Put) Then Continue For
            If Not Decimal.TryParse(tbVolSmileACall(SettingIndex).Text, opt.VolatilitySmileACall) Then Continue For
            If Not Decimal.TryParse(tbVolSmileAPut(SettingIndex).Text, opt.VolatilitySmileAPut) Then Continue For
            If Not Decimal.TryParse(tbVolSmileBCall(SettingIndex).Text, opt.VolatilitySmileBCall) Then Continue For
            If Not Decimal.TryParse(tbVolSmileBPut(SettingIndex).Text, opt.VolatilitySmileBPut) Then Continue For
            If Not Decimal.TryParse(tbVolSpreadCall(SettingIndex).Text, opt.VolatilitySpreadITMCall) Then Continue For
            opt.VolatilitySpreadOTMCall = opt.VolatilitySpreadITMCall
            If Not Decimal.TryParse(tbVolSpreadPut(SettingIndex).Text, opt.VolatilitySpreadITMPut) Then Continue For
            opt.VolatilitySpreadOTMPut = opt.VolatilitySpreadITMPut
            If Not Decimal.TryParse(tbAskFeePriceCall(SettingIndex).Text, opt.AskFeePriceCall) Then Continue For
            If Not Decimal.TryParse(tbAskBidSpreadMinCall(SettingIndex).Text, opt.AskBidSpreadMinCall) Then Continue For
            If Not Decimal.TryParse(tbBidFeeRateCall(SettingIndex).Text, opt.BidFeeRateCall) Then Continue For
            opt.BidFeeRateCall /= 100
            If Not Decimal.TryParse(tbAskFeePricePut(SettingIndex).Text, opt.AskFeePricePut) Then Continue For
            If Not Decimal.TryParse(tbAskBidSpreadMinPut(SettingIndex).Text, opt.AskBidSpreadMinPut) Then Continue For
            If Not Decimal.TryParse(tbBidFeeRatePut(SettingIndex).Text, opt.BidFeeRatePut) Then Continue For
            opt.BidFeeRatePut /= 100
            If Not Decimal.TryParse(tbAskPriceMaxCall(SettingIndex).Text, opt.AskPriceMaxCall) Then Continue For
            If Not Decimal.TryParse(tbAskPriceMinCall(SettingIndex).Text, opt.AskPriceMinCall) Then Continue For
            If Not Decimal.TryParse(tbBidPriceMaxCall(SettingIndex).Text, opt.BidPriceMaxCall) Then Continue For
            If Not Decimal.TryParse(tbBidPriceMinCall(SettingIndex).Text, opt.BidPriceMinCall) Then Continue For
            If Not Decimal.TryParse(tbAskPriceMaxPut(SettingIndex).Text, opt.AskPriceMaxPut) Then Continue For
            If Not Decimal.TryParse(tbAskPriceMinPut(SettingIndex).Text, opt.AskPriceMinPut) Then Continue For
            If Not Decimal.TryParse(tbBidPriceMaxPut(SettingIndex).Text, opt.BidPriceMaxPut) Then Continue For
            If Not Decimal.TryParse(tbBidPriceMinPut(SettingIndex).Text, opt.BidPriceMinPut) Then Continue For

            opt.ExercPrice = nudExercPrice(fa - 1).Value

            For Each row In Table.Rows
                opt.CalcTime = row("RateChartTime")

                opt.Rate = row("HighRate")

                opt.CalcVolatility()
                opt.CalcPrice()

                If Not chkVolatility.Checked Then
                    If chkCallAskHigh.Checked Then
                        row("PriceCallAskHigh" & fa) = opt.AskCall
                        If pricemax < opt.AskCall Then pricemax = opt.AskCall
                        If pricemin > opt.AskCall Then pricemin = opt.AskCall
                    End If

                    If chkCallBidHigh.Checked Then
                        row("PriceCallBidHigh" & fa) = opt.BidCall
                        If pricemax < opt.BidCall Then pricemax = opt.BidCall
                        If pricemin > opt.BidCall Then pricemin = opt.BidCall
                    End If

                    If chkPutAskLow.Checked Then
                        row("PricePutAskLow" & fa) = opt.AskPut
                        If pricemax < opt.AskPut Then pricemax = opt.AskPut
                        If pricemin > opt.AskPut Then pricemin = opt.AskPut
                    End If

                    If chkPutBidLow.Checked Then
                        row("PricePutBidLow" & fa) = opt.BidPut
                        If pricemax < opt.BidPut Then pricemax = opt.BidPut
                        If pricemin > opt.BidPut Then pricemin = opt.BidPut
                    End If
                Else
                    If chkCallAskHigh.Checked Then
                        row("PriceCallAskHigh" & fa) = opt.VolAskCall
                        If pricemax < opt.VolAskCall Then pricemax = opt.VolAskCall
                        If pricemin > opt.VolAskCall Then pricemin = opt.VolAskCall
                    End If

                    If chkCallBidHigh.Checked Then
                        row("PriceCallBidHigh" & fa) = opt.VolBidCall
                        If pricemax < opt.VolBidCall Then pricemax = opt.VolBidCall
                        If pricemin > opt.VolBidCall Then pricemin = opt.VolBidCall
                    End If

                    If chkPutAskLow.Checked Then
                        row("PricePutAskLow" & fa) = opt.VolAskPut
                        If pricemax < opt.VolAskPut Then pricemax = opt.VolAskPut
                        If pricemin > opt.VolAskPut Then pricemin = opt.VolAskPut
                    End If

                    If chkPutBidLow.Checked Then
                        row("PricePutBidLow" & fa) = opt.VolBidPut
                        If pricemax < opt.VolBidPut Then pricemax = opt.VolBidPut
                        If pricemin > opt.VolBidPut Then pricemin = opt.VolBidPut
                    End If
                End If

                opt.Rate = row("LowRate")

                opt.CalcVolatility()
                opt.CalcPrice()

                If Not chkVolatility.Checked Then
                    If chkCallAskLow.Checked Then
                        row("PriceCallAskLow" & fa) = opt.AskCall
                        If pricemax < opt.AskCall Then pricemax = opt.AskCall
                        If pricemin > opt.AskCall Then pricemin = opt.AskCall
                    End If

                    If chkCallBidLow.Checked Then
                        row("PriceCallBidLow" & fa) = opt.BidCall
                        If pricemax < opt.BidCall Then pricemax = opt.BidCall
                        If pricemin > opt.BidCall Then pricemin = opt.BidCall
                    End If

                    If chkPutAskHigh.Checked Then
                        row("PricePutAskHigh" & fa) = opt.AskPut
                        If pricemax < opt.AskPut Then pricemax = opt.AskPut
                        If pricemin > opt.AskPut Then pricemin = opt.AskPut
                    End If

                    If chkPutBidHigh.Checked Then
                        row("PricePutBidHigh" & fa) = opt.BidPut
                        If pricemax < opt.BidPut Then pricemax = opt.BidPut
                        If pricemin > opt.BidPut Then pricemin = opt.BidPut
                    End If
                Else
                    If chkCallAskLow.Checked Then
                        row("PriceCallAskLow" & fa) = opt.VolAskCall
                        If pricemax < opt.VolAskCall Then pricemax = opt.VolAskCall
                        If pricemin > opt.VolAskCall Then pricemin = opt.VolAskCall
                    End If

                    If chkCallBidLow.Checked Then
                        row("PriceCallBidLow" & fa) = opt.VolBidCall
                        If pricemax < opt.VolBidCall Then pricemax = opt.VolBidCall
                        If pricemin > opt.VolBidCall Then pricemin = opt.VolBidCall
                    End If

                    If chkPutAskHigh.Checked Then
                        row("PricePutAskHigh" & fa) = opt.VolAskPut
                        If pricemax < opt.VolAskPut Then pricemax = opt.VolAskPut
                        If pricemin > opt.VolAskPut Then pricemin = opt.VolAskPut
                    End If

                    If chkPutBidHigh.Checked Then
                        row("PricePutBidHigh" & fa) = opt.VolBidPut
                        If pricemax < opt.VolBidPut Then pricemax = opt.VolBidPut
                        If pricemin > opt.VolBidPut Then pricemin = opt.VolBidPut
                    End If
                End If

            Next
        Next

        chartPrice.DataBind()

        If pricemax <> pricemin Then
            If Not chkVolatility.Checked Then
                If pricemax <> Decimal.MinValue Then chartPrice.ChartAreas(0).AxisY.Maximum = Math.Min(1000, Math.Round(pricemax + (pricemax - pricemin) * 0.05))
                If pricemin <> Decimal.MaxValue Then chartPrice.ChartAreas(0).AxisY.Minimum = Math.Max(0, Math.Round(pricemin - (pricemax - pricemin) * 0.05))
            Else
                If pricemax <> Decimal.MinValue Then chartPrice.ChartAreas(0).AxisY.Maximum = Math.Min(1, pricemax + (pricemax - pricemin) * 0.05)
                If pricemin <> Decimal.MaxValue Then chartPrice.ChartAreas(0).AxisY.Minimum = Math.Max(0, pricemin - (pricemax - pricemin) * 0.05)
            End If
        End If
    End Sub

    Private Sub btnRateChart_Click(sender As System.Object, e As System.EventArgs) Handles btnRateChart.Click
        request()
    End Sub

    Private Sub btnRate_Click(sender As System.Object, e As System.EventArgs) Handles btnRate.Click
        Dim NowRate As Decimal = DDDService.GetLastRate(cbComCode.SelectedValue).Rate
        For fa = 1 To PRICE_COUNT
            nudExercPrice(fa - 1).Value = NowRate
        Next
    End Sub

    Private Sub btnCalc_Click(sender As System.Object, e As System.EventArgs) Handles btnCalc.Click
        calcPrice()
    End Sub

    Private Sub chkPriceChart_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles _
        chkCallAskHighView.CheckedChanged,
        chkCallAskLowView.CheckedChanged,
        chkCallBidHighView.CheckedChanged,
        chkCallBidLowView.CheckedChanged,
        chkPutAskHighView.CheckedChanged,
        chkPutAskLowView.CheckedChanged,
        chkPutBidHighView.CheckedChanged,
        chkPutBidLowView.CheckedChanged,
        chkChartView1.CheckedChanged,
        chkChartView2.CheckedChanged,
        chkChartView3.CheckedChanged,
        chkChartView4.CheckedChanged,
        chkChartView5.CheckedChanged,
        chkChartView6.CheckedChanged,
        chkChartView7.CheckedChanged,
        chkChartView8.CheckedChanged,
        chkChartView9.CheckedChanged

        setPriceChartView()
    End Sub

    Private Sub setPriceChartView()
        For fa As Integer = 1 To PRICE_COUNT
            If chkChartView(fa - 1) Is Nothing Then Continue For
            chartPrice.Series("PriceCallAskHigh" & fa).Enabled = chkChartView(fa - 1).Checked And chkCallAskHighView.Checked
            chartPrice.Series("PriceCallAskLow" & fa).Enabled = chkChartView(fa - 1).Checked And chkCallAskLowView.Checked
            chartPrice.Series("PriceCallBidHigh" & fa).Enabled = chkChartView(fa - 1).Checked And chkCallBidHighView.Checked
            chartPrice.Series("PriceCallBidLow" & fa).Enabled = chkChartView(fa - 1).Checked And chkCallBidLowView.Checked
            chartPrice.Series("PricePutAskHigh" & fa).Enabled = chkChartView(fa - 1).Checked And chkPutAskHighView.Checked
            chartPrice.Series("PricePutAskLow" & fa).Enabled = chkChartView(fa - 1).Checked And chkPutAskLowView.Checked
            chartPrice.Series("PricePutBidHigh" & fa).Enabled = chkChartView(fa - 1).Checked And chkPutBidHighView.Checked
            chartPrice.Series("PricePutBidLow" & fa).Enabled = chkChartView(fa - 1).Checked And chkPutBidLowView.Checked
        Next
    End Sub

    Private Sub rbColorType_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbColorType.CheckedChanged
        setChartColor()
    End Sub

    Private Sub setChartColor()
        If rbColorType.Checked Then
            For fa As Integer = 1 To PRICE_COUNT
                chartPrice.Series("PriceCallAskHigh" & fa).Color = Color.FromArgb(255, &HFF, 0, 0)
                chartPrice.Series("PriceCallAskLow" & fa).Color = Color.FromArgb(255, &HBB, 0, 0)
                chartPrice.Series("PriceCallBidHigh" & fa).Color = Color.FromArgb(255, &HFF, &H88, 0)
                chartPrice.Series("PriceCallBidLow" & fa).Color = Color.FromArgb(255, &HBB, &H88, 0)
                chartPrice.Series("PricePutAskHigh" & fa).Color = Color.FromArgb(255, 0, 0, &HFF)
                chartPrice.Series("PricePutAskLow" & fa).Color = Color.FromArgb(255, &H88, 0, &HFF)
                chartPrice.Series("PricePutBidHigh" & fa).Color = Color.FromArgb(255, 0, &H88, &HFF)
                chartPrice.Series("PricePutBidLow" & fa).Color = Color.FromArgb(255, &H88, &H88, &HFF)
            Next
        Else
            Dim PriceColor() As Color = {
                Color.FromArgb(255, &HFF, 0, 0),
                Color.FromArgb(255, &HFF, &HAA, 0),
                Color.FromArgb(255, &HAA, &HAA, 0),
                Color.FromArgb(255, &HAA, &HFF, 0),
                Color.FromArgb(255, &H0, &HFF, 0),
                Color.FromArgb(255, &H0, &HFF, &HAA),
                Color.FromArgb(255, &H0, &HAA, &HAA),
                Color.FromArgb(255, &H0, &HAA, &HFF),
                Color.FromArgb(255, &H0, 0, &HFF)
            }
            For fa As Integer = 1 To PRICE_COUNT
                chartPrice.Series("PriceCallAskHigh" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PriceCallAskLow" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PriceCallBidHigh" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PriceCallBidLow" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PricePutAskHigh" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PricePutAskLow" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PricePutBidHigh" & fa).Color = PriceColor(fa - 1)
                chartPrice.Series("PricePutBidLow" & fa).Color = PriceColor(fa - 1)
            Next
        End If
    End Sub



    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As New List(Of List(Of String))

        Me.sfdCsvFile.FileName = "pricingchart"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor

                columnList.Add(New List(Of String) From {"RateChartTime", "RateChartTime"})
                columnList.Add(New List(Of String) From {"HighRate", "HighRate"})
                columnList.Add(New List(Of String) From {"LowRate", "LowRate"})

                For fa As Integer = 1 To PRICE_COUNT
                    If Not chkChartView(fa - 1).Checked Then Continue For
                    If chkCallAskHighView.Checked Then columnList.Add(New List(Of String) From {"PriceCallAskHigh" & fa, "PriceCallAskHigh" & fa})
                    If chkCallAskLowView.Checked Then columnList.Add(New List(Of String) From {"PriceCallAskLow" & fa, "PriceCallAskLow" & fa})
                    If chkCallBidHighView.Checked Then columnList.Add(New List(Of String) From {"PriceCallBidHigh" & fa, "PriceCallBidHigh" & fa})
                    If chkCallBidLowView.Checked Then columnList.Add(New List(Of String) From {"PriceCallBidLow" & fa, "PriceCallBidLow" & fa})
                    If chkPutAskHighView.Checked Then columnList.Add(New List(Of String) From {"PricePutAskHigh" & fa, "PricePutAskHigh" & fa})
                    If chkPutAskLowView.Checked Then columnList.Add(New List(Of String) From {"PricePutAskLow" & fa, "PricePutAskLow" & fa})
                    If chkPutBidHighView.Checked Then columnList.Add(New List(Of String) From {"PricePutBidHigh" & fa, "PricePutBidHigh" & fa})
                    If chkPutBidLowView.Checked Then columnList.Add(New List(Of String) From {"PricePutBidLow" & fa, "PricePutBidLow" & fa})
                Next

                'CSV作成
                [clsUtil].SaveToCsv(Table, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    ''' <summary>
    ''' コントロールの配列化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub setControlArray()
        chkChart(0) = chkChart1
        chkChart(1) = chkChart2
        chkChart(2) = chkChart3
        chkChart(3) = chkChart4
        chkChart(4) = chkChart5
        chkChart(5) = chkChart6
        chkChart(6) = chkChart7
        chkChart(7) = chkChart8
        chkChart(8) = chkChart9

        chkChartView(0) = chkChartView1
        chkChartView(1) = chkChartView2
        chkChartView(2) = chkChartView3
        chkChartView(3) = chkChartView4
        chkChartView(4) = chkChartView5
        chkChartView(5) = chkChartView6
        chkChartView(6) = chkChartView7
        chkChartView(7) = chkChartView8
        chkChartView(8) = chkChartView9

        nudExercPrice(0) = nudExercPrice1
        nudExercPrice(1) = nudExercPrice2
        nudExercPrice(2) = nudExercPrice3
        nudExercPrice(3) = nudExercPrice4
        nudExercPrice(4) = nudExercPrice5
        nudExercPrice(5) = nudExercPrice6
        nudExercPrice(6) = nudExercPrice7
        nudExercPrice(7) = nudExercPrice8
        nudExercPrice(8) = nudExercPrice9

        tbVolRatio1Call(0) = tbVolRatio1Call1

        tbVolRatio1Put(0) = tbVolRatio1Put1

        tbCallPutSpread(0) = tbCallPutSpread1

        tbVolRatio2Call(0) = tbVolRatio2Call1

        tbVolRatio2Put(0) = tbVolRatio2Put1

        tbVolSmileACall(0) = tbVolSmileACall1

        tbVolSmileAPut(0) = tbVolSmileAPut1

        tbVolSmileBCall(0) = tbVolSmileBCall1

        tbVolSmileBPut(0) = tbVolSmileBPut1

        tbVolSpreadCall(0) = tbVolSpreadCall1

        tbVolSpreadPut(0) = tbVolSpreadPut1

        tbAskFeePriceCall(0) = tbAskFeePriceCall1

        tbAskBidSpreadMinCall(0) = tbAskBidSpreadMinCall1

        tbBidFeeRateCall(0) = tbBidFeeRateCall1

        tbAskFeePricePut(0) = tbAskFeePricePut1

        tbAskBidSpreadMinPut(0) = tbAskBidSpreadMinPut1

        tbBidFeeRatePut(0) = tbBidFeeRatePut1

        tbAskPriceMaxCall(0) = tbAskPriceMaxCall1

        tbAskPriceMinCall(0) = tbAskPriceMinCall1

        tbBidPriceMaxCall(0) = tbBidPriceMaxCall1

        tbBidPriceMinCall(0) = tbBidPriceMinCall1

        tbAskPriceMaxPut(0) = tbAskPriceMaxPut1

        tbAskPriceMinPut(0) = tbAskPriceMinPut1

        tbBidPriceMaxPut(0) = tbBidPriceMaxPut1

        tbBidPriceMinPut(0) = tbBidPriceMinPut1

        tbInterestRate(0) = tbInterestRate1

        tbSwapRate(0) = tbSwapRate1

        tbHV(0) = tbHV1
    End Sub

    ''' <summary>
    ''' チャート設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub setChart()
        For fa As Integer = 1 To PRICE_COUNT
            Dim SeriesPriceCallAskHigh As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallAskHigh = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallAskHigh.ChartArea = "ChartArea1"
            SeriesPriceCallAskHigh.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPriceCallAskHigh.Name = "PriceCallAskHigh" & fa
            SeriesPriceCallAskHigh.XValueMember = "RateChartTime"
            SeriesPriceCallAskHigh.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPriceCallAskHigh.YValueMembers = "PriceCallAskHigh" & fa
            SeriesPriceCallAskHigh.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPriceCallAskHigh)

            Dim SeriesPriceCallAskLow As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallAskLow = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallAskLow.ChartArea = "ChartArea1"
            SeriesPriceCallAskLow.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPriceCallAskLow.Name = "PriceCallAskLow" & fa
            SeriesPriceCallAskLow.XValueMember = "RateChartTime"
            SeriesPriceCallAskLow.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPriceCallAskLow.YValueMembers = "PriceCallAskLow" & fa
            SeriesPriceCallAskLow.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPriceCallAskLow)

            Dim SeriesPriceCallBidHigh As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallBidHigh = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallBidHigh.ChartArea = "ChartArea1"
            SeriesPriceCallBidHigh.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPriceCallBidHigh.Name = "PriceCallBidHigh" & fa
            SeriesPriceCallBidHigh.XValueMember = "RateChartTime"
            SeriesPriceCallBidHigh.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPriceCallBidHigh.YValueMembers = "PriceCallBidHigh" & fa
            SeriesPriceCallBidHigh.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPriceCallBidHigh)

            Dim SeriesPriceCallBidLow As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallBidLow = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPriceCallBidLow.ChartArea = "ChartArea1"
            SeriesPriceCallBidLow.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPriceCallBidLow.Name = "PriceCallBidLow" & fa
            SeriesPriceCallBidLow.XValueMember = "RateChartTime"
            SeriesPriceCallBidLow.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPriceCallBidLow.YValueMembers = "PriceCallBidLow" & fa
            SeriesPriceCallBidLow.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPriceCallBidLow)

            Dim SeriesPricePutAskHigh As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutAskHigh = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutAskHigh.ChartArea = "ChartArea1"
            SeriesPricePutAskHigh.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPricePutAskHigh.Name = "PricePutAskHigh" & fa
            SeriesPricePutAskHigh.XValueMember = "RateChartTime"
            SeriesPricePutAskHigh.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPricePutAskHigh.YValueMembers = "PricePutAskHigh" & fa
            SeriesPricePutAskHigh.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPricePutAskHigh)

            Dim SeriesPricePutAskLow As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutAskLow = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutAskLow.ChartArea = "ChartArea1"
            SeriesPricePutAskLow.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPricePutAskLow.Name = "PricePutAskLow" & fa
            SeriesPricePutAskLow.XValueMember = "RateChartTime"
            SeriesPricePutAskLow.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPricePutAskLow.YValueMembers = "PricePutAskLow" & fa
            SeriesPricePutAskLow.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPricePutAskLow)

            Dim SeriesPricePutBidHigh As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutBidHigh = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutBidHigh.ChartArea = "ChartArea1"
            SeriesPricePutBidHigh.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPricePutBidHigh.Name = "PricePutBidHigh" & fa
            SeriesPricePutBidHigh.XValueMember = "RateChartTime"
            SeriesPricePutBidHigh.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPricePutBidHigh.YValueMembers = "PricePutBidHigh" & fa
            SeriesPricePutBidHigh.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPricePutBidHigh)

            Dim SeriesPricePutBidLow As System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutBidLow = New System.Windows.Forms.DataVisualization.Charting.Series
            SeriesPricePutBidLow.ChartArea = "ChartArea1"
            SeriesPricePutBidLow.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
            SeriesPricePutBidLow.Name = "PricePutBidLow" & fa
            SeriesPricePutBidLow.XValueMember = "RateChartTime"
            SeriesPricePutBidLow.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
            SeriesPricePutBidLow.YValueMembers = "PricePutBidLow" & fa
            SeriesPricePutBidLow.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
            chartPrice.Series.Add(SeriesPricePutBidLow)
        Next
    End Sub

    Private Sub tbBidFeeRateCall1_TextChanged(sender As Object, e As EventArgs) Handles tbBidFeeRateCall1.TextChanged
        tbBidFeeRatePut1.Text = tbBidFeeRateCall1.Text
    End Sub

    Private Sub tbBidPriceMaxCall1_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMaxCall1.TextChanged
        tbBidPriceMaxPut1.Text = tbBidPriceMaxCall1.Text
    End Sub

    Private Sub tbBidPriceMinCall1_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMinCall1.TextChanged
        tbBidPriceMinPut1.Text = tbBidPriceMinCall1.Text
    End Sub

End Class
