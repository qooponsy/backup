﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PricingSim1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.colExercPriceSetting = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceAskCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceBidCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceAskPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceBidPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolAskCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolBidCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolAskPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolBidPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.miSelectAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.tbPriceUnit = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMinPut = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMaxPut = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMinCall = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.tbAskPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tbAskBidSpreadMinPut = New System.Windows.Forms.TextBox()
        Me.tbAskBidSpreadMinCall = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbAskFeePricePut = New System.Windows.Forms.TextBox()
        Me.tbAskFeePriceCall = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tbSwapRate = New System.Windows.Forms.TextBox()
        Me.tbInterestRate = New System.Windows.Forms.TextBox()
        Me.tbHV = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.nudExercPriceUnit = New System.Windows.Forms.NumericUpDown()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.nudExercPriceRate = New System.Windows.Forms.NumericUpDown()
        Me.chkAuto = New System.Windows.Forms.CheckBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.nudRate = New System.Windows.Forms.NumericUpDown()
        Me.dtpLife = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbVolSmileBPut = New System.Windows.Forms.TextBox()
        Me.tbVolSmileAPut = New System.Windows.Forms.TextBox()
        Me.tbVolSmileBCall = New System.Windows.Forms.TextBox()
        Me.tbVolSmileACall = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.tbCallPutSpread = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tbBulkSetUnit = New System.Windows.Forms.TextBox()
        Me.nudBulkSetCount = New System.Windows.Forms.NumericUpDown()
        Me.btnBulkSet = New System.Windows.Forms.Button()
        Me.tbBidFeeRatePut = New System.Windows.Forms.TextBox()
        Me.lblPutName1 = New System.Windows.Forms.Label()
        Me.lblCallName1 = New System.Windows.Forms.Label()
        Me.tbAskPriceMinPut = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMaxPut = New System.Windows.Forms.TextBox()
        Me.tbVolSpreadPut = New System.Windows.Forms.TextBox()
        Me.tbVolRatio2Put = New System.Windows.Forms.TextBox()
        Me.tbVolRatio1Put = New System.Windows.Forms.TextBox()
        Me.tbBidFeeRateCall = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.tbAskPriceMinCall = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.tbBidPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.tbVolSpreadCall = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.cbExercPriceUnitType = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.tbVolRatio2Call = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.tbVolRatio1Call = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbExercPriceSettings = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.nudExercPriceUnit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPriceRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudBulkSetCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colExercPriceSetting, Me.colExercPrice, Me.colPriceAskCall, Me.colPriceBidCall, Me.colPriceAskPut, Me.colPriceBidPut, Me.colVolAskCall, Me.colVolBidCall, Me.colVolAskPut, Me.colVolBidPut})
        Me.grid.ContextMenuStrip = Me.cmGrid
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 339)
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(581, 330)
        Me.grid.StandardTab = True
        Me.grid.TabIndex = 17
        '
        'colExercPriceSetting
        '
        Me.colExercPriceSetting.DataPropertyName = "ExercPriceSetting"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colExercPriceSetting.DefaultCellStyle = DataGridViewCellStyle2
        Me.colExercPriceSetting.HeaderText = "行使価格設定"
        Me.colExercPriceSetting.Name = "colExercPriceSetting"
        Me.colExercPriceSetting.ReadOnly = True
        Me.colExercPriceSetting.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercPriceSetting.Width = 61
        '
        'colExercPrice
        '
        Me.colExercPrice.DataPropertyName = "ExercPrice"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colExercPrice.DefaultCellStyle = DataGridViewCellStyle3
        Me.colExercPrice.HeaderText = "行使価格"
        Me.colExercPrice.Name = "colExercPrice"
        Me.colExercPrice.ReadOnly = True
        Me.colExercPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercPrice.Width = 61
        '
        'colPriceAskCall
        '
        Me.colPriceAskCall.DataPropertyName = "PriceAskCall"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colPriceAskCall.DefaultCellStyle = DataGridViewCellStyle4
        Me.colPriceAskCall.HeaderText = "購入\nCall"
        Me.colPriceAskCall.Name = "colPriceAskCall"
        Me.colPriceAskCall.ReadOnly = True
        Me.colPriceAskCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceAskCall.Width = 46
        '
        'colPriceBidCall
        '
        Me.colPriceBidCall.DataPropertyName = "PriceBidCall"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colPriceBidCall.DefaultCellStyle = DataGridViewCellStyle5
        Me.colPriceBidCall.HeaderText = "清算\nCall"
        Me.colPriceBidCall.Name = "colPriceBidCall"
        Me.colPriceBidCall.ReadOnly = True
        Me.colPriceBidCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceBidCall.Width = 46
        '
        'colPriceAskPut
        '
        Me.colPriceAskPut.DataPropertyName = "PriceAskPut"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colPriceAskPut.DefaultCellStyle = DataGridViewCellStyle6
        Me.colPriceAskPut.HeaderText = "購入\nPut"
        Me.colPriceAskPut.Name = "colPriceAskPut"
        Me.colPriceAskPut.ReadOnly = True
        Me.colPriceAskPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceAskPut.Width = 46
        '
        'colPriceBidPut
        '
        Me.colPriceBidPut.DataPropertyName = "PriceBidPut"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colPriceBidPut.DefaultCellStyle = DataGridViewCellStyle7
        Me.colPriceBidPut.HeaderText = "清算\nPut"
        Me.colPriceBidPut.Name = "colPriceBidPut"
        Me.colPriceBidPut.ReadOnly = True
        Me.colPriceBidPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceBidPut.Width = 46
        '
        'colVolAskCall
        '
        Me.colVolAskCall.DataPropertyName = "VolAskCall"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "0.00000000"
        Me.colVolAskCall.DefaultCellStyle = DataGridViewCellStyle8
        Me.colVolAskCall.HeaderText = "評価Vol\n購入\nCall"
        Me.colVolAskCall.Name = "colVolAskCall"
        Me.colVolAskCall.ReadOnly = True
        Me.colVolAskCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolAskCall.Width = 62
        '
        'colVolBidCall
        '
        Me.colVolBidCall.DataPropertyName = "VolBidCall"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "0.00000000"
        Me.colVolBidCall.DefaultCellStyle = DataGridViewCellStyle9
        Me.colVolBidCall.HeaderText = "評価Vol\n清算\nCall"
        Me.colVolBidCall.Name = "colVolBidCall"
        Me.colVolBidCall.ReadOnly = True
        Me.colVolBidCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolBidCall.Width = 62
        '
        'colVolAskPut
        '
        Me.colVolAskPut.DataPropertyName = "VolAskPut"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "0.00000000"
        Me.colVolAskPut.DefaultCellStyle = DataGridViewCellStyle10
        Me.colVolAskPut.HeaderText = "評価Vol\n購入\nPut"
        Me.colVolAskPut.Name = "colVolAskPut"
        Me.colVolAskPut.ReadOnly = True
        Me.colVolAskPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolAskPut.Width = 62
        '
        'colVolBidPut
        '
        Me.colVolBidPut.DataPropertyName = "VolBidPut"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle11.Format = "0.00000000"
        Me.colVolBidPut.DefaultCellStyle = DataGridViewCellStyle11
        Me.colVolBidPut.HeaderText = "評価Vol\n清算\nPut"
        Me.colVolBidPut.Name = "colVolBidPut"
        Me.colVolBidPut.ReadOnly = True
        Me.colVolBidPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolBidPut.Width = 62
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miCopy, Me.miSelectAll})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(137, 48)
        '
        'miCopy
        '
        Me.miCopy.Name = "miCopy"
        Me.miCopy.Size = New System.Drawing.Size(136, 22)
        Me.miCopy.Text = "コピー"
        '
        'miSelectAll
        '
        Me.miSelectAll.Name = "miSelectAll"
        Me.miSelectAll.Size = New System.Drawing.Size(136, 22)
        Me.miSelectAll.Text = "すべて選択"
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.tbPriceUnit)
        Me.Panel1.Controls.Add(Me.tbBidPriceMinPut)
        Me.Panel1.Controls.Add(Me.tbAskPriceMaxPut)
        Me.Panel1.Controls.Add(Me.tbBidPriceMinCall)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.tbAskPriceMaxCall)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.tbAskBidSpreadMinPut)
        Me.Panel1.Controls.Add(Me.tbAskBidSpreadMinCall)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.tbAskFeePricePut)
        Me.Panel1.Controls.Add(Me.tbAskFeePriceCall)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.tbSwapRate)
        Me.Panel1.Controls.Add(Me.tbInterestRate)
        Me.Panel1.Controls.Add(Me.tbHV)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.nudExercPriceUnit)
        Me.Panel1.Controls.Add(Me.btnCreate)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.nudExercPriceRate)
        Me.Panel1.Controls.Add(Me.chkAuto)
        Me.Panel1.Controls.Add(Me.btnCalc)
        Me.Panel1.Controls.Add(Me.btnRate)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.nudRate)
        Me.Panel1.Controls.Add(Me.dtpLife)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.tbVolSmileBPut)
        Me.Panel1.Controls.Add(Me.tbVolSmileAPut)
        Me.Panel1.Controls.Add(Me.tbVolSmileBCall)
        Me.Panel1.Controls.Add(Me.tbVolSmileACall)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.tbCallPutSpread)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.tbBulkSetUnit)
        Me.Panel1.Controls.Add(Me.nudBulkSetCount)
        Me.Panel1.Controls.Add(Me.btnBulkSet)
        Me.Panel1.Controls.Add(Me.tbBidFeeRatePut)
        Me.Panel1.Controls.Add(Me.lblPutName1)
        Me.Panel1.Controls.Add(Me.lblCallName1)
        Me.Panel1.Controls.Add(Me.tbAskPriceMinPut)
        Me.Panel1.Controls.Add(Me.tbBidPriceMaxPut)
        Me.Panel1.Controls.Add(Me.tbVolSpreadPut)
        Me.Panel1.Controls.Add(Me.tbVolRatio2Put)
        Me.Panel1.Controls.Add(Me.tbVolRatio1Put)
        Me.Panel1.Controls.Add(Me.tbBidFeeRateCall)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.tbAskPriceMinCall)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.tbBidPriceMaxCall)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.tbVolSpreadCall)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.cbExercPriceUnitType)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.tbVolRatio2Call)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.tbVolRatio1Call)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.tbExercPriceSettings)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(581, 339)
        Me.Panel1.TabIndex = 18
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(10, 284)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(77, 12)
        Me.Label23.TabIndex = 197
        Me.Label23.Text = "価格算出単位"
        '
        'tbPriceUnit
        '
        Me.tbPriceUnit.Location = New System.Drawing.Point(99, 281)
        Me.tbPriceUnit.Name = "tbPriceUnit"
        Me.tbPriceUnit.Size = New System.Drawing.Size(87, 19)
        Me.tbPriceUnit.TabIndex = 196
        Me.tbPriceUnit.Text = "10"
        Me.tbPriceUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMinPut
        '
        Me.tbBidPriceMinPut.Location = New System.Drawing.Point(502, 275)
        Me.tbBidPriceMinPut.Name = "tbBidPriceMinPut"
        Me.tbBidPriceMinPut.ReadOnly = True
        Me.tbBidPriceMinPut.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMinPut.TabIndex = 192
        Me.tbBidPriceMinPut.Text = "0"
        Me.tbBidPriceMinPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMaxPut
        '
        Me.tbAskPriceMaxPut.Location = New System.Drawing.Point(502, 212)
        Me.tbAskPriceMaxPut.Name = "tbAskPriceMaxPut"
        Me.tbAskPriceMaxPut.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMaxPut.TabIndex = 195
        Me.tbAskPriceMaxPut.Text = "1000"
        Me.tbAskPriceMaxPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMinCall
        '
        Me.tbBidPriceMinCall.Location = New System.Drawing.Point(441, 275)
        Me.tbBidPriceMinCall.Name = "tbBidPriceMinCall"
        Me.tbBidPriceMinCall.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMinCall.TabIndex = 191
        Me.tbBidPriceMinCall.Text = "0"
        Me.tbBidPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(303, 278)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(77, 12)
        Me.Label11.TabIndex = 190
        Me.Label11.Text = "最低清算価格"
        '
        'tbAskPriceMaxCall
        '
        Me.tbAskPriceMaxCall.Location = New System.Drawing.Point(441, 212)
        Me.tbAskPriceMaxCall.Name = "tbAskPriceMaxCall"
        Me.tbAskPriceMaxCall.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMaxCall.TabIndex = 194
        Me.tbAskPriceMaxCall.Text = "1000"
        Me.tbAskPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(303, 215)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 12)
        Me.Label13.TabIndex = 193
        Me.Label13.Text = "最高購入価格"
        '
        'tbAskBidSpreadMinPut
        '
        Me.tbAskBidSpreadMinPut.Location = New System.Drawing.Point(502, 170)
        Me.tbAskBidSpreadMinPut.Name = "tbAskBidSpreadMinPut"
        Me.tbAskBidSpreadMinPut.Size = New System.Drawing.Size(50, 19)
        Me.tbAskBidSpreadMinPut.TabIndex = 189
        Me.tbAskBidSpreadMinPut.Text = "0"
        Me.tbAskBidSpreadMinPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskBidSpreadMinCall
        '
        Me.tbAskBidSpreadMinCall.Location = New System.Drawing.Point(441, 170)
        Me.tbAskBidSpreadMinCall.Name = "tbAskBidSpreadMinCall"
        Me.tbAskBidSpreadMinCall.Size = New System.Drawing.Size(50, 19)
        Me.tbAskBidSpreadMinCall.TabIndex = 188
        Me.tbAskBidSpreadMinCall.Text = "0"
        Me.tbAskBidSpreadMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(303, 173)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(137, 12)
        Me.Label9.TabIndex = 187
        Me.Label9.Text = "購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        '
        'tbAskFeePricePut
        '
        Me.tbAskFeePricePut.Location = New System.Drawing.Point(502, 149)
        Me.tbAskFeePricePut.Name = "tbAskFeePricePut"
        Me.tbAskFeePricePut.ReadOnly = True
        Me.tbAskFeePricePut.Size = New System.Drawing.Size(50, 19)
        Me.tbAskFeePricePut.TabIndex = 186
        Me.tbAskFeePricePut.Text = "0"
        Me.tbAskFeePricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskFeePriceCall
        '
        Me.tbAskFeePriceCall.Location = New System.Drawing.Point(441, 149)
        Me.tbAskFeePriceCall.Name = "tbAskFeePriceCall"
        Me.tbAskFeePriceCall.ReadOnly = True
        Me.tbAskFeePriceCall.Size = New System.Drawing.Size(50, 19)
        Me.tbAskFeePriceCall.TabIndex = 185
        Me.tbAskFeePriceCall.Text = "0"
        Me.tbAskFeePriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(303, 152)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 12)
        Me.Label8.TabIndex = 184
        Me.Label8.Text = "購入価格リスク"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 222)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 12)
        Me.Label7.TabIndex = 183
        Me.Label7.Text = "HV"
        '
        'tbSwapRate
        '
        Me.tbSwapRate.Location = New System.Drawing.Point(99, 261)
        Me.tbSwapRate.Name = "tbSwapRate"
        Me.tbSwapRate.Size = New System.Drawing.Size(87, 19)
        Me.tbSwapRate.TabIndex = 181
        Me.tbSwapRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbInterestRate
        '
        Me.tbInterestRate.Location = New System.Drawing.Point(99, 240)
        Me.tbInterestRate.Name = "tbInterestRate"
        Me.tbInterestRate.Size = New System.Drawing.Size(88, 19)
        Me.tbInterestRate.TabIndex = 179
        Me.tbInterestRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHV
        '
        Me.tbHV.Location = New System.Drawing.Point(99, 219)
        Me.tbHV.Name = "tbHV"
        Me.tbHV.Size = New System.Drawing.Size(125, 19)
        Me.tbHV.TabIndex = 182
        Me.tbHV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 264)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 180
        Me.Label6.Text = "スワップ金利(%)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 243)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 12)
        Me.Label4.TabIndex = 178
        Me.Label4.Text = "短期金利(%)"
        '
        'nudExercPriceUnit
        '
        Me.nudExercPriceUnit.DecimalPlaces = 3
        Me.nudExercPriceUnit.Increment = New Decimal(New Integer() {1, 0, 0, 196608})
        Me.nudExercPriceUnit.Location = New System.Drawing.Point(207, 36)
        Me.nudExercPriceUnit.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPriceUnit.Name = "nudExercPriceUnit"
        Me.nudExercPriceUnit.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPriceUnit.TabIndex = 177
        Me.nudExercPriceUnit.Value = New Decimal(New Integer() {1, 0, 0, 196608})
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(194, 180)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(75, 29)
        Me.btnCreate.TabIndex = 176
        Me.btnCreate.Text = "設定"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 189)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 12)
        Me.Label3.TabIndex = 175
        Me.Label3.Text = "行使価格決定時レート"
        '
        'nudExercPriceRate
        '
        Me.nudExercPriceRate.DecimalPlaces = 3
        Me.nudExercPriceRate.Location = New System.Drawing.Point(127, 187)
        Me.nudExercPriceRate.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPriceRate.Name = "nudExercPriceRate"
        Me.nudExercPriceRate.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPriceRate.TabIndex = 174
        Me.nudExercPriceRate.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkAuto
        '
        Me.chkAuto.AutoSize = True
        Me.chkAuto.Location = New System.Drawing.Point(110, 312)
        Me.chkAuto.Name = "chkAuto"
        Me.chkAuto.Size = New System.Drawing.Size(48, 16)
        Me.chkAuto.TabIndex = 173
        Me.chkAuto.Text = "連動"
        Me.chkAuto.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(15, 305)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(89, 29)
        Me.btnCalc.TabIndex = 172
        Me.btnCalc.Text = "再計算"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(422, 303)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(89, 29)
        Me.btnRate.TabIndex = 171
        Me.btnRate.Text = "現在レート"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(302, 314)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 12)
        Me.Label1.TabIndex = 170
        Me.Label1.Text = "レート"
        '
        'nudRate
        '
        Me.nudRate.DecimalPlaces = 3
        Me.nudRate.Location = New System.Drawing.Point(345, 309)
        Me.nudRate.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudRate.Name = "nudRate"
        Me.nudRate.Size = New System.Drawing.Size(61, 19)
        Me.nudRate.TabIndex = 169
        Me.nudRate.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'dtpLife
        '
        Me.dtpLife.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpLife.Location = New System.Drawing.Point(223, 309)
        Me.dtpLife.Name = "dtpLife"
        Me.dtpLife.ShowUpDown = True
        Me.dtpLife.Size = New System.Drawing.Size(64, 19)
        Me.dtpLife.TabIndex = 168
        Me.dtpLife.Value = New Date(2013, 9, 26, 2, 0, 0, 0)
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(164, 313)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 167
        Me.Label5.Text = "残存期間"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(64, 10)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(131, 20)
        Me.cbComCode.TabIndex = 166
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 165
        Me.Label2.Text = "通貨ペア"
        '
        'tbVolSmileBPut
        '
        Me.tbVolSmileBPut.Location = New System.Drawing.Point(502, 107)
        Me.tbVolSmileBPut.Name = "tbVolSmileBPut"
        Me.tbVolSmileBPut.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileBPut.TabIndex = 148
        Me.tbVolSmileBPut.Text = "0.1"
        Me.tbVolSmileBPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSmileAPut
        '
        Me.tbVolSmileAPut.Location = New System.Drawing.Point(502, 86)
        Me.tbVolSmileAPut.Name = "tbVolSmileAPut"
        Me.tbVolSmileAPut.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileAPut.TabIndex = 146
        Me.tbVolSmileAPut.Text = "0.5"
        Me.tbVolSmileAPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSmileBCall
        '
        Me.tbVolSmileBCall.Location = New System.Drawing.Point(441, 107)
        Me.tbVolSmileBCall.Name = "tbVolSmileBCall"
        Me.tbVolSmileBCall.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileBCall.TabIndex = 147
        Me.tbVolSmileBCall.Text = "0.1"
        Me.tbVolSmileBCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSmileACall
        '
        Me.tbVolSmileACall.Location = New System.Drawing.Point(441, 86)
        Me.tbVolSmileACall.Name = "tbVolSmileACall"
        Me.tbVolSmileACall.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileACall.TabIndex = 144
        Me.tbVolSmileACall.Text = "0.5"
        Me.tbVolSmileACall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(302, 111)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(106, 12)
        Me.Label10.TabIndex = 164
        Me.Label10.Text = "ボラティリティスマイルｂ"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(302, 90)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(106, 12)
        Me.Label22.TabIndex = 163
        Me.Label22.Text = "ボラティリティスマイルａ"
        '
        'tbCallPutSpread
        '
        Me.tbCallPutSpread.Location = New System.Drawing.Point(502, 44)
        Me.tbCallPutSpread.Name = "tbCallPutSpread"
        Me.tbCallPutSpread.Size = New System.Drawing.Size(50, 19)
        Me.tbCallPutSpread.TabIndex = 140
        Me.tbCallPutSpread.Text = "0.01"
        Me.tbCallPutSpread.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(302, 48)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(108, 12)
        Me.Label16.TabIndex = 162
        Me.Label16.Text = "CALL/PUT スプレッド"
        '
        'tbBulkSetUnit
        '
        Me.tbBulkSetUnit.Location = New System.Drawing.Point(87, 149)
        Me.tbBulkSetUnit.Name = "tbBulkSetUnit"
        Me.tbBulkSetUnit.Size = New System.Drawing.Size(62, 19)
        Me.tbBulkSetUnit.TabIndex = 130
        Me.tbBulkSetUnit.TabStop = False
        Me.tbBulkSetUnit.Text = "0.00005"
        Me.tbBulkSetUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudBulkSetCount
        '
        Me.nudBulkSetCount.Location = New System.Drawing.Point(155, 149)
        Me.nudBulkSetCount.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.nudBulkSetCount.Name = "nudBulkSetCount"
        Me.nudBulkSetCount.Size = New System.Drawing.Size(31, 19)
        Me.nudBulkSetCount.TabIndex = 131
        Me.nudBulkSetCount.TabStop = False
        Me.nudBulkSetCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudBulkSetCount.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'btnBulkSet
        '
        Me.btnBulkSet.Location = New System.Drawing.Point(192, 147)
        Me.btnBulkSet.Name = "btnBulkSet"
        Me.btnBulkSet.Size = New System.Drawing.Size(77, 23)
        Me.btnBulkSet.TabIndex = 132
        Me.btnBulkSet.TabStop = False
        Me.btnBulkSet.Text = "一括設定"
        Me.btnBulkSet.UseVisualStyleBackColor = True
        '
        'tbBidFeeRatePut
        '
        Me.tbBidFeeRatePut.Location = New System.Drawing.Point(502, 191)
        Me.tbBidFeeRatePut.Name = "tbBidFeeRatePut"
        Me.tbBidFeeRatePut.ReadOnly = True
        Me.tbBidFeeRatePut.Size = New System.Drawing.Size(50, 19)
        Me.tbBidFeeRatePut.TabIndex = 155
        Me.tbBidFeeRatePut.Text = "4"
        Me.tbBidFeeRatePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblPutName1
        '
        Me.lblPutName1.Location = New System.Drawing.Point(498, 8)
        Me.lblPutName1.Name = "lblPutName1"
        Me.lblPutName1.Size = New System.Drawing.Size(60, 12)
        Me.lblPutName1.TabIndex = 136
        Me.lblPutName1.Text = "PUT"
        Me.lblPutName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCallName1
        '
        Me.lblCallName1.Location = New System.Drawing.Point(438, 8)
        Me.lblCallName1.Name = "lblCallName1"
        Me.lblCallName1.Size = New System.Drawing.Size(60, 12)
        Me.lblCallName1.TabIndex = 135
        Me.lblCallName1.Text = "CALL"
        Me.lblCallName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tbAskPriceMinPut
        '
        Me.tbAskPriceMinPut.Location = New System.Drawing.Point(502, 233)
        Me.tbAskPriceMinPut.Name = "tbAskPriceMinPut"
        Me.tbAskPriceMinPut.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMinPut.TabIndex = 158
        Me.tbAskPriceMinPut.Text = "200"
        Me.tbAskPriceMinPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMaxPut
        '
        Me.tbBidPriceMaxPut.Location = New System.Drawing.Point(502, 254)
        Me.tbBidPriceMaxPut.Name = "tbBidPriceMaxPut"
        Me.tbBidPriceMaxPut.ReadOnly = True
        Me.tbBidPriceMaxPut.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMaxPut.TabIndex = 161
        Me.tbBidPriceMaxPut.Text = "950"
        Me.tbBidPriceMaxPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSpreadPut
        '
        Me.tbVolSpreadPut.Location = New System.Drawing.Point(502, 128)
        Me.tbVolSpreadPut.Name = "tbVolSpreadPut"
        Me.tbVolSpreadPut.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSpreadPut.TabIndex = 153
        Me.tbVolSpreadPut.Text = "0.01"
        Me.tbVolSpreadPut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolRatio2Put
        '
        Me.tbVolRatio2Put.Location = New System.Drawing.Point(502, 65)
        Me.tbVolRatio2Put.Name = "tbVolRatio2Put"
        Me.tbVolRatio2Put.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio2Put.TabIndex = 143
        Me.tbVolRatio2Put.Text = "0.1"
        Me.tbVolRatio2Put.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolRatio1Put
        '
        Me.tbVolRatio1Put.Location = New System.Drawing.Point(502, 23)
        Me.tbVolRatio1Put.Name = "tbVolRatio1Put"
        Me.tbVolRatio1Put.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio1Put.TabIndex = 139
        Me.tbVolRatio1Put.Text = "0.5"
        Me.tbVolRatio1Put.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidFeeRateCall
        '
        Me.tbBidFeeRateCall.Location = New System.Drawing.Point(441, 191)
        Me.tbBidFeeRateCall.Name = "tbBidFeeRateCall"
        Me.tbBidFeeRateCall.Size = New System.Drawing.Size(50, 19)
        Me.tbBidFeeRateCall.TabIndex = 154
        Me.tbBidFeeRateCall.Text = "4"
        Me.tbBidFeeRateCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(303, 194)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(91, 12)
        Me.Label21.TabIndex = 152
        Me.Label21.Text = "清算価格リスク(%)"
        '
        'tbAskPriceMinCall
        '
        Me.tbAskPriceMinCall.Location = New System.Drawing.Point(441, 233)
        Me.tbAskPriceMinCall.Name = "tbAskPriceMinCall"
        Me.tbAskPriceMinCall.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMinCall.TabIndex = 157
        Me.tbAskPriceMinCall.Text = "200"
        Me.tbAskPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(303, 236)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(77, 12)
        Me.Label20.TabIndex = 156
        Me.Label20.Text = "最低購入価格"
        '
        'tbBidPriceMaxCall
        '
        Me.tbBidPriceMaxCall.Location = New System.Drawing.Point(441, 254)
        Me.tbBidPriceMaxCall.Name = "tbBidPriceMaxCall"
        Me.tbBidPriceMaxCall.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMaxCall.TabIndex = 160
        Me.tbBidPriceMaxCall.Text = "950"
        Me.tbBidPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(303, 257)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(77, 12)
        Me.Label19.TabIndex = 159
        Me.Label19.Text = "最高清算価格"
        '
        'tbVolSpreadCall
        '
        Me.tbVolSpreadCall.Location = New System.Drawing.Point(441, 128)
        Me.tbVolSpreadCall.Name = "tbVolSpreadCall"
        Me.tbVolSpreadCall.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSpreadCall.TabIndex = 151
        Me.tbVolSpreadCall.Text = "0.01"
        Me.tbVolSpreadCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(302, 133)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(105, 12)
        Me.Label18.TabIndex = 145
        Me.Label18.Text = "ボラティリティスプレッド"
        '
        'cbExercPriceUnitType
        '
        Me.cbExercPriceUnitType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercPriceUnitType.FormattingEnabled = True
        Me.cbExercPriceUnitType.Items.AddRange(New Object() {"なし", "切り上げ", "切り捨て"})
        Me.cbExercPriceUnitType.Location = New System.Drawing.Point(123, 36)
        Me.cbExercPriceUnitType.Name = "cbExercPriceUnitType"
        Me.cbExercPriceUnitType.Size = New System.Drawing.Size(78, 20)
        Me.cbExercPriceUnitType.TabIndex = 126
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(10, 40)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(88, 12)
        Me.Label17.TabIndex = 125
        Me.Label17.Text = "行使価格刻み幅"
        '
        'tbVolRatio2Call
        '
        Me.tbVolRatio2Call.Location = New System.Drawing.Point(441, 65)
        Me.tbVolRatio2Call.Name = "tbVolRatio2Call"
        Me.tbVolRatio2Call.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio2Call.TabIndex = 142
        Me.tbVolRatio2Call.Text = "0.1"
        Me.tbVolRatio2Call.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(302, 69)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(98, 12)
        Me.Label15.TabIndex = 141
        Me.Label15.Text = "ボラティリティレシオ２"
        '
        'tbVolRatio1Call
        '
        Me.tbVolRatio1Call.Location = New System.Drawing.Point(441, 23)
        Me.tbVolRatio1Call.Name = "tbVolRatio1Call"
        Me.tbVolRatio1Call.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio1Call.TabIndex = 138
        Me.tbVolRatio1Call.Text = "0.5"
        Me.tbVolRatio1Call.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(302, 27)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 12)
        Me.Label14.TabIndex = 137
        Me.Label14.Text = "ボラティリティレシオ１"
        '
        'tbExercPriceSettings
        '
        Me.tbExercPriceSettings.AcceptsReturn = True
        Me.tbExercPriceSettings.Location = New System.Drawing.Point(12, 76)
        Me.tbExercPriceSettings.Multiline = True
        Me.tbExercPriceSettings.Name = "tbExercPriceSettings"
        Me.tbExercPriceSettings.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbExercPriceSettings.Size = New System.Drawing.Size(257, 70)
        Me.tbExercPriceSettings.TabIndex = 129
        Me.tbExercPriceSettings.Text = "+0.01,+0.02,+0.03,+0.04,+0.05" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "-0.01,-0.02,-0.03,-0.04,-0.05"
        Me.tbExercPriceSettings.WordWrap = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(10, 61)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(77, 12)
        Me.Label12.TabIndex = 128
        Me.Label12.Text = "行使価格設定"
        '
        'PricingSim1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 669)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "PricingSim1"
        Me.Text = "プライシングシミュレータ１"
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.nudExercPriceUnit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPriceRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudBulkSetCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents tbVolSmileBPut As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSmileAPut As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSmileBCall As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSmileACall As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents tbCallPutSpread As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tbBulkSetUnit As System.Windows.Forms.TextBox
    Friend WithEvents nudBulkSetCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnBulkSet As System.Windows.Forms.Button
    Friend WithEvents tbBidFeeRatePut As System.Windows.Forms.TextBox
    Friend WithEvents lblPutName1 As System.Windows.Forms.Label
    Friend WithEvents lblCallName1 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMinPut As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMaxPut As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSpreadPut As System.Windows.Forms.TextBox
    Friend WithEvents tbVolRatio2Put As System.Windows.Forms.TextBox
    Friend WithEvents tbVolRatio1Put As System.Windows.Forms.TextBox
    Friend WithEvents tbBidFeeRateCall As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMinCall As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents tbBidPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents tbVolSpreadCall As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cbExercPriceUnitType As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio2Call As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio1Call As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tbExercPriceSettings As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents nudExercPriceRate As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkAuto As System.Windows.Forms.CheckBox
    Friend WithEvents btnCalc As System.Windows.Forms.Button
    Friend WithEvents btnRate As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents nudRate As System.Windows.Forms.NumericUpDown
    Friend WithEvents dtpLife As System.Windows.Forms.DateTimePicker
    Friend WithEvents nudExercPriceUnit As System.Windows.Forms.NumericUpDown
    Friend WithEvents colExercPriceSetting As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceAskCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceBidCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceAskPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceBidPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolAskCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolBidCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolAskPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolBidPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents tbSwapRate As System.Windows.Forms.TextBox
    Friend WithEvents tbInterestRate As System.Windows.Forms.TextBox
    Friend WithEvents tbHV As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miCopy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miSelectAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tbAskBidSpreadMinPut As System.Windows.Forms.TextBox
    Friend WithEvents tbAskBidSpreadMinCall As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbAskFeePricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbAskFeePriceCall As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tbBidPriceMinPut As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMaxPut As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMinCall As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents tbPriceUnit As System.Windows.Forms.TextBox
End Class
