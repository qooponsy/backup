﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NowStatusForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblProductStatusNextTimeName = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.lblSysDate = New System.Windows.Forms.Label()
        Me.lblSystemEnabled = New System.Windows.Forms.Label()
        Me.lblAbandEnabled = New System.Windows.Forms.Label()
        Me.lblCashOutEnabled = New System.Windows.Forms.Label()
        Me.lblCashInEnabled = New System.Windows.Forms.Label()
        Me.lblProductStatusStatus = New System.Windows.Forms.Label()
        Me.lblProductStatusNextTime = New System.Windows.Forms.Label()
        Me.lblAccountCount = New System.Windows.Forms.Label()
        Me.lblAccountCountEnabled = New System.Windows.Forms.Label()
        Me.lblNewAccountCount = New System.Windows.Forms.Label()
        Me.lblTradeAccountCount = New System.Windows.Forms.Label()
        Me.lblTradeCount = New System.Windows.Forms.Label()
        Me.lblTradeAmount = New System.Windows.Forms.Label()
        Me.lblTotalMoney = New System.Windows.Forms.Label()
        Me.lblTotalPAndL = New System.Windows.Forms.Label()
        Me.lblCashInCount = New System.Windows.Forms.Label()
        Me.lblCashInMoney = New System.Windows.Forms.Label()
        Me.lblCashOutCount = New System.Windows.Forms.Label()
        Me.lblCashOutMoney = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.lblGetDBTime = New System.Windows.Forms.Label()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.lblLoginCustCount = New System.Windows.Forms.Label()
        Me.lblLoginAdminCount = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "システム営業日"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "[システム制御]"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(29, 98)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 12)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "購入"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(29, 118)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 12)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "清算"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 144)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 12)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "[入出金振替制御]"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(29, 164)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 12)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "出金振替"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(29, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 12)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "入金振替"
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 13)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label8.Location = New System.Drawing.Point(12, 209)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 12)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "[取引中銘柄]"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label9.Location = New System.Drawing.Point(29, 229)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 12)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "ステータス"
        '
        'lblProductStatusNextTimeName
        '
        Me.lblProductStatusNextTimeName.AutoSize = True
        Me.lblProductStatusNextTimeName.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProductStatusNextTimeName.Location = New System.Drawing.Point(29, 249)
        Me.lblProductStatusNextTimeName.Name = "lblProductStatusNextTimeName"
        Me.lblProductStatusNextTimeName.Size = New System.Drawing.Size(57, 12)
        Me.lblProductStatusNextTimeName.TabIndex = 11
        Me.lblProductStatusNextTimeName.Text = "開始日時"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label11.Location = New System.Drawing.Point(210, 55)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 12)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "[営業実績]"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label12.Location = New System.Drawing.Point(223, 78)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 12)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "登録口座数"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label13.Location = New System.Drawing.Point(223, 98)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(70, 12)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "有効口座数"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label14.Location = New System.Drawing.Point(223, 118)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(70, 12)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "新規口座数"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label15.Location = New System.Drawing.Point(223, 138)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(70, 12)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "取引口座数"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label16.Location = New System.Drawing.Point(223, 158)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(57, 12)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "取引件数"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label17.Location = New System.Drawing.Point(223, 178)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(57, 12)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "取引金額"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label18.Location = New System.Drawing.Point(223, 198)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(57, 12)
        Me.Label18.TabIndex = 19
        Me.Label18.Text = "残高合計"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label19.Location = New System.Drawing.Point(223, 218)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(57, 12)
        Me.Label19.TabIndex = 20
        Me.Label19.Text = "実現損益"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label20.Location = New System.Drawing.Point(223, 238)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(57, 12)
        Me.Label20.TabIndex = 21
        Me.Label20.Text = "入金件数"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label21.Location = New System.Drawing.Point(223, 258)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(70, 12)
        Me.Label21.TabIndex = 22
        Me.Label21.Text = "入金額合計"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label22.Location = New System.Drawing.Point(223, 278)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(57, 12)
        Me.Label22.TabIndex = 23
        Me.Label22.Text = "出金件数"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label23.Location = New System.Drawing.Point(223, 298)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(70, 12)
        Me.Label23.TabIndex = 24
        Me.Label23.Text = "出金額合計"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label24.Location = New System.Drawing.Point(418, 55)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(125, 12)
        Me.Label24.TabIndex = 25
        Me.Label24.Text = "[ログイン中ユーザー数]"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label25.Location = New System.Drawing.Point(434, 78)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(88, 12)
        Me.Label25.TabIndex = 26
        Me.Label25.Text = "管理者ユーザー"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label26.Location = New System.Drawing.Point(434, 98)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(88, 12)
        Me.Label26.TabIndex = 27
        Me.Label26.Text = "委託者ユーザー"
        '
        'lblSysDate
        '
        Me.lblSysDate.BackColor = System.Drawing.Color.White
        Me.lblSysDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSysDate.Location = New System.Drawing.Point(109, 51)
        Me.lblSysDate.Name = "lblSysDate"
        Me.lblSysDate.Size = New System.Drawing.Size(78, 21)
        Me.lblSysDate.TabIndex = 28
        Me.lblSysDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSystemEnabled
        '
        Me.lblSystemEnabled.BackColor = System.Drawing.Color.White
        Me.lblSystemEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSystemEnabled.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblSystemEnabled.Location = New System.Drawing.Point(109, 94)
        Me.lblSystemEnabled.Name = "lblSystemEnabled"
        Me.lblSystemEnabled.Size = New System.Drawing.Size(78, 21)
        Me.lblSystemEnabled.TabIndex = 29
        Me.lblSystemEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAbandEnabled
        '
        Me.lblAbandEnabled.BackColor = System.Drawing.Color.White
        Me.lblAbandEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAbandEnabled.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblAbandEnabled.Location = New System.Drawing.Point(109, 114)
        Me.lblAbandEnabled.Name = "lblAbandEnabled"
        Me.lblAbandEnabled.Size = New System.Drawing.Size(78, 21)
        Me.lblAbandEnabled.TabIndex = 30
        Me.lblAbandEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCashOutEnabled
        '
        Me.lblCashOutEnabled.BackColor = System.Drawing.Color.White
        Me.lblCashOutEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCashOutEnabled.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCashOutEnabled.Location = New System.Drawing.Point(109, 160)
        Me.lblCashOutEnabled.Name = "lblCashOutEnabled"
        Me.lblCashOutEnabled.Size = New System.Drawing.Size(78, 21)
        Me.lblCashOutEnabled.TabIndex = 31
        Me.lblCashOutEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCashInEnabled
        '
        Me.lblCashInEnabled.BackColor = System.Drawing.Color.White
        Me.lblCashInEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCashInEnabled.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblCashInEnabled.Location = New System.Drawing.Point(109, 180)
        Me.lblCashInEnabled.Name = "lblCashInEnabled"
        Me.lblCashInEnabled.Size = New System.Drawing.Size(78, 21)
        Me.lblCashInEnabled.TabIndex = 32
        Me.lblCashInEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblProductStatusStatus
        '
        Me.lblProductStatusStatus.BackColor = System.Drawing.Color.White
        Me.lblProductStatusStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProductStatusStatus.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblProductStatusStatus.Location = New System.Drawing.Point(109, 225)
        Me.lblProductStatusStatus.Name = "lblProductStatusStatus"
        Me.lblProductStatusStatus.Size = New System.Drawing.Size(78, 21)
        Me.lblProductStatusStatus.TabIndex = 33
        Me.lblProductStatusStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblProductStatusNextTime
        '
        Me.lblProductStatusNextTime.BackColor = System.Drawing.Color.White
        Me.lblProductStatusNextTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProductStatusNextTime.Location = New System.Drawing.Point(65, 265)
        Me.lblProductStatusNextTime.Name = "lblProductStatusNextTime"
        Me.lblProductStatusNextTime.Size = New System.Drawing.Size(122, 21)
        Me.lblProductStatusNextTime.TabIndex = 34
        Me.lblProductStatusNextTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAccountCount
        '
        Me.lblAccountCount.BackColor = System.Drawing.Color.White
        Me.lblAccountCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAccountCount.Location = New System.Drawing.Point(310, 74)
        Me.lblAccountCount.Name = "lblAccountCount"
        Me.lblAccountCount.Size = New System.Drawing.Size(84, 21)
        Me.lblAccountCount.TabIndex = 35
        Me.lblAccountCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAccountCountEnabled
        '
        Me.lblAccountCountEnabled.BackColor = System.Drawing.Color.White
        Me.lblAccountCountEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAccountCountEnabled.Location = New System.Drawing.Point(310, 94)
        Me.lblAccountCountEnabled.Name = "lblAccountCountEnabled"
        Me.lblAccountCountEnabled.Size = New System.Drawing.Size(84, 21)
        Me.lblAccountCountEnabled.TabIndex = 36
        Me.lblAccountCountEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNewAccountCount
        '
        Me.lblNewAccountCount.BackColor = System.Drawing.Color.White
        Me.lblNewAccountCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblNewAccountCount.Location = New System.Drawing.Point(310, 114)
        Me.lblNewAccountCount.Name = "lblNewAccountCount"
        Me.lblNewAccountCount.Size = New System.Drawing.Size(84, 21)
        Me.lblNewAccountCount.TabIndex = 37
        Me.lblNewAccountCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTradeAccountCount
        '
        Me.lblTradeAccountCount.BackColor = System.Drawing.Color.White
        Me.lblTradeAccountCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTradeAccountCount.Location = New System.Drawing.Point(310, 134)
        Me.lblTradeAccountCount.Name = "lblTradeAccountCount"
        Me.lblTradeAccountCount.Size = New System.Drawing.Size(84, 21)
        Me.lblTradeAccountCount.TabIndex = 38
        Me.lblTradeAccountCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTradeCount
        '
        Me.lblTradeCount.BackColor = System.Drawing.Color.White
        Me.lblTradeCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTradeCount.Location = New System.Drawing.Point(310, 154)
        Me.lblTradeCount.Name = "lblTradeCount"
        Me.lblTradeCount.Size = New System.Drawing.Size(84, 21)
        Me.lblTradeCount.TabIndex = 39
        Me.lblTradeCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTradeAmount
        '
        Me.lblTradeAmount.BackColor = System.Drawing.Color.White
        Me.lblTradeAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTradeAmount.Location = New System.Drawing.Point(310, 174)
        Me.lblTradeAmount.Name = "lblTradeAmount"
        Me.lblTradeAmount.Size = New System.Drawing.Size(84, 21)
        Me.lblTradeAmount.TabIndex = 40
        Me.lblTradeAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTotalMoney
        '
        Me.lblTotalMoney.BackColor = System.Drawing.Color.White
        Me.lblTotalMoney.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalMoney.Location = New System.Drawing.Point(310, 194)
        Me.lblTotalMoney.Name = "lblTotalMoney"
        Me.lblTotalMoney.Size = New System.Drawing.Size(84, 21)
        Me.lblTotalMoney.TabIndex = 41
        Me.lblTotalMoney.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTotalPAndL
        '
        Me.lblTotalPAndL.BackColor = System.Drawing.Color.White
        Me.lblTotalPAndL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPAndL.Location = New System.Drawing.Point(310, 214)
        Me.lblTotalPAndL.Name = "lblTotalPAndL"
        Me.lblTotalPAndL.Size = New System.Drawing.Size(84, 21)
        Me.lblTotalPAndL.TabIndex = 42
        Me.lblTotalPAndL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCashInCount
        '
        Me.lblCashInCount.BackColor = System.Drawing.Color.White
        Me.lblCashInCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCashInCount.Location = New System.Drawing.Point(310, 234)
        Me.lblCashInCount.Name = "lblCashInCount"
        Me.lblCashInCount.Size = New System.Drawing.Size(84, 21)
        Me.lblCashInCount.TabIndex = 43
        Me.lblCashInCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCashInMoney
        '
        Me.lblCashInMoney.BackColor = System.Drawing.Color.White
        Me.lblCashInMoney.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCashInMoney.Location = New System.Drawing.Point(310, 254)
        Me.lblCashInMoney.Name = "lblCashInMoney"
        Me.lblCashInMoney.Size = New System.Drawing.Size(84, 21)
        Me.lblCashInMoney.TabIndex = 44
        Me.lblCashInMoney.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCashOutCount
        '
        Me.lblCashOutCount.BackColor = System.Drawing.Color.White
        Me.lblCashOutCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCashOutCount.Location = New System.Drawing.Point(310, 274)
        Me.lblCashOutCount.Name = "lblCashOutCount"
        Me.lblCashOutCount.Size = New System.Drawing.Size(84, 21)
        Me.lblCashOutCount.TabIndex = 45
        Me.lblCashOutCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblCashOutMoney
        '
        Me.lblCashOutMoney.BackColor = System.Drawing.Color.White
        Me.lblCashOutMoney.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCashOutMoney.Location = New System.Drawing.Point(310, 294)
        Me.lblCashOutMoney.Name = "lblCashOutMoney"
        Me.lblCashOutMoney.Size = New System.Drawing.Size(84, 21)
        Me.lblCashOutMoney.TabIndex = 46
        Me.lblCashOutMoney.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label46.Location = New System.Drawing.Point(161, 17)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(57, 12)
        Me.Label46.TabIndex = 47
        Me.Label46.Text = "取得日時"
        '
        'lblGetDBTime
        '
        Me.lblGetDBTime.BackColor = System.Drawing.Color.White
        Me.lblGetDBTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblGetDBTime.Location = New System.Drawing.Point(224, 13)
        Me.lblGetDBTime.Name = "lblGetDBTime"
        Me.lblGetDBTime.Size = New System.Drawing.Size(125, 21)
        Me.lblGetDBTime.TabIndex = 48
        Me.lblGetDBTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(367, 9)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(89, 29)
        Me.btnRefresh.TabIndex = 49
        Me.btnRefresh.Text = "更新"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'lblLoginCustCount
        '
        Me.lblLoginCustCount.BackColor = System.Drawing.Color.White
        Me.lblLoginCustCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLoginCustCount.Location = New System.Drawing.Point(538, 94)
        Me.lblLoginCustCount.Name = "lblLoginCustCount"
        Me.lblLoginCustCount.Size = New System.Drawing.Size(84, 21)
        Me.lblLoginCustCount.TabIndex = 51
        Me.lblLoginCustCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblLoginAdminCount
        '
        Me.lblLoginAdminCount.BackColor = System.Drawing.Color.White
        Me.lblLoginAdminCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLoginAdminCount.Location = New System.Drawing.Point(538, 74)
        Me.lblLoginAdminCount.Name = "lblLoginAdminCount"
        Me.lblLoginAdminCount.Size = New System.Drawing.Size(84, 21)
        Me.lblLoginAdminCount.TabIndex = 50
        Me.lblLoginAdminCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'NowStatusForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(639, 334)
        Me.Controls.Add(Me.lblLoginCustCount)
        Me.Controls.Add(Me.lblLoginAdminCount)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.lblGetDBTime)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.lblCashOutMoney)
        Me.Controls.Add(Me.lblCashOutCount)
        Me.Controls.Add(Me.lblCashInMoney)
        Me.Controls.Add(Me.lblCashInCount)
        Me.Controls.Add(Me.lblTotalPAndL)
        Me.Controls.Add(Me.lblTotalMoney)
        Me.Controls.Add(Me.lblTradeAmount)
        Me.Controls.Add(Me.lblTradeCount)
        Me.Controls.Add(Me.lblTradeAccountCount)
        Me.Controls.Add(Me.lblNewAccountCount)
        Me.Controls.Add(Me.lblAccountCountEnabled)
        Me.Controls.Add(Me.lblAccountCount)
        Me.Controls.Add(Me.lblProductStatusNextTime)
        Me.Controls.Add(Me.lblProductStatusStatus)
        Me.Controls.Add(Me.lblCashInEnabled)
        Me.Controls.Add(Me.lblCashOutEnabled)
        Me.Controls.Add(Me.lblAbandEnabled)
        Me.Controls.Add(Me.lblSystemEnabled)
        Me.Controls.Add(Me.lblSysDate)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lblProductStatusNextTimeName)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cbCmpCode)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "NowStatusForm"
        Me.Text = "稼動ステータス"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblProductStatusNextTimeName As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents lblSysDate As System.Windows.Forms.Label
    Friend WithEvents lblSystemEnabled As System.Windows.Forms.Label
    Friend WithEvents lblAbandEnabled As System.Windows.Forms.Label
    Friend WithEvents lblCashOutEnabled As System.Windows.Forms.Label
    Friend WithEvents lblCashInEnabled As System.Windows.Forms.Label
    Friend WithEvents lblProductStatusStatus As System.Windows.Forms.Label
    Friend WithEvents lblProductStatusNextTime As System.Windows.Forms.Label
    Friend WithEvents lblAccountCount As System.Windows.Forms.Label
    Friend WithEvents lblAccountCountEnabled As System.Windows.Forms.Label
    Friend WithEvents lblNewAccountCount As System.Windows.Forms.Label
    Friend WithEvents lblTradeAccountCount As System.Windows.Forms.Label
    Friend WithEvents lblTradeCount As System.Windows.Forms.Label
    Friend WithEvents lblTradeAmount As System.Windows.Forms.Label
    Friend WithEvents lblTotalMoney As System.Windows.Forms.Label
    Friend WithEvents lblTotalPAndL As System.Windows.Forms.Label
    Friend WithEvents lblCashInCount As System.Windows.Forms.Label
    Friend WithEvents lblCashInMoney As System.Windows.Forms.Label
    Friend WithEvents lblCashOutCount As System.Windows.Forms.Label
    Friend WithEvents lblCashOutMoney As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents lblGetDBTime As System.Windows.Forms.Label
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents lblLoginCustCount As System.Windows.Forms.Label
    Friend WithEvents lblLoginAdminCount As System.Windows.Forms.Label
End Class
