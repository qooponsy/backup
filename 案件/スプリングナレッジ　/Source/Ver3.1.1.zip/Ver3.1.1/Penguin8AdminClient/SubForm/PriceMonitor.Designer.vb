﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PriceMonitor
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle36 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle37 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle38 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle39 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle40 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle41 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle42 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle43 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle44 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle45 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle61 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle62 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle63 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkViewColumns = New System.Windows.Forms.CheckBox()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.colProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProductSubCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComOrder = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOpName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTradeLimitTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPriceTimespan = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPriceRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPriceUnitType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPriceUnitTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPriceUnit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPriceSetting = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExercPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProductEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProductSubEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProductSubStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCalcTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceAskCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceBidCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceAskPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPriceBidPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolAskCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolBidCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolAskPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolBidPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHVol = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colInterestRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSwapRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolRatio1Call = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolRatio1Put = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolRatio2Call = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolRatio2Put = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSpread = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSmileACall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSmileAPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSmileBCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSmileBPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSpreadITMCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSpreadITMPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSpreadOTMCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVolSpreadOTMPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskFeePriceCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskFeePricePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskBidSpreadMinCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskBidSpreadMinPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBidFeeRateCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBidFeeRatePut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskPriceMaxCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskPriceMaxPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskPriceMinCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAskPriceMinPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBidPriceMaxCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBidPriceMaxPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBidPriceMinCall = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBidPriceMinPut = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.cmGrid.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(547, 205)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(211, 63)
        Me.lblNoData.TabIndex = 16
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Location = New System.Drawing.Point(130, 6)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(121, 20)
        Me.cbOpType.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.chkViewColumns)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.cbOpType)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(927, 33)
        Me.Panel1.TabIndex = 13
        '
        'chkViewColumns
        '
        Me.chkViewColumns.AutoSize = True
        Me.chkViewColumns.Location = New System.Drawing.Point(275, 9)
        Me.chkViewColumns.Name = "chkViewColumns"
        Me.chkViewColumns.Size = New System.Drawing.Size(84, 16)
        Me.chkViewColumns.TabIndex = 16
        Me.chkViewColumns.Text = "全項目表示"
        Me.chkViewColumns.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(430, 2)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 15
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(3, 6)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 1
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colProductCode, Me.colProductSubCode, Me.colComCode, Me.colComName, Me.colComOrder, Me.colOpType, Me.colOpName, Me.colStartTime, Me.colTradeLimitTime, Me.colExercTime, Me.colExercPriceTimespan, Me.colExercPriceRate, Me.colExercPriceUnitType, Me.colExercPriceUnitTypeName, Me.colExercPriceUnit, Me.colExercPriceSetting, Me.colExercPrice, Me.colProductEnabled, Me.colProductSubEnabled, Me.colProductSubStatus, Me.colStatus, Me.colRateSeq, Me.colRate, Me.colRateTime, Me.colCalcTime, Me.colPriceAskCall, Me.colPriceBidCall, Me.colPriceAskPut, Me.colPriceBidPut, Me.colVolAskCall, Me.colVolBidCall, Me.colVolAskPut, Me.colVolBidPut, Me.colHVol, Me.colInterestRate, Me.colSwapRate, Me.colVolRatio1Call, Me.colVolRatio1Put, Me.colVolRatio2Call, Me.colVolRatio2Put, Me.colVolSpread, Me.colVolSmileACall, Me.colVolSmileAPut, Me.colVolSmileBCall, Me.colVolSmileBPut, Me.colVolSpreadITMCall, Me.colVolSpreadITMPut, Me.colVolSpreadOTMCall, Me.colVolSpreadOTMPut, Me.colAskFeePriceCall, Me.colAskFeePricePut, Me.colAskBidSpreadMinCall, Me.colAskBidSpreadMinPut, Me.colBidFeeRateCall, Me.colBidFeeRatePut, Me.colAskPriceMaxCall, Me.colAskPriceMaxPut, Me.colAskPriceMinCall, Me.colAskPriceMinPut, Me.colBidPriceMaxCall, Me.colBidPriceMaxPut, Me.colBidPriceMinCall, Me.colBidPriceMinPut})
        Me.grid.ContextMenuStrip = Me.cmGrid
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 33)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(927, 381)
        Me.grid.StandardTab = True
        Me.grid.TabIndex = 0
        '
        'colProductCode
        '
        Me.colProductCode.DataPropertyName = "ProductCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colProductCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.colProductCode.HeaderText = "銘柄コード"
        Me.colProductCode.Name = "colProductCode"
        Me.colProductCode.ReadOnly = True
        Me.colProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colProductCode.Width = 108
        '
        'colProductSubCode
        '
        Me.colProductSubCode.DataPropertyName = "ProductSubCode"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colProductSubCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.colProductSubCode.HeaderText = "銘柄詳細コード"
        Me.colProductSubCode.Name = "colProductSubCode"
        Me.colProductSubCode.ReadOnly = True
        Me.colProductSubCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colProductSubCode.Width = 108
        '
        'colComCode
        '
        Me.colComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colComCode.DefaultCellStyle = DataGridViewCellStyle4
        Me.colComCode.HeaderText = "通貨ペアコード"
        Me.colComCode.Name = "colComCode"
        Me.colComCode.ReadOnly = True
        Me.colComCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colComName
        '
        Me.colComName.DataPropertyName = "ComName"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colComName.DefaultCellStyle = DataGridViewCellStyle5
        Me.colComName.HeaderText = "通貨ペア"
        Me.colComName.Name = "colComName"
        Me.colComName.ReadOnly = True
        Me.colComName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colComName.Width = 58
        '
        'colComOrder
        '
        Me.colComOrder.DataPropertyName = "ComOrder"
        Me.colComOrder.HeaderText = "通貨ペアソート"
        Me.colComOrder.Name = "colComOrder"
        Me.colComOrder.ReadOnly = True
        Me.colComOrder.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colComOrder.Visible = False
        '
        'colOpType
        '
        Me.colOpType.DataPropertyName = "OpType"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colOpType.DefaultCellStyle = DataGridViewCellStyle6
        Me.colOpType.HeaderText = "オプション種別コード"
        Me.colOpType.Name = "colOpType"
        Me.colOpType.ReadOnly = True
        Me.colOpType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colOpName
        '
        Me.colOpName.DataPropertyName = "OpName"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colOpName.DefaultCellStyle = DataGridViewCellStyle7
        Me.colOpName.HeaderText = "オプション種別"
        Me.colOpName.Name = "colOpName"
        Me.colOpName.ReadOnly = True
        Me.colOpName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colOpName.Width = 81
        '
        'colStartTime
        '
        Me.colStartTime.DataPropertyName = "StartTime"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.Format = "HH:mm"
        DataGridViewCellStyle8.NullValue = Nothing
        Me.colStartTime.DefaultCellStyle = DataGridViewCellStyle8
        Me.colStartTime.HeaderText = "取引開始"
        Me.colStartTime.Name = "colStartTime"
        Me.colStartTime.ReadOnly = True
        Me.colStartTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colStartTime.Width = 42
        '
        'colTradeLimitTime
        '
        Me.colTradeLimitTime.DataPropertyName = "TradeLimitTime"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.Format = "HH:mm"
        Me.colTradeLimitTime.DefaultCellStyle = DataGridViewCellStyle9
        Me.colTradeLimitTime.HeaderText = "取引期限"
        Me.colTradeLimitTime.Name = "colTradeLimitTime"
        Me.colTradeLimitTime.ReadOnly = True
        Me.colTradeLimitTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTradeLimitTime.Width = 42
        '
        'colExercTime
        '
        Me.colExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.Format = "HH:mm"
        Me.colExercTime.DefaultCellStyle = DataGridViewCellStyle10
        Me.colExercTime.HeaderText = "行使期日"
        Me.colExercTime.Name = "colExercTime"
        Me.colExercTime.ReadOnly = True
        Me.colExercTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercTime.Width = 42
        '
        'colExercPriceTimespan
        '
        Me.colExercPriceTimespan.DataPropertyName = "ExercPriceTimespan"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colExercPriceTimespan.DefaultCellStyle = DataGridViewCellStyle11
        Me.colExercPriceTimespan.HeaderText = "行使価格決定時間"
        Me.colExercPriceTimespan.Name = "colExercPriceTimespan"
        Me.colExercPriceTimespan.ReadOnly = True
        Me.colExercPriceTimespan.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colExercPriceRate
        '
        Me.colExercPriceRate.DataPropertyName = "ExercPriceRate"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colExercPriceRate.DefaultCellStyle = DataGridViewCellStyle12
        Me.colExercPriceRate.HeaderText = "行使価格決定時レート"
        Me.colExercPriceRate.Name = "colExercPriceRate"
        Me.colExercPriceRate.ReadOnly = True
        Me.colExercPriceRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercPriceRate.Width = 61
        '
        'colExercPriceUnitType
        '
        Me.colExercPriceUnitType.DataPropertyName = "ExercPriceUnitType"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colExercPriceUnitType.DefaultCellStyle = DataGridViewCellStyle13
        Me.colExercPriceUnitType.HeaderText = "行使価格刻み幅種別コード"
        Me.colExercPriceUnitType.Name = "colExercPriceUnitType"
        Me.colExercPriceUnitType.ReadOnly = True
        Me.colExercPriceUnitType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colExercPriceUnitTypeName
        '
        Me.colExercPriceUnitTypeName.DataPropertyName = "ExercPriceUnitTypeName"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colExercPriceUnitTypeName.DefaultCellStyle = DataGridViewCellStyle14
        Me.colExercPriceUnitTypeName.HeaderText = "行使価格刻み幅種別"
        Me.colExercPriceUnitTypeName.Name = "colExercPriceUnitTypeName"
        Me.colExercPriceUnitTypeName.ReadOnly = True
        Me.colExercPriceUnitTypeName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colExercPriceUnit
        '
        Me.colExercPriceUnit.DataPropertyName = "ExercPriceUnit"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colExercPriceUnit.DefaultCellStyle = DataGridViewCellStyle15
        Me.colExercPriceUnit.HeaderText = "行使価格刻み幅"
        Me.colExercPriceUnit.Name = "colExercPriceUnit"
        Me.colExercPriceUnit.ReadOnly = True
        Me.colExercPriceUnit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercPriceUnit.Width = 61
        '
        'colExercPriceSetting
        '
        Me.colExercPriceSetting.DataPropertyName = "ExercPriceSetting"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colExercPriceSetting.DefaultCellStyle = DataGridViewCellStyle16
        Me.colExercPriceSetting.HeaderText = "行使価格設定"
        Me.colExercPriceSetting.Name = "colExercPriceSetting"
        Me.colExercPriceSetting.ReadOnly = True
        Me.colExercPriceSetting.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercPriceSetting.Width = 61
        '
        'colExercPrice
        '
        Me.colExercPrice.DataPropertyName = "ExercPrice"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colExercPrice.DefaultCellStyle = DataGridViewCellStyle17
        Me.colExercPrice.HeaderText = "行使価格"
        Me.colExercPrice.Name = "colExercPrice"
        Me.colExercPrice.ReadOnly = True
        Me.colExercPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExercPrice.Width = 61
        '
        'colProductEnabled
        '
        Me.colProductEnabled.DataPropertyName = "ProductEnabled"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colProductEnabled.DefaultCellStyle = DataGridViewCellStyle18
        Me.colProductEnabled.HeaderText = "銘柄有効フラグ"
        Me.colProductEnabled.Name = "colProductEnabled"
        Me.colProductEnabled.ReadOnly = True
        Me.colProductEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colProductSubEnabled
        '
        Me.colProductSubEnabled.DataPropertyName = "ProductSubEnabled"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colProductSubEnabled.DefaultCellStyle = DataGridViewCellStyle19
        Me.colProductSubEnabled.HeaderText = "銘柄詳細有効フラグ"
        Me.colProductSubEnabled.Name = "colProductSubEnabled"
        Me.colProductSubEnabled.ReadOnly = True
        Me.colProductSubEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colProductSubStatus
        '
        Me.colProductSubStatus.DataPropertyName = "ProductSubStatus"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colProductSubStatus.DefaultCellStyle = DataGridViewCellStyle20
        Me.colProductSubStatus.HeaderText = "銘柄詳細ステータス"
        Me.colProductSubStatus.Name = "colProductSubStatus"
        Me.colProductSubStatus.ReadOnly = True
        Me.colProductSubStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colStatus
        '
        Me.colStatus.DataPropertyName = "Status"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colStatus.DefaultCellStyle = DataGridViewCellStyle21
        Me.colStatus.HeaderText = "ステータス"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colRateSeq
        '
        Me.colRateSeq.DataPropertyName = "RateSeq"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colRateSeq.DefaultCellStyle = DataGridViewCellStyle22
        Me.colRateSeq.HeaderText = "レートSeq"
        Me.colRateSeq.Name = "colRateSeq"
        Me.colRateSeq.ReadOnly = True
        Me.colRateSeq.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colRate
        '
        Me.colRate.DataPropertyName = "Rate"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colRate.DefaultCellStyle = DataGridViewCellStyle23
        Me.colRate.HeaderText = "レート"
        Me.colRate.Name = "colRate"
        Me.colRate.ReadOnly = True
        Me.colRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colRate.Width = 61
        '
        'colRateTime
        '
        Me.colRateTime.DataPropertyName = "RateTime"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle24.Format = "HH:mm:ss"
        Me.colRateTime.DefaultCellStyle = DataGridViewCellStyle24
        Me.colRateTime.HeaderText = "レート時刻"
        Me.colRateTime.Name = "colRateTime"
        Me.colRateTime.ReadOnly = True
        Me.colRateTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colRateTime.Width = 46
        '
        'colCalcTime
        '
        Me.colCalcTime.DataPropertyName = "CalcTime"
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle25.Format = "HH:mm:ss"
        Me.colCalcTime.DefaultCellStyle = DataGridViewCellStyle25
        Me.colCalcTime.HeaderText = "計算時刻"
        Me.colCalcTime.Name = "colCalcTime"
        Me.colCalcTime.ReadOnly = True
        Me.colCalcTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCalcTime.Width = 46
        '
        'colPriceAskCall
        '
        Me.colPriceAskCall.DataPropertyName = "PriceAskCall"
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle26.Format = "0.########"
        Me.colPriceAskCall.DefaultCellStyle = DataGridViewCellStyle26
        Me.colPriceAskCall.HeaderText = "購入\nCall"
        Me.colPriceAskCall.Name = "colPriceAskCall"
        Me.colPriceAskCall.ReadOnly = True
        Me.colPriceAskCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceAskCall.Width = 46
        '
        'colPriceBidCall
        '
        Me.colPriceBidCall.DataPropertyName = "PriceBidCall"
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle27.Format = "0.########"
        Me.colPriceBidCall.DefaultCellStyle = DataGridViewCellStyle27
        Me.colPriceBidCall.HeaderText = "清算\nCall"
        Me.colPriceBidCall.Name = "colPriceBidCall"
        Me.colPriceBidCall.ReadOnly = True
        Me.colPriceBidCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceBidCall.Width = 46
        '
        'colPriceAskPut
        '
        Me.colPriceAskPut.DataPropertyName = "PriceAskPut"
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle28.Format = "0.########"
        Me.colPriceAskPut.DefaultCellStyle = DataGridViewCellStyle28
        Me.colPriceAskPut.HeaderText = "購入\nPut"
        Me.colPriceAskPut.Name = "colPriceAskPut"
        Me.colPriceAskPut.ReadOnly = True
        Me.colPriceAskPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceAskPut.Width = 46
        '
        'colPriceBidPut
        '
        Me.colPriceBidPut.DataPropertyName = "PriceBidPut"
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle29.Format = "0.########"
        Me.colPriceBidPut.DefaultCellStyle = DataGridViewCellStyle29
        Me.colPriceBidPut.HeaderText = "清算\nPut"
        Me.colPriceBidPut.Name = "colPriceBidPut"
        Me.colPriceBidPut.ReadOnly = True
        Me.colPriceBidPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPriceBidPut.Width = 46
        '
        'colVolAskCall
        '
        Me.colVolAskCall.DataPropertyName = "VolAskCall"
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle30.Format = "0.00000000"
        Me.colVolAskCall.DefaultCellStyle = DataGridViewCellStyle30
        Me.colVolAskCall.HeaderText = "評価Vol\n購入\nCall"
        Me.colVolAskCall.Name = "colVolAskCall"
        Me.colVolAskCall.ReadOnly = True
        Me.colVolAskCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolAskCall.Width = 62
        '
        'colVolBidCall
        '
        Me.colVolBidCall.DataPropertyName = "VolBidCall"
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle31.Format = "0.00000000"
        Me.colVolBidCall.DefaultCellStyle = DataGridViewCellStyle31
        Me.colVolBidCall.HeaderText = "評価Vol\n清算\nCall"
        Me.colVolBidCall.Name = "colVolBidCall"
        Me.colVolBidCall.ReadOnly = True
        Me.colVolBidCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolBidCall.Width = 62
        '
        'colVolAskPut
        '
        Me.colVolAskPut.DataPropertyName = "VolAskPut"
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle32.Format = "0.00000000"
        Me.colVolAskPut.DefaultCellStyle = DataGridViewCellStyle32
        Me.colVolAskPut.HeaderText = "評価Vol\n購入\nPut"
        Me.colVolAskPut.Name = "colVolAskPut"
        Me.colVolAskPut.ReadOnly = True
        Me.colVolAskPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolAskPut.Width = 62
        '
        'colVolBidPut
        '
        Me.colVolBidPut.DataPropertyName = "VolBidPut"
        DataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle33.Format = "0.00000000"
        Me.colVolBidPut.DefaultCellStyle = DataGridViewCellStyle33
        Me.colVolBidPut.HeaderText = "評価Vol\n清算\nPut"
        Me.colVolBidPut.Name = "colVolBidPut"
        Me.colVolBidPut.ReadOnly = True
        Me.colVolBidPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolBidPut.Width = 62
        '
        'colHVol
        '
        Me.colHVol.DataPropertyName = "HVol"
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle34.Format = "0.00000000"
        Me.colHVol.DefaultCellStyle = DataGridViewCellStyle34
        Me.colHVol.HeaderText = "HV"
        Me.colHVol.Name = "colHVol"
        Me.colHVol.ReadOnly = True
        Me.colHVol.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colHVol.Width = 62
        '
        'colInterestRate
        '
        Me.colInterestRate.DataPropertyName = "InterestRate"
        DataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle35.Format = "0.########"
        Me.colInterestRate.DefaultCellStyle = DataGridViewCellStyle35
        Me.colInterestRate.HeaderText = "短期\n金利(%)"
        Me.colInterestRate.Name = "colInterestRate"
        Me.colInterestRate.ReadOnly = True
        Me.colInterestRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colInterestRate.Width = 61
        '
        'colSwapRate
        '
        Me.colSwapRate.DataPropertyName = "SwapRate"
        DataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle36.Format = "0.########"
        Me.colSwapRate.DefaultCellStyle = DataGridViewCellStyle36
        Me.colSwapRate.HeaderText = "スワップ\n金利(%)"
        Me.colSwapRate.Name = "colSwapRate"
        Me.colSwapRate.ReadOnly = True
        Me.colSwapRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colSwapRate.Width = 61
        '
        'colVolRatio1Call
        '
        Me.colVolRatio1Call.DataPropertyName = "VolRatio1Call"
        DataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle37.Format = "0.########"
        Me.colVolRatio1Call.DefaultCellStyle = DataGridViewCellStyle37
        Me.colVolRatio1Call.HeaderText = "Vol\nRatio1\nCall"
        Me.colVolRatio1Call.Name = "colVolRatio1Call"
        Me.colVolRatio1Call.ReadOnly = True
        Me.colVolRatio1Call.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolRatio1Call.Width = 61
        '
        'colVolRatio1Put
        '
        Me.colVolRatio1Put.DataPropertyName = "VolRatio1Put"
        DataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle38.Format = "0.########"
        DataGridViewCellStyle38.NullValue = Nothing
        Me.colVolRatio1Put.DefaultCellStyle = DataGridViewCellStyle38
        Me.colVolRatio1Put.HeaderText = "Vol\nRatio1\nPut"
        Me.colVolRatio1Put.Name = "colVolRatio1Put"
        Me.colVolRatio1Put.ReadOnly = True
        Me.colVolRatio1Put.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolRatio1Put.Width = 61
        '
        'colVolRatio2Call
        '
        Me.colVolRatio2Call.DataPropertyName = "VolRatio2Call"
        DataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle39.Format = "0.########"
        Me.colVolRatio2Call.DefaultCellStyle = DataGridViewCellStyle39
        Me.colVolRatio2Call.HeaderText = "Vol\nRatio2\nCall"
        Me.colVolRatio2Call.Name = "colVolRatio2Call"
        Me.colVolRatio2Call.ReadOnly = True
        Me.colVolRatio2Call.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolRatio2Call.Width = 61
        '
        'colVolRatio2Put
        '
        Me.colVolRatio2Put.DataPropertyName = "VolRatio2Put"
        DataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle40.Format = "0.########"
        Me.colVolRatio2Put.DefaultCellStyle = DataGridViewCellStyle40
        Me.colVolRatio2Put.HeaderText = "Vol\nRatio2\nPut"
        Me.colVolRatio2Put.Name = "colVolRatio2Put"
        Me.colVolRatio2Put.ReadOnly = True
        Me.colVolRatio2Put.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolRatio2Put.Width = 61
        '
        'colVolSpread
        '
        Me.colVolSpread.DataPropertyName = "VolSpread"
        DataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle41.Format = "0.########"
        Me.colVolSpread.DefaultCellStyle = DataGridViewCellStyle41
        Me.colVolSpread.HeaderText = "Vol\nSpread"
        Me.colVolSpread.Name = "colVolSpread"
        Me.colVolSpread.ReadOnly = True
        Me.colVolSpread.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSpread.Width = 61
        '
        'colVolSmileACall
        '
        Me.colVolSmileACall.DataPropertyName = "VolSmileACall"
        DataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle42.Format = "0.########"
        Me.colVolSmileACall.DefaultCellStyle = DataGridViewCellStyle42
        Me.colVolSmileACall.HeaderText = "Vol\nSmile a\nCall"
        Me.colVolSmileACall.Name = "colVolSmileACall"
        Me.colVolSmileACall.ReadOnly = True
        Me.colVolSmileACall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSmileACall.Width = 61
        '
        'colVolSmileAPut
        '
        Me.colVolSmileAPut.DataPropertyName = "VolSmileAPut"
        DataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle43.Format = "0.########"
        Me.colVolSmileAPut.DefaultCellStyle = DataGridViewCellStyle43
        Me.colVolSmileAPut.HeaderText = "Vol\nSmile a\nPut"
        Me.colVolSmileAPut.Name = "colVolSmileAPut"
        Me.colVolSmileAPut.ReadOnly = True
        Me.colVolSmileAPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSmileAPut.Width = 61
        '
        'colVolSmileBCall
        '
        Me.colVolSmileBCall.DataPropertyName = "VolSmileBCall"
        DataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle44.Format = "0.########"
        Me.colVolSmileBCall.DefaultCellStyle = DataGridViewCellStyle44
        Me.colVolSmileBCall.HeaderText = "Vol\nSmile b\nCall"
        Me.colVolSmileBCall.Name = "colVolSmileBCall"
        Me.colVolSmileBCall.ReadOnly = True
        Me.colVolSmileBCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSmileBCall.Width = 61
        '
        'colVolSmileBPut
        '
        Me.colVolSmileBPut.DataPropertyName = "VolSmileBPut"
        DataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle45.Format = "0.########"
        Me.colVolSmileBPut.DefaultCellStyle = DataGridViewCellStyle45
        Me.colVolSmileBPut.HeaderText = "Vol\nSmile b\nPut"
        Me.colVolSmileBPut.Name = "colVolSmileBPut"
        Me.colVolSmileBPut.ReadOnly = True
        Me.colVolSmileBPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSmileBPut.Width = 61
        '
        'colVolSpreadITMCall
        '
        Me.colVolSpreadITMCall.DataPropertyName = "VolSpreadITMCall"
        DataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle46.Format = "0.########"
        Me.colVolSpreadITMCall.DefaultCellStyle = DataGridViewCellStyle46
        Me.colVolSpreadITMCall.HeaderText = "Vol\nSpread\nCall"
        Me.colVolSpreadITMCall.Name = "colVolSpreadITMCall"
        Me.colVolSpreadITMCall.ReadOnly = True
        Me.colVolSpreadITMCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSpreadITMCall.Width = 61
        '
        'colVolSpreadITMPut
        '
        Me.colVolSpreadITMPut.DataPropertyName = "VolSpreadITMPut"
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle47.Format = "0.########"
        Me.colVolSpreadITMPut.DefaultCellStyle = DataGridViewCellStyle47
        Me.colVolSpreadITMPut.HeaderText = "Vol\nSpread\nPut"
        Me.colVolSpreadITMPut.Name = "colVolSpreadITMPut"
        Me.colVolSpreadITMPut.ReadOnly = True
        Me.colVolSpreadITMPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSpreadITMPut.Width = 61
        '
        'colVolSpreadOTMCall
        '
        Me.colVolSpreadOTMCall.DataPropertyName = "VolSpreadOTMCall"
        DataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle48.Format = "0.########"
        Me.colVolSpreadOTMCall.DefaultCellStyle = DataGridViewCellStyle48
        Me.colVolSpreadOTMCall.HeaderText = "Vol\nSpread\nCall"
        Me.colVolSpreadOTMCall.Name = "colVolSpreadOTMCall"
        Me.colVolSpreadOTMCall.ReadOnly = True
        Me.colVolSpreadOTMCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVolSpreadOTMCall.Width = 61
        '
        'colVolSpreadOTMPut
        '
        Me.colVolSpreadOTMPut.DataPropertyName = "VolSpreadOTMPut"
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle49.Format = "0.########"
        Me.colVolSpreadOTMPut.DefaultCellStyle = DataGridViewCellStyle49
        Me.colVolSpreadOTMPut.HeaderText = "Vol\nSpread\nPut"
        Me.colVolSpreadOTMPut.Name = "colVolSpreadOTMPut"
        Me.colVolSpreadOTMPut.ReadOnly = True
        '
        'colAskFeePriceCall
        '
        Me.colAskFeePriceCall.DataPropertyName = "AskFeePriceCall"
        DataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskFeePriceCall.DefaultCellStyle = DataGridViewCellStyle50
        Me.colAskFeePriceCall.HeaderText = "購入\nFee\nCall"
        Me.colAskFeePriceCall.Name = "colAskFeePriceCall"
        Me.colAskFeePriceCall.ReadOnly = True
        Me.colAskFeePriceCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskFeePriceCall.Width = 46
        '
        'colAskFeePricePut
        '
        Me.colAskFeePricePut.DataPropertyName = "AskFeePricePut"
        DataGridViewCellStyle51.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskFeePricePut.DefaultCellStyle = DataGridViewCellStyle51
        Me.colAskFeePricePut.HeaderText = "購入\nFee\nPut"
        Me.colAskFeePricePut.Name = "colAskFeePricePut"
        Me.colAskFeePricePut.ReadOnly = True
        Me.colAskFeePricePut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskFeePricePut.Width = 46
        '
        'colAskBidSpreadMinCall
        '
        Me.colAskBidSpreadMinCall.DataPropertyName = "AskBidSpreadMinCall"
        DataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskBidSpreadMinCall.DefaultCellStyle = DataGridViewCellStyle52
        Me.colAskBidSpreadMinCall.HeaderText = "価格\nSpread\nCall"
        Me.colAskBidSpreadMinCall.Name = "colAskBidSpreadMinCall"
        Me.colAskBidSpreadMinCall.ReadOnly = True
        Me.colAskBidSpreadMinCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskBidSpreadMinCall.Width = 46
        '
        'colAskBidSpreadMinPut
        '
        Me.colAskBidSpreadMinPut.DataPropertyName = "AskBidSpreadMinPut"
        DataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskBidSpreadMinPut.DefaultCellStyle = DataGridViewCellStyle53
        Me.colAskBidSpreadMinPut.HeaderText = "価格\nSpread\nPut"
        Me.colAskBidSpreadMinPut.Name = "colAskBidSpreadMinPut"
        Me.colAskBidSpreadMinPut.ReadOnly = True
        Me.colAskBidSpreadMinPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskBidSpreadMinPut.Width = 46
        '
        'colBidFeeRateCall
        '
        Me.colBidFeeRateCall.DataPropertyName = "BidFeeRateCall"
        DataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle54.Format = "0.######"
        Me.colBidFeeRateCall.DefaultCellStyle = DataGridViewCellStyle54
        Me.colBidFeeRateCall.HeaderText = "清算\nFee(%)\nCall"
        Me.colBidFeeRateCall.Name = "colBidFeeRateCall"
        Me.colBidFeeRateCall.ReadOnly = True
        Me.colBidFeeRateCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBidFeeRateCall.Width = 61
        '
        'colBidFeeRatePut
        '
        Me.colBidFeeRatePut.DataPropertyName = "BidFeeRatePut"
        DataGridViewCellStyle55.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle55.Format = "0.######"
        Me.colBidFeeRatePut.DefaultCellStyle = DataGridViewCellStyle55
        Me.colBidFeeRatePut.HeaderText = "清算\nFee(%)\nPut"
        Me.colBidFeeRatePut.Name = "colBidFeeRatePut"
        Me.colBidFeeRatePut.ReadOnly = True
        Me.colBidFeeRatePut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBidFeeRatePut.Width = 61
        '
        'colAskPriceMaxCall
        '
        Me.colAskPriceMaxCall.DataPropertyName = "AskPriceMaxCall"
        DataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskPriceMaxCall.DefaultCellStyle = DataGridViewCellStyle56
        Me.colAskPriceMaxCall.HeaderText = "MAX\n購入\nCall"
        Me.colAskPriceMaxCall.Name = "colAskPriceMaxCall"
        Me.colAskPriceMaxCall.ReadOnly = True
        Me.colAskPriceMaxCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskPriceMaxCall.Width = 46
        '
        'colAskPriceMaxPut
        '
        Me.colAskPriceMaxPut.DataPropertyName = "AskPriceMaxPut"
        DataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskPriceMaxPut.DefaultCellStyle = DataGridViewCellStyle57
        Me.colAskPriceMaxPut.HeaderText = "MAX\n購入\nPut"
        Me.colAskPriceMaxPut.Name = "colAskPriceMaxPut"
        Me.colAskPriceMaxPut.ReadOnly = True
        Me.colAskPriceMaxPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskPriceMaxPut.Width = 46
        '
        'colAskPriceMinCall
        '
        Me.colAskPriceMinCall.DataPropertyName = "AskPriceMinCall"
        DataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskPriceMinCall.DefaultCellStyle = DataGridViewCellStyle58
        Me.colAskPriceMinCall.HeaderText = "MIN\n購入\nCall"
        Me.colAskPriceMinCall.Name = "colAskPriceMinCall"
        Me.colAskPriceMinCall.ReadOnly = True
        Me.colAskPriceMinCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskPriceMinCall.Width = 46
        '
        'colAskPriceMinPut
        '
        Me.colAskPriceMinPut.DataPropertyName = "AskPriceMinPut"
        DataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colAskPriceMinPut.DefaultCellStyle = DataGridViewCellStyle59
        Me.colAskPriceMinPut.HeaderText = "MIN\n購入\nPut"
        Me.colAskPriceMinPut.Name = "colAskPriceMinPut"
        Me.colAskPriceMinPut.ReadOnly = True
        Me.colAskPriceMinPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAskPriceMinPut.Width = 46
        '
        'colBidPriceMaxCall
        '
        Me.colBidPriceMaxCall.DataPropertyName = "BidPriceMaxCall"
        DataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colBidPriceMaxCall.DefaultCellStyle = DataGridViewCellStyle60
        Me.colBidPriceMaxCall.HeaderText = "MAX\n清算\nCall"
        Me.colBidPriceMaxCall.Name = "colBidPriceMaxCall"
        Me.colBidPriceMaxCall.ReadOnly = True
        Me.colBidPriceMaxCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBidPriceMaxCall.Width = 46
        '
        'colBidPriceMaxPut
        '
        Me.colBidPriceMaxPut.DataPropertyName = "BidPriceMaxPut"
        DataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colBidPriceMaxPut.DefaultCellStyle = DataGridViewCellStyle61
        Me.colBidPriceMaxPut.HeaderText = "MAX\n清算\nPut"
        Me.colBidPriceMaxPut.Name = "colBidPriceMaxPut"
        Me.colBidPriceMaxPut.ReadOnly = True
        Me.colBidPriceMaxPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBidPriceMaxPut.Width = 46
        '
        'colBidPriceMinCall
        '
        Me.colBidPriceMinCall.DataPropertyName = "BidPriceMinCall"
        DataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colBidPriceMinCall.DefaultCellStyle = DataGridViewCellStyle62
        Me.colBidPriceMinCall.HeaderText = "MIN\n清算\nCall"
        Me.colBidPriceMinCall.Name = "colBidPriceMinCall"
        Me.colBidPriceMinCall.ReadOnly = True
        Me.colBidPriceMinCall.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBidPriceMinCall.Width = 46
        '
        'colBidPriceMinPut
        '
        Me.colBidPriceMinPut.DataPropertyName = "BidPriceMinPut"
        DataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colBidPriceMinPut.DefaultCellStyle = DataGridViewCellStyle63
        Me.colBidPriceMinPut.HeaderText = "MIN\n清算\nPut"
        Me.colBidPriceMinPut.Name = "colBidPriceMinPut"
        Me.colBidPriceMinPut.ReadOnly = True
        Me.colBidPriceMinPut.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBidPriceMinPut.Width = 46
        '
        'PriceMonitor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(927, 414)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "PriceMonitor"
        Me.Text = "時価モニター"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.cmGrid.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents cbOpType As System.Windows.Forms.ComboBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents chkViewColumns As System.Windows.Forms.CheckBox
    Friend WithEvents colProductCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProductSubCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colComOrder As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOpType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOpName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStartTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTradeLimitTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPriceTimespan As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPriceRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPriceUnitType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPriceUnitTypeName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPriceUnit As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPriceSetting As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExercPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProductEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProductSubEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProductSubStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRateSeq As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRateTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCalcTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceAskCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceBidCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceAskPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPriceBidPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolAskCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolBidCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolAskPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolBidPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colHVol As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colInterestRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSwapRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolRatio1Call As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolRatio1Put As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolRatio2Call As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolRatio2Put As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSpread As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSmileACall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSmileAPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSmileBCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSmileBPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSpreadITMCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSpreadITMPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSpreadOTMCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVolSpreadOTMPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskFeePriceCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskFeePricePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskBidSpreadMinCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskBidSpreadMinPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBidFeeRateCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBidFeeRatePut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskPriceMaxCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskPriceMaxPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskPriceMinCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAskPriceMinPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBidPriceMaxCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBidPriceMaxPut As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBidPriceMinCall As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBidPriceMinPut As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
