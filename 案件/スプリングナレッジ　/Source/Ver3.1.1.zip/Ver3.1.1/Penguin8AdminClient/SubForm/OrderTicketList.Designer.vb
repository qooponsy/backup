﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrderTicketList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dtpSysDateTo = New System.Windows.Forms.DateTimePicker()
        Me.dtpSysDateFrom = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.OrderReqTime2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SubSeqCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderReqTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Own = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BuySell = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypeOfTrading = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Classification = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExecutionDevision = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Lot = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Premium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandReqTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercProcTime2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercProcTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutPrice2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Payout2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Payout = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeStatusName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dtpSysDateTo)
        Me.Panel1.Controls.Add(Me.dtpSysDateFrom)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.btnPrint)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(800, 41)
        Me.Panel1.TabIndex = 21
        '
        'dtpSysDateTo
        '
        Me.dtpSysDateTo.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDateTo.Location = New System.Drawing.Point(285, 7)
        Me.dtpSysDateTo.Name = "dtpSysDateTo"
        Me.dtpSysDateTo.ShowCheckBox = True
        Me.dtpSysDateTo.Size = New System.Drawing.Size(117, 19)
        Me.dtpSysDateTo.TabIndex = 18
        '
        'dtpSysDateFrom
        '
        Me.dtpSysDateFrom.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDateFrom.Location = New System.Drawing.Point(139, 7)
        Me.dtpSysDateFrom.Name = "dtpSysDateFrom"
        Me.dtpSysDateFrom.ShowCheckBox = True
        Me.dtpSysDateFrom.Size = New System.Drawing.Size(117, 19)
        Me.dtpSysDateFrom.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(262, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "～"
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(586, 6)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(89, 29)
        Me.btnPrint.TabIndex = 15
        Me.btnPrint.Text = "印刷"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(497, 6)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 14
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 6)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(408, 6)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 13
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 17
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 538)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(800, 32)
        Me.pnlSearchAdd.TabIndex = 23
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(204, 207)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(232, 63)
        Me.lblNoData.TabIndex = 24
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.OrderReqTime2, Me.SysDate, Me.TradeSeq, Me.SubSeqCount, Me.CustCode, Me.CustName, Me.OrderReqTime, Me.Own, Me.BuySell, Me.TypeOfTrading, Me.ComCode, Me.ComName, Me.TradeType, Me.TradeTypeName, Me.ExercPrice, Me.ExercTime, Me.Classification, Me.ExecutionDevision, Me.TradeTime, Me.Lot, Me.Price, Me.Premium, Me.AbandReqTime, Me.ExercProcTime2, Me.ExercProcTime, Me.PayoutPrice2, Me.Payout2, Me.PayoutPrice, Me.Payout, Me.TradeStatusName})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 41)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle32.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle32
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(800, 497)
        Me.grid.TabIndex = 25
        '
        'OrderReqTime2
        '
        Me.OrderReqTime2.DataPropertyName = "OrderReqTime2"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.Format = "yyyy/MM/dd HH:mm:ss"
        Me.OrderReqTime2.DefaultCellStyle = DataGridViewCellStyle2
        Me.OrderReqTime2.HeaderText = "約定年月日"
        Me.OrderReqTime2.Name = "OrderReqTime2"
        Me.OrderReqTime2.ReadOnly = True
        Me.OrderReqTime2.Width = 130
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle3
        Me.SysDate.HeaderText = "作成日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 80
        '
        'TradeSeq
        '
        Me.TradeSeq.DataPropertyName = "TradeSeq"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeSeq.DefaultCellStyle = DataGridViewCellStyle4
        Me.TradeSeq.HeaderText = "注文番号"
        Me.TradeSeq.Name = "TradeSeq"
        Me.TradeSeq.ReadOnly = True
        Me.TradeSeq.Width = 108
        '
        'SubSeqCount
        '
        Me.SubSeqCount.DataPropertyName = "SubSeqCount"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.SubSeqCount.DefaultCellStyle = DataGridViewCellStyle5
        Me.SubSeqCount.HeaderText = "注文番号枝番"
        Me.SubSeqCount.Name = "SubSeqCount"
        Me.SubSeqCount.ReadOnly = True
        Me.SubSeqCount.Width = 80
        '
        'CustCode
        '
        Me.CustCode.DataPropertyName = "CustCode"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustCode.DefaultCellStyle = DataGridViewCellStyle6
        Me.CustCode.HeaderText = "委託者コード"
        Me.CustCode.Name = "CustCode"
        Me.CustCode.ReadOnly = True
        Me.CustCode.Width = 70
        '
        'CustName
        '
        Me.CustName.DataPropertyName = "CustName"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustName.DefaultCellStyle = DataGridViewCellStyle7
        Me.CustName.HeaderText = "顧客氏名"
        Me.CustName.Name = "CustName"
        Me.CustName.ReadOnly = True
        Me.CustName.Width = 80
        '
        'OrderReqTime
        '
        Me.OrderReqTime.DataPropertyName = "OrderReqTime"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.Format = "yyyy/MM/dd HH:mm:ss"
        Me.OrderReqTime.DefaultCellStyle = DataGridViewCellStyle8
        Me.OrderReqTime.HeaderText = "注文時間"
        Me.OrderReqTime.Name = "OrderReqTime"
        Me.OrderReqTime.ReadOnly = True
        Me.OrderReqTime.Width = 130
        '
        'Own
        '
        Me.Own.DataPropertyName = "Own"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Own.DefaultCellStyle = DataGridViewCellStyle9
        Me.Own.HeaderText = "自己又委託"
        Me.Own.Name = "Own"
        Me.Own.ReadOnly = True
        Me.Own.Width = 90
        '
        'BuySell
        '
        Me.BuySell.DataPropertyName = "BuySell"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.BuySell.DefaultCellStyle = DataGridViewCellStyle10
        Me.BuySell.HeaderText = "売付/買付"
        Me.BuySell.Name = "BuySell"
        Me.BuySell.ReadOnly = True
        Me.BuySell.Width = 90
        '
        'TypeOfTrading
        '
        Me.TypeOfTrading.DataPropertyName = "TypeOfTrading"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.TypeOfTrading.DefaultCellStyle = DataGridViewCellStyle11
        Me.TypeOfTrading.HeaderText = "取引種類"
        Me.TypeOfTrading.Name = "TypeOfTrading"
        Me.TypeOfTrading.ReadOnly = True
        Me.TypeOfTrading.Width = 140
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle12
        Me.ComCode.HeaderText = "通貨ペア(Code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle13
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 80
        '
        'TradeType
        '
        Me.TradeType.DataPropertyName = "TradeType"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeType.DefaultCellStyle = DataGridViewCellStyle14
        Me.TradeType.HeaderText = "種別(Code)"
        Me.TradeType.Name = "TradeType"
        Me.TradeType.ReadOnly = True
        Me.TradeType.Visible = False
        '
        'TradeTypeName
        '
        Me.TradeTypeName.DataPropertyName = "TradeTypeName"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeTypeName.DefaultCellStyle = DataGridViewCellStyle15
        Me.TradeTypeName.FillWeight = 80.0!
        Me.TradeTypeName.HeaderText = "種別"
        Me.TradeTypeName.Name = "TradeTypeName"
        Me.TradeTypeName.ReadOnly = True
        Me.TradeTypeName.Width = 56
        '
        'ExercPrice
        '
        Me.ExercPrice.DataPropertyName = "ExercPrice"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle16.Format = "######0.000#####"
        DataGridViewCellStyle16.NullValue = Nothing
        Me.ExercPrice.DefaultCellStyle = DataGridViewCellStyle16
        Me.ExercPrice.HeaderText = "行使価格"
        Me.ExercPrice.Name = "ExercPrice"
        Me.ExercPrice.ReadOnly = True
        Me.ExercPrice.Width = 93
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle17.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle17.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle17
        Me.ExercTime.HeaderText = "行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        Me.ExercTime.Width = 96
        '
        'Classification
        '
        Me.Classification.DataPropertyName = "Classification"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Classification.DefaultCellStyle = DataGridViewCellStyle18
        Me.Classification.HeaderText = "新規・清算・行使・消滅"
        Me.Classification.Name = "Classification"
        Me.Classification.ReadOnly = True
        Me.Classification.Width = 93
        '
        'ExecutionDevision
        '
        Me.ExecutionDevision.DataPropertyName = "ExecutionDevision"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExecutionDevision.DefaultCellStyle = DataGridViewCellStyle19
        Me.ExecutionDevision.HeaderText = "執行区分"
        Me.ExecutionDevision.Name = "ExecutionDevision"
        Me.ExecutionDevision.ReadOnly = True
        Me.ExecutionDevision.Width = 80
        '
        'TradeTime
        '
        Me.TradeTime.DataPropertyName = "TradeTime"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle20.Format = "yyyy/MM/dd HH:mm:ss"
        Me.TradeTime.DefaultCellStyle = DataGridViewCellStyle20
        Me.TradeTime.HeaderText = "約定時間"
        Me.TradeTime.Name = "TradeTime"
        Me.TradeTime.ReadOnly = True
        Me.TradeTime.Width = 130
        '
        'Lot
        '
        Me.Lot.DataPropertyName = "Lot"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Lot.DefaultCellStyle = DataGridViewCellStyle21
        Me.Lot.HeaderText = "ロット"
        Me.Lot.Name = "Lot"
        Me.Lot.ReadOnly = True
        Me.Lot.Width = 60
        '
        'Price
        '
        Me.Price.DataPropertyName = "Price"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle22.Format = "#,###,###,##0.####"
        DataGridViewCellStyle22.NullValue = Nothing
        Me.Price.DefaultCellStyle = DataGridViewCellStyle22
        Me.Price.HeaderText = "購入価格"
        Me.Price.Name = "Price"
        Me.Price.ReadOnly = True
        Me.Price.Width = 60
        '
        'Premium
        '
        Me.Premium.DataPropertyName = "Premium"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle23.Format = "#,###,###,##0.####"
        Me.Premium.DefaultCellStyle = DataGridViewCellStyle23
        Me.Premium.HeaderText = "受注金額・約定金額"
        Me.Premium.Name = "Premium"
        Me.Premium.ReadOnly = True
        Me.Premium.Width = 88
        '
        'AbandReqTime
        '
        Me.AbandReqTime.DataPropertyName = "AbandReqTime"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle24.Format = "yyyy/MM/dd HH:mm:ss"
        Me.AbandReqTime.DefaultCellStyle = DataGridViewCellStyle24
        Me.AbandReqTime.HeaderText = "清算受付日時"
        Me.AbandReqTime.Name = "AbandReqTime"
        Me.AbandReqTime.ReadOnly = True
        Me.AbandReqTime.Width = 130
        '
        'ExercProcTime2
        '
        Me.ExercProcTime2.DataPropertyName = "ExercProcTime2"
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle25.Format = "yyyy/MM/dd HH:mm:ss"
        Me.ExercProcTime2.DefaultCellStyle = DataGridViewCellStyle25
        Me.ExercProcTime2.HeaderText = "清算約定時間"
        Me.ExercProcTime2.Name = "ExercProcTime2"
        Me.ExercProcTime2.ReadOnly = True
        Me.ExercProcTime2.Width = 130
        '
        'ExercProcTime
        '
        Me.ExercProcTime.DataPropertyName = "ExercProcTime"
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle26.Format = "yyyy/MM/dd HH:mm:ss"
        Me.ExercProcTime.DefaultCellStyle = DataGridViewCellStyle26
        Me.ExercProcTime.HeaderText = "行使時間"
        Me.ExercProcTime.Name = "ExercProcTime"
        Me.ExercProcTime.ReadOnly = True
        Me.ExercProcTime.Width = 130
        '
        'PayoutPrice2
        '
        Me.PayoutPrice2.DataPropertyName = "PayoutPrice2"
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle27.Format = "N0"
        Me.PayoutPrice2.DefaultCellStyle = DataGridViewCellStyle27
        Me.PayoutPrice2.HeaderText = "清算価格"
        Me.PayoutPrice2.Name = "PayoutPrice2"
        Me.PayoutPrice2.ReadOnly = True
        Me.PayoutPrice2.Width = 80
        '
        'Payout2
        '
        Me.Payout2.DataPropertyName = "Payout2"
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle28.Format = "#,###,###,##0.####"
        Me.Payout2.DefaultCellStyle = DataGridViewCellStyle28
        Me.Payout2.HeaderText = "受注金額・約定金額"
        Me.Payout2.Name = "Payout2"
        Me.Payout2.ReadOnly = True
        Me.Payout2.Width = 88
        '
        'PayoutPrice
        '
        Me.PayoutPrice.DataPropertyName = "PayoutPrice"
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle29.Format = "N0"
        Me.PayoutPrice.DefaultCellStyle = DataGridViewCellStyle29
        Me.PayoutPrice.HeaderText = "ペイアウト価格"
        Me.PayoutPrice.Name = "PayoutPrice"
        Me.PayoutPrice.ReadOnly = True
        Me.PayoutPrice.Width = 80
        '
        'Payout
        '
        Me.Payout.DataPropertyName = "Payout"
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle30.Format = "#,###,###,##0.####"
        Me.Payout.DefaultCellStyle = DataGridViewCellStyle30
        Me.Payout.HeaderText = "ペイアウト額"
        Me.Payout.Name = "Payout"
        Me.Payout.ReadOnly = True
        Me.Payout.Width = 80
        '
        'TradeStatusName
        '
        Me.TradeStatusName.DataPropertyName = "TradeStatusName"
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeStatusName.DefaultCellStyle = DataGridViewCellStyle31
        Me.TradeStatusName.HeaderText = "取引ステータス"
        Me.TradeStatusName.Name = "TradeStatusName"
        Me.TradeStatusName.ReadOnly = True
        Me.TradeStatusName.Width = 106
        '
        'OrderTicketList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 570)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Name = "OrderTicketList"
        Me.Text = "注文伝票"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents dtpSysDateTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpSysDateFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents OrderReqTime2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SysDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeSeq As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SubSeqCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents OrderReqTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Own As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BuySell As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TypeOfTrading As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeTypeName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Classification As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExecutionDevision As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lot As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Premium As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AbandReqTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercProcTime2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercProcTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PayoutPrice2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Payout2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PayoutPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Payout As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeStatusName As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
