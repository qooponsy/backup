﻿Public Class ProductSubForm
    Public Property Code As String
    Public Property SubCode As String
    Public Property ComCode As String
    Public Property ProductDeatail As String

    Private WithEvents service As New ProductSubListService

    Private Const MAX_PRICE As Integer = 1000

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT
    Private ProductEnabled As Boolean = False

    Private Sub ProductSubForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        setTitle()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbProductSubStatus.DisplayMember = "Name"
        cbProductSubStatus.ValueMember = "Code"
        cbProductSubStatus.DataSource = ProductSubStatusManager.GetList()

        cbExercStatus.DisplayMember = "Name"
        cbExercStatus.ValueMember = "Code"
        cbExercStatus.DataSource = ExercStatusManager.GetList(False, False)

        cbExercResultCall.DisplayMember = "Name"
        cbExercResultCall.ValueMember = "Code"
        cbExercResultCall.DataSource = ExercResultManager.GetList()

        cbExercResultPut.DisplayMember = "Name"
        cbExercResultPut.ValueMember = "Code"
        cbExercResultPut.DataSource = ExercResultManager.GetList()

        ProductEnabled = False

        'lblCode.Text = Code
        'lblProductCode.Text = "2013071900000001"
        'tbExercPriceSetting.Text = "+0.10"

        If SubCode = "" Then
            setFormMode(FormMode.REGIST)
            lblProductCode.Text = Code
            initRegist()
        Else
            setFormMode(FormMode.READ)
            'lblCode.Text = Code
            lblProductDetail.Text = ProductDeatail
            initEdit()
        End If

    End Sub

    Private Sub ProductSubForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormProductSubForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If SubCode = "" Then
            Me.Text = "銘柄詳細登録"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "銘柄詳細編集"
            Else
                Me.Text = "銘柄詳細参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        tbExercPriceSetting.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPrice.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbProductSubStatus.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbEnabled.Visible = (status = FormMode.REGIST Or status = FormMode.REGISTCONF Or status = FormMode.REGISTRUN)
        cbEnabled.Enabled = (status = FormMode.REGIST)
        lblEnabled.Visible = Not (status = FormMode.REGIST Or status = FormMode.REGISTCONF Or status = FormMode.REGISTRUN)

        tbVolRatio1Call.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        tbAskBidSpreadMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskPriceMaxCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAskPriceMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBidPriceMaxCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbBidPriceMinCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbExercStatus.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercRateSeq.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpExercRateTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbExercResultCall.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbExercResultPut.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select

        '2013-10-03 ADD Start
        btnEnabled.Enabled = (status = FormMode.EDIT And Not ProductEnabled)
        btnDisabled.Enabled = (status = FormMode.EDIT And ProductEnabled)
        '2013-10-03 ADD End
    End Sub

    Private Sub initRegist()
        cbEnabled.SelectedValue = ""
        cbExercStatus.SelectedValue = ""
        lblProductDetail.Text = ""
        tbVolRatio1Call.Text = ""
        tbAskBidSpreadMinCall.Text = ""
        tbAskPriceMaxCall.Text = ""
        tbAskPriceMinCall.Text = ""
        tbBidPriceMaxCall.Text = ""
        tbBidPriceMinCall.Text = ""
        cbProductSubStatus.SelectedValue = ""
        cbExercResultCall.SelectedValue = ""
        cbExercResultPut.SelectedValue = ""
    End Sub

    Private Sub initEdit()
        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of ProductSubData)) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "銘柄詳細の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).ProductSubCode <> Code Then
            MessageBox.Show(Me, "銘柄詳細の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As ProductSubData)
        Me.lblProductSubCode.Text = data.ProductSubCode
        Me.cbEnabled.SelectedValue = data.ProductEnabled
        Me.ProductEnabled = data.ProductEnabled         '2013-10-03 Add 
        Me.lblEnabled.Text = data.ProductEnabledName    '2013-10-03 Add 
        Me.cbProductSubStatus.SelectedValue = data.ProductSubStatus
        Me.lblProductCode.Text = data.ProductCode
        Me.tbExercPriceSetting.Text = data.ExercPriceSetting
        Me.tbExercPrice.Text = data.ExercPrice.ToString("######0.########")
        Me.tbVolRatio1Call.Text = If(data.VolatilityRatio1CallEnabled, data.VolatilityRatio1Call.ToString("######0.########"), "")
        Me.tbAskBidSpreadMinCall.Text = If(data.AskBidSpreadMinCallEnabled, (data.AskBidSpreadMinCall).ToString("######0.########"), "")
        Me.tbAskPriceMaxCall.Text = If(data.AskPriceMaxCallEnabled, data.AskPriceMaxCall.ToString("######0.########"), "")
        Me.tbAskPriceMinCall.Text = If(data.AskPriceMinCallEnabled, data.AskPriceMinCall.ToString("######0.########"), "")
        Me.tbBidPriceMaxCall.Text = If(data.BidPriceMaxCallEnabled, data.BidPriceMaxCall.ToString("######0.########"), "")
        Me.tbBidPriceMinCall.Text = If(data.BidPriceMinCallEnabled, data.BidPriceMinCall.ToString("######0.########"), "")
        Me.cbExercStatus.SelectedValue = data.ExercStatus
        Me.tbExercRateSeq.Text = data.ExercRateSeq
        Me.dtpExercRateTime.Value = IIf(data.ExercRateTimeEnabled, data.ExercRateTime, DateTime.Now)
        Me.tbExercRate.Text = data.ExercRate.ToString("######0.########")
        Me.cbExercResultCall.SelectedValue = data.ExercResultCall
        Me.cbExercResultPut.SelectedValue = data.ExercResultPut
    End Sub

    Private Function getDataFromControl() As ProductSubData
        Dim ret As New ProductSubData

        ret.ProductSubCode = Me.lblProductSubCode.Text
        ret.ProductEnabled = Me.cbEnabled.SelectedValue
        ret.ProductCode = Me.lblProductCode.Text
        ret.ProductSubStatus = Me.cbProductSubStatus.SelectedValue
        ret.ExercPriceSetting = Me.tbExercPriceSetting.Text
        ret.ExercPrice = Me.tbExercPrice.Text

        If Me.tbVolRatio1Call.Text.Length > 0 Then
            ret.VolatilityRatio1Call = Decimal.Parse(Me.tbVolRatio1Call.Text)
        End If

        If Me.tbAskBidSpreadMinCall.Text.Length > 0 Then
            ret.AskBidSpreadMinCall = Decimal.Parse(Me.tbAskBidSpreadMinCall.Text)
        End If
        If Me.tbAskPriceMaxCall.Text.Length > 0 Then
            ret.AskPriceMaxCall = Decimal.Parse(Me.tbAskPriceMaxCall.Text)
        End If
        If Me.tbAskPriceMinCall.Text.Length > 0 Then
            ret.AskPriceMinCall = Decimal.Parse(Me.tbAskPriceMinCall.Text)
        End If
        If Me.tbBidPriceMaxCall.Text.Length > 0 Then
            ret.BidPriceMaxCall = Decimal.Parse(Me.tbBidPriceMaxCall.Text)
        End If
        If Me.tbBidPriceMinCall.Text.Length > 0 Then
            ret.BidPriceMinCall = Decimal.Parse(Me.tbBidPriceMinCall.Text)
        End If

        ret.ExercStatus = Me.cbExercStatus.SelectedValue
        If Me.tbExercRateSeq.Text.Length > 0 Then
            ret.ExercRateSeqEnabled = True
            ret.ExercRateSeq = Me.tbExercRateSeq.Text
        End If
        If Me.dtpExercRateTime.Text.Length > 0 Then
            ret.ExercRateTimeEnabled = True
            ret.ExercRateTime = Me.dtpExercRateTime.Value
        End If
        If Me.tbExercRate.Text.Length > 0 Then
            ret.ExercRateEnabled = True
            ret.ExercRate = Me.tbExercRate.Text
        End If

        ret.ExercResultCall = Me.cbExercResultCall.SelectedValue
        ret.ExercResultPut = Me.cbExercResultPut.SelectedValue

        Select Case FormModeStatus
            Case FormMode.REGIST, FormMode.REGISTCONF, FormMode.REGISTRUN
                ret.ProductEnabled = cbEnabled.SelectedValue
        End Select

        Return ret
    End Function

    Private Function checkInput() As Boolean
        If cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbExercPriceSetting Is Nothing OrElse Me.tbExercPriceSetting.Text.Length = 0 OrElse Not CheckUtil.RegExSignRate3.IsMatch(Me.tbExercPriceSetting.Text) Then
            MessageBox.Show(Me, "行使価格設定には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(Me.tbExercPrice.Text) Then
            MessageBox.Show(Me, "行使価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim exercPrice As Decimal
        If Not Decimal.TryParse(Me.tbExercPrice.Text, exercPrice) Then
            MessageBox.Show(Me, "行使価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.cbProductSubStatus.SelectedValue = "" Then
            MessageBox.Show("ステータスフラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExSignRate.IsMatch(Me.tbVolRatio1Call.Text) Then
            MessageBox.Show("ボラティリティレシオ１には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim volatilityRatio1Call As Decimal
        If Not Decimal.TryParse(Me.tbVolRatio1Call.Text, volatilityRatio1Call) Then
            MessageBox.Show("ボラティリティレシオ１には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(Me.tbAskBidSpreadMinCall.Text) Then
            MessageBox.Show("購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim AskBidSpreadMinCall As Decimal
        If Not Decimal.TryParse(Me.tbAskBidSpreadMinCall.Text, AskBidSpreadMinCall) Then
            MessageBox.Show("購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(Me.tbAskPriceMaxCall.Text) Then
            MessageBox.Show("最高購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim askPriceMaxCall As Decimal
        If Not Decimal.TryParse(Me.tbAskPriceMaxCall.Text, askPriceMaxCall) Then
            MessageBox.Show("最高購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(Me.tbAskPriceMinCall.Text) Then
            MessageBox.Show("最低購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim askPriceMinCall As Decimal
        If Not Decimal.TryParse(Me.tbAskPriceMinCall.Text, askPriceMinCall) Then
            MessageBox.Show("最低購入価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(Me.tbBidPriceMaxCall.Text) Then
            MessageBox.Show("最高清算価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim bidPriceMaxCall As Decimal
        If Not Decimal.TryParse(Me.tbBidPriceMaxCall.Text, bidPriceMaxCall) Then
            MessageBox.Show("最高清算価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(Me.tbBidPriceMinCall.Text) Then
            MessageBox.Show("最低清算価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim bidPriceMinCall As Decimal
        If Not Decimal.TryParse(Me.tbBidPriceMinCall.Text, bidPriceMinCall) Then
            MessageBox.Show("最低清算価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Dim ExercStatus As String = Me.cbExercStatus.SelectedValue
        If (ExercStatus Is Nothing) OrElse (ExercStatus.Length.Equals(0)) Then
            MessageBox.Show("行使フラグが未入力です。" & vbCrLf & "入力値を確認して下さい。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExRate.IsMatch(tbExercRate.Text) Then
            MessageBox.Show(Me, "行使時価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
        If Not CheckUtil.GetRegRateDecimalPlaces(com.DecimalPlaces).IsMatch(tbExercRate.Text) Then
            MessageBox.Show(Me, String.Format("行使時価格は小数{0}桁以内で入力してください。", com.DecimalPlaces), My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim exercRate As Decimal
        If Not Decimal.TryParse(tbExercRate.Text, exercRate) Then
            MessageBox.Show(Me, "行使時価格には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Dim ExercResultCall As String = Me.cbExercResultCall.SelectedValue
        If ExercResultCall Is Nothing OrElse ExercResultCall.Length.Equals(0) Then
            MessageBox.Show("行使結果(Call)が未入力です。" & vbCrLf & "入力値を確認して下さい。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Dim ExercResultPut As String = Me.cbExercResultPut.SelectedValue
        If ExercResultPut Is Nothing OrElse ExercResultPut.Length.Equals(0) Then
            MessageBox.Show("行使結果(Put)が未入力です。" & vbCrLf & "入力値を確認して下さい。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As ProductSubData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As ProductSubData = getDataFromControl()

        service.Update(data)
    End Sub

    Private Sub btnEnabled_Click(sender As System.Object, e As System.EventArgs) Handles btnEnabled.Click
        Dim dlg As New ProductSubEnabled With {.Code = Code}
        dlg.ShowDialog(Me)
        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub btnDisabled_Click(sender As System.Object, e As System.EventArgs) Handles btnDisabled.Click
        Dim dlg As New ProductSubDisabled With {.Code = Code}
        dlg.ShowDialog(Me)
        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub cbExercStatus_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbExercStatus.SelectedIndexChanged
        setFormMode(FormModeStatus)
    End Sub

    Private Function isExerc() As Boolean
        If cbExercStatus.SelectedValue = "2" Then
            Return True
        End If
        Return False
    End Function

    Private Sub tbBidPriceMaxCall_TextChanged(sender As Object, e As EventArgs) Handles tbBidPriceMaxCall.TextChanged

        If tbBidPriceMaxCall.Text <> "" Then
            Dim bidPriceMin As Integer = MAX_PRICE - tbBidPriceMaxCall.Text
            tbBidPriceMinCall.Text = bidPriceMin
        End If

    End Sub

End Class