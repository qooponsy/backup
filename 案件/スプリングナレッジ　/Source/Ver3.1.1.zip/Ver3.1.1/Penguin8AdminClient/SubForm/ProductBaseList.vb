﻿Public Class ProductBaseList

    Private WithEvents service As New ProductBaseService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As New DataTable
    Private view As New DataView

    Private Sub ProductBaseList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        btnRegist.Enabled = editable
        miEdit.Text = IIf(editable, "編集", "参照")

        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Me.cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        Me.cbComCode.SelectedValue = ""

        MainWindow.SubFormProductBase = True
        grid.AutoGenerateColumns = False
        LoadSettings()

        request()
    End Sub

    Private Sub ProductBaseList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormProductBase = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        clsUtil.LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductBaseList_Columns)
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.ProductBaseList_ComCode
        chkEnabled.Checked = UserSettings.getInstance().DataSaved.ProductBaseList_Enabled
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        clsUtil.SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductBaseList_Columns)
        UserSettings.getInstance().DataSaved.ProductBaseList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.ProductBaseList_Enabled = chkEnabled.Checked
    End Sub

    Private Sub setGrid(ProductBaseDataList As List(Of ProductBaseData))
        Table = New DataTable

        Table.Columns.Add("ProductBaseCode", GetType(String))
        Table.Columns.Add("ProductBaseEnabledCode", GetType(String))
        Table.Columns.Add("ProductBaseEnabled", GetType(String))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("OpType", GetType(String))
        Table.Columns.Add("OptionTime", GetType(Integer))
        Table.Columns.Add("CreateTime", GetType(Integer))
        Table.Columns.Add("StartTime", GetType(String))
        Table.Columns.Add("ExercTime", GetType(String))
        If Not ProductBaseDataList Is Nothing Then
            For i As Integer = 0 To ProductBaseDataList.Count - 1
                Dim row As DataRow = Table.NewRow()
                row("ProductBaseCode") = ProductBaseDataList(i).ProductBaseCode
                row("ProductBaseEnabledCode") = ProductBaseDataList(i).ProductBaseEnabled
                row("ProductBaseEnabled") = ProductBaseDataList(i).EnabledName()
                row("ComCode") = CurrencyPairService.GetData(ProductBaseDataList(i).ComCode).ComCode
                row("ComName") = CurrencyPairService.GetData(ProductBaseDataList(i).ComCode).ComName
                row("OpType") = ProductBaseData.cnvOpType(ProductBaseDataList(i).OpType)
                row("OptionTime") = ProductBaseDataList(i).OptionTime
                row("CreateTime") = ProductBaseDataList(i).CreateTime
                row("StartTime") = String.Format("{0:00}:{1:00}", ProductBaseDataList(i).StartTime.Hours, ProductBaseDataList(i).StartTime.Minutes)
                row("ExercTime") = String.Format("{0:00}:{1:00}", ProductBaseDataList(i).ExercTime.Hours, ProductBaseDataList(i).ExercTime.Minutes)
                Table.Rows.Add(row)
            Next
        End If

        view = New DataView(Table)
        grid.DataSource = view
        setGridFilter()
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        setGridFilter()
    End Sub

    Private Sub chkEnabled_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkEnabled.CheckedChanged
        setGridFilter()
    End Sub

    Private Sub btnReflesh_Click(sender As System.Object, e As System.EventArgs) Handles btnReflesh.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                request()
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("ProductBaseCode").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductBaseCode").Value
        edit(code)
    End Sub

    Private Sub request()
        service.ReadList()
        formModeStatus = FormMode.READ
        btnReflesh.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnReflesh.Text = "更新"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of ProductBaseData)) Handles service.ReadSuccess
        setGrid(list)
        requestEnd()
    End Sub

    Private Sub setGridFilter()
        Dim strFilter As String = ""
        '通貨ペア
        If cbComCode.SelectedValue <> "" Then
            strFilter = "ComCode = '" & cbComCode.SelectedValue & "'"
        End If
        '有効フラグ
        If chkEnabled.Checked Then
            If strFilter <> "" Then
                strFilter = strFilter & " AND "
            End If
            strFilter = strFilter & "ProductBaseEnabledCode = '" & ProductBaseData.EnabledCode.Enabled & "'"
        End If
        view.RowFilter = strFilter
        grid.DataSource = view
        lblNoData.Visible = (grid.RowCount = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = MainWindow
        ProductBaseForm.Code = ""
        ProductBaseForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = MainWindow
        ProductBaseForm.Code = code
        ProductBaseForm.Show()
    End Sub

End Class