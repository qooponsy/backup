﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductSubList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.lblProductDeatails = New System.Windows.Forms.Label()
        Me.lblProductCode = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.ProductSubCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductEnabledCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPriceSetting = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductSubStatusCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductSubStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Premium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.cmGrid.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(246, 167)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(211, 63)
        Me.lblNoData.TabIndex = 16
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnUpdate)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.lblProductDeatails)
        Me.Panel1.Controls.Add(Me.lblProductCode)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(388, 76)
        Me.Panel1.TabIndex = 13
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(278, 7)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 18
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'lblProductDeatails
        '
        Me.lblProductDeatails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblProductDeatails.Location = New System.Drawing.Point(14, 33)
        Me.lblProductDeatails.Name = "lblProductDeatails"
        Me.lblProductDeatails.Size = New System.Drawing.Size(241, 23)
        Me.lblProductDeatails.TabIndex = 14
        Me.lblProductDeatails.Text = "USD/JPY ラダー CALL 11:00 "
        Me.lblProductDeatails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblProductCode
        '
        Me.lblProductCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblProductCode.Location = New System.Drawing.Point(74, 7)
        Me.lblProductCode.Name = "lblProductCode"
        Me.lblProductCode.Size = New System.Drawing.Size(109, 23)
        Me.lblProductCode.TabIndex = 13
        Me.lblProductCode.Text = "2013071900000001"
        Me.lblProductCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 12)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "銘柄コード"
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ProductSubCode, Me.ProductEnabledCode, Me.ProductEnabled, Me.ExercPriceSetting, Me.ExercRate, Me.ProductSubStatusCode, Me.ProductSubStatus, Me.Premium, Me.PAndL})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 76)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(388, 256)
        Me.grid.TabIndex = 17
        '
        'ProductSubCode
        '
        Me.ProductSubCode.DataPropertyName = "ProductSubCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductSubCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.ProductSubCode.HeaderText = "銘柄詳細コード"
        Me.ProductSubCode.Name = "ProductSubCode"
        Me.ProductSubCode.ReadOnly = True
        Me.ProductSubCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ProductSubCode.Width = 108
        '
        'ProductEnabledCode
        '
        Me.ProductEnabledCode.DataPropertyName = "ProductEnabledCode"
        Me.ProductEnabledCode.HeaderText = "有効フラグ(Code)"
        Me.ProductEnabledCode.Name = "ProductEnabledCode"
        Me.ProductEnabledCode.ReadOnly = True
        Me.ProductEnabledCode.Visible = False
        '
        'ProductEnabled
        '
        Me.ProductEnabled.DataPropertyName = "ProductEnabled"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductEnabled.DefaultCellStyle = DataGridViewCellStyle3
        Me.ProductEnabled.HeaderText = "有効フラグ"
        Me.ProductEnabled.Name = "ProductEnabled"
        Me.ProductEnabled.ReadOnly = True
        Me.ProductEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ProductEnabled.Width = 46
        '
        'ExercPriceSetting
        '
        Me.ExercPriceSetting.DataPropertyName = "ExercPriceSetting"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercPriceSetting.DefaultCellStyle = DataGridViewCellStyle4
        Me.ExercPriceSetting.HeaderText = "行使価格設定"
        Me.ExercPriceSetting.Name = "ExercPriceSetting"
        Me.ExercPriceSetting.ReadOnly = True
        Me.ExercPriceSetting.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ExercPriceSetting.Width = 60
        '
        'ExercRate
        '
        Me.ExercRate.DataPropertyName = "ExercRate"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.Format = "######0.000#####"
        DataGridViewCellStyle5.NullValue = Nothing
        Me.ExercRate.DefaultCellStyle = DataGridViewCellStyle5
        Me.ExercRate.HeaderText = "行使価格"
        Me.ExercRate.Name = "ExercRate"
        Me.ExercRate.ReadOnly = True
        Me.ExercRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ExercRate.Width = 60
        '
        'ProductSubStatusCode
        '
        Me.ProductSubStatusCode.DataPropertyName = "ProductSubStatusCode"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductSubStatusCode.DefaultCellStyle = DataGridViewCellStyle6
        Me.ProductSubStatusCode.HeaderText = "ステータス(Code)"
        Me.ProductSubStatusCode.Name = "ProductSubStatusCode"
        Me.ProductSubStatusCode.ReadOnly = True
        Me.ProductSubStatusCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ProductSubStatusCode.Visible = False
        '
        'ProductSubStatus
        '
        Me.ProductSubStatus.DataPropertyName = "ProductSubStatus"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductSubStatus.DefaultCellStyle = DataGridViewCellStyle7
        Me.ProductSubStatus.HeaderText = "ステータス"
        Me.ProductSubStatus.Name = "ProductSubStatus"
        Me.ProductSubStatus.ReadOnly = True
        Me.ProductSubStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ProductSubStatus.Width = 110
        '
        'Premium
        '
        Me.Premium.DataPropertyName = "Premium"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "###,###,###,###,##0"
        Me.Premium.DefaultCellStyle = DataGridViewCellStyle8
        Me.Premium.HeaderText = "取引金額"
        Me.Premium.Name = "Premium"
        Me.Premium.ReadOnly = True
        Me.Premium.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Premium.Visible = False
        '
        'PAndL
        '
        Me.PAndL.DataPropertyName = "PAndL"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "###,###,###,###,##0"
        DataGridViewCellStyle9.NullValue = Nothing
        Me.PAndL.DefaultCellStyle = DataGridViewCellStyle9
        Me.PAndL.HeaderText = "損益"
        Me.PAndL.Name = "PAndL"
        Me.PAndL.ReadOnly = True
        Me.PAndL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PAndL.Visible = False
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(278, 42)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(89, 28)
        Me.btnUpdate.TabIndex = 19
        Me.btnUpdate.Text = "更新"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'ProductSubList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(388, 332)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "ProductSubList"
        Me.Text = "銘柄詳細一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.cmGrid.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents lblProductDeatails As System.Windows.Forms.Label
    Friend WithEvents lblProductCode As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents ProductSubCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductEnabledCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercPriceSetting As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductSubStatusCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProductSubStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Premium As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PAndL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
End Class
