﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CalcParamSettingsForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblComName = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblVolatilityAdjust = New System.Windows.Forms.Label()
        Me.lblInterestRate = New System.Windows.Forms.Label()
        Me.lblSwapRate = New System.Windows.Forms.Label()
        Me.lblVolatility = New System.Windows.Forms.Label()
        Me.tbVolatilityAdjust = New System.Windows.Forms.TextBox()
        Me.tbInterestRate = New System.Windows.Forms.TextBox()
        Me.tbSwapRate = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblComName
        '
        Me.lblComName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblComName.Location = New System.Drawing.Point(173, 16)
        Me.lblComName.Name = "lblComName"
        Me.lblComName.Size = New System.Drawing.Size(125, 19)
        Me.lblComName.TabIndex = 1
        Me.lblComName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "通貨ペア"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(262, 233)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 18
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(134, 233)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 17
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(206, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "現在適用値"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(335, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(123, 12)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "翌営業日以降の適用値"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 125)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 12)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "ボラティリティレシオ(%)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 75)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 12)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "短期金利(%)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(29, 100)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "スワップ金利(%)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(29, 150)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 12)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "ボラティリティ"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Red
        Me.Label8.Location = New System.Drawing.Point(58, 200)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 12)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "＜注意＞"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Red
        Me.Label9.Location = New System.Drawing.Point(129, 200)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(307, 12)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "本変更は即時反映はされず、翌営業日の計算に適用されます。"
        '
        'lblVolatilityAdjust
        '
        Me.lblVolatilityAdjust.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblVolatilityAdjust.Location = New System.Drawing.Point(173, 125)
        Me.lblVolatilityAdjust.Name = "lblVolatilityAdjust"
        Me.lblVolatilityAdjust.Size = New System.Drawing.Size(125, 19)
        Me.lblVolatilityAdjust.TabIndex = 11
        Me.lblVolatilityAdjust.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblInterestRate
        '
        Me.lblInterestRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblInterestRate.Location = New System.Drawing.Point(173, 75)
        Me.lblInterestRate.Name = "lblInterestRate"
        Me.lblInterestRate.Size = New System.Drawing.Size(125, 19)
        Me.lblInterestRate.TabIndex = 5
        Me.lblInterestRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSwapRate
        '
        Me.lblSwapRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSwapRate.Location = New System.Drawing.Point(173, 100)
        Me.lblSwapRate.Name = "lblSwapRate"
        Me.lblSwapRate.Size = New System.Drawing.Size(125, 19)
        Me.lblSwapRate.TabIndex = 8
        Me.lblSwapRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblVolatility
        '
        Me.lblVolatility.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblVolatility.Location = New System.Drawing.Point(173, 150)
        Me.lblVolatility.Name = "lblVolatility"
        Me.lblVolatility.Size = New System.Drawing.Size(125, 19)
        Me.lblVolatility.TabIndex = 14
        Me.lblVolatility.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbVolatilityAdjust
        '
        Me.tbVolatilityAdjust.Location = New System.Drawing.Point(333, 125)
        Me.tbVolatilityAdjust.Name = "tbVolatilityAdjust"
        Me.tbVolatilityAdjust.Size = New System.Drawing.Size(125, 19)
        Me.tbVolatilityAdjust.TabIndex = 12
        Me.tbVolatilityAdjust.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbInterestRate
        '
        Me.tbInterestRate.Location = New System.Drawing.Point(333, 75)
        Me.tbInterestRate.Name = "tbInterestRate"
        Me.tbInterestRate.Size = New System.Drawing.Size(125, 19)
        Me.tbInterestRate.TabIndex = 6
        Me.tbInterestRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbSwapRate
        '
        Me.tbSwapRate.Location = New System.Drawing.Point(333, 100)
        Me.tbSwapRate.Name = "tbSwapRate"
        Me.tbSwapRate.Size = New System.Drawing.Size(125, 19)
        Me.tbSwapRate.TabIndex = 9
        Me.tbSwapRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CalcParamSettingsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(494, 282)
        Me.Controls.Add(Me.tbSwapRate)
        Me.Controls.Add(Me.tbInterestRate)
        Me.Controls.Add(Me.tbVolatilityAdjust)
        Me.Controls.Add(Me.lblVolatility)
        Me.Controls.Add(Me.lblSwapRate)
        Me.Controls.Add(Me.lblInterestRate)
        Me.Controls.Add(Me.lblVolatilityAdjust)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.lblComName)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "CalcParamSettingsForm"
        Me.Text = "プレミアムパラメータ変更"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblComName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblVolatilityAdjust As System.Windows.Forms.Label
    Friend WithEvents lblInterestRate As System.Windows.Forms.Label
    Friend WithEvents lblSwapRate As System.Windows.Forms.Label
    Friend WithEvents lblVolatility As System.Windows.Forms.Label
    Friend WithEvents tbVolatilityAdjust As System.Windows.Forms.TextBox
    Friend WithEvents tbInterestRate As System.Windows.Forms.TextBox
    Friend WithEvents tbSwapRate As System.Windows.Forms.TextBox
End Class
