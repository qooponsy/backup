﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PriceChartForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.dtpCloseTime = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbCloseTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.lblRateCode = New System.Windows.Forms.Label()
        Me.tbCloseAskPriceCall = New System.Windows.Forms.TextBox()
        Me.tbLowAskPriceCall = New System.Windows.Forms.TextBox()
        Me.tbHighAskPriceCall = New System.Windows.Forms.TextBox()
        Me.tbOpenAskPriceCall = New System.Windows.Forms.TextBox()
        Me.dtpChartTime = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbChartTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.cbChartType = New System.Windows.Forms.ComboBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.lblPriceChartCode = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.tbProductCode = New System.Windows.Forms.TextBox()
        Me.tbProductSubCode = New System.Windows.Forms.TextBox()
        Me.tbCloseBidPriceCall = New System.Windows.Forms.TextBox()
        Me.tbLowBidPriceCall = New System.Windows.Forms.TextBox()
        Me.tbHighBidPriceCall = New System.Windows.Forms.TextBox()
        Me.tbOpenBidPriceCall = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.tbCloseAskPricePut = New System.Windows.Forms.TextBox()
        Me.tbLowAskPricePut = New System.Windows.Forms.TextBox()
        Me.tbHighAskPricePut = New System.Windows.Forms.TextBox()
        Me.tbOpenAskPricePut = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.tbCloseBidPricePut = New System.Windows.Forms.TextBox()
        Me.tbLowBidPricePut = New System.Windows.Forms.TextBox()
        Me.tbHighBidPricePut = New System.Windows.Forms.TextBox()
        Me.tbOpenBidPricePut = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(288, 392)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 71
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(160, 392)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 70
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'dtpCloseTime
        '
        Me.dtpCloseTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpCloseTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpCloseTime.Location = New System.Drawing.Point(362, 146)
        Me.dtpCloseTime.Name = "dtpCloseTime"
        Me.dtpCloseTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpCloseTime.TabIndex = 52
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(491, 174)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 12)
        Me.Label14.TabIndex = 54
        Me.Label14.Text = "ミリ秒"
        '
        'tbCloseTimeMilliseconds
        '
        Me.tbCloseTimeMilliseconds.Location = New System.Drawing.Point(452, 171)
        Me.tbCloseTimeMilliseconds.Name = "tbCloseTimeMilliseconds"
        Me.tbCloseTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbCloseTimeMilliseconds.TabIndex = 53
        Me.tbCloseTimeMilliseconds.Text = "999"
        Me.tbCloseTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblRateCode
        '
        Me.lblRateCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRateCode.Location = New System.Drawing.Point(362, 107)
        Me.lblRateCode.Name = "lblRateCode"
        Me.lblRateCode.Size = New System.Drawing.Size(160, 23)
        Me.lblRateCode.TabIndex = 51
        Me.lblRateCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbCloseAskPriceCall
        '
        Me.tbCloseAskPriceCall.Location = New System.Drawing.Point(62, 356)
        Me.tbCloseAskPriceCall.Name = "tbCloseAskPriceCall"
        Me.tbCloseAskPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbCloseAskPriceCall.TabIndex = 57
        Me.tbCloseAskPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbLowAskPriceCall
        '
        Me.tbLowAskPriceCall.Location = New System.Drawing.Point(62, 326)
        Me.tbLowAskPriceCall.Name = "tbLowAskPriceCall"
        Me.tbLowAskPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbLowAskPriceCall.TabIndex = 56
        Me.tbLowAskPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHighAskPriceCall
        '
        Me.tbHighAskPriceCall.Location = New System.Drawing.Point(62, 296)
        Me.tbHighAskPriceCall.Name = "tbHighAskPriceCall"
        Me.tbHighAskPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbHighAskPriceCall.TabIndex = 55
        Me.tbHighAskPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbOpenAskPriceCall
        '
        Me.tbOpenAskPriceCall.Location = New System.Drawing.Point(62, 266)
        Me.tbOpenAskPriceCall.Name = "tbOpenAskPriceCall"
        Me.tbOpenAskPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbOpenAskPriceCall.TabIndex = 54
        Me.tbOpenAskPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpChartTime
        '
        Me.dtpChartTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpChartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpChartTime.Location = New System.Drawing.Point(98, 184)
        Me.dtpChartTime.Name = "dtpChartTime"
        Me.dtpChartTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpChartTime.TabIndex = 44
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(227, 212)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 12)
        Me.Label12.TabIndex = 46
        Me.Label12.Text = "ミリ秒"
        '
        'tbChartTimeMilliseconds
        '
        Me.tbChartTimeMilliseconds.Location = New System.Drawing.Point(188, 209)
        Me.tbChartTimeMilliseconds.Name = "tbChartTimeMilliseconds"
        Me.tbChartTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbChartTimeMilliseconds.TabIndex = 45
        Me.tbChartTimeMilliseconds.Text = "999"
        Me.tbChartTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbChartType
        '
        Me.cbChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbChartType.FormattingEnabled = True
        Me.cbChartType.Location = New System.Drawing.Point(98, 147)
        Me.cbChartType.Name = "cbChartType"
        Me.cbChartType.Size = New System.Drawing.Size(160, 20)
        Me.cbChartType.TabIndex = 43
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(98, 108)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(160, 20)
        Me.cbComCode.TabIndex = 42
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(98, 69)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(160, 20)
        Me.cbEnabled.TabIndex = 41
        '
        'lblPriceChartCode
        '
        Me.lblPriceChartCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPriceChartCode.Location = New System.Drawing.Point(98, 28)
        Me.lblPriceChartCode.Name = "lblPriceChartCode"
        Me.lblPriceChartCode.Size = New System.Drawing.Size(160, 23)
        Me.lblPriceChartCode.TabIndex = 40
        Me.lblPriceChartCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(288, 151)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 12)
        Me.Label11.TabIndex = 39
        Me.Label11.Text = "レート日時"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(288, 112)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 12)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "レートSeq"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 360)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 12)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "終了"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 330)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 12)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "最低"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 300)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(29, 12)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "最高"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 270)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 12)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "開始"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 189)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 12)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "チャート日時"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 12)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "チャート種別"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 12)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "通貨ペア"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 12)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "有効フラグ"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 12)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "チャートSeq"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(289, 33)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(56, 12)
        Me.Label13.TabIndex = 58
        Me.Label13.Text = "銘柄コード"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(288, 68)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(75, 12)
        Me.Label15.TabIndex = 59
        Me.Label15.Text = "銘柄サブコード"
        '
        'tbProductCode
        '
        Me.tbProductCode.Location = New System.Drawing.Point(363, 30)
        Me.tbProductCode.MaxLength = 17
        Me.tbProductCode.Name = "tbProductCode"
        Me.tbProductCode.Size = New System.Drawing.Size(160, 19)
        Me.tbProductCode.TabIndex = 38
        Me.tbProductCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbProductSubCode
        '
        Me.tbProductSubCode.Location = New System.Drawing.Point(362, 67)
        Me.tbProductSubCode.MaxLength = 17
        Me.tbProductSubCode.Name = "tbProductSubCode"
        Me.tbProductSubCode.Size = New System.Drawing.Size(160, 19)
        Me.tbProductSubCode.TabIndex = 39
        Me.tbProductSubCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCloseBidPriceCall
        '
        Me.tbCloseBidPriceCall.Location = New System.Drawing.Point(185, 356)
        Me.tbCloseBidPriceCall.Name = "tbCloseBidPriceCall"
        Me.tbCloseBidPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbCloseBidPriceCall.TabIndex = 61
        Me.tbCloseBidPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbLowBidPriceCall
        '
        Me.tbLowBidPriceCall.Location = New System.Drawing.Point(185, 326)
        Me.tbLowBidPriceCall.Name = "tbLowBidPriceCall"
        Me.tbLowBidPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbLowBidPriceCall.TabIndex = 60
        Me.tbLowBidPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHighBidPriceCall
        '
        Me.tbHighBidPriceCall.Location = New System.Drawing.Point(185, 296)
        Me.tbHighBidPriceCall.Name = "tbHighBidPriceCall"
        Me.tbHighBidPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbHighBidPriceCall.TabIndex = 59
        Me.tbHighBidPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbOpenBidPriceCall
        '
        Me.tbOpenBidPriceCall.Location = New System.Drawing.Point(185, 266)
        Me.tbOpenBidPriceCall.Name = "tbOpenBidPriceCall"
        Me.tbOpenBidPriceCall.Size = New System.Drawing.Size(74, 19)
        Me.tbOpenBidPriceCall.TabIndex = 58
        Me.tbOpenBidPriceCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(150, 360)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(29, 12)
        Me.Label16.TabIndex = 66
        Me.Label16.Text = "終了"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(150, 330)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(29, 12)
        Me.Label17.TabIndex = 65
        Me.Label17.Text = "最低"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(150, 300)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(29, 12)
        Me.Label18.TabIndex = 64
        Me.Label18.Text = "最高"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(150, 270)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 12)
        Me.Label19.TabIndex = 63
        Me.Label19.Text = "開始"
        '
        'tbCloseAskPricePut
        '
        Me.tbCloseAskPricePut.Location = New System.Drawing.Point(328, 356)
        Me.tbCloseAskPricePut.Name = "tbCloseAskPricePut"
        Me.tbCloseAskPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbCloseAskPricePut.TabIndex = 65
        Me.tbCloseAskPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbLowAskPricePut
        '
        Me.tbLowAskPricePut.Location = New System.Drawing.Point(328, 326)
        Me.tbLowAskPricePut.Name = "tbLowAskPricePut"
        Me.tbLowAskPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbLowAskPricePut.TabIndex = 64
        Me.tbLowAskPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHighAskPricePut
        '
        Me.tbHighAskPricePut.Location = New System.Drawing.Point(328, 296)
        Me.tbHighAskPricePut.Name = "tbHighAskPricePut"
        Me.tbHighAskPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbHighAskPricePut.TabIndex = 63
        Me.tbHighAskPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbOpenAskPricePut
        '
        Me.tbOpenAskPricePut.Location = New System.Drawing.Point(328, 266)
        Me.tbOpenAskPricePut.Name = "tbOpenAskPricePut"
        Me.tbOpenAskPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbOpenAskPricePut.TabIndex = 62
        Me.tbOpenAskPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(288, 360)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(29, 12)
        Me.Label20.TabIndex = 74
        Me.Label20.Text = "終了"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(288, 330)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(29, 12)
        Me.Label21.TabIndex = 73
        Me.Label21.Text = "最低"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(288, 300)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(29, 12)
        Me.Label22.TabIndex = 72
        Me.Label22.Text = "最高"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(288, 270)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(29, 12)
        Me.Label23.TabIndex = 71
        Me.Label23.Text = "開始"
        '
        'tbCloseBidPricePut
        '
        Me.tbCloseBidPricePut.Location = New System.Drawing.Point(452, 356)
        Me.tbCloseBidPricePut.Name = "tbCloseBidPricePut"
        Me.tbCloseBidPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbCloseBidPricePut.TabIndex = 69
        Me.tbCloseBidPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbLowBidPricePut
        '
        Me.tbLowBidPricePut.Location = New System.Drawing.Point(452, 326)
        Me.tbLowBidPricePut.Name = "tbLowBidPricePut"
        Me.tbLowBidPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbLowBidPricePut.TabIndex = 68
        Me.tbLowBidPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHighBidPricePut
        '
        Me.tbHighBidPricePut.Location = New System.Drawing.Point(452, 296)
        Me.tbHighBidPricePut.Name = "tbHighBidPricePut"
        Me.tbHighBidPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbHighBidPricePut.TabIndex = 67
        Me.tbHighBidPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbOpenBidPricePut
        '
        Me.tbOpenBidPricePut.Location = New System.Drawing.Point(452, 266)
        Me.tbOpenBidPricePut.Name = "tbOpenBidPricePut"
        Me.tbOpenBidPricePut.Size = New System.Drawing.Size(74, 19)
        Me.tbOpenBidPricePut.TabIndex = 66
        Me.tbOpenBidPricePut.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(414, 360)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(29, 12)
        Me.Label24.TabIndex = 82
        Me.Label24.Text = "終了"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(414, 330)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(29, 12)
        Me.Label25.TabIndex = 81
        Me.Label25.Text = "最低"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(414, 300)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(29, 12)
        Me.Label26.TabIndex = 80
        Me.Label26.Text = "最高"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(414, 270)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(29, 12)
        Me.Label27.TabIndex = 79
        Me.Label27.Text = "開始"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(56, 244)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(81, 12)
        Me.Label28.TabIndex = 83
        Me.Label28.Text = "購入価格(Call)"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(176, 244)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(81, 12)
        Me.Label29.TabIndex = 84
        Me.Label29.Text = "清算価格(Call)"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(444, 244)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(78, 12)
        Me.Label30.TabIndex = 86
        Me.Label30.Text = "清算価格(Put)"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(320, 244)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(78, 12)
        Me.Label31.TabIndex = 85
        Me.Label31.Text = "購入価格(Put)"
        '
        'PriceChartForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(552, 445)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.tbCloseBidPricePut)
        Me.Controls.Add(Me.tbLowBidPricePut)
        Me.Controls.Add(Me.tbHighBidPricePut)
        Me.Controls.Add(Me.tbOpenBidPricePut)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.tbCloseAskPricePut)
        Me.Controls.Add(Me.tbLowAskPricePut)
        Me.Controls.Add(Me.tbHighAskPricePut)
        Me.Controls.Add(Me.tbOpenAskPricePut)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.tbCloseBidPriceCall)
        Me.Controls.Add(Me.tbLowBidPriceCall)
        Me.Controls.Add(Me.tbHighBidPriceCall)
        Me.Controls.Add(Me.tbOpenBidPriceCall)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.tbProductSubCode)
        Me.Controls.Add(Me.tbProductCode)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.dtpCloseTime)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.tbCloseTimeMilliseconds)
        Me.Controls.Add(Me.lblRateCode)
        Me.Controls.Add(Me.tbCloseAskPriceCall)
        Me.Controls.Add(Me.tbLowAskPriceCall)
        Me.Controls.Add(Me.tbHighAskPriceCall)
        Me.Controls.Add(Me.tbOpenAskPriceCall)
        Me.Controls.Add(Me.dtpChartTime)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.tbChartTimeMilliseconds)
        Me.Controls.Add(Me.cbChartType)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.lblPriceChartCode)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PriceChartForm"
        Me.Text = "時価チャート編集"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents dtpCloseTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tbCloseTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents lblRateCode As System.Windows.Forms.Label
    Friend WithEvents tbCloseAskPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents tbLowAskPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents tbHighAskPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents tbOpenAskPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents dtpChartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbChartTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents cbChartType As System.Windows.Forms.ComboBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents lblPriceChartCode As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents tbProductCode As System.Windows.Forms.TextBox
    Friend WithEvents tbProductSubCode As System.Windows.Forms.TextBox
    Friend WithEvents tbCloseBidPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents tbLowBidPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents tbHighBidPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents tbOpenBidPriceCall As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents tbCloseAskPricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbLowAskPricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbHighAskPricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbOpenAskPricePut As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents tbCloseBidPricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbLowBidPricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbHighBidPricePut As System.Windows.Forms.TextBox
    Friend WithEvents tbOpenBidPricePut As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
End Class
