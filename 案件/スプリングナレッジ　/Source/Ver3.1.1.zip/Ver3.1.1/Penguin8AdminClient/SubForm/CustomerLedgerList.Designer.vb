﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustomerLedgerList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkMovementOfFundsDisp = New System.Windows.Forms.CheckBox()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpSysDateTo = New System.Windows.Forms.DateTimePicker()
        Me.dtpSysDateFrom = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExecTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypeOfTrading = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BuySell = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeStatusName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Lot = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PremiumOrPayout = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Payout = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalMoneyPrev = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Money = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.chkMovementOfFundsDisp)
        Me.Panel1.Controls.Add(Me.tbCustCode)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.dtpSysDateTo)
        Me.Panel1.Controls.Add(Me.dtpSysDateFrom)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.btnPrint)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1094, 41)
        Me.Panel1.TabIndex = 26
        '
        'chkMovementOfFundsDisp
        '
        Me.chkMovementOfFundsDisp.AutoSize = True
        Me.chkMovementOfFundsDisp.Checked = True
        Me.chkMovementOfFundsDisp.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkMovementOfFundsDisp.Location = New System.Drawing.Point(13, 14)
        Me.chkMovementOfFundsDisp.Name = "chkMovementOfFundsDisp"
        Me.chkMovementOfFundsDisp.Size = New System.Drawing.Size(140, 16)
        Me.chkMovementOfFundsDisp.TabIndex = 22
        Me.chkMovementOfFundsDisp.Text = "資金移動がなくても表示"
        Me.chkMovementOfFundsDisp.UseVisualStyleBackColor = True
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(531, 11)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(59, 19)
        Me.tbCustCode.TabIndex = 19
        Me.tbCustCode.Text = "1000050"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(457, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 12)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "委託者コード"
        '
        'dtpSysDateTo
        '
        Me.dtpSysDateTo.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDateTo.Location = New System.Drawing.Point(323, 11)
        Me.dtpSysDateTo.Name = "dtpSysDateTo"
        Me.dtpSysDateTo.ShowCheckBox = True
        Me.dtpSysDateTo.Size = New System.Drawing.Size(117, 19)
        Me.dtpSysDateTo.TabIndex = 18
        '
        'dtpSysDateFrom
        '
        Me.dtpSysDateFrom.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDateFrom.Location = New System.Drawing.Point(177, 11)
        Me.dtpSysDateFrom.Name = "dtpSysDateFrom"
        Me.dtpSysDateFrom.ShowCheckBox = True
        Me.dtpSysDateFrom.Size = New System.Drawing.Size(117, 19)
        Me.dtpSysDateFrom.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(300, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "～"
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(774, 6)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(89, 29)
        Me.btnPrint.TabIndex = 15
        Me.btnPrint.Text = "印刷"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(685, 6)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 14
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(596, 6)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 13
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 17
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 741)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(1094, 32)
        Me.pnlSearchAdd.TabIndex = 27
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(128, 203)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(232, 63)
        Me.lblNoData.TabIndex = 28
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SysDate, Me.CustCode, Me.CustName, Me.ExecTime, Me.TypeOfTrading, Me.ComCode, Me.ComName, Me.ExercTime, Me.ExercPrice, Me.BuySell, Me.TradeType, Me.TradeTypeName, Me.CashTypeName, Me.TradeStatusName, Me.Lot, Me.Price, Me.PayoutPrice, Me.PremiumOrPayout, Me.Payout, Me.TotalMoneyPrev, Me.Money, Me.TotalMoney})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 41)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle24
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(1094, 700)
        Me.grid.TabIndex = 30
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle2
        Me.SysDate.HeaderText = "作成日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 80
        '
        'CustCode
        '
        Me.CustCode.DataPropertyName = "CustCode"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.CustCode.HeaderText = "委託者コード"
        Me.CustCode.Name = "CustCode"
        Me.CustCode.ReadOnly = True
        Me.CustCode.Width = 70
        '
        'CustName
        '
        Me.CustName.DataPropertyName = "CustName"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustName.DefaultCellStyle = DataGridViewCellStyle4
        Me.CustName.HeaderText = "顧客氏名"
        Me.CustName.Name = "CustName"
        Me.CustName.ReadOnly = True
        Me.CustName.Width = 80
        '
        'ExecTime
        '
        Me.ExecTime.DataPropertyName = "ExecTime"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.Format = "yyyy/MM/dd HH:mm:ss"
        Me.ExecTime.DefaultCellStyle = DataGridViewCellStyle5
        Me.ExecTime.HeaderText = "約定・清算・行使・消滅・入出金時間"
        Me.ExecTime.Name = "ExecTime"
        Me.ExecTime.ReadOnly = True
        Me.ExecTime.Width = 130
        '
        'TypeOfTrading
        '
        Me.TypeOfTrading.DataPropertyName = "TypeOfTrading"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.TypeOfTrading.DefaultCellStyle = DataGridViewCellStyle6
        Me.TypeOfTrading.HeaderText = "取引種類"
        Me.TypeOfTrading.Name = "TypeOfTrading"
        Me.TypeOfTrading.ReadOnly = True
        Me.TypeOfTrading.Width = 170
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle7
        Me.ComCode.HeaderText = "通貨ペア(Code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle8
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 80
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle9.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle9
        Me.ExercTime.HeaderText = "行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        '
        'ExercPrice
        '
        Me.ExercPrice.DataPropertyName = "ExercPrice"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "######0.000#####"
        DataGridViewCellStyle10.NullValue = Nothing
        Me.ExercPrice.DefaultCellStyle = DataGridViewCellStyle10
        Me.ExercPrice.HeaderText = "行使価格"
        Me.ExercPrice.Name = "ExercPrice"
        Me.ExercPrice.ReadOnly = True
        Me.ExercPrice.Width = 80
        '
        'BuySell
        '
        Me.BuySell.DataPropertyName = "BuySell"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.BuySell.DefaultCellStyle = DataGridViewCellStyle11
        Me.BuySell.HeaderText = "売付/買付"
        Me.BuySell.Name = "BuySell"
        Me.BuySell.ReadOnly = True
        Me.BuySell.Width = 80
        '
        'TradeType
        '
        Me.TradeType.DataPropertyName = "TradeType"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeType.DefaultCellStyle = DataGridViewCellStyle12
        Me.TradeType.HeaderText = "種別(Code)"
        Me.TradeType.Name = "TradeType"
        Me.TradeType.ReadOnly = True
        Me.TradeType.Visible = False
        '
        'TradeTypeName
        '
        Me.TradeTypeName.DataPropertyName = "TradeTypeName"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeTypeName.DefaultCellStyle = DataGridViewCellStyle13
        Me.TradeTypeName.FillWeight = 80.0!
        Me.TradeTypeName.HeaderText = "種別"
        Me.TradeTypeName.Name = "TradeTypeName"
        Me.TradeTypeName.ReadOnly = True
        Me.TradeTypeName.Width = 60
        '
        'CashTypeName
        '
        Me.CashTypeName.DataPropertyName = "CashTypeName"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CashTypeName.DefaultCellStyle = DataGridViewCellStyle14
        Me.CashTypeName.HeaderText = "新規・清算・行使・消滅"
        Me.CashTypeName.Name = "CashTypeName"
        Me.CashTypeName.ReadOnly = True
        '
        'TradeStatusName
        '
        Me.TradeStatusName.DataPropertyName = "TradeStatusName"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeStatusName.DefaultCellStyle = DataGridViewCellStyle15
        Me.TradeStatusName.HeaderText = "取引ステータス"
        Me.TradeStatusName.Name = "TradeStatusName"
        Me.TradeStatusName.ReadOnly = True
        Me.TradeStatusName.Width = 106
        '
        'Lot
        '
        Me.Lot.DataPropertyName = "Lot"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Lot.DefaultCellStyle = DataGridViewCellStyle16
        Me.Lot.HeaderText = "ロット"
        Me.Lot.Name = "Lot"
        Me.Lot.ReadOnly = True
        Me.Lot.Width = 60
        '
        'Price
        '
        Me.Price.DataPropertyName = "Price"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle17.Format = "#,###,###,##0.####"
        DataGridViewCellStyle17.NullValue = Nothing
        Me.Price.DefaultCellStyle = DataGridViewCellStyle17
        Me.Price.HeaderText = "購入価格"
        Me.Price.Name = "Price"
        Me.Price.ReadOnly = True
        Me.Price.Width = 60
        '
        'PayoutPrice
        '
        Me.PayoutPrice.DataPropertyName = "PayoutPrice"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle18.Format = "#,###,###,##0.####"
        Me.PayoutPrice.DefaultCellStyle = DataGridViewCellStyle18
        Me.PayoutPrice.HeaderText = "清算価格"
        Me.PayoutPrice.Name = "PayoutPrice"
        Me.PayoutPrice.ReadOnly = True
        Me.PayoutPrice.Width = 80
        '
        'PremiumOrPayout
        '
        Me.PremiumOrPayout.DataPropertyName = "PremiumOrPayout"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle19.Format = "#,###,###,##0.####"
        Me.PremiumOrPayout.DefaultCellStyle = DataGridViewCellStyle19
        Me.PremiumOrPayout.HeaderText = "購入・清算金額"
        Me.PremiumOrPayout.Name = "PremiumOrPayout"
        Me.PremiumOrPayout.ReadOnly = True
        Me.PremiumOrPayout.Width = 80
        '
        'Payout
        '
        Me.Payout.DataPropertyName = "Payout"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle20.Format = "#,###,###,##0.####"
        Me.Payout.DefaultCellStyle = DataGridViewCellStyle20
        Me.Payout.HeaderText = "行使・消滅金額"
        Me.Payout.Name = "Payout"
        Me.Payout.ReadOnly = True
        Me.Payout.Width = 80
        '
        'TotalMoneyPrev
        '
        Me.TotalMoneyPrev.DataPropertyName = "TotalMoneyPrev"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle21.Format = "#,###,###,##0.####"
        Me.TotalMoneyPrev.DefaultCellStyle = DataGridViewCellStyle21
        Me.TotalMoneyPrev.HeaderText = "繰越残高"
        Me.TotalMoneyPrev.Name = "TotalMoneyPrev"
        Me.TotalMoneyPrev.ReadOnly = True
        Me.TotalMoneyPrev.Width = 80
        '
        'Money
        '
        Me.Money.DataPropertyName = "Money"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle22.Format = "#,###,###,##0.####"
        Me.Money.DefaultCellStyle = DataGridViewCellStyle22
        Me.Money.HeaderText = "入出金"
        Me.Money.Name = "Money"
        Me.Money.ReadOnly = True
        Me.Money.Width = 80
        '
        'TotalMoney
        '
        Me.TotalMoney.DataPropertyName = "TotalMoney"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle23.Format = "#,###,###,##0.####"
        Me.TotalMoney.DefaultCellStyle = DataGridViewCellStyle23
        Me.TotalMoney.HeaderText = "残高"
        Me.TotalMoney.Name = "TotalMoney"
        Me.TotalMoney.ReadOnly = True
        Me.TotalMoney.Width = 80
        '
        'CustomerLedgerList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1094, 773)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Name = "CustomerLedgerList"
        Me.Text = "顧客勘定元帳"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtpSysDateTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpSysDateFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents tbCustCode As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chkMovementOfFundsDisp As System.Windows.Forms.CheckBox
    Friend WithEvents SysDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExecTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TypeOfTrading As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExercPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BuySell As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeTypeName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashTypeName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeStatusName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lot As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PayoutPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PremiumOrPayout As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Payout As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalMoneyPrev As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Money As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalMoney As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
