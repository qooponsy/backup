﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateMonitor
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateArrowCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateFilterDiff = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateFilterCountMax = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AnomalyRateDiff = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateFilterStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateFilterCounter = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastFilteringRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastFilteringTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastAnomalyRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastAnomalyTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ComCode, Me.ComName, Me.Rate, Me.RateArrowCount, Me.RateTime, Me.RateFilterDiff, Me.RateFilterCountMax, Me.AnomalyRateDiff, Me.RateFilterStatus, Me.RateFilterCounter, Me.LastFilteringRate, Me.LastFilteringTime, Me.LastAnomalyRate, Me.LastAnomalyTime})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 0)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle14.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(773, 114)
        Me.grid.TabIndex = 0
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.ComCode.HeaderText = "通貨ペア(code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle3
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComName.Width = 75
        '
        'Rate
        '
        Me.Rate.DataPropertyName = "Rate"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "######0.000#####"
        DataGridViewCellStyle4.Padding = New System.Windows.Forms.Padding(0, 0, 18, 0)
        Me.Rate.DefaultCellStyle = DataGridViewCellStyle4
        Me.Rate.HeaderText = "現在レート"
        Me.Rate.Name = "Rate"
        Me.Rate.ReadOnly = True
        Me.Rate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Rate.Width = 75
        '
        'RateArrowCount
        '
        Me.RateArrowCount.DataPropertyName = "RateArrowCount"
        Me.RateArrowCount.HeaderText = "レート矢印カウント"
        Me.RateArrowCount.Name = "RateArrowCount"
        Me.RateArrowCount.ReadOnly = True
        Me.RateArrowCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.RateArrowCount.Visible = False
        '
        'RateTime
        '
        Me.RateTime.DataPropertyName = "RateTime"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.Format = "yyyy/MM/dd HH:mm:ss.fff"
        DataGridViewCellStyle5.NullValue = Nothing
        Me.RateTime.DefaultCellStyle = DataGridViewCellStyle5
        Me.RateTime.HeaderText = "レート日時"
        Me.RateTime.Name = "RateTime"
        Me.RateTime.ReadOnly = True
        Me.RateTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.RateTime.Width = 130
        '
        'RateFilterDiff
        '
        Me.RateFilterDiff.DataPropertyName = "RateFilterDiff"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.Format = "N0"
        DataGridViewCellStyle6.NullValue = Nothing
        Me.RateFilterDiff.DefaultCellStyle = DataGridViewCellStyle6
        Me.RateFilterDiff.HeaderText = "レートフィルター乖離値"
        Me.RateFilterDiff.Name = "RateFilterDiff"
        Me.RateFilterDiff.ReadOnly = True
        Me.RateFilterDiff.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'RateFilterCountMax
        '
        Me.RateFilterCountMax.DataPropertyName = "RateFilterCountMax"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle7.Format = "N0"
        DataGridViewCellStyle7.NullValue = Nothing
        Me.RateFilterCountMax.DefaultCellStyle = DataGridViewCellStyle7
        Me.RateFilterCountMax.HeaderText = "レートフィルターカウント閾値"
        Me.RateFilterCountMax.Name = "RateFilterCountMax"
        Me.RateFilterCountMax.ReadOnly = True
        Me.RateFilterCountMax.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'AnomalyRateDiff
        '
        Me.AnomalyRateDiff.DataPropertyName = "AnomalyRateDiff"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "N0"
        Me.AnomalyRateDiff.DefaultCellStyle = DataGridViewCellStyle8
        Me.AnomalyRateDiff.HeaderText = "異常レート乖離値"
        Me.AnomalyRateDiff.Name = "AnomalyRateDiff"
        Me.AnomalyRateDiff.ReadOnly = True
        Me.AnomalyRateDiff.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.AnomalyRateDiff.Width = 90
        '
        'RateFilterStatus
        '
        Me.RateFilterStatus.DataPropertyName = "Status"
        Me.RateFilterStatus.HeaderText = "ステータス"
        Me.RateFilterStatus.Name = "RateFilterStatus"
        Me.RateFilterStatus.ReadOnly = True
        Me.RateFilterStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'RateFilterCounter
        '
        Me.RateFilterCounter.DataPropertyName = "RateFilterCounter"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "N0"
        Me.RateFilterCounter.DefaultCellStyle = DataGridViewCellStyle9
        Me.RateFilterCounter.HeaderText = "レートフィルターカウンタ"
        Me.RateFilterCounter.Name = "RateFilterCounter"
        Me.RateFilterCounter.ReadOnly = True
        Me.RateFilterCounter.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'LastFilteringRate
        '
        Me.LastFilteringRate.DataPropertyName = "LastFilteringRate"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "######0.000#####"
        Me.LastFilteringRate.DefaultCellStyle = DataGridViewCellStyle10
        Me.LastFilteringRate.HeaderText = "最終フィルタレート"
        Me.LastFilteringRate.Name = "LastFilteringRate"
        Me.LastFilteringRate.ReadOnly = True
        Me.LastFilteringRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LastFilteringRate.Width = 85
        '
        'LastFilteringTime
        '
        Me.LastFilteringTime.DataPropertyName = "LastFilteringTime"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle11.NullValue = Nothing
        Me.LastFilteringTime.DefaultCellStyle = DataGridViewCellStyle11
        Me.LastFilteringTime.HeaderText = "レート日時"
        Me.LastFilteringTime.Name = "LastFilteringTime"
        Me.LastFilteringTime.ReadOnly = True
        Me.LastFilteringTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LastFilteringTime.Width = 120
        '
        'LastAnomalyRate
        '
        Me.LastAnomalyRate.DataPropertyName = "LastAnomalyRate"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle12.Format = "######0.000#####"
        Me.LastAnomalyRate.DefaultCellStyle = DataGridViewCellStyle12
        Me.LastAnomalyRate.HeaderText = "最終異常レート"
        Me.LastAnomalyRate.Name = "LastAnomalyRate"
        Me.LastAnomalyRate.ReadOnly = True
        Me.LastAnomalyRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LastAnomalyRate.Width = 75
        '
        'LastAnomalyTime
        '
        Me.LastAnomalyTime.DataPropertyName = "LastAnomalyTime"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle13.NullValue = Nothing
        Me.LastAnomalyTime.DefaultCellStyle = DataGridViewCellStyle13
        Me.LastAnomalyTime.HeaderText = "レート日時"
        Me.LastAnomalyTime.Name = "LastAnomalyTime"
        Me.LastAnomalyTime.ReadOnly = True
        Me.LastAnomalyTime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.LastAnomalyTime.Width = 120
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'RateMonitor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(773, 114)
        Me.Controls.Add(Me.grid)
        Me.Name = "RateMonitor"
        Me.Text = "レートモニター"
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateArrowCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateFilterDiff As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateFilterCountMax As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AnomalyRateDiff As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateFilterStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateFilterCounter As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastFilteringRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastFilteringTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastAnomalyRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastAnomalyTime As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
