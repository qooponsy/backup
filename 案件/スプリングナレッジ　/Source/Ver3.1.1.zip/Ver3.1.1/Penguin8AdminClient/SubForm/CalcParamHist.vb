﻿Public Class CalcParamHist

    Private WithEvents service As New CalcParamHistService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1

    Private Sub ExercResultList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)
        
        '「対象のデータはありませんでした」Label
        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        '日付初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        dtpFromDate.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
        dtpToDate.Value = DateTime.Now
        dtpToDate.Checked = False

        MainWindow.SubFormExercResultList = True
        LoadSettings()

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub ExercResultList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormExercResultList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ExercResultList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ExercResultList_FormSize, _
            UserSettings.getInstance().DataSaved.ExercResultList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ExercResultList_Columns)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ExercResultList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ExercResultList_FormSize, _
            UserSettings.getInstance().DataSaved.ExercResultList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ExercResultList_Columns)
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("SysDate", GetType(Date))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("ShortRate", GetType(Decimal))
        Table.Columns.Add("SwapRate", GetType(Decimal))
        Table.Columns.Add("Volatility", GetType(Decimal))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of CalcParamHistData))
        For Each item As CalcParamHistData In list
            Dim row As DataRow = Table.NewRow()
            setResult(item, row)
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [CSV]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlCalcParamHist"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成()
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub request()
        Dim FromDate As String = If(dtpFromDate.Checked, dtpFromDate.Value.ToString("yyyyMMdd"), "")
        Dim ToDate As String = If(dtpToDate.Checked, dtpToDate.Value.ToString("yyyyMMdd"), "")
        Dim Sort As String = ""

        service.ReadList(FromDate, ToDate, Start, Sort)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    ''' <summary>
    ''' 検索処理キャンセル
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    ''' <summary>
    ''' 検索処理エラー
    ''' </summary>
    ''' <param name="ErrorMessage"></param>
    ''' <remarks></remarks>
    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    ''' <summary>
    ''' 検索処理成功
    ''' </summary>
    ''' <param name="list"></param>
    ''' <param name="existNextFlag"></param>
    ''' <remarks></remarks>
    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of CalcParamHistData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

    '行使結果(Call)時の値設定
    Private Sub setResult(item As CalcParamHistData, ByRef resList As DataRow)

        resList("SysDate") = item.SysDate
        resList("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
        resList("ShortRate") = item.InterestRate * 100
        resList("SwapRate") = item.SwapRate * 100
        resList("Volatility") = item.Volatility

    End Sub
End Class