﻿Imports System.Globalization

Public Class RateFilterForm

    Public Property Code As String

    Private WithEvents service As New RateFilterService
    Private WithEvents serviceRead As RateFilterService

    Private Enum FormMode
        INIT = 0
        READ = 1
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub RateFilterForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        setTitle()

        MainWindow.SubFormRateFilterForm = True

        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub RateFilterForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormRateFilterForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "レートフィルター設定登録"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "レートフィルター設定編集"
            Else
                Me.Text = "レートフィルター設定参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        tbRateFilterDiff.Enabled = (status = FormMode.EDIT)
        tbRateFilterCountMax.Enabled = (status = FormMode.EDIT)
        tbAnomalyRateDiff.Enabled = (status = FormMode.EDIT)
        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.EDITCONF, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initEdit()
        serviceRead = New RateFilterService
        RateFilterService.Read()
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        RateFilterService.Read()
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As RateFilterData)
        Dim ComItem As CurrencyPairData = CurrencyPairService.GetData(Code)
        lblComName.Text = ComItem.ComName
        tbRateFilterDiff.Text = data.RateFilterDiff * Math.Pow(10, ComItem.DecimalPlaces)
        tbRateFilterCountMax.Text = data.RateFilterCountMax
        tbAnomalyRateDiff.Text = data.AnomalyRateDiff * Math.Pow(10, ComItem.DecimalPlaces)
    End Sub

    Private Function getDataFromControl() As RateFilterData
        Dim ret As New RateFilterData
        Dim ComItem As CurrencyPairData = CurrencyPairService.GetData(Code)

        ret.ComCode = Code
        ret.RateFilterDiff = Integer.Parse(tbRateFilterDiff.Text) / Math.Pow(10, ComItem.DecimalPlaces)
        ret.RateFilterCountMax = Integer.Parse(tbRateFilterCountMax.Text)
        ret.AnomalyRateDiff = Integer.Parse(tbAnomalyRateDiff.Text) / Math.Pow(10, ComItem.DecimalPlaces)

        Return ret
    End Function

    Private Function checkInput() As Boolean

        If Me.tbRateFilterDiff.Text.Length = 0 Then
            MessageBox.Show(Me, "レートフィルター乖離値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExRate.IsMatch(tbRateFilterDiff.Text) Then
            MessageBox.Show(Me, "レートフィルター乖離値には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim RateFilterDiff As Decimal
        If Not Decimal.TryParse(tbRateFilterDiff.Text, RateFilterDiff) Then
            MessageBox.Show(Me, "レートフィルター乖離値には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbRateFilterCountMax.Text.Length = 0 Then
            MessageBox.Show(Me, "レートフィルターカウント閾値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExInt.IsMatch(Me.tbRateFilterCountMax.Text) Then
            MessageBox.Show(Me, "レートフィルターカウント閾値の入力内容が不正です。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim intRateFilterCountMax As Integer
        If Not Integer.TryParse(Me.tbRateFilterCountMax.Text, intRateFilterCountMax) Then
            MessageBox.Show(Me, "レートフィルターカウント閾値の入力内容が不正です。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbAnomalyRateDiff.Text.Length = 0 Then
            MessageBox.Show(Me, "異常レート乖離値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExRate.IsMatch(tbAnomalyRateDiff.Text) Then
            MessageBox.Show(Me, "異常レート乖離値には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim AnomalyRateDiff As Integer
        If Not Decimal.TryParse(tbAnomalyRateDiff.Text, AnomalyRateDiff) Then
            MessageBox.Show(Me, "異常レート乖離値には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub updateData()
        Dim data As RateFilterData = getDataFromControl()

        service.Update(data)
    End Sub

    Private Sub serviceRead_ReadError(ErrorMessage As String) Handles serviceRead.ReadError
        serviceRead = Nothing
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub serviceRead_ReadSuccess(RateFilterList As System.Collections.Generic.List(Of RateFilterData)) Handles serviceRead.ReadSuccess
        serviceRead = Nothing
        setControlFromData(RateFilterService.GetData(Code))

        If UserTypeManager.IsAdmin(SessionService.UserType) Then
            setFormMode(FormMode.EDIT)
        Else
            setFormMode(FormMode.REFERENCE)
        End If
    End Sub
End Class