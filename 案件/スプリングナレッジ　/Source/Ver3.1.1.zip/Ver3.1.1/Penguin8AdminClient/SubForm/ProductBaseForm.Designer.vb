﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductBaseForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.nudOpTerm = New System.Windows.Forms.NumericUpDown()
        Me.pnlOpTerm = New System.Windows.Forms.Panel()
        Me.rbOpTermMinutes = New System.Windows.Forms.RadioButton()
        Me.rbOpTermHour = New System.Windows.Forms.RadioButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pnlCreateTerm = New System.Windows.Forms.Panel()
        Me.rbCreateTermMinutes = New System.Windows.Forms.RadioButton()
        Me.rbCreateTermHour = New System.Windows.Forms.RadioButton()
        Me.nudCreateTerm = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.dtpStartTime = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.dtpEndTime = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.tbPayoutRate = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbExercPriceSettings = New System.Windows.Forms.TextBox()
        Me.tbExceptExercPrice = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tbVolRatio1Call = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbExercPriceTimeSpan = New System.Windows.Forms.TextBox()
        Me.tbExercPriceUnit = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cbExercPriceUnitType = New System.Windows.Forms.ComboBox()
        Me.tbBidPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.tbAskPriceMinCall = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btnExercPricePreview = New System.Windows.Forms.Button()
        Me.btnBulkSet = New System.Windows.Forms.Button()
        Me.nudBulkSetCount = New System.Windows.Forms.NumericUpDown()
        Me.tbBulkSetUnit = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.tbAskBidSpreadMinCall = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMaxCall = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMinCall = New System.Windows.Forms.TextBox()
        CType(Me.nudOpTerm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlOpTerm.SuspendLayout()
        Me.pnlCreateTerm.SuspendLayout()
        CType(Me.nudCreateTerm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudBulkSetCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "銘柄設定コード"
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(159, 14)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(131, 23)
        Me.lblCode.TabIndex = 1
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "通貨ペア"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(159, 68)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(131, 20)
        Me.cbComCode.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 97)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "オプション種別"
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Items.AddRange(New Object() {"バイナリ"})
        Me.cbOpType.Location = New System.Drawing.Point(159, 94)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(131, 20)
        Me.cbOpType.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 12)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "オプション期間"
        '
        'nudOpTerm
        '
        Me.nudOpTerm.Location = New System.Drawing.Point(159, 146)
        Me.nudOpTerm.Maximum = New Decimal(New Integer() {9999999, 0, 0, 0})
        Me.nudOpTerm.Name = "nudOpTerm"
        Me.nudOpTerm.Size = New System.Drawing.Size(131, 19)
        Me.nudOpTerm.TabIndex = 4
        Me.nudOpTerm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'pnlOpTerm
        '
        Me.pnlOpTerm.Controls.Add(Me.rbOpTermMinutes)
        Me.pnlOpTerm.Controls.Add(Me.rbOpTermHour)
        Me.pnlOpTerm.Location = New System.Drawing.Point(159, 120)
        Me.pnlOpTerm.Name = "pnlOpTerm"
        Me.pnlOpTerm.Size = New System.Drawing.Size(131, 24)
        Me.pnlOpTerm.TabIndex = 3
        '
        'rbOpTermMinutes
        '
        Me.rbOpTermMinutes.AutoSize = True
        Me.rbOpTermMinutes.Location = New System.Drawing.Point(76, 4)
        Me.rbOpTermMinutes.Name = "rbOpTermMinutes"
        Me.rbOpTermMinutes.Size = New System.Drawing.Size(35, 16)
        Me.rbOpTermMinutes.TabIndex = 1
        Me.rbOpTermMinutes.TabStop = True
        Me.rbOpTermMinutes.Text = "分"
        Me.rbOpTermMinutes.UseVisualStyleBackColor = True
        '
        'rbOpTermHour
        '
        Me.rbOpTermHour.AutoSize = True
        Me.rbOpTermHour.Location = New System.Drawing.Point(14, 4)
        Me.rbOpTermHour.Name = "rbOpTermHour"
        Me.rbOpTermHour.Size = New System.Drawing.Size(47, 16)
        Me.rbOpTermHour.TabIndex = 0
        Me.rbOpTermHour.TabStop = True
        Me.rbOpTermHour.Text = "時間"
        Me.rbOpTermHour.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "生成間隔"
        '
        'pnlCreateTerm
        '
        Me.pnlCreateTerm.Controls.Add(Me.rbCreateTermMinutes)
        Me.pnlCreateTerm.Controls.Add(Me.rbCreateTermHour)
        Me.pnlCreateTerm.Location = New System.Drawing.Point(159, 171)
        Me.pnlCreateTerm.Name = "pnlCreateTerm"
        Me.pnlCreateTerm.Size = New System.Drawing.Size(131, 24)
        Me.pnlCreateTerm.TabIndex = 5
        '
        'rbCreateTermMinutes
        '
        Me.rbCreateTermMinutes.AutoSize = True
        Me.rbCreateTermMinutes.Location = New System.Drawing.Point(76, 4)
        Me.rbCreateTermMinutes.Name = "rbCreateTermMinutes"
        Me.rbCreateTermMinutes.Size = New System.Drawing.Size(35, 16)
        Me.rbCreateTermMinutes.TabIndex = 1
        Me.rbCreateTermMinutes.TabStop = True
        Me.rbCreateTermMinutes.Text = "分"
        Me.rbCreateTermMinutes.UseVisualStyleBackColor = True
        '
        'rbCreateTermHour
        '
        Me.rbCreateTermHour.AutoSize = True
        Me.rbCreateTermHour.Location = New System.Drawing.Point(14, 4)
        Me.rbCreateTermHour.Name = "rbCreateTermHour"
        Me.rbCreateTermHour.Size = New System.Drawing.Size(47, 16)
        Me.rbCreateTermHour.TabIndex = 0
        Me.rbCreateTermHour.TabStop = True
        Me.rbCreateTermHour.Text = "時間"
        Me.rbCreateTermHour.UseVisualStyleBackColor = True
        '
        'nudCreateTerm
        '
        Me.nudCreateTerm.Location = New System.Drawing.Point(159, 197)
        Me.nudCreateTerm.Maximum = New Decimal(New Integer() {9999999, 0, 0, 0})
        Me.nudCreateTerm.Name = "nudCreateTerm"
        Me.nudCreateTerm.Size = New System.Drawing.Size(131, 19)
        Me.nudCreateTerm.TabIndex = 6
        Me.nudCreateTerm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 227)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "生成開始時間"
        '
        'dtpStartTime
        '
        Me.dtpStartTime.CustomFormat = "HH:mm"
        Me.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartTime.Location = New System.Drawing.Point(159, 222)
        Me.dtpStartTime.Name = "dtpStartTime"
        Me.dtpStartTime.ShowUpDown = True
        Me.dtpStartTime.Size = New System.Drawing.Size(131, 19)
        Me.dtpStartTime.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(30, 252)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 12)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "最終行使期日"
        '
        'dtpEndTime
        '
        Me.dtpEndTime.CustomFormat = "HH:mm"
        Me.dtpEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpEndTime.Location = New System.Drawing.Point(159, 247)
        Me.dtpEndTime.Name = "dtpEndTime"
        Me.dtpEndTime.ShowUpDown = True
        Me.dtpEndTime.Size = New System.Drawing.Size(131, 19)
        Me.dtpEndTime.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(30, 275)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 12)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "ペイアウト率"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(30, 46)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 12)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "有効フラグ"
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(159, 42)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(131, 20)
        Me.cbEnabled.TabIndex = 0
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(193, 440)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 44
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(326, 440)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 45
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'tbPayoutRate
        '
        Me.tbPayoutRate.Location = New System.Drawing.Point(159, 272)
        Me.tbPayoutRate.Name = "tbPayoutRate"
        Me.tbPayoutRate.ReadOnly = True
        Me.tbPayoutRate.Size = New System.Drawing.Size(131, 19)
        Me.tbPayoutRate.TabIndex = 9
        Me.tbPayoutRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(336, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(121, 12)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "行使価格決定時間(秒)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(336, 69)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(77, 12)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "行使価格設定"
        '
        'tbExercPriceSettings
        '
        Me.tbExercPriceSettings.AcceptsReturn = True
        Me.tbExercPriceSettings.Location = New System.Drawing.Point(338, 84)
        Me.tbExercPriceSettings.Multiline = True
        Me.tbExercPriceSettings.Name = "tbExercPriceSettings"
        Me.tbExercPriceSettings.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbExercPriceSettings.Size = New System.Drawing.Size(257, 70)
        Me.tbExercPriceSettings.TabIndex = 13
        Me.tbExercPriceSettings.Text = "+0.01,+0.02,+0.03,+0.04,+0.05" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "-0.01,-0.02,-0.03,-0.04,-0.05"
        Me.tbExercPriceSettings.WordWrap = False
        '
        'tbExceptExercPrice
        '
        Me.tbExceptExercPrice.AcceptsReturn = True
        Me.tbExceptExercPrice.Location = New System.Drawing.Point(338, 203)
        Me.tbExceptExercPrice.Multiline = True
        Me.tbExceptExercPrice.Name = "tbExceptExercPrice"
        Me.tbExceptExercPrice.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbExceptExercPrice.Size = New System.Drawing.Size(257, 57)
        Me.tbExceptExercPrice.TabIndex = 17
        Me.tbExceptExercPrice.Text = "95,96,97,98,99,100,101,102,103,104,105"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(336, 189)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 12)
        Me.Label13.TabIndex = 30
        Me.Label13.Text = "除外行使価格"
        '
        'tbVolRatio1Call
        '
        Me.tbVolRatio1Call.Location = New System.Drawing.Point(230, 330)
        Me.tbVolRatio1Call.Name = "tbVolRatio1Call"
        Me.tbVolRatio1Call.Size = New System.Drawing.Size(60, 19)
        Me.tbVolRatio1Call.TabIndex = 19
        Me.tbVolRatio1Call.Text = "0.5"
        Me.tbVolRatio1Call.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(30, 333)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 12)
        Me.Label14.TabIndex = 35
        Me.Label14.Text = "ボラティリティレシオ１"
        '
        'tbExercPriceTimeSpan
        '
        Me.tbExercPriceTimeSpan.Location = New System.Drawing.Point(464, 16)
        Me.tbExercPriceTimeSpan.Name = "tbExercPriceTimeSpan"
        Me.tbExercPriceTimeSpan.Size = New System.Drawing.Size(131, 19)
        Me.tbExercPriceTimeSpan.TabIndex = 10
        Me.tbExercPriceTimeSpan.Text = "300"
        Me.tbExercPriceTimeSpan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbExercPriceUnit
        '
        Me.tbExercPriceUnit.Location = New System.Drawing.Point(548, 42)
        Me.tbExercPriceUnit.Name = "tbExercPriceUnit"
        Me.tbExercPriceUnit.ReadOnly = True
        Me.tbExercPriceUnit.Size = New System.Drawing.Size(47, 19)
        Me.tbExercPriceUnit.TabIndex = 12
        Me.tbExercPriceUnit.Text = "0.01"
        Me.tbExercPriceUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(336, 45)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(88, 12)
        Me.Label17.TabIndex = 22
        Me.Label17.Text = "行使価格刻み幅"
        '
        'cbExercPriceUnitType
        '
        Me.cbExercPriceUnitType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercPriceUnitType.Enabled = False
        Me.cbExercPriceUnitType.FormattingEnabled = True
        Me.cbExercPriceUnitType.Items.AddRange(New Object() {"なし", "切り上げ", "切り捨て"})
        Me.cbExercPriceUnitType.Location = New System.Drawing.Point(464, 41)
        Me.cbExercPriceUnitType.Name = "cbExercPriceUnitType"
        Me.cbExercPriceUnitType.Size = New System.Drawing.Size(78, 20)
        Me.cbExercPriceUnitType.TabIndex = 11
        '
        'tbBidPriceMaxCall
        '
        Me.tbBidPriceMaxCall.Location = New System.Drawing.Point(448, 376)
        Me.tbBidPriceMaxCall.Name = "tbBidPriceMaxCall"
        Me.tbBidPriceMaxCall.ReadOnly = True
        Me.tbBidPriceMaxCall.Size = New System.Drawing.Size(60, 19)
        Me.tbBidPriceMaxCall.TabIndex = 40
        Me.tbBidPriceMaxCall.Text = "960"
        Me.tbBidPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(336, 379)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(77, 12)
        Me.Label19.TabIndex = 52
        Me.Label19.Text = "最高清算価格"
        '
        'tbAskPriceMinCall
        '
        Me.tbAskPriceMinCall.Location = New System.Drawing.Point(448, 353)
        Me.tbAskPriceMinCall.Name = "tbAskPriceMinCall"
        Me.tbAskPriceMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskPriceMinCall.TabIndex = 38
        Me.tbAskPriceMinCall.Text = "40"
        Me.tbAskPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(336, 357)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(77, 12)
        Me.Label20.TabIndex = 49
        Me.Label20.Text = "最低購入価格"
        '
        'btnExercPricePreview
        '
        Me.btnExercPricePreview.Location = New System.Drawing.Point(448, 265)
        Me.btnExercPricePreview.Name = "btnExercPricePreview"
        Me.btnExercPricePreview.Size = New System.Drawing.Size(147, 23)
        Me.btnExercPricePreview.TabIndex = 18
        Me.btnExercPricePreview.TabStop = False
        Me.btnExercPricePreview.Text = "行使価格プレビュー"
        Me.btnExercPricePreview.UseVisualStyleBackColor = True
        '
        'btnBulkSet
        '
        Me.btnBulkSet.Location = New System.Drawing.Point(518, 155)
        Me.btnBulkSet.Name = "btnBulkSet"
        Me.btnBulkSet.Size = New System.Drawing.Size(77, 23)
        Me.btnBulkSet.TabIndex = 16
        Me.btnBulkSet.TabStop = False
        Me.btnBulkSet.Text = "一括設定"
        Me.btnBulkSet.UseVisualStyleBackColor = True
        '
        'nudBulkSetCount
        '
        Me.nudBulkSetCount.Location = New System.Drawing.Point(481, 157)
        Me.nudBulkSetCount.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.nudBulkSetCount.Name = "nudBulkSetCount"
        Me.nudBulkSetCount.Size = New System.Drawing.Size(31, 19)
        Me.nudBulkSetCount.TabIndex = 15
        Me.nudBulkSetCount.TabStop = False
        Me.nudBulkSetCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudBulkSetCount.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'tbBulkSetUnit
        '
        Me.tbBulkSetUnit.Location = New System.Drawing.Point(413, 157)
        Me.tbBulkSetUnit.Name = "tbBulkSetUnit"
        Me.tbBulkSetUnit.Size = New System.Drawing.Size(62, 19)
        Me.tbBulkSetUnit.TabIndex = 14
        Me.tbBulkSetUnit.TabStop = False
        Me.tbBulkSetUnit.Text = "0.00005"
        Me.tbBulkSetUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(30, 358)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(137, 12)
        Me.Label23.TabIndex = 124
        Me.Label23.Text = "購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(336, 333)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(77, 12)
        Me.Label25.TabIndex = 126
        Me.Label25.Text = "最高購入価格"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(336, 401)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(77, 12)
        Me.Label26.TabIndex = 127
        Me.Label26.Text = "最低清算価格"
        '
        'tbAskBidSpreadMinCall
        '
        Me.tbAskBidSpreadMinCall.Location = New System.Drawing.Point(230, 355)
        Me.tbAskBidSpreadMinCall.Name = "tbAskBidSpreadMinCall"
        Me.tbAskBidSpreadMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbAskBidSpreadMinCall.TabIndex = 32
        Me.tbAskBidSpreadMinCall.Text = "0"
        Me.tbAskBidSpreadMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMaxCall
        '
        Me.tbAskPriceMaxCall.Location = New System.Drawing.Point(448, 328)
        Me.tbAskPriceMaxCall.Name = "tbAskPriceMaxCall"
        Me.tbAskPriceMaxCall.Size = New System.Drawing.Size(61, 19)
        Me.tbAskPriceMaxCall.TabIndex = 36
        Me.tbAskPriceMaxCall.Text = "1000"
        Me.tbAskPriceMaxCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMinCall
        '
        Me.tbBidPriceMinCall.Location = New System.Drawing.Point(448, 401)
        Me.tbBidPriceMinCall.Name = "tbBidPriceMinCall"
        Me.tbBidPriceMinCall.ReadOnly = True
        Me.tbBidPriceMinCall.Size = New System.Drawing.Size(60, 19)
        Me.tbBidPriceMinCall.TabIndex = 42
        Me.tbBidPriceMinCall.Text = "0"
        Me.tbBidPriceMinCall.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ProductBaseForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(634, 489)
        Me.Controls.Add(Me.tbBidPriceMinCall)
        Me.Controls.Add(Me.tbAskPriceMaxCall)
        Me.Controls.Add(Me.tbAskBidSpreadMinCall)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.tbBulkSetUnit)
        Me.Controls.Add(Me.nudBulkSetCount)
        Me.Controls.Add(Me.btnBulkSet)
        Me.Controls.Add(Me.btnExercPricePreview)
        Me.Controls.Add(Me.tbAskPriceMinCall)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.tbBidPriceMaxCall)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.cbExercPriceUnitType)
        Me.Controls.Add(Me.tbExercPriceUnit)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.tbExercPriceTimeSpan)
        Me.Controls.Add(Me.tbVolRatio1Call)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.tbExceptExercPrice)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.tbExercPriceSettings)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.tbPayoutRate)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.dtpEndTime)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.dtpStartTime)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.pnlCreateTerm)
        Me.Controls.Add(Me.nudCreateTerm)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.pnlOpTerm)
        Me.Controls.Add(Me.nudOpTerm)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cbOpType)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "ProductBaseForm"
        Me.Text = "銘柄設定登録"
        CType(Me.nudOpTerm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlOpTerm.ResumeLayout(False)
        Me.pnlOpTerm.PerformLayout()
        Me.pnlCreateTerm.ResumeLayout(False)
        Me.pnlCreateTerm.PerformLayout()
        CType(Me.nudCreateTerm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudBulkSetCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cbOpType As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents nudOpTerm As System.Windows.Forms.NumericUpDown
    Friend WithEvents pnlOpTerm As System.Windows.Forms.Panel
    Friend WithEvents rbOpTermMinutes As System.Windows.Forms.RadioButton
    Friend WithEvents rbOpTermHour As System.Windows.Forms.RadioButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents pnlCreateTerm As System.Windows.Forms.Panel
    Friend WithEvents rbCreateTermMinutes As System.Windows.Forms.RadioButton
    Friend WithEvents rbCreateTermHour As System.Windows.Forms.RadioButton
    Friend WithEvents nudCreateTerm As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents dtpStartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dtpEndTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents tbPayoutRate As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbExercPriceSettings As System.Windows.Forms.TextBox
    Friend WithEvents tbExceptExercPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio1Call As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tbExercPriceTimeSpan As System.Windows.Forms.TextBox
    Friend WithEvents tbExercPriceUnit As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cbExercPriceUnitType As System.Windows.Forms.ComboBox
    Friend WithEvents tbBidPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMinCall As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents btnExercPricePreview As System.Windows.Forms.Button
    Friend WithEvents btnBulkSet As System.Windows.Forms.Button
    Friend WithEvents nudBulkSetCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents tbBulkSetUnit As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents tbAskBidSpreadMinCall As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMaxCall As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMinCall As System.Windows.Forms.TextBox
End Class
