﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PricingSim2
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.chartRate = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.chartPrice = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbColorPrice = New System.Windows.Forms.RadioButton()
        Me.rbColorType = New System.Windows.Forms.RadioButton()
        Me.chkChartView9 = New System.Windows.Forms.CheckBox()
        Me.chkChartView8 = New System.Windows.Forms.CheckBox()
        Me.chkChartView7 = New System.Windows.Forms.CheckBox()
        Me.chkChartView6 = New System.Windows.Forms.CheckBox()
        Me.chkChartView5 = New System.Windows.Forms.CheckBox()
        Me.chkChartView4 = New System.Windows.Forms.CheckBox()
        Me.chkChartView3 = New System.Windows.Forms.CheckBox()
        Me.chkChartView2 = New System.Windows.Forms.CheckBox()
        Me.chkChartView1 = New System.Windows.Forms.CheckBox()
        Me.chkPutBidLowView = New System.Windows.Forms.CheckBox()
        Me.chkPutBidHighView = New System.Windows.Forms.CheckBox()
        Me.chkPutAskLowView = New System.Windows.Forms.CheckBox()
        Me.chkPutAskHighView = New System.Windows.Forms.CheckBox()
        Me.chkCallBidLowView = New System.Windows.Forms.CheckBox()
        Me.chkCallBidHighView = New System.Windows.Forms.CheckBox()
        Me.chkCallAskLowView = New System.Windows.Forms.CheckBox()
        Me.chkCallAskHighView = New System.Windows.Forms.CheckBox()
        Me.tabSetting = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.tbBidPriceMinPut1 = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMinCall1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.tbAskPriceMaxPut1 = New System.Windows.Forms.TextBox()
        Me.tbAskPriceMaxCall1 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tbAskBidSpreadMinPut1 = New System.Windows.Forms.TextBox()
        Me.tbAskBidSpreadMinCall1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbAskFeePricePut1 = New System.Windows.Forms.TextBox()
        Me.tbAskFeePriceCall1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tbSwapRate1 = New System.Windows.Forms.TextBox()
        Me.tbInterestRate1 = New System.Windows.Forms.TextBox()
        Me.tbHV1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbVolSmileBPut1 = New System.Windows.Forms.TextBox()
        Me.tbVolSmileAPut1 = New System.Windows.Forms.TextBox()
        Me.tbVolSmileBCall1 = New System.Windows.Forms.TextBox()
        Me.tbVolSmileACall1 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.tbCallPutSpread1 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tbBidFeeRatePut1 = New System.Windows.Forms.TextBox()
        Me.lblPutName1 = New System.Windows.Forms.Label()
        Me.lblCallName1 = New System.Windows.Forms.Label()
        Me.tbAskPriceMinPut1 = New System.Windows.Forms.TextBox()
        Me.tbBidPriceMaxPut1 = New System.Windows.Forms.TextBox()
        Me.tbVolSpreadPut1 = New System.Windows.Forms.TextBox()
        Me.tbVolRatio2Put1 = New System.Windows.Forms.TextBox()
        Me.tbVolRatio1Put1 = New System.Windows.Forms.TextBox()
        Me.tbBidFeeRateCall1 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.tbAskPriceMinCall1 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.tbBidPriceMaxCall1 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.tbVolSpreadCall1 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.tbVolRatio2Call1 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.tbVolRatio1Call1 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkPutBidLow = New System.Windows.Forms.CheckBox()
        Me.chkPutBidHigh = New System.Windows.Forms.CheckBox()
        Me.chkPutAskLow = New System.Windows.Forms.CheckBox()
        Me.chkPutAskHigh = New System.Windows.Forms.CheckBox()
        Me.chkCallBidLow = New System.Windows.Forms.CheckBox()
        Me.chkCallBidHigh = New System.Windows.Forms.CheckBox()
        Me.chkCallAskLow = New System.Windows.Forms.CheckBox()
        Me.chkCallAskHigh = New System.Windows.Forms.CheckBox()
        Me.chkVolatility = New System.Windows.Forms.CheckBox()
        Me.chkSettingMulti = New System.Windows.Forms.CheckBox()
        Me.chkChart9 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice9 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart8 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice8 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart7 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice7 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart6 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice6 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart5 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice5 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart4 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice4 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart3 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice3 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart2 = New System.Windows.Forms.CheckBox()
        Me.nudExercPrice2 = New System.Windows.Forms.NumericUpDown()
        Me.chkChart1 = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnRateChart = New System.Windows.Forms.Button()
        Me.nudTerm = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.dtpExercTime = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnRate = New System.Windows.Forms.Button()
        Me.nudExercPrice1 = New System.Windows.Forms.NumericUpDown()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.chartRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chartPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tabSetting.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.nudExercPrice9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTerm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudExercPrice1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(504, 16)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(78, 29)
        Me.btnCSV.TabIndex = 195
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(289, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.chartRate)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.chartPrice)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel2)
        Me.SplitContainer1.Size = New System.Drawing.Size(653, 705)
        Me.SplitContainer1.SplitterDistance = 160
        Me.SplitContainer1.TabIndex = 21
        '
        'chartRate
        '
        ChartArea1.AxisY.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount
        ChartArea1.Name = "ChartArea1"
        Me.chartRate.ChartAreas.Add(ChartArea1)
        Me.chartRate.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chartRate.Location = New System.Drawing.Point(0, 0)
        Me.chartRate.Name = "chartRate"
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick
        Series1.Name = "seriesRate"
        Series1.XValueMember = "RateChartTime"
        Series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time
        Series1.YValueMembers = "HighRate, LowRate, OpenRate, CloseRate"
        Series1.YValuesPerPoint = 4
        Series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.[Double]
        Me.chartRate.Series.Add(Series1)
        Me.chartRate.Size = New System.Drawing.Size(653, 160)
        Me.chartRate.TabIndex = 0
        Me.chartRate.Text = "Chart1"
        '
        'chartPrice
        '
        ChartArea2.Name = "ChartArea1"
        Me.chartPrice.ChartAreas.Add(ChartArea2)
        Me.chartPrice.Dock = System.Windows.Forms.DockStyle.Fill
        Me.chartPrice.Location = New System.Drawing.Point(0, 0)
        Me.chartPrice.Name = "chartPrice"
        Me.chartPrice.Size = New System.Drawing.Size(653, 479)
        Me.chartPrice.TabIndex = 2
        Me.chartPrice.Text = "Chart2"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.GroupBox1)
        Me.Panel2.Controls.Add(Me.chkChartView9)
        Me.Panel2.Controls.Add(Me.chkChartView8)
        Me.Panel2.Controls.Add(Me.chkChartView7)
        Me.Panel2.Controls.Add(Me.chkChartView6)
        Me.Panel2.Controls.Add(Me.chkChartView5)
        Me.Panel2.Controls.Add(Me.chkChartView4)
        Me.Panel2.Controls.Add(Me.chkChartView3)
        Me.Panel2.Controls.Add(Me.chkChartView2)
        Me.Panel2.Controls.Add(Me.chkChartView1)
        Me.Panel2.Controls.Add(Me.chkPutBidLowView)
        Me.Panel2.Controls.Add(Me.chkPutBidHighView)
        Me.Panel2.Controls.Add(Me.chkPutAskLowView)
        Me.Panel2.Controls.Add(Me.chkPutAskHighView)
        Me.Panel2.Controls.Add(Me.chkCallBidLowView)
        Me.Panel2.Controls.Add(Me.chkCallBidHighView)
        Me.Panel2.Controls.Add(Me.chkCallAskLowView)
        Me.Panel2.Controls.Add(Me.chkCallAskHighView)
        Me.Panel2.Controls.Add(Me.btnCSV)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 479)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(653, 62)
        Me.Panel2.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbColorPrice)
        Me.GroupBox1.Controls.Add(Me.rbColorType)
        Me.GroupBox1.Location = New System.Drawing.Point(389, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(99, 55)
        Me.GroupBox1.TabIndex = 196
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "カラー"
        '
        'rbColorPrice
        '
        Me.rbColorPrice.AutoSize = True
        Me.rbColorPrice.Location = New System.Drawing.Point(18, 31)
        Me.rbColorPrice.Name = "rbColorPrice"
        Me.rbColorPrice.Size = New System.Drawing.Size(71, 16)
        Me.rbColorPrice.TabIndex = 1
        Me.rbColorPrice.Text = "行使価格"
        Me.rbColorPrice.UseVisualStyleBackColor = True
        '
        'rbColorType
        '
        Me.rbColorType.AutoSize = True
        Me.rbColorType.Location = New System.Drawing.Point(18, 13)
        Me.rbColorType.Name = "rbColorType"
        Me.rbColorType.Size = New System.Drawing.Size(71, 16)
        Me.rbColorType.TabIndex = 0
        Me.rbColorType.Text = "価格種別"
        Me.rbColorType.UseVisualStyleBackColor = True
        '
        'chkChartView9
        '
        Me.chkChartView9.AutoSize = True
        Me.chkChartView9.Location = New System.Drawing.Point(295, 3)
        Me.chkChartView9.Name = "chkChartView9"
        Me.chkChartView9.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView9.TabIndex = 16
        Me.chkChartView9.Text = "9"
        Me.chkChartView9.UseVisualStyleBackColor = True
        '
        'chkChartView8
        '
        Me.chkChartView8.AutoSize = True
        Me.chkChartView8.Location = New System.Drawing.Point(259, 3)
        Me.chkChartView8.Name = "chkChartView8"
        Me.chkChartView8.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView8.TabIndex = 15
        Me.chkChartView8.Text = "8"
        Me.chkChartView8.UseVisualStyleBackColor = True
        '
        'chkChartView7
        '
        Me.chkChartView7.AutoSize = True
        Me.chkChartView7.Location = New System.Drawing.Point(223, 3)
        Me.chkChartView7.Name = "chkChartView7"
        Me.chkChartView7.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView7.TabIndex = 14
        Me.chkChartView7.Text = "7"
        Me.chkChartView7.UseVisualStyleBackColor = True
        '
        'chkChartView6
        '
        Me.chkChartView6.AutoSize = True
        Me.chkChartView6.Location = New System.Drawing.Point(187, 3)
        Me.chkChartView6.Name = "chkChartView6"
        Me.chkChartView6.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView6.TabIndex = 13
        Me.chkChartView6.Text = "6"
        Me.chkChartView6.UseVisualStyleBackColor = True
        '
        'chkChartView5
        '
        Me.chkChartView5.AutoSize = True
        Me.chkChartView5.Location = New System.Drawing.Point(151, 3)
        Me.chkChartView5.Name = "chkChartView5"
        Me.chkChartView5.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView5.TabIndex = 12
        Me.chkChartView5.Text = "5"
        Me.chkChartView5.UseVisualStyleBackColor = True
        '
        'chkChartView4
        '
        Me.chkChartView4.AutoSize = True
        Me.chkChartView4.Location = New System.Drawing.Point(115, 3)
        Me.chkChartView4.Name = "chkChartView4"
        Me.chkChartView4.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView4.TabIndex = 11
        Me.chkChartView4.Text = "4"
        Me.chkChartView4.UseVisualStyleBackColor = True
        '
        'chkChartView3
        '
        Me.chkChartView3.AutoSize = True
        Me.chkChartView3.Location = New System.Drawing.Point(79, 3)
        Me.chkChartView3.Name = "chkChartView3"
        Me.chkChartView3.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView3.TabIndex = 10
        Me.chkChartView3.Text = "3"
        Me.chkChartView3.UseVisualStyleBackColor = True
        '
        'chkChartView2
        '
        Me.chkChartView2.AutoSize = True
        Me.chkChartView2.Location = New System.Drawing.Point(43, 3)
        Me.chkChartView2.Name = "chkChartView2"
        Me.chkChartView2.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView2.TabIndex = 9
        Me.chkChartView2.Text = "2"
        Me.chkChartView2.UseVisualStyleBackColor = True
        '
        'chkChartView1
        '
        Me.chkChartView1.AutoSize = True
        Me.chkChartView1.Location = New System.Drawing.Point(7, 3)
        Me.chkChartView1.Name = "chkChartView1"
        Me.chkChartView1.Size = New System.Drawing.Size(30, 16)
        Me.chkChartView1.TabIndex = 8
        Me.chkChartView1.Text = "1"
        Me.chkChartView1.UseVisualStyleBackColor = True
        '
        'chkPutBidLowView
        '
        Me.chkPutBidLowView.AutoSize = True
        Me.chkPutBidLowView.Location = New System.Drawing.Point(295, 43)
        Me.chkPutBidLowView.Name = "chkPutBidLowView"
        Me.chkPutBidLowView.Size = New System.Drawing.Size(85, 16)
        Me.chkPutBidLowView.TabIndex = 7
        Me.chkPutBidLowView.Text = "Put清算Low"
        Me.chkPutBidLowView.UseVisualStyleBackColor = True
        '
        'chkPutBidHighView
        '
        Me.chkPutBidHighView.AutoSize = True
        Me.chkPutBidHighView.Location = New System.Drawing.Point(295, 23)
        Me.chkPutBidHighView.Name = "chkPutBidHighView"
        Me.chkPutBidHighView.Size = New System.Drawing.Size(88, 16)
        Me.chkPutBidHighView.TabIndex = 6
        Me.chkPutBidHighView.Text = "Put清算High"
        Me.chkPutBidHighView.UseVisualStyleBackColor = True
        '
        'chkPutAskLowView
        '
        Me.chkPutAskLowView.AutoSize = True
        Me.chkPutAskLowView.Location = New System.Drawing.Point(201, 43)
        Me.chkPutAskLowView.Name = "chkPutAskLowView"
        Me.chkPutAskLowView.Size = New System.Drawing.Size(85, 16)
        Me.chkPutAskLowView.TabIndex = 5
        Me.chkPutAskLowView.Text = "Put購入Low"
        Me.chkPutAskLowView.UseVisualStyleBackColor = True
        '
        'chkPutAskHighView
        '
        Me.chkPutAskHighView.AutoSize = True
        Me.chkPutAskHighView.Location = New System.Drawing.Point(201, 23)
        Me.chkPutAskHighView.Name = "chkPutAskHighView"
        Me.chkPutAskHighView.Size = New System.Drawing.Size(88, 16)
        Me.chkPutAskHighView.TabIndex = 4
        Me.chkPutAskHighView.Text = "Put購入High"
        Me.chkPutAskHighView.UseVisualStyleBackColor = True
        '
        'chkCallBidLowView
        '
        Me.chkCallBidLowView.AutoSize = True
        Me.chkCallBidLowView.Location = New System.Drawing.Point(104, 43)
        Me.chkCallBidLowView.Name = "chkCallBidLowView"
        Me.chkCallBidLowView.Size = New System.Drawing.Size(88, 16)
        Me.chkCallBidLowView.TabIndex = 3
        Me.chkCallBidLowView.Text = "Call清算Low"
        Me.chkCallBidLowView.UseVisualStyleBackColor = True
        '
        'chkCallBidHighView
        '
        Me.chkCallBidHighView.AutoSize = True
        Me.chkCallBidHighView.Location = New System.Drawing.Point(104, 23)
        Me.chkCallBidHighView.Name = "chkCallBidHighView"
        Me.chkCallBidHighView.Size = New System.Drawing.Size(91, 16)
        Me.chkCallBidHighView.TabIndex = 2
        Me.chkCallBidHighView.Text = "Call清算High"
        Me.chkCallBidHighView.UseVisualStyleBackColor = True
        '
        'chkCallAskLowView
        '
        Me.chkCallAskLowView.AutoSize = True
        Me.chkCallAskLowView.Location = New System.Drawing.Point(7, 43)
        Me.chkCallAskLowView.Name = "chkCallAskLowView"
        Me.chkCallAskLowView.Size = New System.Drawing.Size(88, 16)
        Me.chkCallAskLowView.TabIndex = 1
        Me.chkCallAskLowView.Text = "Call購入Low"
        Me.chkCallAskLowView.UseVisualStyleBackColor = True
        '
        'chkCallAskHighView
        '
        Me.chkCallAskHighView.AutoSize = True
        Me.chkCallAskHighView.Location = New System.Drawing.Point(7, 23)
        Me.chkCallAskHighView.Name = "chkCallAskHighView"
        Me.chkCallAskHighView.Size = New System.Drawing.Size(91, 16)
        Me.chkCallAskHighView.TabIndex = 0
        Me.chkCallAskHighView.Text = "Call購入High"
        Me.chkCallAskHighView.UseVisualStyleBackColor = True
        '
        'tabSetting
        '
        Me.tabSetting.Controls.Add(Me.TabPage1)
        Me.tabSetting.Location = New System.Drawing.Point(0, 316)
        Me.tabSetting.Name = "tabSetting"
        Me.tabSetting.SelectedIndex = 0
        Me.tabSetting.Size = New System.Drawing.Size(289, 377)
        Me.tabSetting.TabIndex = 189
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.Controls.Add(Me.tbBidPriceMinPut1)
        Me.TabPage1.Controls.Add(Me.tbBidPriceMinCall1)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.tbAskPriceMaxPut1)
        Me.TabPage1.Controls.Add(Me.tbAskPriceMaxCall1)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.tbAskBidSpreadMinPut1)
        Me.TabPage1.Controls.Add(Me.tbAskBidSpreadMinCall1)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.tbAskFeePricePut1)
        Me.TabPage1.Controls.Add(Me.tbAskFeePriceCall1)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.tbSwapRate1)
        Me.TabPage1.Controls.Add(Me.tbInterestRate1)
        Me.TabPage1.Controls.Add(Me.tbHV1)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.tbVolSmileBPut1)
        Me.TabPage1.Controls.Add(Me.tbVolSmileAPut1)
        Me.TabPage1.Controls.Add(Me.tbVolSmileBCall1)
        Me.TabPage1.Controls.Add(Me.tbVolSmileACall1)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.tbCallPutSpread1)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.tbBidFeeRatePut1)
        Me.TabPage1.Controls.Add(Me.lblPutName1)
        Me.TabPage1.Controls.Add(Me.lblCallName1)
        Me.TabPage1.Controls.Add(Me.tbAskPriceMinPut1)
        Me.TabPage1.Controls.Add(Me.tbBidPriceMaxPut1)
        Me.TabPage1.Controls.Add(Me.tbVolSpreadPut1)
        Me.TabPage1.Controls.Add(Me.tbVolRatio2Put1)
        Me.TabPage1.Controls.Add(Me.tbVolRatio1Put1)
        Me.TabPage1.Controls.Add(Me.tbBidFeeRateCall1)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.tbAskPriceMinCall1)
        Me.TabPage1.Controls.Add(Me.Label20)
        Me.TabPage1.Controls.Add(Me.tbBidPriceMaxCall1)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.tbVolSpreadCall1)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.tbVolRatio2Call1)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.tbVolRatio1Call1)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(281, 351)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "1"
        '
        'tbBidPriceMinPut1
        '
        Me.tbBidPriceMinPut1.Location = New System.Drawing.Point(210, 274)
        Me.tbBidPriceMinPut1.Name = "tbBidPriceMinPut1"
        Me.tbBidPriceMinPut1.ReadOnly = True
        Me.tbBidPriceMinPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMinPut1.TabIndex = 213
        Me.tbBidPriceMinPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMinCall1
        '
        Me.tbBidPriceMinCall1.Location = New System.Drawing.Point(149, 274)
        Me.tbBidPriceMinCall1.Name = "tbBidPriceMinCall1"
        Me.tbBidPriceMinCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMinCall1.TabIndex = 212
        Me.tbBidPriceMinCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(11, 277)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(77, 12)
        Me.Label11.TabIndex = 211
        Me.Label11.Text = "最低清算価格"
        '
        'tbAskPriceMaxPut1
        '
        Me.tbAskPriceMaxPut1.Location = New System.Drawing.Point(210, 211)
        Me.tbAskPriceMaxPut1.Name = "tbAskPriceMaxPut1"
        Me.tbAskPriceMaxPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMaxPut1.TabIndex = 210
        Me.tbAskPriceMaxPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskPriceMaxCall1
        '
        Me.tbAskPriceMaxCall1.Location = New System.Drawing.Point(149, 211)
        Me.tbAskPriceMaxCall1.Name = "tbAskPriceMaxCall1"
        Me.tbAskPriceMaxCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMaxCall1.TabIndex = 209
        Me.tbAskPriceMaxCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(11, 214)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 12)
        Me.Label13.TabIndex = 208
        Me.Label13.Text = "最高購入価格"
        '
        'tbAskBidSpreadMinPut1
        '
        Me.tbAskBidSpreadMinPut1.Location = New System.Drawing.Point(210, 169)
        Me.tbAskBidSpreadMinPut1.Name = "tbAskBidSpreadMinPut1"
        Me.tbAskBidSpreadMinPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskBidSpreadMinPut1.TabIndex = 207
        Me.tbAskBidSpreadMinPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskBidSpreadMinCall1
        '
        Me.tbAskBidSpreadMinCall1.Location = New System.Drawing.Point(149, 169)
        Me.tbAskBidSpreadMinCall1.Name = "tbAskBidSpreadMinCall1"
        Me.tbAskBidSpreadMinCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskBidSpreadMinCall1.TabIndex = 206
        Me.tbAskBidSpreadMinCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(11, 172)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(137, 12)
        Me.Label9.TabIndex = 205
        Me.Label9.Text = "購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ"
        '
        'tbAskFeePricePut1
        '
        Me.tbAskFeePricePut1.Location = New System.Drawing.Point(210, 148)
        Me.tbAskFeePricePut1.Name = "tbAskFeePricePut1"
        Me.tbAskFeePricePut1.ReadOnly = True
        Me.tbAskFeePricePut1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskFeePricePut1.TabIndex = 204
        Me.tbAskFeePricePut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAskFeePriceCall1
        '
        Me.tbAskFeePriceCall1.Location = New System.Drawing.Point(149, 148)
        Me.tbAskFeePriceCall1.Name = "tbAskFeePriceCall1"
        Me.tbAskFeePriceCall1.ReadOnly = True
        Me.tbAskFeePriceCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskFeePriceCall1.TabIndex = 203
        Me.tbAskFeePriceCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 151)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 12)
        Me.Label1.TabIndex = 202
        Me.Label1.Text = "購入価格リスク"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(155, 306)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 12)
        Me.Label7.TabIndex = 201
        Me.Label7.Text = "HV"
        '
        'tbSwapRate1
        '
        Me.tbSwapRate1.Location = New System.Drawing.Point(93, 324)
        Me.tbSwapRate1.Name = "tbSwapRate1"
        Me.tbSwapRate1.Size = New System.Drawing.Size(50, 19)
        Me.tbSwapRate1.TabIndex = 199
        Me.tbSwapRate1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbInterestRate1
        '
        Me.tbInterestRate1.Location = New System.Drawing.Point(93, 303)
        Me.tbInterestRate1.Name = "tbInterestRate1"
        Me.tbInterestRate1.Size = New System.Drawing.Size(50, 19)
        Me.tbInterestRate1.TabIndex = 197
        Me.tbInterestRate1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHV1
        '
        Me.tbHV1.Location = New System.Drawing.Point(156, 324)
        Me.tbHV1.Name = "tbHV1"
        Me.tbHV1.Size = New System.Drawing.Size(113, 19)
        Me.tbHV1.TabIndex = 200
        Me.tbHV1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 327)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 198
        Me.Label6.Text = "スワップ金利(%)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(11, 306)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 12)
        Me.Label4.TabIndex = 196
        Me.Label4.Text = "短期金利(%)"
        '
        'tbVolSmileBPut1
        '
        Me.tbVolSmileBPut1.Location = New System.Drawing.Point(210, 106)
        Me.tbVolSmileBPut1.Name = "tbVolSmileBPut1"
        Me.tbVolSmileBPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileBPut1.TabIndex = 178
        Me.tbVolSmileBPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSmileAPut1
        '
        Me.tbVolSmileAPut1.Location = New System.Drawing.Point(210, 85)
        Me.tbVolSmileAPut1.Name = "tbVolSmileAPut1"
        Me.tbVolSmileAPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileAPut1.TabIndex = 176
        Me.tbVolSmileAPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSmileBCall1
        '
        Me.tbVolSmileBCall1.Location = New System.Drawing.Point(149, 106)
        Me.tbVolSmileBCall1.Name = "tbVolSmileBCall1"
        Me.tbVolSmileBCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileBCall1.TabIndex = 177
        Me.tbVolSmileBCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSmileACall1
        '
        Me.tbVolSmileACall1.Location = New System.Drawing.Point(149, 85)
        Me.tbVolSmileACall1.Name = "tbVolSmileACall1"
        Me.tbVolSmileACall1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSmileACall1.TabIndex = 174
        Me.tbVolSmileACall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 110)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(106, 12)
        Me.Label10.TabIndex = 192
        Me.Label10.Text = "ボラティリティスマイルｂ"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(10, 89)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(106, 12)
        Me.Label22.TabIndex = 191
        Me.Label22.Text = "ボラティリティスマイルａ"
        '
        'tbCallPutSpread1
        '
        Me.tbCallPutSpread1.Location = New System.Drawing.Point(210, 43)
        Me.tbCallPutSpread1.Name = "tbCallPutSpread1"
        Me.tbCallPutSpread1.Size = New System.Drawing.Size(50, 19)
        Me.tbCallPutSpread1.TabIndex = 170
        Me.tbCallPutSpread1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 47)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(108, 12)
        Me.Label16.TabIndex = 190
        Me.Label16.Text = "CALL/PUT スプレッド"
        '
        'tbBidFeeRatePut1
        '
        Me.tbBidFeeRatePut1.Location = New System.Drawing.Point(210, 190)
        Me.tbBidFeeRatePut1.Name = "tbBidFeeRatePut1"
        Me.tbBidFeeRatePut1.ReadOnly = True
        Me.tbBidFeeRatePut1.Size = New System.Drawing.Size(50, 19)
        Me.tbBidFeeRatePut1.TabIndex = 183
        Me.tbBidFeeRatePut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblPutName1
        '
        Me.lblPutName1.Location = New System.Drawing.Point(205, 7)
        Me.lblPutName1.Name = "lblPutName1"
        Me.lblPutName1.Size = New System.Drawing.Size(60, 12)
        Me.lblPutName1.TabIndex = 166
        Me.lblPutName1.Text = "PUT"
        Me.lblPutName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCallName1
        '
        Me.lblCallName1.Location = New System.Drawing.Point(145, 7)
        Me.lblCallName1.Name = "lblCallName1"
        Me.lblCallName1.Size = New System.Drawing.Size(60, 12)
        Me.lblCallName1.TabIndex = 165
        Me.lblCallName1.Text = "CALL"
        Me.lblCallName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tbAskPriceMinPut1
        '
        Me.tbAskPriceMinPut1.Location = New System.Drawing.Point(210, 232)
        Me.tbAskPriceMinPut1.Name = "tbAskPriceMinPut1"
        Me.tbAskPriceMinPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMinPut1.TabIndex = 186
        Me.tbAskPriceMinPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidPriceMaxPut1
        '
        Me.tbBidPriceMaxPut1.Location = New System.Drawing.Point(210, 253)
        Me.tbBidPriceMaxPut1.Name = "tbBidPriceMaxPut1"
        Me.tbBidPriceMaxPut1.ReadOnly = True
        Me.tbBidPriceMaxPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMaxPut1.TabIndex = 189
        Me.tbBidPriceMaxPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolSpreadPut1
        '
        Me.tbVolSpreadPut1.Location = New System.Drawing.Point(210, 127)
        Me.tbVolSpreadPut1.Name = "tbVolSpreadPut1"
        Me.tbVolSpreadPut1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSpreadPut1.TabIndex = 181
        Me.tbVolSpreadPut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolRatio2Put1
        '
        Me.tbVolRatio2Put1.Location = New System.Drawing.Point(210, 64)
        Me.tbVolRatio2Put1.Name = "tbVolRatio2Put1"
        Me.tbVolRatio2Put1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio2Put1.TabIndex = 173
        Me.tbVolRatio2Put1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolRatio1Put1
        '
        Me.tbVolRatio1Put1.Location = New System.Drawing.Point(210, 22)
        Me.tbVolRatio1Put1.Name = "tbVolRatio1Put1"
        Me.tbVolRatio1Put1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio1Put1.TabIndex = 169
        Me.tbVolRatio1Put1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBidFeeRateCall1
        '
        Me.tbBidFeeRateCall1.Location = New System.Drawing.Point(149, 190)
        Me.tbBidFeeRateCall1.Name = "tbBidFeeRateCall1"
        Me.tbBidFeeRateCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbBidFeeRateCall1.TabIndex = 182
        Me.tbBidFeeRateCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(11, 193)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(91, 12)
        Me.Label21.TabIndex = 180
        Me.Label21.Text = "清算価格リスク(%)"
        '
        'tbAskPriceMinCall1
        '
        Me.tbAskPriceMinCall1.Location = New System.Drawing.Point(149, 232)
        Me.tbAskPriceMinCall1.Name = "tbAskPriceMinCall1"
        Me.tbAskPriceMinCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbAskPriceMinCall1.TabIndex = 185
        Me.tbAskPriceMinCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(11, 235)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(77, 12)
        Me.Label20.TabIndex = 184
        Me.Label20.Text = "最低購入価格"
        '
        'tbBidPriceMaxCall1
        '
        Me.tbBidPriceMaxCall1.Location = New System.Drawing.Point(149, 253)
        Me.tbBidPriceMaxCall1.Name = "tbBidPriceMaxCall1"
        Me.tbBidPriceMaxCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbBidPriceMaxCall1.TabIndex = 188
        Me.tbBidPriceMaxCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(11, 256)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(77, 12)
        Me.Label19.TabIndex = 187
        Me.Label19.Text = "最高清算価格"
        '
        'tbVolSpreadCall1
        '
        Me.tbVolSpreadCall1.Location = New System.Drawing.Point(149, 127)
        Me.tbVolSpreadCall1.Name = "tbVolSpreadCall1"
        Me.tbVolSpreadCall1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolSpreadCall1.TabIndex = 179
        Me.tbVolSpreadCall1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(10, 132)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(105, 12)
        Me.Label18.TabIndex = 175
        Me.Label18.Text = "ボラティリティスプレッド"
        '
        'tbVolRatio2Call1
        '
        Me.tbVolRatio2Call1.Location = New System.Drawing.Point(149, 64)
        Me.tbVolRatio2Call1.Name = "tbVolRatio2Call1"
        Me.tbVolRatio2Call1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio2Call1.TabIndex = 172
        Me.tbVolRatio2Call1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 68)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(98, 12)
        Me.Label15.TabIndex = 171
        Me.Label15.Text = "ボラティリティレシオ２"
        '
        'tbVolRatio1Call1
        '
        Me.tbVolRatio1Call1.Location = New System.Drawing.Point(149, 22)
        Me.tbVolRatio1Call1.Name = "tbVolRatio1Call1"
        Me.tbVolRatio1Call1.Size = New System.Drawing.Size(50, 19)
        Me.tbVolRatio1Call1.TabIndex = 168
        Me.tbVolRatio1Call1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(10, 26)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 12)
        Me.Label14.TabIndex = 167
        Me.Label14.Text = "ボラティリティレシオ１"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.chkPutBidLow)
        Me.Panel1.Controls.Add(Me.chkPutBidHigh)
        Me.Panel1.Controls.Add(Me.chkPutAskLow)
        Me.Panel1.Controls.Add(Me.chkPutAskHigh)
        Me.Panel1.Controls.Add(Me.chkCallBidLow)
        Me.Panel1.Controls.Add(Me.chkCallBidHigh)
        Me.Panel1.Controls.Add(Me.chkCallAskLow)
        Me.Panel1.Controls.Add(Me.chkCallAskHigh)
        Me.Panel1.Controls.Add(Me.chkVolatility)
        Me.Panel1.Controls.Add(Me.chkSettingMulti)
        Me.Panel1.Controls.Add(Me.chkChart9)
        Me.Panel1.Controls.Add(Me.nudExercPrice9)
        Me.Panel1.Controls.Add(Me.chkChart8)
        Me.Panel1.Controls.Add(Me.nudExercPrice8)
        Me.Panel1.Controls.Add(Me.chkChart7)
        Me.Panel1.Controls.Add(Me.nudExercPrice7)
        Me.Panel1.Controls.Add(Me.chkChart6)
        Me.Panel1.Controls.Add(Me.nudExercPrice6)
        Me.Panel1.Controls.Add(Me.chkChart5)
        Me.Panel1.Controls.Add(Me.nudExercPrice5)
        Me.Panel1.Controls.Add(Me.chkChart4)
        Me.Panel1.Controls.Add(Me.nudExercPrice4)
        Me.Panel1.Controls.Add(Me.chkChart3)
        Me.Panel1.Controls.Add(Me.nudExercPrice3)
        Me.Panel1.Controls.Add(Me.chkChart2)
        Me.Panel1.Controls.Add(Me.nudExercPrice2)
        Me.Panel1.Controls.Add(Me.chkChart1)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btnRateChart)
        Me.Panel1.Controls.Add(Me.nudTerm)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.btnCalc)
        Me.Panel1.Controls.Add(Me.dtpExercTime)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.btnRate)
        Me.Panel1.Controls.Add(Me.nudExercPrice1)
        Me.Panel1.Controls.Add(Me.tabSetting)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(289, 705)
        Me.Panel1.TabIndex = 20
        '
        'chkPutBidLow
        '
        Me.chkPutBidLow.AutoSize = True
        Me.chkPutBidLow.Location = New System.Drawing.Point(162, 247)
        Me.chkPutBidLow.Name = "chkPutBidLow"
        Me.chkPutBidLow.Size = New System.Drawing.Size(85, 16)
        Me.chkPutBidLow.TabIndex = 261
        Me.chkPutBidLow.Text = "Put清算Low"
        Me.chkPutBidLow.UseVisualStyleBackColor = True
        '
        'chkPutBidHigh
        '
        Me.chkPutBidHigh.AutoSize = True
        Me.chkPutBidHigh.Location = New System.Drawing.Point(162, 228)
        Me.chkPutBidHigh.Name = "chkPutBidHigh"
        Me.chkPutBidHigh.Size = New System.Drawing.Size(88, 16)
        Me.chkPutBidHigh.TabIndex = 260
        Me.chkPutBidHigh.Text = "Put清算High"
        Me.chkPutBidHigh.UseVisualStyleBackColor = True
        '
        'chkPutAskLow
        '
        Me.chkPutAskLow.AutoSize = True
        Me.chkPutAskLow.Location = New System.Drawing.Point(162, 209)
        Me.chkPutAskLow.Name = "chkPutAskLow"
        Me.chkPutAskLow.Size = New System.Drawing.Size(85, 16)
        Me.chkPutAskLow.TabIndex = 259
        Me.chkPutAskLow.Text = "Put購入Low"
        Me.chkPutAskLow.UseVisualStyleBackColor = True
        '
        'chkPutAskHigh
        '
        Me.chkPutAskHigh.AutoSize = True
        Me.chkPutAskHigh.Location = New System.Drawing.Point(162, 190)
        Me.chkPutAskHigh.Name = "chkPutAskHigh"
        Me.chkPutAskHigh.Size = New System.Drawing.Size(88, 16)
        Me.chkPutAskHigh.TabIndex = 258
        Me.chkPutAskHigh.Text = "Put購入High"
        Me.chkPutAskHigh.UseVisualStyleBackColor = True
        '
        'chkCallBidLow
        '
        Me.chkCallBidLow.AutoSize = True
        Me.chkCallBidLow.Location = New System.Drawing.Point(162, 171)
        Me.chkCallBidLow.Name = "chkCallBidLow"
        Me.chkCallBidLow.Size = New System.Drawing.Size(88, 16)
        Me.chkCallBidLow.TabIndex = 257
        Me.chkCallBidLow.Text = "Call清算Low"
        Me.chkCallBidLow.UseVisualStyleBackColor = True
        '
        'chkCallBidHigh
        '
        Me.chkCallBidHigh.AutoSize = True
        Me.chkCallBidHigh.Location = New System.Drawing.Point(162, 152)
        Me.chkCallBidHigh.Name = "chkCallBidHigh"
        Me.chkCallBidHigh.Size = New System.Drawing.Size(91, 16)
        Me.chkCallBidHigh.TabIndex = 256
        Me.chkCallBidHigh.Text = "Call清算High"
        Me.chkCallBidHigh.UseVisualStyleBackColor = True
        '
        'chkCallAskLow
        '
        Me.chkCallAskLow.AutoSize = True
        Me.chkCallAskLow.Location = New System.Drawing.Point(162, 133)
        Me.chkCallAskLow.Name = "chkCallAskLow"
        Me.chkCallAskLow.Size = New System.Drawing.Size(88, 16)
        Me.chkCallAskLow.TabIndex = 255
        Me.chkCallAskLow.Text = "Call購入Low"
        Me.chkCallAskLow.UseVisualStyleBackColor = True
        '
        'chkCallAskHigh
        '
        Me.chkCallAskHigh.AutoSize = True
        Me.chkCallAskHigh.Location = New System.Drawing.Point(162, 114)
        Me.chkCallAskHigh.Name = "chkCallAskHigh"
        Me.chkCallAskHigh.Size = New System.Drawing.Size(91, 16)
        Me.chkCallAskHigh.TabIndex = 254
        Me.chkCallAskHigh.Text = "Call購入High"
        Me.chkCallAskHigh.UseVisualStyleBackColor = True
        '
        'chkVolatility
        '
        Me.chkVolatility.AutoSize = True
        Me.chkVolatility.Location = New System.Drawing.Point(179, 58)
        Me.chkVolatility.Name = "chkVolatility"
        Me.chkVolatility.Size = New System.Drawing.Size(105, 16)
        Me.chkVolatility.TabIndex = 253
        Me.chkVolatility.Text = "評価ボラティリティ"
        Me.chkVolatility.UseVisualStyleBackColor = True
        '
        'chkSettingMulti
        '
        Me.chkSettingMulti.AutoSize = True
        Me.chkSettingMulti.Enabled = False
        Me.chkSettingMulti.Location = New System.Drawing.Point(13, 295)
        Me.chkSettingMulti.Name = "chkSettingMulti"
        Me.chkSettingMulti.Size = New System.Drawing.Size(124, 16)
        Me.chkSettingMulti.TabIndex = 252
        Me.chkSettingMulti.Text = "個別設定を使用する"
        Me.chkSettingMulti.UseVisualStyleBackColor = True
        '
        'chkChart9
        '
        Me.chkChart9.AutoSize = True
        Me.chkChart9.Location = New System.Drawing.Point(13, 266)
        Me.chkChart9.Name = "chkChart9"
        Me.chkChart9.Size = New System.Drawing.Size(65, 16)
        Me.chkChart9.TabIndex = 251
        Me.chkChart9.Text = "チャート9"
        Me.chkChart9.UseVisualStyleBackColor = True
        '
        'nudExercPrice9
        '
        Me.nudExercPrice9.DecimalPlaces = 3
        Me.nudExercPrice9.Location = New System.Drawing.Point(84, 265)
        Me.nudExercPrice9.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice9.Name = "nudExercPrice9"
        Me.nudExercPrice9.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice9.TabIndex = 250
        Me.nudExercPrice9.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart8
        '
        Me.chkChart8.AutoSize = True
        Me.chkChart8.Location = New System.Drawing.Point(13, 247)
        Me.chkChart8.Name = "chkChart8"
        Me.chkChart8.Size = New System.Drawing.Size(65, 16)
        Me.chkChart8.TabIndex = 249
        Me.chkChart8.Text = "チャート8"
        Me.chkChart8.UseVisualStyleBackColor = True
        '
        'nudExercPrice8
        '
        Me.nudExercPrice8.DecimalPlaces = 3
        Me.nudExercPrice8.Location = New System.Drawing.Point(84, 246)
        Me.nudExercPrice8.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice8.Name = "nudExercPrice8"
        Me.nudExercPrice8.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice8.TabIndex = 248
        Me.nudExercPrice8.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart7
        '
        Me.chkChart7.AutoSize = True
        Me.chkChart7.Location = New System.Drawing.Point(13, 228)
        Me.chkChart7.Name = "chkChart7"
        Me.chkChart7.Size = New System.Drawing.Size(65, 16)
        Me.chkChart7.TabIndex = 247
        Me.chkChart7.Text = "チャート7"
        Me.chkChart7.UseVisualStyleBackColor = True
        '
        'nudExercPrice7
        '
        Me.nudExercPrice7.DecimalPlaces = 3
        Me.nudExercPrice7.Location = New System.Drawing.Point(84, 227)
        Me.nudExercPrice7.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice7.Name = "nudExercPrice7"
        Me.nudExercPrice7.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice7.TabIndex = 246
        Me.nudExercPrice7.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart6
        '
        Me.chkChart6.AutoSize = True
        Me.chkChart6.Location = New System.Drawing.Point(13, 209)
        Me.chkChart6.Name = "chkChart6"
        Me.chkChart6.Size = New System.Drawing.Size(65, 16)
        Me.chkChart6.TabIndex = 245
        Me.chkChart6.Text = "チャート6"
        Me.chkChart6.UseVisualStyleBackColor = True
        '
        'nudExercPrice6
        '
        Me.nudExercPrice6.DecimalPlaces = 3
        Me.nudExercPrice6.Location = New System.Drawing.Point(84, 208)
        Me.nudExercPrice6.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice6.Name = "nudExercPrice6"
        Me.nudExercPrice6.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice6.TabIndex = 244
        Me.nudExercPrice6.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart5
        '
        Me.chkChart5.AutoSize = True
        Me.chkChart5.Location = New System.Drawing.Point(13, 190)
        Me.chkChart5.Name = "chkChart5"
        Me.chkChart5.Size = New System.Drawing.Size(65, 16)
        Me.chkChart5.TabIndex = 243
        Me.chkChart5.Text = "チャート5"
        Me.chkChart5.UseVisualStyleBackColor = True
        '
        'nudExercPrice5
        '
        Me.nudExercPrice5.DecimalPlaces = 3
        Me.nudExercPrice5.Location = New System.Drawing.Point(84, 189)
        Me.nudExercPrice5.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice5.Name = "nudExercPrice5"
        Me.nudExercPrice5.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice5.TabIndex = 242
        Me.nudExercPrice5.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart4
        '
        Me.chkChart4.AutoSize = True
        Me.chkChart4.Location = New System.Drawing.Point(13, 171)
        Me.chkChart4.Name = "chkChart4"
        Me.chkChart4.Size = New System.Drawing.Size(65, 16)
        Me.chkChart4.TabIndex = 241
        Me.chkChart4.Text = "チャート4"
        Me.chkChart4.UseVisualStyleBackColor = True
        '
        'nudExercPrice4
        '
        Me.nudExercPrice4.DecimalPlaces = 3
        Me.nudExercPrice4.Location = New System.Drawing.Point(84, 170)
        Me.nudExercPrice4.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice4.Name = "nudExercPrice4"
        Me.nudExercPrice4.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice4.TabIndex = 240
        Me.nudExercPrice4.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart3
        '
        Me.chkChart3.AutoSize = True
        Me.chkChart3.Location = New System.Drawing.Point(13, 152)
        Me.chkChart3.Name = "chkChart3"
        Me.chkChart3.Size = New System.Drawing.Size(65, 16)
        Me.chkChart3.TabIndex = 239
        Me.chkChart3.Text = "チャート3"
        Me.chkChart3.UseVisualStyleBackColor = True
        '
        'nudExercPrice3
        '
        Me.nudExercPrice3.DecimalPlaces = 3
        Me.nudExercPrice3.Location = New System.Drawing.Point(84, 151)
        Me.nudExercPrice3.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice3.Name = "nudExercPrice3"
        Me.nudExercPrice3.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice3.TabIndex = 238
        Me.nudExercPrice3.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart2
        '
        Me.chkChart2.AutoSize = True
        Me.chkChart2.Location = New System.Drawing.Point(13, 133)
        Me.chkChart2.Name = "chkChart2"
        Me.chkChart2.Size = New System.Drawing.Size(65, 16)
        Me.chkChart2.TabIndex = 237
        Me.chkChart2.Text = "チャート2"
        Me.chkChart2.UseVisualStyleBackColor = True
        '
        'nudExercPrice2
        '
        Me.nudExercPrice2.DecimalPlaces = 3
        Me.nudExercPrice2.Location = New System.Drawing.Point(84, 132)
        Me.nudExercPrice2.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice2.Name = "nudExercPrice2"
        Me.nudExercPrice2.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice2.TabIndex = 236
        Me.nudExercPrice2.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'chkChart1
        '
        Me.chkChart1.AutoSize = True
        Me.chkChart1.Location = New System.Drawing.Point(13, 114)
        Me.chkChart1.Name = "chkChart1"
        Me.chkChart1.Size = New System.Drawing.Size(65, 16)
        Me.chkChart1.TabIndex = 235
        Me.chkChart1.Text = "チャート1"
        Me.chkChart1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 12)
        Me.Label3.TabIndex = 234
        Me.Label3.Text = "行使価格"
        '
        'btnRateChart
        '
        Me.btnRateChart.Location = New System.Drawing.Point(9, 51)
        Me.btnRateChart.Name = "btnRateChart"
        Me.btnRateChart.Size = New System.Drawing.Size(78, 29)
        Me.btnRateChart.TabIndex = 232
        Me.btnRateChart.Text = "データ取得"
        Me.btnRateChart.UseVisualStyleBackColor = True
        '
        'nudTerm
        '
        Me.nudTerm.Location = New System.Drawing.Point(228, 29)
        Me.nudTerm.Maximum = New Decimal(New Integer() {24, 0, 0, 0})
        Me.nudTerm.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudTerm.Name = "nudTerm"
        Me.nudTerm.Size = New System.Drawing.Size(46, 19)
        Me.nudTerm.TabIndex = 231
        Me.nudTerm.Value = New Decimal(New Integer() {2, 0, 0, 0})
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(198, 32)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 12)
        Me.Label8.TabIndex = 229
        Me.Label8.Text = "期間"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(95, 51)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(78, 29)
        Me.btnCalc.TabIndex = 228
        Me.btnCalc.Text = "再計算"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'dtpExercTime
        '
        Me.dtpExercTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpExercTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercTime.Location = New System.Drawing.Point(68, 29)
        Me.dtpExercTime.Name = "dtpExercTime"
        Me.dtpExercTime.ShowUpDown = True
        Me.dtpExercTime.Size = New System.Drawing.Size(113, 19)
        Me.dtpExercTime.TabIndex = 227
        Me.dtpExercTime.Value = New Date(2013, 9, 26, 2, 0, 0, 0)
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 226
        Me.Label5.Text = "行使期日"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(63, 5)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(131, 20)
        Me.cbComCode.TabIndex = 225
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 224
        Me.Label2.Text = "通貨ペア"
        '
        'btnRate
        '
        Me.btnRate.Location = New System.Drawing.Point(76, 85)
        Me.btnRate.Name = "btnRate"
        Me.btnRate.Size = New System.Drawing.Size(105, 23)
        Me.btnRate.TabIndex = 230
        Me.btnRate.Text = "現在レート反映"
        Me.btnRate.UseVisualStyleBackColor = True
        '
        'nudExercPrice1
        '
        Me.nudExercPrice1.DecimalPlaces = 3
        Me.nudExercPrice1.Location = New System.Drawing.Point(84, 113)
        Me.nudExercPrice1.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.nudExercPrice1.Name = "nudExercPrice1"
        Me.nudExercPrice1.Size = New System.Drawing.Size(61, 19)
        Me.nudExercPrice1.TabIndex = 233
        Me.nudExercPrice1.Value = New Decimal(New Integer() {100001, 0, 0, 196608})
        '
        'PricingSim2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(942, 705)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "PricingSim2"
        Me.Text = "プライシングシミュレータ２"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.chartRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chartPrice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tabSetting.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.nudExercPrice9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTerm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudExercPrice1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents chartRate As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents chartPrice As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents chkPutBidLowView As System.Windows.Forms.CheckBox
    Friend WithEvents chkPutBidHighView As System.Windows.Forms.CheckBox
    Friend WithEvents chkPutAskLowView As System.Windows.Forms.CheckBox
    Friend WithEvents chkPutAskHighView As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallBidLowView As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallBidHighView As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallAskLowView As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallAskHighView As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView9 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView8 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView7 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView6 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView5 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView4 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView3 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkChartView1 As System.Windows.Forms.CheckBox
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbColorPrice As System.Windows.Forms.RadioButton
    Friend WithEvents rbColorType As System.Windows.Forms.RadioButton
    Friend WithEvents tabSetting As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents tbSwapRate1 As System.Windows.Forms.TextBox
    Friend WithEvents tbInterestRate1 As System.Windows.Forms.TextBox
    Friend WithEvents tbHV1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbVolSmileBPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSmileAPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSmileBCall1 As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSmileACall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents tbCallPutSpread1 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tbBidFeeRatePut1 As System.Windows.Forms.TextBox
    Friend WithEvents lblPutName1 As System.Windows.Forms.Label
    Friend WithEvents lblCallName1 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMinPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMaxPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbVolSpreadPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbVolRatio2Put1 As System.Windows.Forms.TextBox
    Friend WithEvents tbVolRatio1Put1 As System.Windows.Forms.TextBox
    Friend WithEvents tbBidFeeRateCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMinCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents tbBidPriceMaxCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents tbVolSpreadCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio2Call1 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents tbVolRatio1Call1 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chkPutBidLow As System.Windows.Forms.CheckBox
    Friend WithEvents chkPutBidHigh As System.Windows.Forms.CheckBox
    Friend WithEvents chkPutAskLow As System.Windows.Forms.CheckBox
    Friend WithEvents chkPutAskHigh As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallBidLow As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallBidHigh As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallAskLow As System.Windows.Forms.CheckBox
    Friend WithEvents chkCallAskHigh As System.Windows.Forms.CheckBox
    Friend WithEvents chkVolatility As System.Windows.Forms.CheckBox
    Friend WithEvents chkSettingMulti As System.Windows.Forms.CheckBox
    Friend WithEvents chkChart9 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice9 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart8 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice8 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart7 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart6 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice6 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart5 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice5 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart4 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart3 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart2 As System.Windows.Forms.CheckBox
    Friend WithEvents nudExercPrice2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkChart1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnRateChart As System.Windows.Forms.Button
    Friend WithEvents nudTerm As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnCalc As System.Windows.Forms.Button
    Friend WithEvents dtpExercTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnRate As System.Windows.Forms.Button
    Friend WithEvents nudExercPrice1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents tbAskBidSpreadMinPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbAskBidSpreadMinCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbAskFeePricePut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbAskFeePriceCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tbAskPriceMaxPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbAskPriceMaxCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tbBidPriceMinPut1 As System.Windows.Forms.TextBox
    Friend WithEvents tbBidPriceMinCall1 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
