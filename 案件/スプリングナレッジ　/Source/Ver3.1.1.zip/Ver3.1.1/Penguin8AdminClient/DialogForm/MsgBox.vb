﻿Public Class MsgBox

    Public Property Message As String
    Public Property RunVisible As Boolean = True
    Public Property CancelName As String
    Public Property ExitVisible As Boolean = False

    Public ApplicationExit As Boolean = False

    Private Sub MsgBox_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If CancelName IsNot Nothing Then btnCancel.Text = CancelName
        btnOK.Visible = RunVisible
        lblMessage.Text = Message
        btnExit.Visible = ExitVisible
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        ApplicationExit = True
        Me.Close()
    End Sub
End Class