﻿Public Class ProductSubEnabled

    Public Property Code As String

    Private WithEvents service As ProductSubListService

    Private Enum FormMode
        INIT = 0
        RUN = 1
        RESULT = 2
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        service = New ProductSubListService
        service.SetStatus(Code, True)
        FormModeStatus = FormMode.RUN
        btnOK.Enabled = False
    End Sub

    Private Sub service_SetStatusCancel() Handles service.SetStatusCancel
        lblMessage.Text = "有効化処理をキャンセルしましたが、サーバー側では処理が完了している可能性があります。"
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_SetStatusError(ErrorMessage As String) Handles service.SetStatusError
        lblMessage.Text = ErrorMessage
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_SetStatusSuccess() Handles service.SetStatusSuccess
        lblMessage.Text = "銘柄詳細を有効化しました。"
        FormModeStatus = FormMode.RESULT
        btnCancel.Text = "閉じる"
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.INIT, FormMode.RESULT
                Me.Close()
            Case FormMode.RUN
                service.CancelSetStatus()
        End Select
    End Sub
End Class
