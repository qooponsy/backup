﻿Public Class SystemStop

    Private WithEvents service As SysStatusService
    Private WithEvents serviceTradeNow As TradeNowService

    Private Enum FormMode
        INIT = 0
        RUN = 1
        RESULT = 2
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub SystemStop_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        SetTargetCount()
        serviceTradeNow = New TradeNowService
    End Sub

    Private Sub SystemStop_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        service = Nothing
        serviceTradeNow = Nothing
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        service = New SysStatusService
        SysStatusService.SystemStop()
        FormModeStatus = FormMode.RUN
        btnOK.Enabled = False
    End Sub

    Private Sub service_SetStatusCancel() Handles service.RegistCancel
        lblMessage.Text = "システム停止処理をキャンセルしましたが、サーバー側では処理が完了している可能性があります。"
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_SetStatusError(ErrorMessage As String) Handles service.RegistError
        lblMessage.Text = ErrorMessage
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_SetStatusSuccess() Handles service.RegistSuccess
        lblMessage.Text = "システムを停止ました。"
        FormModeStatus = FormMode.RESULT
        btnCancel.Text = "閉じる"
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.INIT, FormMode.RESULT
                Me.Close()
            Case FormMode.RUN
                SysStatusService.CancelRegist()
        End Select
    End Sub

    Private Sub SetTargetCount()
        lblTarget.Text = String.Format("取引中取引件数：{0} 件", TradeNowService.DataList.Count)
    End Sub

    Private Sub serviceTradeNow_DataChanged() Handles serviceTradeNow.DataChanged
        SetTargetCount()
    End Sub

End Class