﻿Imports System.Text

Public Class LadderOption

    Public Const CALL_TYPE As String = "01"
    Public Const PUT_TYPE As String = "02"

    Public Const LotAmount As Decimal = 1000

    Public Const MAX_PRICE As Decimal = 1000

    Public Shared Function buildExercPriceSettings(Unit As Decimal, Count As Integer, DecimalPlaces As Integer) As String
        Dim plus As New StringBuilder
        Dim minus As New StringBuilder
        Dim delimiter As String = ""
        Dim format As String = clsUtil.GetRateDPFormat(DecimalPlaces)
        For fa As Integer = 1 To Count
            plus.Append(delimiter)
            plus.Append("+")
            plus.Append((Unit * fa).ToString(format))
            minus.Append(delimiter)
            minus.Append("-")
            minus.Append((Unit * fa).ToString(format))
            delimiter = ","
        Next
        Return plus.ToString() + vbCrLf + "0" + vbCrLf + minus.ToString()
    End Function

    Public PriceUnit As Decimal = 1

    Public InterestRate As Decimal              '短期金利
    Public SwapRate As Decimal                  'スワップ金利
    Public HistVol As Decimal                   'ヒストリカルボラティリティ

    Public ExercTime As DateTime                '行使期日
    Public ExercPrice As Decimal                '行使価格

    Public VolatilityRatio1Call As Decimal      'ボラティリティレシオ１CALL
    Public VolatilityRatio1Put As Decimal       'ボラティリティレシオ１PUT
    Public VolatilitySpread As Decimal          'ボラティリティスプレッド
    Public VolatilityRatio2Call As Decimal      'ボラティリティレシオ２CALL
    Public VolatilityRatio2Put As Decimal       'ボラティリティレシオ２PUT
    Public VolatilitySmileACall As Decimal      'ボラティリティスマイルａCALL
    Public VolatilitySmileAPut As Decimal       'ボラティリティスマイルａPUT
    Public VolatilitySmileBCall As Decimal      'ボラティリティスマイルｂCALL
    Public VolatilitySmileBPut As Decimal       'ボラティリティスマイルｂPUT
    Public VolatilitySpreadITMCall As Decimal   'ボラティリティスプレッドITM CALL
    Public VolatilitySpreadOTMCall As Decimal   'ボラティリティスプレッドOTM CALL
    Public VolatilitySpreadITMPut As Decimal    'ボラティリティスプレッドITM PUT
    Public VolatilitySpreadOTMPut As Decimal    'ボラティリティスプレッドOTM PUT

    Public AskFeePriceCall As Decimal           '購入価格リスク(CALL)
    Public AskFeePricePut As Decimal            '購入価格リスク(PUT)
    Public AskBidSpreadMinCall As Decimal       '最小購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ
    Public AskBidSpreadMinPut As Decimal        '最小購入清算価格ｽﾌﾟﾚｯﾄﾞﾘｽｸ
    Public BidFeeRateCall As Decimal            '清算価格リスク(%)CALL
    Public BidFeeRatePut As Decimal             '清算価格リスク(%)PUT
    Public AskPriceMaxCall As Decimal           '最高購入価格CALL
    Public AskPriceMinCall As Decimal           '最低購入価格CALL
    Public BidPriceMaxCall As Decimal           '最高清算価格CALL
    Public BidPriceMinCall As Decimal           '最低清算価格CALL
    Public AskPriceMaxPut As Decimal            '最高購入価格PUT
    Public AskPriceMinPut As Decimal            '最低購入価格PUT
    Public BidPriceMaxPut As Decimal            '最高清算価格PUT
    Public BidPriceMinPut As Decimal            '最低清算価格PUT

    Public CalcTime As DateTime                 '計算時刻
    Public Rate As Decimal                      '現在レート

    Public VolAskCall As Decimal                '評価ボラティリティCALL購入
    Public VolBidCall As Decimal                '評価ボラティリティCALL清算
    Public VolAskPut As Decimal                 '評価ボラティリティPUT購入
    Public VolBidPut As Decimal                 '評価ボラティリティPUT清算

    Public AskCall As Decimal                   '時価CALL購入
    Public BidCall As Decimal                   '時価CALL清算
    Public AskPut As Decimal                    '時価PUT購入
    Public BidPut As Decimal                    '時価PUT清算

    ''' <summary>
    ''' 評価ボラティリティ算出
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalcVolatility()
        Dim SmileX As Decimal = (ExercPrice - Rate) / Rate
        Dim VolATMCall As Decimal = HistVol * VolatilityRatio1Call
        Dim SmileCall As Decimal = VolatilityRatio2Call * (VolatilitySmileACall * SmileX * SmileX + VolatilitySmileBCall * SmileX)
        Dim VolATMPut As Decimal = HistVol * VolatilityRatio1Put + VolatilitySpread
        Dim SmilePut As Decimal = VolatilityRatio2Put * (VolatilitySmileAPut * SmileX * SmileX + VolatilitySmileBPut * SmileX)
        VolAskCall = VolATMCall + SmileCall
        VolBidCall = VolAskCall + If(ExercPrice <= Rate, VolatilitySpreadITMCall, 0) - If(ExercPrice > Rate, VolatilitySpreadOTMCall, 0)
        VolAskPut = VolATMPut + SmilePut
        VolBidPut = VolAskPut + If(ExercPrice >= Rate, VolatilitySpreadITMPut, 0) - If(ExercPrice < Rate, VolatilitySpreadOTMPut, 0)
    End Sub

    ''' <summary>
    ''' 時価算出CALL購入
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalcPriceAskCall()
        Dim CalcType As String = CALL_TYPE
        Dim Volatility As Decimal = VolAskCall
        Dim FeePrice As Decimal = AskFeePriceCall
        Dim FeeRate As Decimal = +0
        Dim MaxPrice As Decimal = AskPriceMaxCall
        Dim MinPrice As Decimal = AskPriceMinCall

        Dim Value1 As Double
        Dim Value2 As Decimal
        Value1 = RiskCalc.Premium(LotAmount / PriceUnit, 0, CalcType, Rate, ExercPrice, InterestRate, SwapRate, Volatility, CalcTime, ExercTime)
        Value1 = Value1 * (1 + FeeRate)
        Value2 = Math.Round(Value1) * PriceUnit
        Value2 = Value2 + FeePrice
        Value2 = Math.Min(Value2, MaxPrice)
        Value2 = Math.Max(Value2, MinPrice)

        AskCall = Value2
    End Sub

    ''' <summary>
    ''' 時価算出CALL購入/清算
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalcPriceCall()
        CalcPriceAskCall()

        Dim CalcType As String = CALL_TYPE
        Dim volatility As Decimal = VolBidCall
        Dim FeePrice As Decimal = -0
        Dim FeeRate As Decimal = -BidFeeRateCall
        Dim MaxPrice As Decimal = Math.Min(BidPriceMaxCall, AskCall - AskBidSpreadMinCall)
        Dim MinPrice As Decimal = BidPriceMinCall

        Dim Value1 As Double
        Dim Value2 As Decimal
        Value1 = RiskCalc.Premium(LotAmount / PriceUnit, 0, CalcType, Rate, ExercPrice, InterestRate, SwapRate, Volatility, CalcTime, ExercTime)
        Value1 = Value1 * (1 + FeeRate)
        Value2 = Math.Round(Value1) * PriceUnit
        Value2 = Value2 + FeePrice
        Value2 = Math.Min(Value2, MaxPrice)
        Value2 = Math.Max(Value2, MinPrice)

        BidCall = Value2
    End Sub

    ''' <summary>
    ''' 時価算出PUT購入
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalcPriceAskPut()
        Dim CalcType As String = PUT_TYPE
        Dim Volatility As Decimal = VolAskPut
        Dim FeePrice As Decimal = AskFeePricePut
        Dim FeeRate As Decimal = +0
        Dim MaxPrice As Decimal = AskPriceMaxPut
        Dim MinPrice As Decimal = AskPriceMinPut

        Dim Value1 As Double
        Dim Value2 As Decimal
        Value1 = RiskCalc.Premium(LotAmount / PriceUnit, 0, CalcType, Rate, ExercPrice, InterestRate, SwapRate, Volatility, CalcTime, ExercTime)
        Value1 = Value1 * (1 + FeeRate)
        Value2 = Math.Round(Value1) * PriceUnit
        Value2 = Value2 + FeePrice
        Value2 = Math.Min(Value2, MaxPrice)
        Value2 = Math.Max(Value2, MinPrice)

        AskPut = Value2
    End Sub

    ''' <summary>
    ''' 時価算出PUT清算
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CalcPricePut()
        CalcPriceAskPut()

        Dim CalcType As String = PUT_TYPE
        Dim volatility As Decimal = VolBidPut
        Dim FeePrice As Decimal = -0
        Dim FeeRate As Decimal = -BidFeeRatePut
        Dim MaxPrice As Decimal = Math.Min(BidPriceMaxPut, AskPut - AskBidSpreadMinPut)
        Dim MinPrice As Decimal = BidPriceMinPut

        Dim Value1 As Double
        Dim Value2 As Decimal
        Value1 = RiskCalc.Premium(LotAmount / PriceUnit, 0, CalcType, Rate, ExercPrice, InterestRate, SwapRate, volatility, CalcTime, ExercTime)
        Value1 = Value1 * (1 + FeeRate)
        Value2 = Math.Round(Value1) * PriceUnit
        Value2 = Value2 + FeePrice
        Value2 = Math.Min(Value2, MaxPrice)
        Value2 = Math.Max(Value2, MinPrice)

        BidPut = Value2
    End Sub

    ''' <summary>
    ''' 時価算出　CALL購入/清算　PUT購入/清算 
    ''' 
    ''' 　①Call清算価格=[Max(最低清算価格,Min(最高清算価格,理論価格))]      
    ''' 　　※価格の単位合わせを行う。現行は10円単位であるが、これを１円単位に変更する。
    ''' 　②Put清算価格=1000-Call清算価格
    ''' 　③Call購入価格=Min(最高購入価格,Max(最低購入価格,Call清算価格+購入清算価格スプレッドリスク))
    ''' 　④Put購入価格=Min(最高購入価格,Max(最低購入価格,Put清算価格+購入清算価格スプレッドリスク
    ''' </summary>
    Public Sub CalcPrice()

        Dim Value1 As Double
        Dim Value2 As Decimal

        ' CALL清算価格算出
        Dim CalcType As String = CALL_TYPE
        Dim volatility As Decimal = VolBidCall
        Dim FeePrice As Decimal = -0
        Dim FeeRate As Decimal = -BidFeeRateCall
        Dim MaxPrice As Decimal = BidPriceMaxCall
        Dim MinPrice As Decimal = BidPriceMinCall

        Value1 = RiskCalc.Premium(LotAmount / PriceUnit, 0, CalcType, Rate, ExercPrice, InterestRate, SwapRate, volatility, CalcTime, ExercTime)
        Value1 = Value1 * (1 + FeeRate)
        Value2 = Math.Round(Value1) * PriceUnit
        Value2 = Value2 + FeePrice
        Value2 = Math.Min(Value2, MaxPrice)
        Value2 = Math.Max(Value2, MinPrice)

        BidCall = Value2

        ' Put清算価格算出
        BidPut = MAX_PRICE - BidCall

        ' Call購入価格算出
        MaxPrice = AskPriceMaxCall
        MinPrice = AskPriceMinCall

        Value1 = Math.Max(MinPrice, BidCall + AskBidSpreadMinCall)
        Value2 = Math.Min(MaxPrice, Value1)

        AskCall = Value2

        ' Put購入算出
        MaxPrice = AskPriceMaxPut
        MinPrice = AskPriceMinPut

        Value1 = Math.Max(MinPrice, BidPut + AskBidSpreadMinPut)
        Value2 = Math.Min(MaxPrice, Value1)

        AskPut = Value2

    End Sub

End Class
