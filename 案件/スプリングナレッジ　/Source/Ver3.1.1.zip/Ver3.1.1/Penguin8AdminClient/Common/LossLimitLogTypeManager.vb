﻿Public Class LossLimitLogTypeManager

    Private Shared LogTypeList As New List(Of LossLimitLogTypeManager)

    Public Shared Sub Init()
        LogTypeList.Add(New LossLimitLogTypeManager With {.Code = "01", .Name = "限度枠設定"})
        LogTypeList.Add(New LossLimitLogTypeManager With {.Code = "02", .Name = "取引停止判定"})
        LogTypeList.Add(New LossLimitLogTypeManager With {.Code = "", .Name = "全て"})
    End Sub

    Public Shared Function GetLogTypeList() As List(Of LossLimitLogTypeManager)
        Return LogTypeList.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
