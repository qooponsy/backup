﻿Public Class OperationCustDataManager

    Private Shared DataTypeList As New List(Of OperationCustDataManager)
    Private Shared DataTypeListWithAll As New List(Of OperationCustDataManager)

    Private Shared LogTypeList As New List(Of OperationCustDataManager)

    Public Shared Sub Init()
        DataTypeList.Add(New OperationCustDataManager With {.DataTypeCode = "01", .DataTypeName = "ログイン"})
        DataTypeList.Add(New OperationCustDataManager With {.DataTypeCode = "02", .DataTypeName = "ログアウト"})

        DataTypeListWithAll.Add(New OperationCustDataManager With {.DataTypeCode = "", .DataTypeName = "全て"})
        DataTypeListWithAll.Add(New OperationCustDataManager With {.DataTypeCode = "01", .DataTypeName = "ログイン"})
        DataTypeListWithAll.Add(New OperationCustDataManager With {.DataTypeCode = "02", .DataTypeName = "ログアウト"})

        LogTypeList.Add(New OperationCustDataManager With {.LogTypeCode = "01", .LogTypeName = "成功"})
        LogTypeList.Add(New OperationCustDataManager With {.LogTypeCode = "02", .LogTypeName = "失敗"})

    End Sub

    Public Shared Function GetDataTypeList() As List(Of OperationCustDataManager)
        Return DataTypeList.ToList()
    End Function

    Public Shared Function GetDataTypeListWithAll() As List(Of OperationCustDataManager)
        Return DataTypeListWithAll.ToList()
    End Function

    Public Shared Function GetDataTypeName(Code As String) As String
        For Each item In DataTypeList
            If item.DataTypeCode = Code Then
                Return item.DataTypeName
            End If
        Next
        Return ""
    End Function

    Public Shared Function GetLogTypeList() As List(Of OperationCustDataManager)
        Return LogTypeList.ToList()
    End Function

    Public Shared Function GetLogTypeName(Code As String) As String
        For Each item In LogTypeList
            If item.LogTypeCode = Code Then
                Return item.LogTypeName
            End If
        Next
        Return ""
    End Function

    Public Property DataTypeCode As String
    Public Property DataTypeName As String
    Public Property LogTypeCode As String
    Public Property LogTypeName As String

End Class
