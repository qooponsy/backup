﻿Public Class RateFilterStatusManager

    Private Shared StatusList As New List(Of RateFilterStatusManager)

    Public Shared Sub Init()
        StatusList.Add(New RateFilterStatusManager With {.Code = "0", .Name = ""})
        StatusList.Add(New RateFilterStatusManager With {.Code = "1", .Name = "レートフィルター"})
        StatusList.Add(New RateFilterStatusManager With {.Code = "2", .Name = "異常レート"})
    End Sub

    Public Shared Function GetStatusName(Status As String) As String
        For Each item As RateFilterStatusManager In StatusList
            If item.Code = Status Then
                Return item.Name
            End If
        Next
        Return "不明"
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
