﻿Public Class CurrencyManager

    Public Shared List As New List(Of CurrencyManager)

    Public Shared Sub Init()
        List.Add(New CurrencyManager With {.Code = "JPY", .Name = "JPY"})
    End Sub

    Public Shared Function GetList() As List(Of CurrencyManager)
        Return List.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
