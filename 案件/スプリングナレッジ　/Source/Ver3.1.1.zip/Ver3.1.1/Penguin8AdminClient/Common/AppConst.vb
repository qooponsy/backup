﻿Public Class AppConst

    Public Const CLIENT_TYPE As String = "00"

End Class
