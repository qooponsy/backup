﻿Public Class ExercPriceUnitTypeManager

    Public Shared List As New List(Of ExercPriceUnitTypeManager)

    Public Shared Sub Init()
        List.Add(New ExercPriceUnitTypeManager With {.Code = "0", .Name = "なし"})
        List.Add(New ExercPriceUnitTypeManager With {.Code = "1", .Name = "切り上げ"})
        List.Add(New ExercPriceUnitTypeManager With {.Code = "2", .Name = "切り捨て"})
    End Sub

    Public Shared Function GetList(NoSelect As Boolean, AllSelect As Boolean) As List(Of ExercPriceUnitTypeManager)
        Dim ret As List(Of ExercPriceUnitTypeManager) = List.ToList
        If NoSelect Then ret.Insert(0, New ExercPriceUnitTypeManager With {.Code = "", .Name = ""})
        If AllSelect Then ret.Add(New ExercPriceUnitTypeManager With {.Code = "ALL", .Name = "全て"})
        Return ret
    End Function

    Public Shared Function GetName(Code As String) As String
        For Each item In List
            If item.Code = Code Then
                Return item.Name
            End If
        Next
        Return ""
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
