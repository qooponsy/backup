﻿Public Class ExercStatusManager

    Private Shared List As New List(Of ExercStatusManager)
    Private Shared ListWithAll As New List(Of ExercStatusManager)

    Public Shared Sub Init()
        List.Add(New ExercStatusManager With {.Code = "0", .Name = "未行使"})
        List.Add(New ExercStatusManager With {.Code = "1", .Name = "行使処理中"})
        List.Add(New ExercStatusManager With {.Code = "2", .Name = "行使済み"})
        List.Add(New ExercStatusManager With {.Code = "3", .Name = "行使処理失敗"})
    End Sub

    Public Shared Function GetList(NoSelect As Boolean, AllSelect As Boolean) As List(Of ExercStatusManager)
        Dim ret As List(Of ExercStatusManager) = List.ToList
        If NoSelect Then ret.Insert(0, New ExercStatusManager With {.Code = "", .Name = ""})
        If AllSelect Then ret.Add(New ExercStatusManager With {.Code = "ALL", .Name = "全て"})
        Return ret
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
