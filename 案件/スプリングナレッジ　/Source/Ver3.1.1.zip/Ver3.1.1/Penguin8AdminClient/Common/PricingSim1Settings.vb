﻿Imports System.IO
Imports System.Xml.Serialization
Imports System.Runtime.Serialization

<Serializable()> _
Public Class PricingSim1Settings

    <OptionalField()> Public FormMaximized As Boolean = False
    <OptionalField()> Public FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ComCode As String = "USDJPY"
    <OptionalField()> Public ExercPriceUnitType As String = ""
    <OptionalField()> Public AutoCalc As Boolean = False
    <OptionalField()> Public VolRatio1Call As String = "1"
    <OptionalField()> Public VolRatio1Put As String = "1"
    <OptionalField()> Public CallPutSpread As String = "0"
    <OptionalField()> Public VolRatio2Call As String = "1"
    <OptionalField()> Public VolRatio2Put As String = "1"
    <OptionalField()> Public VolSmileACall As String = "1"
    <OptionalField()> Public VolSmileAPut As String = "1"
    <OptionalField()> Public VolSmileBCall As String = "0"
    <OptionalField()> Public VolSmileBPut As String = "0"
    <OptionalField()> Public VolSpreadCall As String = "0"
    <OptionalField()> Public VolSpreadPut As String = "0"

    <OptionalField()> Public AskFeePriceCall As String = "0"
    <OptionalField()> Public AskFeePricePut As String = "0"
    <OptionalField()> Public AskBidSpreadMinCall As String = "0"
    <OptionalField()> Public AskBidSpreadMinPut As String = "0"
    <OptionalField()> Public BidFeeRateCall As String = "0"
    <OptionalField()> Public BidFeeRatePut As String = "0"
    <OptionalField()> Public AskPriceMaxCall As String = "1000"
    <OptionalField()> Public AskPriceMinCall As String = "0"
    <OptionalField()> Public BidPriceMaxCall As String = "1000"
    <OptionalField()> Public BidPriceMinCall As String = "0"
    <OptionalField()> Public AskPriceMaxPut As String = "1000"
    <OptionalField()> Public AskPriceMinPut As String = "0"
    <OptionalField()> Public BidPriceMaxPut As String = "1000"
    <OptionalField()> Public BidPriceMinPut As String = "0"

    Public Shared Function Load() As PricingSim1Settings
        Dim path As String = GetSettingPath()
        Dim obj As Object = Nothing
        Try
            Using fs As New FileStream(path, FileMode.Open, FileAccess.Read)
                Dim xs As New System.Xml.Serialization.XmlSerializer(GetType(PricingSim1Settings))
                obj = xs.Deserialize(fs)
                fs.Close()
            End Using
        Catch ex As Exception
            obj = New PricingSim1Settings
        End Try

        Return CType(obj, PricingSim1Settings)
    End Function

    Public Shared Sub Save(data As PricingSim1Settings)
        Dim path As String = GetSettingPath()

        Dim retry As Integer = 3
        Do
            retry -= 1
            Try
                Using fs As New FileStream(path, FileMode.Create, FileAccess.Write)
                    Dim xs As New System.Xml.Serialization.XmlSerializer(GetType(PricingSim1Settings))
                    xs.Serialize(fs, data)
                    fs.Close()
                End Using
                retry = 0
            Catch ex As Exception

            End Try
        Loop While retry

    End Sub

    Private Shared Function GetSettingDir() As String
        Return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            Application.CompanyName + "\" + Application.ProductName)
    End Function

    Private Shared Function GetSettingPath() As String
        If Not Directory.Exists(GetSettingDir) Then
            Directory.CreateDirectory(GetSettingDir())
        End If
        Return GetSettingDir() + "\" + "PricingSim1.config"
    End Function

End Class
