﻿Public Class ExercPriceStatusManager

    Private Shared List As New List(Of ExercPriceStatusManager)
    Private Shared ListWithAll As New List(Of ExercPriceStatusManager)

    Public Shared Sub Init()
        List.Add(New ExercPriceStatusManager With {.Code = "0", .Name = "行使価格未定"})
        List.Add(New ExercPriceStatusManager With {.Code = "1", .Name = "行使価格決定"})
        List.Add(New ExercPriceStatusManager With {.Code = "2", .Name = "行使価格エラー"})
    End Sub

    Public Shared Function GetList(NoSelect As Boolean, AllSelect As Boolean) As List(Of ExercPriceStatusManager)
        Dim ret As List(Of ExercPriceStatusManager) = List.ToList
        If NoSelect Then ret.Insert(0, New ExercPriceStatusManager With {.Code = "", .Name = ""})
        If AllSelect Then ret.Add(New ExercPriceStatusManager With {.Code = "ALL", .Name = "全て"})
        Return ret
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
