﻿Public Class ExercResultManager

    Public Shared List As New List(Of ExercResultManager)
    Private Shared ListWithAll As New List(Of ExercResultManager)
    Private Shared ListResultType As New List(Of ExercResultManager)

    Public Shared Sub Init()
        List.Add(New ExercResultManager With {.Code = "0", .Name = "未行使"})
        List.Add(New ExercResultManager With {.Code = "1", .Name = "ITM"})
        List.Add(New ExercResultManager With {.Code = "2", .Name = "OTM"})
        List.Add(New ExercResultManager With {.Code = "3", .Name = "ATM"})

        ListWithAll.Add(New ExercResultManager With {.Code = "0", .Name = "未行使"})
        ListWithAll.Add(New ExercResultManager With {.Code = "1", .Name = "ITM"})
        ListWithAll.Add(New ExercResultManager With {.Code = "2", .Name = "OTM"})
        ListWithAll.Add(New ExercResultManager With {.Code = "3", .Name = "ATM"})
        ListWithAll.Add(New ExercResultManager With {.Code = "", .Name = "全て"})

        ListResultType.Add(New ExercResultManager With {.Code = "01", .Name = "Call"})
        ListResultType.Add(New ExercResultManager With {.Code = "02", .Name = "Put"})
        ListResultType.Add(New ExercResultManager With {.Code = "", .Name = "全て"})
    End Sub

    Public Shared Function GetList() As List(Of ExercResultManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of ExercResultManager)
        Return ListWithAll.ToList()
    End Function

    Public Shared Function GetListResultType() As List(Of ExercResultManager)
        Return ListResultType.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
