﻿Public Class TradeTypeManager

    Public Shared List As New List(Of TradeTypeManager)
    Private Shared ListWithAll As New List(Of TradeTypeManager)
    Private Shared ListWithAll2 As New List(Of TradeTypeManager)

    Public Shared Sub Init()
        'List.Add(New TradeTypeManager With {.Code = "00", .Name = "CALL/PUT"})
        List.Add(New TradeTypeManager With {.Code = "01", .Name = "CALL"})
        List.Add(New TradeTypeManager With {.Code = "02", .Name = "PUT"})

        ListWithAll.Add(New TradeTypeManager With {.Code = "", .Name = "全て"})
        ListWithAll.Add(New TradeTypeManager With {.Code = "01", .Name = "CALL"})
        ListWithAll.Add(New TradeTypeManager With {.Code = "02", .Name = "PUT"})

        ListWithAll2.Add(New TradeTypeManager With {.Code = "", .Name = "全て"})
        ListWithAll2.Add(New TradeTypeManager With {.Code = "00", .Name = "CALL/PUT"})
        ListWithAll2.Add(New TradeTypeManager With {.Code = "01", .Name = "CALL"})
        ListWithAll2.Add(New TradeTypeManager With {.Code = "02", .Name = "PUT"})
    End Sub

    Public Shared Function GetList() As List(Of TradeTypeManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of TradeTypeManager)
        Return ListWithAll.ToList()
    End Function

    Public Shared Function GetListWithAll2() As List(Of TradeTypeManager)
        Return ListWithAll2.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
