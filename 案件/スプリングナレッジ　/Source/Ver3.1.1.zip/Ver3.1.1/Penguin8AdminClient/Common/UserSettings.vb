﻿Imports System.IO
Imports System.Runtime.Serialization
Imports System.Xml.Serialization

Public Class UserSettings

    'シングルトンインスタンス
    Private Shared _instance As New UserSettings

    Public Shared Function getInstance() As UserSettings
        Return _instance
    End Function

    '設定値データセット
    Public DataSaved As New UserSettingsSaved '永続化データ
    Public DataFlash As New UserSettingsFlash '非永続化データ

    'コンストラクタ
    Public Sub New()
    End Sub

    '設定値読込
    Public Sub load(init As Boolean, data As String)
        Dim tmp As UserSettingsSaved = Nothing
        Dim settingsString As String = Nothing
        If Not init Then
            settingsString = data
        End If
            If settingsString IsNot Nothing AndAlso Not IsDBNull(settingsString) Then
                Dim xs As New XmlSerializer(GetType(UserSettingsSaved))
                Dim xr As New StringReader(settingsString)
                Try
                    tmp = xs.Deserialize(xr)
                Catch ex As Exception
                    tmp = New UserSettingsSaved
                End Try
            Else
                tmp = New UserSettingsSaved
            End If

            DataSaved = tmp
            loadSync()
    End Sub

    '設定値保存
    Public Sub save()
        Dim xs As New XmlSerializer(GetType(UserSettingsSaved))
        Dim xw As New StringWriter

        xs.Serialize(xw, DataSaved)

        Dim service As New ClientSettingsService
        service.RegistSync(xw.ToString())
    End Sub

    Private Sub loadSync()

    End Sub

End Class
