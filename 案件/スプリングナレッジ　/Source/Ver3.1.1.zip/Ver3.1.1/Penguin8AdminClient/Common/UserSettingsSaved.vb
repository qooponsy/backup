﻿Imports System.Xml.Serialization
Imports System.Runtime.Serialization

<Serializable()> _
Public Class KeyValue
    Public Sub New()
    End Sub

    Public Sub New(ByVal _key As String, ByVal _value As Integer)
        key = _key
        Value = _value
    End Sub
    Public Key As String
    Public Value As Integer
End Class

<Serializable()> _
Public Class UserSettingsSaved

    'ウィンドウ
    <OptionalField()> Public MainWindow_FormMaximized As Boolean = False
    <OptionalField()> Public MainWindow_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public MainWindow_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public MainWindow_SubFormProductBase As Boolean = False
    <OptionalField()> Public MainWindow_SubFormProduct As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormCust As Boolean = False
    <OptionalField()> Public MainWindow_SubFormTrade As Boolean = False
    <OptionalField()> Public MainWindow_SubFormCash As Boolean = False
    <OptionalField()> Public MainWindow_SubFormSysSettingsForm As Boolean = False
    <OptionalField()> Public MainWindow_SubFormSysControlForm As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRiskMonitor As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRiskSimulate As Boolean = False
    <OptionalField()> Public MainWindow_SubFormPrisingParamList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormSalesPerformance As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateMonitor As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateFilterLogList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormNowStatus As Boolean = False
    <OptionalField()> Public MainWindow_SubFormUser As Boolean = False
    <OptionalField()> Public MainWindow_subFormLossLimitLogList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateChartHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormPremiumChartHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormPriceMonitor As Boolean = False
    <OptionalField()> Public MainWindow_SubFormExercResultList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormOrderTicketList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormTradeDiaryList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormCustomerLedgerList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormOperationHistClientList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormFileDownloadList As Boolean = False

    '銘柄設定一覧
    <OptionalField()> Public ProductBaseList_FormMaximized As Boolean = False
    <OptionalField()> Public ProductBaseList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ProductBaseList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ProductBaseList_Columns As New List(Of KeyValue)
    <OptionalField()> Public ProductBaseList_ComCode As String = ""
    <OptionalField()> Public ProductBaseList_Enabled As Boolean = True

    '銘柄一覧
    <OptionalField()> Public ProductList_FormMaximized As Boolean = False
    <OptionalField()> Public ProductList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ProductList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ProductList_Columns As New List(Of KeyValue)
    <OptionalField()> Public ProductList_CmpCode As String = ""
    <OptionalField()> Public ProductList_ComCode As String = ""
    <OptionalField()> Public ProductList_ExercStatus As String = "0"
    <OptionalField()> Public ProductList_Enabled As Boolean = True

    '銘柄詳細一覧
    <OptionalField()> Public ProductSubList_FormMaximized As Boolean = False
    <OptionalField()> Public ProductSubList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ProductSubList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    '行使結果履歴一覧
    <OptionalField()> Public ExercResultList_FormMaximized As Boolean = False
    <OptionalField()> Public ExercResultList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ExercResultList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ExercResultList_Columns As New List(Of KeyValue)
    <OptionalField()> Public ExercResultList_ComCode As String = ""
    <OptionalField()> Public ExercResultList_OpType As String = ""
    <OptionalField()> Public ExercResultList_ExercResult As String = ""
    
    'レート一覧
    <OptionalField()> Public RateHistList_FormMaximized As Boolean = False
    <OptionalField()> Public RateHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public RateHistList_ComCode As String = ""
    <OptionalField()> Public RateHistList_Enabled As Boolean = True
    <OptionalField()> Public RateHistList_Exerc As Integer = 0

    'レートチャート一覧
    <OptionalField()> Public RateChartHistList_FormMaximized As Boolean = False
    <OptionalField()> Public RateChartHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateChartHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateChartHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public RateChartHistList_ComCode As String = ""
    <OptionalField()> Public RateChartHistList_Enabled As Boolean = True
    <OptionalField()> Public RateChartHistList_ChartType As String = ""

    'プレミアムチャート一覧
    <OptionalField()> Public PremiumChartHistList_FormMaximized As Boolean = False
    <OptionalField()> Public PremiumChartHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public PremiumChartHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public PremiumChartHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public PremiumChartHistList_ComCode As String = ""
    <OptionalField()> Public PremiumChartHistList_Enabled As Boolean = True
    <OptionalField()> Public PremiumChartHistList_ChartType As String = ""
    <OptionalField()> Public PremiumChartHistList_PriceType As String = ""

    '委託者一覧
    <OptionalField()> Public CustList_FormMaximized As Boolean = False
    <OptionalField()> Public CustList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public CustList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public CustList_Columns As New List(Of KeyValue)
    <OptionalField()> Public CustList_CmpCode As String = ""
    <OptionalField()> Public CustList_EnableCust As Boolean = False
    <OptionalField()> Public CustList_FromCustCode As String = ""
    <OptionalField()> Public CustList_ToCustCode As String = ""

    '損失限度枠管理ログ
    <OptionalField()> Public LossLimitLogList_FormMaximized As Boolean = False
    <OptionalField()> Public LossLimitLogList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public LossLimitLogList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public LossLimitLogList_Columns As New List(Of KeyValue)
    <OptionalField()> Public LossLimitLogList_CmpCode As String = ""
    <OptionalField()> Public LossLimitLogList_LogType As String = ""
    <OptionalField()> Public LossLimitLogList_CustCode As String = ""

    '取引データ一覧
    <OptionalField()> Public TradeList_FormMaximized As Boolean = False
    <OptionalField()> Public TradeList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public TradeList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public TradeList_Columns As New List(Of KeyValue)
    <OptionalField()> Public TradeList_CmpCode As String = ""
    <OptionalField()> Public TradeList_ListType As String = "1"
    <OptionalField()> Public TradeList_ComCode As String = ""
    <OptionalField()> Public TradeList_TradeType As String = ""
    <OptionalField()> Public TradeList_TradeStatus As String = ""
    <OptionalField()> Public TradeList_DateType As String = "0"
    <OptionalField()> Public TradeList_ProductCode As String = ""
    <OptionalField()> Public TradeList_CustCode As String = ""

    '残高データ一覧
    <OptionalField()> Public CashList_FormMaximized As Boolean = False
    <OptionalField()> Public CashList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public CashList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public CashList_Columns As New List(Of KeyValue)
    <OptionalField()> Public CashList_CmpCode As String = ""
    <OptionalField()> Public CashList_CashType As String = ""
    <OptionalField()> Public CashList_DateType As String = "0"
    <OptionalField()> Public CashList_CustCode As String = ""

    'システム設定
    <OptionalField()> Public SysSettingsForm_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    'システム制御
    <OptionalField()> Public SysControlForm_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    'リスクモニタ
    <OptionalField()> Public RiskMonitor_FormMaximized As Boolean = False
    <OptionalField()> Public RiskMonitor_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RiskMonitor_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RiskMonitor_SplitterDistance As Integer = 0
    <OptionalField()> Public RiskMonitor_SumColumns As New List(Of KeyValue)
    <OptionalField()> Public RiskMonitor_DetailColumns As New List(Of KeyValue)
    <OptionalField()> Public RiskMonitor_CmpCode As String = ""

    'リスクシミュレーション
    <OptionalField()> Public RiskSimulate_FormMaximized As Boolean = False
    <OptionalField()> Public RiskSimulate_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RiskSimulate_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RiskSimulate_SplitterDistance As Integer = 0
    <OptionalField()> Public RiskSimulate_Columns As New List(Of KeyValue)
    <OptionalField()> Public RiskSimulate_ComCode As String = "USDJPY"
    <OptionalField()> Public RiskSimulate_CmpCode As String = ""
    <OptionalField()> Public RiskSimulate_AutoReCalc As Boolean = False

    '営業実績表
    <OptionalField()> Public SalesPerformanceList_FormMaximized As Boolean = False
    <OptionalField()> Public SalesPerformanceList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public SalesPerformanceList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public SalesPerformanceList_Columns As New List(Of KeyValue)
    <OptionalField()> Public SalesPerformanceList_CmpCode As String = ""

    'レートフィルターログ
    <OptionalField()> Public RateFilterLogList_FormMaximized As Boolean = False
    <OptionalField()> Public RateFilterLogList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateFilterLogList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateFilterLogList_Columns As New List(Of KeyValue)
    <OptionalField()> Public RateFilterLogList_DataType As String = "0"
    <OptionalField()> Public RateFilterLogList_ComCode As String = ""
    <OptionalField()> Public RateFilterLogList_LogType As String = ""

    'レートモニター
    <OptionalField()> Public RateMonitor_FormMaximized As Boolean = False
    <OptionalField()> Public RateMonitor_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateMonitor_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateMonitorList_Columns As New List(Of KeyValue)

    'レートログアラート
    <OptionalField()> Public RateLogAlert_RateFilterSettings As Boolean = False
    <OptionalField()> Public RateLogAlert_RateFilter As Boolean = False
    <OptionalField()> Public RateLogAlert_RateFilterCounterClear As Boolean = False
    <OptionalField()> Public RateLogAlert_RateChanged As Boolean = False
    <OptionalField()> Public RateLogAlert_AnomalyRate As Boolean = False
    <OptionalField()> Public RateLogAlert_AnomalyRateClear As Boolean = False
    <OptionalField()> Public RateLogAlert_RateTimeDiff As Boolean = False
    <OptionalField()> Public RateLogAlert_RateTimeDiffClear As Boolean = False

    '時価モニター
    <OptionalField()> Public PriceMonitor_FormMaximized As Boolean = False
    <OptionalField()> Public PriceMonitor_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public PriceMonitor_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public PriceMonitorList_Columns As New List(Of KeyValue)

    '稼働ステータス
    <OptionalField()> Public NowStatusForm_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public NowStatusForm_CmpCode As String = ""

    '法定帳簿：注文伝票
    <OptionalField()> Public OrderTicketList_FormMaximized As Boolean = False
    <OptionalField()> Public OrderTicketList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public OrderTicketList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public OrderTicketList_Columns As New List(Of KeyValue)
    <OptionalField()> Public OrderTicketList_CmpCode As String = ""

    '法定帳簿：取引日記帳
    <OptionalField()> Public TradeDiaryList_FormMaximized As Boolean = False
    <OptionalField()> Public TradeDiaryList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public TradeDiaryList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public TradeDiaryList_Columns As New List(Of KeyValue)
    <OptionalField()> Public TradeDiaryList_CmpCode As String = ""

    '法定帳簿：顧客勘定元帳帳
    <OptionalField()> Public CustomerLedgerList_FormMaximized As Boolean = False
    <OptionalField()> Public CustomerLedgerList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public CustomerLedgerList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public CustomerLedgerList_Columns As New List(Of KeyValue)
    <OptionalField()> Public CustomerLedgerList_CustCode As String = ""
    <OptionalField()> Public CustomerLedgerList_MovementOfFundsDisp As Boolean = False

    'ユーザー一覧
    <OptionalField()> Public UserList_FormMaximized As Boolean = False
    <OptionalField()> Public UserList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public UserList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public UserList_Columns As New List(Of KeyValue)
    <OptionalField()> Public UserList_CmpCode As String = ""
    <OptionalField()> Public UserList_Enabled As Boolean = True

    '委託者用操作ログ一覧
    <OptionalField()> Public OperationHistClientList_FormMaximized As Boolean = False
    <OptionalField()> Public OperationHistClientList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public OperationHistClientList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public OperationHistClientList_Columns As New List(Of KeyValue)
    <OptionalField()> Public OperationHistClientList_CmpCode As String = ""
    <OptionalField()> Public OperationHistClientList_DataType As String = ""
    <OptionalField()> Public OperationHistClientList_ChannelName As String = ""
    <OptionalField()> Public OperationHistClientList_CustCode As String = ""
    <OptionalField()> Public OperationHistClientList_Code As String = ""
    <OptionalField()> Public OperationHistClientList_IPAddress As String = ""

    'ファイルダウンロード
    <OptionalField()> Public FileDownloadList_FormMaximized As Boolean = False
    <OptionalField()> Public FileDownloadList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public FileDownloadList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public FileDownloadList_Columns As New List(Of KeyValue)
    <OptionalField()> Public FileDownloadList_CmpCode As String = ""
    <OptionalField()> Public FileDownloadList_FileType As Integer = 0

End Class
