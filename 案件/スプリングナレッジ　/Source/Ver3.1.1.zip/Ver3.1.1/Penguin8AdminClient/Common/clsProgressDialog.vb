﻿'*******************************************************************************
'
'
'
'
'
'*******************************************************************************

''' <summary>
''' プログレスバー用ダイアログクラス
''' </summary>
''' <remarks></remarks>
Public Class clsProgressDialog
    Implements IDisposable

    Private _Canceled As Boolean = False
    Private _DialogForm As SplashScreen
    Private _StartEvent As System.Threading.ManualResetEvent
    Private _Showed As Boolean = False
    Private _Closing As Boolean = False
    Private _OwnerForm As Form
    Private _thread As System.Threading.Thread
    Private _Minimum As Integer = 0
    Private _Maximum As Integer = 100
    Private _Value As Integer = 0

    ''' <summary>
    ''' プログレスバーの最小値
    ''' </summary>
    Public Property Minimum() As Integer
        Get
            Return Me._Minimum
        End Get
        Set(ByVal Value As Integer)
            Me._Minimum = Value
            If Me._DialogForm IsNot Nothing Then
                Me._DialogForm.Invoke(New MethodInvoker(AddressOf SetProgressMinimum))
            End If
        End Set
    End Property

    ''' <summary>
    ''' プログレスバーの最大値
    ''' </summary>
    Public Property Maximum() As Integer
        Get
            Return Me._Maximum
        End Get
        Set(ByVal Value As Integer)
            Me._Maximum = Value
            If Me._DialogForm IsNot Nothing Then
                Me._DialogForm.Invoke(New MethodInvoker(AddressOf SetProgressMaximun))
            End If
        End Set
    End Property

    ''' <summary>
    ''' プログレスバーの値
    ''' </summary>
    Public Property Value() As Integer
        Get
            Return Me._Value
        End Get
        Set(ByVal Value As Integer)
            Me._Value = Value
            If Me._DialogForm IsNot Nothing Then
                Me._DialogForm.Invoke(New MethodInvoker(AddressOf SetProgressValue))
            End If
        End Set
    End Property

    ''' <summary>
    ''' キャンセルされたか
    ''' </summary>
    Public ReadOnly Property Canceled() As Boolean
        Get
            Return Me._Canceled
        End Get
    End Property

    ''' <summary>
    ''' ダイアログ表示
    ''' </summary>
    ''' <param name="OwnerForm"></param>
    ''' <remarks></remarks>
    Public Overloads Sub Show(ByVal OwnerForm As Form)
        If Me._Showed Then
            Return
        End If
        Me._Showed = True
        Me._Canceled = False
        Me._StartEvent = New System.Threading.ManualResetEvent(False)
        Me._OwnerForm = OwnerForm
        Me._thread = New System.Threading.Thread( _
            New System.Threading.ThreadStart(AddressOf Run))
        Me._thread.IsBackground = True
        'Me.thread.ApartmentState = System.Threading.ApartmentState.STA
        Me._thread.SetApartmentState(System.Threading.ApartmentState.STA)
        Me._thread.Start()
        Me._StartEvent.WaitOne()    '※ フォームが表示されるまで待機
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Overloads Sub Show()
        Show(Nothing)
    End Sub

    ''' <summary>
    ''' 別スレッド用メソッド
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Run()
        Me._DialogForm = New SplashScreen
        AddHandler Me._DialogForm.Closing, AddressOf form_Closing
        AddHandler Me._DialogForm.Activated, AddressOf form_Activated
        Me._DialogForm.upbProgressBar.Minimum = Me._Minimum
        Me._DialogForm.upbProgressBar.Maximum = Me._Maximum
        Me._DialogForm.upbProgressBar.Value = Me._Value
        Me._DialogForm.ShowDialog()
        Me._DialogForm.Dispose()
    End Sub

    ''' <summary>
    ''' ダイアログを閉じる
    ''' </summary>
    Public Sub Close()
        Me._Closing = True
        Me._DialogForm.Invoke(New MethodInvoker(AddressOf Me._DialogForm.Close))
    End Sub 'Close

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Dispose() Implements System.IDisposable.Dispose
        Me._DialogForm.Invoke(New MethodInvoker(AddressOf Me._DialogForm.Dispose))
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetProgressValue()
        If (Me._DialogForm IsNot Nothing) AndAlso (Not Me._DialogForm.IsDisposed) Then
            Me._DialogForm.upbProgressBar.Value = Me._Value
        End If
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetProgressMaximun()
        If (Me._DialogForm IsNot Nothing) AndAlso (Not Me._DialogForm.IsDisposed) Then
            Me._DialogForm.upbProgressBar.Maximum = Me._Maximum
        End If
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetProgressMinimum()
        If (Me._DialogForm IsNot Nothing) AndAlso (Not Me._DialogForm.IsDisposed) Then
            Me._DialogForm.upbProgressBar.Minimum = Me._Minimum
        End If
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub form_Closing(ByVal sender As Object, _
        ByVal e As System.ComponentModel.CancelEventArgs)
        If Not Me._Closing Then
            e.Cancel = True
            Me._Canceled = True
        End If
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub form_Activated(ByVal sender As Object, ByVal e As EventArgs)
        RemoveHandler Me._DialogForm.Activated, AddressOf form_Activated
        Me._StartEvent.Set()
    End Sub

End Class
