﻿Public Class ExercFlagManager

    Private Shared List As New List(Of ExercStatusManager)

    Public Shared Sub Init()
        List.Add(New ExercStatusManager With {.Code = "0", .Name = "行使対象外"})
        List.Add(New ExercStatusManager With {.Code = "1", .Name = "行使対象"})
    End Sub

    Public Shared Function GetList() As List(Of ExercStatusManager)
        Return List.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
