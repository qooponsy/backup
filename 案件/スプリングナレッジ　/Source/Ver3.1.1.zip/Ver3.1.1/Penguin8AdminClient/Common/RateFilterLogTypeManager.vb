﻿Public Class RateFilterLogTypeManager

    Private Shared DataTypeList As New List(Of RateFilterLogTypeManager)
    Private Shared LogTypeList As New List(Of RateFilterLogTypeManager)

    Public Shared Sub Init()
        DataTypeList.Add(New RateFilterLogTypeManager With {.Code = "0", .Name = "リアルタイム"})
        DataTypeList.Add(New RateFilterLogTypeManager With {.Code = "1", .Name = "履歴検索"})

        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "01", .Name = "レートフィルター設定変更"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "11", .Name = "レートフィルター"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "12", .Name = "レートフィルターカウンタクリア"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "13", .Name = "相場水準変更"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "14", .Name = "異常レート"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "15", .Name = "異常レート状態解除"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "21", .Name = "レート時間乖離"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "22", .Name = "レート時間乖離復旧"})
        LogTypeList.Add(New RateFilterLogTypeManager With {.Code = "", .Name = "全て"})
    End Sub

    Public Shared Function GetDataTypeList() As List(Of RateFilterLogTypeManager)
        Return DataTypeList.ToList()
    End Function

    Public Shared Function GetLogTypeList() As List(Of RateFilterLogTypeManager)
        Return LogTypeList.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
