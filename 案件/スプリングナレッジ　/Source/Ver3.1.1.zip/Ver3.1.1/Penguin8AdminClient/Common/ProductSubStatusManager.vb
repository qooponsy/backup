﻿Public Class ProductSubStatusManager

    Public Shared List As New List(Of ProductSubStatusManager)
    Private Shared ListWithAll As New List(Of ProductSubStatusManager)

    Public Shared Sub Init()
        List.Add(New ProductSubStatusManager With {.Code = "0", .Name = "通常"})
        List.Add(New ProductSubStatusManager With {.Code = "1", .Name = "除外行使価格"})

        ListWithAll.Add(New ProductSubStatusManager With {.Code = "", .Name = "全て"})
        ListWithAll.Add(New ProductSubStatusManager With {.Code = "0", .Name = "通常"})
        ListWithAll.Add(New ProductSubStatusManager With {.Code = "1", .Name = "除外行使価格"})
    End Sub

    Public Shared Function GetList() As List(Of ProductSubStatusManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of ProductSubStatusManager)
        Return ListWithAll.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
