﻿Imports System.IO
Imports System.Xml.Serialization
Imports System.Runtime.Serialization

<Serializable()> _
Public Class PricingSim2Settings

    <OptionalField()> Public FormMaximized As Boolean = False
    <OptionalField()> Public FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public SplitterDistance As Integer = 160
    <OptionalField()> Public ComCode As String = "USDJPY"
    <OptionalField()> Public Volatility As Boolean = False
    <OptionalField()> Public Chart() As Boolean = {True, False, False, False, False, False, False, False, False}
    <OptionalField()> Public CallAskHigh As Boolean = True
    <OptionalField()> Public CallAskLow As Boolean = True
    <OptionalField()> Public CallBidHigh As Boolean = True
    <OptionalField()> Public CallBidLow As Boolean = True
    <OptionalField()> Public PutAskHigh As Boolean = True
    <OptionalField()> Public PutAskLow As Boolean = True
    <OptionalField()> Public PutBidHigh As Boolean = True
    <OptionalField()> Public PutBidLow As Boolean = True
    <OptionalField()> Public ChartView() As Boolean = {True, False, False, False, False, False, False, False, False}
    <OptionalField()> Public CallAskHighView As Boolean = True
    <OptionalField()> Public CallAskLowView As Boolean = True
    <OptionalField()> Public CallBidHighView As Boolean = True
    <OptionalField()> Public CallBidLowView As Boolean = True
    <OptionalField()> Public PutAskHighView As Boolean = True
    <OptionalField()> Public PutAskLowView As Boolean = True
    <OptionalField()> Public PutBidHighView As Boolean = True
    <OptionalField()> Public PutBidLowView As Boolean = True
    <OptionalField()> Public SettingMulti As Boolean = False
    <OptionalField()> Public ColorType As Boolean = True
    <OptionalField()> Public VolRatio1Call() As String = {"1", "1", "1", "1", "1", "1", "1", "1", "1"}
    <OptionalField()> Public VolRatio1Put() As String = {"1", "1", "1", "1", "1", "1", "1", "1", "1"}
    <OptionalField()> Public CallPutSpread() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public VolRatio2Call() As String = {"1", "1", "1", "1", "1", "1", "1", "1", "1"}
    <OptionalField()> Public VolRatio2Put() As String = {"1", "1", "1", "1", "1", "1", "1", "1", "1"}
    <OptionalField()> Public VolSmileACall() As String = {"1", "1", "1", "1", "1", "1", "1", "1", "1"}
    <OptionalField()> Public VolSmileAPut() As String = {"1", "1", "1", "1", "1", "1", "1", "1", "1"}
    <OptionalField()> Public VolSmileBCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public VolSmileBPut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public VolSpreadCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public VolSpreadPut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public AskFeePriceCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public AskFeePricePut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public AskBidSpreadMinCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public AskBidSpreadMinPut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public BidFeeRateCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public BidFeeRatePut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public AskPriceMaxCall() As String = {"1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000"}
    <OptionalField()> Public AskPriceMinCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public BidPriceMaxCall() As String = {"1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000"}
    <OptionalField()> Public BidPriceMinCall() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public AskPriceMaxPut() As String = {"1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000"}
    <OptionalField()> Public AskPriceMinPut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}
    <OptionalField()> Public BidPriceMaxPut() As String = {"1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000", "1000"}
    <OptionalField()> Public BidPriceMinPut() As String = {"0", "0", "0", "0", "0", "0", "0", "0", "0"}

    Public Shared Function Load() As PricingSim2Settings
        Dim path As String = GetSettingPath()
        Dim obj As Object = Nothing
        Try
            Using fs As New FileStream(path, FileMode.Open, FileAccess.Read)
                Dim xs As New System.Xml.Serialization.XmlSerializer(GetType(PricingSim2Settings))
                obj = xs.Deserialize(fs)
                fs.Close()
            End Using
        Catch ex As Exception
            obj = New PricingSim2Settings
        End Try

        Return CType(obj, PricingSim2Settings)
    End Function

    Public Shared Sub Save(data As PricingSim2Settings)
        Dim path As String = GetSettingPath()

        Using fs As New FileStream(path, FileMode.Create, FileAccess.Write)
            Dim xs As New System.Xml.Serialization.XmlSerializer(GetType(PricingSim2Settings))
            xs.Serialize(fs, data)
            fs.Close()
        End Using
    End Sub

    Private Shared Function GetSettingDir() As String
        Return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            Application.CompanyName + "\" + Application.ProductName)
    End Function

    Private Shared Function GetSettingPath() As String
        If Not Directory.Exists(GetSettingDir) Then
            Directory.CreateDirectory(GetSettingDir())
        End If
        Return GetSettingDir() + "\" + "PricingSim2.config"
    End Function

End Class
