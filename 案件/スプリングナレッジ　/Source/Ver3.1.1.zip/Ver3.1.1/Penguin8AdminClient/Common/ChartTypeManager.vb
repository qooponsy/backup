﻿Public Class ChartTypeManager

    Private Shared ChartTypeList As New List(Of ChartTypeManager)
    Private Shared ListWithAll As New List(Of ChartTypeManager)

    Public Shared Sub Init()
        ChartTypeList.Add(New ChartTypeManager With {.Code = "1", .Name = "1分足"})

        'ListWithAll.Add(New ChartTypeManager With {.Code = "1", .Name = "1分足"})
        'ListWithAll.Add(New ChartTypeManager With {.Code = "", .Name = "全て"})
        ListWithAll.Add(New ChartTypeManager With {.Code = "", .Name = "1分足"})

    End Sub

    Public Shared Function GetChartTypeList() As List(Of ChartTypeManager)
        Return ChartTypeList.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of ChartTypeManager)
        Return ListWithAll.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
