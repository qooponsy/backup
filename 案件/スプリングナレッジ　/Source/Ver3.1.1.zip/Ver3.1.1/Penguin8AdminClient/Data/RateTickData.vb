﻿Public Class RateTickData

    Public ComCode As String    '通貨ペアコード
    Public RateSeq As String    'レートSeq
    Public RateTime As DateTime 'レート時間
    Public Rate As Decimal      'レート
    Public RateOld As Decimal
    Public RateArrowCount As Integer

End Class
