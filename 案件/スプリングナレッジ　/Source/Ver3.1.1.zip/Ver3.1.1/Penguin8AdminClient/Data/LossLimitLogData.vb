﻿Public Class LossLimitLogData
    Public LogID As Integer
    Public LogTime As DateTime
    Public SysDate As DateTime
    Public CmpCode As String
    Public CsutCode As String
    Public LogType As String
    Public LogText As String

    Public ReadOnly Property LogTypeName()
        Get
            For Each item As LossLimitLogTypeManager In LossLimitLogTypeManager.GetLogTypeList
                If item.Code = LogType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
