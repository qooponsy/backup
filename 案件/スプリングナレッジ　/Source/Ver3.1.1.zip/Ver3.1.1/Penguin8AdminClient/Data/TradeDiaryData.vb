﻿Public Class TradeDiaryData
    Public OrderReqTime2Enabled As Boolean
    Public OrderReqTime2 As DateTime
    Public SysDate As DateTime
    Public TradeSeq As String
    Public TradeSubSeq As Integer
    Public SubSeqCount As Integer
    Public CustCode As String
    Public CustName As String
    'Public CmpName As String
    Public CmpCode As String
    Public OrderReqTimeEnabled As Boolean
    Public OrderReqTime As DateTime
    Public ComCode As String
    Public Own As String
    Public BuySell As String
    Public TypeOfTrading As String
    Public Classification As String
    Public ExecutionDevision As String
    Public TradeType As String
    Public ExercPriceEnabled As Boolean
    Public ExercPrice As Decimal
    Public ExercTimeEnabled As Boolean
    Public ExercTime As DateTime
    Public TradeTimeEnabled As Boolean
    Public TradeTime As DateTime
    Public LotEnabled As Boolean
    Public Lot As Integer
    Public PriceEnabled As Boolean
    Public Price As Decimal
    Public Premium As Decimal
    Public AbandReqTimeEnabled As Boolean
    Public AbandReqTime As DateTime
    Public ExercProcTimeEnabled As Boolean
    Public ExercProcTime As DateTime
    Public ExercProcTime2Enabled As Boolean
    Public ExercProcTime2 As DateTime
    Public PayoutPriceEnabled As Boolean
    Public PayoutPrice As Decimal
    Public PayoutEnabled As Boolean
    Public Payout As Decimal
    Public PayoutPrice2Enabled As Boolean
    Public PayoutPrice2 As Decimal
    Public Payout2Enabled As Boolean
    Public Payout2 As Decimal
    Public TradeStatusName As String

    Public ReadOnly Property TradeTypeName()
        Get
            For Each item As TradeTypeManager In TradeTypeManager.List
                If item.Code = TradeType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
