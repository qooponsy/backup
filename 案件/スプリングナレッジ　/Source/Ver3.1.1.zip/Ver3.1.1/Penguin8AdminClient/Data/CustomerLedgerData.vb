﻿Public Class CustomerLedgerData
    Public CashCode As String
    Public SysDate As DateTime
    Public CustCodeEnabled As Boolean
    Public CustCode As String
    Public CustNameEnabled As Boolean
    Public CustName As String
    Public ExecTimeEnabled As Boolean
    Public ExecTime As DateTime
    Public TypeOfTradingEnabled As Boolean
    Public TypeOfTrading As String
    Public ComCodeEnabled As Boolean
    Public ComCode As String
    Public ExercTimeEnabled As Boolean
    Public ExercTime As DateTime
    Public ExercPriceEnabled As Boolean
    Public ExercPrice As Decimal
    Public BuySellEnabled As Boolean
    Public BuySell As String
    Public TradeTypeEnabled As Boolean
    Public TradeType As String
    Public CashTypeNameEnabled As Boolean
    Public CashTypeName As String
    Public TradeStatusNameEnabled As Boolean
    Public TradeStatusName As String
    Public LotEnabled As Boolean
    Public Lot As Integer
    Public PriceEnabled As Boolean
    Public Price As Decimal
    Public PayoutPriceEnabled As Boolean
    Public PayoutPrice As Decimal
    Public PremiumOrPayoutEnabled As Boolean
    Public PremiumOrPayout As Decimal
    Public PayoutEnabled As Boolean
    Public Payout As Decimal
    Public TotalMoneyPrevEnabled As Boolean
    Public TotalMoneyPrev As Decimal
    Public MoneyEnabled As Boolean
    Public Money As Decimal
    Public TotalMoneyEnabled As Boolean
    Public TotalMoney As Decimal

    Public ReadOnly Property TradeTypeName()
        Get
            For Each item As TradeTypeManager In TradeTypeManager.List
                If item.Code = TradeType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property
End Class
