﻿Public Class RateProviderData
    Public ProviderID As Integer                     'プロバイダID
    Public ProviderName As String                    'プロバイダ名称
End Class
