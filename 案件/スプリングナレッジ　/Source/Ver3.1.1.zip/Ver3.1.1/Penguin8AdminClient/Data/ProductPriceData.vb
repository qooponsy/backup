﻿Public Class ProductPriceData

    Public ProductSubCode As String
    Public CalcTime As DateTime
    Public PriceAskCall As Decimal
    Public PriceBidCall As Decimal
    Public PriceAskPut As Decimal
    Public PriceBidPut As Decimal
    Public VolAskCall As Decimal
    Public VolBidCall As Decimal
    Public VolAskPut As Decimal
    Public VolBidPut As Decimal

End Class
