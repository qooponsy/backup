﻿Public Class OperationHistClientData

    Public LogTime As DateTime      '操作日時
    Public SysDate As Date          'システム日時
    Public CmpCode As String        '会社コード
    Public CustCode As String       '委託者コード
    Public ClientType As String     'クライアント種別
    Public ChannelName As String    'チャネル名
    Public ClientIP As String       'IPアドレス
    Public DataType As String       'データタイプ
    Public LogType As String        'ログタイプ
    Public Code As String           'コード
    Public LogText As String        'ログ

End Class
