﻿Public Class NowProductData

    Public ProductCode As String                        '銘柄コード
    Public ProductSubCode As String                     '銘柄詳細コード
    Public ProductEnabled As String                     '銘柄有効フラグ
    Public ProductSubEnabled As String                  '銘柄詳細有効フラグ
    Public ProductSubStatus As String                   '銘柄ステータス
    Public ComCode As String                            '通貨ペアコード
    Public OpType As String                             'オプション種別
    Public StartTime As DateTime                        '取引開始時間
    Public ExercTime As DateTime                        '行使期日
    Public TradeLimitTime As DateTime                   '取引可能期日
    Public ExercPriceTimespanEnabled As Boolean         '行使価格決定時間
    Public ExercPriceTimespan As Integer
    Public ExercPriceRateEnabled As Boolean             '行使価格決定時レート
    Public ExercPriceRate As Decimal
    Public ExercPriceUnitTypeEnabled As Boolean         '行使価格刻み幅種別
    Public ExercPriceUnitType As String
    Public ExercPriceUnitEnabled As Boolean             '行使価格刻み幅
    Public ExercPriceUnit As Decimal
    Public ExercPriceSettingEnabled As Boolean         '行使価格設定
    Public ExercPriceSetting As String
    Public ExercPriceEnabled As Boolean                 '行使価格
    Public ExercPrice As Decimal
    Public VolRatio1CallEnabled As Boolean       'ボラティリティレシオ１(Call)
    Public VolRatio1Call As Decimal
    Public VolRatio1PutEnabled As Boolean        'ボラティリティレシオ１(Put)
    Public VolRatio1Put As Decimal
    Public VolRatio2CallEnabled As Boolean       'ボラティリティレシオ２(Call)
    Public VolRatio2Call As Decimal
    Public VolRatio2PutEnabled As Boolean        'ボラティリティレシオ２(Put)
    Public VolRatio2Put As Decimal
    Public VolSmileACallEnabled As Boolean       'ボラティリティスマイルａ(Call)
    Public VolSmileACall As Decimal
    Public VolSmileAPutEnabled As Boolean        'ボラティリティスマイルａ(Put)
    Public VolSmileAPut As Decimal
    Public VolSmileBCallEnabled As Boolean       'ボラティリティスマイルｂ(Call)
    Public VolSmileBCall As Decimal
    Public VolSmileBPutEnabled As Boolean        'ボラティリティスマイルｂ(Put)
    Public VolSmileBPut As Decimal
    Public VolSpreadEnabled As Boolean           'ボラティリティスプレッド
    Public VolSpread As Decimal
    Public VolSpreadITMCallEnabled As Boolean       'ボラティリティスプレッドITM(Call)
    Public VolSpreadITMCall As Decimal
    Public VolSpreadITMPutEnabled As Boolean        'ボラティリティスプレッドITM(Put)
    Public VolSpreadITMPut As Decimal
    Public VolSpreadOTMCallEnabled As Boolean       'ボラティリティスプレッドOTM(Call)
    Public VolSpreadOTMCall As Decimal
    Public VolSpreadOTMPutEnabled As Boolean        'ボラティリティスプレッドOTM(Put)
    Public VolSpreadOTMPut As Decimal
    Public AskFeePriceCallEnabled As Boolean           '購入価格リスク(Call)
    Public AskFeePriceCall As Decimal
    Public AskFeePricePutEnabled As Boolean            '購入価格リスク(Put)
    Public AskFeePricePut As Decimal
    Public AskBidSpreadMinCallEnabled As Boolean           '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Call)
    Public AskBidSpreadMinCall As Decimal
    Public AskBidSpreadMinPutEnabled As Boolean            '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Put)
    Public AskBidSpreadMinPut As Decimal
    Public BidFeeRateCallEnabled As Boolean           '清算価格リスク(%)(Call)
    Public BidFeeRateCall As Decimal
    Public BidFeeRatePutEnabled As Boolean            '清算価格リスク(%)(Put)
    Public BidFeeRatePut As Decimal
    Public AskPriceMaxCallEnabled As Boolean            '最高購入価格(Call)
    Public AskPriceMaxCall As Decimal
    Public AskPriceMaxPutEnabled As Boolean             '最高購入価格(Put)
    Public AskPriceMaxPut As Decimal
    Public AskPriceMinCallEnabled As Boolean            '最低購入価格(Call)
    Public AskPriceMinCall As Decimal
    Public AskPriceMinPutEnabled As Boolean             '最低購入価格(Put)
    Public AskPriceMinPut As Decimal
    Public BidPriceMaxCallEnabled As Boolean            '最高清算価格(Call)
    Public BidPriceMaxCall As Decimal
    Public BidPriceMaxPutEnabled As Boolean             '最高清算価格(Put)
    Public BidPriceMaxPut As Decimal
    Public BidPriceMinCallEnabled As Boolean            '最低清算価格(Call)
    Public BidPriceMinCall As Decimal
    Public BidPriceMinPutEnabled As Boolean             '最低清算価格(Put)
    Public BidPriceMinPut As Decimal

    Public ReadOnly Property Status
        Get
            If ProductEnabled <> "1" Then
                Return "銘柄無効"
            ElseIf ProductSubEnabled <> "1" Then
                Return "銘柄詳細無効"
            ElseIf ProductSubStatus <> "0" Then
                Return "除外行使価格"
            Else
                Return ""
            End If
        End Get
    End Property

End Class
