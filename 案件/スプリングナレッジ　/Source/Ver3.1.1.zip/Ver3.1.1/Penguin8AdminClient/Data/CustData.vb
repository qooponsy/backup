﻿Public Class CustData

    Public Property CmpCode As String
    Public Property CustCode As String
    Public Property RegTime As DateTime
    Public Property CurCode As String
    Public Property TotalMoney As Decimal
    Public Property LossLimit As Decimal
    Public Property DealDisabled As String
    Public Property PAndLMonthly As Decimal

End Class
