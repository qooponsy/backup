﻿Public Class SysSettingsData

    Public StopTradeTime As Integer
    Public StartAbandTime As Integer
    Public AbandPriceDiff As Integer
    Public LimitOrderRate As Integer
    Public LimitAbandRate As Integer
    Public Commission As Decimal
    Public AbandMargine As Decimal
    Public TradeMoneyMin As Decimal
    Public TradeLotMin As Decimal
    Public TradeMoneyMax As Decimal
    Public TradeLotMax As Decimal
    Public ProductMoneyMax As Decimal
    Public ProductLotMax As Decimal
    Public CustCountMax As Integer
    Public CustMoneyMax As Decimal
    Public CustLotMax As Decimal
    Public CustProductMoneyMax As Decimal
    Public CustProductLotMax As Decimal
    Public CashInMoneyMin As Decimal
    Public CashInMoneyDayMin As Decimal
    Public CashOutMoneyMax As Decimal
    Public CashOutMoneyDayMax As Decimal
    Public ProductStartPreTime As Integer
    Public ProductEndLossTime As Integer
    Public RateEnableTime As Integer

    Public Function IsMatch(item As SysSettingsData) As Boolean
        If StopTradeTime <> item.StopTradeTime Then Return False
        If StartAbandTime <> item.StartAbandTime Then Return False
        If AbandPriceDiff <> item.AbandPriceDiff Then Return False
        If LimitOrderRate <> item.LimitOrderRate Then Return False
        If LimitAbandRate <> item.LimitAbandRate Then Return False
        If Commission <> item.Commission Then Return False
        If AbandMargine <> item.AbandMargine Then Return False
        If TradeMoneyMin <> item.TradeMoneyMin Then Return False
        If TradeLotMin <> item.TradeLotMin Then Return False
        If TradeMoneyMax <> item.TradeMoneyMax Then Return False
        If TradeLotMax <> item.TradeLotMax Then Return False
        If ProductMoneyMax <> item.ProductMoneyMax Then Return False
        If ProductLotMax <> item.ProductLotMax Then Return False
        If CustCountMax <> item.CustCountMax Then Return False
        If CustMoneyMax <> item.CustMoneyMax Then Return False
        If CustLotMax <> item.CustLotMax Then Return False
        If CustProductMoneyMax <> item.CustProductMoneyMax Then Return False
        If CustProductLotMax <> item.CustProductLotMax Then Return False
        If CashInMoneyMin <> item.CashInMoneyMin Then Return False
        If CashInMoneyDayMin <> item.CashInMoneyDayMin Then Return False
        If CashOutMoneyMax <> item.CashOutMoneyMax Then Return False
        If CashOutMoneyDayMax <> item.CashOutMoneyDayMax Then Return False
        If ProductStartPreTime <> item.ProductStartPreTime Then Return False
        If ProductEndLossTime <> item.ProductEndLossTime Then Return False
        If RateEnableTime <> item.RateEnableTime Then Return False
        Return True
    End Function

End Class
