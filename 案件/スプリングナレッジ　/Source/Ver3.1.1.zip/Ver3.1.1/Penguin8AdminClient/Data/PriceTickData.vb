﻿Public Class PriceTickData

    Public ProductCode As String        '銘柄コード
    Public ProductSubCode As String     '銘柄詳細コード
    Public ComCode As String            '通貨ペア
    Public OpType As String             'オプション種別
    Public ExercTime As DateTime        '行使期日
    Public ExercPrice As Decimal        '行使価格
    Public RateSeq As String            'レートSeq
    Public Rate As Decimal              'レート
    Public RateTime As DateTime         'レート時刻
    Public CalcTime As DateTime         '計算時刻
    Public AskCall As Decimal           '購入価格(Call)
    Public BidCall As Decimal           '清算価格(Call)
    Public AskPut As Decimal            '購入価格(Put)
    Public BidPut As Decimal            '清算価格(Put)
    Public VolatilityCall As Decimal    'ボラティリティ(Call)
    Public VolatilityPut As Decimal     'ボラティリティ(Put)

    Public ReadOnly Property OpName() As String
        Get
            Return IIf(OpType = "1", "バイナリ", "ラダー")
        End Get
    End Property

End Class
