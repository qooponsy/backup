﻿Public Class ClientVersionData
    Public Property ClientType As String
    Public Property ClientVersion As Integer
    Public Property APIVersion As Integer
    Public Property ChannelName As String

    Public Function IsMatch(item As ClientVersionData)
        If ClientType <> item.ClientType Then Return False
        If ClientVersion <> item.ClientVersion Then Return False
        If APIVersion <> item.APIVersion Then Return False
        If ChannelName <> item.ChannelName Then Return False

        Return True
    End Function

End Class
