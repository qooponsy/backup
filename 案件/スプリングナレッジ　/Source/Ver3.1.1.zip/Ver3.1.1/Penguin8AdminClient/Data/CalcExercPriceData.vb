﻿Public Class CalcExercPriceData

    Public ExercPriceSetting As String              '行使価格設定
    Public ExercPriceEnabled As Boolean             '行使価格
    Public ExercPrice As Decimal
    Public ProductSubStatus As String               'ステータス

    Public ReadOnly Property ProductSubStatsuName() As String
        Get
            If ProductSubStatus = "" Then Return "エラー"
            Return IIf(ProductSubStatus = "1", "除外行使価格", "通常")
        End Get
    End Property

End Class
