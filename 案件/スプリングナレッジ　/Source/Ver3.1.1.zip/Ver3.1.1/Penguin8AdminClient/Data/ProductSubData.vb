﻿Public Class ProductSubData

    Public ProductSubCode As String                 '銘柄詳細コード
    Public ProductEnabled As String                 '有効フラグ
    Public ProductSubStatus As String               'ステータス
    Public ProductCode As String                    '銘柄コード
    Public ExercPriceSetting As String              '行使価格設定
    Public ExercPrice As Decimal                    '行使価格
    Public VolatilityRatio1CallEnabled As Boolean   'ボラティリティレシオ１(Call)
    Public VolatilityRatio1Call As Decimal
    Public VolatilityRatio1PutEnabled As Boolean    'ボラティリティレシオ１(Put)
    Public VolatilityRatio1Put As Decimal
    Public VolatilityRatio2CallEnabled As Boolean   'ボラティリティレシオ２(Call)
    Public VolatilityRatio2Call As Decimal
    Public VolatilityRatio2PutEnabled As Boolean    'ボラティリティレシオ２(Put)
    Public VolatilityRatio2Put As Decimal
    Public VolatilitySmileACallEnabled As Boolean   'ボラティリティスマイルａ(Call)
    Public VolatilitySmileACall As Decimal
    Public VolatilitySmileAPutEnabled As Boolean    'ボラティリティスマイルａ(Put)
    Public VolatilitySmileAPut As Decimal
    Public VolatilitySmileBCallEnabled As Boolean   'ボラティリティスマイルｂ(Call)
    Public VolatilitySmileBCall As Decimal
    Public VolatilitySmileBPutEnabled As Boolean    'ボラティリティスマイルｂ(Put)
    Public VolatilitySmileBPut As Decimal
    Public VolatilitySpreadEnabled As Boolean       'ボラティリティスプレッド
    Public VolatilitySpread As Decimal
    Public VolatilitySpreadITMCallEnabled As Boolean   'ボラティリティスプレッドITM(Call)
    Public VolatilitySpreadITMCall As Decimal
    Public VolatilitySpreadITMPutEnabled As Boolean    'ボラティリティスプレッドITM(Put)
    Public VolatilitySpreadITMPut As Decimal
    Public VolatilitySpreadOTMCallEnabled As Boolean   'ボラティリティスプレッドOTM(Call)
    Public VolatilitySpreadOTMCall As Decimal
    Public VolatilitySpreadOTMPutEnabled As Boolean    'ボラティリティスプレッドOTM(Put)
    Public VolatilitySpreadOTMPut As Decimal
    Public AskFeePriceCallEnabled As Boolean       '購入価格リスク(Call)
    Public AskFeePriceCall As Decimal
    Public AskFeePricePutEnabled As Boolean        '購入価格リスク(Put)
    Public AskFeePricePut As Decimal
    Public AskBidSpreadMinCallEnabled As Boolean       '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Call)
    Public AskBidSpreadMinCall As Decimal
    Public AskBidSpreadMinPutEnabled As Boolean        '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Put)
    Public AskBidSpreadMinPut As Decimal
    Public BidFeeRateCallEnabled As Boolean       '清算価格リスク(%)(Call)
    Public BidFeeRateCall As Decimal
    Public BidFeeRatePutEnabled As Boolean        '清算価格リスク(%)(Put)
    Public BidFeeRatePut As Decimal
    Public AskPriceMaxCallEnabled As Boolean        '最高購入価格(Call)
    Public AskPriceMaxCall As Decimal
    Public AskPriceMaxPutEnabled As Boolean         '最高購入価格(Put)
    Public AskPriceMaxPut As Decimal
    Public AskPriceMinCallEnabled As Boolean        '最低購入価格(Call)
    Public AskPriceMinCall As Decimal
    Public AskPriceMinPutEnabled As Boolean         '最低購入価格(Put)	
    Public AskPriceMinPut As Decimal
    Public BidPriceMaxCallEnabled As Boolean        '最高清算価格(Call)
    Public BidPriceMaxCall As Decimal
    Public BidPriceMaxPutEnabled As Boolean         '最高清算価格(Put)
    Public BidPriceMaxPut As Decimal
    Public BidPriceMinCallEnabled As Boolean        '最低清算価格(Call)
    Public BidPriceMinCall As Decimal
    Public BidPriceMinPutEnabled As Boolean         '最低清算価格(Put)	
    Public BidPriceMinPut As Decimal
    Public ExercStatus As String                    '行使ステータス
    Public ExercPriceStatus As String               '行使価格ステータス
    Public ExercRateSeqEnabled As Boolean           '行使時レートSeq
    Public ExercRateSeq As String
    Public ExercRateTimeEnabled As Boolean          '行使時レート時刻
    Public ExercRateTime As DateTime
    Public ExercRateEnabled As Boolean              '行使時レート
    Public ExercRate As Decimal
    Public ExercResultCall As String                '行使結果(Call)
    Public ExercResultPut As String                 '行使結果(Put)
    Public ExercResultCallName As String
    Public ExercResultPutName As String

    Public PAndL As Decimal             '損益
    Public Premium As Decimal           '取引金額

    Public ReadOnly Property ProductEnabledName() As String
        Get
            Return IIf(ProductEnabled = "1", "有効", "無効")
        End Get
    End Property

    Public ReadOnly Property ProductSubStatsuName() As String
        Get
            Return IIf(ProductSubStatus = "1", "除外行使価格", "通常")
        End Get
    End Property

    Public ReadOnly Property ExercResultCallStatusName() As String
        Get
            Select Case ExercResultCall
                Case "0" : Return ExercResultCallName = "未行使"
                Case "1" : Return ExercResultCallName = "ITM"
                Case "2" : Return ExercResultCallName = "OTM"
                Case "3" : Return ExercResultCallName = "ATM"
                Case Else : Return ExercResultCallName = ""
            End Select
        End Get
    End Property

    Public ReadOnly Property ExercResultPutStatusName() As String
        Get
            Select Case ExercResultPut
                Case "0" : Return ExercResultPutName = "未行使"
                Case "1" : Return ExercResultPutName = "ITM"
                Case "2" : Return ExercResultPutName = "OTM"
                Case "3" : Return ExercResultPutName = "ATM"
                Case Else : Return ExercResultPutName = ""
            End Select
        End Get
    End Property

End Class
