﻿Public Class SalesPerformanceData

    Public SysDate As DateTime
    Public AccountCount As Integer
    Public AccountCountEnabled As Integer
    Public NewAccountCount As Integer
    Public TradeAccountCount As Integer
    Public TradeCount As Integer
    Public TradeAmount As Decimal
    Public TotalMoney As Decimal
    Public TotalPAndL As Decimal
    Public CashInCount As Integer
    Public CashInMoney As Decimal
    Public CashOutCount As Integer
    Public CashOutMoney As Decimal

End Class
