﻿Public Class CalcParamData

    Public Property ComCode As String
    Public Property InterestRate As Decimal
    Public Property SwapRate As Decimal
    Public Property VolatilityAdjust As Decimal
    Public Property Volatility As Decimal
    Public Property DeltaVariation As Decimal
    Public Property GammaVariation As Decimal
    Public Property VegaVariation As Decimal
    Public Property ThetaVariation As Decimal
    Public Property RhoVariation As Decimal

    Public Function IsMatch(item As CalcParamData) As Boolean
        If ComCode <> item.ComCode Then Return False
        If InterestRate <> item.InterestRate Then Return False
        If SwapRate <> item.SwapRate Then Return False
        If VolatilityAdjust <> item.VolatilityAdjust Then Return False
        If Volatility <> item.Volatility Then Return False
        If DeltaVariation <> item.DeltaVariation Then Return False
        If GammaVariation <> item.GammaVariation Then Return False
        If VegaVariation <> item.VegaVariation Then Return False
        If ThetaVariation <> item.ThetaVariation Then Return False
        If RhoVariation <> item.RhoVariation Then Return False
        Return True
    End Function

End Class
