﻿Public Class TradeData
    Public TradeSeq As String
    Public SysDate As DateTime
    Public ProductCode As String
    Public ProductSubCode As String
    Public ComCode As String
    Public OpType As String
    Public PayoutRateEnabled As Boolean
    Public PayoutRate As Decimal
    Public CurCode As String
    Public TradeType As String
    Public PriceEnabled As Boolean
    Public Price As Decimal
    Public LotEnabled As Boolean
    Public Lot As Integer
    Public Premium As Decimal
    Public Commission As Decimal
    Public CustCode As String
    Public CmpCode As String
    Public TradeStatus As String
    Public OrderReqTimeEnabled As Boolean
    Public OrderReqTime As DateTime
    Public OrderClientRateSeq As String
    Public OrderClientRateTimeEnabled As Boolean
    Public OrderClientRateTime As DateTime
    Public OrderClientRateEnabled As Boolean
    Public OrderClientRate As Decimal
    Public AbandReqTimeEnabled As Boolean
    Public AbandReqTime As DateTime
    Public AbandClientRateSeq As String
    Public AbandClientRateTimeEnabled As Boolean
    Public AbandClientRateTime As DateTime
    Public AbandClientRateEnabled As Boolean
    Public AbandClientRate As Decimal
    Public TradeTimeEnabled As Boolean
    Public TradeTime As DateTime
    Public TradeRateSeq As String
    Public TradeRateTimeEnabled As Boolean
    Public TradeRateTime As DateTime
    Public TradeRateEnabled As Boolean
    Public TradeRate As Decimal
    Public TradeCalcTimeEnabled As Boolean
    Public TradeCalcTime As DateTime
    Public TradeVolatilityEnabled As Boolean
    Public TradeVolatility As Decimal
    Public ExercPriceEnabled As Boolean
    Public ExercPrice As Decimal
    Public ExercTimeEnabled As Boolean
    Public StartTimeEnabled As Boolean
    Public StartTime As DateTime
    Public ExercTime As DateTime
    Public ExercProcTimeEnabled As Boolean
    Public ExercProcTime As DateTime
    Public ExercRateSeq As String
    Public ExercRateTimeEnabled As Boolean
    Public ExercRateTime As DateTime
    Public ExercRateEnabled As Boolean
    Public ExercRate As Decimal
    Public ExercCalcTimeEnabled As Boolean
    Public ExercCalcTime As DateTime
    Public ExercVolatilityEnabled As Boolean
    Public ExercVolatility As Decimal
    Public ExercPayoutRateEnabled As Boolean
    Public ExercPayoutRate As Decimal
    Public PayoutPriceEnabled As Boolean
    Public PayoutPrice As Decimal
    Public PayoutEnabled As Boolean
    Public Payout As Decimal
    Public PAndLEnabled As Decimal
    Public PAndL As Decimal
    Public Memo As String
    Public InfoTitle As String
    Public Info As String
    Public ClientType As String

    Public ReadOnly Property TradeTypeName()
        Get
            For Each item As TradeTypeManager In TradeTypeManager.list
                If item.Code = TradeType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

    Public ReadOnly Property TradeStatusName()
        Get
            For Each item As TradeStatusManager In TradeStatusManager.List
                If item.Code = TradeStatus Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
