﻿Public Class PriceChartHistData

    Public PriceChartSeq As String          'プライスチャートSeq
    Public Enabled As String                '有効フラグ
    Public ComCode As String                '通貨ペアコード
    Public ChartType As String              'チャート種別
    Public RateSeq As String                'レートSeq
    Public PriceChartTime As DateTime       'プライスチャート日時
    Public OpenAskPriceCall As Decimal      '開始購入価格(Call)
    Public HighAskPriceCall As Decimal      '最高購入価格(Call)
    Public LowAskPriceCall As Decimal       '最低購入価格(Call)
    Public CloseAskPriceCall As Decimal     '終了購入価格(Call)
    Public OpenAskPricePut As Decimal       '開始購入価格(Put)
    Public HighAskPricePut As Decimal       '最高購入価格(Put)
    Public LowAskPricePut As Decimal        '最低購入価格(Put)
    Public CloseAskPricePut As Decimal      '終了購入価格(Put)
    Public OpenBidPriceCall As Decimal      '開始清算価格(Call)
    Public HighBidPriceCall As Decimal      '最高清算価格(Call)
    Public LowBidPriceCall As Decimal       '最低清算価格(Call)
    Public CloseBidPriceCall As Decimal     '終了清算価格(Call)
    Public OpenBidPricePut As Decimal       '開始清算価格(Put)
    Public HighBidPricePut As Decimal      '最高清算価格(Put)
    Public LowBidPricePut As Decimal        '最低清算価格(Put)
    Public CloseBidPricePut As Decimal      '終了清算価格(Put)
    Public CloseTime As DateTime            '終了日時
    Public ProductCode As String            '銘柄コード
    Public ProductSubCode As String         '銘柄サブコード

    Public ReadOnly Property EnabledName() As String
        Get
            Return IIf(Enabled = "1", "有効", "無効")
        End Get
    End Property

    Public ReadOnly Property ChartName() As String
        Get
            Dim retChartName As String = ""

            Select Case ChartType
                Case "1"
                    retChartName = "１分足"
            End Select

            Return retChartName
        End Get
    End Property

End Class
