﻿Public Class FileDownloadData

    Public Property FileType As String
    Public Property SysDate As String
    Public Property CmpCode As String
    Public Property FileName As String
    Public Property FileSize As Long

    Public Function IsMatch(item As FileDownloadData) As Boolean
        If FileType <> item.FileType Then Return False
        If SysDate <> item.SysDate Then Return False
        If CmpCode <> item.CmpCode Then Return False
        If FileName <> item.FileName Then Return False
        If FileSize <> item.FileSize Then Return False
        Return True
    End Function

End Class
