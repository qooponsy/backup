﻿Public Class CashData
    Public CashCode As String
    Public TradeSeq As String   '■■ついか
    Public Enabled As String
    Public SysDate As DateTime
    Public ExecTime As DateTime
    Public CustCode As String
    Public CmpCode As String
    Public ComCode As String
    Public CashType As String
    Public CurCode As String
    Public Money As Decimal
    Public TotalMoney As Decimal

    Public ReadOnly Property EnabledName()
        Get
            For Each item As EnabledFlagManager In EnabledFlagManager.List
                If item.Code = Enabled Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

    Public ReadOnly Property CashTypeName()
        Get
            For Each item As CashTypeManager In CashTypeManager.List
                If item.Code = CashType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
