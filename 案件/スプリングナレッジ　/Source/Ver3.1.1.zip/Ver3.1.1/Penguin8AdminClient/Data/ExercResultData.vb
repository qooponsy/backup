﻿Public Class ExercResultData

    Public ProductCode As String
    Public ProductSubCode As String
    Public ProductName As String
    Public TradeType As String
    Public ComCode As String
    Public OpType As String
    Public StartTime As DateTime
    Public ExercTime As DateTime
    Public ExercPrice As Decimal
    Public ExercRate As Decimal
    Public ExercRateTimeEnabled As Boolean  'add 201405 fukushima@fate-i
    Public ExercRateTime As DateTime        'add 201405 fukushima@fate-i
    Public ResultTime As DateTime
    Public ExercResult As String
    Public PayoutPriceEnabled As Boolean
    Public PayoutPrice As Decimal

    Public ReadOnly Property OpTypeStatsuName() As String
        Get
            Return IIf(OpType = "01", "ハイ・ロー", "ラダー")
        End Get
    End Property

    Public ReadOnly Property ExercReslutStatsuName() As String
        Get
            Select Case ExercResult
                Case 1
                    Return "ITM"
                Case 2
                    Return "OTM"
                Case 3
                    Return "ATM"
            End Select

            Return ""
        End Get
    End Property

End Class
