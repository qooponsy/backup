﻿Public Class OptionInfoData
    Public Property OpType As String
    Public Property OpName As String
    Public Property CallName As String
    Public Property PutName As String

    Public Function IsMatch(item As OptionInfoData) As Boolean
        If OpType <> item.OpType Then Return False
        If OpName <> item.OpName Then Return False
        If CallName <> item.CallName Then Return False
        If PutName <> item.PutName Then Return False
        Return True
    End Function

End Class
