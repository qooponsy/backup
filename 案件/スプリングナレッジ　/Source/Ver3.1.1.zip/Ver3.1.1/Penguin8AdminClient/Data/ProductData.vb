﻿Public Class ProductData

    Public Property ProductCode As String        '銘柄コード
    Public ProductEnabled As String     '有効フラグ
    Public ProductBaseCode As String    '銘柄設定コード
    Public SysDate As DateTime          'システム営業日
    Public ComCode As String            '通貨ペア
    Public OpType As String             'オプション種別
    Public StartTime As DateTime        '取引開始時間
    Public ExercTime As DateTime        '行使期日
    Public TradeLimitTime As DateTime   '取引可能期日
    Public PayoutRateEnabled As Boolean             'ペイアウト率
    Public PayoutRate As Decimal
    Public ExercPriceTimespanEnabled As Boolean     '行使価格決定時間
    Public ExercPriceTimespan As Integer
    Public ExercPriceRateSeqEnabled As Boolean      '行使価格決定時レートSeq
    Public ExercPriceRateSeq As String
    Public ExercPriceRateEnabled As Boolean         '行使価格決定時レート
    Public ExercPriceRate As Decimal
    Public ExercPriceUnitTypeEnabled As Boolean     '行使価格刻み幅種別
    Public ExercPriceUnitType As String
    Public ExercPriceUnitEnabled As Boolean         '行使価格刻み幅
    Public ExercPriceUnit As Decimal
    Public ExercPriceSettingsEnabled As Boolean     '行使価格設定
    Public ExercPriceSettings As String
    Public ExceptExercPriceEnabled As Boolean       '除外行使価格
    Public ExceptExercPrice As String
    Public VolatilityRatio1CallEnabled As Boolean   'ボラティリティレシオ１(Call)
    Public VolatilityRatio1Call As Decimal
    Public VolatilityRatio1PutEnabled As Boolean    'ボラティリティレシオ１(Put)
    Public VolatilityRatio1Put As Decimal
    Public VolatilityRatio2CallEnabled As Boolean   'ボラティリティレシオ２(Call)
    Public VolatilityRatio2Call As Decimal
    Public VolatilityRatio2PutEnabled As Boolean    'ボラティリティレシオ２(Put)
    Public VolatilityRatio2Put As Decimal
    Public VolatilitySmileACallEnabled As Boolean   'ボラティリティスマイルａ(Call)
    Public VolatilitySmileACall As Decimal
    Public VolatilitySmileAPutEnabled As Boolean    'ボラティリティスマイルａ(Put)
    Public VolatilitySmileAPut As Decimal
    Public VolatilitySmileBCallEnabled As Boolean   'ボラティリティスマイルｂ(Call)
    Public VolatilitySmileBCall As Decimal
    Public VolatilitySmileBPutEnabled As Boolean    'ボラティリティスマイルｂ(Put)
    Public VolatilitySmileBPut As Decimal
    Public VolatilitySpreadEnabled As Boolean       'ボラティリティスプレッド
    Public VolatilitySpread As Decimal
    Public VolatilitySpreadITMCallEnabled As Boolean   'ボラティリティスプレッドITM(Call)
    Public VolatilitySpreadITMCall As Decimal
    Public VolatilitySpreadITMPutEnabled As Boolean    'ボラティリティスプレッドITM(Put)
    Public VolatilitySpreadITMPut As Decimal
    Public VolatilitySpreadOTMCallEnabled As Boolean   'ボラティリティスプレッドOTM(Call)
    Public VolatilitySpreadOTMCall As Decimal
    Public VolatilitySpreadOTMPutEnabled As Boolean    'ボラティリティスプレッドOTM(Put)
    Public VolatilitySpreadOTMPut As Decimal
    Public AskFeePriceCallEnabled As Boolean       '購入価格リスク(Call)
    Public AskFeePriceCall As Decimal
    Public AskFeePricePutEnabled As Boolean        '購入価格リスク(Put)
    Public AskFeePricePut As Decimal
    Public AskBidSpreadMinCallEnabled As Boolean       '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Call)
    Public AskBidSpreadMinCall As Decimal
    Public AskBidSpreadMinPutEnabled As Boolean        '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Put)
    Public AskBidSpreadMinPut As Decimal
    Public BidFeeRateCallEnabled As Boolean       '清算価格リスク(%)(Call)
    Public BidFeeRateCall As Decimal
    Public BidFeeRatePutEnabled As Boolean        '清算価格リスク(%)(Put)
    Public BidFeeRatePut As Decimal
    Public AskPriceMaxCallEnabled As Boolean        '最高購入価格(Call)
    Public AskPriceMaxCall As Decimal
    Public AskPriceMaxPutEnabled As Boolean         '最高購入価格(Put)
    Public AskPriceMaxPut As Decimal
    Public AskPriceMinCallEnabled As Boolean        '最低購入価格(Call)
    Public AskPriceMinCall As Decimal
    Public AskPriceMinPutEnabled As Boolean         '最低購入価格(Put)	
    Public AskPriceMinPut As Decimal
    Public BidPriceMaxCallEnabled As Boolean        '最高清算価格(Call)
    Public BidPriceMaxCall As Decimal
    Public BidPriceMaxPutEnabled As Boolean         '最高清算価格(Put)
    Public BidPriceMaxPut As Decimal
    Public BidPriceMinCallEnabled As Boolean        '最低清算価格(Call)
    Public BidPriceMinCall As Decimal
    Public BidPriceMinPutEnabled As Boolean         '最低清算価格(Put)	
    Public BidPriceMinPut As Decimal
    Public ExercStatus As String                    '行使ステータス
    Public ExercPriceStatus As String               '行使価格ステータス
    Public ExercRateSeqEnabled As Boolean           '行使時レートSeq
    Public ExercRateSeq As String
    Public ExercRateEnabled As Boolean              '行使時レート
    Public ExercRate As Decimal

    Public PAndL As Decimal             '損益
    Public Premium As Decimal           '取引金額

    ''' <summary>[T_RateHistTick]からレートを取得するらしいが、とりあえず0.0を戻すだけ</summary>
    Public Shared Function getRate() As Decimal
        Dim ret As Decimal = 0.0

        Return ret
    End Function

    'T_RateHistTickの日付を利用するが、とりあえずNowで作成
    ''' <summary>「hhhh時間mm分ss秒」形式で残存期間文字列の作成</summary>
    Public Shared Function getResidualTime(ByVal DateDiffSecond As Long) As String
        Dim ret As String = ""

        Dim secondLong As Long = 0
        Dim minutesLong As Long = 0
        Dim hourLong As Long = 0

        If DateDiffSecond > 0 Then
            '秒の算出
            secondLong = DateDiffSecond Mod (60 * 60)   '時の除去
            secondLong = secondLong Mod 60              '分の除去

            '分の算出
            minutesLong = DateDiffSecond - secondLong   '秒の除去
            minutesLong = minutesLong Mod (60 * 60)     '時の除去
            minutesLong = minutesLong / 60              '分の算出

            '時の算出
            hourLong = DateDiffSecond - secondLong - (minutesLong * 60) '分・秒の除去
            hourLong = hourLong / (60 * 60)                             '時の算出
        End If

        ret = Right(Space(4) & CStr(hourLong), 4) & "時間" & Right("00" & CStr(minutesLong), 2) & "分" & Right("00" & CStr(secondLong), 2) & "秒"

        Return ret
    End Function

    Public ReadOnly Property ProductEnabledName() As String
        Get
            Return IIf(ProductEnabled = "1", "有効", "無効")
        End Get
    End Property

    Public ReadOnly Property OpTypeName() As String
        Get
            Dim ret As String = ""
            Select Case OpType
                Case "01" : ret = "ハイロー"
                Case "02" : ret = "ラダー"
                Case Else
            End Select
            Return ret
        End Get
    End Property

    Public ReadOnly Property ExercStatusName() As String
        Get
            Dim ret As String = ""
            Select Case ExercStatus
                Case "0" : ret = "未行使"
                Case "1" : ret = "行使処理中"
                Case "2" : ret = "行使済み"
                Case "3" : ret = "行使処理失敗"
                Case Else
            End Select
            Return ret
        End Get
    End Property

    Public ReadOnly Property ExercPriceStatsuName() As String
        Get
            Dim ret As String = ""
            Select Case ExercPriceStatus
                Case "0" : ret = "行使価格未定"
                Case "1" : ret = "行使価格決定"
                Case "2" : ret = "行使価格エラー"
                Case Else
            End Select

            Return ret
        End Get
    End Property

    Public ReadOnly Property ExercTimeDisp() As String
        Get
            Return ExercTime.ToString("yyyy/MM/dd HH:mm")
        End Get
    End Property

End Class
