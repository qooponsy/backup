﻿Public Class ProductBaseData

    Public Class EnabledCode
        Public Const Enabled As String = "1"
        Public Const Visible As String = "0"
    End Class

    Public ProductBaseCode As String    '銘柄設定コード
    Public ProductBaseEnabled As String '有効フラグ
    Public ComCode As String            '通貨ペア
    Public OpType As String             'オプション種別
    Public OptionTime As Integer        'オプション期間
    Public CreateTime As Integer        '生成間隔
    Public StartTime As TimeSpan        '生成開始時間
    Public ExercTime As TimeSpan        '最終行使期日
    Public PayoutRateEnabled As Boolean             'ペイアウト率
    Public PayoutRate As Decimal
    Public ExercPriceTimespanEnabled As Boolean     '行使価格決定時間
    Public ExercPriceTimespan As Integer
    Public ExercPriceUnitTypeEnabled As Boolean     '行使価格刻み幅種別
    Public ExercPriceUnitType As String
    Public ExercPriceUnitEnabled As Boolean         '行使価格刻み幅
    Public ExercPriceUnit As Decimal
    Public ExercPriceSettingsEnabled As Boolean     '行使価格設定
    Public ExercPriceSettings As String
    Public ExceptExercPriceEnabled As Boolean       '除外行使価格
    Public ExceptExercPrice As String
    Public VolatilityRatio1CallEnabled As Boolean   'ボラティリティレシオ１(Call)
    Public VolatilityRatio1Call As Decimal
    Public VolatilityRatio1PutEnabled As Boolean    'ボラティリティレシオ１(Put)
    Public VolatilityRatio1Put As Decimal
    Public VolatilityRatio2CallEnabled As Boolean   'ボラティリティレシオ２(Call)
    Public VolatilityRatio2Call As Decimal
    Public VolatilityRatio2PutEnabled As Boolean    'ボラティリティレシオ２(Put)
    Public VolatilityRatio2Put As Decimal
    Public VolatilitySmileACallEnabled As Boolean   'ボラティリティスマイルａ(Call)
    Public VolatilitySmileACall As Decimal
    Public VolatilitySmileAPutEnabled As Boolean    'ボラティリティスマイルａ(Put)
    Public VolatilitySmileAPut As Decimal
    Public VolatilitySmileBCallEnabled As Boolean   'ボラティリティスマイルｂ(Call)
    Public VolatilitySmileBCall As Decimal
    Public VolatilitySmileBPutEnabled As Boolean    'ボラティリティスマイルｂ(Put)
    Public VolatilitySmileBPut As Decimal
    Public VolatilitySpreadEnabled As Boolean       'ボラティリティスプレッド
    Public VolatilitySpread As Decimal
    Public VolatilitySpreadITMCallEnabled As Boolean   'ボラティリティスプレッドITM(Call)
    Public VolatilitySpreadITMCall As Decimal
    Public VolatilitySpreadITMPutEnabled As Boolean    'ボラティリティスプレッドITM(Put)
    Public VolatilitySpreadITMPut As Decimal
    Public VolatilitySpreadOTMCallEnabled As Boolean   'ボラティリティスプレッドOTM(Call)
    Public VolatilitySpreadOTMCall As Decimal
    Public VolatilitySpreadOTMPutEnabled As Boolean    'ボラティリティスプレッドOTM(Put)
    Public VolatilitySpreadOTMPut As Decimal
    Public AskFeePriceCallEnabled As Boolean       '購入価格リスク(Call)
    Public AskFeePriceCall As Decimal
    Public AskFeePricePutEnabled As Boolean        '購入価格リスク(Put)
    Public AskFeePricePut As Decimal
    Public AskBidSpreadMinCallEnabled As Boolean       '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Call)
    Public AskBidSpreadMinCall As Decimal
    Public AskBidSpreadMinPutEnabled As Boolean        '購入清算価格最小ｽﾌﾟﾚｯﾄﾞﾘｽｸ(Put)
    Public AskBidSpreadMinPut As Decimal
    Public BidFeeRateCallEnabled As Boolean       '清算価格リスク(%)(Call)
    Public BidFeeRateCall As Decimal
    Public BidFeeRatePutEnabled As Boolean        '清算価格リスク(%)(Put)
    Public BidFeeRatePut As Decimal
    Public AskPriceMaxCallEnabled As Boolean        '最高購入価格(Call)
    Public AskPriceMaxCall As Decimal
    Public AskPriceMaxPutEnabled As Boolean         '最高購入価格(Put)
    Public AskPriceMaxPut As Decimal
    Public AskPriceMinCallEnabled As Boolean        '最低購入価格(Call)
    Public AskPriceMinCall As Decimal
    Public AskPriceMinPutEnabled As Boolean         '最低購入価格(Put)	
    Public AskPriceMinPut As Decimal
    Public BidPriceMaxCallEnabled As Boolean        '最高清算価格(Call)
    Public BidPriceMaxCall As Decimal
    Public BidPriceMaxPutEnabled As Boolean         '最高清算価格(Put)
    Public BidPriceMaxPut As Decimal
    Public BidPriceMinCallEnabled As Boolean        '最低清算価格(Call)
    Public BidPriceMinCall As Decimal
    Public BidPriceMinPutEnabled As Boolean         '最低清算価格(Put)	
    Public BidPriceMinPut As Decimal

    Public Shared Function cnvOpType(ByVal OpType As String) As String
        Dim ret As String = ""
        Select Case OpType
            Case "01" : ret = "ハイ・ロー"
            Case "02" : ret = "ラダー"
            Case Else
        End Select

        Return ret
    End Function

    Public Function EnabledName() As String
        Dim ret As String = ""
        Select Case Me.ProductBaseEnabled
            Case EnabledCode.Enabled : ret = "有効"
            Case Else
        End Select

        Return ret
    End Function

End Class
