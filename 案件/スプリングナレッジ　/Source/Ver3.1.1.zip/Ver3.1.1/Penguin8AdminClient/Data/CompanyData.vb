﻿Public Class CompanyData
    Public Property CmpCode As String
    Public Property CmpName As String
    Public Property CmpNameAnother As String

    Public Function IsMatch(item As CompanyData) As Boolean
        If CmpCode <> item.CmpCode Then Return False
        If CmpName <> item.CmpName Then Return False
        If CmpNameAnother <> item.CmpNameAnother Then Return False
        Return True
    End Function

End Class
