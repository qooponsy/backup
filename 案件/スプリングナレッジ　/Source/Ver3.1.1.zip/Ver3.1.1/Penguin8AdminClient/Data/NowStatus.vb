﻿Public Class NowStatus

    Public GetDBTime As DateTime
    Public SysDate As Date
    Public SysEnabled As String
    Public AbandEnabled As String
    Public CashOutEnabled As String
    Public CashInEnabled As String
    Public ProductStatusStatus As Integer
    Public ProductStatusNextTime As DateTime
    Public AccountCount As Integer
    Public AccountCountEnabled As Integer
    Public NewAccountCount As Integer
    Public TradeAccountCount As Integer
    Public TradeCount As Integer
    Public TradeAmount As Decimal
    Public TotalMoney As Decimal
    Public TotalPAndL As Decimal
    Public CashInCount As Integer
    Public CashInMoney As Decimal
    Public CashOutCount As Integer
    Public CashOutMoney As Decimal
    Public LoginAdminCount As Integer
    Public LoginCustCount As Integer

End Class
