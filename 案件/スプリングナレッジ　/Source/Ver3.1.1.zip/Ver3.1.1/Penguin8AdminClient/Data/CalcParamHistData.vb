﻿Public Class CalcParamHistData

    Public Property SysDate As Date
    Public Property ComCode As String
    Public Property InterestRate As Decimal
    Public Property SwapRate As Decimal
    Public Property VolatilityAdjust As Decimal
    Public Property Volatility As Decimal
    Public Property DeltaVariation As Decimal
    Public Property GammaVariation As Decimal
    Public Property VegaVariation As Decimal
    Public Property ThetaVariation As Decimal
    Public Property RhoVariation As Decimal

End Class
