﻿Public Class CurrencyPairData
    Public Property ComCode As String
    Public Property ComName As String
    Public Property DecimalPlaces As Integer
    Public Property SortOrder As Integer
    Public Property ExcgComCode As String

    Public Function IsMatch(item As CurrencyPairData)
        If ComCode <> item.ComCode Then Return False
        If ComName <> item.ComName Then Return False
        If DecimalPlaces <> item.DecimalPlaces Then Return False
        If SortOrder <> item.SortOrder Then Return False
        If ExcgComCode <> item.ExcgComCode Then Return False

        Return True
    End Function

End Class

