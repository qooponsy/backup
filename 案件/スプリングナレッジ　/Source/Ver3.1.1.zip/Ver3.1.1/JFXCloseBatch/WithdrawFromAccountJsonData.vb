﻿Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json

Public Class WithdrawFromAccountJsonData

    Public Property returnCode As Integer
    Public Property description As String

End Class
