﻿Imports System.Collections.Specialized
Imports System.IO
Imports System.Text
Imports System.Windows.Forms
Imports System.Security.Cryptography
Imports System.Net
Imports System.Runtime.Serialization.Json

Module JFXCloseBatch

    Sub Main()

        'csvの相対パス
        Dim path As String = "csv\JFXUser.csv"
        Dim objFile As StreamReader = Nothing

        Dim strLine As String   '1行
        Dim strTemp() As String '戻り配列

        Dim success As Boolean = True
        Try
            objFile = New StreamReader(path)
        Catch ex As Exception
            MessageBox.Show("csvファイルの読み込みに失敗しました" & vbCrLf & ex.Message)
            success = False
        End Try


        'ファイル読み込みに成功していれば出金処理
        If success Then

            'データ読み込み開始
            strLine = objFile.ReadLine()

            Dim traderID As String = ""
            Dim amount As String = ""

            '1行目はヘッダなので読み込まない
            strLine = objFile.ReadLine()
            While success AndAlso (strLine <> "")
                Try
                    '行単位データをカンマ部分で分割し、配列へ格納
                    strTemp = Split(strLine, ",")

                    traderID = strTemp(0)
                    amount = strTemp(1)

                    Dim ValueList As New NameValueCollection
                    Dim QueryList As New List(Of KeyValuePair(Of String, String))
                    SetQueryParam(ValueList, QueryList, "traderID", traderID)
                    SetQueryParam(ValueList, QueryList, "amount", amount)

                    '出金リクエスト
                    Dim res As WithdrawFromAccountJsonData
                    res = Request("Account/WithdrawFromAccount", ValueList, QueryList)

                    If res.returnCode <> 0 Then
                        MessageBox.Show("ReturnCode:" & res.returnCode & vbCrLf &
                                        "ID:" & traderID & vbCrLf &
                                        res.description)
                        success = False
                    End If

                    '次の行へ
                    strLine = objFile.ReadLine()

                Catch ex As Exception
                    MessageBox.Show("ID:" & traderID & "の処理中にエラーが発生" & vbCrLf & ex.Message)
                    success = False
                End Try

            End While

        End If

    End Sub

    Private Sub SetQueryParam(ValueList As NameValueCollection, QueryList As List(Of KeyValuePair(Of String, String)), Name As String, Value As String)
        ValueList.Add(Name, Value)
        QueryList.Add(New KeyValuePair(Of String, String)(Name, Value))
    End Sub

    Private Function Request(PageAddress As String, ValueList As NameValueCollection, QueryList As List(Of KeyValuePair(Of String, String))) As WithdrawFromAccountJsonData
        Dim ret As WithdrawFromAccountJsonData = Nothing

        Try
            Dim QueryString As New StringBuilder
            Dim Delimiter As String = ""
            For Each item As KeyValuePair(Of String, String) In QueryList
                If Not item.Value Is Nothing Then
                    QueryString.AppendFormat("{0}{1}={2}", Delimiter, item.Key, item.Value)
                    Delimiter = "&"
                End If
            Next

            Dim CRCKey As String = My.Settings.CRCKey
            Dim passbin As Byte() = Encoding.UTF8.GetBytes(CRCKey & QueryString.ToString())
            Dim md5 As New MD5CryptoServiceProvider()
            Dim passhash As Byte() = md5.ComputeHash(passbin)
            Dim passstr As String = BitConverter.ToString(passhash).ToUpper().Replace("-", "")
            ValueList.Add("CRC", passstr)

            Dim client As New WebClient
            client.BaseAddress = My.Settings.RequestURL

            Dim resdata As Byte() = client.UploadValues(PageAddress, ValueList)

            'リクエスト結果を取得
            Dim returnText As String = Encoding.UTF8.GetString(resdata)

            'デシリアライズ
            ret = Deserialize(Of WithdrawFromAccountJsonData)(returnText)

        Catch ex As Exception
            MessageBox.Show("リクエスト処理で失敗しました" & vbCrLf & ex.Message)
            ret = Nothing
        End Try

        Return ret
    End Function

    Private Function Deserialize(Of WithdrawFromAccountJsonData)(json As String) As WithdrawFromAccountJsonData
        Dim ret As WithdrawFromAccountJsonData = Nothing

        Dim serializer As New DataContractJsonSerializer(GetType(WithdrawFromAccountJsonData))
        Dim stream As New MemoryStream(Encoding.UTF8.GetBytes(json))

        ret = DirectCast(serializer.ReadObject(stream), WithdrawFromAccountJsonData)

        Return ret
    End Function

End Module
