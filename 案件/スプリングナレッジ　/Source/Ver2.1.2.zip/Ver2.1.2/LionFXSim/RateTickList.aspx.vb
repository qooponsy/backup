﻿Imports System.Data.SqlClient

Public Class RateTickList
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim reqComCode As String = Request("comcode")

        Dim success As Boolean = False
        Dim result As New ResResult
        Dim list As New List(Of List(Of Object))

        Do
            If reqComCode Is Nothing OrElse reqComCode.Length <> 6 Then
                result.Code = "X00001"
                result.Text = "通貨ペアコードの指定が間違っています。"
                Exit Do
            End If
            Select Case reqComCode
                Case "EURUSD"
                Case "USDJPY"
                Case "EURJPY"
                Case "GBPUSD"
                Case "GBPJPY"
                Case "AUDJPY"
                Case Else
                    result.Code = "X00001"
                    result.Text = "通貨ペアコードの指定が間違っています。"
                    Exit Do
            End Select
            Dim ComCode As String = reqComCode

            Using con As New SqlConnection(My.Settings.DB)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [Rate] where [ComCode] = @ComCode order by [RowID]"
                    cmd.Parameters.Add("@ComCode", SqlDbType.Char, 6).Value = ComCode
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read
                            Dim line As New List(Of Object)
                            line.Add(reader("RowID"))
                            line.Add(reader("ProviderID"))
                            line.Add(reader("Bid"))
                            line.Add(reader("Ask"))
                            line.Add(reader("RateTime"))
                            list.Add(line)
                        End While
                    End Using
                End Using
            End Using

            success = True
        Loop While False

        Dim res As New ResBuilder
        res.result = result
        If success Then
            res.Append(list)
        End If

        Response.Write(res.GetResponse())
    End Sub

End Class