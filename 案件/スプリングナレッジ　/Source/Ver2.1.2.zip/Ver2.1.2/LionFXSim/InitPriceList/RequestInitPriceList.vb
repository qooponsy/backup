﻿Imports System.Runtime.Serialization

<DataContract()> _
Public Class RequestInitPriceList

    <DataMember()> _
    Public symbolCode As String() = Nothing
    <DataMember()> _
    Public companyId As String = Nothing
    <DataMember()> _
    Public channel As String = Nothing
    <DataMember()> _
    Public locale As String = Nothing
    <DataMember()> _
    Public sessionId As String = Nothing

End Class
