﻿Imports System.Net
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json
Imports System.IO

Public Class TickChartServlet_IIJ
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim success As Boolean = False
        Dim reqObj As New RequestInitPriceList
        Dim resObj As New ResponseInitPriceList
        Dim DataCount As Integer = 0
        Dim errorMsg As String = ""

        'エラーブレイク構造
        While True

            If Request.InputStream.Length = 0 Then

                errorMsg = "リクエストパラメータがありません"
                Exit While

            End If

            Dim reqSr As New DataContractJsonSerializer(GetType(RequestInitPriceList))

            reqObj = reqSr.ReadObject(Request.InputStream)

            Using con As New SqlConnection(My.Settings.DB)
                con.Open()
                ReDim resObj.priceAndQuotationDtos(reqObj.symbolCode.Length - 1)
                For Each sCode In reqObj.symbolCode
                    Using cmd As SqlCommand = con.CreateCommand
                        cmd.CommandText = String.Format("select * from [RateIIJ] with (nolock) where [symbolCode] = {0}", sCode)

                        Using reader As SqlDataReader = cmd.ExecuteReader()
                            While reader.Read
                                Dim res As New ResponsePriceAndQuotationDto
                                res.symbolCode = reader("symbolCode")
                                res.seq = reader("seq")
                                res.bidRate = reader("bidRate")
                                res.askRate = reader("askRate")
                                res.changeRatio = reader("changeRatio")
                                res.openPrice = reader("openPrice")
                                res.highPrice = reader("highPrice")
                                res.lowPrice = reader("lowPrice")
                                res.highTime = reader("highTime")
                                res.lowTime = reader("lowTime")
                                res.previousClosePrice = reader("previousClosePrice")
                                res.autoTime = reader("autoTime")
                                If res.autoTime = "1" Then
                                    res.calcTime = DateTime.Now.ToString("yyyy.MM.dd.HH.mm.ss.fff")
                                Else
                                    res.calcTime = reader("calcTime")
                                End If
                                resObj.priceAndQuotationDtos(DataCount) = res
                                DataCount += 1
                                Debug.WriteLine("symbolCode：" + res.symbolCode + vbTab + "seq：" + res.seq + vbTab + "bidRate：" + res.bidRate + vbTab + "askRate：" + res.askRate)
                            End While
                        End Using
                    End Using
                Next
                
            End Using

            success = True
            Exit While

        End While

        If success Then

            resObj.result = "OK"
            resObj.message = ""
            resObj.operationNumber = ""
            resObj.priceAndQuotationDtosCnt = DataCount

        Else
            resObj.result = "NG"
            resObj.message = errorMsg
        End If
        Response.ContentType = "application/json; charset=UTF-8"
        Dim resSr As New DataContractJsonSerializer(GetType(ResponseInitPriceList))
        resSr.WriteObject(Response.OutputStream, resObj)

    End Sub


    ''' <summary>
    ''' ストリームからデータを読み込み
    ''' </summary>
    ''' <param name="st"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ReadBinaryData(ByVal st As Stream) As Byte()

        Dim buf(32768) As Byte ' 一時バッファ

        Using ms As New MemoryStream()

            While (True)
                ' ストリームから一時バッファに読み込む
                Dim read As Integer = st.Read(buf, 0, buf.Length)

                If read > 0 Then
                    ' 一時バッファの内容をメモリ・ストリームに書き込む
                    ms.Write(buf, 0, read)
                Else
                    Exit While
                End If
            End While

            ' メモリ・ストリームの内容をバイト配列に格納
            Return ms.ToArray

        End Using
    End Function

End Class