﻿Public Class ResResult

    Public Code As String = vbNullString
    Public Text As String = vbNullString

End Class
