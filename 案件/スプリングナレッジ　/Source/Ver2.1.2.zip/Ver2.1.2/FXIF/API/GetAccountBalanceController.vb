﻿Imports System.IO
Imports System.Text
Imports System.Web
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json
Imports System.Web.Mvc

Namespace FXIF
    Public Class GetAccountBalanceController
        Implements IController

        Public Sub Execute(requestContext As System.Web.Routing.RequestContext) Implements System.Web.Mvc.IController.Execute
            Dim Request As HttpRequestBase = requestContext.HttpContext.Request
            Dim Response As HttpResponseBase = requestContext.HttpContext.Response

            Dim QueryList As New List(Of KeyValuePair(Of String, String))
            Dim reqTraderID As String = CheckUtil.SetQueryParam(QueryList, Request, "traderID")
            Dim reqTimestamp As String = CheckUtil.SetQueryParam(QueryList, Request, "timestamp")
            Dim reqCRC As String = Request("CRC")

            Dim success As Boolean = False
            Dim returnCode As Integer = 99
            Dim description As String = "System Maintenance"
            Dim balance As Decimal

            Try
                Do
                    'テスト用ロジック
                    If My.Settings.TestCode <> 0 Then
                        returnCode = My.Settings.TestCode
                        description = My.Settings.TestMessage
                        Exit Do
                    End If

                    If reqCRC Is Nothing OrElse reqCRC.Length = 0 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    If Not CheckUtil.CheckCRC(QueryList, reqCRC) Then
                        returnCode = 6
                        description = "Sent CRC does not match the server"
                        Exit Do
                    End If

                    If reqTraderID Is Nothing OrElse reqTraderID.Length = 0 OrElse reqTraderID.Length > 32 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    Dim DBSuccess As Boolean = False
                    Dim DBConnStr As String = My.Settings.DB
                    Try
                        Using con As New SqlConnection(DBConnStr)
                            con.Open()
                            Using cmd As SqlCommand = con.CreateCommand
                                cmd.CommandText = "select [TotalMoney] from [T_CashSpot] where [CustCode]=@CustCode"
                                cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                                Dim TotalMoneyValue As Object = cmd.ExecuteScalar()
                                If TotalMoneyValue Is Nothing OrElse IsDBNull(TotalMoneyValue) Then
                                    returnCode = 1
                                    description = "No account was found with given id"
                                    Exit Do
                                End If
                                balance = TotalMoneyValue
                            End Using
                        End Using

                        returnCode = 0
                        description = "Successful call"
                        success = True
                        SystemLog.DBSuccess(DBConnStr)
                        DBSuccess = True
                    Catch ex As Exception
                        SystemLog.DBError(DBConnStr, ex)
                    End Try
                Loop While False
            Catch ex As Exception
                SystemLog.AppError(ex)
            End Try

            Dim res As New GetAccountBalanceJsonData
            Dim serializer As New DataContractJsonSerializer(GetType(GetAccountBalanceJsonData))

            res.returnCode = returnCode
            res.description = description

            If success Then
                res.balance = balance
            End If

            Dim ms As New MemoryStream
            serializer.WriteObject(ms, res)
            ms.Position = 0
            Dim sr As New StreamReader(ms)
            Response.ContentType = "application/json"
            Response.Charset = "utf-8"
            Response.Write(sr.ReadToEnd())
        End Sub
    End Class
End Namespace