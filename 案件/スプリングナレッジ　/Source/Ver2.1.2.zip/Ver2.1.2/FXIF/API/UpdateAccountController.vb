﻿Imports System.IO
Imports System.Text
Imports System.Web
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json
Imports System.Web.Mvc

Namespace FXIF
    Public Class UpdateAccountController
        Implements IController

        Public Sub Execute(requestContext As System.Web.Routing.RequestContext) Implements System.Web.Mvc.IController.Execute
            Dim Request As HttpRequestBase = requestContext.HttpContext.Request
            Dim Response As HttpResponseBase = requestContext.HttpContext.Response

            Dim QueryList As New List(Of KeyValuePair(Of String, String))
            Dim reqUsername As String = CheckUtil.SetQueryParam(QueryList, Request, "username")
            Dim reqTraderID As String = CheckUtil.SetQueryParam(QueryList, Request, "traderID")
            Dim reqCRC As String = Request("CRC")

            Dim success As Boolean = False
            Dim returnCode As Integer = 99
            Dim description As String = "System Maintenance"

            Try
                Do
                    'テスト用ロジック
                    If My.Settings.TestCode <> 0 Then
                        returnCode = My.Settings.TestCode
                        description = My.Settings.TestMessage
                        Exit Do
                    End If

                    If reqCRC Is Nothing OrElse reqCRC.Length = 0 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    If Not CheckUtil.CheckCRC(QueryList, reqCRC) Then
                        returnCode = 6
                        description = "Sent CRC does not match the server"
                        Exit Do
                    End If

                    If reqTraderID Is Nothing OrElse reqTraderID.Length = 0 OrElse reqTraderID.Length > 32 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    If reqUsername Is Nothing OrElse reqUsername.Length = 0 Then
                        returnCode = 0
                        description = "Successful call"
                        success = True
                        Exit Do
                    End If

                    Dim DBSuccess As Boolean = False
                    Dim DBConnStr As String = My.Settings.DB
                    Try
                        Using con As New SqlConnection(DBConnStr)
                            con.Open()
                            Using cmd As SqlCommand = con.CreateCommand
                                cmd.CommandText = "select * from [M_Customer] where [CustCode]=@CustCode"
                                cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                                Using reader As SqlDataReader = cmd.ExecuteReader()
                                    If Not reader.Read() Then
                                        returnCode = 1
                                        description = "No account was found with given id"
                                        Exit Do
                                    End If
                                End Using
                            End Using
                            Using cmd As SqlCommand = con.CreateCommand
                                Dim SQL As New StringBuilder
                                SQL.AppendLine("Update [M_Customer] set [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@ProcUser, [CustName]=@CustName where [CustCode]=@CustCode")
                                cmd.CommandText = SQL.ToString()
                                cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                                cmd.Parameters.Add("@CustName", SqlDbType.NVarChar, 64).Value = reqUsername
                                cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                                cmd.ExecuteNonQuery()
                            End Using
                        End Using

                        returnCode = 0
                        description = "Successful call"
                        success = True
                        SystemLog.DBSuccess(DBConnStr)
                        DBSuccess = True
                    Catch ex As Exception
                        SystemLog.DBError(DBConnStr, ex)
                    End Try
                Loop While False
            Catch ex As Exception
                SystemLog.AppError(ex)
            End Try

            Dim res As New UpdateAccountJsonData
            Dim serializer As New DataContractJsonSerializer(GetType(UpdateAccountJsonData))

            res.returnCode = returnCode
            res.description = description

            If success Then

            End If

            Dim ms As New MemoryStream
            serializer.WriteObject(ms, res)
            ms.Position = 0
            Dim sr As New StreamReader(ms)
            Response.ContentType = "application/json"
            Response.Charset = "utf-8"
            Response.Write(sr.ReadToEnd())
        End Sub
    End Class
End Namespace