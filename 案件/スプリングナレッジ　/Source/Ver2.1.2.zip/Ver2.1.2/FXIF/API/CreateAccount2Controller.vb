﻿Imports System.IO
Imports System.Text
Imports System.Web
Imports System.Data.SqlClient
Imports System.Runtime.Serialization.Json
Imports System.Web.Mvc

Namespace FXIF
    Public Class CreateAccount2Controller
        Implements IController

        Public Sub Execute(requestContext As System.Web.Routing.RequestContext) Implements System.Web.Mvc.IController.Execute
            Dim Request As HttpRequestBase = requestContext.HttpContext.Request
            Dim Response As HttpResponseBase = requestContext.HttpContext.Response

            Dim QueryList As New List(Of KeyValuePair(Of String, String))
            Dim reqUsername As String = CheckUtil.SetQueryParam(QueryList, Request, "username")
            Dim reqCompany As String = CheckUtil.SetQueryParam(QueryList, Request, "company")
            Dim reqTraderID As String = CheckUtil.SetQueryParam(QueryList, Request, "traderID")
            Dim reqCurrency As String = CheckUtil.SetQueryParam(QueryList, Request, "currency")
            Dim reqCountryCode As String = CheckUtil.SetQueryParam(QueryList, Request, "countrycode")
            Dim reqCRC As String = Request("CRC")

            Dim success As Boolean = False
            Dim returnCode As Integer = 99
            Dim description As String = "System Maintenance"
            Dim mpUserID As Integer

            Try
                Do
                    'テスト用ロジック
                    If My.Settings.TestCode <> 0 Then
                        returnCode = My.Settings.TestCode
                        description = My.Settings.TestMessage
                        Exit Do
                    End If

                    If reqCRC Is Nothing OrElse reqCRC.Length = 0 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    If Not CheckUtil.CheckCRC(QueryList, reqCRC) Then
                        returnCode = 6
                        description = "Sent CRC does not match the server"
                        Exit Do
                    End If

                    If reqTraderID Is Nothing OrElse reqTraderID.Length = 0 OrElse reqTraderID.Length > 32 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    If reqCompany Is Nothing OrElse reqCompany.Length = 0 Then
                        returnCode = 2
                        description = "Required field missing"
                        Exit Do
                    End If

                    Dim DBSuccess As Boolean = False
                    Dim DBConnStr As String = My.Settings.DB
                    Try
                        Using con As New SqlConnection(DBConnStr)
                            con.Open()

                            Dim CmpCode As String = ""
                            Using cmd As SqlCommand = con.CreateCommand
                                cmd.CommandText = "select * from [M_Company] where [CmpCode]=@CmpCode"
                                cmd.Parameters.Add("@CmpCode", SqlDbType.VarChar, 10).Value = reqCompany
                                Using reader As SqlDataReader = cmd.ExecuteReader()
                                    If Not reader.Read() Then
                                        returnCode = 100
                                        description = "Unknown error"
                                        Exit Do
                                    End If
                                    CmpCode = reader("CmpCode")
                                    If CmpCode <> reqCompany Then
                                        returnCode = 100
                                        description = "Unknown error"
                                        Exit Do
                                    End If
                                End Using
                            End Using

                            Dim CurCode As String = ""
                            Using cmd As SqlCommand = con.CreateCommand
                                cmd.CommandText = "select * from [M_Currency] where [CurCode]=@CurCode"
                                cmd.Parameters.Add("@CurCode", SqlDbType.VarChar, 3).Value = reqCurrency
                                Using reader As SqlDataReader = cmd.ExecuteReader()
                                    If Not reader.Read() Then
                                        returnCode = 12
                                        description = "Currency is not valid"
                                        Exit Do
                                    End If
                                    CurCode = reader("CurCode")
                                    Dim AccountEnabled As String = reader("AccountEnabled")
                                    If AccountEnabled <> "1" Then
                                        returnCode = 13
                                        description = "Currency is not supported by operator"
                                        Exit Do
                                    End If
                                End Using
                            End Using

                            Using cmd As SqlCommand = con.CreateCommand
                                cmd.CommandText = "select * from [M_Customer] where [CustCode]=@CustCode"
                                cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                                Using reader As SqlDataReader = cmd.ExecuteReader()
                                    If reader.Read() Then
                                        returnCode = 3
                                        description = "Trader with the same id already exists"
                                        Exit Do
                                    End If
                                End Using
                            End Using

                            Dim CashCode As String = SeqCounter.GetSeqSysDate(SeqCounter.SeqCounterCode.Cash)

                            Using cmd As SqlCommand = con.CreateCommand
                                Dim SQL As New StringBuilder
                                SQL.AppendLine("declare @SysDate date")
                                SQL.AppendLine("select @SysDate=[SysDate] from [S_SysStatus] where [SysCode]='0'")
                                SQL.AppendLine("begin tran")
                                SQL.AppendLine("insert into [M_Customer] values (SYSUTCDATETIME(), @ProcUser, SYSUTCDATETIME(), @ProcUser, @CustCode, @CustName, @CmpCode, @CurCode, SYSUTCDATETIME(),0,0,0,@CountryCode)")
                                SQL.AppendLine("insert into [T_Cash] values (SYSUTCDATETIME(), @ProcUser, SYSUTCDATETIME(), @ProcUser, @CashCode, '1', @SysDate, SYSUTCDATETIME(), @CustCode, @CmpCode, '00', @CurCode, 0, 0)")
                                SQL.AppendLine("insert into [T_CashSpot] values (SYSUTCDATETIME(), @ProcUser, SYSUTCDATETIME(), @ProcUser, @CashCode, '1', @SysDate, SYSUTCDATETIME(), @CustCode, @CmpCode, '00', @CurCode, 0, 0)")
                                SQL.AppendLine("commit tran")
                                cmd.CommandText = SQL.ToString()
                                cmd.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reqTraderID
                                cmd.Parameters.Add("@CustName", SqlDbType.NVarChar, 64).Value = reqUsername
                                cmd.Parameters.Add("@CmpCode", SqlDbType.VarChar, 10).Value = CmpCode
                                cmd.Parameters.Add("@CurCode", SqlDbType.VarChar, 3).Value = CurCode
                                cmd.Parameters.Add("@CashCode", SqlDbType.Char, 17).Value = CashCode
                                cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                                cmd.Parameters.Add("@CountryCode", SqlDbType.Char, 2).Value = reqCountryCode
                                cmd.ExecuteNonQuery()
                            End Using
                        End Using

                        mpUserID = 0

                        returnCode = 0
                        description = "Successful call"
                        success = True
                        SystemLog.DBSuccess(DBConnStr)
                        DBSuccess = True
                    Catch ex As Exception
                        SystemLog.DBError(DBConnStr, ex)
                    End Try
                Loop While False
            Catch ex As Exception
                SystemLog.AppError(ex)
            End Try


            Dim res As New CreateAccountJsonData
            Dim serializer As New DataContractJsonSerializer(GetType(CreateAccountJsonData))

            res.returnCode = returnCode
            res.description = description

            If success Then

            End If

            Dim ms As New MemoryStream
            serializer.WriteObject(ms, res)
            ms.Position = 0
            Dim sr As New StreamReader(ms)
            Response.ContentType = "application/json"
            Response.Charset = "utf-8"
            Response.Write(sr.ReadToEnd())
        End Sub
    End Class
End Namespace