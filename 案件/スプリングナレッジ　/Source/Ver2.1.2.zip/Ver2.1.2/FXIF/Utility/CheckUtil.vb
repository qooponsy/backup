﻿Imports System.Security.Cryptography

Public Class CheckUtil

    Public Shared RegExMoney As New Regex("^\d{1,11}(\.\d{1,4}){0,1}$")
    Public Shared RegExMoney0 As New Regex("^\d{1,11}(\.0{1,4}){0,1}$")
    Public Shared RegExMoney1 As New Regex("^\d{1,11}(\.\d{1,1}){0,1}0{0,1}$")
    Public Shared RegExMoney2 As New Regex("^\d{1,11}(\.\d{1,2}){0,1}0{0,2}$")
    Public Shared RegExMoney3 As New Regex("^\d{1,11}(\.\d{1,3}){0,1}0{0,3}$")
    Public Shared RegExMoney4 As New Regex("^\d{1,11}(\.\d{1,4}){0,1}$")

    Public Shared Function CheckMoney(Value As String, DecimalPlaces As Integer) As Boolean
        Dim ret As Boolean = False
        Select Case DecimalPlaces
            Case 0 : ret = RegExMoney0.IsMatch(Value)
            Case 1 : ret = RegExMoney1.IsMatch(Value)
            Case 2 : ret = RegExMoney2.IsMatch(Value)
            Case 3 : ret = RegExMoney3.IsMatch(Value)
            Case 4 : ret = RegExMoney4.IsMatch(Value)
        End Select
        Return ret
    End Function

    Public Shared Function SetQueryParam(QueryList As List(Of KeyValuePair(Of String, String)), Request As HttpRequestBase, Name As String) As String
        Dim Value As String = Request(Name)
        QueryList.Add(New KeyValuePair(Of String, String)(Name, Value))
        Return Value
    End Function

    Public Shared Function CheckCRC(QueryList As List(Of KeyValuePair(Of String, String)), CRC As String) As Boolean
        Dim QueryString As New StringBuilder
        Dim Delimiter As String = ""
        For Each item As KeyValuePair(Of String, String) In QueryList
            If Not item.Value Is Nothing Then
                QueryString.AppendFormat("{0}{1}={2}", Delimiter, item.Key, item.Value)
                Delimiter = "&"
            End If
        Next

        Dim CheckString = My.Settings.CRCKey & QueryString.ToString()
        Dim passbin As Byte() = Encoding.UTF8.GetBytes(CheckString)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim passhash As Byte() = md5.ComputeHash(passbin)
        Dim passstr = BitConverter.ToString(passhash).ToUpper().Replace("-", "")
        Return (CRC = passstr)
    End Function

End Class
