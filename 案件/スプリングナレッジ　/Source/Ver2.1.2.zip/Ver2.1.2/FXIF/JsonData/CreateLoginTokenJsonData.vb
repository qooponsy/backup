﻿Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Json

<DataContract()>
Public Class CreateLoginTokenJsonData
    <DataMember()>
    Public returnCode As Integer
    <DataMember()>
    Public description As String
    <DataMember()>
    Public token As String
End Class
