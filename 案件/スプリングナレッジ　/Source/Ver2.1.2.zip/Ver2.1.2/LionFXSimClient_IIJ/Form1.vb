﻿Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class Form1


    ''' <summary>
    ''' 初期設定
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Form1_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        'DB情報をコンボボックスに設定
        ComboDB.Items.Add(My.Settings.DB)
        ComboDB.Text = My.Settings.DB

        'DBを検索し、銘柄コードのコンボボックスを設定
        Using con As New SqlConnection(ComboDB.Text)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                cmd.CommandText = String.Format("select symbolCode from RateIIJ with (nolock)")
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read
                        ComboSymbolCode.Items.Add(reader("symbolCode"))
                    End While
                End Using
            End Using
        End Using

    End Sub


    ''' <summary>
    ''' 選択ボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnSelect_Click(sender As System.Object, e As System.EventArgs) Handles BtnSelect.Click

        'DBを検索し、銘柄コードのコンボボックスを設定
        Using con As New SqlConnection(ComboDB.Text)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                cmd.CommandText = String.Format("select * from [RateIIJ]  with (nolock) where [symbolCode] = @symbolCode")
                cmd.Parameters.Add("@symbolCode", SqlDbType.Char, 4).Value = ComboSymbolCode.Text
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read
                        BoxSEQ.Text = (reader("seq"))
                        BoxBidRate.Text = reader("bidRate")
                        BoxAskRate.Text = reader("askRate")
                        BoxChangeRatio.Text = reader("changeRatio")
                        BoxOpenPrice.Text = reader("openPrice")
                        BoxHighPrice.Text = reader("highPrice")
                        BoxLowPrice.Text = reader("lowPrice")
                        BoxHighTime.Text = DateConversion(reader("highTime"))
                        BoxLowTime.Text = DateConversion(reader("lowTime"))
                        BoxPreviousClosePrice.Text = reader("previousClosePrice")
                        BoxCalcTime.Text = DateConversion(reader("calcTime"))
                        BoxAutoTime.Text = (reader("autoTime"))
                    End While
                End Using
            End Using
        End Using

    End Sub

    ''' <summary>
    ''' アップデートボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BtnUpd_Click(sender As System.Object, e As System.EventArgs) Handles BtnUpd.Click

        Using con As New SqlConnection(ComboDB.Text)
            con.Open()
            Using cmd As SqlCommand = con.CreateCommand
                'SQL文を作成
                cmd.CommandText = "update [RateIIJ] set" +
                    "[seq]=@seq," +
                    "[bidRate]=@bidRate," +
                    "[askRate]=@askRate," +
                    "[changeRatio]=@changeRatio," +
                    "[openPrice]=@openPrice," +
                    "[highPrice]=@highPrice," +
                    "[lowPrice]=@lowPrice," +
                    "[highTime]=@highTime," +
                    "[lowTime]=@lowTime," +
                    "[previousClosePrice]=@previousClosePrice," +
                    "[calcTime]=@calcTime," +
                    "[autoTime]=@autoTime " +
                    "where [symbolCode] = @symbolCode"
                cmd.Parameters.Add("@symbolCode", SqlDbType.Char, 4).Value = ComboSymbolCode.Text
                cmd.Parameters.Add("@seq", SqlDbType.BigInt).Value = BoxSEQ.Text
                cmd.Parameters.Add("@bidRate", SqlDbType.Decimal, 18).Value = BoxBidRate.Text
                cmd.Parameters.Add("@askRate", SqlDbType.Decimal, 18).Value = BoxAskRate.Text
                cmd.Parameters.Add("@changeRatio", SqlDbType.Decimal, 18).Value = BoxChangeRatio.Text
                cmd.Parameters.Add("@openPrice", SqlDbType.Decimal, 18).Value = BoxOpenPrice.Text
                cmd.Parameters.Add("@highPrice", SqlDbType.Decimal, 18).Value = BoxHighPrice.Text
                cmd.Parameters.Add("@lowPrice", SqlDbType.Decimal, 18).Value = BoxLowPrice.Text
                cmd.Parameters.Add("@highTime", SqlDbType.DateTime2, 7).Value = strConversion(BoxHighTime.Text)
                cmd.Parameters.Add("@lowTime", SqlDbType.DateTime2, 7).Value = strConversion(BoxLowTime.Text)
                cmd.Parameters.Add("@previousClosePrice", SqlDbType.Decimal, 18).Value = BoxPreviousClosePrice.Text
                If BoxAutoTime.Text = 1 Then
                    cmd.Parameters.Add("@calcTime", SqlDbType.DateTime2, 7).Value = DateTime.Now
                Else
                    cmd.Parameters.Add("@calcTime", SqlDbType.DateTime2, 7).Value = strConversion(BoxCalcTime.Text)
                End If
                cmd.Parameters.Add("@autoTime", SqlDbType.Char, 1).Value = BoxAutoTime.Text

                '更新
                Dim resultNum As Integer = cmd.ExecuteNonQuery()
                Dim result As DialogResult
                If resultNum > 0 Then
                    result = MessageBox.Show("DBが更新されました", "結果", MessageBoxButtons.OK)
                Else
                    result = MessageBox.Show("更新が行われませんでした", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Hand)
                End If

                '更新が成功したらテキストボックスを空に
                If result = DialogResult.OK Then
                    BoxSEQ.Clear()
                    BoxBidRate.Clear()
                    BoxAskRate.Clear()
                    BoxChangeRatio.Clear()
                    BoxOpenPrice.Clear()
                    BoxHighPrice.Clear()
                    BoxLowPrice.Clear()
                    BoxHighTime.Clear()
                    BoxLowTime.Clear()
                    BoxPreviousClosePrice.Clear()
                    BoxCalcTime.Clear()
                    BoxAutoTime.Clear()
                End If

            End Using

        End Using

    End Sub

    ''' <summary>
    ''' Date型を指定のフォーマットでString型に変換
    ''' </summary>
    ''' <param name="ddate">date型の日付</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DateConversion(ByVal ddate As Date) As String
        Dim strdate As String = ddate.ToString("yyyy.MM.dd.HH.mm.ss")
        Return strdate
    End Function

    ''' <summary>
    ''' String型をDate型に変換
    ''' </summary>
    ''' <param name="strDate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function strConversion(ByVal strDate As String) As Date
        Dim d As String = Replace(strDate, ".", "")
        Dim f As String = "yyyyMMddHHmmss"
        Dim ddate As Date = DateTime.ParseExact(d, f, Nothing)
        Return ddate
    End Function

End Class
