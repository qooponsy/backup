﻿Imports System.Text

Public Class clsDataWatcherData
    Private CustDataDic As New Dictionary(Of String, clsDataWatcherCustData)

    ''' <summary>委託者の損益情報登録</summary>
    Public Function setPAndL(CmpCode As String, CustCode As String, PAndL As Decimal) As Boolean
        If CustDataDic.ContainsKey(CustCode) Then
            '該当の委託者がdicにいる場合は金額更新
            CustDataDic(CustCode).PAndL += PAndL
        Else
            '該当の委託者がdicにいない場合はdicに追加
            Dim CustData As clsDataWatcherCustData
            CustData = New clsDataWatcherCustData(CustCode, CmpCode, PAndL)

            CustDataDic.Add(CustCode, CustData)
        End If
        Return True
    End Function

    ''' <summary>損益上位委託者の一覧取得</summary>
    Public Function getRankPAndL(RankLimit As Integer) As String
        Dim RankSortedList As New SortedList(New myReverserClass())
        Dim AlertText As New StringBuilder
        For Each CustCode In CustDataDic.Keys
            Dim CustData As New clsDataWatcherCustData(CustCode, CustDataDic(CustCode).cmpCode, CustDataDic(CustCode).PAndL)
            Dim RegistFlg As Boolean = False    '登録する場合True

            '登録数が指定数以下であれば登録flgを設定
            If Not RegistFlg Then
                Dim TotalCount As Integer = 0
                For iCnt = 0 To RankSortedList.Count - 1
                    Dim CustDataList As New List(Of clsDataWatcherCustData)
                    CustDataList = RankSortedList.GetByIndex(iCnt)
                    TotalCount += CustDataList.Count
                Next
                If (TotalCount < RankLimit) Then
                    RegistFlg = True
                End If
            End If

            '登録している最低値に対し、それ以上のデータであれば登録flgを設定
            If Not RegistFlg Then
                If (RankSortedList.GetKey(RankSortedList.Count - 1) <= CustData.PAndL) Then
                    RegistFlg = True
                End If
            End If

            'データ登録処理
            If RegistFlg Then
                Dim CustDataList As New List(Of clsDataWatcherCustData)
                '登録済みの場合は更新登録
                If RegistFlg Then
                    For iCnt = 0 To RankSortedList.Count - 1
                        If RankSortedList.GetKey(iCnt) = CustData.PAndL Then
                            CustDataList = RankSortedList.GetByIndex(iCnt)
                            CustDataList.Add(CustData)
                            RankSortedList.SetByIndex(iCnt, CustDataList)
                            RegistFlg = False
                            Exit For
                        End If
                    Next
                End If

                '追加登録
                If RegistFlg Then
                    CustDataList.Add(CustData)
                    RankSortedList.Add(CustData.PAndL, CustDataList)
                    RegistFlg = False
                End If
            End If

            '余分データ削除処理
            If 1 <= RankSortedList.Count Then
                Dim DeleteFlg As Boolean = False
                Dim TotalCount As Integer = 0
                For iCnt = 0 To RankSortedList.Count - 1
                    Dim CustDataList As New List(Of clsDataWatcherCustData)
                    CustDataList = RankSortedList.GetByIndex(iCnt)
                    TotalCount += CustDataList.Count
                    If DeleteFlg Then
                        RankSortedList.RemoveAt(RankSortedList.Count - 1)
                    End If
                    If (TotalCount >= RankLimit) Then
                        DeleteFlg = True
                    End If
                Next
            End If
        Next

        '文字列作成
        For iCnt = 0 To RankSortedList.Count - 1
            Dim RankListTemp As New List(Of clsDataWatcherCustData)
            RankListTemp = RankSortedList.GetByIndex(iCnt)
            For Each temp As clsDataWatcherCustData In RankListTemp
                AlertText.AppendFormat("「アラート顧客損益」顧客コード：{0}、損益：{1}" & vbCrLf, temp.CustCode, temp.PAndL.ToString("#######0.00"))
            Next
        Next

        Return AlertText.ToString()
    End Function
    ' (降順ソート用)独自の比較処理
    '　【参考】http://www.atmarkit.co.jp/fdotnet/bookpreview/kisokaravb_1201/kisokaravb_1201_03.html
    Public Class myReverserClass : Implements IComparer
        Private Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements IComparer.Compare
            ' パラメータを逆にして比較した結果を返す
            Return ((New CaseInsensitiveComparer()).Compare(y, x))
        End Function
    End Class

    ''' <summary>全体の損益情報:取得</summary>
    Public Function getTotalPAndL(CustCode As String) As Decimal
        Dim TotalPAndL As Decimal = 0
        For Each CustCode In CustDataDic.Keys
            TotalPAndL += CustDataDic(CustCode).PAndL
        Next
        Return TotalPAndL
    End Function
    ''' <summary>委託者の損益情報:取得</summary>
    Public Function getPAndL(CustCode As String) As Decimal
        If CustDataDic.ContainsKey(CustCode) Then
            Return CustDataDic(CustCode).PAndL
        End If
        Return 0
    End Function

    ''' <summary>委託者のメール通知済フラグ取得(True=通知済)</summary>
    Public Function getAlertAnnounceFlg(CustCode As String) As Boolean
        If CustDataDic.ContainsKey(CustCode) Then
            Return CustDataDic(CustCode).AlertAnnounceFlg
        End If
        Return False
    End Function
    ''' <summary>委託者のメール通知済フラグ設定</summary>
    Public Sub letAlertAnnounceFlg(CustCode As String, Flg As Boolean)
        If CustDataDic.ContainsKey(CustCode) Then
            CustDataDic(CustCode).AlertAnnounceFlg = Flg
        End If
    End Sub

    ''' <summary>委託者の会社コード取得</summary>
    Public Function getCmpCode(CustCode As String) As String
        If CustDataDic.ContainsKey(CustCode) Then
            Return CustDataDic(CustCode).cmpCode
        End If
        Return ""
    End Function

    ''' <summary>setされているデータのKeyCollectionを戻す</summary>
    Public Function Keys() As Object
        Return CustDataDic.Keys
    End Function
    ''' <summary>setされているデータの削除</summary>
    Sub Clear()
        CustDataDic.Clear()
    End Sub

    '--------------------------------------------------------------------------
    ' データクラス
    '--------------------------------------------------------------------------
    Class clsDataWatcherCustData
        Public CustCode As String
        Public cmpCode As String
        Public PAndL As Decimal
        Public AlertAnnounceFlg As Boolean

        'クラスコンストラクタ
        Public Sub New(pCustCode As String, pCmpCode As String, pPAndL As Decimal)
            CustCode = pCustCode
            cmpCode = pCmpCode
            PAndL = pPAndL
            AlertAnnounceFlg = False
        End Sub
    End Class
End Class
