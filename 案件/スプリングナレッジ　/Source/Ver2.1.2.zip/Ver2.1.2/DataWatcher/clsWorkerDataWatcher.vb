﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
Imports System.Text
Imports System.Threading.Tasks
'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsWorkerDataWatcher
    Private strServiceName As String
    Private ServiceStopSignal As ManualResetEvent
    Private blnMasterMode As Boolean
    Private ServerDateTime As Date
    Private HolidayCheckMinutesList As List(Of Integer)

    Private MasterHB() As Byte
    Private SlaveHB() As Byte
    Private HeartBeatUDP As UdpClient
    Private HeartBeatWatch As Stopwatch     ' HeartBeat間隔用
    Private MasterWatch As Stopwatch        ' Master/Slave切替時間用
    Private RunmodeWatch As Stopwatch       ' RunMode判定間隔用
    Private DeliveryWatch1 As Stopwatch     ' データ検査間隔用
    Private OldTradeUpdateSeq As Long
    Private TradeUpdateSeq As Long

    Private DataWatcherCustList As clsDataWatcherData
    Private TotalPAndL As Decimal
    Private TotalAlertAnnounceFlg As Boolean
    Private SysDate As Date
    Private OldSysDate As Date

    Dim clsSendMail As clsSendMail
    Dim AlertMailSubject As String

    '--------------------------------------------------------------------------
    ' クラスコンストラクタ
    '--------------------------------------------------------------------------
    Public Sub New()
        'intThreadNum = 0
        strServiceName = "DataWatcher"
#If REL_DEMO Then
        strServiceName = "DataWatcherDemoUK"
#End If
#If REL_ST Then
        strServiceName = "DataWatcherUK"
#End If
#If REL_UK Then
        strServiceName = "DataWatcherUK"
#End If
#If REL_MT4 Then
        strServiceName = "DataWatcherMT4"
#End If
        blnMasterMode = False

        DataWatcherCustList = New clsDataWatcherData
        OldTradeUpdateSeq = 0
        TotalPAndL = 0
        TotalAlertAnnounceFlg = False
        clsSendMail = New clsSendMail
        AlertMailSubject = "【海外BO】損益アラート発生 "
        If My.Settings.EnvTitle <> "" Then
            AlertMailSubject = AlertMailSubject & "(" & My.Settings.EnvTitle & ")"
        End If
    End Sub

    Enum AlertSettingsCode
        All = 0
        Cmp = 1
    End Enum
    Public Class AlertType
        Public Const All As String = "01"
        Public Const Cust As String = "02"
    End Class

    '--------------------------------------------------------------------------
    ' マスターモード稼動判定
    '--------------------------------------------------------------------------
    Public Function IsMasterMode() As Boolean
        Return blnMasterMode
    End Function

    Public Function GetMasterPriority() As Integer
        Return My.Settings.MasterPriority
    End Function

    Public Function GetProcessID() As String
        Return My.Settings.ProcessID
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッドの初期設定
    '--------------------------------------------------------------------------
    Public Function InitializeServiceThread() As Boolean
        Dim bInitRes As Boolean

        bInitRes = True

        ServiceStopSignal = New ManualResetEvent(False)

        '----------------------------------------------------------------------
        ' ハートビート電文の編集
        '----------------------------------------------------------------------
        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)

        Dim HolidayCheckMinutes() As String = My.Settings.HolidayCheckMinutes.Split(",")
        HolidayCheckMinutesList = New List(Of Integer)
        For Each CheckMinutes As String In HolidayCheckMinutes
            HolidayCheckMinutesList.Add(Integer.Parse(CheckMinutes))
        Next

        Return bInitRes
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッド
    '--------------------------------------------------------------------------
    Public Sub ServiceThread()
        Logging("ServiceThread Start.", EventLogEntryType.Information)

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew
        RunmodeWatch = Stopwatch.StartNew
        DeliveryWatch1 = Stopwatch.StartNew

        If Not ServiceStopSignal.WaitOne(0) Then

            '-----------------------------------------------------------------
            ' 初期状態としてSlaveモードに設定
            '-----------------------------------------------------------------
            OnSlaveMode()

            '-----------------------------------------------------------------
            ' 生存確認のStopWatch開始
            '-----------------------------------------------------------------
            HeartBeatWatch = Stopwatch.StartNew

            '-----------------------------------------------------------------
            ' 実行制御初期化
            '-----------------------------------------------------------------
            RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTime)
            Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)

            '-----------------------------------------------------------------
            ' 停止フラグ=Trueになるまでサービス処理をLoop
            '-----------------------------------------------------------------
            While True
                CheckMasterAlive()
                CheckRunMode()

                If blnMasterMode Then
                    'Master Mode
                    MasterLoop()
                Else
                    'Slave Mode
                    'HeartBeat調整のためDB接続のみさせる
                    Dim DataBase As clsPenguinDB
                    Try
                        DataBase = New clsPenguinDB
                        If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                            DataBase.EndSqlConnection()
                        Else
                            Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                        End If
                    Catch ex As Exception
                        SystemLog.ExceptionError(ex)
                        Logging("ServiceThread CheckDataWatche Exception:" & ex.Message, EventLogEntryType.Error)
                    End Try
                End If

                If ServiceStopSignal.WaitOne(500) Then Exit While
            End While
        End If

        DeliveryWatch1.Stop()
        RunmodeWatch.Stop()
        MasterWatch.Stop()
        HeartBeatUDP.Close()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master Mode Loop
    '--------------------------------------------------------------------------
    Public Sub MasterLoop()

        '-----------------------------------------------------
        ' ワーカースレッド停止待機
        '-----------------------------------------------------
        Logging("Master Loop Start.", EventLogEntryType.Information)

        While True
            If ServiceStopSignal.WaitOne(500) Then Exit While
            If Not CheckMasterAlive() Then Exit While

            CheckRunMode()
            If RunningContoroller.Running Then
                CheckDataWatche()
            End If
        End While
        Logging("Master Loop Stop.", EventLogEntryType.Information)

    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド、及びワーカースレッドの停止要求
    '--------------------------------------------------------------------------
    Public Sub StopService()
        ServiceStopSignal.Set()
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnMasterMode()
        blnMasterMode = True

        Logging("Master Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnSlaveMode()

        blnMasterMode = False

        Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' ハートビート送受信による、生存確認とモードの切替(Master/Slave)
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        If HeartBeatWatch.ElapsedMilliseconds() >= My.Settings.HeartBeatCycle Then
            HeartBeatWatch.Restart()

            bMasterRecv = False
            bSlaveRecv = False
            iHeartBeatPriority = 9
            If HeartBeatUDP.Available() > 0 Then
                Dim sDataHB As String
                Dim DataHB() As Byte

                RemoteEP = Nothing
                Try
                    DataHB = Nothing
                    While HeartBeatUDP.Available() > 0
                        DataHB = HeartBeatUDP.Receive(RemoteEP)
                    End While
                    sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                    Do
                        Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                        If NextIndex = -1 Then Exit Do
                        If sDataHB.Length - NextIndex < 3 Then Exit Do
                        sDataHB = sDataHB.Substring(NextIndex)
                    Loop While True
                    If My.Settings.HeartBeatLog Then
                        SystemLog.Information(sDataHB)
                    End If
                    If sDataHB.Length >= 3 Then
                        sHeartBeatMode = sDataHB.Substring(1, 1)
                        iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                        If sHeartBeatMode.Equals("M") = True Then
                            bMasterRecv = True
                            MasterWatch.Restart()
                        End If
                        If sHeartBeatMode.Equals("S") = True Then
                            bSlaveRecv = True
                        End If
                    End If
                Catch ex As Exception
                    If My.Settings.HeartBeatLog Then
                        SystemLog.AppError(ex)
                    End If
                End Try
            End If

            If blnMasterMode = True Then
                If bMasterRecv = True Then
                    ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                    If iHeartBeatPriority < My.Settings.MasterPriority Then
                        OnSlaveMode()
                        MasterWatch.Restart()
                    End If
                End If
            Else
                If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                    OnMasterMode()
                    MasterWatch.Restart()
                ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                    If SystemLog.GetDBErrorCount() > 0 Then
                        If My.Settings.HeartBeatLog Then
                            SystemLog.Information("DB Error Now.")
                        End If
                    Else
                        OnMasterMode()
                        MasterWatch.Restart()
                    End If
                End If
            End If

            Try
                If blnMasterMode Then
                    HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
                Else
                    HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then
                    SystemLog.AppError(ex)
                End If
            End Try
        End If

        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' 時間設定によるRunMode判定
    '--------------------------------------------------------------------------
    Private Sub CheckRunMode()
        If RunmodeWatch.ElapsedMilliseconds >= My.Settings.WatchRunMode Then
            RunmodeWatch.Restart()
            Try
                If RunningContoroller.check() Then
                    Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
                Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
            End Try
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' 時間設定による取引データ検査
    '--------------------------------------------------------------------------
    Private Sub CheckDataWatche()
        Dim DataBase As clsPenguinDB
        If DeliveryWatch1.ElapsedMilliseconds >= My.Settings.WatchDelivery1 Then
            DeliveryWatch1.Restart()
            Try
                DataBase = New clsPenguinDB
                If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                    Dim TradeNewFlg As Boolean = False
                    Dim checkCmpCustList As New Dictionary(Of String, Dictionary(Of String, String))

                    '損益集計
                    Dim Trade As DataTable = Nothing
                    If DataBase.GetTradeWatcher(Trade, SysDate, OldTradeUpdateSeq, TradeUpdateSeq) Then
                        '日付が変わった場合、日付更新と損益集計初期化
                        If OldSysDate <> SysDate Then
                            OldSysDate = SysDate
                            TotalPAndL = 0
                            DataWatcherCustList.Clear()
                            TotalAlertAnnounceFlg = False
                        End If

                        '損益集計
                        For iIndex = 0 To Trade.Rows.Count() - 1
                            Dim TradeRow As DataRow = Trade.Rows(iIndex)
                            '全体の損益集計
                            TotalPAndL += TradeRow.Item("PAndL")
                            '委託者ごとの損益集計
                            DataWatcherCustList.setPAndL(TradeRow.Item("CmpCode"), TradeRow.Item("CustCode"), TradeRow.Item("PAndL"))

                            '(差分)取引のあった会社と委託者コードの一覧を作成
                            If checkCmpCustList.ContainsKey(TradeRow.Item("CmpCode")) Then
                                Dim checkCustListTemp As Dictionary(Of String, String) = checkCmpCustList(TradeRow.Item("CmpCode"))
                                If Not checkCustListTemp.ContainsKey(TradeRow.Item("CustCode")) Then
                                    checkCustListTemp.Add(TradeRow.Item("CustCode"), "")
                                End If
                            Else
                                Dim checkCustListTemp As New Dictionary(Of String, String)
                                checkCustListTemp.Add(TradeRow.Item("CustCode"), "")
                                checkCmpCustList.Add(TradeRow.Item("CmpCode"), checkCustListTemp)
                            End If

                            TradeNewFlg = True
                        Next
                        OldTradeUpdateSeq = TradeUpdateSeq
                    End If

                    '損益確認(全体、(会社毎の)委託者)
                    If TradeNewFlg Then
                        'システム設定(損益設定)の取得
                        Dim AlertDayPAndL As Decimal
                        Dim AlertDayPAndLCust As Decimal
                        Dim SysStatus As DataTable = Nothing
                        If DataBase.GetSysStatusListWatcher(SysStatus) Then
                            For iIndex = 0 To SysStatus.Rows.Count() - 1
                                Dim SysStatusRow As DataRow = SysStatus.Rows(iIndex)
                                AlertDayPAndL = SysStatusRow.Item("AlertDayPAndL")
                                AlertDayPAndLCust = SysStatusRow.Item("AlertDayPAndLCust")
                            Next
                        End If

                        '全体の損益確認
                        If AlertDayPAndL <> 0 Then
                            If Not TotalAlertAnnounceFlg Then
                                If AlertDayPAndL <= TotalPAndL Then
                                    'ログ出力
                                    Dim AlertLogText As New StringBuilder
                                    AlertLogText.AppendFormat("【アラート損益】　損益：{0}", TotalPAndL)
                                    DataBase.RegistAlertLogWatcher(AlertType.All, "", "", AlertLogText.ToString())

                                    'メール送信
                                    Dim MailList As DataTable = Nothing
                                    If DataBase.GetMailListWatcher(AlertSettingsCode.All, MailList) Then
                                        Dim AlertMailText As New StringBuilder
                                        AlertMailText.AppendFormat("■アラート時間：")
                                        AlertMailText.AppendFormat(vbCrLf & Format(DateTime.UtcNow, "yyyy/MM/dd HH:mm:ss"))
                                        AlertMailText.AppendFormat(vbCrLf & "日本時間：{0}", Format(DateTime.Now, "yyyy/MM/dd HH:mm:ss"))
                                        AlertMailText.AppendFormat(vbCrLf & "")
                                        AlertMailText.AppendFormat(vbCrLf & "■アラート対象:")
                                        AlertMailText.AppendFormat(vbCrLf & "{0}アラート{1}", "全体", "")
                                        AlertMailText.AppendFormat(vbCrLf & "")
                                        AlertMailText.AppendFormat(vbCrLf & "■現在損益")
                                        AlertMailText.AppendFormat(vbCrLf & "全体損益：{0}", TotalPAndL.ToString("#######0.00"))
                                        AlertMailText.AppendFormat(vbCrLf & DataWatcherCustList.getRankPAndL(My.Settings.RankSetting))

                                        For iIndex = 0 To MailList.Rows.Count() - 1
                                            Dim MailListRow As DataRow = MailList.Rows(iIndex)
                                            Dim CmpCode As String = MailListRow.Item("CmpCode")
                                            Dim ToAddress As String = MailListRow.Item("ToAddress")

                                            Task.Run(Sub() clsSendMail.SendMail(My.Settings.MailFrom, ToAddress, AlertMailSubject, AlertMailText.ToString()))
                                        Next

                                        '送信済フラグon
                                        TotalAlertAnnounceFlg = True
                                    End If
                                End If
                            End If
                        End If

                        '(会社毎の)委託者の損益確認
                        If AlertDayPAndLCust <> 0 Then

                            Dim MailList As DataTable = Nothing
                            If DataBase.GetMailListWatcher(AlertSettingsCode.Cmp, MailList) Then

                                For iIndex = 0 To MailList.Rows.Count() - 1
                                    Dim MailListRow As DataRow = MailList.Rows(iIndex)
                                    Dim CmpCode As String = MailListRow.Item("CmpCode")
                                    Dim ToAddress As String = MailListRow.Item("ToAddress")

                                    'チェックする必要がある会社かの判定
                                    If Not checkCmpCustList.ContainsKey(CmpCode) Then Continue For

                                    Dim AlertMailFlgCmpCust As Boolean = False  '(会社毎の)損益通知が必要かの確認
                                    Dim AlertMailTextCustCode As New StringBuilder
                                    Dim AlertMailTextCustData As New StringBuilder

                                    For Each custCode In checkCmpCustList(CmpCode).Keys
                                        '通知済みかの判定
                                        If DataWatcherCustList.getAlertAnnounceFlg(custCode) Then
                                            '通知済みの場合処理しない
                                        Else
                                            '通知していない場合、損益のチェック
                                            If AlertDayPAndLCust <= DataWatcherCustList.getPAndL(custCode) Then
                                                'ログ出力
                                                Dim AlertLogText As New StringBuilder
                                                AlertLogText.AppendFormat("【アラート損益(顧客)】　委託者コード：{0},損益：{1}", custCode, DataWatcherCustList.getPAndL(custCode).ToString("#######0.00"))
                                                DataBase.RegistAlertLogWatcher(AlertType.Cust, DataWatcherCustList.getCmpCode(custCode), custCode, AlertLogText.ToString())

                                                'メール送信用設定
                                                AlertMailTextCustCode.AppendFormat(IIf(AlertMailTextCustCode.Length = 0, "：", ",") & custCode)
                                                AlertMailTextCustData.AppendFormat("「アラート顧客損益」顧客コード：{0}、損益：{1}" & vbCrLf, custCode, DataWatcherCustList.getPAndL(custCode).ToString("#######0.00"))
                                                AlertMailFlgCmpCust = True  '損益通知が必要な委託者がいた場合、その会社内でのメール送付させる

                                                '送信済フラグon
                                                DataWatcherCustList.letAlertAnnounceFlg(custCode, True)
                                            End If
                                        End If
                                    Next

                                    '委託者のアラートメール送信
                                    If AlertMailFlgCmpCust Then
                                        Dim AlertMailText As New StringBuilder
                                        AlertMailText.AppendFormat("■アラート時間：")
                                        AlertMailText.AppendFormat(vbCrLf & Format(DateTime.UtcNow, "yyyy/MM/dd HH:mm:ss"))
                                        AlertMailText.AppendFormat(vbCrLf & "日本時間：{0}", Format(DateTime.Now, "yyyy/MM/dd HH:mm:ss"))
                                        AlertMailText.AppendFormat(vbCrLf & "")
                                        AlertMailText.AppendFormat(vbCrLf & "■アラート対象:")
                                        AlertMailText.AppendFormat(vbCrLf & "{0}アラート{1}", "個別", AlertMailTextCustCode.ToString)
                                        AlertMailText.AppendFormat(vbCrLf & "")
                                        AlertMailText.AppendFormat(vbCrLf & "■現在損益")
                                        AlertMailText.AppendFormat(vbCrLf & "全体損益：{0}", TotalPAndL.ToString("#######0.00"))
                                        AlertMailText.AppendFormat(vbCrLf & AlertMailTextCustData.ToString())
                                        Task.Run(Sub() clsSendMail.SendMail(My.Settings.MailFrom, ToAddress, AlertMailSubject, AlertMailText.ToString()))
                                    End If
                                Next
                            End If
                        End If
                    End If

                    DataBase.EndSqlConnection()
                Else
                    Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
                Logging("ServiceThread CheckDataWatche Exception:" & ex.Message, EventLogEntryType.Error)
            End Try
            DataBase = Nothing
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' ログ出力
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog

        Try
            Debug.Print(sMessage)
            eLog = New EventLog()
            eLog.Source = strServiceName
            eLog.WriteEntry(sMessage, entryType)
            eLog = Nothing
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
    End Sub

End Class
