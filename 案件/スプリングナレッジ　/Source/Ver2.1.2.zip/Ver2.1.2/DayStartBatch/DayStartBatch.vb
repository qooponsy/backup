﻿Imports System.Data.SqlClient
Imports System.Globalization

Module DayStartBatch

    Const MODE_AUTO As String = "AUTO"
    Const MODE_MANUAL As String = "MANUAL"

    Sub Main(CmdArgs() As String)
        SystemLog.InitConsoleApp()

        Dim Mode As String = MODE_MANUAL
        Dim DateTimeTestModeFlg As Boolean = False
        If CmdArgs.Count > 0 Then
            '引数指定による、実行モードについて
            '   AUTO    ：実行確認なしの実行
            '   日時    ：日時指定テスト実行
            '   (その他)：実行確認ありの実行
            Mode = CmdArgs(0)
        End If

        SystemLog.Information("Run Mode:" & Mode)

        If Not Mode = MODE_AUTO Then
            If MsgBox("日次開始処理を実行します。よろしいですか？", MsgBoxStyle.Information Or MsgBoxStyle.OkCancel, "LionBO 日次開始バッチ") <> MsgBoxResult.Ok Then
                SystemLog.Information("Manual Cancel")
                Exit Sub
            Else
                If IsDate(Mode) Then
                    '引数が日時形式の場合、日時指定テストとみなす
                    DateTimeTestModeFlg = True
                End If
            End If
        End If

        SystemLog.Information("Start")

        Dim NowDateTime As DateTime
        Dim NowDate As DateTime
        Dim NowWeekday As Integer
        Dim WeekdayCheck As Boolean
        Dim HolidayCheck As Boolean
        Dim OldSysDate As DateTime
        Dim NewSysDate As DateTime
        Dim RunStartDay As Boolean
        Dim UpdateCount As Integer = 0
        Dim GeneratedCount As Integer = 0

        Dim ExecDayEndBatch As Boolean = False
        Dim ExecDayStartBatch As Boolean = False

        Dim SuccessSysDateUpdate As Boolean = False
        Dim SuccessSalesPerformance As Boolean = False
        Dim SuccessCustHist As Boolean = False
        Dim SuccessProductHist As Boolean = False
        Dim SuccessTradeNew As Boolean = False
        Dim SuccessCalcParam As Boolean = False
        Dim SuccessGenerateProdcut As Boolean = False
        Dim SuccessSysUpdateSeq As Boolean = False
        Dim SuccessProductChangedSpread As Boolean = False
        Dim SuccessProductChangedTradeMoney As Boolean = False

        While True
            'DBから情報取得
            If Not SysSettings.getDB() Then
                Exit While
            End If

            If DateTimeTestModeFlg Then
                'テスト用日時作成(引数日時(local)をシステム用日時(UTC)に変換)
                Dim culture As CultureInfo = CultureInfo.CreateSpecificCulture("ja-JP")
                Dim styles As DateTimeStyles = DateTimeStyles.AssumeLocal
                NowDateTime = DateTime.Parse(Mode, culture, styles)
                NowDateTime = NowDateTime.ToUniversalTime
            Else
                'テスト日時が指定されていない場合、システム日時を取得
                NowDateTime = SysSettings.SysDateTime
            End If

            If Not DayStart.SystemCheck(NowDateTime, NowDate, NowWeekday, WeekdayCheck, HolidayCheck) Then
                Exit While
            End If

            'システム営業日取得
            If Not SysStatus.getSysDate(NowDate, NewSysDate) Then
                Exit While
            End If

            'システム営業日更新
            Dim OldNowSysDate As DateTime
            If Not DayStart.UpdateSysDate(NewSysDate, RunStartDay, OldNowSysDate) Then
                Exit While
            End If
            If RunStartDay Then
                SystemLog.Information(String.Format("Success UpdateSysDate:{0:yyyy/MM/dd}", NewSysDate))
            Else
                SystemLog.Information(String.Format("Skip DayEnd Batch:{0:yyyy/MM/dd}", NewSysDate))
            End If
            SuccessSysDateUpdate = True

            '前営業日の取得
            If Not SysStatus.getPrevSysDate(NewSysDate, OldSysDate) Then
                Exit While
            End If

            'システム稼働日終了処理①
            If RunStartDay Then
                ExecDayEndBatch = True

                '営業実績表生成
                If SalesPerformance.Regist(OldNowSysDate) Then
                    SuccessSalesPerformance = True
                End If

                '銘柄履歴登録
                If My.Settings.ProductHist Then
                    If Product.CopyToHist() Then
                        SuccessProductHist = True
                    End If
                Else
                    SuccessProductHist = True
                End If

                '取引新規更新データ削除
                If My.Settings.TradeNew Then
                    If TradeNew.DeleteTradeNew() Then
                        SuccessTradeNew = True
                    End If
                Else
                    SuccessTradeNew = True
                End If

            End If

            'システム稼働日開始処理
            If WeekdayCheck And HolidayCheck Then
                ExecDayStartBatch = True

                '計算パラメータ更新
                '計算パラメータ設定の内容を計算パラメータに反映
                'ボラティリティの算出
                '計算パラメータ履歴の登録
                Dim HistVolList As New Dictionary(Of String, Decimal)
                If CalcParam.Update(NewSysDate, OldSysDate, HistVolList) Then
                    SuccessCalcParam = True
                End If

                '銘柄生成
                '休日は翌営業日の開始処理を行うが、銘柄の生成を行わない様に修正 2012/09/21 fate-i ARAI
                '銘柄の生成は営業日当日の朝のバッチ処理で再実行されて作成する。
                If ProductGenerator.Generate(NewSysDate, HistVolList, UpdateCount, GeneratedCount) Then
                    SuccessGenerateProdcut = True
                    SystemLog.Information(String.Format("Success GenerateProduct:{0}", UpdateCount))
                End If

                '銘柄スプレッド一括更新テーブルの全レコード削除
                If ProductChangedSpread.delete() Then
                    SuccessProductChangedSpread = True
                    SystemLog.Information(String.Format("Success ProductChangedSpread"))
                End If

                '銘柄最小最大取引額更新テーブルの全レコード削除
                If ProductChangedTradeMoney.delete() Then
                    SuccessProductChangedTradeMoney = True
                    SystemLog.Information(String.Format("Success ProductChangeTradeMoney"))
                End If
            Else
                SystemLog.Information(String.Format("Skip DayStart Batch 曜日:{0} 休日:{1}", WeekdayCheck, HolidayCheck))
            End If

            'システム稼働日終了処理②
            ' ※データ数増加により実行時間も増えてしまったため
            ' 　影響のない終了処理は営業日開始処理のあとに行い、平行処理の負荷を調整する
            If RunStartDay Then

                '委託者残高履歴登録
                If My.Settings.CustHist Then
                    If CustHist.CopySpotToHist(OldNowSysDate) Then
                        SuccessCustHist = True
                    End If
                Else
                    SuccessCustHist = True
                End If

            End If

            'システム更新シーケンス更新
            If RunStartDay Or UpdateCount > 0 Or SuccessCalcParam Then
                If Not SysStatus.updateSysUpdateSeq() Then
                    Exit While
                End If
            End If
            SuccessSysUpdateSeq = True

            Exit While
        End While

        If SuccessSysDateUpdate And SuccessSysUpdateSeq _
            And (Not ExecDayEndBatch Or SuccessSalesPerformance And SuccessCustHist And SuccessProductHist And SuccessTradeNew) _
            And (Not ExecDayStartBatch Or SuccessCalcParam And SuccessGenerateProdcut And SuccessProductChangedSpread And SuccessProductChangedTradeMoney) Then
            If Not Mode = MODE_AUTO Then
                MsgBox("日次開始処理の実行に成功しました。" & vbCrLf & _
                       String.Format("システム営業日:{0} 銘柄生成:{1}件", RunStartDay, UpdateCount),
                       MsgBoxStyle.Information Or MsgBoxStyle.OkOnly, "LionBO 日次開始バッチ")
            End If
        Else
            Dim SubMsg As String = "日次開始処理の実行に失敗しました。"
            If Not SuccessSysDateUpdate Then
                SystemLog.ErrorTEL("Update SysDate", "システム営業日の更新に失敗")
                SubMsg += vbCrLf & "システム営業日の更新に失敗"
            End If
            If ExecDayEndBatch Then
                If Not SuccessSalesPerformance Then
                    SystemLog.ErrorMAIL("SalesPerformance", "営業実績表の登録に失敗")
                    SubMsg += vbCrLf & "営業実績表の登録に失敗"
                End If
                If Not SuccessCustHist Then
                    SystemLog.ErrorMAIL("Cust Hist", "委託者残高履歴の登録に失敗")
                    SubMsg += vbCrLf & "委託者残高履歴の登録に失敗"
                End If
                If Not SuccessProductHist Then
                    SystemLog.ErrorMAIL("Product Hist", "銘柄履歴の登録に失敗")
                    SubMsg += vbCrLf & "銘柄履歴の登録に失敗"
                End If
                If Not SuccessTradeNew Then
                    SystemLog.ErrorMAIL("Trade New", "取引新規更新データの削除に失敗")
                    SubMsg += vbCrLf & "取引新規更新データの削除に失敗"
                End If
            End If
            If ExecDayStartBatch Then
                If Not SuccessCalcParam Then
                    SystemLog.ErrorMAIL("Update CalcParam", "計算パラメータの更新に失敗")
                    SubMsg += vbCrLf & "計算パラメータの更新に失敗"
                End If
                If Not SuccessGenerateProdcut Then
                    SystemLog.ErrorTEL("Generate Product", "銘柄の生成に失敗")
                    SubMsg += vbCrLf & "銘柄の生成に失敗"
                ElseIf My.Settings.ProductCountCheck And Not (UpdateCount + GeneratedCount) > 0 Then
                    SystemLog.ErrorTEL("Product Nothing", "銘柄が生成されませんでした")
                    SubMsg += vbCrLf & "銘柄が生成されませんでした"
                End If
                If Not SuccessProductChangedSpread Then
                    SystemLog.ErrorTEL("Delete ProductChangedSpread", "銘柄スプレッド一括更新テーブルの全レコード削除に失敗")
                    SubMsg += vbCrLf & "銘柄スプレッド一括更新テーブルの全レコード削除に失敗"
                End If
                If Not SuccessProductChangedTradeMoney Then
                    SystemLog.ErrorTEL("Delete ProductChangeTradeMoney", "銘柄最小最大取引額一括更新テーブルの全レコード削除に失敗")
                    SubMsg += vbCrLf & "銘柄スプレッド一括更新テーブルの全レコード削除に失敗"
                End If
            End If
            If Not SuccessSysUpdateSeq Then
                SystemLog.ErrorTEL("Update SysUpdateSeq", "システム更新通番の更新に失敗")
                SubMsg += vbCrLf & "システム更新通番の更新に失敗"
            End If

            If Not Mode = MODE_AUTO Then
                MsgBox(SubMsg, MsgBoxStyle.Critical Or MsgBoxStyle.OkOnly, "LionBO 日次開始バッチ")
            End If
        End If

        SystemLog.Information("End")
    End Sub

End Module
