﻿Imports System.Data.SqlClient

Public Class SysSettings

    Public Shared TimeZone As Integer
    Public Shared SysDateTimeZone As Integer
    Public Shared SysDateTime As DateTime

    Public Shared Function getDB() As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select *, SYSUTCDATETIME() as [UTCDATE] from [M_SysSettings] where [SysCode] = '0'"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            TimeZone = reader("TimeZone")
                            SysDateTimeZone = reader("SysDateTimeZone")
                            SysDateTime = reader("UTCDATE")
                        End If
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
