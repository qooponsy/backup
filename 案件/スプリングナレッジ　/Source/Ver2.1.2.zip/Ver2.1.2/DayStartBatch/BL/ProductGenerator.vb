﻿Imports System.Text
Imports System.Data.SqlClient

Public Class ProductGenerator

    Const STANDARD_TIME_FLG As Integer = 7200

    Public Class OpTypeCode
        Public Const BINARI As String = "01"
        Public Const ANY_TIME As String = "02"
    End Class

    Public Shared Function Generate(CreateDate As DateTime, HistVolList As Dictionary(Of String, Decimal), ByRef UpdateCount As Integer, ByRef GeneratedCount As Integer) As Boolean
        UpdateCount = 0

        Dim ret As Boolean = False

        While True
            '対象システム営業日の銘柄生成状況チェック
            If Not Product.getCountSysDate(CreateDate, GeneratedCount) Then
                Exit While
            End If
            If GeneratedCount > 0 Then
                '生成済みの為終了
                SystemLog.Information(String.Format("Exist Product SysDate:{0:yyyy/MM/dd} Count:{1}", CreateDate, GeneratedCount))
                ret = True
                Exit While
            End If

            Dim sysDate As DateTime = CreateDate
            Dim pbList As List(Of ProductBase) = Nothing
            If Not ProductBase.getList(pbList) Then
                Exit While
            End If

            Dim DBSuccess As Boolean = False
            Dim DBConnStr As String = My.Settings.DB
            Try
                Using con As New SqlConnection(DBConnStr)
                    con.Open()
                    Using tran As SqlTransaction = con.BeginTransaction()
                        Try
                            For Each pb As ProductBase In pbList
                                Dim DiffTime As Integer = SysSettings.TimeZone * 60 - SysSettings.SysDateTimeZone * 60
                                Dim startTime As New DateTime(sysDate.Year, sysDate.Month, sysDate.Day, 0, 0, 0)

                                ' 標準時間、夏時間の判定
                                Dim sTime As Integer = 0
                                Dim eTime As Integer = 0
                                If SysSettings.SysDateTimeZone * 60 = STANDARD_TIME_FLG Then
                                    sTime = pb.StartTime.TotalSeconds
                                    eTime = pb.ExercTime.TotalSeconds
                                Else
                                    sTime = pb.StartSummerTime.TotalSeconds
                                    eTime = pb.ExercSummerTime.TotalSeconds
                                End If

                                ' 開始時間を設定
                                If DiffTime > 0 Then
                                    If sTime < DiffTime Then
                                        sTime += (24 * 60 * 60)
                                    End If
                                Else
                                    If sTime > 24 * 60 * 60 + DiffTime Then
                                        sTime -= (24 * 60 * 60)
                                    End If
                                End If
                                startTime = startTime.AddSeconds(sTime)


                                Dim endTime As New DateTime(sysDate.Year, sysDate.Month, sysDate.Day, 0, 0, 0)
                                If DiffTime > 0 Then
                                    If eTime < DiffTime Then
                                        eTime += (24 * 60 * 60)
                                    End If
                                Else
                                    If eTime > 24 * 60 * 60 + DiffTime Then
                                        eTime -= (24 * 60 * 60)
                                    End If
                                End If
                                endTime = endTime.AddSeconds(eTime)

                                Dim exercTime As DateTime = startTime.AddSeconds(pb.OptionTime)
                                Dim tradeLimitTime As DateTime = Nothing

                                Select Case pb.OpType
                                    Case OpTypeCode.BINARI

                                        ' High/Low銘柄の作成
                                        While exercTime <= endTime
                                            tradeLimitTime = exercTime.AddSeconds(-pb.StopTradeTime)
                                            regist(con, tran, CreateDate, pb, startTime, exercTime, tradeLimitTime, pb.VolatilityAdjust * HistVolList.Item(pb.ComCode))

                                            UpdateCount += 1
                                            startTime = startTime.AddSeconds(pb.CreateTime)
                                            exercTime = startTime.AddSeconds(pb.OptionTime)
                                        End While

                                    Case OpTypeCode.ANY_TIME

                                        ' AnyTime銘柄の作成
                                        regist(con, tran, CreateDate, pb, startTime, endTime, tradeLimitTime, pb.VolatilityAdjust * HistVolList.Item(pb.ComCode))

                                        UpdateCount += 1

                                End Select

                            Next

                            tran.Commit()
                        Catch ex As Exception
                            SystemLog.AppError(ex)
                            Try
                                tran.Rollback()
                            Catch ex2 As Exception
                                SystemLog.AppError(ex2)
                            End Try
                            Throw
                        End Try
                    End Using
                End Using

                SystemLog.DBSuccess(DBConnStr)
                DBSuccess = True
            Catch ex As Exception
                SystemLog.DBError(DBConnStr, ex)
            End Try

            Return DBSuccess

            ret = True
            Exit While
        End While

        Return ret
    End Function

    Public Shared Sub regist(con As SqlConnection, tran As SqlTransaction, SysDate As DateTime, pb As ProductBase, StartTime As DateTime, ExercTime As DateTime, TradeLimitTime As DateTime, Volatility As Decimal)

        Dim newSeq As String = NewProductCode(con, tran)

        Using cmd As SqlCommand = con.CreateCommand
            cmd.Transaction = tran
            Dim ratetime As DateTime = DateTime.Now
            cmd.CommandText = My.Resources.SQL_Product_Regist
            cmd.Parameters.Add("@User", SqlDbType.Char, 34).Value = "P:" + My.Settings.ProcessID
            cmd.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = newSeq
            cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = pb.ComCode
            cmd.Parameters.Add("@OpType", SqlDbType.Char, 2).Value = pb.OpType
            cmd.Parameters.Add("@OptionTime", SqlDbType.Int).Value = pb.OptionTime
            cmd.Parameters.Add(New SqlParameter("@PayoutRate", SqlDbType.Decimal) With {.Precision = 15, .Scale = 8}) _
                .Value = pb.PayoutRate
            cmd.Parameters.Add("@Spread", SqlDbType.Int).Value = pb.Spread
            cmd.Parameters.Add("@StartAbandTime", SqlDbType.Int).Value = pb.StartAbandTime
            cmd.Parameters.Add("@AbandPriceDiff", SqlDbType.Int).Value = pb.AbandPriceDiff
            cmd.Parameters.Add(New SqlParameter("@AbandMargine", SqlDbType.Decimal) With {.Precision = 15, .Scale = 8}) _
                .Value = pb.AbandMargine
            cmd.Parameters.Add(New SqlParameter("@VolatilityAdjust", SqlDbType.Decimal) With {.Precision = 15, .Scale = 14}) _
                .Value = pb.VolatilityAdjust
            cmd.Parameters.Add(New SqlParameter("@Volatility", SqlDbType.Decimal) With {.Precision = 15, .Scale = 14}) _
                .Value = Volatility
            cmd.Parameters.Add(New SqlParameter("@TradeMoneyMin", SqlDbType.Decimal) With {.Precision = 15, .Scale = 4}) _
                .Value = pb.TradeMoneyMin
            cmd.Parameters.Add(New SqlParameter("@TradeMoneyMax", SqlDbType.Decimal) With {.Precision = 15, .Scale = 4}) _
                .Value = pb.TradeMoneyMax
            cmd.Parameters.Add("@StartTime", SqlDbType.DateTime2, 7).Value = StartTime.AddMinutes(-SysSettings.TimeZone)
            cmd.Parameters.Add("@ExercTime", SqlDbType.DateTime2, 7).Value = ExercTime.AddMinutes(-SysSettings.TimeZone)

            If TradeLimitTime <> Nothing Then
                cmd.Parameters.Add("@TradeLimitTime", SqlDbType.DateTime2, 7).Value = TradeLimitTime.AddMinutes(-SysSettings.TimeZone)
            Else
                cmd.Parameters.Add("@TradeLimitTime", SqlDbType.DateTime2, 7).Value = SqlTypes.SqlDateTime.Null
            End If

            cmd.Parameters.Add("@StopTradeTime", SqlDbType.Int).Value = pb.StopTradeTime
            cmd.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = pb.ProductBaseCode
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Function NewProductCode(con As SqlConnection, tran As SqlTransaction) As String
        Dim result As String

        Using cmd As SqlCommand = con.CreateCommand
            cmd.Transaction = tran
            Dim sql As New StringBuilder
            sql.AppendLine("declare @Counter int")
            sql.AppendLine("select")
            sql.AppendLine("	 @Counter = [Counter]")
            sql.AppendLine("	from [S_Counter] with (updlock)")
            sql.AppendLine("	where [CounterCode] = '04'")
            sql.AppendLine("update [S_Counter] set")
            sql.AppendLine("	 [Counter] = @Counter + 1")
            sql.AppendLine("	where [CounterCode] = '04'")
            sql.AppendLine("select")
            sql.AppendLine("	 convert(char(8), [SysDate], 112)")
            sql.AppendLine("	 + replicate('0' ,9 - len(@Counter))")
            sql.AppendLine("	 + convert(varchar(9),@Counter)")
            sql.AppendLine("	from [S_SysStatus] ")
            sql.AppendLine("	where [SysCode] = '0'")
            cmd.CommandText = sql.ToString()
            result = cmd.ExecuteScalar()
        End Using

        Return result
    End Function


End Class
