﻿Imports System.Data.SqlClient

Public Class TradeNew

    Public Shared Function DeleteTradeNew() As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = _
                        "Delete T_TradeNew from T_TradeNew n " & vbCrLf & _
                        "inner join T_Trade t on n.TradeSeq = t.TradeSeq " & vbCrLf & _
                        "where not t.TradeStatus = '02'"

                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
