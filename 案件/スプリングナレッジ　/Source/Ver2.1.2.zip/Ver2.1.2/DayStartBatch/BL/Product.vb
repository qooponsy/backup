﻿Imports System.Data.SqlClient

Public Class Product

    Public Shared Function getCountSysDate(ByVal SysDate As DateTime, ByRef ProductCount As Integer) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            ProductCount = 0
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select COUNT(*) from [M_Product] with (nolock) where [SysDate] = @SysDate and [Enabled] = '1'"
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    ProductCount = cmd.ExecuteScalar()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public Shared Function CopyToHist() As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText =
                        "begin tran" & vbCrLf &
                        "insert into M_ProductHist select * from M_Product where not [ExercStatus] in ('0','1')" & vbCrLf &
                        "delete M_Product where not [ExercStatus] in ('0','1')" & vbCrLf &
                        "commit tran"
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
