﻿Imports System.Data.SqlClient

Public Class SalesPerformance

    Public Shared Function Regist(SysDate As DateTime) As Boolean
        Dim CmpList As List(Of Company) = Nothing
        If Not Company.GetList(CmpList) Then
            Return False
        End If
        Dim CurList As List(Of Currency) = Nothing
        If Not Currency.GetList(CurList) Then
            Return False
        End If
        For Each itemCmp As Company In CmpList
            For Each itemCur As Currency In CurList
                If Not Regist(SysDate, itemCmp.CmpCode, itemCur.CurCode) Then
                    Return False
                End If
            Next
        Next

        Return True
    End Function

    Private Shared Function Regist(SysDate As DateTime, CmpCode As String, CurCode As String) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    Dim ratetime As DateTime = DateTime.Now
                    cmd.CommandText = My.Resources.SQL_SalesPerformance
                    cmd.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                    cmd.Parameters.Add("@CmpCode", SqlDbType.VarChar, 10).Value = CmpCode
                    cmd.Parameters.Add("@CurCode", SqlDbType.VarChar, 10).Value = CurCode
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

End Class
