﻿Imports System.Data.SqlClient

Public Class Currency

    Public Shared Function GetList(ByRef list As List(Of Currency)) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [M_Currency] order by [SortOrder]"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        list = New List(Of Currency)
                        While reader.Read()
                            Dim objCurrency As New Currency
                            objCurrency.CurCode = reader("CurCode")
                            objCurrency.CurName = reader("CurName")

                            list.Add(objCurrency)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public CurCode As String
    Public CurName As String

End Class
