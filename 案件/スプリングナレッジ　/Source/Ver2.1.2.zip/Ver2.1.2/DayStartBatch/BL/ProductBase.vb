﻿Imports System.Data.SqlClient

Public Class ProductBase

    Public Shared Function getList(ByRef list As List(Of ProductBase)) As Boolean
        list = New List(Of ProductBase)

        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    Dim ratetime As DateTime = DateTime.Now
                    cmd.CommandText = "select * from [M_ProductBase] where [Enabled] = '1' order by [ProductBaseCode] desc"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            Dim newData As New ProductBase
                            newData.ProductBaseCode = reader("ProductBaseCode")
                            newData.Enabled = reader("Enabled")
                            newData.ComCode = reader("ComCode")
                            newData.OpType = reader("OpType")
                            newData.PayoutRate = reader("PayoutRate")
                            newData.Spread = reader("Spread")
                            newData.OptionTime = reader("OptionTime")
                            newData.CreateTime = reader("CreateTime")
                            newData.StartTime = reader("StartTime")
                            newData.ExercTime = reader("ExercTime")
                            newData.StartSummerTime = reader("StartSummerTime")
                            newData.ExercSummerTime = reader("ExercSummerTime")
                            newData.StopTradeTime = reader("StopTradeTime")
                            newData.StartAbandTime = reader("StartAbandTime")
                            newData.AbandPriceDiff = reader("AbandPriceDiff")
                            newData.AbandMargine = reader("AbandMargine")
                            newData.VolatilityAdjust = reader("VolatilityAdjust")
                            newData.TradeMoneyMin = reader("TradeMoneyMin")
                            newData.TradeMoneyMax = reader("TradeMoneyMax")
                            list.Add(newData)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public ProductBaseCode As String
    Public Enabled As String
    Public ComCode As String
    Public OpType As String
    Public OptionTime As Integer
    Public CreateTime As Integer
    Public StartTime As TimeSpan
    Public ExercTime As TimeSpan
    Public StartSummerTime As TimeSpan
    Public ExercSummerTime As TimeSpan
    Public PayoutRate As Decimal
    Public Spread As Integer
    Public StopTradeTime As Integer
    Public StartAbandTime As Integer
    Public AbandPriceDiff As Integer
    Public AbandMargine As Decimal
    Public VolatilityAdjust As Decimal
    Public TradeMoneyMin As Decimal
    Public TradeMoneyMax As Decimal

End Class
