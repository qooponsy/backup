﻿Imports System.Data.SqlClient

Public Class CalcParamSettings

    Public Shared Function GetList(ByRef list As Dictionary(Of String, CalcParamSettings)) As Boolean
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [M_CalcParamSettings]"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        list = New Dictionary(Of String, CalcParamSettings)
                        While reader.Read()
                            Dim item As New CalcParamSettings
                            item.ComCode = reader("ComCode")
                            item.InterestRate = reader("InterestRate")
                            item.SwapRate = reader("SwapRate")
                            item.VolatilityAdjust = reader("VolatilityAdjust")
                            list.Add(item.ComCode, item)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess(DBConnStr)
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStr, ex)
        End Try

        Return DBSuccess
    End Function

    Public ComCode As String
    Public InterestRate As Decimal
    Public SwapRate As Decimal
    Public VolatilityAdjust As Decimal

End Class
