﻿Imports System.Threading
Imports System.Text
Imports System.Data.SqlClient

Public Class CustHist

    Public Shared Function CopySpotToHist(SysDate As DateTime) As Boolean
        Dim DBSuccessMain As Boolean = False
        Dim DBConnStrMain As String = My.Settings.DB
        Dim DBSuccessSub As Boolean = False
        Dim DBConnStrSub As String = My.Settings.DBSub
        Try
            Using conMain As New SqlConnection(DBConnStrMain)
                conMain.Open()
                Using cmdMain As SqlCommand = conMain.CreateCommand
                    cmdMain.CommandText = "select * from [T_CustHistSpot]"
                    cmdMain.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate

                    Using reader As SqlDataReader = cmdMain.ExecuteReader()

                        DBSuccessSub = False
                        Try
                            Using conSub As New SqlConnection(DBConnStrSub)
                                conSub.Open()
                                Using cmdSub As SqlCommand = conSub.CreateCommand
                                    cmdSub.CommandText = "delete [T_CustHist] where [SysDate]=@SysDate"
                                    cmdSub.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
                                    cmdSub.ExecuteNonQuery()
                                End Using
                            End Using

                            SystemLog.DBSuccess(DBConnStrSub)
                            DBSuccessSub = True
                        Catch ex As Exception
                            SystemLog.DBError(DBConnStrSub, ex)
                        End Try

                        If DBSuccessSub Then
                            While reader.Read()
                                DBSuccessSub = False
                                Try
                                    Using conSub As New SqlConnection(DBConnStrSub)
                                        conSub.Open()
                                        Using cmdSub As SqlCommand = conSub.CreateCommand
                                            cmdSub.CommandText = "insert into [T_CustHist] values (SYSUTCDATETIME(), @ProcUser, @SysDate, @CustCode, @CmpCode, @CurCode, @TotalMoney)"
                                            Dim param As SqlParameter
                                            cmdSub.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                                            cmdSub.Parameters.Add("@SysDate", SqlDbType.Date).Value = reader("SysDate")
                                            cmdSub.Parameters.Add("@CustCode", SqlDbType.VarChar, 32).Value = reader("CustCode")
                                            cmdSub.Parameters.Add("@CmpCode", SqlDbType.VarChar, 10).Value = reader("CmpCode")
                                            cmdSub.Parameters.Add("@CurCode", SqlDbType.VarChar, 3).Value = reader("CurCode")
                                            param = cmdSub.Parameters.Add("@TotalMoney", SqlDbType.Decimal)
                                            param.Precision = 15
                                            param.Scale = 4
                                            param.Value = reader("TotalMoney")
                                            cmdSub.ExecuteNonQuery()
                                        End Using
                                    End Using

                                    SystemLog.DBSuccess(DBConnStrSub)
                                    DBSuccessSub = True
                                Catch ex As Exception
                                    SystemLog.DBError(DBConnStrSub, ex)
                                End Try
                                If Not DBSuccessSub Then
                                    Exit While
                                End If
                            End While
                        End If
                    End Using

                End Using
            End Using

            SystemLog.DBSuccess(DBConnStrMain)
            DBSuccessMain = True
        Catch ex As Exception
            SystemLog.DBError(DBConnStrMain, ex)
        End Try

        Return DBSuccessMain And DBSuccessSub
    End Function

End Class
