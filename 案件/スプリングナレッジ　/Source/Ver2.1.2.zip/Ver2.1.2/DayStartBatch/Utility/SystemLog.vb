﻿Imports System.Threading

Public Class SystemLog
    Private Const EVENT_SOURCE As String = "LionBO"
    Private Const ALERT_MESSAGE_TEL As String = "LionBO ALERT TEL:"
    Private Const ALERT_MESSAGE_MAIL As String = "LionBO ALERT MAIL:"

    Public Shared Sub InitConsoleApp()
        AddHandler AppDomain.CurrentDomain.UnhandledException, AddressOf ApplicationUnhandledException
    End Sub

    'UnhandledExceptionイベントハンドラ
    Private Shared Sub ApplicationUnhandledException(ByVal sender As Object, ByVal e As UnhandledExceptionEventArgs)
        Try
            EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """", EventLogEntryType.Error)
            Dim ex As Exception = CType(e.ExceptionObject, Exception)
            EventLog.WriteEntry(EVENT_SOURCE,
                                "PROCESS:" & Process.GetCurrentProcess.ProcessName & vbCrLf &
                                "MESSAGE:" & ex.Message & vbCrLf &
                                "STACK TRACE:" & vbCrLf & ex.StackTrace, EventLogEntryType.Error)
        Finally
            End
        End Try
    End Sub

    Public Shared Sub AppError(ex As Exception)
        EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """", EventLogEntryType.Error)
        ExceptionError(ex)
    End Sub

    Public Shared Sub Information(Msg As String)
        EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Information)
    End Sub

    Public Shared Sub ErrorTEL(AlertMsg As String, Msg As String)
        EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """ " & AlertMsg, EventLogEntryType.Error)
        EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Warning)
    End Sub

    Public Shared Sub ErrorMAIL(AlertMsg As String, Msg As String)
        EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_MAIL & "Error Process """ & My.Settings.ProcessID & """ " & AlertMsg, EventLogEntryType.Error)
        EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Warning)
    End Sub

    Private Shared DBErrorCounterMain As Integer = 0

    Public Shared Sub DBSuccess(DBConnStr As String)
        Dim DBName As String = ""
        Dim OldErrorCounter As Integer = 0
        Select Case DBConnStr
            Case My.Settings.DB
                DBName = "Main"
                OldErrorCounter = Interlocked.Exchange(DBErrorCounterMain, 0)
        End Select
        If OldErrorCounter > 0 Then
            Information(String.Format("{1} DB Success (ErrorCount:{0})", OldErrorCounter, DBName))
        End If
    End Sub

    Public Shared Sub DBError(DBConnStr As String, ex As Exception)
        Dim DBName As String = ""
        Dim ErrorCount As Integer = 0
        Select Case DBConnStr
            Case My.Settings.DB
                DBName = "Main"
                ErrorCount = Interlocked.Increment(DBErrorCounterMain)
        End Select

        If ErrorCount <= 3 Then
            EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """ " & DBName & " DB Error", EventLogEntryType.Error)
        End If
        If ErrorCount <= 20 Then
            ExceptionError(ex)
        End If
    End Sub

    Public Shared Sub ExceptionError(ex As Exception)
        Dim objErr As Exception = ex
        While (objErr IsNot Nothing)
            Dim st As StackTrace = New StackTrace(3, True)
            EventLog.WriteEntry(EVENT_SOURCE,
                                "PROCESS:" & My.Settings.ProcessID & vbCrLf &
                                "SOURCE:" & objErr.Source & vbCrLf &
                                "MESSAGE:" & objErr.Message & vbCrLf &
                                "TARGET SITE:" & If(Not objErr.TargetSite Is Nothing, objErr.TargetSite.ToString(), "") & vbCrLf &
                                "STACK TRACE:" & If(Not objErr.StackTrace Is Nothing, vbCrLf & objErr.StackTrace.ToString(), "") & vbCrLf & st.ToString(),
                                EventLogEntryType.Warning)
            objErr = objErr.InnerException
        End While
    End Sub

End Class
