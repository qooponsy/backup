﻿Public Class RiskCalc

    Public Shared Function volatility(RateList As List(Of Decimal)) As Decimal
        Dim n As Integer = RateList.Count - 1
        If n < 2 Then Return 0.1

        Dim u2sum As Decimal = 0
        Dim usum As Decimal = 0
        For i As Integer = 1 To n
            Dim u As Decimal = Math.Log(RateList(i) / RateList(i - 1))
            u2sum += u * u
            usum += u
        Next

        Dim s As Decimal = Math.Sqrt((1 / (n - 1) * u2sum) - (1 / (n * (n - 1)) * usum * usum))
        Dim sigma As Decimal = s / Math.Sqrt(1 / 250)

        Return sigma
    End Function

End Class
