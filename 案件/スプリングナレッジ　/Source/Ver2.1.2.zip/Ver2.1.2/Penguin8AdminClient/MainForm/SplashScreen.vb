﻿Imports System.Threading

Public NotInheritable Class SplashScreen

    Public UserSettingInit As Boolean = False

    Private WithEvents serviceClientSettings As ClientSettingsService = Nothing
    Private WithEvents serviceCurrencyPair As CurrencyPairService = Nothing
    Private WithEvents serviceCurrency As CurrencyService = Nothing
    Private WithEvents serviceSysStatics As SysStaticsService = Nothing
    Private WithEvents serviceCompany As CompanyService = Nothing
    Private WithEvents serviceRateProvider As RateProviderService = Nothing
    Private WithEvents serviceRateTick As RateTickService = Nothing
    Private WithEvents serviceSysSettings As SysSettingsService = Nothing
    Private WithEvents serviceSysStatus As SysStatusService = Nothing
    Private WithEvents serviceCalcParam As CalcParamService = Nothing
    Private WithEvents serviceTradeNow As TradeNowService = Nothing
    Private WithEvents serviceRateFilterStatus As RateFilterStatusService = Nothing
    Private WithEvents serviceRateFilter As RateFilterService = Nothing
    Private WithEvents serviceFileType As FileTypeService = Nothing
    Private WithEvents serviceChartType As ChartTypeService = Nothing
    'Private WithEvents serviceRateFilterLog As RateFilterLogService = Nothing

    Private ReqClientSettingsService As Boolean = False
    Private ReqCurrencyPairService As Boolean = False
    Private ReqCurrencyService As Boolean = False
    Private ReqSysStaticsService As Boolean = False
    Private ReqCompanyService As Boolean = False
    Private ReqRateProviderService As Boolean = False
    Private ReqRateTickService As Boolean = False
    Private ReqSysSettingsService As Boolean = False
    Private ReqSysStatusService As Boolean = False
    Private ReqCalcParamService As Boolean = False
    Private ReqTradeNowService As Boolean = False
    Private ReqRateFilterStatusService As Boolean = False
    Private ReqRateFilterService As Boolean = False
    Private ReqFileTypeService As Boolean = False
    Private ReqChartTypeService As Boolean = False
    'Private ReqRateFilterLogService As Boolean = False

    Private InitClientSettingsService As Boolean = False
    Private InitCurrencyPairService As Boolean = False
    Private InitCurrencyService As Boolean = False
    Private InitSysStaticsService As Boolean = False
    Private InitCompanyService As Boolean = False
    Private InitRateProviderService As Boolean = False
    Private InitRateTickService As Boolean = False
    Private InitSysSettingsService As Boolean = False
    Private InitSysStatusService As Boolean = False
    Private InitCalcParamService As Boolean = False
    Private InitTradeNowService As Boolean = False
    Private InitRateFilterStatusService As Boolean = False
    Private InitRateFilterService As Boolean = False
    Private InitFileTypeService As Boolean = False
    Private InitChartTypeService As Boolean = False
    'Private InitRateFilterLogService As Boolean = False

    Private Sub SplashScreen_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'アプリケーション タイトル
        If My.Application.Info.Title <> "" Then
            ApplicationTitle.Text = My.Application.Info.Title
        Else
            'アプリケーション タイトルがない場合は、拡張子なしのアプリケーション名を使用します
            ApplicationTitle.Text = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If

        'デザイン時に書式設定文字列としてバージョン管理で設定されたテキストを使用して、バージョン情報の書式を
        '  設定します。これにより効率的なローカリゼーションが可能になります。
        '  ビルドおよび リビジョン情報は、次のコードを使用したり、バージョン管理のデザイン時のテキストを 
        '  "Version {0}.{1:00}.{2}.{3}" のように変更したりすることによって含めることができます。
        '  詳細については、ヘルプの String.Format() を参照してください。
        '
        '    Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor, My.Application.Info.Version.Build, My.Application.Info.Version.Revision)

        Version.Text = String.Format("Version {0}", clsUtil.GetVersionString())

        '著作権情報
        Copyright.Text = My.Application.Info.Copyright
    End Sub

    Private Sub SplashScreen_Shown(sender As Object, e As System.EventArgs) Handles Me.Shown
        LoadingStart()
    End Sub

    Private Sub LoadingStart()
        upbProgressBar.Minimum = 0
        upbProgressBar.Maximum = 100
        upbProgressBar.Value = 0

        EnabledFlagManager.Init()
        ExercStatusManager.Init()
        ExercFlagManager.Init()
        TradeListTypeManager.Init()
        TradeStatusManager.Init()
        TradeTypeManager.Init()
        DateTypeManager.Init()
        CashTypeManager.Init()
        RateFilterLogTypeManager.Init()
        RateFilterStatusManager.Init()
        UserTypeManager.Init()
        AccountLockFlagManager.Init()
        AlertTypeManager.Init()
        OptionTypeManager.Init()
        ReportTypeManager.Init()
        CountryTypeManager.Init()

        Loading()
    End Sub

    Private Sub Loading()

        'upbProgressBar.Value = upbProgressBar.Value + 7
        upbProgressBar.Value = upbProgressBar.Value + 6

        Me.Update()

        If Not ReqClientSettingsService Then
            ReqClientSettingsService = True
            serviceClientSettings = New ClientSettingsService
            serviceClientSettings.Read()
        End If
        If Not ReqCurrencyPairService Then
            ReqCurrencyPairService = True
            serviceCurrencyPair = New CurrencyPairService
            CurrencyPairService.Init()
        End If
        If Not ReqCurrencyService Then
            ReqCurrencyService = True
            serviceCurrency = New CurrencyService
            CurrencyService.Init()
        End If
        If Not ReqSysStaticsService Then
            ReqSysStaticsService = True
            serviceSysStatics = New SysStaticsService
            SysStaticsService.Init()
        End If
        If Not ReqCompanyService Then
            ReqCompanyService = True
            serviceCompany = New CompanyService
            CompanyService.Init()
        End If
        If Not ReqRateProviderService Then
            ReqRateProviderService = True
            serviceRateProvider = New RateProviderService
            RateProviderService.Init()
        End If
        If Not ReqRateTickService Then
            If InitCurrencyPairService Then
                ReqRateTickService = True
                serviceRateTick = New RateTickService
                RateTickService.Init()
            End If
        End If
        If Not ReqSysSettingsService Then
            If InitRateTickService Then
                ReqSysSettingsService = True
                serviceSysSettings = New SysSettingsService
                SysSettingsService.Init()
            End If
        End If
        If Not ReqSysStatusService Then
            If InitRateTickService Then
                ReqSysStatusService = True
                serviceSysStatus = New SysStatusService
                SysStatusService.Init()
            End If
        End If
        If Not ReqCalcParamService Then
            If InitRateTickService Then
                ReqCalcParamService = True
                serviceCalcParam = New CalcParamService
                CalcParamService.Init()
            End If
        End If
        If Not ReqTradeNowService Then
            If InitRateTickService Then
                ReqTradeNowService = True
                serviceTradeNow = New TradeNowService
                TradeNowService.Init()
            End If
        End If
        If Not ReqRateFilterService Then
            If InitCurrencyPairService Then
                ReqRateFilterService = True
                serviceRateFilter = New RateFilterService
                RateFilterService.Init()
            End If
        End If
        If Not ReqRateFilterStatusService Then
            If InitCurrencyPairService Then
                ReqRateFilterStatusService = True
                serviceRateFilterStatus = New RateFilterStatusService
                RateFilterStatusService.Init()
            End If
        End If
        'If Not ReqRateFilterLogService Then
        '    If InitCurrencyPairService Then
        '        ReqRateFilterLogService = True
        '        serviceRateFilterLog = New RateFilterLogService
        '        RateFilterLogService.Init()
        '    End If
        'End If
        If Not ReqFileTypeService Then
            ReqFileTypeService = True
            serviceFileType = New FileTypeService
            FileTypeService.Init()
        End If

        If Not ReqChartTypeService Then
            ReqChartTypeService = True
            serviceChartType = New ChartTypeService
            ChartTypeService.Init()
        End If

        If InitClientSettingsService And
            InitCurrencyPairService And
            InitCurrencyService And
            InitSysStaticsService And
            InitCompanyService And
            InitRateProviderService And
            InitRateTickService And
            InitSysSettingsService And
            InitSysStatusService And
            InitCalcParamService And
            InitTradeNowService And
            InitRateFilterStatusService And
            InitRateFilterService And
            InitFileTypeService And
            InitChartTypeService Then
            'InitRateFilterLogService Then

            serviceClientSettings = Nothing
            serviceCurrencyPair = Nothing
            serviceCurrency = Nothing
            serviceSysStatics = Nothing
            serviceCompany = Nothing
            serviceRateProvider = Nothing
            serviceRateTick = Nothing
            serviceSysSettings = Nothing
            serviceSysStatus = Nothing
            serviceCalcParam = Nothing
            serviceTradeNow = Nothing
            serviceRateFilterStatus = Nothing
            serviceRateFilter = Nothing
            serviceFileType = Nothing
            serviceChartType = Nothing
            'serviceRateFilterLog = Nothing

            upbProgressBar.Value = 100
            Me.Update()
            MainWindow.Show()
            Me.Close()
        End If
    End Sub

    Private Sub LoadingError(ErrorMessage As String)
        serviceClientSettings = Nothing
        serviceCurrencyPair = Nothing
        serviceCurrency = Nothing
        serviceSysStatics = Nothing
        serviceCompany = Nothing
        serviceRateProvider = Nothing
        serviceRateTick = Nothing
        serviceSysSettings = Nothing
        serviceSysStatus = Nothing
        serviceCalcParam = Nothing
        serviceTradeNow = Nothing
        serviceRateFilterStatus = Nothing
        serviceRateFilter = Nothing
        serviceFileType = Nothing
        serviceChartType = Nothing
        'serviceRateFilterLog = Nothing
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        SessionService.LogoutAdmin()
        Me.Close()
    End Sub

    Private Sub serviceRateTick_Initialized() Handles serviceRateTick.Initialized
        InitRateTickService = True
        Loading()
    End Sub

    Private Sub serviceRateTick_NewTickError(ErrorMessage As String) Handles serviceRateTick.NewTickError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceCalcParam_Initialized() Handles serviceCalcParam.Initialized
        InitCalcParamService = True
        Loading()
    End Sub

    Private Sub serviceCalcParam_ReadError(ErrorMessage As String) Handles serviceCalcParam.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceClientSettings_ReadError(ErrorMessage As String) Handles serviceClientSettings.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceClientSettings_ReadSuccess(data As String) Handles serviceClientSettings.ReadSuccess
        InitClientSettingsService = True
        UserSettings.getInstance().load(UserSettingInit, data)
        Loading()
    End Sub

    Private Sub serviceCompany_Initialized() Handles serviceCompany.Initialized
        InitCompanyService = True
        Loading()
    End Sub

    Private Sub serviceCompany_ReadError(ErrorMessage As String) Handles serviceCompany.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceCurrencyPair_Initialized() Handles serviceCurrencyPair.Initialized
        InitCurrencyPairService = True
        Loading()
    End Sub

    Private Sub serviceCurrencyPair_ReadError(ErrorMessage As String) Handles serviceCurrencyPair.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceCurrency_Initialized() Handles serviceCurrency.Initialized
        InitCurrencyService = True
        Loading()
    End Sub

    Private Sub serviceCurrency_ReadError(ErrorMessage As String) Handles serviceCurrency.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceSysStatics_Initialized() Handles serviceSysStatics.Initialized
        InitSysStaticsService = True
        Loading()
    End Sub

    Private Sub serviceSysStatics_ReadError(ErrorMessage As String) Handles serviceSysStatics.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceRateProvider_Initialized() Handles serviceRateProvider.Initialized
        InitRateProviderService = True
        Loading()
    End Sub

    Private Sub serviceRateProvider_ReadError(ErrorMessage As String) Handles serviceRateProvider.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceSysSettings_Initialized() Handles serviceSysSettings.Initialized
        InitSysSettingsService = True
        Loading()
    End Sub

    Private Sub serviceSysSettings_ReadError(ErrorMessage As String) Handles serviceSysSettings.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceSysStatus_Initialized() Handles serviceSysStatus.Initialized
        InitSysStatusService = True
        Loading()
    End Sub

    Private Sub serviceSysStatus_ReadError(ErrorMessage As String) Handles serviceSysStatus.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceTradeNow_Initialized() Handles serviceTradeNow.Initialized
        serviceTradeNow = Nothing
        InitTradeNowService = True
        Loading()
    End Sub

    Private Sub serviceTradeNow_ReadError(ErrorMessage As String) Handles serviceTradeNow.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceRateFilterStatus_Initialized() Handles serviceRateFilterStatus.Initialized
        InitRateFilterStatusService = True
        Loading()
    End Sub

    Private Sub serviceRateFilterStatus_ReadError(ErrorMessage As String) Handles serviceRateFilterStatus.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceRateFilter_Initialized() Handles serviceRateFilter.Initialized
        InitRateFilterService = True
        Loading()
    End Sub

    Private Sub serviceRateFilter_ReadError(ErrorMessage As String) Handles serviceRateFilter.ReadError
        LoadingError(ErrorMessage)
    End Sub

    'Private Sub serviceRateFilterLog_Initialized() Handles serviceRateFilterLog.Initialized
    '    InitRateFilterLogService = True
    '    Loading()
    'End Sub

    'Private Sub serviceRateFilterLog_ReadError(ErrorMessage As String) Handles serviceRateFilterLog.ReadError
    '    LoadingError(ErrorMessage)
    'End Sub

    Private Sub serviceFileType_Initialized() Handles serviceFileType.Initialized
        InitFileTypeService = True
        Loading()
    End Sub

    Private Sub serviceFileType_ReadError(ErrorMessage As String) Handles serviceFileType.ReadError
        LoadingError(ErrorMessage)
    End Sub

    Private Sub serviceChartType_Initialized() Handles serviceChartType.Initialized
        InitChartTypeService = True
        Loading()
    End Sub

    Private Sub serviceChartType_ReadError(ErrorMessage As String) Handles serviceChartType.ReadError
        LoadingError(ErrorMessage)
    End Sub

End Class
