Imports System.Threading
Imports Penguin8AdminClient

''' <summary>
''' ���C�����j���[
''' </summary>
''' <remarks></remarks>
Public Class MainWindow
    Public SubFormProductBase As Boolean = False
    Public SubFormProduct As Boolean = False
    Public SubFormRateHist As Boolean = False
    Public SubFormExercRateHist As Boolean = False
    Public SubFormCust As Boolean = False
    Public SubFormTrade As Boolean = False
    Public SubFormCash As Boolean = False
    Public SubFormSysSettingsForm As Boolean = False
    Public SubFormSysControlForm As Boolean = False
    Public SubFormRiskMonitor As Boolean = False
    Public SubFormRiskSimulate As Boolean = False
    Public SubFormRateChartHist As Boolean = False
    Public SubFormRateChartForm As Boolean = False
    Public SubFormSalesPerformance As Boolean = False
    Public SubFormNowStatus As Boolean = False
    Public SubFormUser As Boolean = False
    Public SubFormOperationHist As Boolean = False
    Public SubFormOperationHistClient As Boolean = False
    Public SubFormAlertHist As Boolean = False

    Public SubFormProductBaseForm As Boolean = False
    Public SubFormProductForm As Boolean = False
    Public SubFormRateHistForm As Boolean = False
    Public SubFormTradeForm As Boolean = False
    Public SubFormCashForm As Boolean = False
    Public SubFormUserForm As Boolean = False
    Public SubFormUserChangePasswordForm As Boolean = False

    Public SubFormRateFilterForm As Boolean = False
    Public SubFormRateMonitor As Boolean = False
    Public SubFormRateFilterLogList As Boolean = False

    Public SubFormCalcParamSettingsForm As Boolean = False

    Public SubFormFileDownloadList As Boolean = False
    Public SubFormReportDownload As Boolean = False
    Public SubFormTradeAccountSummaryDownload As Boolean = False

    Private WithEvents serviceRateTick As RateTickService = Nothing
    Private WithEvents serviceRateLog As RateFilterLogService = Nothing
    Private WithEvents serviceAlertLog As AlertLogService = Nothing

    Private RateFilterUpdateSeq As Long = Long.MaxValue
    Private WatcherAlertUpdateSeq As Long = Long.MaxValue
    Private LastAlertSoundTime As DateTime = DateTime.MinValue

    ''' <summary>
    ''' �t�H�[�����[�h�C�x���g
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainMenu_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        Dim EnvTitle As String = clsUtil.GetEnvTitle()
        If EnvTitle <> "" Then
            Me.Text = Me.Text & "(" & EnvTitle & ")"
        End If
        'Me.Hide()

        Init()
        LoadSettings()

        'Me.Show()
    End Sub

    Private Sub MainWindow_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        UserSettings.getInstance().DataSaved.MainWindow_SubFormProductBase = SubFormProductBase
        UserSettings.getInstance().DataSaved.MainWindow_SubFormProduct = SubFormProduct
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateHist = SubFormRateHist
        UserSettings.getInstance().DataSaved.MainWindow_SubFormExercRateHist = SubFormExercRateHist
        UserSettings.getInstance().DataSaved.MainWindow_SubFormCust = SubFormCust
        UserSettings.getInstance().DataSaved.MainWindow_SubFormTrade = SubFormTrade
        UserSettings.getInstance().DataSaved.MainWindow_SubFormCash = SubFormCash
        UserSettings.getInstance().DataSaved.MainWindow_SubFormSysSettingsForm = SubFormSysSettingsForm
        UserSettings.getInstance().DataSaved.MainWindow_SubFormSysControlForm = SubFormSysControlForm
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskMonitor = SubFormRiskMonitor
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskSimulate = SubFormRiskSimulate
        UserSettings.getInstance().DataSaved.MainWindow_SubFormSalesPerformance = SubFormSalesPerformance
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateMonitor = SubFormRateMonitor
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateChartHist = SubFormRateChartHist
        UserSettings.getInstance().DataSaved.MainWindow_SubFormRateFilterLogList = SubFormRateFilterLogList
        UserSettings.getInstance().DataSaved.MainWindow_SubFormNowStatus = SubFormNowStatus
        UserSettings.getInstance().DataSaved.MainWindow_SubFormUser = SubFormUser
        UserSettings.getInstance().DataSaved.MainWindow_SubFormUser = SubFormCalcParamSettingsForm
        UserSettings.getInstance().DataSaved.MainWindow_SubFormOperationHist = SubFormOperationHist
        UserSettings.getInstance().DataSaved.MainWindow_SubFormOperationHistClient = SubFormOperationHistClient
        UserSettings.getInstance().DataSaved.MainWindow_SubFormFileDownloadList = SubFormFileDownloadList
    End Sub

    ''' <summary>
    ''' �t�H�[���N���[�Y�C�x���g
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainMenu_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        term()

        '�A�v���P�[�V�����I������
        If e.CloseReason <> CloseReason.ApplicationExitCall Then
            '���j���[�ȊO����̏I������Application.Exit()�����s���邱�ƂŊJ���Ă���t�H�[����FormClosed�C�x���g�𔭐�������
            Application.Exit()
        End If
    End Sub

    ''' <summary>
    ''' �t�H�[���ݒ�̓Ǎ�
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadFormSettings(Me, _
            False, _
            UserSettings.getInstance().DataSaved.MainWindow_FormSize, _
            UserSettings.getInstance().DataSaved.MainWindow_FormLocation)
    End Sub

    ''' <summary>
    ''' �t�H�[���ݒ�̕ۑ�
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.MainWindow_FormMaximized, _
            UserSettings.getInstance().DataSaved.MainWindow_FormSize, _
            UserSettings.getInstance().DataSaved.MainWindow_FormLocation)
        UserSettings.getInstance().save()
    End Sub

    ''' <summary>
    ''' ����������
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainMenu_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If UserSettings.getInstance().DataSaved.MainWindow_FormMaximized Then
            Me.WindowState = FormWindowState.Maximized
        End If
        InitSubForm()
    End Sub

    Private Sub InitSubForm()

        Dim whitelabel As Boolean = UserTypeManager.IsWL(SessionService.UserType)

        If UserSettings.getInstance().DataSaved.MainWindow_SubFormProductBase Then
            ProductBaseList.MdiParent = Me
            ProductBaseList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormProduct Then
            ProductList.MdiParent = Me
            ProductList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormRateHist Then
            RateHistList.MdiParent = Me
            RateHistList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormExercRateHist Then
            ExercRateHistList.MdiParent = Me
            ExercRateHistList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormCust Then
            CustList.MdiParent = Me
            CustList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormTrade Then
            TradeList.MdiParent = Me
            TradeList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormCash Then
            CashList.MdiParent = Me
            CashList.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormSysSettingsForm Then
            SysSettingsForm.MdiParent = Me
            SysSettingsForm.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormSysControlForm Then
            SysControlForm.MdiParent = Me
            SysControlForm.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskMonitor Then
            RiskMonitor.MdiParent = Me
            RiskMonitor.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRiskSimulate Then
            RiskSimulate.MdiParent = Me
            RiskSimulate.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormSalesPerformance Then
            SalesPerformanceList.MdiParent = Me
            SalesPerformanceList.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRateMonitor Then
            RateMonitor.MdiParent = Me
            RateMonitor.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormRateChartHist Then
            RateChartHistList.MdiParent = Me
            RateChartHistList.Show()
        End If
        If Not whitelabel AndAlso UserSettings.getInstance().DataSaved.MainWindow_SubFormRateFilterLogList Then
            RateFilterLogList.MdiParent = Me
            RateFilterLogList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormNowStatus Then
            NowStatusForm.MdiParent = Me
            NowStatusForm.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormUser Then
            UserList.MdiParent = Me
            UserList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormOperationHist Then
            OperationHistList.MdiParent = Me
            OperationHistList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormOperationHistClient Then
            OperationHistClientList.MdiParent = Me
            OperationHistClientList.Show()
        End If
        If UserSettings.getInstance().DataSaved.MainWindow_SubFormFileDownloadList Then
            FileDownloadList.MdiParent = Me
            FileDownloadList.Show()
        End If

        serviceRateTick = New RateTickService
    End Sub

    Private Sub Init()
        SetUserInfo()
        SetMenu()
        setTickInfo()
        RateFilterUpdateSeq = RateTickService.RateFilterUpdateSeq
        WatcherAlertUpdateSeq = RateTickService.WatcherAlertUpdateSeq
        SetAlertMessage(Nothing)
        SetWatcherAlertMessage(Nothing)
    End Sub

    Private Sub term()
        serviceRateTick = Nothing

        '�t�H�[���ݒ�̕ۑ�
        SaveSettings()

        SessionService.LogoutAdmin()
    End Sub

    Private NewTickErrorCount As Integer = 0
    Private Sub rateTick_NewTick() Handles serviceRateTick.NewTick
        NewTickErrorCount = 0
        setTickInfo()
        setRateLog()
        setWatcherAlertLog()
    End Sub

    Private Sub serviceRateTick_NewTickError(ErrorMessage As String) Handles serviceRateTick.NewTickError
        NewTickErrorCount += 1
        If (NewTickErrorCount >= 10) Then
            SessionService.ChangeConnectMode()
            NewTickErrorCount = 0
        End If
    End Sub

    Private Sub setTickInfo()
        Dim StatusName As String = ""
        Dim NextTimeTitle As String = ""
        If RateTickService.ProductStatus = 1 Then
            StatusName = "�����"
            NextTimeTitle = "��~���� "
        Else
            StatusName = "��~��"
            NextTimeTitle = "�J�n���� "
        End If
        slServerTime.Text = String.Format("�T�[�o�[���� {0:HH:mm:ss}", RateTickService.ServerTime)
        slServerStatus.Text = String.Format("�@�X�e�[�^�X:{0}", StatusName)
        slServerNextTime.Text = IIf(RateTickService.NextTime.Equals(Date.MinValue), "", String.Format("�@{0} {1:yyyy/MM/dd HH:mm:ss}", NextTimeTitle, RateTickService.NextTime))
        slServer.Text = String.Format("�@�ڑ��� {0}", SessionService.GetConnectText())
    End Sub

    Private Sub setRateLog()
        If Me.RateFilterUpdateSeq < RateTickService.RateFilterUpdateSeq Then
            serviceRateLog = New RateFilterLogService
            serviceRateLog.Read(Me.RateFilterUpdateSeq)
            Me.RateFilterUpdateSeq = RateTickService.RateFilterUpdateSeq
        End If
    End Sub

    Private Sub setWatcherAlertLog()
        If Me.WatcherAlertUpdateSeq < RateTickService.WatcherAlertUpdateSeq Then
            serviceAlertLog = New AlertLogService
            serviceAlertLog.Read(Me.WatcherAlertUpdateSeq)
            Me.WatcherAlertUpdateSeq = RateTickService.WatcherAlertUpdateSeq
        End If
    End Sub

    Private Sub SetAlertMessage(item As RateFilterLogData)
        If item Is Nothing Then
            PanelAlert.Visible = False
            lblAlertMessage.Text = ""
        Else
            PanelAlert.Visible = True
            lblAlertMessage.Text = String.Format("{0:yyyy/MM/dd HH:mm:ss.fff}�@{1}", item.LogTime, item.LogText)
            'System.Media.SystemSounds.Asterisk.Play()
            'System.Media.SystemSounds.Beep.Play()
            If Now.Subtract(LastAlertSoundTime).TotalSeconds() > 5 Then
                System.Media.SystemSounds.Exclamation.Play()
                LastAlertSoundTime = Now
            End If
        End If
    End Sub

    Private Sub SetWatcherAlertMessage(item As AlertLogData)
        If item Is Nothing Then
            PanelWatcherAlert.Visible = False
            lblWatcherAlertMessage.Text = ""
            lblAlertMessage.Text = ""
        Else
            PanelWatcherAlert.Visible = True
            lblWatcherAlertMessage.Text = String.Format("{0:yyyy/MM/dd HH:mm:ss.fff}�@{1}", item.LogTime, item.LogText)

            If Now.Subtract(LastAlertSoundTime).TotalSeconds() > 5 Then
                System.Media.SystemSounds.Exclamation.Play()
                LastAlertSoundTime = Now
            End If
        End If
    End Sub

    Private Sub SetUserInfo()
        slServer.Text = String.Format("�@�ڑ��� {0}", SessionService.GetConnectText())
        slUser.Text = String.Format("�@UserID:{0}  Name:{1}", SessionService.UserID, SessionService.UserName)
    End Sub

    Private Sub SetMenu()
        Dim admin As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        Dim adminview As Boolean = UserTypeManager.IsAdminView(SessionService.UserType)
        Dim edit As Boolean = UserTypeManager.IsEdit(SessionService.UserType)
        Dim whitelabel As Boolean = UserTypeManager.IsWL(SessionService.UserType)
        Dim whiterefer As Boolean = UserTypeManager.IsWLReferrer(SessionService.UserType)
        Dim whitelabelGroup As Boolean = whitelabel Or whiterefer

        miProductBaseReg.Enabled = admin
        miProductReg.Enabled = False
        miRateReg.Enabled = False
        miUserList.Enabled = adminview Or whitelabel                ' ���[�U�[�Ǘ��i���X�g�Q�Ɓj	�F2014/12 Admin/AdminRef/WL�ɋ���
        miTradeReg.Enabled = False
        miCashReg.Enabled = False

        miRateMonitor.Enabled = True                                ' ���[�g���j�^�[				�F2014/12 �SUserType�ɋ���(Not whitelabel����ύX)
        miRateFilterLog.Enabled = Not whitelabelGroup               ' ���[�g�t�B���^�[���O			�F2014/12 WL/WLReferrer�ȊO�ɋ���(Not Whitelabel����ύX)
        miRiskMonitor.Enabled = True                                ' ���X�N���j�^�[				�F2014/12 �SUserType�ɋ���(Not whitelabel����ύX)
        miRiskSimulate.Enabled = True                               ' ���X�N�V�~�����[�^�[			�F2014/12 �SUserType�ɋ���(Not whitelabel����ύX)
        miSysControlForm.Enabled = True                             ' �V�X�e������					�F2014/12 �SUserType�ɋ���(Not whitelabel����ύX)
        miSysSettingsForm.Enabled = True                            ' �V�X�e���ݒ�					�F2014/12 �SUserType�ɋ���(Not whitelabel����ύX)

        miRateList.Enabled = Not whitelabelGroup                    ' ���[�g						�F2014/12 WL/WLReferrer�ȊO�ɋ���(����ǉ�)
    End Sub

    Private Sub miFileLogout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles miFileLogout.Click
        Me.Close()
    End Sub

    Private Sub miVersion_Click(sender As System.Object, e As System.EventArgs) Handles miVersion.Click
        Using VI As frmVersionInformation = New frmVersionInformation()
            VI.ShowDialog()
        End Using
    End Sub

    Private Sub miProductList_Click(sender As System.Object, e As System.EventArgs) Handles miProductList.Click
        If SubFormProduct Then
            ProductList.Activate()
        Else
            ProductList.MdiParent = Me
            ProductList.Show()
        End If
    End Sub

    Private Sub miRateList_Click(sender As System.Object, e As System.EventArgs) Handles miRateList.Click
        If SubFormRateHist Then
            RateHistList.Activate()
        Else
            RateHistList.MdiParent = Me
            RateHistList.Show()
        End If
    End Sub

    Private Sub miSysSettingsForm_Click(sender As System.Object, e As System.EventArgs) Handles miSysSettingsForm.Click
        If SubFormSysSettingsForm Then
            SysSettingsForm.Activate()
        Else
            SysSettingsForm.MdiParent = Me
            SysSettingsForm.Show()
        End If
    End Sub

    Private Sub miProductBaseList_Click(sender As System.Object, e As System.EventArgs) Handles miProductBaseList.Click
        If SubFormProductBase Then
            ProductBaseList.Activate()
        Else
            ProductBaseList.MdiParent = Me
            ProductBaseList.Show()
        End If
    End Sub

    Private Sub miSysControlForm_Click(sender As System.Object, e As System.EventArgs) Handles miSysControlForm.Click
        If SubFormSysControlForm Then
            SysControlForm.Activate()
        Else
            SysControlForm.MdiParent = Me
            SysControlForm.Show()
        End If
    End Sub

    Private Sub miTradeList_Click(sender As System.Object, e As System.EventArgs) Handles miTradeList.Click
        If SubFormTrade Then
            TradeList.Activate()
        Else
            TradeList.MdiParent = Me
            TradeList.Show()
        End If
    End Sub

    Private Sub miCashList_Click(sender As System.Object, e As System.EventArgs) Handles miCashList.Click
        If SubFormCash Then
            CashList.Activate()
        Else
            CashList.MdiParent = Me
            CashList.Show()
        End If
    End Sub

    Private Sub miRiskMonitor_Click(sender As System.Object, e As System.EventArgs) Handles miRiskMonitor.Click
        If SubFormRiskMonitor Then
            RiskMonitor.Activate()
        Else
            RiskMonitor.MdiParent = Me
            RiskMonitor.Show()
        End If
    End Sub

    Private Sub miRiskSimulate_Click(sender As System.Object, e As System.EventArgs) Handles miRiskSimulate.Click
        If SubFormRiskSimulate Then
            RiskSimulate.Activate()
        Else
            RiskSimulate.MdiParent = Me
            RiskSimulate.Show()
        End If
    End Sub

    Private Sub miSalesPerformance_Click(sender As System.Object, e As System.EventArgs) Handles miSalesPerformance.Click
        If SubFormSalesPerformance Then
            SalesPerformanceList.Activate()
        Else
            SalesPerformanceList.MdiParent = Me
            SalesPerformanceList.Show()
        End If
    End Sub

    Private Sub miProductBaseReg_Click(sender As System.Object, e As System.EventArgs) Handles miProductBaseReg.Click
        If SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = Me
        ProductBaseForm.Code = ""
        ProductBaseForm.Show()
    End Sub

    Private Sub miProductReg_Click(sender As System.Object, e As System.EventArgs) Handles miProductReg.Click
        If SubFormProductForm Then
            ProductForm.Close()
        End If
        ProductForm.MdiParent = Me
        ProductForm.Code = ""
        ProductForm.Show()
    End Sub

    Private Sub miRateReg_Click(sender As System.Object, e As System.EventArgs) Handles miRateReg.Click
        If SubFormRateHistForm Then
            RateHistForm.Close()
        End If
        RateHistForm.MdiParent = Me
        RateHistForm.Code = ""
        RateHistForm.Show()
    End Sub

    Private Sub miTradeReg_Click(sender As System.Object, e As System.EventArgs) Handles miTradeReg.Click
        If SubFormTradeForm Then
            TradeForm.Close()
        End If
        TradeForm.MdiParent = Me
        TradeForm.Code = ""
        TradeForm.Show()
    End Sub

    Private Sub miCashReg_Click(sender As System.Object, e As System.EventArgs) Handles miCashReg.Click
        If SubFormCashForm Then
            CashForm.Close()
        End If
        CashForm.MdiParent = Me
        CashForm.Code = ""
        CashForm.Show()
    End Sub

    Private Sub miRateFilterLog_Click(sender As System.Object, e As System.EventArgs) Handles miRateFilterLog.Click
        If SubFormRateFilterLogList Then
            RateFilterLogList.Close()
        End If
        RateFilterLogList.MdiParent = Me
        RateFilterLogList.Show()
    End Sub

    Private Sub miRateMonitor_Click(sender As System.Object, e As System.EventArgs) Handles miRateMonitor.Click
        If SubFormRateMonitor Then
            RateMonitor.Close()
        End If
        RateMonitor.MdiParent = Me
        RateMonitor.Show()
    End Sub

    Private Sub miRateChartList_Click(sender As Object, e As EventArgs) Handles miRateChartList.Click
        If SubFormRateChartHist Then
            RateChartHistList.Activate()
        Else
            RateChartHistList.MdiParent = Me
            RateChartHistList.Show()
        End If
    End Sub

    Private Sub miNowStatusForm_Click(sender As System.Object, e As System.EventArgs) Handles miNowStatusForm.Click
        If SubFormNowStatus Then
            NowStatusForm.Activate()
        Else
            NowStatusForm.MdiParent = Me
            NowStatusForm.Show()
        End If
    End Sub

    Private Sub miCustList_Click(sender As System.Object, e As System.EventArgs) Handles miCustList.Click
        If SubFormCust Then
            CustList.Activate()
        Else
            CustList.MdiParent = Me
            CustList.Show()
        End If
    End Sub

    Private Sub miOperationHist_Click(sender As System.Object, e As System.EventArgs) Handles miOperationHist.Click
        If SubFormOperationHist Then
            OperationHistList.Activate()
        Else
            OperationHistList.MdiParent = Me
            OperationHistList.Show()
        End If
    End Sub

    Private Sub miOperationHistClient_Click(sender As System.Object, e As System.EventArgs) Handles miOperationHistClient.Click
        If SubFormOperationHistClient Then
            OperationHistClientList.Activate()
        Else
            OperationHistClientList.MdiParent = Me
            OperationHistClientList.Show()
        End If
    End Sub

    Private Sub miAlertLog_Click(sender As Object, e As EventArgs) Handles miAlertLog.Click
        If SubFormAlertHist Then
            AlertHistList.Activate()
        Else
            AlertHistList.MdiParent = Me
            AlertHistList.Show()
        End If
    End Sub

    Private Sub miUserList_Click(sender As System.Object, e As System.EventArgs) Handles miUserList.Click
        If SubFormUser Then
            UserList.Activate()
        Else
            UserList.MdiParent = Me
            UserList.Show()
        End If
    End Sub

    Private Sub miChangePassword_Click(sender As System.Object, e As System.EventArgs) Handles miChangePassword.Click
        Dim dlg As New ChangePassword
        dlg.ShowDialog(Me)
    End Sub

    Private Sub miFileDownload_Click(sender As System.Object, e As System.EventArgs) Handles miFileDownload.Click
        If SubFormFileDownloadList Then
            FileDownloadList.Activate()
        Else
            FileDownloadList.MdiParent = Me
            FileDownloadList.Show()
        End If
    End Sub

    Private Sub miReportDownload_Click(sender As Object, e As EventArgs) Handles miReportDownload.Click
        If SubFormReportDownload Then
            ReportDownload.Activate()
        Else
            ReportDownload.MdiParent = Me
            ReportDownload.Show()
        End If
    End Sub

    Private Sub miExercRateList_Click(sender As Object, e As EventArgs) Handles miExercRateList.Click
        If SubFormExercRateHist Then
            ExercRateHistList.Activate()
        Else
            ExercRateHistList.MdiParent = Me
            ExercRateHistList.Show()
        End If
    End Sub

    Private Sub miTestA_Click(sender As System.Object, e As System.EventArgs) Handles miTestA.Click
        TestA.MdiParent = Me
        TestA.Show()
    End Sub

    Private Sub miTestB_Click(sender As System.Object, e As System.EventArgs) Handles miTestB.Click
        TestB.MdiParent = Me
        TestB.Show()
    End Sub

    Private Sub miTestC_Click(sender As System.Object, e As System.EventArgs) Handles miTestC.Click
        ProductList.MdiParent = Me
        ProductList.Show()
    End Sub

    Private Sub miTestD_Click(sender As System.Object, e As System.EventArgs) Handles miTestD.Click
        TestD.MdiParent = Me
        TestD.Show()
    End Sub

    Private Sub miTestE_Click(sender As System.Object, e As System.EventArgs) Handles miTestE.Click
        TestE.MdiParent = Me
        TestE.Show()
    End Sub

    Private Sub serviceRateLog_ReadCancel() Handles serviceRateLog.ReadCancel
        serviceRateLog = Nothing
    End Sub

    Private Sub serviceRateLog_ReadError(ErrorMessage As String) Handles serviceRateLog.ReadError
        serviceRateLog = Nothing
    End Sub

    Private Sub serviceRateLog_ReadSuccess(list As System.Collections.Generic.List(Of RateFilterLogData), ExistNextFlag As Boolean, RateFilterUpdateSeq As Long) Handles serviceRateLog.ReadSuccess
        serviceRateLog = Nothing
        For Each item As RateFilterLogData In list
            If isAlertType(item.LogType) Then
                SetAlertMessage(item)
                Exit For
            End If
        Next
    End Sub

    Private Sub serviceAlertLog_ReadCancel() Handles serviceAlertLog.ReadCancel
        serviceAlertLog = Nothing
    End Sub

    Private Sub serviceAlertLog_ReadError(ErrorMessage As String) Handles serviceAlertLog.ReadError
        serviceAlertLog = Nothing
    End Sub

    Private Sub serviceAlertLog_ReadSuccess(list As List(Of AlertLogData), ExistNextFlag As Boolean, RateFilterUpdateSeq As Long) Handles serviceAlertLog.ReadSuccess
        serviceAlertLog = Nothing
        For Each item As AlertLogData In list

            If UserTypeManager.IsAdminView(SessionService.UserType) Then
                ' �Ǘ��҂ł���ΑS�ẴA���[�g��\��
                SetWatcherAlertMessage(item)
            Else
                ' �Ǘ��҈ȊO�͏�����Ђ̈ϑ��҂̃A���[�g�̂�
                If item.CmpCode = SessionService.CmpCode Then
                    SetWatcherAlertMessage(item)
                End If
            End If

        Next

    End Sub

    Private Function isAlertType(LogType As String) As Boolean
        Select Case LogType
            Case "01" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterSettings
            Case "11" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateFilter
            Case "12" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterCounterClear
            Case "13" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateChanged
            Case "14" : Return UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRate
            Case "15" : Return UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRateClear
            Case "21" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiff
            Case "22" : Return UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiffClear
        End Select
        Return False
    End Function

    Private Sub btnAlertClose_Click(sender As System.Object, e As System.EventArgs) Handles btnAlertClose.Click
        PanelAlert.Visible = False
    End Sub

    Private Sub btnWatcherAlertClose_Click(sender As Object, e As EventArgs) Handles btnWatcherAlertClose.Click
        PanelWatcherAlert.Visible = False
    End Sub

    Private Sub miTradeAccountSummaryDownload_Click(sender As Object, e As EventArgs) Handles miTradeAccountSummaryDownload.Click
        If SubFormTradeAccountSummaryDownload Then
            TradeAccountSummaryDownload.Activate()
        Else
            TradeAccountSummaryDownload.MdiParent = Me
            TradeAccountSummaryDownload.Show()
        End If
    End Sub
End Class
