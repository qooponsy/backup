﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainWindow
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.miFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.miFileLogout = New System.Windows.Forms.ToolStripMenuItem()
        Me.miProduct = New System.Windows.Forms.ToolStripMenuItem()
        Me.miProductBaseList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miProductBaseReg = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.miProductList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miProductReg = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRate = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRateList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miExercRateList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRateReg = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.miRateFilterLog = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRateMonitor = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.miRateChartList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miCust = New System.Windows.Forms.ToolStripMenuItem()
        Me.miCustList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTrade = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTradeList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTradeReg = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.miCashList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miCashReg = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRisk = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRiskMonitor = New System.Windows.Forms.ToolStripMenuItem()
        Me.miRiskSimulate = New System.Windows.Forms.ToolStripMenuItem()
        Me.miEarnings = New System.Windows.Forms.ToolStripMenuItem()
        Me.miSalesPerformance = New System.Windows.Forms.ToolStripMenuItem()
        Me.miSettings = New System.Windows.Forms.ToolStripMenuItem()
        Me.miSysSettingsForm = New System.Windows.Forms.ToolStripMenuItem()
        Me.miSysControlForm = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.miNowStatusForm = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.miOperationHist = New System.Windows.Forms.ToolStripMenuItem()
        Me.miOperationHistClient = New System.Windows.Forms.ToolStripMenuItem()
        Me.miAlertLog = New System.Windows.Forms.ToolStripMenuItem()
        Me.miUserList = New System.Windows.Forms.ToolStripMenuItem()
        Me.miChangePassword = New System.Windows.Forms.ToolStripMenuItem()
        Me.miDownload = New System.Windows.Forms.ToolStripMenuItem()
        Me.miFileDownload = New System.Windows.Forms.ToolStripMenuItem()
        Me.miReportDownload = New System.Windows.Forms.ToolStripMenuItem()
        Me.miHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.miVersion = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTest = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTestA = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTestB = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTestC = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTestD = New System.Windows.Forms.ToolStripMenuItem()
        Me.miTestE = New System.Windows.Forms.ToolStripMenuItem()
        Me.dsLocalDB = New System.Data.DataSet()
        Me.dsLocalDB_MarketPriceDataType = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        Me.dsLocalDB_Currency = New System.Data.DataTable()
        Me.DataColumn7 = New System.Data.DataColumn()
        Me.DataColumn8 = New System.Data.DataColumn()
        Me.DataColumn9 = New System.Data.DataColumn()
        Me.dsLocalDB_Portfolio = New System.Data.DataTable()
        Me.DataColumn10 = New System.Data.DataColumn()
        Me.DataColumn11 = New System.Data.DataColumn()
        Me.DataColumn12 = New System.Data.DataColumn()
        Me.DataColumn13 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceOnmemoryProduct = New System.Data.DataTable()
        Me.DataColumn14 = New System.Data.DataColumn()
        Me.DataColumn15 = New System.Data.DataColumn()
        Me.DataColumn16 = New System.Data.DataColumn()
        Me.DataColumn20 = New System.Data.DataColumn()
        Me.DataColumn77 = New System.Data.DataColumn()
        Me.DataColumn81 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceOnmemoryTrade = New System.Data.DataTable()
        Me.DataColumn17 = New System.Data.DataColumn()
        Me.DataColumn82 = New System.Data.DataColumn()
        Me.DataColumn18 = New System.Data.DataColumn()
        Me.DataColumn19 = New System.Data.DataColumn()
        Me.DataColumn21 = New System.Data.DataColumn()
        Me.DataColumn78 = New System.Data.DataColumn()
        Me.dsLocalDB_Product = New System.Data.DataTable()
        Me.DataColumn22 = New System.Data.DataColumn()
        Me.DataColumn23 = New System.Data.DataColumn()
        Me.DataColumn24 = New System.Data.DataColumn()
        Me.DataColumn25 = New System.Data.DataColumn()
        Me.DataColumn26 = New System.Data.DataColumn()
        Me.DataColumn27 = New System.Data.DataColumn()
        Me.DataColumn28 = New System.Data.DataColumn()
        Me.DataColumn29 = New System.Data.DataColumn()
        Me.DataColumn30 = New System.Data.DataColumn()
        Me.DataColumn31 = New System.Data.DataColumn()
        Me.DataColumn32 = New System.Data.DataColumn()
        Me.DataColumn33 = New System.Data.DataColumn()
        Me.DataColumn34 = New System.Data.DataColumn()
        Me.DataColumn35 = New System.Data.DataColumn()
        Me.DataColumn36 = New System.Data.DataColumn()
        Me.DataColumn37 = New System.Data.DataColumn()
        Me.DataColumn38 = New System.Data.DataColumn()
        Me.DataColumn39 = New System.Data.DataColumn()
        Me.DataColumn40 = New System.Data.DataColumn()
        Me.DataColumn41 = New System.Data.DataColumn()
        Me.DataColumn42 = New System.Data.DataColumn()
        Me.DataColumn43 = New System.Data.DataColumn()
        Me.DataColumn44 = New System.Data.DataColumn()
        Me.DataColumn45 = New System.Data.DataColumn()
        Me.DataColumn46 = New System.Data.DataColumn()
        Me.DataColumn47 = New System.Data.DataColumn()
        Me.DataColumn48 = New System.Data.DataColumn()
        Me.DataColumn49 = New System.Data.DataColumn()
        Me.DataColumn50 = New System.Data.DataColumn()
        Me.DataColumn51 = New System.Data.DataColumn()
        Me.DataColumn52 = New System.Data.DataColumn()
        Me.DataColumn53 = New System.Data.DataColumn()
        Me.DataColumn54 = New System.Data.DataColumn()
        Me.DataColumn55 = New System.Data.DataColumn()
        Me.DataColumn56 = New System.Data.DataColumn()
        Me.DataColumn57 = New System.Data.DataColumn()
        Me.DataColumn58 = New System.Data.DataColumn()
        Me.DataColumn59 = New System.Data.DataColumn()
        Me.DataColumn60 = New System.Data.DataColumn()
        Me.DataColumn61 = New System.Data.DataColumn()
        Me.DataColumn62 = New System.Data.DataColumn()
        Me.DataColumn63 = New System.Data.DataColumn()
        Me.DataColumn64 = New System.Data.DataColumn()
        Me.DataColumn65 = New System.Data.DataColumn()
        Me.DataColumn66 = New System.Data.DataColumn()
        Me.DataColumn67 = New System.Data.DataColumn()
        Me.DataColumn68 = New System.Data.DataColumn()
        Me.DataColumn69 = New System.Data.DataColumn()
        Me.DataColumn70 = New System.Data.DataColumn()
        Me.DataColumn71 = New System.Data.DataColumn()
        Me.DataColumn72 = New System.Data.DataColumn()
        Me.DataColumn76 = New System.Data.DataColumn()
        Me.DataColumn173 = New System.Data.DataColumn()
        Me.DataColumn206 = New System.Data.DataColumn()
        Me.DataColumn207 = New System.Data.DataColumn()
        Me.DataColumn208 = New System.Data.DataColumn()
        Me.DataColumn209 = New System.Data.DataColumn()
        Me.DataColumn210 = New System.Data.DataColumn()
        Me.DataColumn211 = New System.Data.DataColumn()
        Me.DataColumn3 = New System.Data.DataColumn()
        Me.dsLocalDB_PriceType = New System.Data.DataTable()
        Me.DataColumn79 = New System.Data.DataColumn()
        Me.DataColumn80 = New System.Data.DataColumn()
        Me.dsLocalDB_ConversionFactor = New System.Data.DataTable()
        Me.DataColumn83 = New System.Data.DataColumn()
        Me.DataColumn84 = New System.Data.DataColumn()
        Me.DataColumn85 = New System.Data.DataColumn()
        Me.DataColumn86 = New System.Data.DataColumn()
        Me.DataColumn87 = New System.Data.DataColumn()
        Me.DataColumn88 = New System.Data.DataColumn()
        Me.DataColumn89 = New System.Data.DataColumn()
        Me.DataColumn90 = New System.Data.DataColumn()
        Me.dsLocalDB_CodeData = New System.Data.DataTable()
        Me.DataColumn91 = New System.Data.DataColumn()
        Me.DataColumn92 = New System.Data.DataColumn()
        Me.DataColumn93 = New System.Data.DataColumn()
        Me.DataColumn94 = New System.Data.DataColumn()
        Me.DataColumn95 = New System.Data.DataColumn()
        Me.dsLocalDB_Position = New System.Data.DataTable()
        Me.DataColumn96 = New System.Data.DataColumn()
        Me.DataColumn97 = New System.Data.DataColumn()
        Me.DataColumn98 = New System.Data.DataColumn()
        Me.DataColumn99 = New System.Data.DataColumn()
        Me.DataColumn100 = New System.Data.DataColumn()
        Me.DataColumn101 = New System.Data.DataColumn()
        Me.DataColumn102 = New System.Data.DataColumn()
        Me.DataColumn103 = New System.Data.DataColumn()
        Me.DataColumn104 = New System.Data.DataColumn()
        Me.DataColumn105 = New System.Data.DataColumn()
        Me.DataColumn106 = New System.Data.DataColumn()
        Me.DataColumn107 = New System.Data.DataColumn()
        Me.DataColumn108 = New System.Data.DataColumn()
        Me.DataColumn109 = New System.Data.DataColumn()
        Me.DataColumn110 = New System.Data.DataColumn()
        Me.DataColumn111 = New System.Data.DataColumn()
        Me.DataColumn112 = New System.Data.DataColumn()
        Me.DataColumn171 = New System.Data.DataColumn()
        Me.dsLocalDB_Trade = New System.Data.DataTable()
        Me.DataColumn113 = New System.Data.DataColumn()
        Me.DataColumn114 = New System.Data.DataColumn()
        Me.DataColumn115 = New System.Data.DataColumn()
        Me.DataColumn116 = New System.Data.DataColumn()
        Me.DataColumn117 = New System.Data.DataColumn()
        Me.DataColumn118 = New System.Data.DataColumn()
        Me.DataColumn119 = New System.Data.DataColumn()
        Me.DataColumn120 = New System.Data.DataColumn()
        Me.DataColumn121 = New System.Data.DataColumn()
        Me.DataColumn122 = New System.Data.DataColumn()
        Me.DataColumn123 = New System.Data.DataColumn()
        Me.DataColumn124 = New System.Data.DataColumn()
        Me.DataColumn125 = New System.Data.DataColumn()
        Me.DataColumn126 = New System.Data.DataColumn()
        Me.DataColumn127 = New System.Data.DataColumn()
        Me.DataColumn128 = New System.Data.DataColumn()
        Me.DataColumn129 = New System.Data.DataColumn()
        Me.DataColumn130 = New System.Data.DataColumn()
        Me.DataColumn131 = New System.Data.DataColumn()
        Me.DataColumn132 = New System.Data.DataColumn()
        Me.DataColumn133 = New System.Data.DataColumn()
        Me.DataColumn134 = New System.Data.DataColumn()
        Me.DataColumn135 = New System.Data.DataColumn()
        Me.DataColumn136 = New System.Data.DataColumn()
        Me.DataColumn137 = New System.Data.DataColumn()
        Me.DataColumn138 = New System.Data.DataColumn()
        Me.DataColumn139 = New System.Data.DataColumn()
        Me.DataColumn140 = New System.Data.DataColumn()
        Me.DataColumn141 = New System.Data.DataColumn()
        Me.DataColumn142 = New System.Data.DataColumn()
        Me.DataColumn143 = New System.Data.DataColumn()
        Me.DataColumn144 = New System.Data.DataColumn()
        Me.DataColumn145 = New System.Data.DataColumn()
        Me.DataColumn146 = New System.Data.DataColumn()
        Me.DataColumn147 = New System.Data.DataColumn()
        Me.DataColumn148 = New System.Data.DataColumn()
        Me.DataColumn149 = New System.Data.DataColumn()
        Me.DataColumn150 = New System.Data.DataColumn()
        Me.DataColumn151 = New System.Data.DataColumn()
        Me.DataColumn152 = New System.Data.DataColumn()
        Me.DataColumn153 = New System.Data.DataColumn()
        Me.DataColumn154 = New System.Data.DataColumn()
        Me.DataColumn155 = New System.Data.DataColumn()
        Me.DataColumn156 = New System.Data.DataColumn()
        Me.DataColumn172 = New System.Data.DataColumn()
        Me.DataColumn193 = New System.Data.DataColumn()
        Me.DataColumn194 = New System.Data.DataColumn()
        Me.DataColumn195 = New System.Data.DataColumn()
        Me.DataColumn196 = New System.Data.DataColumn()
        Me.DataColumn197 = New System.Data.DataColumn()
        Me.DataColumn198 = New System.Data.DataColumn()
        Me.DataColumn199 = New System.Data.DataColumn()
        Me.DataColumn200 = New System.Data.DataColumn()
        Me.DataColumn201 = New System.Data.DataColumn()
        Me.DataColumn202 = New System.Data.DataColumn()
        Me.DataColumn203 = New System.Data.DataColumn()
        Me.DataColumn204 = New System.Data.DataColumn()
        Me.DataColumn205 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceProduct = New System.Data.DataTable()
        Me.DataColumn178 = New System.Data.DataColumn()
        Me.DataColumn157 = New System.Data.DataColumn()
        Me.DataColumn158 = New System.Data.DataColumn()
        Me.DataColumn159 = New System.Data.DataColumn()
        Me.DataColumn160 = New System.Data.DataColumn()
        Me.DataColumn161 = New System.Data.DataColumn()
        Me.DataColumn169 = New System.Data.DataColumn()
        Me.DataColumn174 = New System.Data.DataColumn()
        Me.DataColumn175 = New System.Data.DataColumn()
        Me.DataColumn230 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceTrade = New System.Data.DataTable()
        Me.DataColumn179 = New System.Data.DataColumn()
        Me.DataColumn162 = New System.Data.DataColumn()
        Me.DataColumn163 = New System.Data.DataColumn()
        Me.DataColumn164 = New System.Data.DataColumn()
        Me.DataColumn165 = New System.Data.DataColumn()
        Me.DataColumn166 = New System.Data.DataColumn()
        Me.DataColumn170 = New System.Data.DataColumn()
        Me.DataColumn176 = New System.Data.DataColumn()
        Me.DataColumn177 = New System.Data.DataColumn()
        Me.DataColumn6 = New System.Data.DataColumn()
        Me.DataColumn231 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceManagement = New System.Data.DataTable()
        Me.DataColumn167 = New System.Data.DataColumn()
        Me.DataColumn168 = New System.Data.DataColumn()
        Me.dsLocalDB_Grade = New System.Data.DataTable()
        Me.DataColumn180 = New System.Data.DataColumn()
        Me.DataColumn181 = New System.Data.DataColumn()
        Me.DataColumn182 = New System.Data.DataColumn()
        Me.DataColumn183 = New System.Data.DataColumn()
        Me.DataColumn184 = New System.Data.DataColumn()
        Me.DataColumn185 = New System.Data.DataColumn()
        Me.DataColumn186 = New System.Data.DataColumn()
        Me.DataColumn187 = New System.Data.DataColumn()
        Me.DataColumn188 = New System.Data.DataColumn()
        Me.DataColumn189 = New System.Data.DataColumn()
        Me.DataColumn190 = New System.Data.DataColumn()
        Me.DataColumn191 = New System.Data.DataColumn()
        Me.DataColumn192 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceRepoRate = New System.Data.DataTable()
        Me.DataColumn212 = New System.Data.DataColumn()
        Me.DataColumn213 = New System.Data.DataColumn()
        Me.DataColumn214 = New System.Data.DataColumn()
        Me.DataColumn215 = New System.Data.DataColumn()
        Me.DataColumn216 = New System.Data.DataColumn()
        Me.DataColumn4 = New System.Data.DataColumn()
        Me.DataColumn5 = New System.Data.DataColumn()
        Me.DataColumn232 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceShortRate = New System.Data.DataTable()
        Me.DataColumn217 = New System.Data.DataColumn()
        Me.DataColumn218 = New System.Data.DataColumn()
        Me.DataColumn219 = New System.Data.DataColumn()
        Me.DataColumn220 = New System.Data.DataColumn()
        Me.DataColumn221 = New System.Data.DataColumn()
        Me.DataColumn222 = New System.Data.DataColumn()
        Me.DataColumn223 = New System.Data.DataColumn()
        Me.DataColumn233 = New System.Data.DataColumn()
        Me.dsLocalDB_MarketPriceOnmemoryRepoRate = New System.Data.DataTable()
        Me.DataColumn224 = New System.Data.DataColumn()
        Me.DataColumn225 = New System.Data.DataColumn()
        Me.DataColumn226 = New System.Data.DataColumn()
        Me.DataColumn227 = New System.Data.DataColumn()
        Me.DataColumn228 = New System.Data.DataColumn()
        Me.DataColumn229 = New System.Data.DataColumn()
        Me.DataColumn234 = New System.Data.DataColumn()
        Me.DataColumn74 = New System.Data.DataColumn()
        Me.DataColumn75 = New System.Data.DataColumn()
        Me.DataColumn73 = New System.Data.DataColumn()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.slServerTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.slUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.slServerStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.slServerNextTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.slServer = New System.Windows.Forms.ToolStripStatusLabel()
        Me.PanelAlert = New System.Windows.Forms.Panel()
        Me.lblAlertMessage = New System.Windows.Forms.Label()
        Me.PanelWatcherAlert = New System.Windows.Forms.Panel()
        Me.lblWatcherAlertMessage = New System.Windows.Forms.Label()
        Me.miTradeAccountSummaryDownload = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.dsLocalDB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceDataType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_Currency, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_Portfolio, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceOnmemoryProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceOnmemoryTrade, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_Product, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_PriceType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_ConversionFactor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_CodeData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_Position, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_Trade, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceProduct, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceTrade, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceManagement, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_Grade, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceRepoRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceShortRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dsLocalDB_MarketPriceOnmemoryRepoRate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.PanelAlert.SuspendLayout()
        Me.PanelWatcherAlert.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miFile, Me.miProduct, Me.miRate, Me.miCust, Me.miTrade, Me.miRisk, Me.miEarnings, Me.miSettings, Me.miDownload, Me.miHelp, Me.miTest})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1008, 26)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'miFile
        '
        Me.miFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miFileLogout})
        Me.miFile.Name = "miFile"
        Me.miFile.Size = New System.Drawing.Size(68, 22)
        Me.miFile.Text = "ファイル"
        '
        'miFileLogout
        '
        Me.miFileLogout.Name = "miFileLogout"
        Me.miFileLogout.Size = New System.Drawing.Size(136, 22)
        Me.miFileLogout.Text = "ログアウト"
        '
        'miProduct
        '
        Me.miProduct.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miProductBaseList, Me.miProductBaseReg, Me.ToolStripSeparator1, Me.miProductList, Me.miProductReg})
        Me.miProduct.Name = "miProduct"
        Me.miProduct.Size = New System.Drawing.Size(44, 22)
        Me.miProduct.Text = "銘柄"
        '
        'miProductBaseList
        '
        Me.miProductBaseList.Name = "miProductBaseList"
        Me.miProductBaseList.Size = New System.Drawing.Size(148, 22)
        Me.miProductBaseList.Text = "銘柄設定一覧"
        '
        'miProductBaseReg
        '
        Me.miProductBaseReg.Name = "miProductBaseReg"
        Me.miProductBaseReg.Size = New System.Drawing.Size(148, 22)
        Me.miProductBaseReg.Text = "銘柄設定登録"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(145, 6)
        '
        'miProductList
        '
        Me.miProductList.Name = "miProductList"
        Me.miProductList.Size = New System.Drawing.Size(148, 22)
        Me.miProductList.Text = "銘柄一覧"
        '
        'miProductReg
        '
        Me.miProductReg.Name = "miProductReg"
        Me.miProductReg.Size = New System.Drawing.Size(148, 22)
        Me.miProductReg.Text = "銘柄登録"
        '
        'miRate
        '
        Me.miRate.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miRateList, Me.miExercRateList, Me.miRateReg, Me.ToolStripSeparator3, Me.miRateFilterLog, Me.miRateMonitor, Me.ToolStripSeparator6, Me.miRateChartList})
        Me.miRate.Name = "miRate"
        Me.miRate.Size = New System.Drawing.Size(56, 22)
        Me.miRate.Text = "レート"
        '
        'miRateList
        '
        Me.miRateList.Name = "miRateList"
        Me.miRateList.Size = New System.Drawing.Size(184, 22)
        Me.miRateList.Text = "レート一覧"
        '
        'miExercRateList
        '
        Me.miExercRateList.Name = "miExercRateList"
        Me.miExercRateList.Size = New System.Drawing.Size(184, 22)
        Me.miExercRateList.Text = "行使レート一覧"
        '
        'miRateReg
        '
        Me.miRateReg.Name = "miRateReg"
        Me.miRateReg.Size = New System.Drawing.Size(184, 22)
        Me.miRateReg.Text = "レート登録"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(181, 6)
        '
        'miRateFilterLog
        '
        Me.miRateFilterLog.Name = "miRateFilterLog"
        Me.miRateFilterLog.Size = New System.Drawing.Size(184, 22)
        Me.miRateFilterLog.Text = "レートログ"
        '
        'miRateMonitor
        '
        Me.miRateMonitor.Name = "miRateMonitor"
        Me.miRateMonitor.Size = New System.Drawing.Size(184, 22)
        Me.miRateMonitor.Text = "レートモニター"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(181, 6)
        '
        'miRateChartList
        '
        Me.miRateChartList.Name = "miRateChartList"
        Me.miRateChartList.Size = New System.Drawing.Size(184, 22)
        Me.miRateChartList.Text = "レートチャート一覧"
        '
        'miCust
        '
        Me.miCust.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miCustList})
        Me.miCust.Name = "miCust"
        Me.miCust.Size = New System.Drawing.Size(56, 22)
        Me.miCust.Text = "委託者"
        '
        'miCustList
        '
        Me.miCustList.Name = "miCustList"
        Me.miCustList.Size = New System.Drawing.Size(136, 22)
        Me.miCustList.Text = "委託者一覧"
        '
        'miTrade
        '
        Me.miTrade.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miTradeList, Me.miTradeReg, Me.ToolStripSeparator2, Me.miCashList, Me.miCashReg})
        Me.miTrade.Name = "miTrade"
        Me.miTrade.Size = New System.Drawing.Size(44, 22)
        Me.miTrade.Text = "取引"
        '
        'miTradeList
        '
        Me.miTradeList.Name = "miTradeList"
        Me.miTradeList.Size = New System.Drawing.Size(124, 22)
        Me.miTradeList.Text = "取引一覧"
        '
        'miTradeReg
        '
        Me.miTradeReg.Name = "miTradeReg"
        Me.miTradeReg.Size = New System.Drawing.Size(124, 22)
        Me.miTradeReg.Text = "取引登録"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(121, 6)
        '
        'miCashList
        '
        Me.miCashList.Name = "miCashList"
        Me.miCashList.Size = New System.Drawing.Size(124, 22)
        Me.miCashList.Text = "残高一覧"
        '
        'miCashReg
        '
        Me.miCashReg.Name = "miCashReg"
        Me.miCashReg.Size = New System.Drawing.Size(124, 22)
        Me.miCashReg.Text = "残高登録"
        '
        'miRisk
        '
        Me.miRisk.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miRiskMonitor, Me.miRiskSimulate})
        Me.miRisk.Name = "miRisk"
        Me.miRisk.Size = New System.Drawing.Size(56, 22)
        Me.miRisk.Text = "リスク"
        '
        'miRiskMonitor
        '
        Me.miRiskMonitor.Name = "miRiskMonitor"
        Me.miRiskMonitor.Size = New System.Drawing.Size(184, 22)
        Me.miRiskMonitor.Text = "リスクモニタ"
        '
        'miRiskSimulate
        '
        Me.miRiskSimulate.Name = "miRiskSimulate"
        Me.miRiskSimulate.Size = New System.Drawing.Size(184, 22)
        Me.miRiskSimulate.Text = "リスクシミュレータ"
        '
        'miEarnings
        '
        Me.miEarnings.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miSalesPerformance})
        Me.miEarnings.Name = "miEarnings"
        Me.miEarnings.Size = New System.Drawing.Size(44, 22)
        Me.miEarnings.Text = "収益"
        '
        'miSalesPerformance
        '
        Me.miSalesPerformance.Name = "miSalesPerformance"
        Me.miSalesPerformance.Size = New System.Drawing.Size(136, 22)
        Me.miSalesPerformance.Text = "営業実績表"
        '
        'miSettings
        '
        Me.miSettings.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miSysSettingsForm, Me.miSysControlForm, Me.ToolStripSeparator4, Me.miNowStatusForm, Me.ToolStripSeparator5, Me.miOperationHist, Me.miOperationHistClient, Me.miAlertLog, Me.miUserList, Me.miChangePassword})
        Me.miSettings.Name = "miSettings"
        Me.miSettings.Size = New System.Drawing.Size(44, 22)
        Me.miSettings.Text = "設定"
        '
        'miSysSettingsForm
        '
        Me.miSysSettingsForm.Name = "miSysSettingsForm"
        Me.miSysSettingsForm.Size = New System.Drawing.Size(160, 22)
        Me.miSysSettingsForm.Text = "システム設定"
        '
        'miSysControlForm
        '
        Me.miSysControlForm.Name = "miSysControlForm"
        Me.miSysControlForm.Size = New System.Drawing.Size(160, 22)
        Me.miSysControlForm.Text = "システム制御"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(157, 6)
        '
        'miNowStatusForm
        '
        Me.miNowStatusForm.Name = "miNowStatusForm"
        Me.miNowStatusForm.Size = New System.Drawing.Size(160, 22)
        Me.miNowStatusForm.Text = "稼動ステータス"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(157, 6)
        '
        'miOperationHist
        '
        Me.miOperationHist.Name = "miOperationHist"
        Me.miOperationHist.Size = New System.Drawing.Size(160, 22)
        Me.miOperationHist.Text = "管理者操作ログ"
        '
        'miOperationHistClient
        '
        Me.miOperationHistClient.Name = "miOperationHistClient"
        Me.miOperationHistClient.Size = New System.Drawing.Size(160, 22)
        Me.miOperationHistClient.Text = "委託者操作ログ"
        '
        'miAlertLog
        '
        Me.miAlertLog.Name = "miAlertLog"
        Me.miAlertLog.Size = New System.Drawing.Size(160, 22)
        Me.miAlertLog.Text = "アラートログ"
        '
        'miUserList
        '
        Me.miUserList.Name = "miUserList"
        Me.miUserList.Size = New System.Drawing.Size(160, 22)
        Me.miUserList.Text = "ユーザー管理"
        '
        'miChangePassword
        '
        Me.miChangePassword.Name = "miChangePassword"
        Me.miChangePassword.Size = New System.Drawing.Size(160, 22)
        Me.miChangePassword.Text = "パスワード変更"
        '
        'miDownload
        '
        Me.miDownload.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miFileDownload, Me.miReportDownload, Me.miTradeAccountSummaryDownload})
        Me.miDownload.Name = "miDownload"
        Me.miDownload.Size = New System.Drawing.Size(92, 22)
        Me.miDownload.Text = "ダウンロード"
        '
        'miFileDownload
        '
        Me.miFileDownload.Name = "miFileDownload"
        Me.miFileDownload.Size = New System.Drawing.Size(196, 22)
        Me.miFileDownload.Text = "ファイルダウンロード"
        '
        'miReportDownload
        '
        Me.miReportDownload.Name = "miReportDownload"
        Me.miReportDownload.Size = New System.Drawing.Size(196, 22)
        Me.miReportDownload.Text = "報告書データ"
        '
        'miHelp
        '
        Me.miHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miVersion})
        Me.miHelp.Name = "miHelp"
        Me.miHelp.Size = New System.Drawing.Size(56, 22)
        Me.miHelp.Text = "ヘルプ"
        '
        'miVersion
        '
        Me.miVersion.Name = "miVersion"
        Me.miVersion.Size = New System.Drawing.Size(160, 22)
        Me.miVersion.Text = "バージョン情報"
        '
        'miTest
        '
        Me.miTest.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miTestA, Me.miTestB, Me.miTestC, Me.miTestD, Me.miTestE})
        Me.miTest.Name = "miTest"
        Me.miTest.Size = New System.Drawing.Size(56, 22)
        Me.miTest.Text = "テスト"
        Me.miTest.Visible = False
        '
        'miTestA
        '
        Me.miTestA.Name = "miTestA"
        Me.miTestA.Size = New System.Drawing.Size(121, 22)
        Me.miTestA.Text = "開発者A"
        '
        'miTestB
        '
        Me.miTestB.Name = "miTestB"
        Me.miTestB.Size = New System.Drawing.Size(121, 22)
        Me.miTestB.Text = "開発者B"
        '
        'miTestC
        '
        Me.miTestC.Name = "miTestC"
        Me.miTestC.Size = New System.Drawing.Size(121, 22)
        Me.miTestC.Text = "開発者C"
        '
        'miTestD
        '
        Me.miTestD.Name = "miTestD"
        Me.miTestD.Size = New System.Drawing.Size(121, 22)
        Me.miTestD.Text = "開発者D"
        '
        'miTestE
        '
        Me.miTestE.Name = "miTestE"
        Me.miTestE.Size = New System.Drawing.Size(121, 22)
        Me.miTestE.Text = "開発者E"
        '
        'dsLocalDB
        '
        Me.dsLocalDB.DataSetName = "LocalDB"
        Me.dsLocalDB.Tables.AddRange(New System.Data.DataTable() {Me.dsLocalDB_MarketPriceDataType, Me.dsLocalDB_Currency, Me.dsLocalDB_Portfolio, Me.dsLocalDB_MarketPriceOnmemoryProduct, Me.dsLocalDB_MarketPriceOnmemoryTrade, Me.dsLocalDB_Product, Me.dsLocalDB_PriceType, Me.dsLocalDB_ConversionFactor, Me.dsLocalDB_CodeData, Me.dsLocalDB_Position, Me.dsLocalDB_Trade, Me.dsLocalDB_MarketPriceProduct, Me.dsLocalDB_MarketPriceTrade, Me.dsLocalDB_MarketPriceManagement, Me.dsLocalDB_Grade, Me.dsLocalDB_MarketPriceRepoRate, Me.dsLocalDB_MarketPriceShortRate, Me.dsLocalDB_MarketPriceOnmemoryRepoRate})
        '
        'dsLocalDB_MarketPriceDataType
        '
        Me.dsLocalDB_MarketPriceDataType.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2})
        Me.dsLocalDB_MarketPriceDataType.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"code_item"}, True)})
        Me.dsLocalDB_MarketPriceDataType.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn1}
        Me.dsLocalDB_MarketPriceDataType.TableName = "MarketPriceDataType"
        '
        'DataColumn1
        '
        Me.DataColumn1.AllowDBNull = False
        Me.DataColumn1.ColumnName = "code_item"
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "code_item_name"
        '
        'dsLocalDB_Currency
        '
        Me.dsLocalDB_Currency.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn7, Me.DataColumn8, Me.DataColumn9})
        Me.dsLocalDB_Currency.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"currency_code"}, True)})
        Me.dsLocalDB_Currency.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn7}
        Me.dsLocalDB_Currency.TableName = "Currency"
        '
        'DataColumn7
        '
        Me.DataColumn7.AllowDBNull = False
        Me.DataColumn7.ColumnName = "currency_code"
        '
        'DataColumn8
        '
        Me.DataColumn8.ColumnName = "disp_type"
        '
        'DataColumn9
        '
        Me.DataColumn9.ColumnName = "disp_order"
        Me.DataColumn9.DataType = GetType(Integer)
        '
        'dsLocalDB_Portfolio
        '
        Me.dsLocalDB_Portfolio.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn10, Me.DataColumn11, Me.DataColumn12, Me.DataColumn13})
        Me.dsLocalDB_Portfolio.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"portfolio_code"}, True)})
        Me.dsLocalDB_Portfolio.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn10}
        Me.dsLocalDB_Portfolio.TableName = "Portfolio"
        '
        'DataColumn10
        '
        Me.DataColumn10.AllowDBNull = False
        Me.DataColumn10.ColumnName = "portfolio_code"
        Me.DataColumn10.DataType = GetType(Integer)
        '
        'DataColumn11
        '
        Me.DataColumn11.ColumnName = "portfolio_type"
        '
        'DataColumn12
        '
        Me.DataColumn12.ColumnName = "portfolio_name"
        '
        'DataColumn13
        '
        Me.DataColumn13.ColumnName = "sys_delete"
        Me.DataColumn13.DataType = GetType(Boolean)
        '
        'dsLocalDB_MarketPriceOnmemoryProduct
        '
        Me.dsLocalDB_MarketPriceOnmemoryProduct.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn14, Me.DataColumn15, Me.DataColumn16, Me.DataColumn20, Me.DataColumn77, Me.DataColumn81})
        Me.dsLocalDB_MarketPriceOnmemoryProduct.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"product_code"}, True)})
        Me.dsLocalDB_MarketPriceOnmemoryProduct.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn14}
        Me.dsLocalDB_MarketPriceOnmemoryProduct.TableName = "MarketPriceOnmemoryProduct"
        '
        'DataColumn14
        '
        Me.DataColumn14.AllowDBNull = False
        Me.DataColumn14.Caption = "銘柄コード"
        Me.DataColumn14.ColumnName = "product_code"
        Me.DataColumn14.DataType = GetType(Integer)
        '
        'DataColumn15
        '
        Me.DataColumn15.Caption = "銘柄名称"
        Me.DataColumn15.ColumnName = "product_name"
        '
        'DataColumn16
        '
        Me.DataColumn16.Caption = "価格種別"
        Me.DataColumn16.ColumnName = "price_type"
        '
        'DataColumn20
        '
        Me.DataColumn20.Caption = "時価"
        Me.DataColumn20.ColumnName = "price"
        Me.DataColumn20.DataType = GetType(Decimal)
        '
        'DataColumn77
        '
        Me.DataColumn77.ColumnName = "tag"
        Me.DataColumn77.DataType = GetType(Object)
        '
        'DataColumn81
        '
        Me.DataColumn81.AllowDBNull = False
        Me.DataColumn81.ColumnName = "use"
        Me.DataColumn81.DataType = GetType(Boolean)
        Me.DataColumn81.DefaultValue = False
        '
        'dsLocalDB_MarketPriceOnmemoryTrade
        '
        Me.dsLocalDB_MarketPriceOnmemoryTrade.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn17, Me.DataColumn82, Me.DataColumn18, Me.DataColumn19, Me.DataColumn21, Me.DataColumn78})
        Me.dsLocalDB_MarketPriceOnmemoryTrade.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"trade_no"}, True)})
        Me.dsLocalDB_MarketPriceOnmemoryTrade.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn17}
        Me.dsLocalDB_MarketPriceOnmemoryTrade.TableName = "MarketPriceOnmemoryTrade"
        '
        'DataColumn17
        '
        Me.DataColumn17.AllowDBNull = False
        Me.DataColumn17.Caption = "取引番号"
        Me.DataColumn17.ColumnName = "trade_no"
        Me.DataColumn17.DataType = GetType(Integer)
        '
        'DataColumn82
        '
        Me.DataColumn82.ColumnName = "product_code"
        Me.DataColumn82.DataType = GetType(Integer)
        '
        'DataColumn18
        '
        Me.DataColumn18.Caption = "銘柄名称"
        Me.DataColumn18.ColumnName = "product_name"
        '
        'DataColumn19
        '
        Me.DataColumn19.Caption = "価格種別"
        Me.DataColumn19.ColumnName = "price_type"
        '
        'DataColumn21
        '
        Me.DataColumn21.Caption = "時価"
        Me.DataColumn21.ColumnName = "price"
        Me.DataColumn21.DataType = GetType(Decimal)
        '
        'DataColumn78
        '
        Me.DataColumn78.ColumnName = "tag"
        Me.DataColumn78.DataType = GetType(Object)
        '
        'dsLocalDB_Product
        '
        Me.dsLocalDB_Product.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn22, Me.DataColumn23, Me.DataColumn24, Me.DataColumn25, Me.DataColumn26, Me.DataColumn27, Me.DataColumn28, Me.DataColumn29, Me.DataColumn30, Me.DataColumn31, Me.DataColumn32, Me.DataColumn33, Me.DataColumn34, Me.DataColumn35, Me.DataColumn36, Me.DataColumn37, Me.DataColumn38, Me.DataColumn39, Me.DataColumn40, Me.DataColumn41, Me.DataColumn42, Me.DataColumn43, Me.DataColumn44, Me.DataColumn45, Me.DataColumn46, Me.DataColumn47, Me.DataColumn48, Me.DataColumn49, Me.DataColumn50, Me.DataColumn51, Me.DataColumn52, Me.DataColumn53, Me.DataColumn54, Me.DataColumn55, Me.DataColumn56, Me.DataColumn57, Me.DataColumn58, Me.DataColumn59, Me.DataColumn60, Me.DataColumn61, Me.DataColumn62, Me.DataColumn63, Me.DataColumn64, Me.DataColumn65, Me.DataColumn66, Me.DataColumn67, Me.DataColumn68, Me.DataColumn69, Me.DataColumn70, Me.DataColumn71, Me.DataColumn72, Me.DataColumn76, Me.DataColumn173, Me.DataColumn206, Me.DataColumn207, Me.DataColumn208, Me.DataColumn209, Me.DataColumn210, Me.DataColumn211, Me.DataColumn3})
        Me.dsLocalDB_Product.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"product_code"}, True)})
        Me.dsLocalDB_Product.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn22}
        Me.dsLocalDB_Product.TableName = "Product"
        '
        'DataColumn22
        '
        Me.DataColumn22.AllowDBNull = False
        Me.DataColumn22.ColumnName = "product_code"
        Me.DataColumn22.DataType = GetType(Integer)
        '
        'DataColumn23
        '
        Me.DataColumn23.AllowDBNull = False
        Me.DataColumn23.ColumnName = "product_name"
        '
        'DataColumn24
        '
        Me.DataColumn24.AllowDBNull = False
        Me.DataColumn24.ColumnName = "product_type1"
        '
        'DataColumn25
        '
        Me.DataColumn25.AllowDBNull = False
        Me.DataColumn25.ColumnName = "product_type2"
        '
        'DataColumn26
        '
        Me.DataColumn26.ColumnName = "bond_type"
        '
        'DataColumn27
        '
        Me.DataColumn27.ColumnName = "currency_code"
        '
        'DataColumn28
        '
        Me.DataColumn28.ColumnName = "cpn_type"
        '
        'DataColumn29
        '
        Me.DataColumn29.ColumnName = "cpn_currency"
        '
        'DataColumn30
        '
        Me.DataColumn30.ColumnName = "cpn_rate"
        Me.DataColumn30.DataType = GetType(Decimal)
        '
        'DataColumn31
        '
        Me.DataColumn31.ColumnName = "cpn_index"
        '
        'DataColumn32
        '
        Me.DataColumn32.ColumnName = "cpn_spread"
        Me.DataColumn32.DataType = GetType(Decimal)
        '
        'DataColumn33
        '
        Me.DataColumn33.ColumnName = "issue_dt"
        Me.DataColumn33.DataType = GetType(Date)
        '
        'DataColumn34
        '
        Me.DataColumn34.ColumnName = "maturity"
        Me.DataColumn34.DataType = GetType(Date)
        '
        'DataColumn35
        '
        Me.DataColumn35.ColumnName = "cpn_num"
        Me.DataColumn35.DataType = GetType(Integer)
        '
        'DataColumn36
        '
        Me.DataColumn36.ColumnName = "cpn_mmdd01"
        '
        'DataColumn37
        '
        Me.DataColumn37.ColumnName = "cpn_mmdd02"
        '
        'DataColumn38
        '
        Me.DataColumn38.ColumnName = "cpn_mmdd03"
        '
        'DataColumn39
        '
        Me.DataColumn39.ColumnName = "cpn_mmdd04"
        '
        'DataColumn40
        '
        Me.DataColumn40.ColumnName = "cpn_mmdd05"
        '
        'DataColumn41
        '
        Me.DataColumn41.ColumnName = "cpn_mmdd06"
        '
        'DataColumn42
        '
        Me.DataColumn42.ColumnName = "cpn_mmdd07"
        '
        'DataColumn43
        '
        Me.DataColumn43.ColumnName = "cpn_mmdd08"
        '
        'DataColumn44
        '
        Me.DataColumn44.ColumnName = "cpn_mmdd09"
        '
        'DataColumn45
        '
        Me.DataColumn45.ColumnName = "cpn_mmdd10"
        '
        'DataColumn46
        '
        Me.DataColumn46.ColumnName = "cpn_mmdd11"
        '
        'DataColumn47
        '
        Me.DataColumn47.ColumnName = "cpn_mmdd12"
        '
        'DataColumn48
        '
        Me.DataColumn48.ColumnName = "first_cpn_dt"
        Me.DataColumn48.DataType = GetType(Date)
        '
        'DataColumn49
        '
        Me.DataColumn49.ColumnName = "last_cpn_dt"
        Me.DataColumn49.DataType = GetType(Date)
        '
        'DataColumn50
        '
        Me.DataColumn50.ColumnName = "redemption_currency"
        '
        'DataColumn51
        '
        Me.DataColumn51.ColumnName = "redemption_price"
        Me.DataColumn51.DataType = GetType(Decimal)
        '
        'DataColumn52
        '
        Me.DataColumn52.ColumnName = "jsda_code"
        '
        'DataColumn53
        '
        Me.DataColumn53.ColumnName = "isin_code"
        '
        'DataColumn54
        '
        Me.DataColumn54.ColumnName = "bloomberg_code"
        '
        'DataColumn55
        '
        Me.DataColumn55.ColumnName = "issuer_code"
        '
        'DataColumn56
        '
        Me.DataColumn56.ColumnName = "investment_grade"
        '
        'DataColumn57
        '
        Me.DataColumn57.ColumnName = "future_type"
        '
        'DataColumn58
        '
        Me.DataColumn58.ColumnName = "exchange"
        '
        'DataColumn59
        '
        Me.DataColumn59.ColumnName = "future_expire_dt"
        '
        'DataColumn60
        '
        Me.DataColumn60.ColumnName = "future_std_year"
        Me.DataColumn60.DataType = GetType(Integer)
        '
        'DataColumn61
        '
        Me.DataColumn61.ColumnName = "future_std_cpn"
        Me.DataColumn61.DataType = GetType(Decimal)
        '
        'DataColumn62
        '
        Me.DataColumn62.ColumnName = "last_trade_dt"
        Me.DataColumn62.DataType = GetType(Date)
        '
        'DataColumn63
        '
        Me.DataColumn63.ColumnName = "kessai_dt"
        Me.DataColumn63.DataType = GetType(Date)
        '
        'DataColumn64
        '
        Me.DataColumn64.ColumnName = "cheapest"
        Me.DataColumn64.DataType = GetType(Integer)
        '
        'DataColumn65
        '
        Me.DataColumn65.ColumnName = "futureop_std_future"
        Me.DataColumn65.DataType = GetType(Integer)
        '
        'DataColumn66
        '
        Me.DataColumn66.ColumnName = "futureop_type_code"
        '
        'DataColumn67
        '
        Me.DataColumn67.ColumnName = "futureop_strikeprice"
        Me.DataColumn67.DataType = GetType(Decimal)
        '
        'DataColumn68
        '
        Me.DataColumn68.ColumnName = "cf"
        Me.DataColumn68.DataType = GetType(Decimal)
        '
        'DataColumn69
        '
        Me.DataColumn69.AllowDBNull = False
        Me.DataColumn69.ColumnName = "sys_delete"
        '
        'DataColumn70
        '
        Me.DataColumn70.AllowDBNull = False
        Me.DataColumn70.ColumnName = "sys_insert_time"
        Me.DataColumn70.DataType = GetType(Date)
        '
        'DataColumn71
        '
        Me.DataColumn71.AllowDBNull = False
        Me.DataColumn71.ColumnName = "sys_update_time"
        Me.DataColumn71.DataType = GetType(Date)
        '
        'DataColumn72
        '
        Me.DataColumn72.ColumnName = "sys_update_counter"
        Me.DataColumn72.DataType = GetType(Integer)
        '
        'DataColumn76
        '
        Me.DataColumn76.ColumnName = "tag"
        Me.DataColumn76.DataType = GetType(Object)
        '
        'DataColumn173
        '
        Me.DataColumn173.ColumnName = "yield_type"
        '
        'DataColumn206
        '
        Me.DataColumn206.ColumnName = "bond_type_name"
        '
        'DataColumn207
        '
        Me.DataColumn207.ColumnName = "cpn_type_name"
        '
        'DataColumn208
        '
        Me.DataColumn208.ColumnName = "future_type_name"
        '
        'DataColumn209
        '
        Me.DataColumn209.ColumnName = "cheapest_name"
        '
        'DataColumn210
        '
        Me.DataColumn210.ColumnName = "futureop_std_future_name"
        '
        'DataColumn211
        '
        Me.DataColumn211.ColumnName = "futureop_type_name"
        '
        'DataColumn3
        '
        Me.DataColumn3.ColumnName = "product_type2_name"
        '
        'dsLocalDB_PriceType
        '
        Me.dsLocalDB_PriceType.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn79, Me.DataColumn80})
        Me.dsLocalDB_PriceType.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"code_item"}, True)})
        Me.dsLocalDB_PriceType.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn79}
        Me.dsLocalDB_PriceType.TableName = "PriceType"
        '
        'DataColumn79
        '
        Me.DataColumn79.AllowDBNull = False
        Me.DataColumn79.ColumnName = "code_item"
        '
        'DataColumn80
        '
        Me.DataColumn80.ColumnName = "code_item_name"
        '
        'dsLocalDB_ConversionFactor
        '
        Me.dsLocalDB_ConversionFactor.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn83, Me.DataColumn84, Me.DataColumn85, Me.DataColumn86, Me.DataColumn87, Me.DataColumn88, Me.DataColumn89, Me.DataColumn90})
        Me.dsLocalDB_ConversionFactor.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"cf_code"}, True)})
        Me.dsLocalDB_ConversionFactor.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn83}
        Me.dsLocalDB_ConversionFactor.TableName = "ConversionFactor"
        '
        'DataColumn83
        '
        Me.DataColumn83.AllowDBNull = False
        Me.DataColumn83.ColumnName = "cf_code"
        Me.DataColumn83.DataType = GetType(Integer)
        '
        'DataColumn84
        '
        Me.DataColumn84.ColumnName = "product_code"
        Me.DataColumn84.DataType = GetType(Integer)
        '
        'DataColumn85
        '
        Me.DataColumn85.ColumnName = "product_code_deliv"
        Me.DataColumn85.DataType = GetType(Integer)
        '
        'DataColumn86
        '
        Me.DataColumn86.ColumnName = "conversion_factor"
        Me.DataColumn86.DataType = GetType(Decimal)
        '
        'DataColumn87
        '
        Me.DataColumn87.ColumnName = "sys_delete"
        Me.DataColumn87.DataType = GetType(Boolean)
        '
        'DataColumn88
        '
        Me.DataColumn88.ColumnName = "tag"
        Me.DataColumn88.DataType = GetType(Object)
        '
        'DataColumn89
        '
        Me.DataColumn89.ColumnName = "product_code_name"
        '
        'DataColumn90
        '
        Me.DataColumn90.ColumnName = "product_code_deliv_name"
        '
        'dsLocalDB_CodeData
        '
        Me.dsLocalDB_CodeData.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn91, Me.DataColumn92, Me.DataColumn93, Me.DataColumn94, Me.DataColumn95})
        Me.dsLocalDB_CodeData.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"code_type", "code_item"}, True)})
        Me.dsLocalDB_CodeData.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn91, Me.DataColumn92}
        Me.dsLocalDB_CodeData.TableName = "CodeData"
        '
        'DataColumn91
        '
        Me.DataColumn91.AllowDBNull = False
        Me.DataColumn91.ColumnName = "code_type"
        '
        'DataColumn92
        '
        Me.DataColumn92.AllowDBNull = False
        Me.DataColumn92.ColumnName = "code_item"
        '
        'DataColumn93
        '
        Me.DataColumn93.ColumnName = "code_item_name"
        '
        'DataColumn94
        '
        Me.DataColumn94.ColumnName = "disp_type"
        '
        'DataColumn95
        '
        Me.DataColumn95.ColumnName = "disp_order"
        Me.DataColumn95.DataType = GetType(Integer)
        '
        'dsLocalDB_Position
        '
        Me.dsLocalDB_Position.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn96, Me.DataColumn97, Me.DataColumn98, Me.DataColumn99, Me.DataColumn100, Me.DataColumn101, Me.DataColumn102, Me.DataColumn103, Me.DataColumn104, Me.DataColumn105, Me.DataColumn106, Me.DataColumn107, Me.DataColumn108, Me.DataColumn109, Me.DataColumn110, Me.DataColumn111, Me.DataColumn112, Me.DataColumn171})
        Me.dsLocalDB_Position.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"position_no"}, True)})
        Me.dsLocalDB_Position.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn96}
        Me.dsLocalDB_Position.TableName = "Position"
        '
        'DataColumn96
        '
        Me.DataColumn96.AllowDBNull = False
        Me.DataColumn96.ColumnName = "position_no"
        Me.DataColumn96.DataType = GetType(Integer)
        '
        'DataColumn97
        '
        Me.DataColumn97.ColumnName = "sys_delete"
        Me.DataColumn97.DataType = GetType(Boolean)
        '
        'DataColumn98
        '
        Me.DataColumn98.ColumnName = "trade_no"
        Me.DataColumn98.DataType = GetType(Integer)
        '
        'DataColumn99
        '
        Me.DataColumn99.ColumnName = "trade_date"
        Me.DataColumn99.DataType = GetType(Date)
        '
        'DataColumn100
        '
        Me.DataColumn100.ColumnName = "product_type1"
        '
        'DataColumn101
        '
        Me.DataColumn101.ColumnName = "product_type2"
        '
        'DataColumn102
        '
        Me.DataColumn102.ColumnName = "book_code"
        Me.DataColumn102.DataType = GetType(Integer)
        '
        'DataColumn103
        '
        Me.DataColumn103.ColumnName = "cust_code"
        Me.DataColumn103.DataType = GetType(Integer)
        '
        'DataColumn104
        '
        Me.DataColumn104.ColumnName = "trade_type"
        '
        'DataColumn105
        '
        Me.DataColumn105.ColumnName = "product_code"
        Me.DataColumn105.DataType = GetType(Integer)
        '
        'DataColumn106
        '
        Me.DataColumn106.ColumnName = "amount"
        Me.DataColumn106.DataType = GetType(Decimal)
        '
        'DataColumn107
        '
        Me.DataColumn107.ColumnName = "price"
        Me.DataColumn107.DataType = GetType(Decimal)
        '
        'DataColumn108
        '
        Me.DataColumn108.ColumnName = "settle_dt"
        Me.DataColumn108.DataType = GetType(Date)
        '
        'DataColumn109
        '
        Me.DataColumn109.ColumnName = "settle_dt_end"
        Me.DataColumn109.DataType = GetType(Date)
        '
        'DataColumn110
        '
        Me.DataColumn110.ColumnName = "currency_code"
        '
        'DataColumn111
        '
        Me.DataColumn111.ColumnName = "price_end"
        Me.DataColumn111.DataType = GetType(Decimal)
        '
        'DataColumn112
        '
        Me.DataColumn112.ColumnName = "repo_rate"
        Me.DataColumn112.DataType = GetType(Decimal)
        '
        'DataColumn171
        '
        Me.DataColumn171.ColumnName = "tag"
        Me.DataColumn171.DataType = GetType(Object)
        '
        'dsLocalDB_Trade
        '
        Me.dsLocalDB_Trade.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn113, Me.DataColumn114, Me.DataColumn115, Me.DataColumn116, Me.DataColumn117, Me.DataColumn118, Me.DataColumn119, Me.DataColumn120, Me.DataColumn121, Me.DataColumn122, Me.DataColumn123, Me.DataColumn124, Me.DataColumn125, Me.DataColumn126, Me.DataColumn127, Me.DataColumn128, Me.DataColumn129, Me.DataColumn130, Me.DataColumn131, Me.DataColumn132, Me.DataColumn133, Me.DataColumn134, Me.DataColumn135, Me.DataColumn136, Me.DataColumn137, Me.DataColumn138, Me.DataColumn139, Me.DataColumn140, Me.DataColumn141, Me.DataColumn142, Me.DataColumn143, Me.DataColumn144, Me.DataColumn145, Me.DataColumn146, Me.DataColumn147, Me.DataColumn148, Me.DataColumn149, Me.DataColumn150, Me.DataColumn151, Me.DataColumn152, Me.DataColumn153, Me.DataColumn154, Me.DataColumn155, Me.DataColumn156, Me.DataColumn172, Me.DataColumn193, Me.DataColumn194, Me.DataColumn195, Me.DataColumn196, Me.DataColumn197, Me.DataColumn198, Me.DataColumn199, Me.DataColumn200, Me.DataColumn201, Me.DataColumn202, Me.DataColumn203, Me.DataColumn204, Me.DataColumn205})
        Me.dsLocalDB_Trade.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"trade_no"}, True)})
        Me.dsLocalDB_Trade.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn113}
        Me.dsLocalDB_Trade.TableName = "Trade"
        '
        'DataColumn113
        '
        Me.DataColumn113.AllowDBNull = False
        Me.DataColumn113.ColumnName = "trade_no"
        Me.DataColumn113.DataType = GetType(Integer)
        '
        'DataColumn114
        '
        Me.DataColumn114.ColumnName = "product_type1"
        '
        'DataColumn115
        '
        Me.DataColumn115.ColumnName = "product_type2"
        '
        'DataColumn116
        '
        Me.DataColumn116.ColumnName = "trade_type"
        '
        'DataColumn117
        '
        Me.DataColumn117.ColumnName = "r_order_date"
        Me.DataColumn117.DataType = GetType(Date)
        '
        'DataColumn118
        '
        Me.DataColumn118.ColumnName = "p_order_date"
        Me.DataColumn118.DataType = GetType(Date)
        '
        'DataColumn119
        '
        Me.DataColumn119.ColumnName = "trade_date"
        Me.DataColumn119.DataType = GetType(Date)
        '
        'DataColumn120
        '
        Me.DataColumn120.ColumnName = "book_code"
        Me.DataColumn120.DataType = GetType(Integer)
        '
        'DataColumn121
        '
        Me.DataColumn121.ColumnName = "cust_code"
        Me.DataColumn121.DataType = GetType(Integer)
        '
        'DataColumn122
        '
        Me.DataColumn122.ColumnName = "product_code"
        Me.DataColumn122.DataType = GetType(Integer)
        '
        'DataColumn123
        '
        Me.DataColumn123.ColumnName = "amount"
        Me.DataColumn123.DataType = GetType(Decimal)
        '
        'DataColumn124
        '
        Me.DataColumn124.ColumnName = "price_type"
        '
        'DataColumn125
        '
        Me.DataColumn125.ColumnName = "price_input"
        Me.DataColumn125.DataType = GetType(Decimal)
        '
        'DataColumn126
        '
        Me.DataColumn126.ColumnName = "price"
        Me.DataColumn126.DataType = GetType(Decimal)
        '
        'DataColumn127
        '
        Me.DataColumn127.ColumnName = "contract_amount"
        Me.DataColumn127.DataType = GetType(Decimal)
        '
        'DataColumn128
        '
        Me.DataColumn128.ColumnName = "accrued_interest"
        Me.DataColumn128.DataType = GetType(Decimal)
        '
        'DataColumn129
        '
        Me.DataColumn129.ColumnName = "cash_delivered"
        Me.DataColumn129.DataType = GetType(Decimal)
        '
        'DataColumn130
        '
        Me.DataColumn130.ColumnName = "price_type_end"
        '
        'DataColumn131
        '
        Me.DataColumn131.ColumnName = "price_input_end"
        Me.DataColumn131.DataType = GetType(Decimal)
        '
        'DataColumn132
        '
        Me.DataColumn132.ColumnName = "price_end"
        Me.DataColumn132.DataType = GetType(Decimal)
        '
        'DataColumn133
        '
        Me.DataColumn133.ColumnName = "contract_amount_end"
        Me.DataColumn133.DataType = GetType(Decimal)
        '
        'DataColumn134
        '
        Me.DataColumn134.ColumnName = "accrued_interest_end"
        Me.DataColumn134.DataType = GetType(Decimal)
        '
        'DataColumn135
        '
        Me.DataColumn135.ColumnName = "cash_delivered_end"
        Me.DataColumn135.DataType = GetType(Decimal)
        '
        'DataColumn136
        '
        Me.DataColumn136.ColumnName = "settle_dt"
        Me.DataColumn136.DataType = GetType(Date)
        '
        'DataColumn137
        '
        Me.DataColumn137.ColumnName = "settle_dt_end"
        Me.DataColumn137.DataType = GetType(Date)
        '
        'DataColumn138
        '
        Me.DataColumn138.ColumnName = "option_type"
        '
        'DataColumn139
        '
        Me.DataColumn139.ColumnName = "exercise_type"
        '
        'DataColumn140
        '
        Me.DataColumn140.ColumnName = "strike_price"
        Me.DataColumn140.DataType = GetType(Decimal)
        '
        'DataColumn141
        '
        Me.DataColumn141.ColumnName = "expire_dt"
        Me.DataColumn141.DataType = GetType(Date)
        '
        'DataColumn142
        '
        Me.DataColumn142.ColumnName = "expire_settle_dt"
        Me.DataColumn142.DataType = GetType(Date)
        '
        'DataColumn143
        '
        Me.DataColumn143.ColumnName = "option_volatility"
        Me.DataColumn143.DataType = GetType(Decimal)
        '
        'DataColumn144
        '
        Me.DataColumn144.ColumnName = "exchange_trade_dt"
        Me.DataColumn144.DataType = GetType(Date)
        '
        'DataColumn145
        '
        Me.DataColumn145.ColumnName = "trade_no_pre"
        Me.DataColumn145.DataType = GetType(Integer)
        '
        'DataColumn146
        '
        Me.DataColumn146.ColumnName = "memo"
        '
        'DataColumn147
        '
        Me.DataColumn147.ColumnName = "sys_delete"
        Me.DataColumn147.DataType = GetType(Boolean)
        '
        'DataColumn148
        '
        Me.DataColumn148.ColumnName = "currency_code"
        '
        'DataColumn149
        '
        Me.DataColumn149.ColumnName = "repo_rate"
        Me.DataColumn149.DataType = GetType(Decimal)
        '
        'DataColumn150
        '
        Me.DataColumn150.ColumnName = "haircut"
        Me.DataColumn150.DataType = GetType(Decimal)
        '
        'DataColumn151
        '
        Me.DataColumn151.ColumnName = "end_open_close"
        '
        'DataColumn152
        '
        Me.DataColumn152.ColumnName = "cash_collateral_rate"
        Me.DataColumn152.DataType = GetType(Decimal)
        '
        'DataColumn153
        '
        Me.DataColumn153.ColumnName = "loan_rate"
        Me.DataColumn153.DataType = GetType(Decimal)
        '
        'DataColumn154
        '
        Me.DataColumn154.ColumnName = "repo_sc_gc"
        '
        'DataColumn155
        '
        Me.DataColumn155.ColumnName = "gensaki_ribukumi"
        '
        'DataColumn156
        '
        Me.DataColumn156.ColumnName = "pre_price"
        Me.DataColumn156.DataType = GetType(Decimal)
        '
        'DataColumn172
        '
        Me.DataColumn172.ColumnName = "tag"
        Me.DataColumn172.DataType = GetType(Object)
        '
        'DataColumn193
        '
        Me.DataColumn193.Caption = "trade_type_name"
        Me.DataColumn193.ColumnName = "trade_type_name"
        '
        'DataColumn194
        '
        Me.DataColumn194.ColumnName = "book_name"
        '
        'DataColumn195
        '
        Me.DataColumn195.ColumnName = "cust_name"
        '
        'DataColumn196
        '
        Me.DataColumn196.ColumnName = "product_name"
        '
        'DataColumn197
        '
        Me.DataColumn197.ColumnName = "price_type_name"
        '
        'DataColumn198
        '
        Me.DataColumn198.ColumnName = "end_open_close_name"
        '
        'DataColumn199
        '
        Me.DataColumn199.ColumnName = "exercise_type_name"
        '
        'DataColumn200
        '
        Me.DataColumn200.ColumnName = "futureop_expire_dt"
        '
        'DataColumn201
        '
        Me.DataColumn201.ColumnName = "futureop_option_type_name"
        '
        'DataColumn202
        '
        Me.DataColumn202.ColumnName = "futureop_strikeprice"
        '
        'DataColumn203
        '
        Me.DataColumn203.ColumnName = "gensaki_ribukumi_name"
        '
        'DataColumn204
        '
        Me.DataColumn204.ColumnName = "option_type_name"
        '
        'DataColumn205
        '
        Me.DataColumn205.ColumnName = "repo_sc_gc_name"
        '
        'dsLocalDB_MarketPriceProduct
        '
        Me.dsLocalDB_MarketPriceProduct.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn178, Me.DataColumn157, Me.DataColumn158, Me.DataColumn159, Me.DataColumn160, Me.DataColumn161, Me.DataColumn169, Me.DataColumn174, Me.DataColumn175, Me.DataColumn230})
        Me.dsLocalDB_MarketPriceProduct.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"data_date", "market_price_type", "product_code"}, True)})
        Me.dsLocalDB_MarketPriceProduct.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn157, Me.DataColumn158, Me.DataColumn159}
        Me.dsLocalDB_MarketPriceProduct.TableName = "MarketPriceProduct"
        '
        'DataColumn178
        '
        Me.DataColumn178.ColumnName = "market_price_code"
        Me.DataColumn178.DataType = GetType(Integer)
        '
        'DataColumn157
        '
        Me.DataColumn157.AllowDBNull = False
        Me.DataColumn157.ColumnName = "data_date"
        Me.DataColumn157.DataType = GetType(Date)
        '
        'DataColumn158
        '
        Me.DataColumn158.AllowDBNull = False
        Me.DataColumn158.ColumnName = "market_price_type"
        '
        'DataColumn159
        '
        Me.DataColumn159.AllowDBNull = False
        Me.DataColumn159.ColumnName = "product_code"
        Me.DataColumn159.DataType = GetType(Integer)
        '
        'DataColumn160
        '
        Me.DataColumn160.ColumnName = "price_type"
        '
        'DataColumn161
        '
        Me.DataColumn161.ColumnName = "price"
        Me.DataColumn161.DataType = GetType(Decimal)
        '
        'DataColumn169
        '
        Me.DataColumn169.ColumnName = "tag"
        Me.DataColumn169.DataType = GetType(Object)
        '
        'DataColumn174
        '
        Me.DataColumn174.ColumnName = "product_name"
        '
        'DataColumn175
        '
        Me.DataColumn175.ColumnName = "price_type_name"
        '
        'DataColumn230
        '
        Me.DataColumn230.ColumnName = "sys_delete"
        Me.DataColumn230.DataType = GetType(Boolean)
        '
        'dsLocalDB_MarketPriceTrade
        '
        Me.dsLocalDB_MarketPriceTrade.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn179, Me.DataColumn162, Me.DataColumn163, Me.DataColumn164, Me.DataColumn165, Me.DataColumn166, Me.DataColumn170, Me.DataColumn176, Me.DataColumn177, Me.DataColumn6, Me.DataColumn231})
        Me.dsLocalDB_MarketPriceTrade.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"data_date", "market_price_type", "trade_no"}, True)})
        Me.dsLocalDB_MarketPriceTrade.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn162, Me.DataColumn163, Me.DataColumn164}
        Me.dsLocalDB_MarketPriceTrade.TableName = "MarketPriceTrade"
        '
        'DataColumn179
        '
        Me.DataColumn179.ColumnName = "market_price_code"
        Me.DataColumn179.DataType = GetType(Integer)
        '
        'DataColumn162
        '
        Me.DataColumn162.AllowDBNull = False
        Me.DataColumn162.ColumnName = "data_date"
        Me.DataColumn162.DataType = GetType(Date)
        '
        'DataColumn163
        '
        Me.DataColumn163.AllowDBNull = False
        Me.DataColumn163.ColumnName = "market_price_type"
        '
        'DataColumn164
        '
        Me.DataColumn164.AllowDBNull = False
        Me.DataColumn164.ColumnName = "trade_no"
        Me.DataColumn164.DataType = GetType(Integer)
        '
        'DataColumn165
        '
        Me.DataColumn165.ColumnName = "price_type"
        '
        'DataColumn166
        '
        Me.DataColumn166.ColumnName = "price"
        Me.DataColumn166.DataType = GetType(Decimal)
        '
        'DataColumn170
        '
        Me.DataColumn170.ColumnName = "tag"
        Me.DataColumn170.DataType = GetType(Object)
        '
        'DataColumn176
        '
        Me.DataColumn176.ColumnName = "product_name"
        '
        'DataColumn177
        '
        Me.DataColumn177.ColumnName = "price_type_name"
        '
        'DataColumn6
        '
        Me.DataColumn6.ColumnName = "product_code"
        '
        'DataColumn231
        '
        Me.DataColumn231.ColumnName = "sys_delete"
        Me.DataColumn231.DataType = GetType(Boolean)
        '
        'dsLocalDB_MarketPriceManagement
        '
        Me.dsLocalDB_MarketPriceManagement.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn167, Me.DataColumn168})
        Me.dsLocalDB_MarketPriceManagement.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"data_date", "market_price_type"}, True)})
        Me.dsLocalDB_MarketPriceManagement.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn167, Me.DataColumn168}
        Me.dsLocalDB_MarketPriceManagement.TableName = "MarketPriceManagement"
        '
        'DataColumn167
        '
        Me.DataColumn167.AllowDBNull = False
        Me.DataColumn167.ColumnName = "data_date"
        Me.DataColumn167.DataType = GetType(Date)
        '
        'DataColumn168
        '
        Me.DataColumn168.AllowDBNull = False
        Me.DataColumn168.ColumnName = "market_price_type"
        '
        'dsLocalDB_Grade
        '
        Me.dsLocalDB_Grade.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn180, Me.DataColumn181, Me.DataColumn182, Me.DataColumn183, Me.DataColumn184, Me.DataColumn185, Me.DataColumn186, Me.DataColumn187, Me.DataColumn188, Me.DataColumn189, Me.DataColumn190, Me.DataColumn191, Me.DataColumn192})
        Me.dsLocalDB_Grade.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"Grade"}, True)})
        Me.dsLocalDB_Grade.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn180}
        Me.dsLocalDB_Grade.TableName = "Grade"
        '
        'DataColumn180
        '
        Me.DataColumn180.AllowDBNull = False
        Me.DataColumn180.ColumnName = "Grade"
        '
        'DataColumn181
        '
        Me.DataColumn181.AllowDBNull = False
        Me.DataColumn181.ColumnName = "disp_type"
        '
        'DataColumn182
        '
        Me.DataColumn182.AllowDBNull = False
        Me.DataColumn182.ColumnName = "disp_order"
        Me.DataColumn182.DataType = GetType(Integer)
        '
        'DataColumn183
        '
        Me.DataColumn183.ColumnName = "rating_agency_01"
        '
        'DataColumn184
        '
        Me.DataColumn184.ColumnName = "rating_agency_02"
        '
        'DataColumn185
        '
        Me.DataColumn185.ColumnName = "rating_agency_03"
        '
        'DataColumn186
        '
        Me.DataColumn186.ColumnName = "rating_agency_04"
        '
        'DataColumn187
        '
        Me.DataColumn187.ColumnName = "rating_agency_05"
        '
        'DataColumn188
        '
        Me.DataColumn188.ColumnName = "rating_agency_06"
        '
        'DataColumn189
        '
        Me.DataColumn189.ColumnName = "rating_agency_07"
        '
        'DataColumn190
        '
        Me.DataColumn190.ColumnName = "rating_agency_08"
        '
        'DataColumn191
        '
        Me.DataColumn191.ColumnName = "rating_agency_09"
        '
        'DataColumn192
        '
        Me.DataColumn192.ColumnName = "rating_agency_10"
        '
        'dsLocalDB_MarketPriceRepoRate
        '
        Me.dsLocalDB_MarketPriceRepoRate.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn212, Me.DataColumn213, Me.DataColumn214, Me.DataColumn215, Me.DataColumn216, Me.DataColumn4, Me.DataColumn5, Me.DataColumn232})
        Me.dsLocalDB_MarketPriceRepoRate.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"data_date", "market_price_type", "product_code"}, True)})
        Me.dsLocalDB_MarketPriceRepoRate.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn213, Me.DataColumn214, Me.DataColumn5}
        Me.dsLocalDB_MarketPriceRepoRate.TableName = "MarketPriceRepoRate"
        '
        'DataColumn212
        '
        Me.DataColumn212.AllowDBNull = False
        Me.DataColumn212.ColumnName = "market_price_code"
        Me.DataColumn212.DataType = GetType(Integer)
        '
        'DataColumn213
        '
        Me.DataColumn213.AllowDBNull = False
        Me.DataColumn213.ColumnName = "data_date"
        Me.DataColumn213.DataType = GetType(Date)
        '
        'DataColumn214
        '
        Me.DataColumn214.AllowDBNull = False
        Me.DataColumn214.ColumnName = "market_price_type"
        '
        'DataColumn215
        '
        Me.DataColumn215.AllowDBNull = False
        Me.DataColumn215.ColumnName = "price"
        Me.DataColumn215.DataType = GetType(Decimal)
        '
        'DataColumn216
        '
        Me.DataColumn216.ColumnName = "tag"
        Me.DataColumn216.DataType = GetType(Object)
        '
        'DataColumn4
        '
        Me.DataColumn4.ColumnName = "product_name"
        '
        'DataColumn5
        '
        Me.DataColumn5.AllowDBNull = False
        Me.DataColumn5.ColumnName = "product_code"
        '
        'DataColumn232
        '
        Me.DataColumn232.ColumnName = "sys_delete"
        Me.DataColumn232.DataType = GetType(Boolean)
        '
        'dsLocalDB_MarketPriceShortRate
        '
        Me.dsLocalDB_MarketPriceShortRate.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn217, Me.DataColumn218, Me.DataColumn219, Me.DataColumn220, Me.DataColumn221, Me.DataColumn222, Me.DataColumn223, Me.DataColumn233})
        Me.dsLocalDB_MarketPriceShortRate.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"data_date", "market_price_type", "product_code"}, True)})
        Me.dsLocalDB_MarketPriceShortRate.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn218, Me.DataColumn219, Me.DataColumn223}
        Me.dsLocalDB_MarketPriceShortRate.TableName = "MarketPriceShortRate"
        '
        'DataColumn217
        '
        Me.DataColumn217.AllowDBNull = False
        Me.DataColumn217.ColumnName = "market_price_code"
        Me.DataColumn217.DataType = GetType(Integer)
        '
        'DataColumn218
        '
        Me.DataColumn218.AllowDBNull = False
        Me.DataColumn218.ColumnName = "data_date"
        Me.DataColumn218.DataType = GetType(Date)
        '
        'DataColumn219
        '
        Me.DataColumn219.AllowDBNull = False
        Me.DataColumn219.ColumnName = "market_price_type"
        '
        'DataColumn220
        '
        Me.DataColumn220.AllowDBNull = False
        Me.DataColumn220.ColumnName = "price"
        Me.DataColumn220.DataType = GetType(Decimal)
        '
        'DataColumn221
        '
        Me.DataColumn221.ColumnName = "tag"
        Me.DataColumn221.DataType = GetType(Object)
        '
        'DataColumn222
        '
        Me.DataColumn222.ColumnName = "product_name"
        '
        'DataColumn223
        '
        Me.DataColumn223.AllowDBNull = False
        Me.DataColumn223.ColumnName = "product_code"
        Me.DataColumn223.DataType = GetType(Integer)
        '
        'DataColumn233
        '
        Me.DataColumn233.ColumnName = "sys_delete"
        Me.DataColumn233.DataType = GetType(Boolean)
        '
        'dsLocalDB_MarketPriceOnmemoryRepoRate
        '
        Me.dsLocalDB_MarketPriceOnmemoryRepoRate.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn224, Me.DataColumn225, Me.DataColumn226, Me.DataColumn227, Me.DataColumn228, Me.DataColumn229, Me.DataColumn234})
        Me.dsLocalDB_MarketPriceOnmemoryRepoRate.Constraints.AddRange(New System.Data.Constraint() {New System.Data.UniqueConstraint("Constraint1", New String() {"product_code"}, True)})
        Me.dsLocalDB_MarketPriceOnmemoryRepoRate.PrimaryKey = New System.Data.DataColumn() {Me.DataColumn224}
        Me.dsLocalDB_MarketPriceOnmemoryRepoRate.TableName = "MarketPriceOnmemoryRepoRate"
        '
        'DataColumn224
        '
        Me.DataColumn224.AllowDBNull = False
        Me.DataColumn224.Caption = "銘柄コード"
        Me.DataColumn224.ColumnName = "product_code"
        Me.DataColumn224.DataType = GetType(Integer)
        '
        'DataColumn225
        '
        Me.DataColumn225.Caption = "銘柄名称"
        Me.DataColumn225.ColumnName = "product_name"
        '
        'DataColumn226
        '
        Me.DataColumn226.Caption = "価格種別"
        Me.DataColumn226.ColumnName = "price_type"
        '
        'DataColumn227
        '
        Me.DataColumn227.Caption = "時価"
        Me.DataColumn227.ColumnName = "price"
        Me.DataColumn227.DataType = GetType(Decimal)
        '
        'DataColumn228
        '
        Me.DataColumn228.ColumnName = "tag"
        Me.DataColumn228.DataType = GetType(Object)
        '
        'DataColumn229
        '
        Me.DataColumn229.ColumnName = "use"
        Me.DataColumn229.DataType = GetType(Boolean)
        '
        'DataColumn234
        '
        Me.DataColumn234.ColumnName = "sys_delete"
        Me.DataColumn234.DataType = GetType(Boolean)
        '
        'DataColumn74
        '
        Me.DataColumn74.ColumnName = "tag"
        Me.DataColumn74.DataType = GetType(Object)
        '
        'DataColumn75
        '
        Me.DataColumn75.ColumnName = "tag"
        Me.DataColumn75.DataType = GetType(Object)
        '
        'DataColumn73
        '
        Me.DataColumn73.ColumnName = "tag"
        Me.DataColumn73.DataType = GetType(Object)
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.slServerTime, Me.slUser, Me.slServerStatus, Me.slServerNextTime, Me.slServer})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 639)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1008, 23)
        Me.StatusStrip1.TabIndex = 7
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'slServerTime
        '
        Me.slServerTime.Name = "slServerTime"
        Me.slServerTime.Size = New System.Drawing.Size(136, 18)
        Me.slServerTime.Text = "サーバー時刻 99:99:99"
        '
        'slUser
        '
        Me.slUser.Name = "slUser"
        Me.slUser.Size = New System.Drawing.Size(172, 18)
        Me.slUser.Text = "UserID:xxxxx  Name:xxxxx"
        '
        'slServerStatus
        '
        Me.slServerStatus.Name = "slServerStatus"
        Me.slServerStatus.Size = New System.Drawing.Size(133, 18)
        Me.slServerStatus.Text = "ステータス:○○○○○"
        '
        'slServerNextTime
        '
        Me.slServerNextTime.Name = "slServerNextTime"
        Me.slServerNextTime.Size = New System.Drawing.Size(182, 18)
        Me.slServerNextTime.Text = "次の日時 9999/99/99 99:99:99"
        '
        'slServer
        '
        Me.slServer.Name = "slServer"
        Me.slServer.Size = New System.Drawing.Size(236, 18)
        Me.slServer.Text = "接続先:https://lionboadmin1.hirosefx.jp"
        '
        'PanelAlert
        '
        Me.PanelAlert.Controls.Add(Me.lblAlertMessage)
        Me.PanelAlert.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelAlert.Location = New System.Drawing.Point(0, 622)
        Me.PanelAlert.Name = "PanelAlert"
        Me.PanelAlert.Size = New System.Drawing.Size(1008, 17)
        Me.PanelAlert.TabIndex = 9
        '
        'lblAlertMessage
        '
        Me.lblAlertMessage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblAlertMessage.ForeColor = System.Drawing.Color.Red
        Me.lblAlertMessage.Location = New System.Drawing.Point(0, 0)
        Me.lblAlertMessage.Name = "lblAlertMessage"
        Me.lblAlertMessage.Size = New System.Drawing.Size(1008, 17)
        Me.lblAlertMessage.TabIndex = 4
        Me.lblAlertMessage.Text = "2012/06/01 16:31:05　レート時間乖離"
        Me.lblAlertMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PanelWatcherAlert
        '
        Me.PanelWatcherAlert.Controls.Add(Me.lblWatcherAlertMessage)
        Me.PanelWatcherAlert.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelWatcherAlert.Location = New System.Drawing.Point(0, 604)
        Me.PanelWatcherAlert.Name = "PanelWatcherAlert"
        Me.PanelWatcherAlert.Size = New System.Drawing.Size(1008, 18)
        Me.PanelWatcherAlert.TabIndex = 13
        '
        'lblWatcherAlertMessage
        '
        Me.lblWatcherAlertMessage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblWatcherAlertMessage.ForeColor = System.Drawing.Color.Red
        Me.lblWatcherAlertMessage.Location = New System.Drawing.Point(0, 0)
        Me.lblWatcherAlertMessage.Name = "lblWatcherAlertMessage"
        Me.lblWatcherAlertMessage.Size = New System.Drawing.Size(1008, 18)
        Me.lblWatcherAlertMessage.TabIndex = 5
        Me.lblWatcherAlertMessage.Text = "2017/01/18 17:41:05　【アラート損益】"
        Me.lblWatcherAlertMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'miTradeAccountSummaryDownload
        '
        Me.miTradeAccountSummaryDownload.Name = "miTradeAccountSummaryDownload"
        Me.miTradeAccountSummaryDownload.Size = New System.Drawing.Size(196, 22)
        Me.miTradeAccountSummaryDownload.Text = "取引口座集計"
        '
        'MainWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 662)
        Me.Controls.Add(Me.PanelWatcherAlert)
        Me.Controls.Add(Me.PanelAlert)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MainWindow"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "LionBO 管理者用クライアント"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.dsLocalDB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceDataType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_Currency, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_Portfolio, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceOnmemoryProduct, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceOnmemoryTrade, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_Product, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_PriceType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_ConversionFactor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_CodeData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_Position, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_Trade, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceProduct, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceTrade, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceManagement, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_Grade, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceRepoRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceShortRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dsLocalDB_MarketPriceOnmemoryRepoRate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.PanelAlert.ResumeLayout(False)
        Me.PanelWatcherAlert.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Public WithEvents dsLocalDB As System.Data.DataSet
    Friend WithEvents DataColumn1 As System.Data.DataColumn
    Friend WithEvents DataColumn2 As System.Data.DataColumn
    Public WithEvents dsLocalDB_MarketPriceDataType As System.Data.DataTable
    Friend WithEvents DataColumn7 As System.Data.DataColumn
    Friend WithEvents DataColumn8 As System.Data.DataColumn
    Friend WithEvents DataColumn9 As System.Data.DataColumn
    Friend WithEvents DataColumn10 As System.Data.DataColumn
    Friend WithEvents DataColumn11 As System.Data.DataColumn
    Friend WithEvents DataColumn12 As System.Data.DataColumn
    Friend WithEvents DataColumn13 As System.Data.DataColumn
    Friend WithEvents DataColumn14 As System.Data.DataColumn
    Friend WithEvents DataColumn15 As System.Data.DataColumn
    Friend WithEvents DataColumn16 As System.Data.DataColumn
    Friend WithEvents DataColumn17 As System.Data.DataColumn
    Friend WithEvents DataColumn18 As System.Data.DataColumn
    Friend WithEvents DataColumn19 As System.Data.DataColumn
    Friend WithEvents DataColumn20 As System.Data.DataColumn
    Friend WithEvents DataColumn21 As System.Data.DataColumn
    Friend WithEvents DataColumn22 As System.Data.DataColumn
    Friend WithEvents DataColumn23 As System.Data.DataColumn
    Friend WithEvents DataColumn24 As System.Data.DataColumn
    Friend WithEvents DataColumn25 As System.Data.DataColumn
    Friend WithEvents DataColumn26 As System.Data.DataColumn
    Friend WithEvents DataColumn27 As System.Data.DataColumn
    Friend WithEvents DataColumn28 As System.Data.DataColumn
    Friend WithEvents DataColumn29 As System.Data.DataColumn
    Friend WithEvents DataColumn30 As System.Data.DataColumn
    Friend WithEvents DataColumn31 As System.Data.DataColumn
    Friend WithEvents DataColumn32 As System.Data.DataColumn
    Friend WithEvents DataColumn33 As System.Data.DataColumn
    Friend WithEvents DataColumn34 As System.Data.DataColumn
    Friend WithEvents DataColumn35 As System.Data.DataColumn
    Friend WithEvents DataColumn36 As System.Data.DataColumn
    Friend WithEvents DataColumn37 As System.Data.DataColumn
    Friend WithEvents DataColumn38 As System.Data.DataColumn
    Friend WithEvents DataColumn39 As System.Data.DataColumn
    Friend WithEvents DataColumn40 As System.Data.DataColumn
    Friend WithEvents DataColumn41 As System.Data.DataColumn
    Friend WithEvents DataColumn42 As System.Data.DataColumn
    Friend WithEvents DataColumn43 As System.Data.DataColumn
    Friend WithEvents DataColumn44 As System.Data.DataColumn
    Friend WithEvents DataColumn45 As System.Data.DataColumn
    Friend WithEvents DataColumn46 As System.Data.DataColumn
    Friend WithEvents DataColumn47 As System.Data.DataColumn
    Friend WithEvents DataColumn48 As System.Data.DataColumn
    Friend WithEvents DataColumn49 As System.Data.DataColumn
    Friend WithEvents DataColumn50 As System.Data.DataColumn
    Friend WithEvents DataColumn51 As System.Data.DataColumn
    Friend WithEvents DataColumn52 As System.Data.DataColumn
    Friend WithEvents DataColumn53 As System.Data.DataColumn
    Friend WithEvents DataColumn54 As System.Data.DataColumn
    Friend WithEvents DataColumn55 As System.Data.DataColumn
    Friend WithEvents DataColumn56 As System.Data.DataColumn
    Friend WithEvents DataColumn57 As System.Data.DataColumn
    Friend WithEvents DataColumn58 As System.Data.DataColumn
    Friend WithEvents DataColumn59 As System.Data.DataColumn
    Friend WithEvents DataColumn60 As System.Data.DataColumn
    Friend WithEvents DataColumn61 As System.Data.DataColumn
    Friend WithEvents DataColumn62 As System.Data.DataColumn
    Friend WithEvents DataColumn63 As System.Data.DataColumn
    Friend WithEvents DataColumn64 As System.Data.DataColumn
    Friend WithEvents DataColumn65 As System.Data.DataColumn
    Friend WithEvents DataColumn66 As System.Data.DataColumn
    Friend WithEvents DataColumn67 As System.Data.DataColumn
    Friend WithEvents DataColumn68 As System.Data.DataColumn
    Friend WithEvents DataColumn69 As System.Data.DataColumn
    Friend WithEvents DataColumn70 As System.Data.DataColumn
    Friend WithEvents DataColumn71 As System.Data.DataColumn
    Friend WithEvents DataColumn72 As System.Data.DataColumn
    Friend WithEvents DataColumn73 As System.Data.DataColumn
    Friend WithEvents DataColumn74 As System.Data.DataColumn
    Friend WithEvents DataColumn75 As System.Data.DataColumn
    Friend WithEvents DataColumn76 As System.Data.DataColumn
    Friend WithEvents DataColumn77 As System.Data.DataColumn
    Friend WithEvents DataColumn78 As System.Data.DataColumn
    Friend WithEvents DataColumn79 As System.Data.DataColumn
    Friend WithEvents DataColumn80 As System.Data.DataColumn
    Friend WithEvents DataColumn81 As System.Data.DataColumn
    Public WithEvents dsLocalDB_Currency As System.Data.DataTable
    Public WithEvents dsLocalDB_Portfolio As System.Data.DataTable
    Public WithEvents dsLocalDB_MarketPriceOnmemoryProduct As System.Data.DataTable
    Public WithEvents dsLocalDB_MarketPriceOnmemoryTrade As System.Data.DataTable
    Public WithEvents dsLocalDB_Product As System.Data.DataTable
    Public WithEvents dsLocalDB_PriceType As System.Data.DataTable
    Friend WithEvents DataColumn82 As System.Data.DataColumn
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents miFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miFileLogout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miProduct As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miProductBaseList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents miProductBaseReg As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miProductList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miProductReg As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRateList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRateReg As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTrade As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTradeList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTradeReg As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miCashList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miCashReg As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRisk As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRiskMonitor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRiskSimulate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miEarnings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miSalesPerformance As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataColumn83 As System.Data.DataColumn
    Friend WithEvents DataColumn84 As System.Data.DataColumn
    Friend WithEvents DataColumn85 As System.Data.DataColumn
    Friend WithEvents DataColumn86 As System.Data.DataColumn
    Friend WithEvents DataColumn87 As System.Data.DataColumn
    Friend WithEvents DataColumn88 As System.Data.DataColumn
    Friend WithEvents DataColumn89 As System.Data.DataColumn
    Friend WithEvents DataColumn90 As System.Data.DataColumn
    Friend WithEvents DataColumn91 As System.Data.DataColumn
    Friend WithEvents DataColumn92 As System.Data.DataColumn
    Friend WithEvents DataColumn93 As System.Data.DataColumn
    Friend WithEvents DataColumn94 As System.Data.DataColumn
    Friend WithEvents DataColumn95 As System.Data.DataColumn
    Friend WithEvents DataColumn96 As System.Data.DataColumn
    Friend WithEvents DataColumn97 As System.Data.DataColumn
    Friend WithEvents DataColumn98 As System.Data.DataColumn
    Friend WithEvents DataColumn99 As System.Data.DataColumn
    Friend WithEvents DataColumn100 As System.Data.DataColumn
    Friend WithEvents DataColumn101 As System.Data.DataColumn
    Friend WithEvents DataColumn102 As System.Data.DataColumn
    Friend WithEvents DataColumn103 As System.Data.DataColumn
    Friend WithEvents DataColumn104 As System.Data.DataColumn
    Friend WithEvents DataColumn105 As System.Data.DataColumn
    Friend WithEvents DataColumn106 As System.Data.DataColumn
    Friend WithEvents DataColumn107 As System.Data.DataColumn
    Friend WithEvents DataColumn108 As System.Data.DataColumn
    Friend WithEvents DataColumn109 As System.Data.DataColumn
    Friend WithEvents DataColumn110 As System.Data.DataColumn
    Friend WithEvents DataColumn111 As System.Data.DataColumn
    Friend WithEvents DataColumn112 As System.Data.DataColumn
    Friend WithEvents DataColumn113 As System.Data.DataColumn
    Friend WithEvents DataColumn114 As System.Data.DataColumn
    Friend WithEvents DataColumn115 As System.Data.DataColumn
    Friend WithEvents DataColumn116 As System.Data.DataColumn
    Friend WithEvents DataColumn117 As System.Data.DataColumn
    Friend WithEvents DataColumn118 As System.Data.DataColumn
    Friend WithEvents DataColumn119 As System.Data.DataColumn
    Friend WithEvents DataColumn120 As System.Data.DataColumn
    Friend WithEvents DataColumn121 As System.Data.DataColumn
    Friend WithEvents DataColumn122 As System.Data.DataColumn
    Friend WithEvents DataColumn123 As System.Data.DataColumn
    Friend WithEvents DataColumn124 As System.Data.DataColumn
    Friend WithEvents DataColumn125 As System.Data.DataColumn
    Friend WithEvents DataColumn126 As System.Data.DataColumn
    Friend WithEvents DataColumn127 As System.Data.DataColumn
    Friend WithEvents DataColumn128 As System.Data.DataColumn
    Friend WithEvents DataColumn129 As System.Data.DataColumn
    Friend WithEvents DataColumn130 As System.Data.DataColumn
    Friend WithEvents DataColumn131 As System.Data.DataColumn
    Friend WithEvents DataColumn132 As System.Data.DataColumn
    Friend WithEvents DataColumn133 As System.Data.DataColumn
    Friend WithEvents DataColumn134 As System.Data.DataColumn
    Friend WithEvents DataColumn135 As System.Data.DataColumn
    Friend WithEvents DataColumn136 As System.Data.DataColumn
    Friend WithEvents DataColumn137 As System.Data.DataColumn
    Friend WithEvents DataColumn138 As System.Data.DataColumn
    Friend WithEvents DataColumn139 As System.Data.DataColumn
    Friend WithEvents DataColumn140 As System.Data.DataColumn
    Friend WithEvents DataColumn141 As System.Data.DataColumn
    Friend WithEvents DataColumn142 As System.Data.DataColumn
    Friend WithEvents DataColumn143 As System.Data.DataColumn
    Friend WithEvents DataColumn144 As System.Data.DataColumn
    Friend WithEvents DataColumn145 As System.Data.DataColumn
    Friend WithEvents DataColumn146 As System.Data.DataColumn
    Friend WithEvents DataColumn147 As System.Data.DataColumn
    Friend WithEvents DataColumn148 As System.Data.DataColumn
    Friend WithEvents DataColumn149 As System.Data.DataColumn
    Friend WithEvents DataColumn150 As System.Data.DataColumn
    Friend WithEvents DataColumn151 As System.Data.DataColumn
    Friend WithEvents DataColumn152 As System.Data.DataColumn
    Friend WithEvents DataColumn153 As System.Data.DataColumn
    Friend WithEvents DataColumn154 As System.Data.DataColumn
    Friend WithEvents DataColumn155 As System.Data.DataColumn
    Friend WithEvents DataColumn156 As System.Data.DataColumn
    Friend WithEvents DataColumn157 As System.Data.DataColumn
    Friend WithEvents DataColumn158 As System.Data.DataColumn
    Friend WithEvents DataColumn159 As System.Data.DataColumn
    Friend WithEvents DataColumn160 As System.Data.DataColumn
    Friend WithEvents DataColumn161 As System.Data.DataColumn
    Friend WithEvents DataColumn162 As System.Data.DataColumn
    Friend WithEvents DataColumn163 As System.Data.DataColumn
    Friend WithEvents DataColumn164 As System.Data.DataColumn
    Friend WithEvents DataColumn165 As System.Data.DataColumn
    Friend WithEvents DataColumn166 As System.Data.DataColumn
    Friend WithEvents DataColumn167 As System.Data.DataColumn
    Friend WithEvents DataColumn168 As System.Data.DataColumn
    Friend WithEvents DataColumn171 As System.Data.DataColumn
    Friend WithEvents DataColumn172 As System.Data.DataColumn
    Friend WithEvents DataColumn169 As System.Data.DataColumn
    Friend WithEvents DataColumn170 As System.Data.DataColumn
    Friend WithEvents DataColumn173 As System.Data.DataColumn
    Friend WithEvents DataColumn174 As System.Data.DataColumn
    Friend WithEvents DataColumn175 As System.Data.DataColumn
    Friend WithEvents DataColumn176 As System.Data.DataColumn
    Friend WithEvents DataColumn177 As System.Data.DataColumn
    Friend WithEvents DataColumn178 As System.Data.DataColumn
    Friend WithEvents DataColumn179 As System.Data.DataColumn
    Friend WithEvents DataColumn180 As System.Data.DataColumn
    Friend WithEvents DataColumn181 As System.Data.DataColumn
    Friend WithEvents DataColumn182 As System.Data.DataColumn
    Friend WithEvents DataColumn183 As System.Data.DataColumn
    Friend WithEvents DataColumn184 As System.Data.DataColumn
    Friend WithEvents DataColumn185 As System.Data.DataColumn
    Friend WithEvents DataColumn186 As System.Data.DataColumn
    Friend WithEvents DataColumn187 As System.Data.DataColumn
    Friend WithEvents DataColumn188 As System.Data.DataColumn
    Friend WithEvents DataColumn189 As System.Data.DataColumn
    Friend WithEvents DataColumn190 As System.Data.DataColumn
    Friend WithEvents DataColumn191 As System.Data.DataColumn
    Friend WithEvents DataColumn192 As System.Data.DataColumn
    Friend WithEvents DataColumn193 As System.Data.DataColumn
    Friend WithEvents DataColumn194 As System.Data.DataColumn
    Friend WithEvents DataColumn195 As System.Data.DataColumn
    Friend WithEvents DataColumn196 As System.Data.DataColumn
    Friend WithEvents DataColumn197 As System.Data.DataColumn
    Friend WithEvents DataColumn198 As System.Data.DataColumn
    Friend WithEvents DataColumn199 As System.Data.DataColumn
    Friend WithEvents DataColumn200 As System.Data.DataColumn
    Friend WithEvents DataColumn201 As System.Data.DataColumn
    Friend WithEvents DataColumn202 As System.Data.DataColumn
    Friend WithEvents DataColumn203 As System.Data.DataColumn
    Friend WithEvents DataColumn204 As System.Data.DataColumn
    Friend WithEvents DataColumn205 As System.Data.DataColumn
    Friend WithEvents DataColumn206 As System.Data.DataColumn
    Friend WithEvents DataColumn207 As System.Data.DataColumn
    Friend WithEvents DataColumn208 As System.Data.DataColumn
    Friend WithEvents DataColumn209 As System.Data.DataColumn
    Friend WithEvents DataColumn210 As System.Data.DataColumn
    Friend WithEvents DataColumn211 As System.Data.DataColumn
    Friend WithEvents DataColumn212 As System.Data.DataColumn
    Friend WithEvents DataColumn213 As System.Data.DataColumn
    Friend WithEvents DataColumn214 As System.Data.DataColumn
    Friend WithEvents DataColumn215 As System.Data.DataColumn
    Friend WithEvents DataColumn216 As System.Data.DataColumn
    Friend WithEvents DataColumn3 As System.Data.DataColumn
    Friend WithEvents DataColumn4 As System.Data.DataColumn
    Friend WithEvents DataColumn5 As System.Data.DataColumn
    Friend WithEvents DataColumn6 As System.Data.DataColumn
    Public WithEvents dsLocalDB_ConversionFactor As System.Data.DataTable
    Public WithEvents dsLocalDB_Position As System.Data.DataTable
    Public WithEvents dsLocalDB_Trade As System.Data.DataTable
    Public WithEvents dsLocalDB_MarketPriceProduct As System.Data.DataTable
    Public WithEvents dsLocalDB_MarketPriceTrade As System.Data.DataTable
    Public WithEvents dsLocalDB_MarketPriceManagement As System.Data.DataTable
    Public WithEvents dsLocalDB_Grade As System.Data.DataTable
    Public WithEvents dsLocalDB_MarketPriceRepoRate As System.Data.DataTable
    Public WithEvents dsLocalDB_CodeData As System.Data.DataTable
    Friend WithEvents dsLocalDB_MarketPriceShortRate As System.Data.DataTable
    Friend WithEvents DataColumn217 As System.Data.DataColumn
    Friend WithEvents DataColumn218 As System.Data.DataColumn
    Friend WithEvents DataColumn219 As System.Data.DataColumn
    Friend WithEvents DataColumn220 As System.Data.DataColumn
    Friend WithEvents DataColumn221 As System.Data.DataColumn
    Friend WithEvents DataColumn222 As System.Data.DataColumn
    Friend WithEvents DataColumn223 As System.Data.DataColumn
    Friend WithEvents dsLocalDB_MarketPriceOnmemoryRepoRate As System.Data.DataTable
    Friend WithEvents DataColumn224 As System.Data.DataColumn
    Friend WithEvents DataColumn225 As System.Data.DataColumn
    Friend WithEvents DataColumn226 As System.Data.DataColumn
    Friend WithEvents DataColumn227 As System.Data.DataColumn
    Friend WithEvents DataColumn228 As System.Data.DataColumn
    Friend WithEvents DataColumn229 As System.Data.DataColumn
    Friend WithEvents DataColumn230 As System.Data.DataColumn
    Friend WithEvents DataColumn231 As System.Data.DataColumn
    Friend WithEvents DataColumn232 As System.Data.DataColumn
    Friend WithEvents DataColumn233 As System.Data.DataColumn
    Friend WithEvents DataColumn234 As System.Data.DataColumn
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents miSettings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miSysSettingsForm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miSysControlForm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miVersion As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTest As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTestA As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTestB As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTestC As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTestD As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miTestE As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents slServerTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents slServerStatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents slServerNextTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents slUser As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents miRateFilterLog As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miRateMonitor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents slServer As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents PanelAlert As System.Windows.Forms.Panel
    Friend WithEvents btnAlertClose As Penguin8AdminClient.ImageButton
    Friend WithEvents lblAlertMessage As System.Windows.Forms.Label
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents miNowStatusForm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miCust As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miCustList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents miUserList As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miChangePassword As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miOperationHist As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miDownload As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miFileDownload As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents miOperationHistClient As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PanelWatcherAlert As Panel
    Friend WithEvents lblWatcherAlertMessage As Label
    Friend WithEvents btnWatcherAlertClose As ImageButton
    Friend WithEvents miAlertLog As ToolStripMenuItem
    Friend WithEvents miExercRateList As ToolStripMenuItem
    Friend WithEvents miReportDownload As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents miRateChartList As ToolStripMenuItem
    Friend WithEvents miTradeAccountSummaryDownload As ToolStripMenuItem
End Class
