﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.chkEnableCust = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblTotalMoney = New System.Windows.Forms.Label()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbFromCustCode = New System.Windows.Forms.TextBox()
        Me.tbToCustCode = New System.Windows.Forms.TextBox()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCountryCode = New System.Windows.Forms.ComboBox()
        Me.chkTestAccount = New System.Windows.Forms.CheckBox()
        Me.chkStopCust = New System.Windows.Forms.CheckBox()
        Me.cbCurCode = New System.Windows.Forms.ComboBox()
        Me.chkEnableCustMode = New System.Windows.Forms.CheckBox()
        Me.dtpSysDateTime = New System.Windows.Forms.DateTimePicker()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.CustCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DealDisabled = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.CashDisabled = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.TestAccount = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.CountryName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(201, 248)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(211, 63)
        Me.lblNoData.TabIndex = 16
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 9
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 465)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(830, 32)
        Me.pnlSearchAdd.TabIndex = 15
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CustCode, Me.RegTime, Me.CurName, Me.TotalMoney, Me.DealDisabled, Me.CashDisabled, Me.TestAccount, Me.CountryName})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 140)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(830, 325)
        Me.grid.TabIndex = 8
        '
        'chkEnableCust
        '
        Me.chkEnableCust.AutoSize = True
        Me.chkEnableCust.Checked = True
        Me.chkEnableCust.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnableCust.Location = New System.Drawing.Point(387, 40)
        Me.chkEnableCust.Name = "chkEnableCust"
        Me.chkEnableCust.Size = New System.Drawing.Size(158, 16)
        Me.chkEnableCust.TabIndex = 1
        Me.chkEnableCust.Text = "残高のある委託者のみ表示"
        Me.chkEnableCust.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(151, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "～"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(161, 93)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 6
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "残高合計"
        '
        'lblTotalMoney
        '
        Me.lblTotalMoney.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalMoney.Location = New System.Drawing.Point(71, 93)
        Me.lblTotalMoney.Name = "lblTotalMoney"
        Me.lblTotalMoney.Size = New System.Drawing.Size(82, 23)
        Me.lblTotalMoney.TabIndex = 9
        Me.lblTotalMoney.Text = "0"
        Me.lblTotalMoney.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 8)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 12)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "委託者コード"
        '
        'tbFromCustCode
        '
        Me.tbFromCustCode.Location = New System.Drawing.Point(86, 66)
        Me.tbFromCustCode.Name = "tbFromCustCode"
        Me.tbFromCustCode.Size = New System.Drawing.Size(59, 19)
        Me.tbFromCustCode.TabIndex = 4
        Me.tbFromCustCode.Text = "1000050"
        '
        'tbToCustCode
        '
        Me.tbToCustCode.Location = New System.Drawing.Point(174, 66)
        Me.tbToCustCode.Name = "tbToCustCode"
        Me.tbToCustCode.Size = New System.Drawing.Size(59, 19)
        Me.tbToCustCode.TabIndex = 5
        Me.tbToCustCode.Text = "1000050"
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(256, 93)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 7
        Me.btnCSV.Text = "CSV"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(104, 39)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "取引日"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbCountryCode)
        Me.Panel1.Controls.Add(Me.chkTestAccount)
        Me.Panel1.Controls.Add(Me.chkStopCust)
        Me.Panel1.Controls.Add(Me.cbCurCode)
        Me.Panel1.Controls.Add(Me.chkEnableCustMode)
        Me.Panel1.Controls.Add(Me.dtpSysDateTime)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.tbToCustCode)
        Me.Panel1.Controls.Add(Me.tbFromCustCode)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.lblTotalMoney)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.chkEnableCust)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(830, 140)
        Me.Panel1.TabIndex = 13
        '
        'cbCountryCode
        '
        Me.cbCountryCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCountryCode.FormattingEnabled = True
        Me.cbCountryCode.Location = New System.Drawing.Point(266, 8)
        Me.cbCountryCode.Name = "cbCountryCode"
        Me.cbCountryCode.Size = New System.Drawing.Size(279, 20)
        Me.cbCountryCode.TabIndex = 20
        '
        'chkTestAccount
        '
        Me.chkTestAccount.AutoSize = True
        Me.chkTestAccount.Location = New System.Drawing.Point(387, 95)
        Me.chkTestAccount.Name = "chkTestAccount"
        Me.chkTestAccount.Size = New System.Drawing.Size(119, 16)
        Me.chkTestAccount.TabIndex = 19
        Me.chkTestAccount.Text = "テスト口座のみ表示"
        Me.chkTestAccount.UseVisualStyleBackColor = True
        '
        'chkStopCust
        '
        Me.chkStopCust.AutoSize = True
        Me.chkStopCust.Location = New System.Drawing.Point(387, 67)
        Me.chkStopCust.Name = "chkStopCust"
        Me.chkStopCust.Size = New System.Drawing.Size(163, 16)
        Me.chkStopCust.TabIndex = 18
        Me.chkStopCust.Text = "停止状態の委託者のみ表示"
        Me.chkStopCust.UseVisualStyleBackColor = True
        '
        'cbCurCode
        '
        Me.cbCurCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCurCode.FormattingEnabled = True
        Me.cbCurCode.Location = New System.Drawing.Point(139, 8)
        Me.cbCurCode.Name = "cbCurCode"
        Me.cbCurCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCurCode.TabIndex = 17
        '
        'chkEnableCustMode
        '
        Me.chkEnableCustMode.AutoSize = True
        Me.chkEnableCustMode.Checked = True
        Me.chkEnableCustMode.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnableCustMode.Location = New System.Drawing.Point(12, 37)
        Me.chkEnableCustMode.Name = "chkEnableCustMode"
        Me.chkEnableCustMode.Size = New System.Drawing.Size(72, 16)
        Me.chkEnableCustMode.TabIndex = 2
        Me.chkEnableCustMode.Text = "現在残高"
        Me.chkEnableCustMode.UseVisualStyleBackColor = True
        '
        'dtpSysDateTime
        '
        Me.dtpSysDateTime.Enabled = False
        Me.dtpSysDateTime.Location = New System.Drawing.Point(154, 36)
        Me.dtpSysDateTime.Name = "dtpSysDateTime"
        Me.dtpSysDateTime.Size = New System.Drawing.Size(127, 19)
        Me.dtpSysDateTime.TabIndex = 3
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'CustCode
        '
        Me.CustCode.DataPropertyName = "CustCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.CustCode.HeaderText = "委託者コード"
        Me.CustCode.Name = "CustCode"
        Me.CustCode.ReadOnly = True
        Me.CustCode.Width = 108
        '
        'RegTime
        '
        Me.RegTime.DataPropertyName = "RegTime"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle3.NullValue = Nothing
        Me.RegTime.DefaultCellStyle = DataGridViewCellStyle3
        Me.RegTime.HeaderText = "口座開設日時"
        Me.RegTime.Name = "RegTime"
        Me.RegTime.ReadOnly = True
        Me.RegTime.Width = 116
        '
        'CurName
        '
        Me.CurName.DataPropertyName = "CurName"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CurName.DefaultCellStyle = DataGridViewCellStyle4
        Me.CurName.HeaderText = "通貨種別"
        Me.CurName.Name = "CurName"
        Me.CurName.ReadOnly = True
        '
        'TotalMoney
        '
        Me.TotalMoney.DataPropertyName = "TotalMoney"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.Format = "###,###,###,###,##0"
        DataGridViewCellStyle5.NullValue = Nothing
        Me.TotalMoney.DefaultCellStyle = DataGridViewCellStyle5
        Me.TotalMoney.HeaderText = "残高"
        Me.TotalMoney.Name = "TotalMoney"
        Me.TotalMoney.ReadOnly = True
        Me.TotalMoney.Width = 120
        '
        'DealDisabled
        '
        Me.DealDisabled.DataPropertyName = "DealDisabled"
        Me.DealDisabled.HeaderText = "取引停止"
        Me.DealDisabled.Name = "DealDisabled"
        Me.DealDisabled.ReadOnly = True
        Me.DealDisabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DealDisabled.Width = 90
        '
        'CashDisabled
        '
        Me.CashDisabled.DataPropertyName = "CashDisabled"
        Me.CashDisabled.HeaderText = "入出金停止"
        Me.CashDisabled.Name = "CashDisabled"
        Me.CashDisabled.ReadOnly = True
        Me.CashDisabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.CashDisabled.Width = 90
        '
        'TestAccount
        '
        Me.TestAccount.DataPropertyName = "TestAccount"
        Me.TestAccount.HeaderText = "テスト口座"
        Me.TestAccount.Name = "TestAccount"
        Me.TestAccount.ReadOnly = True
        Me.TestAccount.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.TestAccount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'CountryName
        '
        Me.CountryName.DataPropertyName = "CountryName"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CountryName.DefaultCellStyle = DataGridViewCellStyle6
        Me.CountryName.HeaderText = "国"
        Me.CountryName.Name = "CountryName"
        Me.CountryName.ReadOnly = True
        '
        'CustList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(830, 497)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Name = "CustList"
        Me.Text = "委託者一覧"
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents chkEnableCust As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblTotalMoney As System.Windows.Forms.Label
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbFromCustCode As System.Windows.Forms.TextBox
    Friend WithEvents tbToCustCode As System.Windows.Forms.TextBox
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtpSysDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkEnableCustMode As System.Windows.Forms.CheckBox
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents cbCurCode As System.Windows.Forms.ComboBox
    Friend WithEvents chkStopCust As CheckBox
    Friend WithEvents chkTestAccount As CheckBox
    Friend WithEvents cbCountryCode As ComboBox
    Friend WithEvents CustCode As DataGridViewTextBoxColumn
    Friend WithEvents RegTime As DataGridViewTextBoxColumn
    Friend WithEvents CurName As DataGridViewTextBoxColumn
    Friend WithEvents TotalMoney As DataGridViewTextBoxColumn
    Friend WithEvents DealDisabled As DataGridViewButtonColumn
    Friend WithEvents CashDisabled As DataGridViewButtonColumn
    Friend WithEvents TestAccount As DataGridViewButtonColumn
    Friend WithEvents CountryName As DataGridViewTextBoxColumn
End Class
