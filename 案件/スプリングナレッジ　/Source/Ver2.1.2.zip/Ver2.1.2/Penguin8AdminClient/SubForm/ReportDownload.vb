﻿Imports System.IO
Imports System.IO.Path

Public Class ReportDownload

    Private WithEvents service As New ReportDownloadService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Public Class ReportType
        Public Const M47 As String = "01"
        Public Const M48 As String = "02"
    End Class


    Private formModeStatus As FormMode = FormMode.INIT
    Private pbForm As DownloadReportProgressStatus
    Private SavePath As String
    Private FileName As String
    Private ReportTypeCode As String

    Private Sub ReportDownload_Load(sender As Object, e As EventArgs) Handles Me.Load

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        btnM47Download.Text = "MB4.7" & vbCrLf & "ダウンロード"
        btnM48Download.Text = "MB4.8" & vbCrLf & "ダウンロード"

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        Dim SysDatePrev As DateTime = clsUtil.GetPrevWorkDay(SysDate)
        dtpFromDateTime.Value = New DateTime(SysDatePrev.Year, SysDatePrev.Month, SysDatePrev.Day)
        dtpToDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
        dtpToDateTime.Checked = False

        MainWindow.SubFormReportDownload = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        formModeStatus = FormMode.NORMAL

    End Sub

    Private Sub ReportDownload_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormReportDownload = False
    End Sub


    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me,
            UserSettings.getInstance().DataSaved.ReportDownload_FormMaximized,
            UserSettings.getInstance().DataSaved.ReportDownload_FormSize,
            UserSettings.getInstance().DataSaved.ReportDownload_FormLocation)

        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.ReportDownload_CmpCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me,
            UserSettings.getInstance().DataSaved.ReportDownload_FormMaximized,
            UserSettings.getInstance().DataSaved.ReportDownload_FormSize,
            UserSettings.getInstance().DataSaved.ReportDownload_FormLocation)

        UserSettings.getInstance().DataSaved.ReportDownload_CmpCode = cbCmpCode.SelectedValue
    End Sub

    Private Sub btnM47Download_Click(sender As Object, e As EventArgs) Handles btnM47Download.Click
        SelectDownload(ReportTypeManager.ReportType.MB4_7)
    End Sub

    Private Sub btnM48Download_Click(sender As Object, e As EventArgs) Handles btnM48Download.Click
        SelectDownload(ReportTypeManager.ReportType.MB4_8)
    End Sub

    Private Sub SelectDownload(ByVal type As String)

        Dim sfd As New SaveFileDialog()
        sfd.Title = "保存先のファイルを選択してください。"
        sfd.Filter = "ZIPファイル(*.zip)|*.zip"
        sfd.FileName = ReportTypeManager.GetReportTypeName(type) & ".zip"


        'Dim fbd As New FolderBrowserDialog
        'fbd.Description = "保存先フォルダを指定してください。"

        If sfd.ShowDialog(Me) = DialogResult.OK Then
            ' 保存先が選択されたらダウンロード処理
            SavePath = sfd.FileName
            FileName = GetFileName(SavePath)
            ReportTypeCode = type

            pbForm = New DownloadReportProgressStatus
            pbForm.Init(1) ' ダウンロードは1ファイルのみ
            pbForm.Service = service
            pbForm.MdiParent = Me.ParentForm
            pbForm.ParentSubForm = Me
            pbForm.Show()
            Me.Enabled = False

            downloadRequest()
        End If

    End Sub

    Private Sub downloadRequest()
        Dim downloadExist As Boolean = False
        If pbForm.Cancel Then
            MessageBox.Show("ファイルのダウンロードを中断しました。",
                        "エラー",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error)
        Else
            Dim CmpCode As String = Me.cbCmpCode.SelectedValue
            Dim SysDateFrom As String = dtpFromDateTime.Value.ToString("yyyyMMdd")
            Dim SysDateTo As String = dtpToDateTime.Value.ToString("yyyyMMdd")

            service.Download(ReportTypeCode, CmpCode, SysDateFrom, SysDateTo, FileName)
            downloadExist = True
        End If

        If Not downloadExist Then
            Me.Enabled = True
            pbForm.EndDownload()
            pbForm.Service = Nothing
            pbForm = Nothing
        End If

    End Sub

    Private Sub service_DownloadCancel() Handles service.DownloadCancel
        downloadRequest()
    End Sub

    Private Sub service_DownloadError(ErrorMessage As String) Handles service.DownloadError
        Me.Enabled = True
        pbForm.EndDownload()
        pbForm.Service = Nothing
        pbForm.ParentSubForm = Nothing
        pbForm = Nothing
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub service_DownloadSuccess(ByVal dlData As Byte()) Handles service.DownloadSuccess

        ' ダウンロードファイルを指定箇所に作成
        Using StreamFile As New FileStream(SavePath, FileMode.Create)
            Using StreamZIP As New BinaryWriter(StreamFile)
                StreamZIP.Write(dlData)
            End Using
        End Using

        'Dim StreamFile As New FileStream(SavePath, FileMode.Create)
        'Dim StreamZIP As New BinaryWriter(StreamFile)

        'StreamZIP.Write(dlData)


        'Dim StreamZIP As BinaryWriter
        'Dim StreamFile As New FileStream(SavePath, FileMode.Create)

        'StreamZIP = New BinaryWriter(StreamFile)
        'StreamZIP.Write(dlData)


        pbForm.Progres()
        MessageBox.Show(Me, "ダウンロードが完了しました", My.Application.Info.Title, MessageBoxButtons.OK)

        Me.Enabled = True
        pbForm.EndDownload()
        pbForm.Service = Nothing
        pbForm = Nothing
    End Sub


End Class