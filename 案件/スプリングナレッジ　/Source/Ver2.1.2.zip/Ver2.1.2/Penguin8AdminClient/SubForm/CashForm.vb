﻿Imports System.Globalization

Public Class CashForm

    Public Property Code As String

    Private WithEvents service As New CashService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub CashForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        setTitle()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbCashType.DisplayMember = "Name"
        cbCashType.ValueMember = "Code"
        cbCashType.DataSource = CashTypeManager.GetList()

        MainWindow.SubFormCashForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub CashForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormCashForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "入出金データ登録"
        Else
            'If UserTypeManager.IsEdit(SessionService.UserType) Then

            If False Then   '海外版は参照のみ
                Me.Text = "入出金データ編集"
            Else
                Me.Text = "入出金データ参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpExecTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExecTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpSysDate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbCashType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbMoney.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTotalMoney.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCustCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        'btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        btnOK.Enabled = False
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        cbEnabled.SelectedValue = ""
        dtpExecTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss")
        tbExecTimeMilliseconds.Text = ""
        dtpSysDate.Value = SysStatusService.GetData().SysDate
        cbCashType.SelectedValue = ""
    End Sub

    Private Sub initEdit()

        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of CashData), existNextFlag As Boolean) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "入出金データの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).CashCode <> Code Then
            MessageBox.Show(Me, "入出金データの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            'If UserTypeManager.IsEdit(SessionService.UserType) Then
            If False Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As CashData)
        Me.lblCode.Text = data.CashCode
        Me.cbEnabled.SelectedValue = data.Enabled
        Me.dtpExecTime.Value = data.ExecTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbExecTimeMilliseconds.Text = data.ExecTime.ToString("fff")
        Me.dtpSysDate.Value = data.SysDate
        Me.cbCashType.SelectedValue = data.CashType
        Select Case data.CashType
            Case "08"
                Me.tbMoney.Text = data.Money.ToString(clsUtil.GetMoneyFormatEdit())
            Case Else
                Me.tbMoney.Text = Math.Abs(data.Money).ToString(clsUtil.GetMoneyFormatEdit())
        End Select
        Me.tbTotalMoney.Text = data.TotalMoney.ToString(clsUtil.GetMoneyFormatEdit())
        Me.tbCustCode.Text = data.CustCode
    End Sub

    Private Function getDataFromControl() As CashData
        Dim ret As New CashData
        ret.CashCode = Me.lblCode.Text
        ret.Enabled = Me.cbEnabled.SelectedValue
        ret.ExecTime = dtpExecTime.Value
        If tbExecTimeMilliseconds.Text <> "" Then
            ret.ExecTime = ret.ExecTime.AddMilliseconds(Integer.Parse(tbExecTimeMilliseconds.Text))
        End If
        ret.SysDate = Me.dtpSysDate.Value
        ret.CashType = Me.cbCashType.SelectedValue
        '取引種別によって負の値に変換
        Select Case Me.cbCashType.SelectedValue
            Case "08"
                ret.Money = Decimal.Parse(Me.tbMoney.Text)
            Case "02", "03"
                ret.Money = Math.Abs(Decimal.Parse(Me.tbMoney.Text)) * -1
            Case Else
                ret.Money = Math.Abs(Decimal.Parse(Me.tbMoney.Text))
        End Select
        ret.TotalMoney = Decimal.Parse(Me.tbTotalMoney.Text)
        ret.CustCode = Me.tbCustCode.Text
        Return ret
    End Function

    Private Function checkInput() As Boolean
        If Me.cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbExecTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "処理時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Me.cbCashType.SelectedValue = "" Then
            MessageBox.Show(Me, "取引種別を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExSignMoney.IsMatch(Me.tbMoney.Text) Then
            MessageBox.Show(Me, "金額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim Money As Decimal
        If Not Decimal.TryParse(Me.tbMoney.Text, Money) Then
            MessageBox.Show(Me, "金額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExSignMoney.IsMatch(Me.tbTotalMoney.Text) Then
            MessageBox.Show(Me, "取引後残高を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim TotalMoney As Decimal
        If Not Decimal.TryParse(Me.tbTotalMoney.Text, TotalMoney) Then
            MessageBox.Show(Me, "取引後残高を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Me.tbCustCode.Text.Length = 0 OrElse Me.tbCustCode.Text.Length > 32 Then
            MessageBox.Show(Me, "委託者コードを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As CashData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As CashData = getDataFromControl()

        service.Update(data)
    End Sub

End Class