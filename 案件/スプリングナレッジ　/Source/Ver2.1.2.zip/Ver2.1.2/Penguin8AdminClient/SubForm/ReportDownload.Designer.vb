﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ReportDownload
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnM47Download = New System.Windows.Forms.Button()
        Me.btnM48Download = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 12)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 11
        '
        'btnM47Download
        '
        Me.btnM47Download.Location = New System.Drawing.Point(42, 83)
        Me.btnM47Download.Name = "btnM47Download"
        Me.btnM47Download.Size = New System.Drawing.Size(75, 33)
        Me.btnM47Download.TabIndex = 15
        Me.btnM47Download.Text = "MB4.7ダウンロード"
        Me.btnM47Download.UseVisualStyleBackColor = True
        '
        'btnM48Download
        '
        Me.btnM48Download.Location = New System.Drawing.Point(183, 83)
        Me.btnM48Download.Name = "btnM48Download"
        Me.btnM48Download.Size = New System.Drawing.Size(75, 33)
        Me.btnM48Download.TabIndex = 16
        Me.btnM48Download.Text = "MB4.8ダウンロード"
        Me.btnM48Download.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(159, 42)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.Size = New System.Drawing.Size(114, 19)
        Me.dtpToDateTime.TabIndex = 19
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(13, 42)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.Size = New System.Drawing.Size(117, 19)
        Me.dtpFromDateTime.TabIndex = 17
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(136, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(17, 12)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "～"
        '
        'ReportDownload
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(299, 132)
        Me.Controls.Add(Me.dtpToDateTime)
        Me.Controls.Add(Me.dtpFromDateTime)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnM48Download)
        Me.Controls.Add(Me.btnM47Download)
        Me.Controls.Add(Me.cbCmpCode)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "ReportDownload"
        Me.Text = "報告書データ"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cbCmpCode As ComboBox
    Friend WithEvents btnM47Download As Button
    Friend WithEvents btnM48Download As Button
    Friend WithEvents dtpToDateTime As DateTimePicker
    Friend WithEvents dtpFromDateTime As DateTimePicker
    Friend WithEvents Label2 As Label
End Class
