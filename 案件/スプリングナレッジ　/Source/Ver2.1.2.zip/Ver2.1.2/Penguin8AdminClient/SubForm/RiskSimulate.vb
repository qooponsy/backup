﻿Public Class RiskSimulate

    Private WithEvents service As New ProductService

    Private Table As New DataTable
    Private ProductList As List(Of ProductData)

    Private ProductCode As String
    Private ComCode As String

    Private Sub RiskSimulate_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        PAndL.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PAndLR.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbCurCode.DisplayMember = "CurName"
        cbCurCode.ValueMember = "CurCode"
        cbCurCode.DataSource = CurrencyService.GetList()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbOpType.DisplayMember = "Name"
        cbOpType.ValueMember = "Code"
        cbOpType.DataSource = OptionTypeManager.GetList()

        cbExercTime.DisplayMember = "ExercTimeDisp"

        MainWindow.SubFormRiskSimulate = True

        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        'setRate()
        initGrid()
        initChart()

        service.ReadList(SessionService.CmpCode, "", cbOpType.SelectedValue, "0", "1", "1", "", DateTimeUtil.ConvToServerDateTime(RateTickService.ServerTime, "yyyyMMddHHmm"), "", "", "", "ExercTime")
    End Sub

    Private Sub RiskSimulate_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormRiskSimulate = False
        SaveSettings()
    End Sub


    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RiskSimulate_FormMaximized, _
            UserSettings.getInstance().DataSaved.RiskSimulate_FormSize, _
            UserSettings.getInstance().DataSaved.RiskSimulate_FormLocation)

        Dim SplitterDistance As Integer = UserSettings.getInstance().DataSaved.RiskSimulate_SplitterDistance
        If SplitterDistance > 0 Then SplitContainer1.SplitterDistance = SplitterDistance
        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RiskSimulate_Columns)
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.RiskSimulate_ComCode
        cbOpType.SelectedValue = UserSettings.getInstance().DataSaved.RiskSimulate_OpType
        cbCurCode.SelectedValue = UserSettings.getInstance().DataSaved.RiskSimulate_CurCode
        chkAutoReCalc.Checked = UserSettings.getInstance().DataSaved.RiskSimulate_AutoReCalc
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RiskSimulate_FormMaximized, _
            UserSettings.getInstance().DataSaved.RiskSimulate_FormSize, _
            UserSettings.getInstance().DataSaved.RiskSimulate_FormLocation)

        UserSettings.getInstance().DataSaved.RiskSimulate_SplitterDistance = SplitContainer1.SplitterDistance
        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RiskSimulate_Columns)
        UserSettings.getInstance().DataSaved.RiskSimulate_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.RiskSimulate_OpType = cbOpType.SelectedValue
        UserSettings.getInstance().DataSaved.RiskSimulate_CurCode = cbCurCode.SelectedValue
        UserSettings.getInstance().DataSaved.RiskSimulate_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.RiskSimulate_AutoReCalc = chkAutoReCalc.Checked
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table.Columns.Add("Rate", GetType(Decimal))
        Table.Columns.Add("PAndL", GetType(Decimal))
        Table.Columns.Add("PAndLR", GetType(Decimal))
        grid.DataSource = Table
    End Sub

    Private Sub initChart()
    End Sub


    Private Sub btnRun_Click(sender As System.Object, e As System.EventArgs) Handles btnRun.Click
        ReCalc()
    End Sub

    Private Sub TimerRefresh_Tick(sender As System.Object, e As System.EventArgs) Handles TimerRefresh.Tick
        ReCalc()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of ProductData), existNextFlag As Boolean) Handles service.ReadSuccess
        ProductList = list
        setExercList()
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        setExercList()
    End Sub

    Private Sub cbOpType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbOpType.SelectedIndexChanged
        service.ReadList(SessionService.CmpCode, "", cbOpType.SelectedValue, "0", "1", "1", "", DateTimeUtil.ConvToServerDateTime(RateTickService.ServerTime, "yyyyMMddHHmm"), "", "", "", "ExercTime")
    End Sub

    Private Sub setExercList()
        If ProductList Is Nothing Then
            Return
        End If
        Dim OpType As String = cbOpType.SelectedValue
        Dim ComCode As String = cbComCode.SelectedValue

        Dim ExercList As New List(Of ProductData)
        For Each item As ProductData In ProductList
            If item.OpType = OpType Then
                If item.ComCode = ComCode Then
                    ExercList.Add(item)
                End If
            End If
        Next
        cbExercTime.DataSource = ExercList
    End Sub


    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).DataPropertyName
                Case "Rate"
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

    Private Sub ReCalc()
        Dim Product As ProductData = cbExercTime.SelectedValue
        If Product Is Nothing Then Return
        If ProductCode <> Product.ProductCode Then Table.Clear()
        ProductCode = Product.ProductCode
        ComCode = Product.ComCode
        Dim CPData As CurrencyPairData = CurrencyPairService.GetData(ComCode)

        lblTime.Text = RateTickService.ServerTime.ToString("HH:mm")
        lblComCode.Text = CPData.ComName
        Dim NowRate As RateTickData = RateTickService.GetLastRate(cbComCode.SelectedValue)
        lblRate.Text = NowRate.Rate.ToString(clsUtil.GetRateDPFormat(CPData.DecimalPlaces))

        Dim OldRateMin As Decimal = Decimal.MinValue
        Dim OldRateMax As Decimal = Decimal.MaxValue

        If Table.Rows.Count > 0 Then
            OldRateMin = Table.Rows(0)("Rate")
            OldRateMax = Table.Rows(Table.Rows.Count - 1)("Rate")
        End If

        Table.Clear()

        Dim dp As Integer = CPData.DecimalPlaces
        Dim rateStepValue As Decimal = Math.Pow(10, -dp)
        Dim sr As Decimal = CalcParamService.GetData(ComCode).InterestRate
        Dim swapRate As Decimal = CalcParamService.GetData(ComCode).SwapRate
        Dim sigma As Decimal = CalcParamService.GetData(ComCode).Volatility
        Dim StdDt As DateTime = RateTickService.ServerTime
        Dim SelCmp As String = cbCmpCode.SelectedValue
        Dim SelCur As String = cbCurCode.SelectedValue

        Dim RateList As New SortedSet(Of Decimal)
        For Each item As TradeData In TradeNowService.DataList
            If SelCmp <> "" AndAlso SelCmp <> item.CmpCode Then Continue For
            If SelCur <> "" AndAlso SelCur <> item.CurCode Then Continue For
            If item.ProductCode <> Product.ProductCode Then Continue For
            RateList.Add(item.ExercPrice - rateStepValue)
            RateList.Add(item.ExercPrice)
            RateList.Add(item.ExercPrice + rateStepValue)
        Next

        If RateList.Count > 0 Then
            '現在レート追加
            RateList.Add(NowRate.Rate)

            Dim RawRateMin As Decimal = RateList.Min
            Dim RawRateMax As Decimal = RateList.Max

            If OldRateMin >= RawRateMin Or OldRateMin < RawRateMin - rateStepValue * 20 Then
                RateList.Add(RawRateMin - (((RawRateMin / rateStepValue - 1) Mod 10) + 1) * rateStepValue)
            Else
                RateList.Add(OldRateMin)
            End If
            If OldRateMax <= RawRateMax Or OldRateMax > RawRateMax + rateStepValue * 20 Then
                RateList.Add(RawRateMax + (10 - ((RawRateMax / rateStepValue) Mod 10)) * rateStepValue)
            Else
                RateList.Add(OldRateMax)
            End If

            For Each rate As Decimal In RateList
                Dim row As DataRow = Table.NewRow()

                Dim PAndL As Decimal = 0
                Dim PAndLR As Decimal = 0

                For Each item As TradeData In TradeNowService.DataList
                    If SelCmp <> "" AndAlso SelCmp <> item.CmpCode Then Continue For
                    If SelCur <> "" AndAlso SelCur <> item.CurCode Then Continue For
                    If item.ProductCode <> Product.ProductCode Then Continue For

                    If item.ExercPrice = rate Then
                        PAndL += 0
                    ElseIf (item.TradeType = "01" And item.ExercPrice < rate) Or (item.TradeType = "02" And item.ExercPrice > rate) Then
                        PAndL -= item.Premium * item.PayoutRate
                    Else
                        PAndL += item.Premium
                    End If

                    PAndLR -= RiskCalc.PAndL(item.Premium, 0, item.PayoutRate, item.TradeType, rate, item.ExercPrice, sr, swapRate, item.Volatility, StdDt, item.ExercTime, SessionService.DecimalPlaces)
                Next

                row("Rate") = rate
                row("PAndL") = PAndL
                row("PAndLR") = PAndLR

                Table.Rows.Add(row)
            Next

        End If

        chart.ChartAreas(0).AxisX.LabelStyle.Format = clsUtil.GetRateDPFormat(CPData.DecimalPlaces)
        chart.ChartAreas(0).AxisX.StripLines(0).IntervalOffset = NowRate.Rate
        chart.ChartAreas(0).AxisX.StripLines(0).Text = lblRate.Text
        chart.Series(0).Points.DataBind(Table.Rows, "Rate", "PAndL", "")
        chart.Series(1).Points.DataBind(Table.Rows, "Rate", "PAndLR", "")

        lblNoData.Visible = (Table.Rows.Count = 0)
    End Sub

    Private Sub chkAutoReCalc_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAutoReCalc.CheckedChanged
        TimerRefresh.Enabled = chkAutoReCalc.Checked
    End Sub

End Class
