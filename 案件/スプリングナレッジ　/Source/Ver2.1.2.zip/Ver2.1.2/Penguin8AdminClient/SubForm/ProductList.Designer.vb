﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpSysDate = New System.Windows.Forms.DateTimePicker()
        Me.chkNowProduct = New System.Windows.Forms.CheckBox()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.cbExercState = New System.Windows.Forms.ComboBox()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ResidualTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Spread = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateArrowCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpTypeCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OptionTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeLimitTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercStatusCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductBaseCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Premium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.cmGrid.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(398, 54)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 7
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "～"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbOpType)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.dtpSysDate)
        Me.Panel1.Controls.Add(Me.chkNowProduct)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.cbExercState)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(950, 87)
        Me.Panel1.TabIndex = 8
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Location = New System.Drawing.Point(265, 6)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(121, 20)
        Me.cbOpType.TabIndex = 20
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(116, 37)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "取引日"
        '
        'dtpSysDate
        '
        Me.dtpSysDate.Location = New System.Drawing.Point(163, 33)
        Me.dtpSysDate.Name = "dtpSysDate"
        Me.dtpSysDate.Size = New System.Drawing.Size(126, 19)
        Me.dtpSysDate.TabIndex = 17
        '
        'chkNowProduct
        '
        Me.chkNowProduct.AutoSize = True
        Me.chkNowProduct.Checked = True
        Me.chkNowProduct.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkNowProduct.Location = New System.Drawing.Point(15, 36)
        Me.chkNowProduct.Name = "chkNowProduct"
        Me.chkNowProduct.Size = New System.Drawing.Size(72, 16)
        Me.chkNowProduct.TabIndex = 16
        Me.chkNowProduct.Text = "現在銘柄"
        Me.chkNowProduct.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(576, 54)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 15
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 6)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'cbExercState
        '
        Me.cbExercState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercState.FormattingEnabled = True
        Me.cbExercState.Location = New System.Drawing.Point(392, 6)
        Me.cbExercState.Name = "cbExercState"
        Me.cbExercState.Size = New System.Drawing.Size(121, 20)
        Me.cbExercState.TabIndex = 2
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.Checked = False
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 61)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 6
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.Checked = False
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 61)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 4
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(487, 54)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 8
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(519, 8)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 3
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(138, 6)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 1
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 408)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(950, 32)
        Me.pnlSearchAdd.TabIndex = 11
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 10
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ComCode, Me.ComName, Me.ExercTime, Me.ResidualTime, Me.PayoutRate, Me.Spread, Me.Rate, Me.RateArrowCount, Me.ProductCode, Me.OpTypeCode, Me.OpType, Me.OptionTime, Me.SysDate, Me.StartTime, Me.TradeLimitTime, Me.LastExercTime, Me.ProductEnabled, Me.ExercStatusCode, Me.ExercStatus, Me.ProductBaseCode, Me.ExercRateSeq, Me.ExercRate, Me.Premium, Me.PAndL})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 87)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle24
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(950, 321)
        Me.grid.TabIndex = 9
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(366, 194)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(211, 63)
        Me.lblNoData.TabIndex = 12
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.ComCode.HeaderText = "通貨ペア(Code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle3
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComName.Width = 65
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle4
        Me.ExercTime.HeaderText = "行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        Me.ExercTime.Width = 96
        '
        'ResidualTime
        '
        Me.ResidualTime.DataPropertyName = "ResidualTime"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.ResidualTime.DefaultCellStyle = DataGridViewCellStyle5
        Me.ResidualTime.HeaderText = "残存期間"
        Me.ResidualTime.Name = "ResidualTime"
        Me.ResidualTime.ReadOnly = True
        Me.ResidualTime.Width = 96
        '
        'PayoutRate
        '
        Me.PayoutRate.DataPropertyName = "PayoutRate"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.Format = "######0.00######"
        DataGridViewCellStyle6.NullValue = Nothing
        Me.PayoutRate.DefaultCellStyle = DataGridViewCellStyle6
        Me.PayoutRate.HeaderText = "ペイアウト率"
        Me.PayoutRate.Name = "PayoutRate"
        Me.PayoutRate.ReadOnly = True
        Me.PayoutRate.Width = 87
        '
        'Spread
        '
        Me.Spread.DataPropertyName = "Spread"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Spread.DefaultCellStyle = DataGridViewCellStyle7
        Me.Spread.HeaderText = "スプレッド"
        Me.Spread.Name = "Spread"
        Me.Spread.ReadOnly = True
        Me.Spread.Width = 80
        '
        'Rate
        '
        Me.Rate.DataPropertyName = "Rate"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "######0.000#####"
        DataGridViewCellStyle8.NullValue = Nothing
        DataGridViewCellStyle8.Padding = New System.Windows.Forms.Padding(0, 0, 18, 0)
        Me.Rate.DefaultCellStyle = DataGridViewCellStyle8
        Me.Rate.HeaderText = "レート"
        Me.Rate.Name = "Rate"
        Me.Rate.ReadOnly = True
        Me.Rate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Rate.Width = 80
        '
        'RateArrowCount
        '
        Me.RateArrowCount.DataPropertyName = "RateArrowCount"
        Me.RateArrowCount.HeaderText = "レート矢印カウント"
        Me.RateArrowCount.Name = "RateArrowCount"
        Me.RateArrowCount.ReadOnly = True
        Me.RateArrowCount.Visible = False
        '
        'ProductCode
        '
        Me.ProductCode.DataPropertyName = "ProductCode"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductCode.DefaultCellStyle = DataGridViewCellStyle9
        Me.ProductCode.HeaderText = "銘柄コード"
        Me.ProductCode.Name = "ProductCode"
        Me.ProductCode.ReadOnly = True
        Me.ProductCode.Width = 108
        '
        'OpTypeCode
        '
        Me.OpTypeCode.DataPropertyName = "OpTypeCode"
        Me.OpTypeCode.HeaderText = "オプション種別コード"
        Me.OpTypeCode.Name = "OpTypeCode"
        Me.OpTypeCode.ReadOnly = True
        Me.OpTypeCode.Visible = False
        '
        'OpType
        '
        Me.OpType.DataPropertyName = "OpType"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OpType.DefaultCellStyle = DataGridViewCellStyle10
        Me.OpType.HeaderText = "オプション種別"
        Me.OpType.Name = "OpType"
        Me.OpType.ReadOnly = True
        Me.OpType.Width = 79
        '
        'OptionTime
        '
        Me.OptionTime.DataPropertyName = "OptionTime"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.Format = "####秒"
        Me.OptionTime.DefaultCellStyle = DataGridViewCellStyle11
        Me.OptionTime.HeaderText = "オプション期間"
        Me.OptionTime.Name = "OptionTime"
        Me.OptionTime.ReadOnly = True
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle12
        Me.SysDate.HeaderText = "システム営業日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 72
        '
        'StartTime
        '
        Me.StartTime.DataPropertyName = "StartTime"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle13.NullValue = Nothing
        Me.StartTime.DefaultCellStyle = DataGridViewCellStyle13
        Me.StartTime.HeaderText = "取引開始日"
        Me.StartTime.Name = "StartTime"
        Me.StartTime.ReadOnly = True
        Me.StartTime.Width = 110
        '
        'TradeLimitTime
        '
        Me.TradeLimitTime.DataPropertyName = "TradeLimitTime"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle14.NullValue = Nothing
        Me.TradeLimitTime.DefaultCellStyle = DataGridViewCellStyle14
        Me.TradeLimitTime.HeaderText = "取引可能期日"
        Me.TradeLimitTime.Name = "TradeLimitTime"
        Me.TradeLimitTime.ReadOnly = True
        Me.TradeLimitTime.Width = 110
        '
        'LastExercTime
        '
        Me.LastExercTime.DataPropertyName = "LastExercTime"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle15.Format = "yyyy/MM/dd HH:mm"
        Me.LastExercTime.DefaultCellStyle = DataGridViewCellStyle15
        Me.LastExercTime.HeaderText = "最終行使期日"
        Me.LastExercTime.Name = "LastExercTime"
        Me.LastExercTime.ReadOnly = True
        Me.LastExercTime.Width = 105
        '
        'ProductEnabled
        '
        Me.ProductEnabled.DataPropertyName = "ProductEnabled"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductEnabled.DefaultCellStyle = DataGridViewCellStyle16
        Me.ProductEnabled.HeaderText = "有効フラグ"
        Me.ProductEnabled.Name = "ProductEnabled"
        Me.ProductEnabled.ReadOnly = True
        Me.ProductEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ProductEnabled.Width = 60
        '
        'ExercStatusCode
        '
        Me.ExercStatusCode.DataPropertyName = "ExercStatusCode"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercStatusCode.DefaultCellStyle = DataGridViewCellStyle17
        Me.ExercStatusCode.HeaderText = "行使フラグ(Code)"
        Me.ExercStatusCode.Name = "ExercStatusCode"
        Me.ExercStatusCode.ReadOnly = True
        Me.ExercStatusCode.Visible = False
        '
        'ExercStatus
        '
        Me.ExercStatus.DataPropertyName = "ExercStatus"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercStatus.DefaultCellStyle = DataGridViewCellStyle18
        Me.ExercStatus.HeaderText = "行使フラグ"
        Me.ExercStatus.Name = "ExercStatus"
        Me.ExercStatus.ReadOnly = True
        Me.ExercStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ExercStatus.Width = 60
        '
        'ProductBaseCode
        '
        Me.ProductBaseCode.DataPropertyName = "ProductBaseCode"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseCode.DefaultCellStyle = DataGridViewCellStyle19
        Me.ProductBaseCode.HeaderText = "銘柄設定コード"
        Me.ProductBaseCode.Name = "ProductBaseCode"
        Me.ProductBaseCode.ReadOnly = True
        Me.ProductBaseCode.Width = 108
        '
        'ExercRateSeq
        '
        Me.ExercRateSeq.DataPropertyName = "ExercRateSeq"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercRateSeq.DefaultCellStyle = DataGridViewCellStyle20
        Me.ExercRateSeq.HeaderText = "行使時価格Seq"
        Me.ExercRateSeq.Name = "ExercRateSeq"
        Me.ExercRateSeq.ReadOnly = True
        Me.ExercRateSeq.Width = 109
        '
        'ExercRate
        '
        Me.ExercRate.DataPropertyName = "ExercRate"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle21.Format = "######0.000#####"
        DataGridViewCellStyle21.NullValue = Nothing
        Me.ExercRate.DefaultCellStyle = DataGridViewCellStyle21
        Me.ExercRate.HeaderText = "行使時価格"
        Me.ExercRate.Name = "ExercRate"
        Me.ExercRate.ReadOnly = True
        Me.ExercRate.Width = 90
        '
        'Premium
        '
        Me.Premium.DataPropertyName = "Premium"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle22.Format = "###,###,###,###,##0"
        Me.Premium.DefaultCellStyle = DataGridViewCellStyle22
        Me.Premium.HeaderText = "取引金額"
        Me.Premium.Name = "Premium"
        Me.Premium.ReadOnly = True
        Me.Premium.Visible = False
        '
        'PAndL
        '
        Me.PAndL.DataPropertyName = "PAndL"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle23.Format = "###,###,###,###,##0"
        DataGridViewCellStyle23.NullValue = Nothing
        Me.PAndL.DefaultCellStyle = DataGridViewCellStyle23
        Me.PAndL.HeaderText = "損益"
        Me.PAndL.Name = "PAndL"
        Me.PAndL.ReadOnly = True
        Me.PAndL.Visible = False
        '
        'ProductList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(950, 440)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "ProductList"
        Me.Text = "銘柄一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.cmGrid.ResumeLayout(False)
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents dgvEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents cbExercState As System.Windows.Forms.ComboBox
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents chkNowProduct As System.Windows.Forms.CheckBox
    Friend WithEvents dtpSysDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cbOpType As ComboBox
    Friend WithEvents ComCode As DataGridViewTextBoxColumn
    Friend WithEvents ComName As DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As DataGridViewTextBoxColumn
    Friend WithEvents ResidualTime As DataGridViewTextBoxColumn
    Friend WithEvents PayoutRate As DataGridViewTextBoxColumn
    Friend WithEvents Spread As DataGridViewTextBoxColumn
    Friend WithEvents Rate As DataGridViewTextBoxColumn
    Friend WithEvents RateArrowCount As DataGridViewTextBoxColumn
    Friend WithEvents ProductCode As DataGridViewTextBoxColumn
    Friend WithEvents OpTypeCode As DataGridViewTextBoxColumn
    Friend WithEvents OpType As DataGridViewTextBoxColumn
    Friend WithEvents OptionTime As DataGridViewTextBoxColumn
    Friend WithEvents SysDate As DataGridViewTextBoxColumn
    Friend WithEvents StartTime As DataGridViewTextBoxColumn
    Friend WithEvents TradeLimitTime As DataGridViewTextBoxColumn
    Friend WithEvents LastExercTime As DataGridViewTextBoxColumn
    Friend WithEvents ProductEnabled As DataGridViewTextBoxColumn
    Friend WithEvents ExercStatusCode As DataGridViewTextBoxColumn
    Friend WithEvents ExercStatus As DataGridViewTextBoxColumn
    Friend WithEvents ProductBaseCode As DataGridViewTextBoxColumn
    Friend WithEvents ExercRateSeq As DataGridViewTextBoxColumn
    Friend WithEvents ExercRate As DataGridViewTextBoxColumn
    Friend WithEvents Premium As DataGridViewTextBoxColumn
    Friend WithEvents PAndL As DataGridViewTextBoxColumn
End Class
