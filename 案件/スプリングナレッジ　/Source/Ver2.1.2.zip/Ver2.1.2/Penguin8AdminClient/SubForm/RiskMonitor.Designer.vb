﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RiskMonitor
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle38 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle36 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle37 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCurCode = New System.Windows.Forms.ComboBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.gridSum = New System.Windows.Forms.DataGridView()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateArrowCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Premium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Delta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GammaU = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GammaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Vega = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Theta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ShortRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SwapRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VolatilityAdjust = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Volatility = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gridDetail = New System.Windows.Forms.DataGridView()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.DetailProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailOpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailOptionTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailZanzon = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailPayoutRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailRateArrowCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailPAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailPremium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailDelta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailGammaU = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailGammaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailVega = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailTheta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailRho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DetailCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.gridSum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gridDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbCurCode)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 26)
        Me.Panel1.TabIndex = 0
        '
        'cbCurCode
        '
        Me.cbCurCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCurCode.FormattingEnabled = True
        Me.cbCurCode.Location = New System.Drawing.Point(130, 3)
        Me.cbCurCode.Name = "cbCurCode"
        Me.cbCurCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCurCode.TabIndex = 19
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(3, 3)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 26)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.gridSum)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.gridDetail)
        Me.SplitContainer1.Size = New System.Drawing.Size(984, 436)
        Me.SplitContainer1.SplitterDistance = 136
        Me.SplitContainer1.TabIndex = 1
        '
        'gridSum
        '
        Me.gridSum.AllowUserToAddRows = False
        Me.gridSum.AllowUserToDeleteRows = False
        Me.gridSum.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.gridSum.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.gridSum.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridSum.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ComCode, Me.ComName, Me.Rate, Me.RateArrowCount, Me.PAndL, Me.Premium, Me.Delta, Me.GammaU, Me.GammaD, Me.Vega, Me.Theta, Me.Rho, Me.TradeCount, Me.ShortRate, Me.SwapRate, Me.VolatilityAdjust, Me.Volatility})
        Me.gridSum.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gridSum.Location = New System.Drawing.Point(0, 0)
        Me.gridSum.MultiSelect = False
        Me.gridSum.Name = "gridSum"
        Me.gridSum.ReadOnly = True
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.gridSum.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.gridSum.RowHeadersVisible = False
        Me.gridSum.RowTemplate.Height = 21
        Me.gridSum.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.gridSum.Size = New System.Drawing.Size(984, 136)
        Me.gridSum.TabIndex = 0
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.ComCode.HeaderText = "通貨ペア(Code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle3
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ComName.Width = 73
        '
        'Rate
        '
        Me.Rate.DataPropertyName = "Rate"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "######0.000#####"
        DataGridViewCellStyle4.Padding = New System.Windows.Forms.Padding(0, 0, 18, 0)
        Me.Rate.DefaultCellStyle = DataGridViewCellStyle4
        Me.Rate.HeaderText = "レート"
        Me.Rate.Name = "Rate"
        Me.Rate.ReadOnly = True
        Me.Rate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Rate.Width = 80
        '
        'RateArrowCount
        '
        Me.RateArrowCount.DataPropertyName = "RateArrowCount"
        Me.RateArrowCount.HeaderText = "レート矢印カウント"
        Me.RateArrowCount.Name = "RateArrowCount"
        Me.RateArrowCount.ReadOnly = True
        Me.RateArrowCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.RateArrowCount.Visible = False
        '
        'PAndL
        '
        Me.PAndL.DataPropertyName = "PAndL"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.Format = "#,###,###,##0"
        Me.PAndL.DefaultCellStyle = DataGridViewCellStyle5
        Me.PAndL.HeaderText = "損益"
        Me.PAndL.Name = "PAndL"
        Me.PAndL.ReadOnly = True
        Me.PAndL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.PAndL.Width = 88
        '
        'Premium
        '
        Me.Premium.DataPropertyName = "Premium"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.Format = "#,###,###,##0.0000"
        Me.Premium.DefaultCellStyle = DataGridViewCellStyle6
        Me.Premium.HeaderText = "Premium"
        Me.Premium.Name = "Premium"
        Me.Premium.ReadOnly = True
        Me.Premium.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Premium.Width = 88
        '
        'Delta
        '
        Me.Delta.DataPropertyName = "Delta"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle7.Format = "#,###,###,##0.0000"
        Me.Delta.DefaultCellStyle = DataGridViewCellStyle7
        Me.Delta.HeaderText = "Delta"
        Me.Delta.Name = "Delta"
        Me.Delta.ReadOnly = True
        Me.Delta.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Delta.Width = 88
        '
        'GammaU
        '
        Me.GammaU.DataPropertyName = "GammaU"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "#,###,###,##0.0000"
        Me.GammaU.DefaultCellStyle = DataGridViewCellStyle8
        Me.GammaU.HeaderText = "Gamma(U)"
        Me.GammaU.Name = "GammaU"
        Me.GammaU.ReadOnly = True
        Me.GammaU.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.GammaU.Width = 88
        '
        'GammaD
        '
        Me.GammaD.DataPropertyName = "GammaD"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "#,###,###,##0.0000"
        Me.GammaD.DefaultCellStyle = DataGridViewCellStyle9
        Me.GammaD.HeaderText = "Gamma(D)"
        Me.GammaD.Name = "GammaD"
        Me.GammaD.ReadOnly = True
        Me.GammaD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.GammaD.Width = 88
        '
        'Vega
        '
        Me.Vega.DataPropertyName = "Vega"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "#,###,###,##0.0000"
        Me.Vega.DefaultCellStyle = DataGridViewCellStyle10
        Me.Vega.HeaderText = "Vega"
        Me.Vega.Name = "Vega"
        Me.Vega.ReadOnly = True
        Me.Vega.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Vega.Width = 88
        '
        'Theta
        '
        Me.Theta.DataPropertyName = "Theta"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle11.Format = "#,###,###,##0.0000"
        Me.Theta.DefaultCellStyle = DataGridViewCellStyle11
        Me.Theta.HeaderText = "Theta"
        Me.Theta.Name = "Theta"
        Me.Theta.ReadOnly = True
        Me.Theta.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Theta.Width = 88
        '
        'Rho
        '
        Me.Rho.DataPropertyName = "Rho"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle12.Format = "#,###,###,##0.0000"
        Me.Rho.DefaultCellStyle = DataGridViewCellStyle12
        Me.Rho.HeaderText = "Rho"
        Me.Rho.Name = "Rho"
        Me.Rho.ReadOnly = True
        Me.Rho.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Rho.Width = 88
        '
        'TradeCount
        '
        Me.TradeCount.DataPropertyName = "TradeCount"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.TradeCount.DefaultCellStyle = DataGridViewCellStyle13
        Me.TradeCount.HeaderText = "件数"
        Me.TradeCount.Name = "TradeCount"
        Me.TradeCount.ReadOnly = True
        Me.TradeCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.TradeCount.Width = 66
        '
        'ShortRate
        '
        Me.ShortRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.ShortRate.DataPropertyName = "ShortRate"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle14.Format = "0.##############"
        Me.ShortRate.DefaultCellStyle = DataGridViewCellStyle14
        Me.ShortRate.HeaderText = "短期金利"
        Me.ShortRate.Name = "ShortRate"
        Me.ShortRate.ReadOnly = True
        Me.ShortRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ShortRate.Width = 75
        '
        'SwapRate
        '
        Me.SwapRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.SwapRate.DataPropertyName = "SwapRate"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle15.Format = "0.##############"
        DataGridViewCellStyle15.NullValue = Nothing
        Me.SwapRate.DefaultCellStyle = DataGridViewCellStyle15
        Me.SwapRate.HeaderText = "スワップ金利"
        Me.SwapRate.Name = "SwapRate"
        Me.SwapRate.ReadOnly = True
        Me.SwapRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.SwapRate.Width = 75
        '
        'VolatilityAdjust
        '
        Me.VolatilityAdjust.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.VolatilityAdjust.DataPropertyName = "VolatilityAdjust"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle16.Format = "0.##############"
        Me.VolatilityAdjust.DefaultCellStyle = DataGridViewCellStyle16
        Me.VolatilityAdjust.HeaderText = "ボラティリティレシオ"
        Me.VolatilityAdjust.Name = "VolatilityAdjust"
        Me.VolatilityAdjust.ReadOnly = True
        Me.VolatilityAdjust.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.VolatilityAdjust.Width = 75
        '
        'Volatility
        '
        Me.Volatility.DataPropertyName = "Volatility"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle17.Format = "0.00000000000000"
        Me.Volatility.DefaultCellStyle = DataGridViewCellStyle17
        Me.Volatility.HeaderText = "ボラティリティ"
        Me.Volatility.Name = "Volatility"
        Me.Volatility.ReadOnly = True
        Me.Volatility.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'gridDetail
        '
        Me.gridDetail.AllowUserToAddRows = False
        Me.gridDetail.AllowUserToDeleteRows = False
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle19.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.gridDetail.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle19
        Me.gridDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridDetail.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DetailProductCode, Me.DetailComCode, Me.DetailComName, Me.DetailOpType, Me.DetailOptionTime, Me.DetailExercTime, Me.DetailZanzon, Me.DetailPayoutRate, Me.DetailRate, Me.DetailRateArrowCount, Me.DetailPAndL, Me.DetailPremium, Me.DetailDelta, Me.DetailGammaU, Me.DetailGammaD, Me.DetailVega, Me.DetailTheta, Me.DetailRho, Me.DetailCount})
        Me.gridDetail.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gridDetail.Location = New System.Drawing.Point(0, 0)
        Me.gridDetail.MultiSelect = False
        Me.gridDetail.Name = "gridDetail"
        Me.gridDetail.ReadOnly = True
        DataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle38.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.gridDetail.RowHeadersDefaultCellStyle = DataGridViewCellStyle38
        Me.gridDetail.RowHeadersVisible = False
        Me.gridDetail.RowTemplate.Height = 21
        Me.gridDetail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.gridDetail.Size = New System.Drawing.Size(984, 296)
        Me.gridDetail.TabIndex = 0
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'DetailProductCode
        '
        Me.DetailProductCode.DataPropertyName = "DetailProductCode"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DetailProductCode.DefaultCellStyle = DataGridViewCellStyle20
        Me.DetailProductCode.HeaderText = "銘柄コード"
        Me.DetailProductCode.Name = "DetailProductCode"
        Me.DetailProductCode.ReadOnly = True
        Me.DetailProductCode.Width = 111
        '
        'DetailComCode
        '
        Me.DetailComCode.DataPropertyName = "DetailComCode"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DetailComCode.DefaultCellStyle = DataGridViewCellStyle21
        Me.DetailComCode.HeaderText = "通貨ペア(Code)"
        Me.DetailComCode.Name = "DetailComCode"
        Me.DetailComCode.ReadOnly = True
        Me.DetailComCode.Visible = False
        '
        'DetailComName
        '
        Me.DetailComName.DataPropertyName = "DetailComName"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DetailComName.DefaultCellStyle = DataGridViewCellStyle22
        Me.DetailComName.HeaderText = "通貨ペア"
        Me.DetailComName.Name = "DetailComName"
        Me.DetailComName.ReadOnly = True
        Me.DetailComName.Width = 73
        '
        'DetailOpType
        '
        Me.DetailOpType.DataPropertyName = "DetailOpType"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DetailOpType.DefaultCellStyle = DataGridViewCellStyle23
        Me.DetailOpType.HeaderText = "オプション種別"
        Me.DetailOpType.Name = "DetailOpType"
        Me.DetailOpType.ReadOnly = True
        '
        'DetailOptionTime
        '
        Me.DetailOptionTime.DataPropertyName = "DetailOptionTime"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle24.Format = "####分"
        Me.DetailOptionTime.DefaultCellStyle = DataGridViewCellStyle24
        Me.DetailOptionTime.HeaderText = "オプション期間"
        Me.DetailOptionTime.Name = "DetailOptionTime"
        Me.DetailOptionTime.ReadOnly = True
        '
        'DetailExercTime
        '
        Me.DetailExercTime.DataPropertyName = "DetailExercTime"
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DetailExercTime.DefaultCellStyle = DataGridViewCellStyle25
        Me.DetailExercTime.HeaderText = "行使期日"
        Me.DetailExercTime.Name = "DetailExercTime"
        Me.DetailExercTime.ReadOnly = True
        Me.DetailExercTime.Width = 96
        '
        'DetailZanzon
        '
        Me.DetailZanzon.DataPropertyName = "DetailZanzon"
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DetailZanzon.DefaultCellStyle = DataGridViewCellStyle26
        Me.DetailZanzon.HeaderText = "残存期間"
        Me.DetailZanzon.Name = "DetailZanzon"
        Me.DetailZanzon.ReadOnly = True
        Me.DetailZanzon.Width = 98
        '
        'DetailPayoutRate
        '
        Me.DetailPayoutRate.DataPropertyName = "DetailPayoutRate"
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle27.Format = "######0.0000####"
        Me.DetailPayoutRate.DefaultCellStyle = DataGridViewCellStyle27
        Me.DetailPayoutRate.HeaderText = "ペイアウト率"
        Me.DetailPayoutRate.Name = "DetailPayoutRate"
        Me.DetailPayoutRate.ReadOnly = True
        Me.DetailPayoutRate.Width = 87
        '
        'DetailRate
        '
        Me.DetailRate.DataPropertyName = "DetailRate"
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle28.Format = "######0.000#####"
        DataGridViewCellStyle28.Padding = New System.Windows.Forms.Padding(0, 0, 18, 0)
        Me.DetailRate.DefaultCellStyle = DataGridViewCellStyle28
        Me.DetailRate.HeaderText = "レート"
        Me.DetailRate.Name = "DetailRate"
        Me.DetailRate.ReadOnly = True
        Me.DetailRate.Width = 79
        '
        'DetailRateArrowCount
        '
        Me.DetailRateArrowCount.DataPropertyName = "DetailRateArrowCount"
        Me.DetailRateArrowCount.HeaderText = "レート矢印カウント"
        Me.DetailRateArrowCount.Name = "DetailRateArrowCount"
        Me.DetailRateArrowCount.ReadOnly = True
        Me.DetailRateArrowCount.Visible = False
        '
        'DetailPAndL
        '
        Me.DetailPAndL.DataPropertyName = "DetailPAndL"
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle29.Format = "#,###,###,##0"
        Me.DetailPAndL.DefaultCellStyle = DataGridViewCellStyle29
        Me.DetailPAndL.HeaderText = "損益"
        Me.DetailPAndL.Name = "DetailPAndL"
        Me.DetailPAndL.ReadOnly = True
        Me.DetailPAndL.Width = 88
        '
        'DetailPremium
        '
        Me.DetailPremium.DataPropertyName = "DetailPremium"
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle30.Format = "#,###,###,##0.0000"
        Me.DetailPremium.DefaultCellStyle = DataGridViewCellStyle30
        Me.DetailPremium.HeaderText = "Premium"
        Me.DetailPremium.Name = "DetailPremium"
        Me.DetailPremium.ReadOnly = True
        Me.DetailPremium.Width = 88
        '
        'DetailDelta
        '
        Me.DetailDelta.DataPropertyName = "DetailDelta"
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle31.Format = "#,###,###,##0.0000"
        Me.DetailDelta.DefaultCellStyle = DataGridViewCellStyle31
        Me.DetailDelta.HeaderText = "Delta"
        Me.DetailDelta.Name = "DetailDelta"
        Me.DetailDelta.ReadOnly = True
        Me.DetailDelta.Width = 88
        '
        'DetailGammaU
        '
        Me.DetailGammaU.DataPropertyName = "DetailGammaU"
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle32.Format = "#,###,###,##0.0000"
        Me.DetailGammaU.DefaultCellStyle = DataGridViewCellStyle32
        Me.DetailGammaU.HeaderText = "Gamma(U)"
        Me.DetailGammaU.Name = "DetailGammaU"
        Me.DetailGammaU.ReadOnly = True
        Me.DetailGammaU.Width = 88
        '
        'DetailGammaD
        '
        Me.DetailGammaD.DataPropertyName = "DetailGammaD"
        DataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle33.Format = "#,###,###,##0.0000"
        Me.DetailGammaD.DefaultCellStyle = DataGridViewCellStyle33
        Me.DetailGammaD.HeaderText = "Gamma(D)"
        Me.DetailGammaD.Name = "DetailGammaD"
        Me.DetailGammaD.ReadOnly = True
        Me.DetailGammaD.Width = 88
        '
        'DetailVega
        '
        Me.DetailVega.DataPropertyName = "DetailVega"
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle34.Format = "#,###,###,##0.0000"
        Me.DetailVega.DefaultCellStyle = DataGridViewCellStyle34
        Me.DetailVega.HeaderText = "Vega"
        Me.DetailVega.Name = "DetailVega"
        Me.DetailVega.ReadOnly = True
        Me.DetailVega.Width = 88
        '
        'DetailTheta
        '
        Me.DetailTheta.DataPropertyName = "DetailTheta"
        DataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle35.Format = "#,###,###,##0.0000"
        Me.DetailTheta.DefaultCellStyle = DataGridViewCellStyle35
        Me.DetailTheta.HeaderText = "Theta"
        Me.DetailTheta.Name = "DetailTheta"
        Me.DetailTheta.ReadOnly = True
        Me.DetailTheta.Width = 88
        '
        'DetailRho
        '
        Me.DetailRho.DataPropertyName = "DetailRho"
        DataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle36.Format = "#,###,###,##0.0000"
        Me.DetailRho.DefaultCellStyle = DataGridViewCellStyle36
        Me.DetailRho.HeaderText = "Rho"
        Me.DetailRho.Name = "DetailRho"
        Me.DetailRho.ReadOnly = True
        Me.DetailRho.Width = 88
        '
        'DetailCount
        '
        Me.DetailCount.DataPropertyName = "DetailCount"
        DataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle37.Format = "N0"
        DataGridViewCellStyle37.NullValue = Nothing
        Me.DetailCount.DefaultCellStyle = DataGridViewCellStyle37
        Me.DetailCount.HeaderText = "件数"
        Me.DetailCount.Name = "DetailCount"
        Me.DetailCount.ReadOnly = True
        Me.DetailCount.Width = 66
        '
        'RiskMonitor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 462)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "RiskMonitor"
        Me.Text = "リスク"
        Me.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.gridSum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gridDetail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents gridSum As System.Windows.Forms.DataGridView
    Friend WithEvents gridDetail As System.Windows.Forms.DataGridView
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ComCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RateArrowCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PAndL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Premium As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Delta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GammaU As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GammaD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Vega As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Theta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rho As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ShortRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SwapRate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents VolatilityAdjust As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Volatility As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cbCurCode As System.Windows.Forms.ComboBox
    Friend WithEvents DetailProductCode As DataGridViewTextBoxColumn
    Friend WithEvents DetailComCode As DataGridViewTextBoxColumn
    Friend WithEvents DetailComName As DataGridViewTextBoxColumn
    Friend WithEvents DetailOpType As DataGridViewTextBoxColumn
    Friend WithEvents DetailOptionTime As DataGridViewTextBoxColumn
    Friend WithEvents DetailExercTime As DataGridViewTextBoxColumn
    Friend WithEvents DetailZanzon As DataGridViewTextBoxColumn
    Friend WithEvents DetailPayoutRate As DataGridViewTextBoxColumn
    Friend WithEvents DetailRate As DataGridViewTextBoxColumn
    Friend WithEvents DetailRateArrowCount As DataGridViewTextBoxColumn
    Friend WithEvents DetailPAndL As DataGridViewTextBoxColumn
    Friend WithEvents DetailPremium As DataGridViewTextBoxColumn
    Friend WithEvents DetailDelta As DataGridViewTextBoxColumn
    Friend WithEvents DetailGammaU As DataGridViewTextBoxColumn
    Friend WithEvents DetailGammaD As DataGridViewTextBoxColumn
    Friend WithEvents DetailVega As DataGridViewTextBoxColumn
    Friend WithEvents DetailTheta As DataGridViewTextBoxColumn
    Friend WithEvents DetailRho As DataGridViewTextBoxColumn
    Friend WithEvents DetailCount As DataGridViewTextBoxColumn
End Class
