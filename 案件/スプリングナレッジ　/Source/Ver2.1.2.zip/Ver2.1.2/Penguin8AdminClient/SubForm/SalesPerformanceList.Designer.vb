﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SalesPerformanceList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCurCode = New System.Windows.Forms.ComboBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountCountEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NewAccountCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeAccountCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalPAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashInCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashInMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashOutCount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashOutMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbCurCode)
        Me.Panel1.Controls.Add(Me.btnPrint)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(982, 44)
        Me.Panel1.TabIndex = 6
        '
        'cbCurCode
        '
        Me.cbCurCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCurCode.FormattingEnabled = True
        Me.cbCurCode.Location = New System.Drawing.Point(139, 14)
        Me.cbCurCode.Name = "cbCurCode"
        Me.cbCurCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCurCode.TabIndex = 7
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(726, 10)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(89, 29)
        Me.btnPrint.TabIndex = 6
        Me.btnPrint.Text = "印刷"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(637, 10)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 5
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 14)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(548, 10)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(412, 15)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(114, 19)
        Me.dtpToDateTime.TabIndex = 3
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(266, 15)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(117, 19)
        Me.dtpFromDateTime.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(389, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "～"
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SysDate, Me.AccountCount, Me.AccountCountEnabled, Me.NewAccountCount, Me.TradeAccountCount, Me.TradeCount, Me.CurName, Me.TradeAmount, Me.TotalMoney, Me.TotalPAndL, Me.CashInCount, Me.CashInMoney, Me.CashOutCount, Me.CashOutMoney})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 44)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(982, 448)
        Me.grid.TabIndex = 7
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(345, 215)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(225, 63)
        Me.lblNoData.TabIndex = 19
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.Format = "yyyy/MM/dd"
        DataGridViewCellStyle2.NullValue = "合計"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle2
        Me.SysDate.HeaderText = "取引日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.SysDate.Width = 74
        '
        'AccountCount
        '
        Me.AccountCount.DataPropertyName = "AccountCount"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.Format = "#,###,###,##0"
        Me.AccountCount.DefaultCellStyle = DataGridViewCellStyle3
        Me.AccountCount.HeaderText = "登録口座数"
        Me.AccountCount.Name = "AccountCount"
        Me.AccountCount.ReadOnly = True
        Me.AccountCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.AccountCount.Width = 66
        '
        'AccountCountEnabled
        '
        Me.AccountCountEnabled.DataPropertyName = "AccountCountEnabled"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "#,###,###,##0"
        Me.AccountCountEnabled.DefaultCellStyle = DataGridViewCellStyle4
        Me.AccountCountEnabled.HeaderText = "有効口座数"
        Me.AccountCountEnabled.Name = "AccountCountEnabled"
        Me.AccountCountEnabled.ReadOnly = True
        Me.AccountCountEnabled.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.AccountCountEnabled.Width = 66
        '
        'NewAccountCount
        '
        Me.NewAccountCount.DataPropertyName = "NewAccountCount"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle5.Format = "#,###,###,##0"
        Me.NewAccountCount.DefaultCellStyle = DataGridViewCellStyle5
        Me.NewAccountCount.HeaderText = "新規口座数"
        Me.NewAccountCount.Name = "NewAccountCount"
        Me.NewAccountCount.ReadOnly = True
        Me.NewAccountCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.NewAccountCount.Width = 66
        '
        'TradeAccountCount
        '
        Me.TradeAccountCount.DataPropertyName = "TradeAccountCount"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle6.Format = "#,###,###,##0"
        Me.TradeAccountCount.DefaultCellStyle = DataGridViewCellStyle6
        Me.TradeAccountCount.HeaderText = "取引口座数"
        Me.TradeAccountCount.Name = "TradeAccountCount"
        Me.TradeAccountCount.ReadOnly = True
        Me.TradeAccountCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.TradeAccountCount.Width = 66
        '
        'TradeCount
        '
        Me.TradeCount.DataPropertyName = "TradeCount"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle7.Format = "#,###,###,##0"
        Me.TradeCount.DefaultCellStyle = DataGridViewCellStyle7
        Me.TradeCount.HeaderText = "取引件数"
        Me.TradeCount.Name = "TradeCount"
        Me.TradeCount.ReadOnly = True
        Me.TradeCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.TradeCount.Width = 66
        '
        'CurName
        '
        Me.CurName.DataPropertyName = "CurName"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CurName.DefaultCellStyle = DataGridViewCellStyle8
        Me.CurName.HeaderText = "通貨種別"
        Me.CurName.Name = "CurName"
        Me.CurName.ReadOnly = True
        '
        'TradeAmount
        '
        Me.TradeAmount.DataPropertyName = "TradeAmount"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "###,###,###,###,##0.####"
        Me.TradeAmount.DefaultCellStyle = DataGridViewCellStyle9
        Me.TradeAmount.HeaderText = "取引金額"
        Me.TradeAmount.Name = "TradeAmount"
        Me.TradeAmount.ReadOnly = True
        Me.TradeAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.TradeAmount.Width = 84
        '
        'TotalMoney
        '
        Me.TotalMoney.DataPropertyName = "TotalMoney"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "###,###,###,###,##0.####"
        Me.TotalMoney.DefaultCellStyle = DataGridViewCellStyle10
        Me.TotalMoney.HeaderText = "残高合計"
        Me.TotalMoney.Name = "TotalMoney"
        Me.TotalMoney.ReadOnly = True
        Me.TotalMoney.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.TotalMoney.Width = 90
        '
        'TotalPAndL
        '
        Me.TotalPAndL.DataPropertyName = "TotalPAndL"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle11.Format = "###,###,###,###,##0.####"
        Me.TotalPAndL.DefaultCellStyle = DataGridViewCellStyle11
        Me.TotalPAndL.HeaderText = "Net損益"
        Me.TotalPAndL.Name = "TotalPAndL"
        Me.TotalPAndL.ReadOnly = True
        Me.TotalPAndL.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.TotalPAndL.Width = 84
        '
        'CashInCount
        '
        Me.CashInCount.DataPropertyName = "CashInCount"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle12.Format = "#,###,###,##0"
        Me.CashInCount.DefaultCellStyle = DataGridViewCellStyle12
        Me.CashInCount.HeaderText = "入金件数"
        Me.CashInCount.Name = "CashInCount"
        Me.CashInCount.ReadOnly = True
        Me.CashInCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.CashInCount.Width = 66
        '
        'CashInMoney
        '
        Me.CashInMoney.DataPropertyName = "CashInMoney"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle13.Format = "###,###,###,###,##0.####"
        Me.CashInMoney.DefaultCellStyle = DataGridViewCellStyle13
        Me.CashInMoney.HeaderText = "入金額合計"
        Me.CashInMoney.Name = "CashInMoney"
        Me.CashInMoney.ReadOnly = True
        Me.CashInMoney.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.CashInMoney.Width = 84
        '
        'CashOutCount
        '
        Me.CashOutCount.DataPropertyName = "CashOutCount"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle14.Format = "#,###,###,##0"
        Me.CashOutCount.DefaultCellStyle = DataGridViewCellStyle14
        Me.CashOutCount.HeaderText = "出金件数"
        Me.CashOutCount.Name = "CashOutCount"
        Me.CashOutCount.ReadOnly = True
        Me.CashOutCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.CashOutCount.Width = 66
        '
        'CashOutMoney
        '
        Me.CashOutMoney.DataPropertyName = "CashOutMoney"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle15.Format = "###,###,###,###,##0.####"
        Me.CashOutMoney.DefaultCellStyle = DataGridViewCellStyle15
        Me.CashOutMoney.HeaderText = "出金額合計"
        Me.CashOutMoney.Name = "CashOutMoney"
        Me.CashOutMoney.ReadOnly = True
        Me.CashOutMoney.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.CashOutMoney.Width = 84
        '
        'SalesPerformanceList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(982, 492)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "SalesPerformanceList"
        Me.Text = "営業実績表"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
	Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents cbCurCode As System.Windows.Forms.ComboBox
    Friend WithEvents SysDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountCountEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NewAccountCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeAccountCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CurName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TradeAmount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalMoney As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalPAndL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashInCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashInMoney As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashOutCount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashOutMoney As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
