﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateChartForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.dtpCloseTime = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbCloseTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.lblRateCode = New System.Windows.Forms.Label()
        Me.tbCloseRate = New System.Windows.Forms.TextBox()
        Me.tbLowRate = New System.Windows.Forms.TextBox()
        Me.tbHighRate = New System.Windows.Forms.TextBox()
        Me.tbOpenRate = New System.Windows.Forms.TextBox()
        Me.dtpChartTime = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbChartTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.cbChartType = New System.Windows.Forms.ComboBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.lblRateChartCode = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(282, 258)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 56
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(154, 258)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 55
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'dtpCloseTime
        '
        Me.dtpCloseTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpCloseTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpCloseTime.Location = New System.Drawing.Point(354, 70)
        Me.dtpCloseTime.Name = "dtpCloseTime"
        Me.dtpCloseTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpCloseTime.TabIndex = 52
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(483, 98)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 12)
        Me.Label14.TabIndex = 54
        Me.Label14.Text = "ミリ秒"
        '
        'tbCloseTimeMilliseconds
        '
        Me.tbCloseTimeMilliseconds.Location = New System.Drawing.Point(444, 95)
        Me.tbCloseTimeMilliseconds.Name = "tbCloseTimeMilliseconds"
        Me.tbCloseTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbCloseTimeMilliseconds.TabIndex = 53
        Me.tbCloseTimeMilliseconds.Text = "999"
        Me.tbCloseTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblRateCode
        '
        Me.lblRateCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRateCode.Location = New System.Drawing.Point(354, 31)
        Me.lblRateCode.Name = "lblRateCode"
        Me.lblRateCode.Size = New System.Drawing.Size(160, 23)
        Me.lblRateCode.TabIndex = 51
        Me.lblRateCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tbCloseRate
        '
        Me.tbCloseRate.Location = New System.Drawing.Point(354, 216)
        Me.tbCloseRate.Name = "tbCloseRate"
        Me.tbCloseRate.Size = New System.Drawing.Size(160, 19)
        Me.tbCloseRate.TabIndex = 50
        Me.tbCloseRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbLowRate
        '
        Me.tbLowRate.Location = New System.Drawing.Point(354, 184)
        Me.tbLowRate.Name = "tbLowRate"
        Me.tbLowRate.Size = New System.Drawing.Size(160, 19)
        Me.tbLowRate.TabIndex = 49
        Me.tbLowRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbHighRate
        '
        Me.tbHighRate.Location = New System.Drawing.Point(354, 152)
        Me.tbHighRate.Name = "tbHighRate"
        Me.tbHighRate.Size = New System.Drawing.Size(160, 19)
        Me.tbHighRate.TabIndex = 48
        Me.tbHighRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbOpenRate
        '
        Me.tbOpenRate.Location = New System.Drawing.Point(354, 120)
        Me.tbOpenRate.Name = "tbOpenRate"
        Me.tbOpenRate.Size = New System.Drawing.Size(160, 19)
        Me.tbOpenRate.TabIndex = 47
        Me.tbOpenRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpChartTime
        '
        Me.dtpChartTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpChartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpChartTime.Location = New System.Drawing.Point(92, 187)
        Me.dtpChartTime.Name = "dtpChartTime"
        Me.dtpChartTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpChartTime.TabIndex = 44
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(221, 215)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(31, 12)
        Me.Label12.TabIndex = 46
        Me.Label12.Text = "ミリ秒"
        '
        'tbChartTimeMilliseconds
        '
        Me.tbChartTimeMilliseconds.Location = New System.Drawing.Point(182, 212)
        Me.tbChartTimeMilliseconds.Name = "tbChartTimeMilliseconds"
        Me.tbChartTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbChartTimeMilliseconds.TabIndex = 45
        Me.tbChartTimeMilliseconds.Text = "999"
        Me.tbChartTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbChartType
        '
        Me.cbChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbChartType.FormattingEnabled = True
        Me.cbChartType.Location = New System.Drawing.Point(92, 150)
        Me.cbChartType.Name = "cbChartType"
        Me.cbChartType.Size = New System.Drawing.Size(160, 20)
        Me.cbChartType.TabIndex = 43
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(92, 111)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(160, 20)
        Me.cbComCode.TabIndex = 42
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(92, 72)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(160, 20)
        Me.cbEnabled.TabIndex = 41
        '
        'lblRateChartCode
        '
        Me.lblRateChartCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRateChartCode.Location = New System.Drawing.Point(92, 31)
        Me.lblRateChartCode.Name = "lblRateChartCode"
        Me.lblRateChartCode.Size = New System.Drawing.Size(160, 23)
        Me.lblRateChartCode.TabIndex = 40
        Me.lblRateChartCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(280, 75)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 12)
        Me.Label11.TabIndex = 39
        Me.Label11.Text = "レート日時"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(280, 36)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 12)
        Me.Label10.TabIndex = 38
        Me.Label10.Text = "レートSeq"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(280, 219)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 12)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Close"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(280, 187)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(25, 12)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "Low"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(280, 155)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 12)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "High"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(280, 123)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 12)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "Open"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(18, 192)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 12)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "チャート日時"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 153)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 12)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "チャート種別"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 12)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "通貨ペア"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 12)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "有効フラグ"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 12)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "チャートSeq"
        '
        'RateChartForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(532, 318)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.dtpCloseTime)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.tbCloseTimeMilliseconds)
        Me.Controls.Add(Me.lblRateCode)
        Me.Controls.Add(Me.tbCloseRate)
        Me.Controls.Add(Me.tbLowRate)
        Me.Controls.Add(Me.tbHighRate)
        Me.Controls.Add(Me.tbOpenRate)
        Me.Controls.Add(Me.dtpChartTime)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.tbChartTimeMilliseconds)
        Me.Controls.Add(Me.cbChartType)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.lblRateChartCode)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "RateChartForm"
        Me.Text = "レートチャート編集"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCancel As Button
    Friend WithEvents btnOK As Button
    Friend WithEvents dtpCloseTime As DateTimePicker
    Friend WithEvents Label14 As Label
    Friend WithEvents tbCloseTimeMilliseconds As TextBox
    Friend WithEvents lblRateCode As Label
    Friend WithEvents tbCloseRate As TextBox
    Friend WithEvents tbLowRate As TextBox
    Friend WithEvents tbHighRate As TextBox
    Friend WithEvents tbOpenRate As TextBox
    Friend WithEvents dtpChartTime As DateTimePicker
    Friend WithEvents Label12 As Label
    Friend WithEvents tbChartTimeMilliseconds As TextBox
    Friend WithEvents cbChartType As ComboBox
    Friend WithEvents cbComCode As ComboBox
    Friend WithEvents cbEnabled As ComboBox
    Friend WithEvents lblRateChartCode As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
