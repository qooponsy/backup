﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateChartHistList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnSarchAdd = New System.Windows.Forms.Button()
        Me.BtnCSV = New System.Windows.Forms.Button()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbChartType = New System.Windows.Forms.ComboBox()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.RateChartSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ChartType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateChartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpenRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HighRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LowRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CloseTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmGrid.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSearchAdd.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'btnSarchAdd
        '
        Me.btnSarchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSarchAdd.Name = "btnSarchAdd"
        Me.btnSarchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSarchAdd.TabIndex = 10
        Me.btnSarchAdd.Text = "さらに読み込む"
        Me.btnSarchAdd.UseVisualStyleBackColor = True
        '
        'BtnCSV
        '
        Me.BtnCSV.Location = New System.Drawing.Point(569, 22)
        Me.BtnCSV.Name = "BtnCSV"
        Me.BtnCSV.Size = New System.Drawing.Size(89, 29)
        Me.BtnCSV.TabIndex = 8
        Me.BtnCSV.Text = "CSV"
        Me.BtnCSV.UseVisualStyleBackColor = True
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(480, 22)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 7
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(391, 22)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 6
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 32)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 5
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 32)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "～"
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(281, 8)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 2
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(12, 6)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 0
        '
        'cbChartType
        '
        Me.cbChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbChartType.FormattingEnabled = True
        Me.cbChartType.Location = New System.Drawing.Point(148, 6)
        Me.cbChartType.Name = "cbChartType"
        Me.cbChartType.Size = New System.Drawing.Size(121, 20)
        Me.cbChartType.TabIndex = 1
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(278, 204)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(226, 63)
        Me.lblNoData.TabIndex = 31
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RateChartSeq, Me.gEnabled, Me.ComName, Me.ChartType, Me.RateChartTime, Me.OpenRate, Me.HighRate, Me.LowRate, Me.CloseRate, Me.RateSeq, Me.CloseTime})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 58)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle24.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle24
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(783, 380)
        Me.grid.TabIndex = 29
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSarchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 438)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(783, 32)
        Me.pnlSearchAdd.TabIndex = 30
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCSV)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Controls.Add(Me.cbChartType)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(783, 58)
        Me.Panel1.TabIndex = 28
        '
        'RateChartSeq
        '
        Me.RateChartSeq.DataPropertyName = "RateChartSeq"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.RateChartSeq.DefaultCellStyle = DataGridViewCellStyle14
        Me.RateChartSeq.HeaderText = "チャートSeq"
        Me.RateChartSeq.Name = "RateChartSeq"
        Me.RateChartSeq.ReadOnly = True
        Me.RateChartSeq.Width = 110
        '
        'gEnabled
        '
        Me.gEnabled.DataPropertyName = "gEnabled"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.gEnabled.DefaultCellStyle = DataGridViewCellStyle15
        Me.gEnabled.HeaderText = "有効フラグ"
        Me.gEnabled.Name = "gEnabled"
        Me.gEnabled.ReadOnly = True
        Me.gEnabled.Width = 79
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle16
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 73
        '
        'ChartType
        '
        Me.ChartType.DataPropertyName = "ChartType"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ChartType.DefaultCellStyle = DataGridViewCellStyle17
        Me.ChartType.HeaderText = "チャート種別"
        Me.ChartType.Name = "ChartType"
        Me.ChartType.ReadOnly = True
        Me.ChartType.Width = 65
        '
        'RateChartTime
        '
        Me.RateChartTime.DataPropertyName = "RateChartTime"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle18.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle18.NullValue = Nothing
        Me.RateChartTime.DefaultCellStyle = DataGridViewCellStyle18
        Me.RateChartTime.HeaderText = "チャート日時"
        Me.RateChartTime.Name = "RateChartTime"
        Me.RateChartTime.ReadOnly = True
        Me.RateChartTime.Width = 110
        '
        'OpenRate
        '
        Me.OpenRate.DataPropertyName = "OpenRate"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle19.Format = "######0.000#####"
        DataGridViewCellStyle19.NullValue = Nothing
        Me.OpenRate.DefaultCellStyle = DataGridViewCellStyle19
        Me.OpenRate.HeaderText = "Open"
        Me.OpenRate.Name = "OpenRate"
        Me.OpenRate.ReadOnly = True
        Me.OpenRate.Width = 55
        '
        'HighRate
        '
        Me.HighRate.DataPropertyName = "HighRate"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.HighRate.DefaultCellStyle = DataGridViewCellStyle20
        Me.HighRate.HeaderText = "High"
        Me.HighRate.Name = "HighRate"
        Me.HighRate.ReadOnly = True
        Me.HighRate.Width = 55
        '
        'LowRate
        '
        Me.LowRate.DataPropertyName = "LowRate"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.LowRate.DefaultCellStyle = DataGridViewCellStyle21
        Me.LowRate.HeaderText = "Low"
        Me.LowRate.Name = "LowRate"
        Me.LowRate.ReadOnly = True
        Me.LowRate.Width = 55
        '
        'CloseRate
        '
        Me.CloseRate.DataPropertyName = "CloseRate"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.CloseRate.DefaultCellStyle = DataGridViewCellStyle22
        Me.CloseRate.HeaderText = "Close"
        Me.CloseRate.Name = "CloseRate"
        Me.CloseRate.ReadOnly = True
        Me.CloseRate.Width = 55
        '
        'RateSeq
        '
        Me.RateSeq.DataPropertyName = "RateSeq"
        Me.RateSeq.HeaderText = "レートSeq"
        Me.RateSeq.Name = "RateSeq"
        Me.RateSeq.ReadOnly = True
        Me.RateSeq.Visible = False
        Me.RateSeq.Width = 110
        '
        'CloseTime
        '
        Me.CloseTime.DataPropertyName = "CloseTime"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle23.Format = "yyyy/MM/dd HH:mm:ss"
        Me.CloseTime.DefaultCellStyle = DataGridViewCellStyle23
        Me.CloseTime.HeaderText = "レート日時"
        Me.CloseTime.Name = "CloseTime"
        Me.CloseTime.ReadOnly = True
        Me.CloseTime.Width = 110
        '
        'RateChartHistList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(783, 470)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "RateChartHistList"
        Me.Text = "レートチャート一覧"
        Me.cmGrid.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSearchAdd.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents sfdCsvFile As SaveFileDialog
    Friend WithEvents cmGrid As ContextMenuStrip
    Friend WithEvents miEdit As ToolStripMenuItem
    Friend WithEvents btnSarchAdd As Button
    Friend WithEvents BtnCSV As Button
    Friend WithEvents btnRegist As Button
    Friend WithEvents btnSearch As Button
    Friend WithEvents dtpToDateTime As DateTimePicker
    Friend WithEvents dtpFromDateTime As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents chkEnabled As CheckBox
    Friend WithEvents cbComCode As ComboBox
    Friend WithEvents cbChartType As ComboBox
    Friend WithEvents lblNoData As Label
    Private WithEvents grid As DataGridView
    Friend WithEvents pnlSearchAdd As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents RateChartSeq As DataGridViewTextBoxColumn
    Friend WithEvents gEnabled As DataGridViewTextBoxColumn
    Friend WithEvents ComName As DataGridViewTextBoxColumn
    Friend WithEvents ChartType As DataGridViewTextBoxColumn
    Friend WithEvents RateChartTime As DataGridViewTextBoxColumn
    Friend WithEvents OpenRate As DataGridViewTextBoxColumn
    Friend WithEvents HighRate As DataGridViewTextBoxColumn
    Friend WithEvents LowRate As DataGridViewTextBoxColumn
    Friend WithEvents CloseRate As DataGridViewTextBoxColumn
    Friend WithEvents RateSeq As DataGridViewTextBoxColumn
    Friend WithEvents CloseTime As DataGridViewTextBoxColumn
End Class
