﻿Public Class OperationHistList

    Private WithEvents service As New OperationHistService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1

    Private Sub OperationHistList_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)

        cbDataType.Items.Clear()
        cbDataType.Items.Add("")
        cbDataType.Items.Add("システム設定")
        cbDataType.Items.Add("銘柄データ")
        cbDataType.Items.Add("銘柄設定")
        cbDataType.Items.Add("計算パラメータ")
        cbDataType.Items.Add("ログイン")
        cbDataType.Items.Add("ログアウト")
        cbDataType.Items.Add("パスワード変更")
        cbDataType.Items.Add("強制パスワード変更")
        cbDataType.Items.Add("ユーザー管理")
        cbDataType.Items.Add("委託者")
        cbDataType.SelectedIndex = 0

        'gridの表示文字
        grid.Columns(0).HeaderText = "日時"
        grid.Columns(1).HeaderText = "システム" & vbCrLf & "営業日"
        grid.Columns(2).HeaderText = "操作ユーザー"
        grid.Columns(3).HeaderText = "操作対象"
        grid.Columns(4).HeaderText = "操作種別"
        grid.Columns(5).HeaderText = "コード"
        grid.Columns(6).HeaderText = "ログ"

        '初期値の設定
        dtpFromDateTime.Value = SysSettingsService.GetStartDate()
        dtpToDateTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone)
        dtpToDateTime.Checked = False

        MainWindow.SubFormOperationHist = True
        LoadSettings()

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub OperationHistList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormOperationHist = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.OperationHistList_FormMaximized, _
            UserSettings.getInstance().DataSaved.OperationHistList_FormSize, _
            UserSettings.getInstance().DataSaved.OperationHistList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.OperationHistList_Columns)
        tbOperationUser.Text = UserSettings.getInstance().DataSaved.OperationHistList_UserName
        cbDataType.SelectedIndex = UserSettings.getInstance().DataSaved.OperationHistList_DataType
        tbCode.Text = UserSettings.getInstance().DataSaved.OperationHistList_Code
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.OperationHistList_FormMaximized, _
            UserSettings.getInstance().DataSaved.OperationHistList_FormSize, _
            UserSettings.getInstance().DataSaved.OperationHistList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.OperationHistList_Columns)
        UserSettings.getInstance().DataSaved.OperationHistList_UserName = tbOperationUser.Text
        UserSettings.getInstance().DataSaved.OperationHistList_DataType = cbDataType.SelectedIndex
        UserSettings.getInstance().DataSaved.OperationHistList_Code = tbCode.Text
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("LogTime", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("OperationUser", GetType(String))
        Table.Columns.Add("DataType", GetType(String))
        Table.Columns.Add("LogType", GetType(String))
        Table.Columns.Add("Code", GetType(String))
        Table.Columns.Add("LogText", GetType(String))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of OperationHistData))
        For Each item As OperationHistData In list
            Dim row As DataRow = Table.NewRow()
            row("LogTime") = item.LogTime
            row("SysDate") = item.SysDate
            row("OperationUser") = item.OperationUser
            row("DataType") = item.GetDataType()
            row("LogType") = item.GetLogType()
            row("Code") = item.Code
            row("LogText") = item.LogText
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click

        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select

    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        Dim DataType As String = ""
        Select Case cbDataType.SelectedIndex
            Case 1
                DataType = "01"
            Case 2
                DataType = "02"
            Case 3
                DataType = "03"
            Case 4
                DataType = "04"
            Case 5
                DataType = "05"
            Case 6
                DataType = "06"
            Case 7
                DataType = "07"
            Case 8
                DataType = "08"
            Case 9
                DataType = "09"
            Case 10
                DataType = "10"
            Case Else
                DataType = ""
        End Select
        Dim OperationUser As String = Me.tbOperationUser.Text
        Dim Code As String = Me.tbCode.Text
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")

        service.ReadList(OperationUser, DataType, FromDateTime, ToDateTime, Code, "", Start)

        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of OperationHistData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

End Class