﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RateFilterForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblComName = New System.Windows.Forms.Label()
        Me.tbRateFilterDiff = New System.Windows.Forms.TextBox()
        Me.tbRateFilterCountMax = New System.Windows.Forms.TextBox()
        Me.tbAnomalyRateDiff = New System.Windows.Forms.TextBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "通貨ペア"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 46)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(111, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "レートフィルター乖離値"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "レートフィルターカウント閾値"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "異常レート乖離値"
        '
        'lblComName
        '
        Me.lblComName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblComName.Location = New System.Drawing.Point(173, 16)
        Me.lblComName.Name = "lblComName"
        Me.lblComName.Size = New System.Drawing.Size(80, 19)
        Me.lblComName.TabIndex = 1
        Me.lblComName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tbRateFilterDiff
        '
        Me.tbRateFilterDiff.Location = New System.Drawing.Point(173, 43)
        Me.tbRateFilterDiff.Name = "tbRateFilterDiff"
        Me.tbRateFilterDiff.Size = New System.Drawing.Size(80, 19)
        Me.tbRateFilterDiff.TabIndex = 3
        Me.tbRateFilterDiff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbRateFilterCountMax
        '
        Me.tbRateFilterCountMax.Location = New System.Drawing.Point(173, 70)
        Me.tbRateFilterCountMax.Name = "tbRateFilterCountMax"
        Me.tbRateFilterCountMax.Size = New System.Drawing.Size(80, 19)
        Me.tbRateFilterCountMax.TabIndex = 5
        Me.tbRateFilterCountMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAnomalyRateDiff
        '
        Me.tbAnomalyRateDiff.Location = New System.Drawing.Point(173, 97)
        Me.tbAnomalyRateDiff.Name = "tbAnomalyRateDiff"
        Me.tbAnomalyRateDiff.Size = New System.Drawing.Size(80, 19)
        Me.tbAnomalyRateDiff.TabIndex = 7
        Me.tbAnomalyRateDiff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(43, 135)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 8
        Me.btnOK.Text = "登録"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(155, 135)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 9
        Me.btnCancel.Text = "戻る"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'RateFilterForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(294, 182)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.tbAnomalyRateDiff)
        Me.Controls.Add(Me.tbRateFilterCountMax)
        Me.Controls.Add(Me.tbRateFilterDiff)
        Me.Controls.Add(Me.lblComName)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "RateFilterForm"
        Me.Text = "レートフィルター設定登録"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblComName As System.Windows.Forms.Label
    Friend WithEvents tbRateFilterDiff As System.Windows.Forms.TextBox
    Friend WithEvents tbRateFilterCountMax As System.Windows.Forms.TextBox
    Friend WithEvents tbAnomalyRateDiff As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
End Class
