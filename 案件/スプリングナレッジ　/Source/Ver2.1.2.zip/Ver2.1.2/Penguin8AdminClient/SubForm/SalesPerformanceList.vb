﻿Imports System.Net
Imports System.Collections.Specialized

Public Class SalesPerformanceList

    Private WithEvents service As New SalesPerformanceService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private View As DataView

	Private ConditionString As String = ""			' 印刷用抽出条件文字列

	Private Sub SalesPerformanceList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

		lblNoData.Parent = grid
		lblNoData.BackColor = Color.Transparent
		lblNoData.Dock = DockStyle.Fill
		lblNoData.Visible = False

        TradeAmount.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        TotalMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        TotalPAndL.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        CashInMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        CashOutMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbCurCode.DisplayMember = "CurName"
        cbCurCode.ValueMember = "CurCode"
        cbCurCode.DataSource = CurrencyService.GetListWithAll()

		'初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        Dim SysDatePrev As DateTime = clsUtil.GetPrevWorkDay(SysDate)
        dtpFromDateTime.Value = New DateTime(SysDatePrev.Year, SysDatePrev.Month, SysDatePrev.Day)
        dtpToDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
		dtpToDateTime.Checked = False

		MainWindow.SubFormSalesPerformance = True
		LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

		initGrid()
		formModeStatus = FormMode.NORMAL
	End Sub

    Private Sub SalesPerformanceList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormSalesPerformance = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.SalesPerformanceList_FormMaximized, _
            UserSettings.getInstance().DataSaved.SalesPerformanceList_FormSize, _
            UserSettings.getInstance().DataSaved.SalesPerformanceList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.SalesPerformanceList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.SalesPerformanceList_CmpCode
        cbCurCode.SelectedValue = UserSettings.getInstance().DataSaved.SalesPerformanceList_CurCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.SalesPerformanceList_FormMaximized, _
            UserSettings.getInstance().DataSaved.SalesPerformanceList_FormSize, _
            UserSettings.getInstance().DataSaved.SalesPerformanceList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.SalesPerformanceList_Columns)
        UserSettings.getInstance().DataSaved.SalesPerformanceList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.SalesPerformanceList_CurCode = cbCurCode.SelectedValue
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        grid.Columns(1).HeaderText = "登録" & vbCrLf & "口座数"
        grid.Columns(2).HeaderText = "有効" & vbCrLf & "口座数"
        grid.Columns(3).HeaderText = "新規" & vbCrLf & "口座数"
        grid.Columns(4).HeaderText = "取引" & vbCrLf & "口座数"
        grid.Columns(5).HeaderText = "取引" & vbCrLf & "件数"
        grid.Columns(6).HeaderText = "通貨" & vbCrLf & "種別"
        grid.Columns(10).HeaderText = "入金" & vbCrLf & "件数"
        grid.Columns(11).HeaderText = "入金額" & vbCrLf & "合計"
        grid.Columns(12).HeaderText = "出金" & vbCrLf & "件数"
        grid.Columns(13).HeaderText = "出金額" & vbCrLf & "合計"

        Table = New DataTable
        Table.Columns.Add("RowType", GetType(Integer))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("AccountCount", GetType(Integer))
        Table.Columns.Add("AccountCountEnabled", GetType(Integer))
        Table.Columns.Add("NewAccountCount", GetType(Integer))
        Table.Columns.Add("TradeAccountCount", GetType(Integer))
        Table.Columns.Add("TradeCount", GetType(Integer))
        Table.Columns.Add("CurName", GetType(String))
        Table.Columns.Add("TradeAmount", GetType(Decimal))
        Table.Columns.Add("TotalMoney", GetType(Decimal))
        Table.Columns.Add("TotalPAndL", GetType(Decimal))
        Table.Columns.Add("CashInCount", GetType(Integer))
        Table.Columns.Add("CashInMoney", GetType(Decimal))
        Table.Columns.Add("CashOutCount", GetType(Integer))
        Table.Columns.Add("CashOutMoney", GetType(Decimal))

        View = New DataView(Table)
        View.ApplyDefaultSort = False
        grid.DataSource = View
        grid.Columns("SysDate").HeaderCell.SortGlyphDirection = SortOrder.Descending
        View.Sort = "RowType,SysDate desc"
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of SalesPerformanceData))
        Dim itemSum As New SalesPerformanceData
        Dim dicItemSum As New Dictionary(Of String, SalesPerformanceData)

        '合計用データ作成
        If cbCurCode.SelectedValue <> "" Then
            '指定されている通貨用合計データのみ作成
            dicItemSum.Add(cbCurCode.SelectedValue, New SalesPerformanceData)
        Else
            '各通貨毎の合計データ作成
            For Each item As CurrencyData In CurrencyService.GetList()
                dicItemSum.Add(item.CurCode, New SalesPerformanceData)
            Next
        End If

        'dgv表示と合計算出
        For Each item As SalesPerformanceData In list
            'dgv表示追加
            Dim row As DataRow = Table.NewRow()
            row("RowType") = 0
            row("SysDate") = item.SysDate
            row("AccountCount") = item.AccountCount
            row("AccountCountEnabled") = item.AccountCountEnabled
            row("NewAccountCount") = item.NewAccountCount
            row("TradeAccountCount") = item.TradeAccountCount
            row("TradeCount") = item.TradeCount
            row("CurName") = item.CurName
            row("TradeAmount") = item.TradeAmount
            row("TotalMoney") = item.TotalMoney
            row("TotalPAndL") = item.TotalPAndL
            row("CashInCount") = item.CashInCount
            row("CashInMoney") = item.CashInMoney
            row("CashOutCount") = item.CashOutCount
            row("CashOutMoney") = item.CashOutMoney
            Table.Rows.Add(row)

            '各通貨毎の合計用dicにデータ追加
            Dim TempDicItemSum As SalesPerformanceData = dicItemSum(item.CurCode)
            TempDicItemSum.AccountCount += item.AccountCount
            TempDicItemSum.AccountCountEnabled += item.AccountCountEnabled
            TempDicItemSum.NewAccountCount += item.NewAccountCount
            TempDicItemSum.TradeAccountCount += item.TradeAccountCount
            TempDicItemSum.TradeCount += item.TradeCount
            TempDicItemSum.TradeAmount += item.TradeAmount
            TempDicItemSum.TotalMoney += item.TotalMoney
            TempDicItemSum.TotalPAndL += item.TotalPAndL
            TempDicItemSum.CashInCount += item.CashInCount
            TempDicItemSum.CashInMoney += item.CashInMoney
            TempDicItemSum.CashOutCount += item.CashOutCount
            TempDicItemSum.CashOutMoney += item.CashOutMoney
        Next

        'dgvに合計行の表示
        For Each item As CurrencyData In CurrencyService.GetList()
            '通貨ペアの並び順で表示のため、GetListを利用

            If Not dicItemSum.ContainsKey(item.CurCode) Then
                '表示しない通貨の合計は処理しない
                Continue For
            End If

            Dim rowSum As DataRow = Table.NewRow()
            rowSum("RowType") = 1
            rowSum("SysDate") = DBNull.Value
            rowSum("AccountCount") = dicItemSum(item.CurCode).AccountCount
            rowSum("AccountCountEnabled") = dicItemSum(item.CurCode).AccountCountEnabled
            rowSum("NewAccountCount") = dicItemSum(item.CurCode).NewAccountCount
            rowSum("TradeAccountCount") = dicItemSum(item.CurCode).TradeAccountCount
            rowSum("TradeCount") = dicItemSum(item.CurCode).TradeCount
            rowSum("CurName") = item.CurName
            rowSum("TradeAmount") = dicItemSum(item.CurCode).TradeAmount
            rowSum("TotalMoney") = dicItemSum(item.CurCode).TotalMoney
            rowSum("TotalPAndL") = dicItemSum(item.CurCode).TotalPAndL
            rowSum("CashInCount") = dicItemSum(item.CurCode).CashInCount
            rowSum("CashInMoney") = dicItemSum(item.CurCode).CashInMoney
            rowSum("CashOutCount") = dicItemSum(item.CurCode).CashOutCount
            rowSum("CashOutMoney") = dicItemSum(item.CurCode).CashOutMoney
            Table.Rows.Add(rowSum)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                request()
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

	Private Sub request()
		'----------------------------------------------------------------------
		' 印刷用　抽出条件編集
		'----------------------------------------------------------------------
        ConditionString = ""
        If cbCmpCode.SelectedValue <> "" Then
            ConditionString = cbCmpCode.Text & " "
        End If
        If cbCurCode.SelectedValue <> "" Then
            ConditionString = ConditionString & cbCurCode.Text & " "
        End If
		If dtpFromDateTime.Checked = True Then
			ConditionString = ConditionString & dtpFromDateTime.Value.ToString("yyyy/MM/dd") & " ～ "
		End If
		If dtpToDateTime.Checked = True Then
			If dtpFromDateTime.Checked = False Then
				ConditionString = ConditionString & "～ "
			End If
			ConditionString = ConditionString & dtpToDateTime.Value.ToString("yyyy/MM/dd")
		End If
		ConditionString = ConditionString.Trim()

        service.ReadList(dtpFromDateTime.Checked, dtpFromDateTime.Value, dtpToDateTime.Checked, dtpToDateTime.Value, cbCmpCode.SelectedValue, cbCurCode.SelectedValue)
		formModeStatus = FormMode.READ
		btnSearch.Text = "キャンセル"
	End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of SalesPerformanceData)) Handles service.ReadSuccess
        Table.Rows.Clear()
        setGrid(list)
        requestEnd()
        lblNoData.Visible = (list.Count = 0)
    End Sub

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grid.CellPainting
        If e.RowIndex >= 0 Then
            If grid.Columns(e.ColumnIndex).Name = "TotalPAndL" Then
                If e.Value < 0 Then
                    If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                        e.Paint(e.CellBounds, e.PaintParts And Not DataGridViewPaintParts.ContentForeground)
                        TextRenderer.DrawText(e.Graphics, e.FormattedValue, e.CellStyle.Font, e.CellBounds, Color.Red, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub grid_ColumnHeaderMouseClick(sender As Object, e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.ColumnHeaderMouseClick
        Dim sort As String = ""
        Dim order As SortOrder = SortOrder.None
        If grid.Columns(e.ColumnIndex).HeaderCell.SortGlyphDirection = SortOrder.Ascending Then
            sort = grid.Columns(e.ColumnIndex).DataPropertyName + " desc"
            order = SortOrder.Descending
        Else
            sort = grid.Columns(e.ColumnIndex).DataPropertyName + " asc"
            order = SortOrder.Ascending
        End If
        If grid.Columns(e.ColumnIndex).DataPropertyName <> "SysDate" Then
            sort += ",SysDate desc"
        End If
        View.Sort = "RowType," + sort
        grid.Columns(e.ColumnIndex).HeaderCell.SortGlyphDirection = order
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "sales"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

	'--------------------------------------------------------------------------
	' 印刷 2012/06/28 H.S
	'--------------------------------------------------------------------------
	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		Dim PrtUtil As PrintUtil

		Try
			PrtUtil = New PrintUtil()
			PrtUtil.PrintReport(grid, PrintUtil.Reports.SalesPerformanceList, ConditionString)
		Catch ex As Exception
		End Try
	End Sub

End Class
