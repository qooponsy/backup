﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CashList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCurCode = New System.Windows.Forms.ComboBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbCashType = New System.Windows.Forms.ComboBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbDateType = New System.Windows.Forms.ComboBox()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.CashCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashEnabledName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExecTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CashTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Money = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbCurCode)
        Me.Panel1.Controls.Add(Me.btnPrint)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.tbCustCode)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.cbCashType)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cbDateType)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(849, 58)
        Me.Panel1.TabIndex = 11
        '
        'cbCurCode
        '
        Me.cbCurCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCurCode.FormattingEnabled = True
        Me.cbCurCode.Location = New System.Drawing.Point(266, 6)
        Me.cbCurCode.Name = "cbCurCode"
        Me.cbCurCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCurCode.TabIndex = 18
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(648, 26)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(89, 29)
        Me.btnPrint.TabIndex = 10
        Me.btnPrint.Text = "印刷"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(559, 26)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 9
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(467, 7)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(59, 19)
        Me.tbCustCode.TabIndex = 3
        Me.tbCustCode.Text = "1000050"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(393, 10)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "委託者コード"
        '
        'cbCashType
        '
        Me.cbCashType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCashType.FormattingEnabled = True
        Me.cbCashType.Location = New System.Drawing.Point(139, 6)
        Me.cbCashType.Name = "cbCashType"
        Me.cbCashType.Size = New System.Drawing.Size(121, 20)
        Me.cbCashType.TabIndex = 1
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 6)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(737, 26)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 11
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(470, 26)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 8
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(317, 32)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 7
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(139, 32)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(294, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "～"
        '
        'cbDateType
        '
        Me.cbDateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDateType.FormattingEnabled = True
        Me.cbDateType.Location = New System.Drawing.Point(12, 31)
        Me.cbDateType.Name = "cbDateType"
        Me.cbDateType.Size = New System.Drawing.Size(121, 20)
        Me.cbDateType.TabIndex = 4
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 460)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(849, 32)
        Me.pnlSearchAdd.TabIndex = 14
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 13
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CashCode, Me.CashEnabled, Me.CashEnabledName, Me.ExecTime, Me.SysDate, Me.CashType, Me.CashTypeName, Me.CurName, Me.Money, Me.TotalMoney, Me.CustCode})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 58)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(849, 402)
        Me.grid.TabIndex = 12
        '
        'CashCode
        '
        Me.CashCode.DataPropertyName = "CashCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CashCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.CashCode.HeaderText = "処理Seq"
        Me.CashCode.Name = "CashCode"
        Me.CashCode.ReadOnly = True
        Me.CashCode.Width = 108
        '
        'CashEnabled
        '
        Me.CashEnabled.DataPropertyName = "CashEnabled"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.NullValue = Nothing
        Me.CashEnabled.DefaultCellStyle = DataGridViewCellStyle3
        Me.CashEnabled.HeaderText = "有効フラグ(Code)"
        Me.CashEnabled.Name = "CashEnabled"
        Me.CashEnabled.ReadOnly = True
        Me.CashEnabled.Visible = False
        '
        'CashEnabledName
        '
        Me.CashEnabledName.DataPropertyName = "CashEnabledName"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CashEnabledName.DefaultCellStyle = DataGridViewCellStyle4
        Me.CashEnabledName.HeaderText = "有効フラグ"
        Me.CashEnabledName.Name = "CashEnabledName"
        Me.CashEnabledName.ReadOnly = True
        Me.CashEnabledName.Width = 79
        '
        'ExecTime
        '
        Me.ExecTime.DataPropertyName = "ExecTime"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle5.NullValue = Nothing
        Me.ExecTime.DefaultCellStyle = DataGridViewCellStyle5
        Me.ExecTime.HeaderText = "処理日時"
        Me.ExecTime.Name = "ExecTime"
        Me.ExecTime.ReadOnly = True
        Me.ExecTime.Width = 130
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle6
        Me.SysDate.HeaderText = "取引日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 66
        '
        'CashType
        '
        Me.CashType.DataPropertyName = "CashType"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CashType.DefaultCellStyle = DataGridViewCellStyle7
        Me.CashType.HeaderText = "取引種別(Code)"
        Me.CashType.Name = "CashType"
        Me.CashType.ReadOnly = True
        Me.CashType.Visible = False
        '
        'CashTypeName
        '
        Me.CashTypeName.DataPropertyName = "CashTypeName"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CashTypeName.DefaultCellStyle = DataGridViewCellStyle8
        Me.CashTypeName.FillWeight = 80.0!
        Me.CashTypeName.HeaderText = "取引種別"
        Me.CashTypeName.Name = "CashTypeName"
        Me.CashTypeName.ReadOnly = True
        Me.CashTypeName.Width = 110
        '
        'CurName
        '
        Me.CurName.DataPropertyName = "CurName"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CurName.DefaultCellStyle = DataGridViewCellStyle9
        Me.CurName.HeaderText = "通貨種別"
        Me.CurName.Name = "CurName"
        Me.CurName.ReadOnly = True
        '
        'Money
        '
        Me.Money.DataPropertyName = "Money"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle10.Format = "#,###,###,##0.####"
        Me.Money.DefaultCellStyle = DataGridViewCellStyle10
        Me.Money.HeaderText = "金額"
        Me.Money.Name = "Money"
        Me.Money.ReadOnly = True
        Me.Money.Width = 87
        '
        'TotalMoney
        '
        Me.TotalMoney.DataPropertyName = "TotalMoney"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle11.Format = "#,###,###,##0.###"
        Me.TotalMoney.DefaultCellStyle = DataGridViewCellStyle11
        Me.TotalMoney.HeaderText = "取引後残高"
        Me.TotalMoney.Name = "TotalMoney"
        Me.TotalMoney.ReadOnly = True
        Me.TotalMoney.Width = 90
        '
        'CustCode
        '
        Me.CustCode.DataPropertyName = "CustCode"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustCode.DefaultCellStyle = DataGridViewCellStyle12
        Me.CustCode.HeaderText = "委託者コード"
        Me.CustCode.Name = "CustCode"
        Me.CustCode.ReadOnly = True
        Me.CustCode.Width = 93
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(265, 215)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(223, 63)
        Me.lblNoData.TabIndex = 15
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CashList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(849, 492)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "CashList"
        Me.Text = "残高データ一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents tbCustCode As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cbCashType As System.Windows.Forms.ComboBox
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbDateType As System.Windows.Forms.ComboBox
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents cbCurCode As System.Windows.Forms.ComboBox
    Friend WithEvents CashCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashEnabledName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExecTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SysDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CashTypeName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CurName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Money As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TotalMoney As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustCode As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
