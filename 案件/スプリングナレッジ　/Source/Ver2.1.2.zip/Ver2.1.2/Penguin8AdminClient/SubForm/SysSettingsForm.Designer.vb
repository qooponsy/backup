﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SysSettingsForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnSetSysSettingsAdmin = New System.Windows.Forms.Button()
        Me.btnCancelChk = New System.Windows.Forms.Button()
        Me.btnSetSysSettingsAdminChk = New System.Windows.Forms.Button()
        Me.tbCashOutMoneyDayMax = New System.Windows.Forms.TextBox()
        Me.tbCashOutMoneyMax = New System.Windows.Forms.TextBox()
        Me.tbCashInMoneyDayMin = New System.Windows.Forms.TextBox()
        Me.tbCashInMoneyMin = New System.Windows.Forms.TextBox()
        Me.tbCustProductMoneyMax = New System.Windows.Forms.TextBox()
        Me.tbCustMoneyMax = New System.Windows.Forms.TextBox()
        Me.tbCustCountMax = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.tbProductMoneyMax = New System.Windows.Forms.TextBox()
        Me.tbTradeMoneyMax = New System.Windows.Forms.TextBox()
        Me.tbTradeMoneyMin = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbRateEnableTime = New System.Windows.Forms.TextBox()
        Me.tbCustMoneyDayMax = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.tbAlertDayPAndLCust = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbAlertDayPAndL = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(335, 245)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(127, 33)
        Me.btnCancel.TabIndex = 28
        Me.btnCancel.Text = "戻る"
        Me.btnCancel.UseVisualStyleBackColor = True
        Me.btnCancel.Visible = False
        '
        'btnSetSysSettingsAdmin
        '
        Me.btnSetSysSettingsAdmin.Location = New System.Drawing.Point(157, 244)
        Me.btnSetSysSettingsAdmin.Name = "btnSetSysSettingsAdmin"
        Me.btnSetSysSettingsAdmin.Size = New System.Drawing.Size(127, 34)
        Me.btnSetSysSettingsAdmin.TabIndex = 26
        Me.btnSetSysSettingsAdmin.Text = "登録"
        Me.btnSetSysSettingsAdmin.UseVisualStyleBackColor = True
        Me.btnSetSysSettingsAdmin.Visible = False
        '
        'btnCancelChk
        '
        Me.btnCancelChk.Location = New System.Drawing.Point(334, 244)
        Me.btnCancelChk.Name = "btnCancelChk"
        Me.btnCancelChk.Size = New System.Drawing.Size(127, 34)
        Me.btnCancelChk.TabIndex = 29
        Me.btnCancelChk.Text = "キャンセル"
        Me.btnCancelChk.UseVisualStyleBackColor = True
        '
        'btnSetSysSettingsAdminChk
        '
        Me.btnSetSysSettingsAdminChk.Location = New System.Drawing.Point(156, 243)
        Me.btnSetSysSettingsAdminChk.Name = "btnSetSysSettingsAdminChk"
        Me.btnSetSysSettingsAdminChk.Size = New System.Drawing.Size(127, 34)
        Me.btnSetSysSettingsAdminChk.TabIndex = 27
        Me.btnSetSysSettingsAdminChk.Text = "内容確認"
        Me.btnSetSysSettingsAdminChk.UseVisualStyleBackColor = True
        '
        'tbCashOutMoneyDayMax
        '
        Me.tbCashOutMoneyDayMax.Location = New System.Drawing.Point(506, 214)
        Me.tbCashOutMoneyDayMax.Name = "tbCashOutMoneyDayMax"
        Me.tbCashOutMoneyDayMax.Size = New System.Drawing.Size(115, 19)
        Me.tbCashOutMoneyDayMax.TabIndex = 25
        Me.tbCashOutMoneyDayMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCashOutMoneyMax
        '
        Me.tbCashOutMoneyMax.Location = New System.Drawing.Point(506, 189)
        Me.tbCashOutMoneyMax.Name = "tbCashOutMoneyMax"
        Me.tbCashOutMoneyMax.Size = New System.Drawing.Size(115, 19)
        Me.tbCashOutMoneyMax.TabIndex = 23
        Me.tbCashOutMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCashInMoneyDayMin
        '
        Me.tbCashInMoneyDayMin.Location = New System.Drawing.Point(506, 164)
        Me.tbCashInMoneyDayMin.Name = "tbCashInMoneyDayMin"
        Me.tbCashInMoneyDayMin.Size = New System.Drawing.Size(115, 19)
        Me.tbCashInMoneyDayMin.TabIndex = 21
        Me.tbCashInMoneyDayMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCashInMoneyMin
        '
        Me.tbCashInMoneyMin.Location = New System.Drawing.Point(506, 139)
        Me.tbCashInMoneyMin.Name = "tbCashInMoneyMin"
        Me.tbCashInMoneyMin.Size = New System.Drawing.Size(115, 19)
        Me.tbCashInMoneyMin.TabIndex = 19
        Me.tbCashInMoneyMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCustProductMoneyMax
        '
        Me.tbCustProductMoneyMax.Location = New System.Drawing.Point(506, 114)
        Me.tbCustProductMoneyMax.Name = "tbCustProductMoneyMax"
        Me.tbCustProductMoneyMax.Size = New System.Drawing.Size(115, 19)
        Me.tbCustProductMoneyMax.TabIndex = 17
        Me.tbCustProductMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCustMoneyMax
        '
        Me.tbCustMoneyMax.Location = New System.Drawing.Point(506, 62)
        Me.tbCustMoneyMax.Name = "tbCustMoneyMax"
        Me.tbCustMoneyMax.Size = New System.Drawing.Size(115, 19)
        Me.tbCustMoneyMax.TabIndex = 13
        Me.tbCustMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCustCountMax
        '
        Me.tbCustCountMax.Location = New System.Drawing.Point(506, 37)
        Me.tbCustCountMax.Name = "tbCustCountMax"
        Me.tbCustCountMax.Size = New System.Drawing.Size(115, 19)
        Me.tbCustCountMax.TabIndex = 11
        Me.tbCustCountMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(340, 217)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(115, 12)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "最大出金可能額(1日)"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(340, 192)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(115, 12)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "最大出金可能額(1回)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(340, 167)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(115, 12)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "最大入金可能額(1日)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(340, 142)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(115, 12)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "最小入金可能額(1回)"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(340, 117)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(159, 12)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "最大購入可能額(1銘柄)(顧客)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(340, 65)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(121, 12)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "最大購入可能額(顧客)"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(340, 40)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(121, 12)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "最大保有建玉数(顧客)"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(328, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 12)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "[顧客]"
        '
        'tbProductMoneyMax
        '
        Me.tbProductMoneyMax.Location = New System.Drawing.Point(172, 87)
        Me.tbProductMoneyMax.Name = "tbProductMoneyMax"
        Me.tbProductMoneyMax.Size = New System.Drawing.Size(115, 19)
        Me.tbProductMoneyMax.TabIndex = 6
        Me.tbProductMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbTradeMoneyMax
        '
        Me.tbTradeMoneyMax.Location = New System.Drawing.Point(172, 62)
        Me.tbTradeMoneyMax.Name = "tbTradeMoneyMax"
        Me.tbTradeMoneyMax.Size = New System.Drawing.Size(115, 19)
        Me.tbTradeMoneyMax.TabIndex = 4
        Me.tbTradeMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbTradeMoneyMin
        '
        Me.tbTradeMoneyMin.Location = New System.Drawing.Point(172, 37)
        Me.tbTradeMoneyMin.Name = "tbTradeMoneyMin"
        Me.tbTradeMoneyMin.Size = New System.Drawing.Size(115, 19)
        Me.tbTradeMoneyMin.TabIndex = 2
        Me.tbTradeMoneyMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(22, 90)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 12)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "最大購入可能額(銘柄)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(22, 65)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(115, 12)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "最大取引額(1回)銘柄"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(22, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(115, 12)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "最少取引額(1回)銘柄"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "[全体]"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 117)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 12)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "レート有効時間(秒)"
        '
        'tbRateEnableTime
        '
        Me.tbRateEnableTime.Location = New System.Drawing.Point(172, 114)
        Me.tbRateEnableTime.Name = "tbRateEnableTime"
        Me.tbRateEnableTime.Size = New System.Drawing.Size(115, 19)
        Me.tbRateEnableTime.TabIndex = 8
        Me.tbRateEnableTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbCustMoneyDayMax
        '
        Me.tbCustMoneyDayMax.Location = New System.Drawing.Point(506, 87)
        Me.tbCustMoneyDayMax.Name = "tbCustMoneyDayMax"
        Me.tbCustMoneyDayMax.Size = New System.Drawing.Size(115, 19)
        Me.tbCustMoneyDayMax.TabIndex = 15
        Me.tbCustMoneyDayMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(340, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(147, 12)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "最大購入可能額(1日)(顧客)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(22, 195)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 12)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "アラート損益(顧客)"
        '
        'tbAlertDayPAndLCust
        '
        Me.tbAlertDayPAndLCust.Location = New System.Drawing.Point(172, 192)
        Me.tbAlertDayPAndLCust.Name = "tbAlertDayPAndLCust"
        Me.tbAlertDayPAndLCust.Size = New System.Drawing.Size(115, 19)
        Me.tbAlertDayPAndLCust.TabIndex = 39
        Me.tbAlertDayPAndLCust.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 170)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 12)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "アラート損益"
        '
        'tbAlertDayPAndL
        '
        Me.tbAlertDayPAndL.Location = New System.Drawing.Point(172, 167)
        Me.tbAlertDayPAndL.Name = "tbAlertDayPAndL"
        Me.tbAlertDayPAndL.Size = New System.Drawing.Size(115, 19)
        Me.tbAlertDayPAndL.TabIndex = 37
        Me.tbAlertDayPAndL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 12)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "[アラート]"
        '
        'SysSettingsForm
        '
        Me.AcceptButton = Me.btnSetSysSettingsAdminChk
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(654, 293)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.tbAlertDayPAndLCust)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbAlertDayPAndL)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbCustMoneyDayMax)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.tbRateEnableTime)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSetSysSettingsAdmin)
        Me.Controls.Add(Me.btnCancelChk)
        Me.Controls.Add(Me.btnSetSysSettingsAdminChk)
        Me.Controls.Add(Me.tbCashOutMoneyDayMax)
        Me.Controls.Add(Me.tbCashOutMoneyMax)
        Me.Controls.Add(Me.tbCashInMoneyDayMin)
        Me.Controls.Add(Me.tbCashInMoneyMin)
        Me.Controls.Add(Me.tbCustProductMoneyMax)
        Me.Controls.Add(Me.tbCustMoneyMax)
        Me.Controls.Add(Me.tbCustCountMax)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.tbProductMoneyMax)
        Me.Controls.Add(Me.tbTradeMoneyMax)
        Me.Controls.Add(Me.tbTradeMoneyMin)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "SysSettingsForm"
        Me.Text = "システム設定"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnSetSysSettingsAdmin As System.Windows.Forms.Button
    Friend WithEvents btnCancelChk As System.Windows.Forms.Button
    Friend WithEvents btnSetSysSettingsAdminChk As System.Windows.Forms.Button
    Friend WithEvents tbCashOutMoneyDayMax As System.Windows.Forms.TextBox
    Friend WithEvents tbCashOutMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents tbCashInMoneyDayMin As System.Windows.Forms.TextBox
    Friend WithEvents tbCashInMoneyMin As System.Windows.Forms.TextBox
    Friend WithEvents tbCustProductMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents tbCustMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents tbCustCountMax As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents tbProductMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents tbTradeMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents tbTradeMoneyMin As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tbRateEnableTime As System.Windows.Forms.TextBox
    Friend WithEvents tbCustMoneyDayMax As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As Label
    Friend WithEvents tbAlertDayPAndLCust As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents tbAlertDayPAndL As TextBox
    Friend WithEvents Label3 As Label
End Class
