﻿Public Class CustList

    Private WithEvents service As New CustService
    Private WithEvents serviceCustHist As New CustHistService

    Private CustMode As Boolean

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT
    Private Const REPLICATION_WAIT As Integer = 2000

    Private Table As DataTable

    Private Start As Integer = 1

    Private Sub ProductList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True
        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        TotalMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbCurCode.DisplayMember = "CurName"
        cbCurCode.ValueMember = "CurCode"
        cbCurCode.DataSource = CurrencyService.GetListWithAll()

        cbCountryCode.DisplayMember = "Name"
        cbCountryCode.ValueMember = "Code"
        cbCountryCode.DataSource = CountryTypeManager.GetListWithAll()

        MainWindow.SubFormCust = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        setTotalMoney(0)
        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub ProductList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormCust = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.CustList_FormMaximized, _
            UserSettings.getInstance().DataSaved.CustList_FormSize, _
            UserSettings.getInstance().DataSaved.CustList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.CustList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.CustList_CmpCode
        cbCurCode.SelectedValue = UserSettings.getInstance().DataSaved.CustList_CurCode
        cbCountryCode.SelectedValue = UserSettings.getInstance().DataSaved.CustList_CountryCode
        chkEnableCust.Checked = UserSettings.getInstance().DataSaved.CustList_EnableCust
        chkStopCust.Checked = UserSettings.getInstance().DataSaved.CustList_StopCust
        chkTestAccount.Checked = UserSettings.getInstance().DataSaved.CustList_TestAccount
        tbFromCustCode.Text = UserSettings.getInstance().DataSaved.CustList_FromCustCode
        tbToCustCode.Text = UserSettings.getInstance().DataSaved.CustList_ToCustCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.CustList_FormMaximized, _
            UserSettings.getInstance().DataSaved.CustList_FormSize, _
            UserSettings.getInstance().DataSaved.CustList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.CustList_Columns)
        UserSettings.getInstance().DataSaved.CustList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.CustList_CurCode = cbCurCode.SelectedValue
        UserSettings.getInstance().DataSaved.CustList_CountryCode = cbCountryCode.SelectedValue
        UserSettings.getInstance().DataSaved.CustList_EnableCust = chkEnableCust.Checked
        UserSettings.getInstance().DataSaved.CustList_StopCust = chkStopCust.Checked
        UserSettings.getInstance().DataSaved.CustList_TestAccount = chkTestAccount.Checked
        UserSettings.getInstance().DataSaved.CustList_FromCustCode = tbFromCustCode.Text
        UserSettings.getInstance().DataSaved.CustList_ToCustCode = tbToCustCode.Text
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("CustCode", GetType(String))
        Table.Columns.Add("RegTime", GetType(DateTime))
        Table.Columns.Add("CurName", GetType(String))
        Table.Columns.Add("TotalMoney", GetType(Decimal))
        Table.Columns.Add("DealDisabled", GetType(String))
        Table.Columns.Add("CashDisabled", GetType(String))
        Table.Columns.Add("TestAccount", GetType(String))
        Table.Columns.Add("CountryName", GetType(String))
        grid.DataSource = Table
    End Sub

    Private Sub setTotalMoney(TotalMoney As Decimal)
        If cbCurCode.SelectedValue = "" Then
            '全ての場合、表示しない
            lblTotalMoney.Text = ""
        Else
            lblTotalMoney.Text = TotalMoney.ToString(clsUtil.GetMoneyFormatDisp())
            If TotalMoney >= 0 Then
                lblTotalMoney.ForeColor = Color.Black
            Else
                lblTotalMoney.ForeColor = Color.Red
            End If
        End If
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of CustData))

        For Each item As CustData In list
            Dim row As DataRow = Table.NewRow()
            row("CustCode") = item.CustCode
            row("RegTime") = item.RegTime
            row("CurName") = item.CurName
            row("TotalMoney") = item.TotalMoney
            Dim DealDisabledName As String = ""
            If item.DealDisabled <> "0" Then
                DealDisabledName = "停止"
            End If
            row("DealDisabled") = DealDisabledName
            Dim CashDisabledName As String = ""
            If item.CashDisabled <> "0" Then
                CashDisabledName = "停止"
            End If
            row("CashDisabled") = CashDisabledName
            Dim TestAccountName As String = ""
            If item.TestAccount Then
                TestAccountName = "テスト口座"
            End If
            row("TestAccount") = TestAccountName
            row("CountryName") = item.CountryTypeName()

            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                If CustMode Then
                    service.CancelRead()
                Else
                    serviceCustHist.CancelRead()
                End If
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim CurCode As String = Me.cbCurCode.SelectedValue
        Dim EnableCustFlg As String = IIf(Me.chkEnableCust.Checked, "1", "")
        Dim StopCustFlg As String = IIf(Me.chkStopCust.Checked, "1", "")
        Dim TestAccountFlg As String = IIf(Me.chkTestAccount.Checked, "1", "")
        Dim FromCustCode As String = tbFromCustCode.Text
        Dim ToCustCode As String = tbToCustCode.Text
        Dim SortKey As String = ""
        Dim CountryCode As String = Me.cbCountryCode.SelectedValue
        If grid.SortedColumn IsNot Nothing Then
            SortKey = convSortKeyName(grid.SortedColumn.Name)
            If SortKey <> "" Then
                If grid.SortOrder = SortOrder.Descending Then
                    SortKey &= " DESC"
                End If
            End If
        End If

        CustMode = chkEnableCustMode.Checked

        If CustMode Then
            '委託者取得
            service.ReadList(CmpCode, CurCode, EnableCustFlg, StopCustFlg, TestAccountFlg, FromCustCode, ToCustCode, "", Start, SortKey, CountryCode)
        Else
            '委託者履歴取得
            Dim SysDateTime As String = dtpSysDateTime.Value.ToString("yyyyMMdd")
            serviceCustHist.ReadList(SysDateTime, CmpCode, CurCode, EnableCustFlg, StopCustFlg, TestAccountFlg, FromCustCode, ToCustCode, "", Start, SortKey, CountryCode)
        End If
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel, serviceCustHist.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError, serviceCustHist.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of CustData), existNextFlag As Boolean, TotalMoney As Decimal) Handles service.ReadSuccess, serviceCustHist.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setTotalMoney(TotalMoney)
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

    Private Function convSortKeyName(columnName As String) As String
        Dim ret As String = ""
        Select Case columnName
            Case "CustCode"
                ret = "CUSTCODE"
            Case "RegTime"
                ret = "REGTIME"
            Case "TotalMoney"
                ret = "TOTALMONEY"
        End Select
        Return ret
    End Function

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs)
        If e.RowIndex >= 0 Then
            If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                Dim ColName As String = grid.Columns(e.ColumnIndex).Name
                If ColName = "TotalMoney" Then
                    If Not IsDBNull(e.Value) AndAlso e.Value < 0 Then
                        e.Paint(e.CellBounds, e.PaintParts And Not DataGridViewPaintParts.ContentForeground)
                        TextRenderer.DrawText(e.Graphics, e.FormattedValue, e.CellStyle.Font, e.CellBounds, Color.Red, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlcust"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub chkEnableCustMode_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkEnableCustMode.CheckedChanged

        If dtpSysDateTime.Enabled = True Then
            dtpSysDateTime.Enabled = False
        Else
            dtpSysDateTime.Enabled = True
        End If
    End Sub

    Private Sub grid_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grid.CellContentClick
        If e.ColumnIndex < 0 Then Exit Sub
        Dim data As New CustData
        If e.ColumnIndex = 4 Then
            If UserTypeManager.IsEdit(SessionService.UserType) Or UserTypeManager.IsWL(SessionService.UserType) Then
                If grid.SelectedRows(0).Cells("DealDisabled").Value = "停止" Then
                    MsgBox.Message = "取引解除を行う"
                    If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                        'webserviceで停止→解除処理を行う
                        data.DealDisabled = "0"
                    Else
                        Exit Sub
                    End If
                Else
                    MsgBox.Message = "取引停止を行う"
                    If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                        'webserviceで停止処理を行う
                        data.DealDisabled = "1"
                    Else
                        Exit Sub
                    End If
                End If
                data.CustCode = grid.SelectedRows(0).Cells("CustCode").Value
                service.ChageDealFlag(data)
            Else
                With MsgBox
                    .Message = "取引状態の変更を行う権限がありません"
                    .RunVisible = False
                    .CancelName = "閉じる"
                    .ShowDialog(Me)
                End With
                Exit Sub
            End If
        ElseIf e.ColumnIndex = 5 Then
            If UserTypeManager.IsEdit(SessionService.UserType) Or UserTypeManager.IsWL(SessionService.UserType) Then
                If grid.SelectedRows(0).Cells("CashDisabled").Value = "停止" Then
                    MsgBox.Message = "入出金解除を行う"
                    If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                        'webserviceで停止→解除処理を行う
                        data.CashDisabled = "0"
                    Else
                        Exit Sub
                    End If
                Else
                    MsgBox.Message = "入出金停止を行う"
                    If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                        'webserviceで停止処理を行う
                        data.CashDisabled = "1"
                    Else
                        Exit Sub
                    End If
                End If
                data.CustCode = grid.SelectedRows(0).Cells("CustCode").Value
                service.ChageCashFlag(data)
            Else
                With MsgBox
                    .Message = "入出金状態の変更を行う権限がありません"
                    .RunVisible = False
                    .CancelName = "閉じる"
                    .ShowDialog(Me)
                End With
                Exit Sub
            End If
        ElseIf e.ColumnIndex = 6 Then
            If UserTypeManager.IsEdit(SessionService.UserType) Or UserTypeManager.IsWL(SessionService.UserType) Then
                If grid.SelectedRows(0).Cells("TestAccount").Value = "テスト口座" Then
                    MsgBox.Message = "テスト口座の解除を行う"
                    If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                        'webserviceで停止→解除処理を行う
                        data.TestAccount = "0"
                    Else
                        Exit Sub
                    End If
                Else
                    MsgBox.Message = "テスト口座として登録する"
                    If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                        'webserviceでテスト口座登録を行う
                        data.TestAccount = "1"
                    Else
                        Exit Sub
                    End If
                End If
                data.CustCode = grid.SelectedRows(0).Cells("CustCode").Value
                service.ChageTestAccountFlag(data)
            Else
                With MsgBox
                    .Message = "テスト口座状態の変更を行う権限がありません"
                    .RunVisible = False
                    .CancelName = "閉じる"
                    .ShowDialog(Me)
                End With
                Exit Sub
            End If
        End If
    End Sub

    Private Sub service_FlagDealSuccess() Handles service.FlagDealSuccess
        Dim sw As Stopwatch = Stopwatch.StartNew
        MessageBox.Show(Me, "取引停止フラグを変更しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        sw.Stop()

        ' SubDBに反映されるまで2秒かかるためスリープ対応
        If sw.ElapsedMilliseconds < REPLICATION_WAIT Then
            Dim wait As Integer = REPLICATION_WAIT - sw.ElapsedMilliseconds
            Threading.Thread.Sleep(wait)
        End If

        Me.Start = 1
        request()
        setWindowLayout(False)
    End Sub

    Private Sub service_FlagDealError(ErrorMessage As String) Handles service.FlagDealError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_FlagDealCancel() Handles service.FlagDealCancel
        requestEnd()
    End Sub

    Private Sub service_FlagCashSuccess() Handles service.FlagCashSuccess
        Dim sw As Stopwatch = Stopwatch.StartNew
        MessageBox.Show(Me, "入出金停止フラグを変更しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        sw.Stop()

        ' SubDBに反映されるまで2秒かかるためスリープ対応
        If sw.ElapsedMilliseconds < REPLICATION_WAIT Then
            Dim wait As Integer = REPLICATION_WAIT - sw.ElapsedMilliseconds
            Threading.Thread.Sleep(wait)
        End If

        Me.Start = 1
        request()
        setWindowLayout(False)
    End Sub

    Private Sub service_FlagCashError(ErrorMessage As String) Handles service.FlagCashError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_FlagCashCancel() Handles service.FlagCashCancel
        requestEnd()
    End Sub

    Private Sub service_FlagTestAccountSuccess() Handles service.FlagTestAccountSuccess
        Dim sw As Stopwatch = Stopwatch.StartNew
        MessageBox.Show(Me, "テスト口座フラグを変更しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        sw.Stop()

        ' SubDBに反映されるまで2秒かかるためスリープ対応
        If sw.ElapsedMilliseconds < REPLICATION_WAIT Then
            Dim wait As Integer = REPLICATION_WAIT - sw.ElapsedMilliseconds
            Threading.Thread.Sleep(wait)
        End If

        Me.Start = 1
        request()
        setWindowLayout(False)
    End Sub

    Private Sub service_FlagTestAccountError(ErrorMessage As String) Handles service.FlagTestAccountError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_FlagTestAccountCancel() Handles service.FlagTestAccountCancel
        requestEnd()
    End Sub


End Class