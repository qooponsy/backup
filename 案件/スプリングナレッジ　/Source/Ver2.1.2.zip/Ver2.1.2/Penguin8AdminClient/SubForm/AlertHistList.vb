﻿Imports Penguin8AdminClient

Public Class AlertHistList

    Private WithEvents service As New AlertLogService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1

    Private Sub AlertHistList_Load(sender As Object, e As EventArgs) Handles Me.Load

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbAlertType.DisplayMember = "Name"
        cbAlertType.ValueMember = "Code"
        cbAlertType.DataSource = AlertTypeManager.GetListWithAll()

        '初期値の設定
        dtpFromDateTime.Value = SysSettingsService.GetStartDate()
        dtpToDateTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone)
        dtpToDateTime.Checked = False

        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)

    End Sub

    Private Sub AlertHistList_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormAlertHist = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me,
            UserSettings.getInstance().DataSaved.AlertHistList_FormMaximized,
            UserSettings.getInstance().DataSaved.AlertHistList_FormSize,
            UserSettings.getInstance().DataSaved.AlertHistList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.AlertHistList_Columns)

        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.AlertHistList_CmpCode
        cbAlertType.SelectedValue = UserSettings.getInstance().DataSaved.AlertHistList_AlertType
        tbCode.Text = UserSettings.getInstance().DataSaved.AlertHistList_Code
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me,
            UserSettings.getInstance().DataSaved.AlertHistList_FormMaximized,
            UserSettings.getInstance().DataSaved.AlertHistList_FormSize,
            UserSettings.getInstance().DataSaved.AlertHistList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.AlertHistList_Columns)
        UserSettings.getInstance().DataSaved.AlertHistList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.AlertHistList_AlertType = cbAlertType.SelectedValue
        UserSettings.getInstance().DataSaved.AlertHistList_Code = tbCode.Text
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("LogId", GetType(String))
        Table.Columns.Add("LogTime", GetType(DateTime))
        Table.Columns.Add("CmpCode", GetType(String))
        Table.Columns.Add("CmpName", GetType(String))
        Table.Columns.Add("Code", GetType(String))
        Table.Columns.Add("AlertType", GetType(String))
        Table.Columns.Add("AlertTypeName", GetType(String))
        Table.Columns.Add("LogText", GetType(String))
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub setGrid(ByVal list As List(Of AlertLogData))

        For Each item As AlertLogData In list
            Dim row As DataRow = Table.NewRow()
            row("LogId") = item.LogID
            row("LogTime") = item.LogTime
            row("CmpCode") = item.CmpCode
            row("CmpName") = CompanyService.GetName(item.CmpCode)
            row("Code") = item.Code
            row("AlertType") = item.AlertType
            row("AlertTypeName") = AlertTypeManager.GetAlertTypeName(item.AlertType)
            row("LogText") = item.LogText
            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    ''' [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    ''' [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSearchAdd_Click(sender As Object, e As EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim AlertType As String = Me.cbAlertType.SelectedValue
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim Code As String = Me.tbCode.Text

        service.ReadList(CmpCode, AlertType, FromDateTime, ToDateTime, Code, "", Start)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As List(Of AlertLogData), ExistNextFlag As Boolean, RateFilterUpdateSeq As Long) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(ExistNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub
End Class