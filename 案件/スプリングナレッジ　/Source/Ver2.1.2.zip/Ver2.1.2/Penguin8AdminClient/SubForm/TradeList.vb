﻿Imports System.Net
Imports System.Collections.Specialized

Public Class TradeList
    Private WithEvents service As New TradeService
    Private WithEvents serviceRateTick As RateTickService
    Private WithEvents serviceTradeNow As TradeNowService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
        REAL = 3
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private View As DataView
    Private Count As Integer = 100
    Private Start As Integer = 1

	Private ConditionString As String = ""			' 印刷用抽出条件文字列

	Private Sub TradeList_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

		clsUtil.SetGridDoubleBuffered(grid)

		lblNoData.Parent = grid
		lblNoData.BackColor = Color.Transparent
		lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Premium.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        Payout.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        NetPAndL.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        AbandMoney.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        Dim editable As Boolean = False
        'Dim editable As Boolean = UserTypeManager.IsEdit(SessionService.UserType)
		btnRegist.Enabled = editable
		miEdit.Text = IIf(editable, "編集", "参照")

		cbCmpCode.DisplayMember = "CmpName"
		cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbCurCode.DisplayMember = "CurName"
        cbCurCode.ValueMember = "CurCode"
        cbCurCode.DataSource = CurrencyService.GetListWithAll()

		cbListType.DisplayMember = "Name"
		cbListType.ValueMember = "Code"
		cbListType.DataSource = TradeListTypeManager.GetList()

		cbComCode.DisplayMember = "ComName"
		cbComCode.ValueMember = "ComCode"
		cbComCode.DataSource = CurrencyPairService.GetListWithAll()

		cbTradeType.DisplayMember = "Name"
		cbTradeType.ValueMember = "Code"
		cbTradeType.DataSource = TradeTypeManager.GetListWithAll()

		cbTradeStatus.DisplayMember = "Name"
		cbTradeStatus.ValueMember = "Code"
		cbTradeStatus.DataSource = TradeStatusManager.GetListWithAll()

		cbDateType.DisplayMember = "Name"
		cbDateType.ValueMember = "Code"
        cbDateType.DataSource = DateTypeManager.GetTradeList()

        cbOpType.DisplayMember = "Name"
        cbOpType.ValueMember = "Code"
        cbOpType.DataSource = OptionTypeManager.GetListWithAll()

        cbCountryCode.DisplayMember = "Name"
        cbCountryCode.ValueMember = "Code"
        cbCountryCode.DataSource = CountryTypeManager.GetListWithAll()

        grid.AutoGenerateColumns = False

		'初期値の設定
        dtpFromDateTime.Value = SysSettingsService.GetStartDate()
        dtpToDateTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone)
		dtpToDateTime.Checked = False

		MainWindow.SubFormTrade = True
		LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

		initGrid()

		If cbListType.SelectedValue = "0" Then
			formModeStatus = FormMode.REAL
			setReal()
		Else
			formModeStatus = FormMode.NORMAL
		End If
		setWindowLayout(False)

		serviceRateTick = New RateTickService
		serviceTradeNow = New TradeNowService
	End Sub

    Private Sub TradeList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceRateTick = Nothing
        serviceTradeNow = Nothing

        SaveSettings()
        MainWindow.SubFormTrade = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.TradeList_FormMaximized, _
            UserSettings.getInstance().DataSaved.TradeList_FormSize, _
            UserSettings.getInstance().DataSaved.TradeList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.TradeList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_CmpCode
        cbCurCode.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_CurCode
        cbListType.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_ListType
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_ComCode
        cbOpType.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_OpType
        cbTradeType.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_TradeType
        cbTradeStatus.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_TradeStatus
        cbDateType.SelectedIndex = UserSettings.getInstance().DataSaved.TradeList_DateType
        cbCountryCode.SelectedValue = UserSettings.getInstance().DataSaved.TradeList_CountryCode
        tbProductCode.Text = UserSettings.getInstance().DataSaved.TradeList_ProductCode
        tbCustCode.Text = UserSettings.getInstance().DataSaved.TradeList_CustCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.TradeList_FormMaximized, _
            UserSettings.getInstance().DataSaved.TradeList_FormSize, _
            UserSettings.getInstance().DataSaved.TradeList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.TradeList_Columns)
        UserSettings.getInstance().DataSaved.TradeList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_CurCode = cbCurCode.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_ListType = cbListType.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_OpType = cbOpType.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_TradeType = cbTradeType.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_TradeStatus = cbTradeStatus.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_DateType = cbDateType.SelectedIndex
        UserSettings.getInstance().DataSaved.TradeList_CountryCode = cbCountryCode.SelectedValue
        UserSettings.getInstance().DataSaved.TradeList_ProductCode = tbProductCode.Text
        UserSettings.getInstance().DataSaved.TradeList_CustCode = tbCustCode.Text
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("TradeSeq", GetType(String))
        Table.Columns.Add("ProductCode", GetType(String))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("OpType", GetType(String))
        Table.Columns.Add("OpTypeName", GetType(String))
        Table.Columns.Add("OptionTime", GetType(String))
        Table.Columns.Add("PayoutRate", GetType(Decimal))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("TradeType", GetType(String))
        Table.Columns.Add("TradeTypeName", GetType(String))
        Table.Columns.Add("CurName", GetType(String))
        Table.Columns.Add("Premium", GetType(Decimal))
        Table.Columns.Add("CustCode", GetType(String))
        Table.Columns.Add("CmpCode", GetType(String))
        Table.Columns.Add("OrderReqTime", GetType(DateTime))
        Table.Columns.Add("OrderClientRateSeq", GetType(String))
        Table.Columns.Add("OrderClientRateTime", GetType(DateTime))
        Table.Columns.Add("OrderClientRate", GetType(Decimal))
        Table.Columns.Add("AbandReqTime", GetType(DateTime))
        Table.Columns.Add("AbandClientRateSeq", GetType(String))
        Table.Columns.Add("AbandClientRateTime", GetType(DateTime))
        Table.Columns.Add("AbandClientRate", GetType(Decimal))
        Table.Columns.Add("TradeTime", GetType(DateTime))
        Table.Columns.Add("TradeRateSeq", GetType(String))
        Table.Columns.Add("TradeRateTime", GetType(DateTime))
        Table.Columns.Add("TradeRate", GetType(Decimal))
        Table.Columns.Add("ExercPrice", GetType(Decimal))
        Table.Columns.Add("ExercProcTime", GetType(DateTime))
        Table.Columns.Add("ExercRateSeq", GetType(String))
        Table.Columns.Add("ExercRateTime", GetType(DateTime))
        Table.Columns.Add("ExercRate", GetType(Decimal))
        Table.Columns.Add("ExercPayoutRate", GetType(Decimal))
        Table.Columns.Add("Payout", GetType(Decimal))
        Table.Columns.Add("NetPAndL", GetType(Decimal))
        Table.Columns.Add("TradeStatus", GetType(String))
        Table.Columns.Add("TradeStatusName", GetType(String))
        Table.Columns.Add("AbandMoney", GetType(Decimal))
        Table.Columns.Add("InfoTitle", GetType(String))
        Table.Columns.Add("Info", GetType(String))
        Table.Columns.Add("Memo", GetType(String))
        Table.Columns.Add("CountryName", GetType(String))
        Table.Columns.Add("AbandMargine", GetType(Decimal))
        Table.Columns.Add("Volatility", GetType(Decimal))
        View = New DataView(Table)
        grid.DataSource = View
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of TradeData))
        View.RowFilter = ""

        For Each item As TradeData In list
            Dim row As DataRow = Table.NewRow()
            row("TradeSeq") = item.TradeSeq
            row("ProductCode") = item.ProductCode
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("OpType") = item.OpType
            row("OpTypeName") = OptionTypeManager.GetOptionTypeName(item.OpType)
            row("OptionTime") = DateTimeUtil.TimeConvView(item.OptionTime)
            row("PayoutRate") = item.PayoutRate
            row("ExercTime") = item.ExercTime
            row("SysDate") = item.SysDate
            row("TradeType") = item.TradeType
            row("TradeTypeName") = item.TradeTypeName
            row("CurName") = item.CurName
            row("Premium") = item.Premium
            row("CustCode") = item.CustCode
            row("CmpCode") = item.CmpCode
            row("OrderReqTime") = IIf(item.OrderReqTimeEnabled, item.OrderReqTime, DBNull.Value)
            row("OrderClientRateSeq") = item.OrderClientRateSeq
            row("OrderClientRateTime") = IIf(item.OrderClientRateTimeEnabled, item.OrderClientRateTime, DBNull.Value)
            row("OrderClientRate") = IIf(item.OrderClientRateEnabled, item.OrderClientRate, DBNull.Value)
            row("AbandReqTime") = IIf(item.AbandReqTimeEnabled, item.AbandReqTime, DBNull.Value)
            row("AbandClientRateSeq") = item.AbandClientRateSeq
            row("AbandClientRateTime") = IIf(item.AbandClientRateTimeEnabled, item.AbandClientRateTime, DBNull.Value)
            row("AbandClientRate") = IIf(item.AbandClientRateEnabled, item.AbandClientRate, DBNull.Value)
            row("TradeTime") = IIf(item.TradeTimeEnabled, item.TradeTime, DBNull.Value)
            row("TradeRateSeq") = item.TradeRateSeq
            row("TradeRateTime") = If(item.TradeRateTimeEnabled, item.TradeRateTime, DBNull.Value)
            row("TradeRate") = IIf(item.TradeRateEnabled, item.TradeRate, DBNull.Value)
            row("ExercPrice") = IIf(item.ExercPriceEnabled, item.ExercPrice, DBNull.Value)
            row("ExercProcTime") = IIf(item.ExercProcTimeEnabled, item.ExercProcTime, DBNull.Value)
            row("ExercRateSeq") = item.ExercRateSeq
            row("ExercRateTime") = IIf(item.ExercRateTimeEnabled, item.ExercRateTime, DBNull.Value)
            row("ExercRate") = IIf(item.ExercRateEnabled, item.ExercRate, DBNull.Value)
            row("ExercPayoutRate") = IIf(item.ExercPayoutRateEnabled, item.ExercPayoutRate, DBNull.Value)
            row("Payout") = IIf(item.PayoutEnabled, item.Payout, DBNull.Value)
            row("NetPAndL") = IIf(item.PAndLEnabled, item.PAndL, DBNull.Value)
            row("TradeStatus") = item.TradeStatus
            row("TradeStatusName") = item.TradeStatusName
            row("AbandMoney") = DBNull.Value
            row("InfoTitle") = item.InfoTitle
            row("Info") = item.Info
            row("Memo") = item.Memo
            row("CountryName") = item.CountryTypeName()
            row("AbandMargine") = item.AbandMargine
            row("Volatility") = item.Volatility

            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL, FormMode.REAL
                Me.Start = 1
                setWindowLayout(False)
                If cbListType.SelectedValue = "0" Then
                    formModeStatus = FormMode.REAL
                    setReal()
                Else
                    request()
                End If
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    '''  [新規]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("TradeSeq").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("TradeSeq").Value
        edit(code)
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim CurCode As String = Me.cbCurCode.SelectedValue
        Dim OpType As String = Me.cbOpType.SelectedValue
        Dim TradeType As String = Me.cbTradeType.SelectedValue
        Dim TradeStatus As String = Me.cbTradeStatus.SelectedValue
        Dim DateType As String = Me.cbDateType.SelectedValue
        Dim ProductCode As String = Me.tbProductCode.Text
        Dim CustCode As String = Me.tbCustCode.Text
        Dim FromDateTime As String = ""
        Dim ToDateTime As String = ""
        Dim SortKey As String = ""
        Dim CountryCode As String = Me.cbCountryCode.SelectedValue

        Dim SysDateFrom As String = ""
        Dim SysDateTo As String = ""
        Dim ExercTimeFrom As String = ""
        Dim ExercTimeTo As String = ""
        Dim TradeTimeFrom As String = ""
        Dim TradeTimeTo As String = ""
        Dim OrderReqTimeFrom As String = ""
        Dim OrderReqTimeTo As String = ""
        Dim AbandReqTimeFrom As String = ""
        Dim AbandReqTimeTo As String = ""
        Dim ExercProcTimeFrom As String = ""
        Dim ExercProcTimeTo As String = ""
        Select Case DateType
            Case "1"
                '取引日はUTC日時変換せず、「yyyyMMdd」形式にする
                SysDateFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.ToString("yyyyMMdd"), "")
                SysDateTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.ToString("yyyyMMdd"), "")
            Case "2"
                ExercTimeFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
                ExercTimeTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
            Case "3"
                OrderReqTimeFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
                OrderReqTimeTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
            Case "4"
                AbandReqTimeFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
                AbandReqTimeTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
            Case "5"
                TradeTimeFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
                TradeTimeTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
            Case "6"
                ExercProcTimeFrom = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
                ExercProcTimeTo = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        End Select

		'----------------------------------------------------------------------
		' 印刷用　抽出条件編集
		'----------------------------------------------------------------------
        ConditionString = "　" & Me.cbListType.Text
        If Me.cbListType.SelectedValue = "1" Then
            If dtpFromDateTime.Checked Or dtpToDateTime.Checked Then
                ConditionString = ConditionString & "　" & Me.cbDateType.Text & "　"
                If dtpFromDateTime.Checked Then
                    ConditionString = ConditionString & dtpFromDateTime.Value.ToString("yyyy/MM/dd")
                End If
                ConditionString = ConditionString & "　～　"
                If dtpToDateTime.Checked Then
                    ConditionString = ConditionString & dtpToDateTime.Value.ToString("yyyy/MM/dd")
                End If
            End If
        End If
        ConditionString = ConditionString & vbTab
        ConditionString = ConditionString & "　　会社:" & cbCmpCode.Text
        If Me.cbCurCode.SelectedValue <> "" Then
            ConditionString = ConditionString & "　通貨:" & Me.cbCurCode.Text
        End If
        If Me.cbComCode.SelectedValue <> "" Then
            ConditionString = ConditionString & "　通貨ペア:" & Me.cbComCode.Text
        End If
        If Me.cbOpType.SelectedValue <> "" Then
            ConditionString = ConditionString & "　オプション種別:" & Me.cbOpType.Text
        End If
        If Me.cbTradeType.SelectedValue <> "" Then
            ConditionString = ConditionString & "　種別:" & Me.cbTradeType.Text
		End If
        If Me.cbListType.SelectedValue = "1" Then
            If Me.cbTradeStatus.SelectedValue <> "" Then
                ConditionString = ConditionString & "　取引ステータス:" & Me.cbTradeStatus.Text
            End If
        End If
        If Me.cbCountryCode.SelectedValue <> "" Then
            ConditionString = ConditionString & "　国:" & Me.cbCountryCode.Text
        End If
        If ProductCode <> "" Then
            ConditionString = ConditionString & "　銘柄コード:" & ProductCode
		End If
        If CustCode <> "" Then
            ConditionString = ConditionString & "　委託者コード:" & CustCode
        End If

        service.ReadList(SysDateFrom, SysDateTo, ProductCode, ComCode, OpType, CmpCode, CurCode, CustCode, ExercTimeFrom, ExercTimeTo, TradeTimeFrom, TradeTimeTo, OrderReqTimeFrom, OrderReqTimeTo, AbandReqTimeFrom, AbandReqTimeTo, ExercProcTimeFrom, ExercProcTimeTo, TradeType, TradeStatus, "", Start.ToString(), SortKey, CountryCode)
        formModeStatus = FormMode.READ
		btnSearch.Text = "キャンセル"
	End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of TradeData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 And list.Count = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormTradeForm Then
            TradeForm.Close()
        End If
        TradeForm.MdiParent = MainWindow
        TradeForm.Code = ""
        TradeForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormTradeForm Then
            TradeForm.Close()
        End If
        TradeForm.MdiParent = MainWindow
        TradeForm.Code = code
        TradeForm.Show()
    End Sub

    Private Sub serviceRateTick_NewTick() Handles serviceRateTick.NewTick
        If formModeStatus = FormMode.REAL Then
            Dim StdDt As DateTime = RateTickService.ServerTime

            For Each row As DataRow In Table.Rows
                Dim sr As Decimal = CalcParamService.GetData(row("ComCode")).InterestRate
                Dim swapRate As Decimal = CalcParamService.GetData(row("ComCode")).SwapRate
                Dim abandPayout As Decimal = RiskCalc.AbandPayout(row("Premium"), row("AbandMargine"), row("PayoutRate"), row("TradeType"), RateTickService.GetLastRate(row("ComCode")).Rate, row("ExercPrice"), sr, swapRate, row("Volatility"), StdDt, row("ExercTime"), SessionService.DecimalPlaces)
                If row("AbandMoney") Is DBNull.Value OrElse abandPayout <> row("AbandMoney") Then
                    row("AbandMoney") = abandPayout
                    row("NetPAndL") = abandPayout - row("Premium")
                End If
            Next
        End If
    End Sub

    Private Sub setReal()
        Dim DispTopRowIndex As Integer = grid.FirstDisplayedScrollingRowIndex
        Dim GridDispRows As Integer = grid.DisplayedRowCount(False)
        Dim GridColumnIndex As Integer = grid.CurrentCellAddress.X
        Dim GridRowIndex As Integer = -1
        Dim DispTopColumnIndex As Integer = grid.FirstDisplayedScrollingColumnIndex

        ' 描画を停止
        grid.SuspendLayout()

        If grid.SelectedRows.Count > 0 Then
            GridRowIndex = grid.SelectedRows(0).Index
        End If

        Table.Rows.Clear()
        setGrid(TradeNowService.DataList)
        Dim RowFilter As String = ""
        Dim RowFilterAnd As String = ""
        If cbCurCode.SelectedValue <> "" Then
            RowFilter += RowFilterAnd + String.Format("CurName='{0}'", cbCurCode.SelectedValue)
            RowFilterAnd = " And "
        End If
        If cbComCode.SelectedValue <> "" Then
            RowFilter += RowFilterAnd + String.Format("ComCode='{0}'", cbComCode.SelectedValue)
            RowFilterAnd = " And "
        End If
        If cbOpType.SelectedValue <> "" Then
            RowFilter += RowFilterAnd + String.Format("OpType='{0}'", cbOpType.SelectedValue)
            RowFilterAnd = " And "
        End If
        If cbCmpCode.SelectedValue <> "" Then
            RowFilter += RowFilterAnd + String.Format("CmpCode='{0}'", cbCmpCode.SelectedValue)
            RowFilterAnd = " And "
        End If
        If cbTradeType.SelectedValue <> "" Then
            RowFilter += RowFilterAnd + String.Format("TradeType='{0}'", cbTradeType.SelectedValue)
            RowFilterAnd = " And "
        End If
        If tbProductCode.Text <> "" Then
            RowFilter += RowFilterAnd + String.Format("ProductCode='{0}'", tbProductCode.Text)
            RowFilterAnd = " And "
        End If
        If tbCustCode.Text <> "" Then
            RowFilter += RowFilterAnd + String.Format("CustCode='{0}'", tbCustCode.Text)
            RowFilterAnd = " And "
        End If
        If cbCountryCode.SelectedValue <> "" Then
            RowFilter += RowFilterAnd + String.Format("CountryName='{0}'", cbCountryCode.SelectedValue)
            RowFilterAnd = " And "
        End If
        View.RowFilter = RowFilter

        Dim DataCount As Integer = grid.Rows.Count
        If DataCount > 0 And DispTopRowIndex >= 0 Then
            If DataCount <= GridDispRows Then   'データ件数がグリッド表示行数以下の場合
                grid.FirstDisplayedScrollingRowIndex = 0
            ElseIf DataCount < DispTopRowIndex + GridDispRows Then  'データ件数が現在の表示行以下の為、表示開始位置が変化する場合
                grid.FirstDisplayedScrollingRowIndex = DispTopRowIndex - (DispTopRowIndex + GridDispRows - DataCount)
            Else    'データ件数が現在の表示行以上で、表示開始位置が変化しない場合
                grid.FirstDisplayedScrollingRowIndex = DispTopRowIndex
            End If
        End If

        If GridRowIndex >= DataCount Then
            GridRowIndex = DataCount - 1
        End If
        If GridRowIndex > -1 Then
            If DispTopColumnIndex >= 0 Then
                grid.FirstDisplayedScrollingColumnIndex = DispTopColumnIndex
            End If
            grid.Rows(GridRowIndex).Selected = True
        End If

        lblNoData.Visible = (grid.RowCount = 0)

        ' 描画再開
        grid.ResumeLayout(True)
    End Sub

    Private Sub setRealChanged()
        Dim TradeSeqHash As New HashSet(Of String)
        For Each item As TradeData In TradeNowService.DataList
            TradeSeqHash.Add(item.TradeSeq)
        Next
        For Each row As DataRow In Table.Rows
            If Not TradeSeqHash.Contains(row("TradeSeq")) Then
                Table.Rows.Remove(row)
                Continue For
            End If
        Next
    End Sub

    Private Sub serviceTradeNow_DataChanged() Handles serviceTradeNow.DataChanged
        If formModeStatus = FormMode.REAL Then
            setReal()
        End If
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dltrade"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)
                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub cbListType_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbListType.SelectedIndexChanged
        cbDateType.Enabled = (cbListType.SelectedValue = "1")
        dtpFromDateTime.Enabled = (cbListType.SelectedValue = "1")
        dtpToDateTime.Enabled = (cbListType.SelectedValue = "1")
        cbTradeStatus.Enabled = (cbListType.SelectedValue = "1")
    End Sub

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grid.CellPainting
        If e.RowIndex >= 0 Then
            Dim ColName As String = grid.Columns(e.ColumnIndex).Name
            If ColName = "NetPAndL" OrElse ColName = "ExercPayoutRate" Then
                If Not IsDBNull(e.Value) AndAlso e.Value < 0 Then
                    If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                        e.Paint(e.CellBounds, e.PaintParts And Not DataGridViewPaintParts.ContentForeground)
                        TextRenderer.DrawText(e.Graphics, e.FormattedValue, e.CellStyle.Font, e.CellBounds, Color.Red, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case grid.Columns(e.ColumnIndex).DataPropertyName
                Case "OrderClientRate", "AbandClientRate", "TradeRate", "ExercPrice", "ExercRate"
                    Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComCode").Value
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

	'--------------------------------------------------------------------------
	' 印刷 2012/06/28 H.S
	'--------------------------------------------------------------------------
	Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click
		Dim PrtUtil As PrintUtil

		Try
			PrtUtil = New PrintUtil()
			PrtUtil.PrintReport(grid, PrintUtil.Reports.TradeList, ConditionString)
		Catch ex As Exception
		End Try
	End Sub

End Class