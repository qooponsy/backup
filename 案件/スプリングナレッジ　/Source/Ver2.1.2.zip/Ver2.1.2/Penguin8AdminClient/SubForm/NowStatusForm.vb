﻿Public Class NowStatusForm

    Private WithEvents service As NowStatusService
    Private WithEvents serviceSysStatus As SysStatusService
    Private WithEvents serviceRateTick As RateTickService

    Private Sub NowStatusForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        MainWindow.SubFormNowStatus = True

        service = New NowStatusService
        serviceSysStatus = New SysStatusService
        serviceRateTick = New RateTickService

        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        service.Read(cbCmpCode.SelectedValue)
    End Sub

    Private Sub NowStatusForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        service = Nothing
        SaveSettings()
        MainWindow.SubFormNowStatus = False

        service = Nothing
        serviceSysStatus = Nothing
        serviceRateTick = Nothing
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        If UserSettings.getInstance().DataSaved.NowStatusForm_FormLocation <> New System.Drawing.Point(Integer.MinValue, Integer.MinValue) Then
            Me.Location = UserSettings.getInstance().DataSaved.NowStatusForm_FormLocation
        End If
        [clsUtil].GuardSubFormLocation(Me)

        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.NowStatusForm_CmpCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        UserSettings.getInstance().DataSaved.NowStatusForm_FormLocation = [clsUtil].GetFormLocation(Me)
        UserSettings.getInstance().DataSaved.NowStatusForm_CmpCode = cbCmpCode.SelectedValue
    End Sub

    Private Sub btnRefresh_Click(sender As System.Object, e As System.EventArgs) Handles btnRefresh.Click
        service.Read(cbCmpCode.SelectedValue)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel

    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError

    End Sub

    Private Sub service_ReadSuccess(data As NowStatus) Handles service.ReadSuccess
        setControlFromData(data)
    End Sub

    Private Sub setControlFromData(data As NowStatus)
        Me.lblGetDBTime.Text = data.GetDBTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.lblSysDate.Text = data.SysDate.ToString("yyyy/MM/dd")
        Me.lblSystemEnabled.Text = IIf(data.SysEnabled = "1", "稼動中", "停止中")
        Me.lblSystemEnabled.ForeColor = IIf(data.SysEnabled = "1", Color.Green, Color.Red)
        Me.lblAbandEnabled.Text = IIf(data.AbandEnabled = "1", "稼動中", "停止中")
        Me.lblAbandEnabled.ForeColor = IIf(data.AbandEnabled = "1", Color.Green, Color.Red)
        Me.lblCashInEnabled.Text = IIf(data.CashInEnabled = "1", "稼動中", "停止中")
        Me.lblCashInEnabled.ForeColor = IIf(data.CashInEnabled = "1", Color.Green, Color.Red)
        Me.lblCashOutEnabled.Text = IIf(data.CashOutEnabled = "1", "稼動中", "停止中")
        Me.lblCashOutEnabled.ForeColor = IIf(data.CashOutEnabled = "1", Color.Green, Color.Red)
        Me.lblProductStatusStatus.Text = IIf(data.ProductStatusStatus = 1, "取引中", "停止中")
        Me.lblProductStatusStatus.ForeColor = IIf(data.ProductStatusStatus = 1, Color.Green, Color.Red)
        Me.lblProductStatusNextTimeName.Text = IIf(data.ProductStatusStatus = 1, "停止日時", "開始日時")
        Me.lblProductStatusNextTime.Text = IIf(data.ProductStatusNextTime.Equals(Date.MinValue), "", data.ProductStatusNextTime.ToString("yyyy/MM/dd HH:mm:ss"))
        Me.lblAccountCount.Text = data.AccountCount.ToString("###,###,###,##0")
        Me.lblAccountCountEnabled.Text = data.AccountCountEnabled.ToString("###,###,###,##0")
        Me.lblNewAccountCount.Text = data.NewAccountCount.ToString("###,###,###,##0")
        Me.lblTradeAccountCount.Text = data.TradeAccountCount.ToString("###,###,###,##0")
        Me.lblTradeCount.Text = data.TradeCount.ToString("###,###,###,##0")
        Me.lblTradeAmount.Text = data.TradeAmount.ToString(clsUtil.GetMoneyFormatDisp())
        Me.lblTotalMoney.Text = data.TotalMoney.ToString(clsUtil.GetMoneyFormatDisp())
        Me.lblTotalPAndL.Text = data.TotalPAndL.ToString(clsUtil.GetMoneyFormatDisp())
        Me.lblTotalPAndL.ForeColor = IIf(data.TotalPAndL >= 0, Color.Black, Color.Red)
        Me.lblCashInCount.Text = data.CashInCount.ToString("###,###,###,##0")
        Me.lblCashInMoney.Text = data.CashInMoney.ToString(clsUtil.GetMoneyFormatDisp())
        Me.lblCashOutCount.Text = data.CashOutCount.ToString("###,###,###,##0")
        Me.lblCashOutMoney.Text = data.CashOutMoney.ToString(clsUtil.GetMoneyFormatDisp())
        Me.lblLoginAdminCount.Text = data.LoginAdminCount.ToString("###,###,###,##0")
        Me.lblLoginCustCount.Text = data.LoginCustCount.ToString("###,###,###,##0")
    End Sub

    Private Sub serviceSysStatus_DataChanged() Handles serviceSysStatus.DataChanged
        Dim Data As SysStatusData = SysStatusService.GetData()
        Me.lblSysDate.Text = Data.SysDate.ToString("yyyy/MM/dd")
        Me.lblSystemEnabled.Text = IIf(Data.SysEnabled = "1", "稼動中", "停止中")
        Me.lblSystemEnabled.ForeColor = IIf(Data.SysEnabled = "1", Color.Green, Color.Red)
        Me.lblAbandEnabled.Text = IIf(Data.AbandEnabled = "1", "稼動中", "停止中")
        Me.lblAbandEnabled.ForeColor = IIf(Data.AbandEnabled = "1", Color.Green, Color.Red)
        Me.lblCashInEnabled.Text = IIf(Data.CashInEnabled = "1", "稼動中", "停止中")
        Me.lblCashInEnabled.ForeColor = IIf(Data.CashInEnabled = "1", Color.Green, Color.Red)
        Me.lblCashOutEnabled.Text = IIf(Data.CashOutEnabled = "1", "稼動中", "停止中")
        Me.lblCashOutEnabled.ForeColor = IIf(Data.CashOutEnabled = "1", Color.Green, Color.Red)
    End Sub

    Private Sub rateTick_NewTick() Handles serviceRateTick.NewTick
        Me.lblProductStatusStatus.Text = IIf(RateTickService.ProductStatus = 1, "取引中", "停止中")
        Me.lblProductStatusStatus.ForeColor = IIf(RateTickService.ProductStatus = 1, Color.Green, Color.Red)
        Me.lblProductStatusNextTimeName.Text = IIf(RateTickService.ProductStatus = 1, "停止日時", "開始日時")
        Me.lblProductStatusNextTime.Text = IIf(RateTickService.NextTime.Equals(Date.MinValue), "", RateTickService.NextTime.ToString("yyyy/MM/dd HH:mm:ss"))
    End Sub

End Class