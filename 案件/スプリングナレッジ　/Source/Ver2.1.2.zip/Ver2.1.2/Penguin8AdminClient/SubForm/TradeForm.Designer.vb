﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TradeForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbProductCode = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblComName = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblPayoutRate = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblExercTime = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbTradeType = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.tbPremium = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbTradeRateSeq = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.tbTradeRate = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnProductRef = New System.Windows.Forms.Button()
        Me.btnRateSeqTrade = New System.Windows.Forms.Button()
        Me.btnRateSeqOrder = New System.Windows.Forms.Button()
        Me.tbOrderClientRate = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tbOrderClientRateSeq = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnRateSeqAband = New System.Windows.Forms.Button()
        Me.tbAbandClientRate = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.tbAbandClientRateSeq = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btnRateSeqExerc = New System.Windows.Forms.Button()
        Me.tbExercRate = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.tbExercRateSeq = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.tbPayout = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblPAndL = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.cbTradeStatus = New System.Windows.Forms.ComboBox()
        Me.tbInfo = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.tbMemo = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.dtpSysDate = New System.Windows.Forms.DateTimePicker()
        Me.tbInfoTitle = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.dtpTradeTime = New System.Windows.Forms.DateTimePicker()
        Me.tbTradeTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.dtpTradeRateTime = New System.Windows.Forms.DateTimePicker()
        Me.tbTradeRateTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.dtpOrderReqTime = New System.Windows.Forms.DateTimePicker()
        Me.tbOrderReqTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.dtpOrderClientRateTime = New System.Windows.Forms.DateTimePicker()
        Me.tbOrderClientRateTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.dtpAbandReqTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpAbandClientRateTime = New System.Windows.Forms.DateTimePicker()
        Me.tbAbandReqTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.tbAbandClientRateTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.dtpExercProcTime = New System.Windows.Forms.DateTimePicker()
        Me.tbExercProcTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.dtpExercRateTime = New System.Windows.Forms.DateTimePicker()
        Me.tbExercRateTimeMilliseconds = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.tbExercPrice = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.lblOpType = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lblOptionTime = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.cbExercStatus = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(713, 713)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 90
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(575, 713)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 89
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "注文番号"
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(172, 30)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(160, 23)
        Me.lblCode.TabIndex = 2
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 12)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "[注文情報]"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 12)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "銘柄コード"
        '
        'tbProductCode
        '
        Me.tbProductCode.Location = New System.Drawing.Point(172, 58)
        Me.tbProductCode.Name = "tbProductCode"
        Me.tbProductCode.Size = New System.Drawing.Size(160, 19)
        Me.tbProductCode.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(95, 86)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "通貨ペア"
        '
        'lblComName
        '
        Me.lblComName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblComName.Location = New System.Drawing.Point(172, 81)
        Me.lblComName.Name = "lblComName"
        Me.lblComName.Size = New System.Drawing.Size(160, 23)
        Me.lblComName.TabIndex = 7
        Me.lblComName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(95, 180)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 12)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "ペイアウト率"
        '
        'lblPayoutRate
        '
        Me.lblPayoutRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPayoutRate.Location = New System.Drawing.Point(172, 175)
        Me.lblPayoutRate.Name = "lblPayoutRate"
        Me.lblPayoutRate.Size = New System.Drawing.Size(160, 23)
        Me.lblPayoutRate.TabIndex = 9
        Me.lblPayoutRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(95, 209)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 12)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "行使期日"
        '
        'lblExercTime
        '
        Me.lblExercTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblExercTime.Location = New System.Drawing.Point(172, 204)
        Me.lblExercTime.Name = "lblExercTime"
        Me.lblExercTime.Size = New System.Drawing.Size(160, 23)
        Me.lblExercTime.TabIndex = 11
        Me.lblExercTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 260)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 12)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "取引種別"
        '
        'cbTradeType
        '
        Me.cbTradeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbTradeType.FormattingEnabled = True
        Me.cbTradeType.Location = New System.Drawing.Point(172, 257)
        Me.cbTradeType.Name = "cbTradeType"
        Me.cbTradeType.Size = New System.Drawing.Size(160, 20)
        Me.cbTradeType.TabIndex = 15
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(33, 286)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 12)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "取引金額"
        '
        'tbPremium
        '
        Me.tbPremium.Location = New System.Drawing.Point(172, 283)
        Me.tbPremium.Name = "tbPremium"
        Me.tbPremium.Size = New System.Drawing.Size(160, 19)
        Me.tbPremium.TabIndex = 17
        Me.tbPremium.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(33, 311)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 12)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "委託者コード"
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(172, 308)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(160, 19)
        Me.tbCustCode.TabIndex = 19
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(13, 334)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(61, 12)
        Me.Label10.TabIndex = 46
        Me.Label10.Text = "[約定情報]"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(33, 355)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(53, 12)
        Me.Label11.TabIndex = 47
        Me.Label11.Text = "約定時間"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(33, 378)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(84, 12)
        Me.Label12.TabIndex = 51
        Me.Label12.Text = "約定時価格Seq"
        '
        'tbTradeRateSeq
        '
        Me.tbTradeRateSeq.Location = New System.Drawing.Point(172, 375)
        Me.tbTradeRateSeq.Name = "tbTradeRateSeq"
        Me.tbTradeRateSeq.Size = New System.Drawing.Size(160, 19)
        Me.tbTradeRateSeq.TabIndex = 52
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(33, 401)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(89, 12)
        Me.Label13.TabIndex = 54
        Me.Label13.Text = "約定時価格時間"
        '
        'tbTradeRate
        '
        Me.tbTradeRate.Location = New System.Drawing.Point(172, 420)
        Me.tbTradeRate.Name = "tbTradeRate"
        Me.tbTradeRate.Size = New System.Drawing.Size(160, 19)
        Me.tbTradeRate.TabIndex = 59
        Me.tbTradeRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(33, 423)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(65, 12)
        Me.Label14.TabIndex = 58
        Me.Label14.Text = "約定時価格"
        '
        'btnProductRef
        '
        Me.btnProductRef.Location = New System.Drawing.Point(338, 56)
        Me.btnProductRef.Name = "btnProductRef"
        Me.btnProductRef.Size = New System.Drawing.Size(70, 23)
        Me.btnProductRef.TabIndex = 5
        Me.btnProductRef.Text = "入力反映"
        Me.btnProductRef.UseVisualStyleBackColor = True
        '
        'btnRateSeqTrade
        '
        Me.btnRateSeqTrade.Location = New System.Drawing.Point(338, 373)
        Me.btnRateSeqTrade.Name = "btnRateSeqTrade"
        Me.btnRateSeqTrade.Size = New System.Drawing.Size(70, 23)
        Me.btnRateSeqTrade.TabIndex = 53
        Me.btnRateSeqTrade.Text = "入力反映"
        Me.btnRateSeqTrade.UseVisualStyleBackColor = True
        '
        'btnRateSeqOrder
        '
        Me.btnRateSeqOrder.Location = New System.Drawing.Point(741, 53)
        Me.btnRateSeqOrder.Name = "btnRateSeqOrder"
        Me.btnRateSeqOrder.Size = New System.Drawing.Size(70, 23)
        Me.btnRateSeqOrder.TabIndex = 26
        Me.btnRateSeqOrder.Text = "入力反映"
        Me.btnRateSeqOrder.UseVisualStyleBackColor = True
        '
        'tbOrderClientRate
        '
        Me.tbOrderClientRate.Location = New System.Drawing.Point(575, 100)
        Me.tbOrderClientRate.Name = "tbOrderClientRate"
        Me.tbOrderClientRate.Size = New System.Drawing.Size(160, 19)
        Me.tbOrderClientRate.TabIndex = 32
        Me.tbOrderClientRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(436, 103)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(65, 12)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "注文時価格"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(436, 81)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(89, 12)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "注文時価格時間"
        '
        'tbOrderClientRateSeq
        '
        Me.tbOrderClientRateSeq.Location = New System.Drawing.Point(575, 55)
        Me.tbOrderClientRateSeq.Name = "tbOrderClientRateSeq"
        Me.tbOrderClientRateSeq.Size = New System.Drawing.Size(160, 19)
        Me.tbOrderClientRateSeq.TabIndex = 25
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(436, 58)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(84, 12)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "注文時価格Seq"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(436, 35)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 12)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "注文時間"
        '
        'btnRateSeqAband
        '
        Me.btnRateSeqAband.Location = New System.Drawing.Point(741, 177)
        Me.btnRateSeqAband.Name = "btnRateSeqAband"
        Me.btnRateSeqAband.Size = New System.Drawing.Size(70, 23)
        Me.btnRateSeqAband.TabIndex = 39
        Me.btnRateSeqAband.Text = "入力反映"
        Me.btnRateSeqAband.UseVisualStyleBackColor = True
        '
        'tbAbandClientRate
        '
        Me.tbAbandClientRate.Location = New System.Drawing.Point(575, 224)
        Me.tbAbandClientRate.Name = "tbAbandClientRate"
        Me.tbAbandClientRate.Size = New System.Drawing.Size(160, 19)
        Me.tbAbandClientRate.TabIndex = 45
        Me.tbAbandClientRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(436, 227)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(65, 12)
        Me.Label19.TabIndex = 44
        Me.Label19.Text = "放棄時価格"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(436, 205)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(89, 12)
        Me.Label20.TabIndex = 40
        Me.Label20.Text = "放棄時価格時間"
        '
        'tbAbandClientRateSeq
        '
        Me.tbAbandClientRateSeq.Location = New System.Drawing.Point(575, 179)
        Me.tbAbandClientRateSeq.Name = "tbAbandClientRateSeq"
        Me.tbAbandClientRateSeq.Size = New System.Drawing.Size(160, 19)
        Me.tbAbandClientRateSeq.TabIndex = 38
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(436, 182)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(84, 12)
        Me.Label21.TabIndex = 37
        Me.Label21.Text = "放棄時価格Seq"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(436, 159)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 12)
        Me.Label22.TabIndex = 33
        Me.Label22.Text = "放棄時間"
        '
        'btnRateSeqExerc
        '
        Me.btnRateSeqExerc.Location = New System.Drawing.Point(741, 373)
        Me.btnRateSeqExerc.Name = "btnRateSeqExerc"
        Me.btnRateSeqExerc.Size = New System.Drawing.Size(70, 23)
        Me.btnRateSeqExerc.TabIndex = 69
        Me.btnRateSeqExerc.Text = "入力反映"
        Me.btnRateSeqExerc.UseVisualStyleBackColor = True
        '
        'tbExercRate
        '
        Me.tbExercRate.Location = New System.Drawing.Point(575, 420)
        Me.tbExercRate.Name = "tbExercRate"
        Me.tbExercRate.Size = New System.Drawing.Size(160, 19)
        Me.tbExercRate.TabIndex = 75
        Me.tbExercRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(436, 423)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(65, 12)
        Me.Label23.TabIndex = 74
        Me.Label23.Text = "行使時価格"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(436, 401)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(89, 12)
        Me.Label24.TabIndex = 70
        Me.Label24.Text = "行使時価格時間"
        '
        'tbExercRateSeq
        '
        Me.tbExercRateSeq.Location = New System.Drawing.Point(575, 375)
        Me.tbExercRateSeq.Name = "tbExercRateSeq"
        Me.tbExercRateSeq.Size = New System.Drawing.Size(160, 19)
        Me.tbExercRateSeq.TabIndex = 68
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(436, 378)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(84, 12)
        Me.Label25.TabIndex = 67
        Me.Label25.Text = "行使時価格Seq"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(436, 355)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(77, 12)
        Me.Label26.TabIndex = 63
        Me.Label26.Text = "行使処理時間"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(418, 308)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(61, 12)
        Me.Label27.TabIndex = 62
        Me.Label27.Text = "[行使情報]"
        '
        'tbPayout
        '
        Me.tbPayout.Location = New System.Drawing.Point(575, 443)
        Me.tbPayout.Name = "tbPayout"
        Me.tbPayout.Size = New System.Drawing.Size(160, 19)
        Me.tbPayout.TabIndex = 77
        Me.tbPayout.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(436, 446)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(62, 12)
        Me.Label28.TabIndex = 76
        Me.Label28.Text = "ペイアウト額"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(496, 470)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(29, 12)
        Me.Label29.TabIndex = 78
        Me.Label29.Text = "損益"
        '
        'lblPAndL
        '
        Me.lblPAndL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPAndL.Location = New System.Drawing.Point(575, 465)
        Me.lblPAndL.Name = "lblPAndL"
        Me.lblPAndL.Size = New System.Drawing.Size(160, 23)
        Me.lblPAndL.TabIndex = 79
        Me.lblPAndL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(33, 506)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(74, 12)
        Me.Label30.TabIndex = 81
        Me.Label30.Text = "取引ステータス"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(13, 485)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(75, 12)
        Me.Label31.TabIndex = 80
        Me.Label31.Text = "[システム情報]"
        '
        'cbTradeStatus
        '
        Me.cbTradeStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbTradeStatus.FormattingEnabled = True
        Me.cbTradeStatus.Location = New System.Drawing.Point(172, 503)
        Me.cbTradeStatus.Name = "cbTradeStatus"
        Me.cbTradeStatus.Size = New System.Drawing.Size(160, 20)
        Me.cbTradeStatus.TabIndex = 82
        '
        'tbInfo
        '
        Me.tbInfo.Location = New System.Drawing.Point(172, 530)
        Me.tbInfo.Multiline = True
        Me.tbInfo.Name = "tbInfo"
        Me.tbInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbInfo.Size = New System.Drawing.Size(563, 83)
        Me.tbInfo.TabIndex = 86
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(33, 533)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(67, 12)
        Me.Label32.TabIndex = 85
        Me.Label32.Text = "システム情報"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(33, 621)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(22, 12)
        Me.Label33.TabIndex = 87
        Me.Label33.Text = "メモ"
        '
        'tbMemo
        '
        Me.tbMemo.Location = New System.Drawing.Point(172, 618)
        Me.tbMemo.Multiline = True
        Me.tbMemo.Name = "tbMemo"
        Me.tbMemo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbMemo.Size = New System.Drawing.Size(563, 83)
        Me.tbMemo.TabIndex = 88
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(33, 237)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(41, 12)
        Me.Label34.TabIndex = 12
        Me.Label34.Text = "取引日"
        '
        'dtpSysDate
        '
        Me.dtpSysDate.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDate.Location = New System.Drawing.Point(172, 232)
        Me.dtpSysDate.Name = "dtpSysDate"
        Me.dtpSysDate.Size = New System.Drawing.Size(160, 19)
        Me.dtpSysDate.TabIndex = 13
        '
        'tbInfoTitle
        '
        Me.tbInfoTitle.Location = New System.Drawing.Point(438, 503)
        Me.tbInfoTitle.Name = "tbInfoTitle"
        Me.tbInfoTitle.Size = New System.Drawing.Size(297, 19)
        Me.tbInfoTitle.TabIndex = 84
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(364, 506)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(56, 12)
        Me.Label35.TabIndex = 83
        Me.Label35.Text = "エラー内容"
        '
        'dtpTradeTime
        '
        Me.dtpTradeTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTradeTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTradeTime.Location = New System.Drawing.Point(172, 352)
        Me.dtpTradeTime.Name = "dtpTradeTime"
        Me.dtpTradeTime.ShowCheckBox = True
        Me.dtpTradeTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpTradeTime.TabIndex = 48
        '
        'tbTradeTimeMilliseconds
        '
        Me.tbTradeTimeMilliseconds.Location = New System.Drawing.Point(338, 352)
        Me.tbTradeTimeMilliseconds.Name = "tbTradeTimeMilliseconds"
        Me.tbTradeTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbTradeTimeMilliseconds.TabIndex = 49
        Me.tbTradeTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(377, 355)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(31, 12)
        Me.Label36.TabIndex = 50
        Me.Label36.Text = "ミリ秒"
        '
        'dtpTradeRateTime
        '
        Me.dtpTradeRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTradeRateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTradeRateTime.Location = New System.Drawing.Point(172, 398)
        Me.dtpTradeRateTime.Name = "dtpTradeRateTime"
        Me.dtpTradeRateTime.ShowCheckBox = True
        Me.dtpTradeRateTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpTradeRateTime.TabIndex = 55
        '
        'tbTradeRateTimeMilliseconds
        '
        Me.tbTradeRateTimeMilliseconds.Location = New System.Drawing.Point(339, 398)
        Me.tbTradeRateTimeMilliseconds.Name = "tbTradeRateTimeMilliseconds"
        Me.tbTradeRateTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbTradeRateTimeMilliseconds.TabIndex = 56
        Me.tbTradeRateTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(377, 403)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(31, 12)
        Me.Label37.TabIndex = 57
        Me.Label37.Text = "ミリ秒"
        '
        'dtpOrderReqTime
        '
        Me.dtpOrderReqTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpOrderReqTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpOrderReqTime.Location = New System.Drawing.Point(575, 32)
        Me.dtpOrderReqTime.Name = "dtpOrderReqTime"
        Me.dtpOrderReqTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpOrderReqTime.TabIndex = 21
        '
        'tbOrderReqTimeMilliseconds
        '
        Me.tbOrderReqTimeMilliseconds.Location = New System.Drawing.Point(741, 32)
        Me.tbOrderReqTimeMilliseconds.Name = "tbOrderReqTimeMilliseconds"
        Me.tbOrderReqTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbOrderReqTimeMilliseconds.TabIndex = 22
        Me.tbOrderReqTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(780, 35)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(31, 12)
        Me.Label38.TabIndex = 23
        Me.Label38.Text = "ミリ秒"
        '
        'dtpOrderClientRateTime
        '
        Me.dtpOrderClientRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpOrderClientRateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpOrderClientRateTime.Location = New System.Drawing.Point(575, 78)
        Me.dtpOrderClientRateTime.Name = "dtpOrderClientRateTime"
        Me.dtpOrderClientRateTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpOrderClientRateTime.TabIndex = 28
        '
        'tbOrderClientRateTimeMilliseconds
        '
        Me.tbOrderClientRateTimeMilliseconds.Location = New System.Drawing.Point(741, 78)
        Me.tbOrderClientRateTimeMilliseconds.Name = "tbOrderClientRateTimeMilliseconds"
        Me.tbOrderClientRateTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbOrderClientRateTimeMilliseconds.TabIndex = 29
        Me.tbOrderClientRateTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(780, 81)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(31, 12)
        Me.Label39.TabIndex = 30
        Me.Label39.Text = "ミリ秒"
        '
        'dtpAbandReqTime
        '
        Me.dtpAbandReqTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpAbandReqTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpAbandReqTime.Location = New System.Drawing.Point(575, 156)
        Me.dtpAbandReqTime.Name = "dtpAbandReqTime"
        Me.dtpAbandReqTime.ShowCheckBox = True
        Me.dtpAbandReqTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpAbandReqTime.TabIndex = 34
        '
        'dtpAbandClientRateTime
        '
        Me.dtpAbandClientRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpAbandClientRateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpAbandClientRateTime.Location = New System.Drawing.Point(575, 202)
        Me.dtpAbandClientRateTime.Name = "dtpAbandClientRateTime"
        Me.dtpAbandClientRateTime.ShowCheckBox = True
        Me.dtpAbandClientRateTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpAbandClientRateTime.TabIndex = 41
        '
        'tbAbandReqTimeMilliseconds
        '
        Me.tbAbandReqTimeMilliseconds.Location = New System.Drawing.Point(741, 156)
        Me.tbAbandReqTimeMilliseconds.Name = "tbAbandReqTimeMilliseconds"
        Me.tbAbandReqTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbAbandReqTimeMilliseconds.TabIndex = 35
        Me.tbAbandReqTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(780, 159)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(31, 12)
        Me.Label40.TabIndex = 36
        Me.Label40.Text = "ミリ秒"
        '
        'tbAbandClientRateTimeMilliseconds
        '
        Me.tbAbandClientRateTimeMilliseconds.Location = New System.Drawing.Point(741, 202)
        Me.tbAbandClientRateTimeMilliseconds.Name = "tbAbandClientRateTimeMilliseconds"
        Me.tbAbandClientRateTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbAbandClientRateTimeMilliseconds.TabIndex = 42
        Me.tbAbandClientRateTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(780, 205)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(31, 12)
        Me.Label41.TabIndex = 43
        Me.Label41.Text = "ミリ秒"
        '
        'dtpExercProcTime
        '
        Me.dtpExercProcTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpExercProcTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercProcTime.Location = New System.Drawing.Point(575, 352)
        Me.dtpExercProcTime.Name = "dtpExercProcTime"
        Me.dtpExercProcTime.ShowCheckBox = True
        Me.dtpExercProcTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpExercProcTime.TabIndex = 64
        '
        'tbExercProcTimeMilliseconds
        '
        Me.tbExercProcTimeMilliseconds.Location = New System.Drawing.Point(741, 352)
        Me.tbExercProcTimeMilliseconds.Name = "tbExercProcTimeMilliseconds"
        Me.tbExercProcTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbExercProcTimeMilliseconds.TabIndex = 65
        Me.tbExercProcTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(780, 355)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(31, 12)
        Me.Label42.TabIndex = 66
        Me.Label42.Text = "ミリ秒"
        '
        'dtpExercRateTime
        '
        Me.dtpExercRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpExercRateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercRateTime.Location = New System.Drawing.Point(575, 398)
        Me.dtpExercRateTime.Name = "dtpExercRateTime"
        Me.dtpExercRateTime.ShowCheckBox = True
        Me.dtpExercRateTime.Size = New System.Drawing.Size(160, 19)
        Me.dtpExercRateTime.TabIndex = 71
        '
        'tbExercRateTimeMilliseconds
        '
        Me.tbExercRateTimeMilliseconds.Location = New System.Drawing.Point(741, 398)
        Me.tbExercRateTimeMilliseconds.Name = "tbExercRateTimeMilliseconds"
        Me.tbExercRateTimeMilliseconds.Size = New System.Drawing.Size(33, 19)
        Me.tbExercRateTimeMilliseconds.TabIndex = 72
        Me.tbExercRateTimeMilliseconds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(780, 401)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(31, 12)
        Me.Label43.TabIndex = 73
        Me.Label43.Text = "ミリ秒"
        '
        'tbExercPrice
        '
        Me.tbExercPrice.Location = New System.Drawing.Point(172, 442)
        Me.tbExercPrice.Name = "tbExercPrice"
        Me.tbExercPrice.Size = New System.Drawing.Size(160, 19)
        Me.tbExercPrice.TabIndex = 61
        Me.tbExercPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(33, 445)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(53, 12)
        Me.Label44.TabIndex = 60
        Me.Label44.Text = "行使価格"
        '
        'lblOpType
        '
        Me.lblOpType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOpType.Location = New System.Drawing.Point(172, 111)
        Me.lblOpType.Name = "lblOpType"
        Me.lblOpType.Size = New System.Drawing.Size(160, 23)
        Me.lblOpType.TabIndex = 92
        Me.lblOpType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(95, 116)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(72, 12)
        Me.Label46.TabIndex = 91
        Me.Label46.Text = "オプション種別"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(95, 146)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(72, 12)
        Me.Label47.TabIndex = 91
        Me.Label47.Text = "オプション期間"
        '
        'lblOptionTime
        '
        Me.lblOptionTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOptionTime.Location = New System.Drawing.Point(172, 141)
        Me.lblOptionTime.Name = "lblOptionTime"
        Me.lblOptionTime.Size = New System.Drawing.Size(160, 23)
        Me.lblOptionTime.TabIndex = 92
        Me.lblOptionTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(436, 331)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(74, 12)
        Me.Label49.TabIndex = 93
        Me.Label49.Text = "行使ステータス"
        '
        'cbExercStatus
        '
        Me.cbExercStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercStatus.FormattingEnabled = True
        Me.cbExercStatus.Location = New System.Drawing.Point(575, 328)
        Me.cbExercStatus.Name = "cbExercStatus"
        Me.cbExercStatus.Size = New System.Drawing.Size(160, 20)
        Me.cbExercStatus.TabIndex = 94
        '
        'TradeForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(836, 748)
        Me.Controls.Add(Me.cbExercStatus)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.lblOptionTime)
        Me.Controls.Add(Me.lblOpType)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.tbExercPrice)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.tbExercRateTimeMilliseconds)
        Me.Controls.Add(Me.dtpExercRateTime)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.tbExercProcTimeMilliseconds)
        Me.Controls.Add(Me.dtpExercProcTime)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.tbAbandClientRateTimeMilliseconds)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.tbAbandReqTimeMilliseconds)
        Me.Controls.Add(Me.dtpAbandClientRateTime)
        Me.Controls.Add(Me.dtpAbandReqTime)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.tbOrderClientRateTimeMilliseconds)
        Me.Controls.Add(Me.dtpOrderClientRateTime)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.tbOrderReqTimeMilliseconds)
        Me.Controls.Add(Me.dtpOrderReqTime)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.tbTradeRateTimeMilliseconds)
        Me.Controls.Add(Me.dtpTradeRateTime)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.tbTradeTimeMilliseconds)
        Me.Controls.Add(Me.dtpTradeTime)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.tbInfoTitle)
        Me.Controls.Add(Me.dtpSysDate)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.tbMemo)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.tbInfo)
        Me.Controls.Add(Me.cbTradeStatus)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.lblPAndL)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.tbPayout)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.btnRateSeqExerc)
        Me.Controls.Add(Me.tbExercRate)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.tbExercRateSeq)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.btnRateSeqAband)
        Me.Controls.Add(Me.tbAbandClientRate)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.tbAbandClientRateSeq)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.btnRateSeqOrder)
        Me.Controls.Add(Me.tbOrderClientRate)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.tbOrderClientRateSeq)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.btnRateSeqTrade)
        Me.Controls.Add(Me.btnProductRef)
        Me.Controls.Add(Me.tbTradeRate)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.tbTradeRateSeq)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.tbCustCode)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tbPremium)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cbTradeType)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblExercTime)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblPayoutRate)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblComName)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbProductCode)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "TradeForm"
        Me.Text = "取引データ登録"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbProductCode As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblComName As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblPayoutRate As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblExercTime As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbTradeType As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tbPremium As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbCustCode As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbTradeRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tbTradeRate As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnProductRef As System.Windows.Forms.Button
    Friend WithEvents btnRateSeqTrade As System.Windows.Forms.Button
    Friend WithEvents btnRateSeqOrder As System.Windows.Forms.Button
    Friend WithEvents tbOrderClientRate As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tbOrderClientRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents btnRateSeqAband As System.Windows.Forms.Button
    Friend WithEvents tbAbandClientRate As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents tbAbandClientRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents btnRateSeqExerc As System.Windows.Forms.Button
    Friend WithEvents tbExercRate As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents tbExercRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents tbPayout As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents lblPAndL As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents cbTradeStatus As System.Windows.Forms.ComboBox
    Friend WithEvents tbInfo As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents tbMemo As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents dtpSysDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbInfoTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents dtpTradeTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbTradeTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents dtpTradeRateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbTradeRateTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents dtpOrderReqTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbOrderReqTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents dtpOrderClientRateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbOrderClientRateTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents dtpAbandReqTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpAbandClientRateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAbandReqTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents tbAbandClientRateTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents dtpExercProcTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbExercProcTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents dtpExercRateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbExercRateTimeMilliseconds As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents tbExercPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents lblOpType As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents lblOptionTime As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents cbExercStatus As ComboBox
End Class
