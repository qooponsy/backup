﻿Imports System.Text

Public Class ProductBaseList

    Private WithEvents service As New ProductBaseService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As New DataTable
    Private view As New DataView

    Private Sub ProductBaseList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        btnRegist.Enabled = editable
        miEdit.Text = IIf(editable, "編集", "参照")
        miCopy.Enabled = editable
        btnSpreadChange.Enabled = editable

        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Me.cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        Me.cbComCode.SelectedValue = ""

        Me.cbOpType.DisplayMember = "Name"
        Me.cbOpType.ValueMember = "Code"
        Me.cbOpType.DataSource = OptionTypeManager.GetListWithAll()

        Me.cbOpType.SelectedValue = ""

        MainWindow.SubFormProductBase = True
        grid.AutoGenerateColumns = False
        LoadSettings()

        request()
    End Sub

    Private Sub ProductBaseList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormProductBase = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        clsUtil.LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductBaseList_Columns)
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.ProductBaseList_ComCode
        cbOpType.SelectedValue = UserSettings.getInstance().DataSaved.ProductBaseList_OpType
        chkEnabled.Checked = UserSettings.getInstance().DataSaved.ProductBaseList_Enabled
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        clsUtil.SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductBaseList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductBaseList_Columns)
        UserSettings.getInstance().DataSaved.ProductBaseList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.ProductBaseList_OpType = cbOpType.SelectedValue
        UserSettings.getInstance().DataSaved.ProductBaseList_Enabled = chkEnabled.Checked
    End Sub

    Private Sub setGrid(ProductBaseDataList As List(Of ProductBaseData))
        Table = New DataTable

        grid.Columns(9).HeaderText = "生成開始時間" & vbCrLf & "（夏時間）"
        grid.Columns(10).HeaderText = "最終行使期日" & vbCrLf & "（夏時間）"
        grid.Columns(14).HeaderText = "取引停止" & vbCrLf & "時間(秒)"
        grid.Columns(15).HeaderText = "権利放棄" & vbCrLf & "手数料(%)"
        grid.Columns(16).HeaderText = "ボラティリティ" & vbCrLf & "レシオ(%)"
        grid.Columns(19).HeaderText = "変更" & vbCrLf & "スプレッド"
        grid.Columns(20).HeaderText = "変更" & vbCrLf & "最小取引額"
        grid.Columns(21).HeaderText = "変更" & vbCrLf & "最大取引額"
        grid.Columns(22).HeaderText = "権利放棄可能" & vbCrLf & "時間(秒)"
        grid.Columns(23).HeaderText = "権利放棄可能" & vbCrLf & "価格差(pips)"
        grid.Columns(24).HeaderText = "最小取引額" & vbCrLf & "(1回)銘柄"
        grid.Columns(25).HeaderText = "最大取引額" & vbCrLf & "(1回)銘柄"

        Table.Columns.Add("ProductBaseCode", GetType(String))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("OpTypeCode", GetType(String))
        Table.Columns.Add("OpType", GetType(String))
        Table.Columns.Add("OptionTime", GetType(String))
        Table.Columns.Add("CreateTime", GetType(String))
        Table.Columns.Add("StartTime", GetType(String))
        Table.Columns.Add("ExercTime", GetType(String))
        Table.Columns.Add("StartSummerTime", GetType(String))
        Table.Columns.Add("ExercSummerTime", GetType(String))
        Table.Columns.Add("PayoutRate", GetType(Decimal))
        Table.Columns.Add("Spread", GetType(Integer))
        Table.Columns.Add("ProductBaseEnabledCode", GetType(String))
        Table.Columns.Add("StopTradeTime", GetType(Integer))
        Table.Columns.Add("AbandMargine", GetType(Decimal))
        Table.Columns.Add("VolatilityAdjust", GetType(Decimal))
        Table.Columns.Add("ProductBaseEnabled", GetType(String))
        Table.Columns.Add("SpreadUpdateTarget", GetType(Boolean))
        Table.Columns.Add("SpreadUpdate", GetType(Integer))
        Table.Columns.Add("TradeMoneyMinUpdate", GetType(Integer))
        Table.Columns.Add("TradeMoneyMaxUpdate", GetType(Integer))
        Table.Columns.Add("StartAbandTime", GetType(Integer))
        Table.Columns.Add("AbandPriceDiff", GetType(Integer))
        Table.Columns.Add("TradeMoneyMin", GetType(String))
        Table.Columns.Add("TradeMoneyMax", GetType(String))
        If Not ProductBaseDataList Is Nothing Then
            For i As Integer = 0 To ProductBaseDataList.Count - 1
                Dim row As DataRow = Table.NewRow()

                row("ProductBaseCode") = ProductBaseDataList(i).ProductBaseCode
                row("ComCode") = CurrencyPairService.GetData(ProductBaseDataList(i).ComCode).ComCode
                row("ComName") = CurrencyPairService.GetData(ProductBaseDataList(i).ComCode).ComName
                row("OpTypeCode") = ProductBaseDataList(i).OpType
                row("OpType") = OptionTypeManager.GetOptionTypeName(ProductBaseDataList(i).OpType)
                row("OptionTime") = DateTimeUtil.TimeConvView(ProductBaseDataList(i).OptionTime)
                row("CreateTime") = DateTimeUtil.TimeConvView(ProductBaseDataList(i).CreateTime)
                row("StartTime") = String.Format("{0:00}:{1:00}:{2:00}", ProductBaseDataList(i).StartTime.Hours, ProductBaseDataList(i).StartTime.Minutes, ProductBaseDataList(i).StartTime.Seconds)
                row("ExercTime") = String.Format("{0:00}:{1:00}:{2:00}", ProductBaseDataList(i).ExercTime.Hours, ProductBaseDataList(i).ExercTime.Minutes, ProductBaseDataList(i).ExercTime.Seconds)
                row("StartSummerTime") = String.Format("{0:00}:{1:00}:{2:00}", ProductBaseDataList(i).StartSummerTime.Hours, ProductBaseDataList(i).StartSummerTime.Minutes, ProductBaseDataList(i).StartSummerTime.Seconds)
                row("ExercSummerTime") = String.Format("{0:00}:{1:00}:{2:00}", ProductBaseDataList(i).ExercSummerTime.Hours, ProductBaseDataList(i).ExercSummerTime.Minutes, ProductBaseDataList(i).ExercSummerTime.Seconds)
                row("PayoutRate") = ProductBaseDataList(i).PayoutRate
                row("Spread") = ProductBaseDataList(i).Spread
                row("ProductBaseEnabledCode") = ProductBaseDataList(i).ProductBaseEnabled
                row("StopTradeTime") = ProductBaseDataList(i).StopTradeTime
                row("AbandMargine") = (ProductBaseDataList(i).AbandMargine * 100)
                row("VolatilityAdjust") = (ProductBaseDataList(i).VolatilityAdjust * 100)
                row("ProductBaseEnabled") = ProductBaseDataList(i).EnabledName()
                row("SpreadUpdateTarget") = False
                If ProductBaseDataList(i).SpreadUpdateEnabled Then
                    row("SpreadUpdate") = ProductBaseDataList(i).SpreadUpdate
                Else
                    row("SpreadUpdate") = DBNull.Value
                End If
                row("StartAbandTime") = ProductBaseDataList(i).StartAbandTime
                row("AbandPriceDiff") = ProductBaseDataList(i).AbandPriceDiff
                row("TradeMoneyMin") = ProductBaseDataList(i).TradeMoneyMin.ToString(clsUtil.GetMoneyFormatEdit())
                row("TradeMoneyMax") = ProductBaseDataList(i).TradeMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
                If ProductBaseDataList(i).TradeMoneyMinUpdateEnabled AndAlso ProductBaseDataList(i).TradeMoneyMinUpdate <> -1 Then
                    row("TradeMoneyMinUpdate") = ProductBaseDataList(i).TradeMoneyMinUpdate
                Else
                    row("TradeMoneyMinUpdate") = DBNull.Value
                End If
                If ProductBaseDataList(i).TradeMoneyMaxUpdateEnabled AndAlso ProductBaseDataList(i).TradeMoneyMaxUpdate <> -1 Then
                    row("TradeMoneyMaxUpdate") = ProductBaseDataList(i).TradeMoneyMaxUpdate
                Else
                    row("TradeMoneyMaxUpdate") = DBNull.Value
                End If

                Table.Rows.Add(row)
            Next
        End If

        view = New DataView(Table)
        grid.DataSource = view
        setGridFilter()
    End Sub

    Private Sub cbComCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbComCode.SelectedIndexChanged
        setGridFilter()
    End Sub

    Private Sub cbOpType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbOpType.SelectedIndexChanged
        setGridFilter()
    End Sub

    Private Sub chkEnabled_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkEnabled.CheckedChanged
        setGridFilter()
    End Sub

    Private Sub btnReflesh_Click(sender As System.Object, e As System.EventArgs) Handles btnReflesh.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                request()
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("ProductBaseCode").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductBaseCode").Value
        edit(code)
    End Sub

    Private Sub miCopy_Click(sender As System.Object, e As System.EventArgs) Handles miCopy.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductBaseCode").Value
        copy(code)
    End Sub

    Private Sub request()
        service.ReadList()
        formModeStatus = FormMode.READ
        btnReflesh.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnReflesh.Text = "更新"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of ProductBaseData)) Handles service.ReadSuccess
        setGrid(list)
        requestEnd()
    End Sub

    Private Sub setGridFilter()
        Dim strFilter As String = ""
        '通貨ペア
        If cbComCode.SelectedValue <> "" Then
            strFilter = "ComCode = '" & cbComCode.SelectedValue & "'"
        End If
        'オプション種別
        If cbOpType.SelectedValue <> "" Then
            If strFilter <> "" Then
                strFilter = strFilter & " AND "
            End If
            strFilter = strFilter & "OpTypeCode = '" & cbOpType.SelectedValue & "'"
        End If
        '有効フラグ
        If chkEnabled.Checked Then
            If strFilter <> "" Then
                strFilter = strFilter & " AND "
            End If
            strFilter = strFilter & "ProductBaseEnabledCode = '" & ProductBaseData.EnabledCode.Enabled & "'"
        End If
        view.RowFilter = strFilter
        grid.DataSource = view
        lblNoData.Visible = (grid.RowCount = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = MainWindow
        ProductBaseForm.Code = ""
        ProductBaseForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = MainWindow
        ProductBaseForm.Code = code
        ProductBaseForm.Show()
    End Sub

    Private Sub copy(code As String)
        If MainWindow.SubFormProductBaseForm Then
            ProductBaseForm.Close()
        End If
        ProductBaseForm.MdiParent = MainWindow
        ProductBaseForm.Code = code
        ProductBaseForm.ModeCopyFlg = True
        ProductBaseForm.Show()
    End Sub

    Private Sub btnSpreadChange_Click(sender As System.Object, e As System.EventArgs) Handles btnSpreadChange.Click
        Dim ProductBaseCodeList As New StringBuilder
        Dim first As Boolean = True
        Dim count As Integer = 0
        For Each row As DataRow In Table.Rows
            If row("SpreadUpdateTarget") Then
                If first Then
                    first = False
                Else
                    ProductBaseCodeList.Append(",")
                End If
                ProductBaseCodeList.Append(row("ProductBaseCode"))
                count += 1
            End If
        Next
        If first Then
            MessageBox.Show(Me, "「変更」欄をチェックしてスプレッドの変更対象を選択してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        If count > 50 Then
            MessageBox.Show(Me, "一度に選択できるスプレッドの変更対象は50個までです。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim dlg As New ProductSpreadBulkChange
        dlg.ProductBaseCodeList = ProductBaseCodeList.ToString()
        dlg.ShowDialog(Me)
    End Sub

    Private Sub btnTradeMoneyChange_Click(sender As System.Object, e As System.EventArgs) Handles btnTradeMoneyChange.Click
        Dim ProductBaseCodeList As New StringBuilder
        Dim first As Boolean = True
        Dim count As Integer = 0
        For Each row As DataRow In Table.Rows
            If row("SpreadUpdateTarget") Then
                If first Then
                    first = False
                Else
                    ProductBaseCodeList.Append(",")
                End If
                ProductBaseCodeList.Append(row("ProductBaseCode"))
                count += 1
            End If
        Next
        If first Then
            MessageBox.Show(Me, "「変更」欄をチェックして最小最大取引額の変更対象を選択してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        If count > 50 Then
            MessageBox.Show(Me, "一度に選択できる最小最大取引額の変更対象は50個までです。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim dlg As New ProductTradeMoneyBulkChange
        dlg.ProductBaseCodeList = ProductBaseCodeList.ToString()
        dlg.ShowDialog(Me)
    End Sub

End Class