﻿Imports System.IO
Imports System.IO.Compression
Imports System.Text

Public Class TradeAccountSummaryDownload

    Private Const FILENAME_ZIP As String = "取引口座集計結果.zip"
    Private Const FILENAME_DETAIL_CSV As String = "口座明細.csv"
    Private Const FILENAME_SUMMARY_CSV As String = "集計結果.csv"
    Private Const ITEM_START As String = "," & """"
    Private Const ITEM_END As String = """"
    Private Const CANCEL_TRADEACCOUNT_EMAIL As String = "hiroseukreport@hotmail.co.uk"

    Private WithEvents service As New TradeAccountSummaryDownloadService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum
    Private Enum Mt4CsvCol
        CUSTCODE = 0
        EMAIL = 2
        COUNTRY = 12
        GROUP = 3
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT
    Private pbForm As DownloadTradeAccountSummaryProgressStatus
    Private SavePath As String

    Private Sub TradeAccountSummaryDownload_Load(sender As Object, e As EventArgs) Handles Me.Load

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"

        Dim cmpCodeList As List(Of CompanyData) = CompanyService.GetList()

        '取引口座集計機能では「Labuan」を一番上にするためReverceする
        cmpCodeList.Reverse()
        Dim item As New CompanyData With {
            .CmpCode = "",
            .CmpName = "全て",
            .CmpNameAnother = "合計"}
        cmpCodeList.Add(item)
        cbCmpCode.DataSource = cmpCodeList

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        Dim SysDatePrev As DateTime = clsUtil.GetPrevWorkDay(SysDate)
        dtpFromDateTime.Value = New DateTime(SysDatePrev.Year, SysDatePrev.Month, SysDatePrev.Day)
        dtpFromDateTime.Checked = False
        dtpToDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
        dtpToDateTime.Checked = False

        MainWindow.SubFormTradeAccountSummaryDownload = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        formModeStatus = FormMode.NORMAL

    End Sub

    Private Sub TradeAccountSummaryDownload_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormTradeAccountSummaryDownload = False
    End Sub


    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me,
            UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_FormMaximized,
            UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_FormSize,
            UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_FormLocation)

        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_CmpCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me,
            UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_FormMaximized,
            UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_FormSize,
            UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_FormLocation)

        UserSettings.getInstance().DataSaved.TradeAccountSummaryDownload_CmpCode = cbCmpCode.SelectedValue
    End Sub

    Private Sub btnSelectFile_Click(sender As Object, e As EventArgs) Handles btnSelectFile.Click

        Dim ofd As New OpenFileDialog()
        ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
        ofd.Filter = "CSVファイル(*.csv)|*.csv|すべてのファイル(*.*)|*.*"
        ofd.Title = "開くファイルを選択してください。"

        If ofd.ShowDialog(Me) = DialogResult.OK Then
            tbFilepath.Text = ofd.FileName
        End If
    End Sub


    Private Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click
        SelectDownload()
    End Sub

    Private Sub SelectDownload()

        Dim FilePath As String = tbFilepath.Text
        If Not File.Exists(FilePath) Then
            MessageBox.Show("指定されたパスにファイルが存在しません。")
            tbFilepath.Focus()
            Exit Sub
        End If

        Dim sfd As New SaveFileDialog()
        sfd.Title = "保存先のファイルを選択してください。"
        sfd.Filter = "ZIPファイル(*.zip)|*.zip"
        sfd.FileName = FILENAME_ZIP

        If sfd.ShowDialog(Me) = DialogResult.OK Then
            ' 保存先が選択されたらダウンロード処理
            SavePath = sfd.FileName

            pbForm = New DownloadTradeAccountSummaryProgressStatus
            pbForm.Init(1) ' ダウンロードは1ファイルのみ
            pbForm.Service = service
            pbForm.MdiParent = Me.ParentForm
            pbForm.ParentSubForm = Me
            pbForm.Show()
            Me.Enabled = False

            downloadRequest()
        End If

    End Sub

    Private Sub downloadRequest()
        Dim downloadExist As Boolean = False
        If pbForm.Cancel Then
            MessageBox.Show("ファイルのダウンロードを中断しました。",
                        "エラー",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error)
        Else
            Dim SysDate As String = Me.dtpSysDateTime.Value.ToString("yyyyMMdd")
            Dim CmpCode As String = Me.cbCmpCode.SelectedValue
            Dim FromRegTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMdd"), "")
            Dim ToRegTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMdd"), "")

            service.ReadList(SysDate, CmpCode, FromRegTime, ToRegTime)
            downloadExist = True
        End If

        If Not downloadExist Then
            Me.Enabled = True
            pbForm.EndDownload()
            pbForm.Service = Nothing
            pbForm = Nothing
        End If

    End Sub

    Private Sub service_DownloadCancel() Handles service.ReadCancel
        downloadRequest()
    End Sub

    Private Sub service_DownloadError(ErrorMessage As String) Handles service.ReadError
        Me.Enabled = True
        pbForm.EndDownload()
        pbForm.Service = Nothing
        pbForm.ParentSubForm = Nothing
        pbForm = Nothing
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub service_DownloadSuccess(tadList As List(Of TradeAccountData)) Handles service.ReadSuccess

        'MT4 status report 存在チェック
        Dim FilePath As String = tbFilepath.Text

        If Not File.Exists(FilePath) Then
            MessageBox.Show("指定されたパスにファイルが存在しません。")
            Me.Enabled = True
            pbForm.EndDownload()
            pbForm.Service = Nothing
            pbForm = Nothing
            tbFilepath.Focus()
            Exit Sub
        End If

        'MT4 status report 読み込み
        Dim dicMt4Tad As New Dictionary(Of String, TradeAccountData)

        Using parser As New FileIO.TextFieldParser(FilePath, Encoding.GetEncoding("utf-8"))
            parser.TextFieldType = FileIO.FieldType.Delimited
            parser.SetDelimiters(",")
            parser.HasFieldsEnclosedInQuotes = True
            Dim record As String()
            record = parser.ReadFields()    'ヘッダ行は無視
            While Not parser.EndOfData
                Try
                    record = parser.ReadFields()
                    Dim mt4tad As New TradeAccountData
                    mt4tad.CustCode = record(Mt4CsvCol.CUSTCODE)
                    mt4tad.Email = record(Mt4CsvCol.EMAIL)
                    mt4tad.Country = record(Mt4CsvCol.COUNTRY)
                    mt4tad.Group = record(Mt4CsvCol.GROUP)
                    dicMt4Tad.Add(mt4tad.CustCode, mt4tad)
                Catch ex As Exception
                    MessageBox.Show("MT4 status reportの読み込みに失敗しました。")
                    Me.Enabled = True
                    pbForm.EndDownload()
                    pbForm.Service = Nothing
                    pbForm = Nothing
                    Exit Sub
                End Try
            End While
        End Using

        'ダウンロードした口座情報にMT4の情報を追加
        For Each tad As TradeAccountData In tadList
            Dim mt4tad As New TradeAccountData

            If dicMt4Tad.TryGetValue(tad.CustCode, mt4tad) Then
                tad.Email = mt4tad.Email
                tad.Country = mt4tad.Country
                tad.Group = mt4tad.Group
                If Strings.Right(tad.Group, 1) = "T" _
                Or tad.Country = "China" Then
                    'テスト口座または国が中国の口座
                    tad.SetTestEnable()
                End If
            Else
                'BO口座に存在して、MT4口座に存在しなかった口座
                tad.SetTestEnable()
            End If
        Next

        '集計
        Dim confTradeAccountNum As Integer = 0                 '(1)設定口座数(解約口座を含む)
        Dim confCancelTradeAccountNum As Integer = 0           '(2)設定口座のうちの解約口座数
        Dim confTradeAccountNotCancelNum As Integer = 0        '(3)設定口座数(解約口座を除く)
        Dim validTradeAccountNum As Integer = 0                '(4)有効口座数(解約口座を含む)
        Dim validCancelTradeAccountNum As Integer = 0          '(5)有効口座のうちの解約口座数
        Dim validTradeAccountNotCancelNum As Integer = 0       '(6)有効口座数(解約口座除く)
        For Each tad As TradeAccountData In tadList
            '(1)設定口座数(解約口座を含む)
            If tad.Test = TradeAccountData.TestFlag.Disable Then
                confTradeAccountNum += 1
                '(2)設定口座のうちの解約口座数
                If tad.Email = CANCEL_TRADEACCOUNT_EMAIL Then
                    confCancelTradeAccountNum += 1
                End If
                '(4)有効口座数(解約口座を含む)
                If tad.TotalMoney > 0 Then
                    validTradeAccountNum += 1
                    '(5)有効口座のうちの解約口座数
                    If tad.Email = CANCEL_TRADEACCOUNT_EMAIL Then
                        validCancelTradeAccountNum += 1
                    End If
                End If
            End If
        Next

        '(3)設定口座数(解約口座を除く) = (1) - (2)
        confTradeAccountNotCancelNum = confTradeAccountNum - confCancelTradeAccountNum
        '(6)有効口座数(解約口座除く) = (4) - (5)
        validTradeAccountNotCancelNum = validTradeAccountNum - validCancelTradeAccountNum

        '集計結果をCSVファイル化
        Dim summaryCSV As New StringBuilder
        summaryCSV.Append("""" & "" & ITEM_END)
        summaryCSV.Append(ITEM_START & "設定口座数" & ITEM_END)
        summaryCSV.Append(ITEM_START & "有効口座数" & ITEM_END)
        summaryCSV.Append(vbCrLf)
        summaryCSV.Append("""" & "解約含む" & ITEM_END)
        summaryCSV.Append("," & confTradeAccountNum.ToString)
        summaryCSV.Append("," & validTradeAccountNum.ToString)
        summaryCSV.Append(vbCrLf)
        summaryCSV.Append("""" & "解約口座" & ITEM_END)
        summaryCSV.Append("," & confCancelTradeAccountNum.ToString)
        summaryCSV.Append("," & validCancelTradeAccountNum.ToString)
        summaryCSV.Append(vbCrLf)
        summaryCSV.Append("""" & "解約除く" & ITEM_END)
        summaryCSV.Append("," & confTradeAccountNotCancelNum.ToString)
        summaryCSV.Append("," & validTradeAccountNotCancelNum.ToString)
        summaryCSV.Append(vbCrLf)

        '口座明細をCSVファイル化
        Dim tradeAccountCSV As New StringBuilder
        ' CSVファイルのヘッダー部分を作成
        Dim header As String() = {"委託者コード", "口座開設日時", "通貨種別",
                  "残高", "メールアドレス", "国", "Group", "テスト"}
        '口座明細CSVデータ作成
        tradeAccountCSV.Append(CreateCsvHeader(header))
        For Each item As TradeAccountData In tadList
            tradeAccountCSV.Append("""" & item.CustCode & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.RegTime.ToString("yyyy/MM/dd") & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.CurName & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.TotalMoney.ToString & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.Email & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.Country & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.Group & ITEM_END)
            tradeAccountCSV.Append(ITEM_START & item.Test.ToString & ITEM_END)
            tradeAccountCSV.Append(vbCrLf)
        Next
        ' バイナリに変換
        Dim summaryCSVOutByte() As Byte
        summaryCSVOutByte = Encoding.GetEncoding("shift_jis").GetBytes(summaryCSV.ToString())
        Dim tradeAccountCSVOutByte() As Byte
        tradeAccountCSVOutByte = Encoding.GetEncoding("shift_jis").GetBytes(tradeAccountCSV.ToString())

        Using ms As New MemoryStream()
            ' メモリストリーム上にZipArchiveを作成
            Using za As ZipArchive = New ZipArchive(ms, ZipArchiveMode.Create)
                Dim entry As ZipArchiveEntry

                entry = za.CreateEntry(FILENAME_DETAIL_CSV)
                Using es As Stream = entry.Open
                    es.Write(tradeAccountCSVOutByte, 0, tradeAccountCSVOutByte.Length)
                End Using
                entry = za.CreateEntry(FILENAME_SUMMARY_CSV)
                Using es As Stream = entry.Open
                    es.Write(summaryCSVOutByte, 0, summaryCSVOutByte.Length)
                End Using
            End Using
            ' CSVをZIP圧縮して指定箇所に作成
            Try
                Using StreamFile As New FileStream(SavePath, FileMode.Create)
                    Using StreamZIP As New BinaryWriter(StreamFile)
                        StreamZIP.Write(ms.ToArray())
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show(ex.Message)
                Me.Enabled = True
                pbForm.EndDownload()
                pbForm.Service = Nothing
                pbForm = Nothing
                Exit Sub
            End Try
        End Using

        pbForm.Progres()
        MessageBox.Show(Me, "ダウンロードが完了しました", My.Application.Info.Title, MessageBoxButtons.OK)

        Me.Enabled = True
        pbForm.EndDownload()
        pbForm.Service = Nothing
        pbForm = Nothing
    End Sub
    Private Shared Function CreateCsvHeader(ByVal calm As String()) As String

        Dim Result As New StringBuilder

        Dim init As Boolean = False
        For Each head In calm
            If init = False Then
                Result.Append("""" & head & """")
                init = True
            Else
                Result.Append(ITEM_START & head & ITEM_END)
            End If

        Next
        Result.Append(vbCrLf)

        Return Result.ToString
    End Function

End Class