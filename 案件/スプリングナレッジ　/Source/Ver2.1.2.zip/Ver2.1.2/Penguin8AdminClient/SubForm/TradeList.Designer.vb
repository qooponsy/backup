﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TradeList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle42 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle29 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle30 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle31 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle32 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle33 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle36 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle37 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle38 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle39 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle40 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle41 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCountryCode = New System.Windows.Forms.ComboBox()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.cbCurCode = New System.Windows.Forms.ComboBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.cbTradeStatus = New System.Windows.Forms.ComboBox()
        Me.btnCSV = New System.Windows.Forms.Button()
        Me.tbCustCode = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbProductCode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbTradeType = New System.Windows.Forms.ComboBox()
        Me.cbListType = New System.Windows.Forms.ComboBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbDateType = New System.Windows.Forms.ComboBox()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.sfdCsvFile = New System.Windows.Forms.SaveFileDialog()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.TradeSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OptionTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CurName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Premium = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderReqTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderClientRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderClientRateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OrderClientRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandReqTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandClientRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandClientRateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandClientRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeRateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercProcTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRateSeq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercPayoutRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Payout = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NetPAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeStatusName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandMoney = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InfoTitle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Info = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Memo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CountryName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.pnlSearchAdd.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbCountryCode)
        Me.Panel1.Controls.Add(Me.cbOpType)
        Me.Panel1.Controls.Add(Me.cbCurCode)
        Me.Panel1.Controls.Add(Me.btnPrint)
        Me.Panel1.Controls.Add(Me.cbTradeStatus)
        Me.Panel1.Controls.Add(Me.btnCSV)
        Me.Panel1.Controls.Add(Me.tbCustCode)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.tbProductCode)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.cbTradeType)
        Me.Panel1.Controls.Add(Me.cbListType)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Controls.Add(Me.cbDateType)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1049, 80)
        Me.Panel1.TabIndex = 11
        '
        'cbCountryCode
        '
        Me.cbCountryCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCountryCode.FormattingEnabled = True
        Me.cbCountryCode.Location = New System.Drawing.Point(393, 6)
        Me.cbCountryCode.Name = "cbCountryCode"
        Me.cbCountryCode.Size = New System.Drawing.Size(279, 20)
        Me.cbCountryCode.TabIndex = 21
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Location = New System.Drawing.Point(139, 30)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(121, 20)
        Me.cbOpType.TabIndex = 20
        '
        'cbCurCode
        '
        Me.cbCurCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCurCode.FormattingEnabled = True
        Me.cbCurCode.Location = New System.Drawing.Point(266, 6)
        Me.cbCurCode.Name = "cbCurCode"
        Me.cbCurCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCurCode.TabIndex = 18
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(862, 45)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(89, 29)
        Me.btnPrint.TabIndex = 15
        Me.btnPrint.Text = "印刷"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'cbTradeStatus
        '
        Me.cbTradeStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbTradeStatus.FormattingEnabled = True
        Me.cbTradeStatus.Location = New System.Drawing.Point(393, 30)
        Me.cbTradeStatus.Name = "cbTradeStatus"
        Me.cbTradeStatus.Size = New System.Drawing.Size(121, 20)
        Me.cbTradeStatus.TabIndex = 4
        '
        'btnCSV
        '
        Me.btnCSV.Location = New System.Drawing.Point(773, 45)
        Me.btnCSV.Name = "btnCSV"
        Me.btnCSV.Size = New System.Drawing.Size(89, 29)
        Me.btnCSV.TabIndex = 14
        Me.btnCSV.Text = "CSV出力"
        Me.btnCSV.UseVisualStyleBackColor = True
        '
        'tbCustCode
        '
        Me.tbCustCode.Location = New System.Drawing.Point(962, 12)
        Me.tbCustCode.Name = "tbCustCode"
        Me.tbCustCode.Size = New System.Drawing.Size(59, 19)
        Me.tbCustCode.TabIndex = 8
        Me.tbCustCode.Text = "1000050"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(888, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 12)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "委託者コード"
        '
        'tbProductCode
        '
        Me.tbProductCode.Location = New System.Drawing.Point(748, 12)
        Me.tbProductCode.Name = "tbProductCode"
        Me.tbProductCode.Size = New System.Drawing.Size(130, 19)
        Me.tbProductCode.TabIndex = 6
        Me.tbProductCode.Text = "20120305999999999"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(685, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 12)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "銘柄コード"
        '
        'cbTradeType
        '
        Me.cbTradeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbTradeType.FormattingEnabled = True
        Me.cbTradeType.Location = New System.Drawing.Point(266, 30)
        Me.cbTradeType.Name = "cbTradeType"
        Me.cbTradeType.Size = New System.Drawing.Size(121, 20)
        Me.cbTradeType.TabIndex = 3
        '
        'cbListType
        '
        Me.cbListType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbListType.FormattingEnabled = True
        Me.cbListType.Location = New System.Drawing.Point(139, 6)
        Me.cbListType.Name = "cbListType"
        Me.cbListType.Size = New System.Drawing.Size(121, 20)
        Me.cbListType.TabIndex = 1
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 6)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(951, 45)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 16
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(684, 45)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 13
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(317, 55)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 12
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(139, 55)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(294, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "～"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(12, 30)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 2
        '
        'cbDateType
        '
        Me.cbDateType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbDateType.FormattingEnabled = True
        Me.cbDateType.Location = New System.Drawing.Point(12, 54)
        Me.cbDateType.Name = "cbDateType"
        Me.cbDateType.Size = New System.Drawing.Size(121, 20)
        Me.cbDateType.TabIndex = 9
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 460)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(1049, 32)
        Me.pnlSearchAdd.TabIndex = 18
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 17
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TradeSeq, Me.ProductCode, Me.ComCode, Me.ComName, Me.OpType, Me.OpTypeName, Me.OptionTime, Me.PayoutRate, Me.ExercTime, Me.SysDate, Me.TradeType, Me.TradeTypeName, Me.CurName, Me.Premium, Me.CustCode, Me.OrderReqTime, Me.OrderClientRateSeq, Me.OrderClientRateTime, Me.OrderClientRate, Me.AbandReqTime, Me.AbandClientRateSeq, Me.AbandClientRateTime, Me.AbandClientRate, Me.TradeTime, Me.TradeRateSeq, Me.TradeRateTime, Me.TradeRate, Me.ExercPrice, Me.ExercProcTime, Me.ExercRateSeq, Me.ExercRateTime, Me.ExercRate, Me.ExercPayoutRate, Me.Payout, Me.NetPAndL, Me.TradeStatus, Me.TradeStatusName, Me.AbandMoney, Me.InfoTitle, Me.Info, Me.Memo, Me.CountryName})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 80)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle42.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle42
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(1049, 380)
        Me.grid.TabIndex = 17
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(101, 26)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(100, 22)
        Me.miEdit.Text = "編集"
        '
        'sfdCsvFile
        '
        Me.sfdCsvFile.DefaultExt = "csv"
        Me.sfdCsvFile.Filter = "csvファイル(*.csv)|*.csv"
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(355, 215)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(232, 63)
        Me.lblNoData.TabIndex = 20
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TradeSeq
        '
        Me.TradeSeq.DataPropertyName = "TradeSeq"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeSeq.DefaultCellStyle = DataGridViewCellStyle2
        Me.TradeSeq.HeaderText = "注文番号"
        Me.TradeSeq.Name = "TradeSeq"
        Me.TradeSeq.ReadOnly = True
        Me.TradeSeq.Width = 108
        '
        'ProductCode
        '
        Me.ProductCode.DataPropertyName = "ProductCode"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.NullValue = Nothing
        Me.ProductCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.ProductCode.HeaderText = "銘柄コード"
        Me.ProductCode.Name = "ProductCode"
        Me.ProductCode.ReadOnly = True
        Me.ProductCode.Width = 108
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle4
        Me.ComCode.HeaderText = "通貨ペア(Code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.Visible = False
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle5
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 80
        '
        'OpType
        '
        Me.OpType.DataPropertyName = "OpType"
        Me.OpType.HeaderText = "オプション種別(Code)"
        Me.OpType.Name = "OpType"
        Me.OpType.ReadOnly = True
        Me.OpType.Visible = False
        '
        'OpTypeName
        '
        Me.OpTypeName.DataPropertyName = "OpTypeName"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OpTypeName.DefaultCellStyle = DataGridViewCellStyle6
        Me.OpTypeName.HeaderText = "オプション種別"
        Me.OpTypeName.Name = "OpTypeName"
        Me.OpTypeName.ReadOnly = True
        Me.OpTypeName.Width = 97
        '
        'OptionTime
        '
        Me.OptionTime.DataPropertyName = "OptionTime"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.Format = "####秒"
        Me.OptionTime.DefaultCellStyle = DataGridViewCellStyle7
        Me.OptionTime.HeaderText = "オプション期間"
        Me.OptionTime.Name = "OptionTime"
        Me.OptionTime.ReadOnly = True
        '
        'PayoutRate
        '
        Me.PayoutRate.DataPropertyName = "PayoutRate"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "######0.00######"
        DataGridViewCellStyle8.NullValue = Nothing
        Me.PayoutRate.DefaultCellStyle = DataGridViewCellStyle8
        Me.PayoutRate.HeaderText = "ペイアウト率"
        Me.PayoutRate.Name = "PayoutRate"
        Me.PayoutRate.ReadOnly = True
        Me.PayoutRate.Width = 62
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.Format = "yyyy/MM/dd HH:mm"
        DataGridViewCellStyle9.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle9
        Me.ExercTime.HeaderText = "行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        Me.ExercTime.Width = 96
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.Format = "yyyy/MM/dd"
        Me.SysDate.DefaultCellStyle = DataGridViewCellStyle10
        Me.SysDate.HeaderText = "取引日"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.ReadOnly = True
        Me.SysDate.Width = 80
        '
        'TradeType
        '
        Me.TradeType.DataPropertyName = "TradeType"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeType.DefaultCellStyle = DataGridViewCellStyle11
        Me.TradeType.HeaderText = "種別(Code)"
        Me.TradeType.Name = "TradeType"
        Me.TradeType.ReadOnly = True
        Me.TradeType.Visible = False
        '
        'TradeTypeName
        '
        Me.TradeTypeName.DataPropertyName = "TradeTypeName"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeTypeName.DefaultCellStyle = DataGridViewCellStyle12
        Me.TradeTypeName.FillWeight = 80.0!
        Me.TradeTypeName.HeaderText = "種別"
        Me.TradeTypeName.Name = "TradeTypeName"
        Me.TradeTypeName.ReadOnly = True
        Me.TradeTypeName.Width = 56
        '
        'CurName
        '
        Me.CurName.DataPropertyName = "CurName"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CurName.DefaultCellStyle = DataGridViewCellStyle13
        Me.CurName.HeaderText = "通貨種別"
        Me.CurName.Name = "CurName"
        Me.CurName.ReadOnly = True
        '
        'Premium
        '
        Me.Premium.DataPropertyName = "Premium"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle14.Format = "#,###,###,##0.####"
        Me.Premium.DefaultCellStyle = DataGridViewCellStyle14
        Me.Premium.HeaderText = "金額"
        Me.Premium.Name = "Premium"
        Me.Premium.ReadOnly = True
        Me.Premium.Width = 74
        '
        'CustCode
        '
        Me.CustCode.DataPropertyName = "CustCode"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CustCode.DefaultCellStyle = DataGridViewCellStyle15
        Me.CustCode.HeaderText = "委託者コード"
        Me.CustCode.Name = "CustCode"
        Me.CustCode.ReadOnly = True
        Me.CustCode.Width = 69
        '
        'OrderReqTime
        '
        Me.OrderReqTime.DataPropertyName = "OrderReqTime"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle16.Format = "yyyy/MM/dd HH:mm:ss"
        Me.OrderReqTime.DefaultCellStyle = DataGridViewCellStyle16
        Me.OrderReqTime.HeaderText = "注文時間"
        Me.OrderReqTime.Name = "OrderReqTime"
        Me.OrderReqTime.ReadOnly = True
        Me.OrderReqTime.Width = 130
        '
        'OrderClientRateSeq
        '
        Me.OrderClientRateSeq.DataPropertyName = "OrderClientRateSeq"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OrderClientRateSeq.DefaultCellStyle = DataGridViewCellStyle17
        Me.OrderClientRateSeq.HeaderText = "注文時価格Seq"
        Me.OrderClientRateSeq.Name = "OrderClientRateSeq"
        Me.OrderClientRateSeq.ReadOnly = True
        Me.OrderClientRateSeq.Width = 111
        '
        'OrderClientRateTime
        '
        Me.OrderClientRateTime.DataPropertyName = "OrderClientRateTime"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle18.Format = "yyyy/MM/dd HH:mm:ss"
        Me.OrderClientRateTime.DefaultCellStyle = DataGridViewCellStyle18
        Me.OrderClientRateTime.HeaderText = "注文時価格時間"
        Me.OrderClientRateTime.Name = "OrderClientRateTime"
        Me.OrderClientRateTime.ReadOnly = True
        Me.OrderClientRateTime.Width = 130
        '
        'OrderClientRate
        '
        Me.OrderClientRate.DataPropertyName = "OrderClientRate"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle19.Format = "######0.000#####"
        Me.OrderClientRate.DefaultCellStyle = DataGridViewCellStyle19
        Me.OrderClientRate.HeaderText = "注文時価格"
        Me.OrderClientRate.Name = "OrderClientRate"
        Me.OrderClientRate.ReadOnly = True
        Me.OrderClientRate.Width = 72
        '
        'AbandReqTime
        '
        Me.AbandReqTime.DataPropertyName = "AbandReqTime"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle20.Format = "yyyy/MM/dd HH:mm:ss"
        Me.AbandReqTime.DefaultCellStyle = DataGridViewCellStyle20
        Me.AbandReqTime.HeaderText = "放棄時間"
        Me.AbandReqTime.Name = "AbandReqTime"
        Me.AbandReqTime.ReadOnly = True
        Me.AbandReqTime.Width = 130
        '
        'AbandClientRateSeq
        '
        Me.AbandClientRateSeq.DataPropertyName = "AbandClientRateSeq"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.AbandClientRateSeq.DefaultCellStyle = DataGridViewCellStyle21
        Me.AbandClientRateSeq.HeaderText = "放棄時価格Seq"
        Me.AbandClientRateSeq.Name = "AbandClientRateSeq"
        Me.AbandClientRateSeq.ReadOnly = True
        Me.AbandClientRateSeq.Width = 108
        '
        'AbandClientRateTime
        '
        Me.AbandClientRateTime.DataPropertyName = "AbandClientRateTime"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle22.Format = "yyyy/MM/dd HH:mm:ss"
        Me.AbandClientRateTime.DefaultCellStyle = DataGridViewCellStyle22
        Me.AbandClientRateTime.HeaderText = "放棄時価格時間"
        Me.AbandClientRateTime.Name = "AbandClientRateTime"
        Me.AbandClientRateTime.ReadOnly = True
        Me.AbandClientRateTime.Width = 130
        '
        'AbandClientRate
        '
        Me.AbandClientRate.DataPropertyName = "AbandClientRate"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle23.Format = "######0.000#####"
        Me.AbandClientRate.DefaultCellStyle = DataGridViewCellStyle23
        Me.AbandClientRate.HeaderText = "放棄時価格"
        Me.AbandClientRate.Name = "AbandClientRate"
        Me.AbandClientRate.ReadOnly = True
        Me.AbandClientRate.Width = 72
        '
        'TradeTime
        '
        Me.TradeTime.DataPropertyName = "TradeTime"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle24.Format = "yyyy/MM/dd HH:mm:ss"
        Me.TradeTime.DefaultCellStyle = DataGridViewCellStyle24
        Me.TradeTime.HeaderText = "約定時間"
        Me.TradeTime.Name = "TradeTime"
        Me.TradeTime.ReadOnly = True
        Me.TradeTime.Width = 130
        '
        'TradeRateSeq
        '
        Me.TradeRateSeq.DataPropertyName = "TradeRateSeq"
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeRateSeq.DefaultCellStyle = DataGridViewCellStyle25
        Me.TradeRateSeq.HeaderText = "約定時価格Seq"
        Me.TradeRateSeq.Name = "TradeRateSeq"
        Me.TradeRateSeq.ReadOnly = True
        Me.TradeRateSeq.Width = 108
        '
        'TradeRateTime
        '
        Me.TradeRateTime.DataPropertyName = "TradeRateTime"
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle26.Format = "yyyy/MM/dd HH:mm:ss"
        Me.TradeRateTime.DefaultCellStyle = DataGridViewCellStyle26
        Me.TradeRateTime.HeaderText = "約定時価格時間"
        Me.TradeRateTime.Name = "TradeRateTime"
        Me.TradeRateTime.ReadOnly = True
        Me.TradeRateTime.Width = 130
        '
        'TradeRate
        '
        Me.TradeRate.DataPropertyName = "TradeRate"
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle27.Format = "######0.000#####"
        Me.TradeRate.DefaultCellStyle = DataGridViewCellStyle27
        Me.TradeRate.HeaderText = "約定時価格"
        Me.TradeRate.Name = "TradeRate"
        Me.TradeRate.ReadOnly = True
        Me.TradeRate.Width = 93
        '
        'ExercPrice
        '
        Me.ExercPrice.DataPropertyName = "ExercPrice"
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle28.Format = "######0.000#####"
        Me.ExercPrice.DefaultCellStyle = DataGridViewCellStyle28
        Me.ExercPrice.HeaderText = "行使価格"
        Me.ExercPrice.Name = "ExercPrice"
        Me.ExercPrice.ReadOnly = True
        Me.ExercPrice.Width = 93
        '
        'ExercProcTime
        '
        Me.ExercProcTime.DataPropertyName = "ExercProcTime"
        DataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle29.Format = "yyyy/MM/dd HH:mm:ss"
        Me.ExercProcTime.DefaultCellStyle = DataGridViewCellStyle29
        Me.ExercProcTime.HeaderText = "行使処理時間"
        Me.ExercProcTime.Name = "ExercProcTime"
        Me.ExercProcTime.ReadOnly = True
        Me.ExercProcTime.Width = 130
        '
        'ExercRateSeq
        '
        Me.ExercRateSeq.DataPropertyName = "ExercRateSeq"
        DataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercRateSeq.DefaultCellStyle = DataGridViewCellStyle30
        Me.ExercRateSeq.HeaderText = "行使時価格Seq"
        Me.ExercRateSeq.Name = "ExercRateSeq"
        Me.ExercRateSeq.ReadOnly = True
        Me.ExercRateSeq.Width = 108
        '
        'ExercRateTime
        '
        Me.ExercRateTime.DataPropertyName = "ExercRateTime"
        DataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle31.Format = "yyyy/MM/dd HH:mm:ss"
        Me.ExercRateTime.DefaultCellStyle = DataGridViewCellStyle31
        Me.ExercRateTime.HeaderText = "行使時価格時間"
        Me.ExercRateTime.Name = "ExercRateTime"
        Me.ExercRateTime.ReadOnly = True
        Me.ExercRateTime.Width = 130
        '
        'ExercRate
        '
        Me.ExercRate.DataPropertyName = "ExercRate"
        DataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle32.Format = "######0.000#####"
        Me.ExercRate.DefaultCellStyle = DataGridViewCellStyle32
        Me.ExercRate.HeaderText = "行使時価格"
        Me.ExercRate.Name = "ExercRate"
        Me.ExercRate.ReadOnly = True
        Me.ExercRate.Width = 72
        '
        'ExercPayoutRate
        '
        Me.ExercPayoutRate.DataPropertyName = "ExercPayoutRate"
        DataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle33.Format = "######0.0000####"
        Me.ExercPayoutRate.DefaultCellStyle = DataGridViewCellStyle33
        Me.ExercPayoutRate.HeaderText = "期限前権利放棄ペイアウト率"
        Me.ExercPayoutRate.Name = "ExercPayoutRate"
        Me.ExercPayoutRate.ReadOnly = True
        '
        'Payout
        '
        Me.Payout.DataPropertyName = "Payout"
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle34.Format = "#,###,###,##0.####"
        Me.Payout.DefaultCellStyle = DataGridViewCellStyle34
        Me.Payout.HeaderText = "ペイアウト額"
        Me.Payout.Name = "Payout"
        Me.Payout.ReadOnly = True
        Me.Payout.Width = 88
        '
        'NetPAndL
        '
        Me.NetPAndL.DataPropertyName = "NetPAndL"
        DataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle35.Format = "#,###,###,##0.####"
        Me.NetPAndL.DefaultCellStyle = DataGridViewCellStyle35
        Me.NetPAndL.HeaderText = "Net損益"
        Me.NetPAndL.Name = "NetPAndL"
        Me.NetPAndL.ReadOnly = True
        Me.NetPAndL.Width = 84
        '
        'TradeStatus
        '
        Me.TradeStatus.DataPropertyName = "TradeStatus"
        DataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeStatus.DefaultCellStyle = DataGridViewCellStyle36
        Me.TradeStatus.HeaderText = "取引ステータス(Code)"
        Me.TradeStatus.Name = "TradeStatus"
        Me.TradeStatus.ReadOnly = True
        Me.TradeStatus.Visible = False
        '
        'TradeStatusName
        '
        Me.TradeStatusName.DataPropertyName = "TradeStatusName"
        DataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.TradeStatusName.DefaultCellStyle = DataGridViewCellStyle37
        Me.TradeStatusName.HeaderText = "取引ステータス"
        Me.TradeStatusName.Name = "TradeStatusName"
        Me.TradeStatusName.ReadOnly = True
        Me.TradeStatusName.Width = 106
        '
        'AbandMoney
        '
        Me.AbandMoney.DataPropertyName = "AbandMoney"
        DataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle38.Format = "#,###,###,##0.####"
        Me.AbandMoney.DefaultCellStyle = DataGridViewCellStyle38
        Me.AbandMoney.HeaderText = "未実現損益"
        Me.AbandMoney.Name = "AbandMoney"
        Me.AbandMoney.ReadOnly = True
        Me.AbandMoney.Width = 92
        '
        'InfoTitle
        '
        Me.InfoTitle.DataPropertyName = "InfoTitle"
        DataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.InfoTitle.DefaultCellStyle = DataGridViewCellStyle39
        Me.InfoTitle.HeaderText = "エラー内容"
        Me.InfoTitle.Name = "InfoTitle"
        Me.InfoTitle.ReadOnly = True
        Me.InfoTitle.Width = 112
        '
        'Info
        '
        Me.Info.DataPropertyName = "Info"
        DataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.Info.DefaultCellStyle = DataGridViewCellStyle40
        Me.Info.HeaderText = "システム情報"
        Me.Info.Name = "Info"
        Me.Info.ReadOnly = True
        '
        'Memo
        '
        Me.Memo.DataPropertyName = "Memo"
        DataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.Memo.DefaultCellStyle = DataGridViewCellStyle41
        Me.Memo.HeaderText = "メモ"
        Me.Memo.Name = "Memo"
        Me.Memo.ReadOnly = True
        '
        'CountryName
        '
        Me.CountryName.DataPropertyName = "CountryName"
        Me.CountryName.HeaderText = "国"
        Me.CountryName.Name = "CountryName"
        Me.CountryName.ReadOnly = True
        '
        'TradeList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1049, 492)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "TradeList"
        Me.Text = "取引データ一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.pnlSearchAdd.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbDateType As System.Windows.Forms.ComboBox
    Friend WithEvents pnlSearchAdd As System.Windows.Forms.Panel
    Friend WithEvents btnSearchAdd As System.Windows.Forms.Button
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents cbTradeType As System.Windows.Forms.ComboBox
    Friend WithEvents cbListType As System.Windows.Forms.ComboBox
    Friend WithEvents btnCSV As System.Windows.Forms.Button
    Friend WithEvents tbCustCode As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbProductCode As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbTradeStatus As System.Windows.Forms.ComboBox
    Friend WithEvents sfdCsvFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents cbCurCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbOpType As ComboBox
    Friend WithEvents cbCountryCode As ComboBox
    Friend WithEvents TradeSeq As DataGridViewTextBoxColumn
    Friend WithEvents ProductCode As DataGridViewTextBoxColumn
    Friend WithEvents ComCode As DataGridViewTextBoxColumn
    Friend WithEvents ComName As DataGridViewTextBoxColumn
    Friend WithEvents OpType As DataGridViewTextBoxColumn
    Friend WithEvents OpTypeName As DataGridViewTextBoxColumn
    Friend WithEvents OptionTime As DataGridViewTextBoxColumn
    Friend WithEvents PayoutRate As DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As DataGridViewTextBoxColumn
    Friend WithEvents SysDate As DataGridViewTextBoxColumn
    Friend WithEvents TradeType As DataGridViewTextBoxColumn
    Friend WithEvents TradeTypeName As DataGridViewTextBoxColumn
    Friend WithEvents CurName As DataGridViewTextBoxColumn
    Friend WithEvents Premium As DataGridViewTextBoxColumn
    Friend WithEvents CustCode As DataGridViewTextBoxColumn
    Friend WithEvents OrderReqTime As DataGridViewTextBoxColumn
    Friend WithEvents OrderClientRateSeq As DataGridViewTextBoxColumn
    Friend WithEvents OrderClientRateTime As DataGridViewTextBoxColumn
    Friend WithEvents OrderClientRate As DataGridViewTextBoxColumn
    Friend WithEvents AbandReqTime As DataGridViewTextBoxColumn
    Friend WithEvents AbandClientRateSeq As DataGridViewTextBoxColumn
    Friend WithEvents AbandClientRateTime As DataGridViewTextBoxColumn
    Friend WithEvents AbandClientRate As DataGridViewTextBoxColumn
    Friend WithEvents TradeTime As DataGridViewTextBoxColumn
    Friend WithEvents TradeRateSeq As DataGridViewTextBoxColumn
    Friend WithEvents TradeRateTime As DataGridViewTextBoxColumn
    Friend WithEvents TradeRate As DataGridViewTextBoxColumn
    Friend WithEvents ExercPrice As DataGridViewTextBoxColumn
    Friend WithEvents ExercProcTime As DataGridViewTextBoxColumn
    Friend WithEvents ExercRateSeq As DataGridViewTextBoxColumn
    Friend WithEvents ExercRateTime As DataGridViewTextBoxColumn
    Friend WithEvents ExercRate As DataGridViewTextBoxColumn
    Friend WithEvents ExercPayoutRate As DataGridViewTextBoxColumn
    Friend WithEvents Payout As DataGridViewTextBoxColumn
    Friend WithEvents NetPAndL As DataGridViewTextBoxColumn
    Friend WithEvents TradeStatus As DataGridViewTextBoxColumn
    Friend WithEvents TradeStatusName As DataGridViewTextBoxColumn
    Friend WithEvents AbandMoney As DataGridViewTextBoxColumn
    Friend WithEvents InfoTitle As DataGridViewTextBoxColumn
    Friend WithEvents Info As DataGridViewTextBoxColumn
    Friend WithEvents Memo As DataGridViewTextBoxColumn
    Friend WithEvents CountryName As DataGridViewTextBoxColumn
End Class
