﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.tbPayoutRate = New System.Windows.Forms.TextBox()
        Me.cbExercStatus = New System.Windows.Forms.ComboBox()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.lblProductBaseCode = New System.Windows.Forms.Label()
        Me.dtpStartTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpExercTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpTradeLimitTime = New System.Windows.Forms.DateTimePicker()
        Me.lblEnabled = New System.Windows.Forms.Label()
        Me.btnDisabled = New System.Windows.Forms.Button()
        Me.btnEnabled = New System.Windows.Forms.Button()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dtpSysDate = New System.Windows.Forms.DateTimePicker()
        Me.tbExercRateSeq = New System.Windows.Forms.TextBox()
        Me.tbExercRate = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.tbSpread = New System.Windows.Forms.TextBox()
        Me.tbVolatilityAdjust = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.tbAbandMargine = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tbAbandPriceDiff = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.tbStartAbandTime = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.tbStopTradeTime = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.tbVolatility = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.tbTradeMoneyMin = New System.Windows.Forms.TextBox()
        Me.tbTradeMoneyMax = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.tbTradeLimitTime = New System.Windows.Forms.TextBox()
        Me.tbOptionTime = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "銘柄コード"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "通貨ペア"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "オプション種別"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 175)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 12)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "取引開始日"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 198)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 12)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "行使期日"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 221)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 12)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "取引可能期日"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.ItemHeight = 12
        Me.cbComCode.Location = New System.Drawing.Point(167, 78)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(144, 20)
        Me.cbComCode.TabIndex = 5
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.ItemHeight = 12
        Me.cbOpType.Location = New System.Drawing.Point(167, 101)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(144, 20)
        Me.cbOpType.TabIndex = 7
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(47, 602)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 42
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(180, 602)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 43
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(25, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 12)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "ペイアウト率"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(25, 469)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 12)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "有効フラグ"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(25, 493)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 12)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "行使フラグ"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(25, 518)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 12)
        Me.Label10.TabIndex = 36
        Me.Label10.Text = "銘柄設定コード"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(25, 544)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(84, 12)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "行使時価格Seq"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(25, 567)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 12)
        Me.Label12.TabIndex = 40
        Me.Label12.Text = "行使時価格"
        '
        'tbPayoutRate
        '
        Me.tbPayoutRate.Location = New System.Drawing.Point(167, 239)
        Me.tbPayoutRate.Name = "tbPayoutRate"
        Me.tbPayoutRate.Size = New System.Drawing.Size(144, 19)
        Me.tbPayoutRate.TabIndex = 17
        Me.tbPayoutRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbExercStatus
        '
        Me.cbExercStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercStatus.FormattingEnabled = True
        Me.cbExercStatus.Items.AddRange(New Object() {"", "未行使", "行使済み"})
        Me.cbExercStatus.Location = New System.Drawing.Point(167, 490)
        Me.cbExercStatus.Name = "cbExercStatus"
        Me.cbExercStatus.Size = New System.Drawing.Size(144, 20)
        Me.cbExercStatus.TabIndex = 35
        '
        'lblCode
        '
        Me.lblCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCode.Location = New System.Drawing.Point(167, 52)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(144, 23)
        Me.lblCode.TabIndex = 3
        Me.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblProductBaseCode
        '
        Me.lblProductBaseCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProductBaseCode.Location = New System.Drawing.Point(167, 513)
        Me.lblProductBaseCode.Name = "lblProductBaseCode"
        Me.lblProductBaseCode.Size = New System.Drawing.Size(144, 23)
        Me.lblProductBaseCode.TabIndex = 37
        Me.lblProductBaseCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dtpStartTime
        '
        Me.dtpStartTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpStartTime.Location = New System.Drawing.Point(167, 170)
        Me.dtpStartTime.Name = "dtpStartTime"
        Me.dtpStartTime.Size = New System.Drawing.Size(144, 19)
        Me.dtpStartTime.TabIndex = 11
        '
        'dtpExercTime
        '
        Me.dtpExercTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpExercTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpExercTime.Location = New System.Drawing.Point(167, 193)
        Me.dtpExercTime.Name = "dtpExercTime"
        Me.dtpExercTime.Size = New System.Drawing.Size(144, 19)
        Me.dtpExercTime.TabIndex = 13
        '
        'dtpTradeLimitTime
        '
        Me.dtpTradeLimitTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTradeLimitTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTradeLimitTime.Location = New System.Drawing.Point(167, 216)
        Me.dtpTradeLimitTime.Name = "dtpTradeLimitTime"
        Me.dtpTradeLimitTime.Size = New System.Drawing.Size(144, 19)
        Me.dtpTradeLimitTime.TabIndex = 15
        '
        'lblEnabled
        '
        Me.lblEnabled.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblEnabled.Location = New System.Drawing.Point(167, 464)
        Me.lblEnabled.Name = "lblEnabled"
        Me.lblEnabled.Size = New System.Drawing.Size(144, 20)
        Me.lblEnabled.TabIndex = 19
        Me.lblEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnDisabled
        '
        Me.btnDisabled.Location = New System.Drawing.Point(192, 12)
        Me.btnDisabled.Name = "btnDisabled"
        Me.btnDisabled.Size = New System.Drawing.Size(98, 29)
        Me.btnDisabled.TabIndex = 1
        Me.btnDisabled.Text = "銘柄無効化"
        Me.btnDisabled.UseVisualStyleBackColor = True
        '
        'btnEnabled
        '
        Me.btnEnabled.Location = New System.Drawing.Point(88, 12)
        Me.btnEnabled.Name = "btnEnabled"
        Me.btnEnabled.Size = New System.Drawing.Size(98, 29)
        Me.btnEnabled.TabIndex = 0
        Me.btnEnabled.Text = "銘柄有効化"
        Me.btnEnabled.UseVisualStyleBackColor = True
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(167, 465)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(144, 20)
        Me.cbEnabled.TabIndex = 33
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(25, 150)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(79, 12)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "システム営業日"
        '
        'dtpSysDate
        '
        Me.dtpSysDate.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDate.Location = New System.Drawing.Point(167, 147)
        Me.dtpSysDate.Name = "dtpSysDate"
        Me.dtpSysDate.Size = New System.Drawing.Size(144, 19)
        Me.dtpSysDate.TabIndex = 7
        '
        'tbExercRateSeq
        '
        Me.tbExercRateSeq.Location = New System.Drawing.Point(167, 541)
        Me.tbExercRateSeq.Name = "tbExercRateSeq"
        Me.tbExercRateSeq.Size = New System.Drawing.Size(144, 19)
        Me.tbExercRateSeq.TabIndex = 39
        '
        'tbExercRate
        '
        Me.tbExercRate.Location = New System.Drawing.Point(167, 564)
        Me.tbExercRate.Name = "tbExercRate"
        Me.tbExercRate.Size = New System.Drawing.Size(144, 19)
        Me.tbExercRate.TabIndex = 41
        Me.tbExercRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(25, 265)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(48, 12)
        Me.Label14.TabIndex = 18
        Me.Label14.Text = "スプレッド"
        '
        'tbSpread
        '
        Me.tbSpread.Location = New System.Drawing.Point(167, 262)
        Me.tbSpread.Name = "tbSpread"
        Me.tbSpread.Size = New System.Drawing.Size(144, 19)
        Me.tbSpread.TabIndex = 19
        Me.tbSpread.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbVolatilityAdjust
        '
        Me.tbVolatilityAdjust.Location = New System.Drawing.Point(167, 374)
        Me.tbVolatilityAdjust.Name = "tbVolatilityAdjust"
        Me.tbVolatilityAdjust.Size = New System.Drawing.Size(144, 19)
        Me.tbVolatilityAdjust.TabIndex = 29
        Me.tbVolatilityAdjust.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(25, 377)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 12)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "ボラティリティレシオ(%)"
        '
        'tbAbandMargine
        '
        Me.tbAbandMargine.Location = New System.Drawing.Point(167, 351)
        Me.tbAbandMargine.Name = "tbAbandMargine"
        Me.tbAbandMargine.Size = New System.Drawing.Size(144, 19)
        Me.tbAbandMargine.TabIndex = 27
        Me.tbAbandMargine.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(25, 354)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(103, 12)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "権利放棄手数料(%)"
        '
        'tbAbandPriceDiff
        '
        Me.tbAbandPriceDiff.Location = New System.Drawing.Point(167, 329)
        Me.tbAbandPriceDiff.Name = "tbAbandPriceDiff"
        Me.tbAbandPriceDiff.Size = New System.Drawing.Size(144, 19)
        Me.tbAbandPriceDiff.TabIndex = 25
        Me.tbAbandPriceDiff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(25, 332)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(142, 12)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "権利放棄可能価格差(pips)"
        '
        'tbStartAbandTime
        '
        Me.tbStartAbandTime.Location = New System.Drawing.Point(167, 307)
        Me.tbStartAbandTime.Name = "tbStartAbandTime"
        Me.tbStartAbandTime.Size = New System.Drawing.Size(144, 19)
        Me.tbStartAbandTime.TabIndex = 23
        Me.tbStartAbandTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(25, 310)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(121, 12)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "権利放棄可能時間(秒)"
        '
        'tbStopTradeTime
        '
        Me.tbStopTradeTime.Location = New System.Drawing.Point(167, 285)
        Me.tbStopTradeTime.Name = "tbStopTradeTime"
        Me.tbStopTradeTime.Size = New System.Drawing.Size(144, 19)
        Me.tbStopTradeTime.TabIndex = 21
        Me.tbStopTradeTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(25, 288)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(97, 12)
        Me.Label19.TabIndex = 20
        Me.Label19.Text = "取引停止時間(秒)"
        '
        'tbVolatility
        '
        Me.tbVolatility.Location = New System.Drawing.Point(167, 396)
        Me.tbVolatility.Name = "tbVolatility"
        Me.tbVolatility.Size = New System.Drawing.Size(144, 19)
        Me.tbVolatility.TabIndex = 31
        Me.tbVolatility.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(25, 399)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 12)
        Me.Label20.TabIndex = 30
        Me.Label20.Text = "ボラティリティ"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(25, 422)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(115, 12)
        Me.Label21.TabIndex = 44
        Me.Label21.Text = "最小取引額(1回)銘柄"
        '
        'tbTradeMoneyMin
        '
        Me.tbTradeMoneyMin.Location = New System.Drawing.Point(167, 419)
        Me.tbTradeMoneyMin.Name = "tbTradeMoneyMin"
        Me.tbTradeMoneyMin.Size = New System.Drawing.Size(144, 19)
        Me.tbTradeMoneyMin.TabIndex = 45
        Me.tbTradeMoneyMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbTradeMoneyMax
        '
        Me.tbTradeMoneyMax.Location = New System.Drawing.Point(167, 442)
        Me.tbTradeMoneyMax.Name = "tbTradeMoneyMax"
        Me.tbTradeMoneyMax.Size = New System.Drawing.Size(144, 19)
        Me.tbTradeMoneyMax.TabIndex = 46
        Me.tbTradeMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(25, 445)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(115, 12)
        Me.Label22.TabIndex = 47
        Me.Label22.Text = "最大取引額(1回)銘柄"
        '
        'tbTradeLimitTime
        '
        Me.tbTradeLimitTime.Enabled = False
        Me.tbTradeLimitTime.Location = New System.Drawing.Point(167, 214)
        Me.tbTradeLimitTime.Name = "tbTradeLimitTime"
        Me.tbTradeLimitTime.Size = New System.Drawing.Size(131, 19)
        Me.tbTradeLimitTime.TabIndex = 48
        '
        'tbOptionTime
        '
        Me.tbOptionTime.Location = New System.Drawing.Point(167, 124)
        Me.tbOptionTime.Name = "tbOptionTime"
        Me.tbOptionTime.Size = New System.Drawing.Size(144, 19)
        Me.tbOptionTime.TabIndex = 6
        Me.tbOptionTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(25, 127)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(92, 12)
        Me.Label23.TabIndex = 50
        Me.Label23.Text = "オプション期間(秒)"
        '
        'ProductForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(337, 640)
        Me.Controls.Add(Me.tbOptionTime)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.tbTradeMoneyMax)
        Me.Controls.Add(Me.tbTradeMoneyMin)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.tbVolatility)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.tbVolatilityAdjust)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.tbAbandMargine)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.tbAbandPriceDiff)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.tbStartAbandTime)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.tbStopTradeTime)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.tbExercRate)
        Me.Controls.Add(Me.tbExercRateSeq)
        Me.Controls.Add(Me.dtpSysDate)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.btnDisabled)
        Me.Controls.Add(Me.btnEnabled)
        Me.Controls.Add(Me.lblEnabled)
        Me.Controls.Add(Me.dtpTradeLimitTime)
        Me.Controls.Add(Me.dtpExercTime)
        Me.Controls.Add(Me.dtpStartTime)
        Me.Controls.Add(Me.lblProductBaseCode)
        Me.Controls.Add(Me.lblCode)
        Me.Controls.Add(Me.cbExercStatus)
        Me.Controls.Add(Me.tbSpread)
        Me.Controls.Add(Me.tbPayoutRate)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.cbOpType)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tbTradeLimitTime)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "ProductForm"
        Me.Text = "銘柄登録"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbOpType As System.Windows.Forms.ComboBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents tbPayoutRate As System.Windows.Forms.TextBox
    Friend WithEvents cbExercStatus As System.Windows.Forms.ComboBox
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents lblProductBaseCode As System.Windows.Forms.Label
    Friend WithEvents dtpStartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpExercTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpTradeLimitTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblEnabled As System.Windows.Forms.Label
    Friend WithEvents btnDisabled As System.Windows.Forms.Button
    Friend WithEvents btnEnabled As System.Windows.Forms.Button
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dtpSysDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbExercRateSeq As System.Windows.Forms.TextBox
    Friend WithEvents tbExercRate As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents tbSpread As System.Windows.Forms.TextBox
    Friend WithEvents tbVolatilityAdjust As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents tbAbandMargine As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tbAbandPriceDiff As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents tbStartAbandTime As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents tbStopTradeTime As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents tbVolatility As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents tbTradeMoneyMin As System.Windows.Forms.TextBox
    Friend WithEvents tbTradeMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents tbTradeLimitTime As TextBox
    Friend WithEvents tbOptionTime As TextBox
    Friend WithEvents Label23 As Label
End Class
