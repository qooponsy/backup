﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TradeAccountSummaryDownload
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnDownload = New System.Windows.Forms.Button()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSelectFile = New System.Windows.Forms.Button()
        Me.tbFilepath = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpSysDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(158, 115)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(114, 19)
        Me.dtpToDateTime.TabIndex = 4
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 115)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(117, 19)
        Me.dtpFromDateTime.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(135, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(17, 12)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "～"
        '
        'btnDownload
        '
        Me.btnDownload.Location = New System.Drawing.Point(119, 210)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(96, 28)
        Me.btnDownload.TabIndex = 7
        Me.btnDownload.Text = "ダウンロード"
        Me.btnDownload.UseVisualStyleBackColor = True
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 12)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 12)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "口座開設日"
        '
        'btnSelectFile
        '
        Me.btnSelectFile.Location = New System.Drawing.Point(268, 169)
        Me.btnSelectFile.Name = "btnSelectFile"
        Me.btnSelectFile.Size = New System.Drawing.Size(47, 23)
        Me.btnSelectFile.TabIndex = 6
        Me.btnSelectFile.Text = "参照"
        Me.btnSelectFile.UseVisualStyleBackColor = True
        '
        'tbFilepath
        '
        Me.tbFilepath.Location = New System.Drawing.Point(12, 171)
        Me.tbFilepath.Name = "tbFilepath"
        Me.tbFilepath.Size = New System.Drawing.Size(250, 19)
        Me.tbFilepath.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 156)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(159, 12)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "MT4 status report ファイル指定"
        '
        'dtpSysDateTime
        '
        Me.dtpSysDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpSysDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSysDateTime.Location = New System.Drawing.Point(12, 68)
        Me.dtpSysDateTime.Name = "dtpSysDateTime"
        Me.dtpSysDateTime.Size = New System.Drawing.Size(117, 19)
        Me.dtpSysDateTime.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 12)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "営業日"
        '
        'TradeAccountSummaryDownload
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(326, 261)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dtpSysDateTime)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbFilepath)
        Me.Controls.Add(Me.btnSelectFile)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtpToDateTime)
        Me.Controls.Add(Me.dtpFromDateTime)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnDownload)
        Me.Controls.Add(Me.cbCmpCode)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "TradeAccountSummaryDownload"
        Me.Text = "取引口座集計"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtpToDateTime As DateTimePicker
    Friend WithEvents dtpFromDateTime As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents btnDownload As Button
    Friend WithEvents cbCmpCode As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnSelectFile As Button
    Friend WithEvents tbFilepath As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents dtpSysDateTime As DateTimePicker
    Friend WithEvents Label4 As Label
End Class
