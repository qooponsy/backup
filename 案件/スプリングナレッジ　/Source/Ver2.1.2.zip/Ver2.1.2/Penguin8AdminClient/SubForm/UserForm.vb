﻿Public Class UserForm
    Public Property Code As String

    Private WithEvents service As New UserService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub UserForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbUserType.DisplayMember = "Name"
        cbUserType.ValueMember = "Code"
        cbUserType.DataSource = UserTypeManager.GetList()

		cbCmpCode.DisplayMember = "CmpName"
		cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetList()

        cbAccountLockFlag.DisplayMember = "Name"
        cbAccountLockFlag.ValueMember = "Code"
        cbAccountLockFlag.DataSource = AccountLockFlagManager.GetList()

		MainWindow.SubFormUserForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            tbUserID.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub UserForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormUserForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

	' 編集可能判定
	' 2014/12 Function化
	' 条件を IsEdit -> IsAdmin Or IsWLに変更
	Private Function IsUserEditable(UserType As String) As Boolean
		Return UserTypeManager.IsAdmin(UserType) Or UserTypeManager.IsWL(UserType)
	End Function

	Private Sub setTitle()
		If Code = "" Then
			Me.Text = "ユーザー登録"
		Else
			If IsUserEditable(SessionService.UserType) Then
				Me.Text = "ユーザー編集"
			Else
				Me.Text = "ユーザー参照"
			End If
		End If
	End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        tbUserID.Enabled = (status = FormMode.REGIST)
        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbAccountLockFlag.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbUserName.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbPassword.Enabled = (status = FormMode.REGIST)
        cbUserType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
		' 2014/12 WhiteLabelは自社分のみに限定
		If UserTypeManager.IsWL(SessionService.UserType) Then
			cbCmpCode.Enabled = False
		Else
			cbCmpCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        End If

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        cbEnabled.SelectedValue = ""
        cbUserType.SelectedValue = ""
        cbAccountLockFlag.SelectedValue = ""

        ' 2014/12 WhiteLabelは自社分のみに限定
        If UserTypeManager.IsWL(SessionService.UserType) Then
            cbCmpCode.SelectedValue = SessionService.CmpCode
        Else
            cbCmpCode.SelectedValue = ""
		End If
	End Sub

    Private Sub initEdit()
        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of UserData)) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "ユーザーの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).UserID <> Code Then
            MessageBox.Show(Me, "ユーザーの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
			If IsUserEditable(SessionService.UserType) Then
				setFormMode(FormMode.EDIT)
			Else
				setFormMode(FormMode.REFERENCE)
			End If
        End If
    End Sub

    Private Sub service_RegistSuccess() Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As UserData)
        Me.tbUserID.Text = data.UserID
        Me.cbEnabled.SelectedValue = data.Enabled
        Me.cbAccountLockFlag.SelectedValue = data.AccountLock
        Me.tbUserName.Text = data.UserName
        Me.tbPassword.Text = ""
        Me.cbUserType.SelectedValue = data.UserType
        Me.cbCmpCode.SelectedValue = data.CmpCode
        Me.tbPasswordUpdTime.Text = data.PasswordUpdTime
    End Sub

    Private Function getDataFromControl() As UserData
        Dim ret As New UserData
        ret.UserID = Me.tbUserID.Text
        ret.Enabled = Me.cbEnabled.SelectedValue
        ret.AccountLock = Me.cbAccountLockFlag.SelectedValue
        ret.UserName = Me.tbUserName.Text
        ret.UserType = Me.cbUserType.SelectedValue
        ret.CmpCode = Me.cbCmpCode.SelectedValue
        Return ret
    End Function

    Private Function checkInput() As Boolean
        If Me.tbUserID.Text.Length = 0 OrElse Me.tbUserID.Text.Length > 32 Then
            MessageBox.Show(Me, "ユーザーIDを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Me.cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Me.cbAccountLockFlag.SelectedValue = "" Then
            MessageBox.Show(Me, "アカウントロックを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If FormModeStatus = FormMode.REGIST Then
            If Me.tbPassword.Text.Length = 0 Then
                MessageBox.Show(Me, "パスワードを入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If Not CheckUtil.IsMatchPasswordPolicy(Me.tbPassword.Text) Then
                MessageBox.Show(Me, "パスワードポリシーを満たしていません。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If
        If Me.tbUserName.Text.Length = 0 OrElse Me.tbUserName.Text.Length > 128 Then
            MessageBox.Show(Me, "ユーザー名を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Me.cbUserType.SelectedValue = "" Then
            MessageBox.Show(Me, "ユーザー種別を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Me.cbCmpCode.SelectedValue = "" Then
            MessageBox.Show(Me, "会社を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As UserData = getDataFromControl()
        Dim password As String = tbPassword.Text

        service.Regist(data, password)
    End Sub

    Private Sub updateData()
        Dim data As UserData = getDataFromControl()

        service.Update(data)
    End Sub

End Class