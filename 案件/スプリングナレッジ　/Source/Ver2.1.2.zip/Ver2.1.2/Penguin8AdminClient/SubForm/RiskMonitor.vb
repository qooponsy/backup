﻿Public Class RiskMonitor

    Private Const RiskDecimalPlaces As Integer = 4

    Private WithEvents serviceRateTick As RateTickService
    Private WithEvents serviceTradeNow As TradeNowService

    Private TableSum As New DataTable
    Private TableDetail As New DataTable
    Private ViewDetail As New DataView

    Private Sub RiskMonitor_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(gridSum)
        clsUtil.SetGridDoubleBuffered(gridDetail)

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        miEdit.Text = IIf(editable, "編集", "参照")

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbCurCode.DisplayMember = "CurName"
        cbCurCode.ValueMember = "CurCode"
        cbCurCode.DataSource = CurrencyService.GetList()

        MainWindow.SubFormRiskMonitor = True

        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        InitGridSum()
        InitGridDetail()
        serviceRateTick = New RateTickService
        serviceTradeNow = New TradeNowService
        Calc()
    End Sub

    Private Sub RiskMonitor_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceRateTick = Nothing
        serviceTradeNow = Nothing

        SaveSettings()
        MainWindow.SubFormRiskMonitor = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RiskMonitor_FormMaximized, _
            UserSettings.getInstance().DataSaved.RiskMonitor_FormSize, _
            UserSettings.getInstance().DataSaved.RiskMonitor_FormLocation)

        Dim SplitterDistance As Integer = UserSettings.getInstance().DataSaved.RiskMonitor_SplitterDistance
        If SplitterDistance > 0 Then SplitContainer1.SplitterDistance = SplitterDistance
        clsUtil.SetDataGridColumnsWidth(gridSum, UserSettings.getInstance().DataSaved.RiskMonitor_SumColumns)
        clsUtil.SetDataGridColumnsWidth(gridDetail, UserSettings.getInstance().DataSaved.RiskMonitor_DetailColumns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.RiskMonitor_CmpCode
        cbCurCode.SelectedValue = UserSettings.getInstance().DataSaved.RiskMonitor_CurCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RiskMonitor_FormMaximized, _
            UserSettings.getInstance().DataSaved.RiskMonitor_FormSize, _
            UserSettings.getInstance().DataSaved.RiskMonitor_FormLocation)

        UserSettings.getInstance().DataSaved.RiskMonitor_SplitterDistance = SplitContainer1.SplitterDistance
        clsUtil.GetDataGridColumnsWidth(gridSum, UserSettings.getInstance().DataSaved.RiskMonitor_SumColumns)
        clsUtil.GetDataGridColumnsWidth(gridDetail, UserSettings.getInstance().DataSaved.RiskMonitor_DetailColumns)
        UserSettings.getInstance().DataSaved.RiskMonitor_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.RiskMonitor_CurCode = cbCurCode.SelectedValue
    End Sub

    Private Sub InitGridSum()
        gridSum.AutoGenerateColumns = False
        TableSum.Columns.Add("ComCode", GetType(String))
        TableSum.Columns.Add("ComName", GetType(String))
        TableSum.Columns.Add("Rate", GetType(Decimal))
        TableSum.Columns.Add("RateArrowCount", GetType(Integer))
        TableSum.Columns.Add("PAndL", GetType(Decimal))
        TableSum.Columns.Add("Premium", GetType(Decimal))
        TableSum.Columns.Add("Delta", GetType(Decimal))
        TableSum.Columns.Add("GammaU", GetType(Decimal))
        TableSum.Columns.Add("GammaD", GetType(Decimal))
        TableSum.Columns.Add("Vega", GetType(Decimal))
        TableSum.Columns.Add("Theta", GetType(Decimal))
        TableSum.Columns.Add("Rho", GetType(Decimal))
        TableSum.Columns.Add("TradeCount", GetType(Integer))
        TableSum.Columns.Add("ShortRate", GetType(Decimal))
        TableSum.Columns.Add("SwapRate", GetType(Decimal))
        TableSum.Columns.Add("VolatilityAdjust", GetType(Decimal))
        TableSum.Columns.Add("Volatility", GetType(Decimal))
        gridSum.DataSource = TableSum

        '/
        'Dim rowAll As DataRow = TableSum.NewRow()
        'rowAll("ComCode") = ""
        'rowAll("ComName") = "全体"
        'rowAll("Rate") = DBNull.Value
        'rowAll("RateArrowCount") = 0
        'rowAll("PAndL") = 0
        'rowAll("Premium") = 0
        'rowAll("Delta") = 0
        'rowAll("GammaU") = 0
        'rowAll("GammaD") = 0
        'rowAll("Vega") = 0
        'rowAll("Theta") = 0
        'rowAll("Rho") = 0
        'rowAll("TradeCount") = 0
        'rowAll("ShortRate") = DBNull.Value
        'rowAll("SwapRate") = DBNull.Value
        'rowAll("VolatilityAdjust") = DBNull.Value
        'rowAll("Volatility") = DBNull.Value
        'TableSum.Rows.Add(rowAll)
        '/

        For Each risk As CurrencyPairData In CurrencyPairService.GetList()
            Dim row As DataRow = TableSum.NewRow()
            row("ComCode") = risk.ComCode
            row("ComName") = CurrencyPairService.GetData(risk.ComCode).ComName
            row("Rate") = RateTickService.GetLastRate(risk.ComCode).Rate
            row("RateArrowCount") = 0
            row("PAndL") = 0
            row("Premium") = 0
            row("Delta") = 0
            row("GammaU") = 0
            row("GammaD") = 0
            row("Vega") = 0
            row("Theta") = 0
            row("Rho") = 0
            row("TradeCount") = 0
            row("ShortRate") = DBNull.Value
            row("SwapRate") = DBNull.Value
            row("VolatilityAdjust") = DBNull.Value
            row("Volatility") = DBNull.Value

            TableSum.Rows.Add(row)
        Next

    End Sub

    Private Sub InitGridDetail()
        gridDetail.AutoGenerateColumns = False

        TableDetail.Columns.Add("DetailProductCode", GetType(String))
        TableDetail.Columns.Add("DetailComCode", GetType(String))
        TableDetail.Columns.Add("DetailComName", GetType(String))
        TableDetail.Columns.Add("DetailOpType", GetType(String))
        TableDetail.Columns.Add("DetailOptionTime", GetType(Integer))
        TableDetail.Columns.Add("DetailRate", GetType(Decimal))
        TableDetail.Columns.Add("DetailRateArrowCount", GetType(Integer))
        TableDetail.Columns.Add("DetailExercTime", GetType(DateTime))
        TableDetail.Columns.Add("DetailZanzon", GetType(String))
        TableDetail.Columns.Add("DetailPayoutRate", GetType(Decimal))
        TableDetail.Columns.Add("DetailPAndL", GetType(Decimal))
        TableDetail.Columns.Add("DetailPremium", GetType(Decimal))
        TableDetail.Columns.Add("DetailDelta", GetType(Decimal))
        TableDetail.Columns.Add("DetailGammaU", GetType(Decimal))
        TableDetail.Columns.Add("DetailGammaD", GetType(Decimal))
        TableDetail.Columns.Add("DetailVega", GetType(Decimal))
        TableDetail.Columns.Add("DetailTheta", GetType(Decimal))
        TableDetail.Columns.Add("DetailRho", GetType(Decimal))
        TableDetail.Columns.Add("DetailCount", GetType(Decimal))

        ViewDetail = New DataView(TableDetail)
        gridDetail.DataSource = ViewDetail
    End Sub

    Private Sub Calc()
        Dim StdDt As DateTime = RateTickService.ServerTime
        'Dim AbandMargine As Decimal = SysSettingsService.GetData().AbandMargine

        Dim sumRiskAll As New TradeRiskData With {.ComCode = ""}
        Dim ComList As New Dictionary(Of String, TradeRiskData)
        Dim ProductList As New Dictionary(Of String, TradeRiskData)
        Dim SelCmpCode As String = cbCmpCode.SelectedValue
        Dim SelCurCode As String = cbCurCode.SelectedValue

        For Each item As CurrencyPairData In CurrencyPairService.GetList()
            ComList.Add(item.ComCode, New TradeRiskData With {.ComCode = item.ComCode})
            Dim ComItem As TradeRiskData = ComList(item.ComCode)
            Dim rate As RateTickData = RateTickService.GetLastRate(item.ComCode)
            ComItem.Rate = rate.Rate
            ComItem.RateArrowCount = rate.RateArrowCount
            ComItem.sr = CalcParamService.GetData(item.ComCode).InterestRate
            ComItem.SwapRate = CalcParamService.GetData(item.ComCode).SwapRate
            ComItem.VolatilityAdjust = CalcParamService.GetData(item.ComCode).VolatilityAdjust
            ComItem.sigma = CalcParamService.GetData(item.ComCode).Volatility
            ComItem.DeltaVariation = CalcParamService.GetData(item.ComCode).DeltaVariation
            ComItem.GammaVariation = CalcParamService.GetData(item.ComCode).GammaVariation
            ComItem.VegaVariation = CalcParamService.GetData(item.ComCode).VegaVariation
            ComItem.ThetaVariation = CalcParamService.GetData(item.ComCode).ThetaVariation
            ComItem.RhoVariation = CalcParamService.GetData(item.ComCode).RhoVariation
            ComItem.ExcgComCode = item.ExcgComCode
            If ComItem.ExcgComCode <> "" Then
                Dim exchRate As RateTickData = RateTickService.GetLastRate(item.ExcgComCode)
                ComItem.ExcgRate = exchRate.Rate
            End If
        Next

        For Each item As TradeData In TradeNowService.DataList
            If SelCmpCode <> "" AndAlso SelCmpCode <> item.CmpCode Then Continue For
            If SelCurCode <> item.CurCode Then Continue For
            Dim ComItem As TradeRiskData = ComList(item.ComCode)
            Dim ProductItem As TradeRiskData = Nothing
            If ProductList.ContainsKey(item.ProductCode) Then
                ProductItem = ProductList(item.ProductCode)
            Else
                ProductList.Add(item.ProductCode, New TradeRiskData)
                ProductItem = ProductList(item.ProductCode)
                ProductItem.ProductCode = item.ProductCode
                ProductItem.ComCode = ComItem.ComCode
                ProductItem.OpType = item.OpType
                ProductItem.OptionTime = item.OptionTime
                ProductItem.PayoutRate = item.PayoutRate
                ProductItem.ExercTime = item.ExercTime
                ProductItem.Rate = ComItem.Rate
                ProductItem.RateArrowCount = ComItem.RateArrowCount
                ProductItem.sr = ComItem.sr
                ProductItem.SwapRate = ComItem.SwapRate
                ProductItem.VolatilityAdjust = ComItem.VolatilityAdjust
                ProductItem.sigma = item.Volatility
                ProductItem.DeltaVariation = ComItem.DeltaVariation
                ProductItem.GammaVariation = ComItem.GammaVariation
                ProductItem.VegaVariation = ComItem.VegaVariation
                ProductItem.ThetaVariation = ComItem.ThetaVariation
                ProductItem.RhoVariation = ComItem.RhoVariation
                ProductItem.ExcgComCode = ComItem.ExcgComCode
                ProductItem.ExcgRate = ComItem.ExcgRate
            End If

            Dim PAndL As Decimal = -RiskCalc.PAndL(item.Premium, 0, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, SessionService.DecimalPlaces)
            Dim Premium As Decimal = Floor(RiskCalc.Premium(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime), RiskDecimalPlaces)
            Dim Delta As Decimal = Floor(RiskCalc.Delta(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, ProductItem.DeltaVariation), RiskDecimalPlaces)
            Dim GammaU As Decimal = Floor(RiskCalc.GammaU(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, ProductItem.DeltaVariation, ProductItem.GammaVariation), RiskDecimalPlaces)
            Dim GammaD As Decimal = Floor(RiskCalc.GammaD(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, ProductItem.DeltaVariation, ProductItem.GammaVariation), RiskDecimalPlaces)
            Dim Vega As Decimal = Floor(RiskCalc.Vega(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, ProductItem.VegaVariation), RiskDecimalPlaces)
            Dim Theta As Decimal = Floor(RiskCalc.Theta(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, ProductItem.ThetaVariation), RiskDecimalPlaces)
            Dim Rho As Decimal = Floor(RiskCalc.Rho(item.Premium, ProductItem.PayoutRate, item.TradeType, ProductItem.Rate, item.ExercPrice, ProductItem.sr, ProductItem.SwapRate, ProductItem.sigma, StdDt, ProductItem.ExercTime, ProductItem.RhoVariation), RiskDecimalPlaces)

            ProductItem.PAndL += PAndL
            ProductItem.Premium += Premium
            ProductItem.Delta += Delta
            ProductItem.GammaU += GammaU
            ProductItem.GammaD += GammaD
            ProductItem.Vega += Vega
            ProductItem.Theta += Theta
            ProductItem.Rho += Rho
            ProductItem.Count += 1
        Next

        For Each item As TradeRiskData In ProductList.Values
            If item.ExcgComCode <> "" Then
                item.Delta /= item.ExcgRate
                item.GammaU /= item.ExcgRate
                item.GammaD /= item.ExcgRate
            End If

            Dim sumRisk As TradeRiskData = ComList(item.ComCode)

            sumRisk.PAndL += item.PAndL
            sumRisk.Premium += item.Premium
            sumRisk.Delta += item.Delta
            sumRisk.GammaU += item.GammaU
            sumRisk.GammaD += item.GammaD
            sumRisk.Vega += item.Vega
            sumRisk.Theta += item.Theta
            sumRisk.Rho += item.Rho
            sumRisk.Count += item.Count

            sumRiskAll.PAndL += item.PAndL
            sumRiskAll.Premium += item.Premium
            sumRiskAll.Delta += item.Delta
            sumRiskAll.GammaU += item.GammaU
            sumRiskAll.GammaD += item.GammaD
            sumRiskAll.Vega += item.Vega
            sumRiskAll.Theta += item.Theta
            sumRiskAll.Rho += item.Rho
            sumRiskAll.Count += item.Count
        Next

        ComList.Add(sumRiskAll.ComCode, sumRiskAll)

        For Each row As DataRow In TableSum.Rows
            Dim risk As TradeRiskData = ComList(row("ComCode"))
            If row("ComCode") <> "" Then
                row("Rate") = RateTickService.GetLastRate(risk.ComCode).Rate
                row("RateArrowCount") = RateTickService.GetLastRate(risk.ComCode).RateArrowCount
                row("ShortRate") = risk.sr * 100
                row("SwapRate") = risk.SwapRate * 100
                row("VolatilityAdjust") = risk.VolatilityAdjust * 100
                row("Volatility") = risk.sigma
            End If
            row("PAndL") = risk.PAndL
            row("Premium") = risk.Premium
            row("Delta") = risk.Delta
            row("GammaU") = risk.GammaU
            row("GammaD") = risk.GammaD
            row("Vega") = risk.Vega
            row("Theta") = risk.Theta
            row("Rho") = risk.Rho
            row("TradeCount") = risk.Count

        Next

        Dim DelProductList As New List(Of DataRow)
        For Each row As DataRow In TableDetail.Rows
            Dim ProductCode As String = row("DetailProductCode")
            If ProductList.ContainsKey(row("DetailProductCode")) Then
                Dim item As TradeRiskData = ProductList(ProductCode)
                row("DetailOpType") = OptionTypeManager.GetOptionTypeName(item.OpType)
                row("DetailOptionTime") = item.OptionTime
                row("DetailRate") = item.Rate
                row("DetailRateArrowCount") = item.RateArrowCount
                row("DetailZanzon") = DateTimeUtil.TimeSpanText(item.ExercTime, StdDt)
                row("DetailPAndL") = item.PAndL
                row("DetailPremium") = item.Premium
                row("DetailDelta") = item.Delta
                row("DetailGammaU") = item.GammaU
                row("DetailGammaD") = item.GammaD
                row("DetailVega") = item.Vega
                row("DetailTheta") = item.Theta
                row("DetailRho") = item.Rho
                row("DetailCount") = item.Count
                ProductList.Remove(ProductCode)
            Else
                DelProductList.Add(row)
            End If
        Next

        For Each row As DataRow In DelProductList
            TableDetail.Rows.Remove(row)
        Next

        For Each item As TradeRiskData In ProductList.Values
            Dim row As DataRow = TableDetail.NewRow()
            row("DetailProductCode") = item.ProductCode
            row("DetailComCode") = item.ComCode
            row("DetailComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("DetailRate") = item.Rate
            row("DetailRateArrowCount") = item.RateArrowCount
            row("DetailExercTime") = item.ExercTime
            row("DetailZanzon") = DateTimeUtil.TimeSpanText(item.ExercTime, StdDt)
            row("DetailPayoutRate") = item.PayoutRate
            row("DetailPAndL") = item.PAndL
            row("DetailPremium") = item.Premium
            row("DetailDelta") = item.Delta
            row("DetailGammaU") = item.GammaU
            row("DetailGammaD") = item.GammaD
            row("DetailVega") = item.Vega
            row("DetailTheta") = item.Theta
            row("DetailRho") = item.Rho
            row("DetailCount") = item.Count
            TableDetail.Rows.Add(row)
        Next

        'Dim a As Integer = 0
        'Dim b As Integer = 1 / a
    End Sub

    Private Sub serviceRateTick_NewTick() Handles serviceRateTick.NewTick
        Calc()
    End Sub

    Private Sub serviceTradeNow_DataChanged() Handles serviceTradeNow.DataChanged
        Calc()
    End Sub

    Private Sub gridSum_SelectionChanged(sender As Object, e As System.EventArgs) Handles gridSum.SelectionChanged
        If gridSum.SelectedRows.Count > 0 Then
            Dim ComCode As String = gridSum.SelectedRows(0).Cells("ComCode").Value
            If ComCode = "" Then
                ViewDetail.RowFilter = ""
            Else
                ViewDetail.RowFilter = String.Format("DetailComCode='{0}'", ComCode)
            End If
        End If
    End Sub

    Private Sub gridSum_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles gridSum.CellFormatting
        If e.RowIndex >= 0 Then
            If gridSum.Columns(e.ColumnIndex).DataPropertyName = "Rate" Then
                Dim ComCode As String = gridSum.Rows(e.RowIndex).Cells("ComCode").Value
                If ComCode <> "" Then
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
                End If
            End If
        End If
    End Sub

    Private Sub gridDetail_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles gridDetail.CellFormatting
        If e.RowIndex >= 0 Then
            Select Case gridDetail.Columns(e.ColumnIndex).DataPropertyName
                Case "DetailRate"
                    Dim ComCode As String = gridDetail.Rows(e.RowIndex).Cells("DetailComCode").Value
                    Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                    e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End Select
        End If
    End Sub

    Private Sub gridSum_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles gridSum.CellPainting
        If e.RowIndex >= 0 Then
            If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                If gridSum.Columns(e.ColumnIndex).Name = "Rate" Then
                    Dim ArrowCount As Integer = gridSum.Rows(e.RowIndex).Cells("RateArrowCount").Value
                    If ArrowCount <> 0 Then
                        e.Paint(e.CellBounds, e.PaintParts)
                        Dim ArrowChar As String
                        Dim ArrowColor As Color
                        If ArrowCount > 0 Then
                            ArrowChar = "▲"
                            ArrowColor = Color.Red
                        Else
                            ArrowChar = "▼"
                            ArrowColor = Color.Blue
                        End If
                        TextRenderer.DrawText(e.Graphics, ArrowChar, e.CellStyle.Font, e.CellBounds, ArrowColor, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub gridDetail_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles gridDetail.CellPainting
        If e.RowIndex >= 0 Then
            If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                If gridDetail.Columns(e.ColumnIndex).Name = "DetailRate" Then
                    Dim ArrowCount As Integer = gridDetail.Rows(e.RowIndex).Cells("DetailRateArrowCount").Value
                    If ArrowCount <> 0 Then
                        e.Paint(e.CellBounds, e.PaintParts)
                        Dim ArrowChar As String
                        Dim ArrowColor As Color
                        If ArrowCount > 0 Then
                            ArrowChar = "▲"
                            ArrowColor = Color.Red
                        Else
                            ArrowChar = "▼"
                            ArrowColor = Color.Blue
                        End If
                        TextRenderer.DrawText(e.Graphics, ArrowChar, e.CellStyle.Font, e.CellBounds, ArrowColor, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Function Floor(value As Double, DecimalPlaces As Integer) As Double
        Dim DecimalPlacesValue As Integer = Math.Pow(10, DecimalPlaces)
        Dim tmp As Double = value * DecimalPlacesValue
        If tmp >= 0 Then
            Return Math.Floor(tmp) / DecimalPlacesValue
        Else
            Return -Math.Floor(-tmp) / DecimalPlacesValue
        End If
    End Function

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles gridSum.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles gridSum.CellDoubleClick
        Dim code As String = gridSum.SelectedRows(0).Cells("ComCode").Value
        edit(code)
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles gridSum.CellMouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            gridSum.ClearSelection()
            gridSum.Rows(e.RowIndex).Selected = True
        End If
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = gridSum.SelectedRows(0).Cells("ComCode").Value
        edit(code)
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormCalcParamSettingsForm Then
            CalcParamSettingsForm.Close()
        End If
        CalcParamSettingsForm.MdiParent = MainWindow
        CalcParamSettingsForm.Code = code
        CalcParamSettingsForm.Show()
    End Sub

End Class
