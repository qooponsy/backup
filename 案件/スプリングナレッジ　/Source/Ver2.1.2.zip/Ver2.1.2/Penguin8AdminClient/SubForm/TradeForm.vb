﻿Imports System.Globalization

Public Class TradeForm

    Public Property Code As String

    Private Const TIME_FORMAT As String = "yyyy/MM/dd HH:mm:ss"
    Private Const TIME_FORMAT_NONE As String = " "

    Private WithEvents service As New TradeService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private comcode As String = ""
    Private optype As String = ""
    Private commission As Decimal = 0
    Private exercPayoutRate As Decimal = 0
    Private tmpProductCode As String = ""

    Private Sub TradeForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        cbTradeType.DisplayMember = "Name"
        cbTradeType.ValueMember = "Code"
        cbTradeType.DataSource = TradeTypeManager.GetList()

        cbTradeStatus.DisplayMember = "Name"
        cbTradeStatus.ValueMember = "Code"
        cbTradeStatus.DataSource = TradeStatusManager.GetList()

        cbExercStatus.DisplayMember = "Name"
        cbExercStatus.ValueMember = "Code"
        cbExercStatus.DataSource = ExercStatusManager.GetList()

        MainWindow.SubFormTradeForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub TradeForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormTradeForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "取引データ登録"
        Else
            If UserTypeManager.IsEdit(SessionService.UserType) Then
                Me.Text = "取引データ編集"
            Else
                Me.Text = "取引データ参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        tbProductCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnProductRef.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpSysDate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbTradeType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbPremium.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCustCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        dtpOrderReqTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOrderReqTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOrderClientRateSeq.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnRateSeqOrder.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpOrderClientRateTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOrderClientRateTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOrderClientRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        dtpAbandReqTime.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAbandReqTimeMilliseconds.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAbandClientRateSeq.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnRateSeqAband.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpAbandClientRateTime.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAbandClientRateTimeMilliseconds.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAbandClientRate.Enabled = isAband() And (status = FormMode.REGIST Or status = FormMode.EDIT)

        dtpTradeTime.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTradeTimeMilliseconds.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTradeRateSeq.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnRateSeqTrade.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpTradeRateTime.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTradeRateTimeMilliseconds.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTradeRate.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercPrice.Enabled = isTrade() And (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbExercStatus.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpExercProcTime.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercProcTimeMilliseconds.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercRateSeq.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnRateSeqExerc.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpExercRateTime.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercRateTimeMilliseconds.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbPayout.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbExercRate.Enabled = isExerc() And (status = FormMode.REGIST Or status = FormMode.EDIT)

        cbTradeStatus.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbInfoTitle.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbInfo.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbMemo.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        'If dtpAbandReqTime.Enabled Then
        '    dtpAbandReqTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpAbandReqTime.CustomFormat = " "
        'End If
        'If dtpAbandClientRateTime.Enabled Then
        '    dtpAbandClientRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpAbandClientRateTime.CustomFormat = " "
        'End If
        'If dtpTradeTime.Enabled Then
        '    dtpTradeTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpTradeTime.CustomFormat = " "
        'End If
        'If dtpTradeRateTime.Enabled Then
        '    dtpTradeRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpTradeRateTime.CustomFormat = " "
        'End If
        'If dtpExercProcTime.Enabled Then
        '    dtpExercProcTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpExercProcTime.CustomFormat = " "
        'End If
        'If dtpExercRateTime.Enabled Then
        '    dtpExercRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpExercRateTime.CustomFormat = " "
        'End If
        'If dtpOrderReqTime.Enabled Then
        '    dtpOrderReqTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpOrderReqTime.CustomFormat = " "
        'End If
        'If dtpOrderClientRateTime.Enabled Then
        '    dtpOrderClientRateTime.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        'Else
        '    dtpOrderClientRateTime.CustomFormat = " "
        'End If

        'btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        btnOK.Enabled = False
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Function isAband() As Boolean
        Select Case cbTradeStatus.SelectedValue
            Case "11", "20"
                Return True
        End Select
        Return False
    End Function

    Private Function isTrade() As Boolean
        Select Case cbTradeStatus.SelectedValue
            Case "02", "05", "10", "11", "12", "13", "20"
                Return True
        End Select
        Return False
    End Function

    Private Function isExerc() As Boolean
        Select Case cbTradeStatus.SelectedValue
            Case "10", "11", "12", "13", "20"
                Return True
        End Select
        Return False
    End Function

    Private Function isDelete() As Boolean
        Select Case cbTradeStatus.SelectedValue
            Case "20"
                Return True
        End Select
        Return False
    End Function

    Private Sub initRegist()
        dtpSysDate.Value = SysStatusService.GetData().SysDate
        cbTradeType.SelectedValue = ""
        cbTradeStatus.SelectedValue = ""
        cbExercStatus.SelectedValue = ""
    End Sub

    Private Sub initEdit()
        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of TradeData), existNextFlag As Boolean) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "取引データの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).TradeSeq <> Code Then
            MessageBox.Show(Me, "取引データの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            tmpProductCode = list(0).ProductCode
            'If UserTypeManager.IsEdit(SessionService.UserType) Then
            If False Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As TradeData)
        Me.lblCode.Text = data.TradeSeq
        Me.dtpSysDate.Value = data.SysDate
        cbTradeStatus.SelectedValue = data.TradeStatus
        cbTradeType.SelectedValue = data.TradeType
        cbExercStatus.SelectedValue = data.ExercStatus

        lblCode.Text = data.TradeSeq
        comcode = data.ComCode
        lblComName.Text = CurrencyPairService.GetData(data.ComCode).ComName
        optype = data.OpType
        lblOpType.Text = OptionTypeManager.GetOptionTypeName(optype)
        lblOptionTime.Text = DateTimeUtil.TimeConvView(data.OptionTime)
        lblExercTime.Text = data.ExercTime.ToString("yyyy/MM/dd HH:mm:ss")
        lblPAndL.Text = IIf(data.PAndLEnabled, data.PAndL.ToString(clsUtil.GetMoneyFormatDisp()), "")
        lblPayoutRate.Text = data.PayoutRate.ToString("######0.000#####")

        tbAbandClientRate.Text = IIf(data.AbandClientRateEnabled, data.AbandClientRate.ToString(clsUtil.GetMoneyFormatEdit()), "")
        tbExercRate.Text = IIf(data.ExercRateEnabled, data.ExercRate.ToString("######0.000#####"), "")
        tbOrderClientRate.Text = IIf(data.OrderClientRateEnabled, data.OrderClientRate.ToString("######0.000#####"), "")
        tbPayout.Text = IIf(data.PayoutEnabled, data.Payout.ToString(clsUtil.GetMoneyFormatEdit()), "")
        tbPremium.Text = data.Premium.ToString(clsUtil.GetMoneyFormatEdit())
        commission = data.Commission
        tbTradeRate.Text = IIf(data.TradeRateEnabled, data.TradeRate.ToString("######0.000#####"), "")
        tbExercPrice.Text = IIf(data.ExercPriceEnabled, data.ExercPrice.ToString("######0.000#####"), "")

        tbAbandClientRateSeq.Text = data.AbandClientRateSeq
        tbCustCode.Text = data.CustCode
        tbExercRateSeq.Text = data.ExercRateSeq
        tbInfoTitle.Text = data.InfoTitle
        tbInfo.Text = data.Info
        tbMemo.Text = data.Memo
        tbOrderClientRateSeq.Text = data.OrderClientRateSeq
        tbProductCode.Text = data.ProductCode
        tbTradeRateSeq.Text = data.TradeRateSeq

        dtpOrderClientRateTime.Checked = data.OrderClientRateTimeEnabled
        dtpOrderClientRateTime.Value = IIf(data.OrderClientRateTimeEnabled, data.OrderClientRateTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
        tbOrderClientRateTimeMilliseconds.Text = IIf(data.OrderClientRateTimeEnabled, data.OrderClientRateTime.ToString("fff"), "")
        dtpOrderReqTime.Checked = data.OrderReqTimeEnabled
        dtpOrderReqTime.Value = IIf(data.OrderReqTimeEnabled, data.OrderReqTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
        tbOrderReqTimeMilliseconds.Text = IIf(data.OrderReqTimeEnabled, data.OrderReqTime.ToString("fff"), "")

        dtpAbandClientRateTime.Checked = data.AbandClientRateTimeEnabled
        If dtpAbandClientRateTime.Checked Then
            dtpAbandClientRateTime.Value = IIf(data.AbandClientRateTimeEnabled, data.AbandClientRateTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
            tbAbandClientRateTimeMilliseconds.Text = IIf(data.AbandClientRateTimeEnabled, data.AbandClientRateTime.ToString("fff"), "")
        End If
        setTimeMode(dtpAbandClientRateTime, tbAbandClientRateTimeMilliseconds)
        dtpAbandReqTime.Checked = data.AbandReqTimeEnabled
        If dtpAbandReqTime.Checked Then
            dtpAbandReqTime.Value = IIf(data.AbandReqTimeEnabled, data.AbandReqTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
            tbAbandReqTimeMilliseconds.Text = IIf(data.AbandReqTimeEnabled, data.AbandReqTime.ToString("fff"), "")
        End If
        setTimeMode(dtpAbandReqTime, tbAbandReqTimeMilliseconds)

        dtpTradeRateTime.Checked = data.TradeRateTimeEnabled
        If dtpTradeRateTime.Checked Then
            dtpTradeRateTime.Value = IIf(data.TradeRateTimeEnabled, data.TradeRateTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
            tbTradeRateTimeMilliseconds.Text = IIf(data.TradeRateTimeEnabled, data.TradeRateTime.ToString("fff"), "")
        End If
        setTimeMode(dtpTradeRateTime, tbTradeRateTimeMilliseconds)
        dtpTradeTime.Checked = data.TradeTimeEnabled
        If dtpTradeTime.Checked Then
            dtpTradeTime.Value = IIf(data.TradeTimeEnabled, data.TradeTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
            tbTradeTimeMilliseconds.Text = IIf(data.TradeTimeEnabled, data.TradeTime.ToString("fff"), "")
        End If
        setTimeMode(dtpTradeTime, tbTradeTimeMilliseconds)

        dtpExercProcTime.Checked = data.ExercProcTimeEnabled
        If dtpExercProcTime.Checked Then
            dtpExercProcTime.Value = IIf(data.ExercProcTimeEnabled, data.ExercProcTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
            tbExercProcTimeMilliseconds.Text = IIf(data.ExercProcTimeEnabled, data.ExercProcTime.ToString("fff"), "")
        End If
        setTimeMode(dtpExercProcTime, tbExercProcTimeMilliseconds)
        dtpExercRateTime.Checked = data.ExercRateTimeEnabled
        If dtpExercRateTime.Checked Then
            dtpExercRateTime.Value = IIf(data.ExercRateTimeEnabled, data.ExercRateTime.ToString("yyyy/MM/dd HH:mm:ss"), DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("yyyy/MM/dd HH:mm:ss"))
            tbExercRateTimeMilliseconds.Text = IIf(data.ExercRateTimeEnabled, data.ExercRateTime.ToString("fff"), "")
        End If
        setTimeMode(dtpExercRateTime, tbExercProcTimeMilliseconds)
    End Sub

    Private Function getDataFromControl() As TradeData
        Dim ret As New TradeData

        ret.TradeSeq = Me.lblCode.Text
        ret.SysDate = Me.dtpSysDate.Value
        ret.ProductCode = Me.tbProductCode.Text
        ret.ComCode = comcode
        ret.OpType = optype
        ret.OptionTime = Me.lblOptionTime.Text
        ret.PayoutRate = Me.lblPayoutRate.Text
        If Me.lblExercTime.Text = "" Then
            ret.ExercTimeEnabled = False
        Else
            ret.ExercTimeEnabled = True
            ret.ExercTime = DateTime.Parse(Me.lblExercTime.Text)
        End If
        ret.TradeType = Me.cbTradeType.SelectedValue
        ret.Premium = Me.tbPremium.Text
        ret.Commission = commission
        ret.CustCode = Me.tbCustCode.Text
        ret.TradeStatus = Me.cbTradeStatus.SelectedValue
        ret.OrderReqTimeEnabled = True
        ret.OrderReqTime = Me.dtpOrderReqTime.Value
        If tbOrderReqTimeMilliseconds.Text <> "" Then
            ret.OrderReqTime = ret.OrderReqTime.AddMilliseconds(Integer.Parse(tbOrderReqTimeMilliseconds.Text))
        End If
        ret.OrderClientRateSeq = Me.tbOrderClientRateSeq.Text
        ret.OrderClientRateTimeEnabled = True
        ret.OrderClientRateTime = Me.dtpOrderClientRateTime.Value
        If tbOrderClientRateTimeMilliseconds.Text <> "" Then
            ret.OrderClientRateTime = ret.OrderClientRateTime.AddMilliseconds(Integer.Parse(tbOrderClientRateTimeMilliseconds.Text))
        End If
        If Me.tbOrderClientRate.Text = "" Then
            ret.OrderClientRateEnabled = False
        Else
            ret.OrderClientRateEnabled = True
            ret.OrderClientRate = Me.tbOrderClientRate.Text
        End If
        If isAband() Then
            If Not isDelete() Then
                ret.AbandReqTimeEnabled = True
                ret.AbandClientRateTimeEnabled = True
                ret.AbandClientRateEnabled = True
            Else
                ret.AbandReqTimeEnabled = dtpAbandReqTime.Checked
                ret.AbandClientRateTimeEnabled = dtpAbandClientRateTime.Checked
                ret.AbandClientRateEnabled = tbAbandClientRate.Text <> ""
            End If
            If ret.AbandReqTimeEnabled Then
                ret.AbandReqTime = Me.dtpAbandReqTime.Value
                If tbAbandReqTimeMilliseconds.Text <> "" Then
                    ret.AbandReqTime = ret.AbandReqTime.AddMilliseconds(Integer.Parse(tbAbandReqTimeMilliseconds.Text))
                End If
            End If
            ret.AbandClientRateSeq = Me.tbAbandClientRateSeq.Text
            If ret.AbandClientRateTimeEnabled Then
                ret.AbandClientRateTime = Me.dtpAbandClientRateTime.Value
                If tbAbandClientRateTimeMilliseconds.Text <> "" Then
                    ret.AbandClientRateTime = ret.AbandClientRateTime.AddMilliseconds(Integer.Parse(tbAbandClientRateTimeMilliseconds.Text))
                End If
            End If
            If ret.AbandClientRateEnabled Then
                ret.AbandClientRate = tbAbandClientRate.Text
            End If
        Else
            ret.AbandReqTimeEnabled = False
            ret.AbandClientRateSeq = ""
            ret.AbandClientRateTimeEnabled = False
            ret.AbandClientRateEnabled = False
        End If

        If isTrade() Then
            If Not isDelete() Then
                ret.TradeTimeEnabled = True
                ret.TradeRateTimeEnabled = True
                ret.TradeRateEnabled = True
                ret.ExercPriceEnabled = True
            Else
                ret.TradeTimeEnabled = dtpTradeTime.Checked
                ret.TradeRateTimeEnabled = dtpTradeRateTime.Checked
                ret.TradeRateEnabled = tbTradeRate.Text <> ""
                ret.ExercPriceEnabled = tbExercPrice.Text <> ""
            End If

            If ret.TradeTimeEnabled Then
                ret.TradeTime = dtpTradeTime.Value
                If tbTradeTimeMilliseconds.Text <> "" Then
                    ret.TradeTime = ret.TradeTime.AddMilliseconds(Integer.Parse(tbTradeTimeMilliseconds.Text))
                End If
            End If
            ret.TradeRateSeq = Me.tbTradeRateSeq.Text
            If ret.TradeRateTimeEnabled Then
                ret.TradeRateTime = dtpTradeRateTime.Value
                If tbTradeRateTimeMilliseconds.Text <> "" Then
                    ret.TradeRateTime = ret.TradeRateTime.AddMilliseconds(Integer.Parse(tbTradeRateTimeMilliseconds.Text))
                End If
            End If
            If ret.TradeRateEnabled Then

                ret.TradeRate = Me.tbTradeRate.Text
            End If
            If ret.ExercPriceEnabled Then
                ret.ExercPrice = Me.tbExercPrice.Text
            End If
        Else
            ret.TradeTimeEnabled = False
            ret.TradeRateSeq = ""
            ret.TradeRateTimeEnabled = False
            ret.TradeRateEnabled = False
            ret.ExercPriceEnabled = False
        End If
        If isExerc() Then
            If Not isDelete() Then
                ret.ExercProcTimeEnabled = True
                ret.ExercRateTimeEnabled = True
                ret.ExercRateEnabled = True
                ret.PayoutEnabled = True
            Else
                ret.ExercProcTimeEnabled = dtpExercProcTime.Checked
                ret.ExercRateTimeEnabled = dtpExercRateTime.Checked
                ret.ExercRateEnabled = tbExercRate.Text <> ""
                ret.PayoutEnabled = tbPayout.Text <> ""
            End If

            ret.ExercStatus = Me.cbExercStatus.SelectedValue

            If ret.ExercProcTimeEnabled Then
                ret.ExercProcTime = dtpExercProcTime.Value
                If tbExercProcTimeMilliseconds.Text <> "" Then
                    ret.ExercProcTime = ret.ExercProcTime.AddMilliseconds(Integer.Parse(tbExercProcTimeMilliseconds.Text))
                End If
            End If
            ret.ExercRateSeq = Me.tbExercRateSeq.Text
            If ret.ExercRateTimeEnabled Then
                ret.ExercRateTime = dtpExercRateTime.Value
                If tbExercRateTimeMilliseconds.Text <> "" Then
                    ret.ExercRateTime = ret.ExercRateTime.AddMilliseconds(Integer.Parse(tbExercRateTimeMilliseconds.Text))
                End If
            End If
            If ret.ExercRateEnabled Then
                ret.ExercRate = Me.tbExercRate.Text
            End If
            If ret.PayoutEnabled Then
                ret.Payout = Me.tbPayout.Text
            End If
            If Not ret.PayoutEnabled Then
                ret.PAndLEnabled = False
            Else
                ret.PAndLEnabled = True
                ret.PAndL = ret.Payout - ret.Premium
            End If
            If Not ret.PAndLEnabled Then
                ret.ExercPayoutRateEnabled = False
            Else
                ret.ExercPayoutRateEnabled = True
                ret.ExercPayoutRate = Math.Round(ret.PAndL / ret.Premium, 2, MidpointRounding.AwayFromZero)
            End If
        Else
            ret.ExercProcTimeEnabled = False
            ret.ExercRateSeq = ""
            ret.ExercRateTimeEnabled = False
            ret.ExercRateEnabled = False
            ret.PayoutEnabled = False
            ret.PAndLEnabled = False
            ret.ExercPayoutRateEnabled = False
        End If
        ret.Memo = Me.tbMemo.Text
        ret.InfoTitle = tbInfoTitle.Text
        ret.Info = Me.tbInfo.Text

        Return ret
    End Function

    Private Function checkInput() As Boolean
        If Me.tbProductCode.Text = "" OrElse Me.tbProductCode.Text.Length <> 17 Then
            MessageBox.Show(Me, "銘柄コードを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not (Me.tbProductCode.Text) = (Me.tmpProductCode) Then
            MessageBox.Show(Me, "銘柄を入力反映してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.cbTradeType.SelectedValue = "" Then
            MessageBox.Show(Me, "取引種別を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbPremium.Text = "" Then
            MessageBox.Show(Me, "取引金額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMoney.IsMatch(tbPremium.Text) Then
            MessageBox.Show(Me, "取引金額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim Premium As Decimal
        If Not Decimal.TryParse(tbPremium.Text, Premium) Then
            MessageBox.Show(Me, "取引金額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Premium <= 0 Then
            MessageBox.Show(Me, "取引金額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbCustCode.Text = "" OrElse Me.tbCustCode.Text.Length > 32 Then
            MessageBox.Show(Me, "委託者コードを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.cbTradeStatus.SelectedValue = "" Then
            MessageBox.Show(Me, "取引ステータスを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not CheckUtil.RegExMS.IsMatch(tbOrderReqTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "注文時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbOrderClientRateSeq.Text = "" OrElse tbOrderClientRateSeq.Text.Length <> 17 Then
            MessageBox.Show(Me, "注文時価格Seqを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbOrderClientRateTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "注文時価格時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Me.tbOrderClientRate.Text = "" Then
            MessageBox.Show(Me, "注文時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExRate.IsMatch(tbOrderClientRate.Text) Then
            MessageBox.Show(Me, "注文時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim OrderClientRate As Decimal
        If Not Decimal.TryParse(tbOrderClientRate.Text, OrderClientRate) Then
            MessageBox.Show(Me, "注文時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If OrderClientRate < 0 Then
            MessageBox.Show(Me, "注文時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If isAband() Then
            If Not isDelete() OrElse dtpAbandReqTime.Checked Then
                If Not dtpAbandReqTime.Checked Then
                    MessageBox.Show(Me, "放棄時間を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMS.IsMatch(tbAbandReqTimeMilliseconds.Text) Then
                    MessageBox.Show(Me, "放棄時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbAbandClientRateSeq.Text <> "" Then
                If Me.tbAbandClientRateSeq.Text = "" OrElse tbAbandClientRateSeq.Text.Length <> 17 Then
                    MessageBox.Show(Me, "放棄時価格Seqを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse dtpAbandClientRateTime.Checked Then
                If Not dtpAbandClientRateTime.Checked Then
                    MessageBox.Show(Me, "放棄時価格時間を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMS.IsMatch(tbAbandClientRateTimeMilliseconds.Text) Then
                    MessageBox.Show(Me, "放棄時価格時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbAbandClientRate.Text <> "" Then
                If Me.tbAbandClientRate.Text = "" Then
                    MessageBox.Show(Me, "放棄時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExRate.IsMatch(tbAbandClientRate.Text) Then
                    MessageBox.Show(Me, "放棄時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                Dim AbandClientRate As Decimal
                If Not Decimal.TryParse(tbAbandClientRate.Text, AbandClientRate) Then
                    MessageBox.Show(Me, "放棄時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If AbandClientRate < 0 Then
                    MessageBox.Show(Me, "放棄時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
        End If
        If isTrade() Then
            If Not isDelete() OrElse dtpTradeTime.Checked Then
                If Not dtpTradeTime.Checked Then
                    MessageBox.Show(Me, "約定時間を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMS.IsMatch(Me.tbTradeTimeMilliseconds.Text) Then
                    MessageBox.Show(Me, "約定時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbTradeRateSeq.Text <> "" Then
                If Me.tbTradeRateSeq.Text = "" OrElse tbTradeRateSeq.Text.Length <> 17 Then
                    MessageBox.Show(Me, "約定時価格Seqを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse dtpTradeRateTime.Checked Then
                If Not dtpTradeRateTime.Checked Then
                    MessageBox.Show(Me, "約定時価格時間を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMS.IsMatch(Me.tbTradeRateTimeMilliseconds.Text) Then
                    MessageBox.Show(Me, "約定時価格時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbTradeRate.Text <> "" Then
                If Me.tbTradeRate.Text = "" Then
                    MessageBox.Show(Me, "約定時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExRate.IsMatch(tbTradeRate.Text) Then
                    MessageBox.Show(Me, "約定時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                Dim TradeRate As Decimal
                If Not Decimal.TryParse(tbTradeRate.Text, TradeRate) Then
                    MessageBox.Show(Me, "約定時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If TradeRate < 0 Then
                    MessageBox.Show(Me, "約定時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbExercPrice.Text <> "" Then
                If Me.tbExercPrice.Text = "" Then
                    MessageBox.Show(Me, "行使価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExRate.IsMatch(tbExercPrice.Text) Then
                    MessageBox.Show(Me, "行使価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                Dim ExercPrice As Decimal
                If Not Decimal.TryParse(tbExercPrice.Text, ExercPrice) Then
                    MessageBox.Show(Me, "行使価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If ExercPrice < 0 Then
                    MessageBox.Show(Me, "行使価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
        End If
        If isExerc() Then
            If Not isDelete() OrElse Me.cbExercStatus.SelectedValue = "" Then
                MessageBox.Show(Me, "行使ステータスを入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If Not isDelete() OrElse dtpExercProcTime.Checked Then
                If Not dtpExercProcTime.Checked Then
                    MessageBox.Show(Me, "行使処理時間を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMS.IsMatch(Me.tbExercProcTimeMilliseconds.Text) Then
                    MessageBox.Show(Me, "行使処理時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbExercRateSeq.Text <> "" Then
                If Me.tbExercRateSeq.Text = "" OrElse tbExercRateSeq.Text.Length <> 17 Then
                    MessageBox.Show(Me, "行使時価格Seqを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse dtpExercRateTime.Checked Then
                If Not dtpExercRateTime.Checked Then
                    MessageBox.Show(Me, "行使時価格時間を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMS.IsMatch(Me.tbExercRateTimeMilliseconds.Text) Then
                    MessageBox.Show(Me, "行使時価格時間には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbExercRate.Text <> "" Then
                If Me.tbExercRate.Text = "" Then
                    MessageBox.Show(Me, "行使時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExRate.IsMatch(tbExercRate.Text) Then
                    MessageBox.Show(Me, "行使時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                Dim ExercRate As Decimal
                If Not Decimal.TryParse(tbExercRate.Text, ExercRate) Then
                    MessageBox.Show(Me, "行使時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If ExercRate < 0 Then
                    MessageBox.Show(Me, "行使時価格を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            If Not isDelete() OrElse Me.tbPayout.Text <> "" Then
                If Me.tbPayout.Text = "" Then
                    MessageBox.Show(Me, "ペイアウト額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Not CheckUtil.RegExMoney.IsMatch(tbPayout.Text) Then
                    MessageBox.Show(Me, "ペイアウト額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                Dim Payout As Decimal
                If Not Decimal.TryParse(tbPayout.Text, Payout) Then
                    MessageBox.Show(Me, "ペイアウト額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If Payout < 0 Then
                    MessageBox.Show(Me, "ペイアウト額を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As TradeData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As TradeData = getDataFromControl()

        service.Update(data)
    End Sub

    Private WithEvents serviceProduct As ProductService
    Private RefProductMode As Integer = 0

    Private Sub btnProductRef_Click(sender As System.Object, e As System.EventArgs) Handles btnProductRef.Click
        serviceProduct = New ProductService

        RefProductMode = 1
        serviceProduct.Read(tbProductCode.Text)
    End Sub

    Private Sub serviceProduct_ReadCancel() Handles serviceProduct.ReadCancel
        serviceProduct = Nothing
    End Sub

    Private Sub serviceProduct_ReadError(ErrorMessage As String) Handles serviceProduct.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        serviceProduct = Nothing
    End Sub

    Private Sub serviceProduct_ReadSuccess(list As System.Collections.Generic.List(Of ProductData), existNextFlag As Boolean) Handles serviceProduct.ReadSuccess
        serviceProduct = Nothing

        If list.Count <> 1 Then
            MessageBox.Show(Me, "銘柄の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            comcode = list(0).ComCode
            optype = list(0).OpType
            Select Case RefProductMode
                Case 1
                    lblComName.Text = list(0).ComCode
                    lblOpType.Text = list(0).OpTypeName()
                    lblOptionTime.Text = list(0).OptionTime
                    lblPayoutRate.Text = list(0).PayoutRate.ToString("######0.000#####")
                    lblExercTime.Text = list(0).ExercTime.ToString("yyyy/MM/dd HH:mm")
                    tmpProductCode = tbProductCode.Text
            End Select
        End If
    End Sub

    Private WithEvents serviceRateHist As RateHistService
    Private RefRateHistMode As Integer = 0

    Private Sub btnRateSeqOrder_Click(sender As System.Object, e As System.EventArgs) Handles btnRateSeqOrder.Click
        If tbOrderClientRateSeq.Text <> "" Then
            serviceRateHist = New RateHistService
            RefRateHistMode = 1
            serviceRateHist.Read(tbOrderClientRateSeq.Text)
        End If
    End Sub

    Private Sub btnRateSeqAband_Click(sender As System.Object, e As System.EventArgs) Handles btnRateSeqAband.Click
        If tbAbandClientRateSeq.Text <> "" Then
            serviceRateHist = New RateHistService
            RefRateHistMode = 2
            serviceRateHist.Read(tbAbandClientRateSeq.Text)
        End If
    End Sub

    Private Sub btnRateSeqTrade_Click(sender As System.Object, e As System.EventArgs) Handles btnRateSeqTrade.Click
        If tbTradeRateSeq.Text <> "" Then
            serviceRateHist = New RateHistService
            RefRateHistMode = 3
            serviceRateHist.Read(tbTradeRateSeq.Text)
        End If
    End Sub

    Private Sub btnRateSeqExerc_Click(sender As System.Object, e As System.EventArgs) Handles btnRateSeqExerc.Click
        If tbExercRateSeq.Text <> "" Then
            serviceRateHist = New RateHistService
            RefRateHistMode = 4
            serviceRateHist.Read(tbExercRateSeq.Text)
        End If
    End Sub

    Private Sub serviceRateHist_ReadCancel() Handles serviceRateHist.ReadCancel
        serviceRateHist = Nothing
    End Sub

    Private Sub serviceRateHist_ReadError(ErrorMessage As String) Handles serviceRateHist.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        serviceRateHist = Nothing
    End Sub

    Private Sub serviceRateHist_ReadSuccess(list As System.Collections.Generic.List(Of RateHistData), ExistNextFlag As Boolean) Handles serviceRateHist.ReadSuccess
        serviceRateHist = Nothing

        If list.Count <> 1 Then
            MessageBox.Show(Me, "レートの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Select Case RefRateHistMode
                Case 1
                    dtpOrderClientRateTime.Value = list(0).RateTime.ToString("yyyy/MM/dd HH:mm:ss")
                    tbOrderClientRate.Text = list(0).Rate.ToString("######0.000#####")
                Case 2
                    dtpAbandClientRateTime.Value = list(0).RateTime.ToString("yyyy/MM/dd HH:mm:ss")
                    tbAbandClientRate.Text = list(0).Rate.ToString("######0.000#####")
                Case 3
                    dtpTradeRateTime.Value = list(0).RateTime.ToString("yyyy/MM/dd HH:mm:ss")
                    tbTradeRate.Text = list(0).Rate.ToString("######0.000#####")
                Case 4
                    dtpExercRateTime.Value = list(0).RateTime.ToString("yyyy/MM/dd HH:mm:ss")
                    tbExercRate.Text = list(0).Rate.ToString("######0.000#####")
            End Select
        End If
    End Sub

    Private Sub CalcPAndL()
        Dim Premium As Decimal
        If Decimal.TryParse(tbPremium.Text, Premium) Then
            If Premium <> 0 Then
                Dim Payout As Decimal
                If Decimal.TryParse(tbPayout.Text, Payout) Then
                    lblPAndL.Text = Payout - Premium
                    Return
                End If
            End If
        End If
        lblPAndL.Text = ""
    End Sub

    Private Sub tbPremium_TextChanged(sender As System.Object, e As System.EventArgs) Handles tbPremium.TextChanged
        CalcPAndL()
    End Sub

    Private Sub tbPayout_TextChanged(sender As System.Object, e As System.EventArgs) Handles tbPayout.TextChanged
        CalcPAndL()
    End Sub

    Private Sub cbTradeStatus_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbTradeStatus.SelectedIndexChanged
        If isAband() Then
            If Not isDelete() Then
                dtpAbandReqTime.Checked = True
                dtpAbandClientRateTime.Checked = True
            End If
        Else
            dtpAbandReqTime.Checked = False
            dtpAbandClientRateTime.Checked = False
        End If
        setTimeMode(dtpAbandReqTime, tbAbandReqTimeMilliseconds)
        setTimeMode(dtpAbandClientRateTime, tbAbandClientRateTimeMilliseconds)
        If isTrade() Then
            If Not isDelete() Then
                dtpTradeTime.Checked = True
                dtpTradeRateTime.Checked = True
            End If
        Else
            dtpTradeTime.Checked = False
            dtpTradeRateTime.Checked = False
        End If
        setTimeMode(dtpTradeTime, tbTradeTimeMilliseconds)
        setTimeMode(dtpTradeRateTime, tbTradeRateTimeMilliseconds)
        If isExerc() Then
            If Not isDelete() Then
                dtpExercProcTime.Checked = True
                dtpExercRateTime.Checked = True
            End If
        Else
            dtpExercProcTime.Checked = False
            dtpExercRateTime.Checked = False
        End If
        setTimeMode(dtpExercProcTime, tbExercProcTimeMilliseconds)
        setTimeMode(dtpExercRateTime, tbExercRateTimeMilliseconds)

        setFormMode(FormModeStatus)
    End Sub

    Private Sub setTimeMode(dtp As DateTimePicker, ms As TextBox)
        If dtp.Checked Then
            dtp.CustomFormat = TIME_FORMAT
            ms.Enabled = True
        Else
            dtp.CustomFormat = TIME_FORMAT_NONE
            ms.Enabled = False
        End If
    End Sub

    Private Sub dtpTradeTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpTradeTime.ValueChanged
        setTimeMode(dtpTradeTime, tbTradeTimeMilliseconds)
    End Sub

    Private Sub dtpTradeRateTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpTradeRateTime.ValueChanged
        setTimeMode(dtpTradeRateTime, tbTradeRateTimeMilliseconds)
    End Sub

    Private Sub dtpAbandReqTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpAbandReqTime.ValueChanged
        setTimeMode(dtpAbandReqTime, tbAbandReqTimeMilliseconds)
    End Sub

    Private Sub dtpAbandClientRateTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpAbandClientRateTime.ValueChanged
        setTimeMode(dtpAbandClientRateTime, tbAbandClientRateTimeMilliseconds)
    End Sub

    Private Sub dtpExercProcTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpExercProcTime.ValueChanged
        setTimeMode(dtpExercProcTime, tbExercProcTimeMilliseconds)
    End Sub

    Private Sub dtpExercRateTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpExercRateTime.ValueChanged
        setTimeMode(dtpExercRateTime, tbExercRateTimeMilliseconds)
    End Sub
End Class