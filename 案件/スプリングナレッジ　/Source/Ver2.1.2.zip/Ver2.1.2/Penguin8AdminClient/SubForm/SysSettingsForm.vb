﻿Public Class SysSettingsForm

    Private WithEvents service As SysSettingsService
    Private WithEvents serviceRead As SysSettingsService

    Private Enum SettingWindowLayout
        Input = 0
        Confirm = 1
    End Enum

    Private ProductStartPreTime As Integer
    Private ProductEndLossTime As Integer

    ''' <summary>
    ''' フォーム - ロード時の処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub SysSettingsForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        MainWindow.SubFormSysSettingsForm = True

        LoadSettings()

        If UserTypeManager.IsAdmin(SessionService.UserType) Then
        Else
            btnSetSysSettingsAdminChk.Enabled = False
            btnSetSysSettingsAdmin.Enabled = False
            tbTradeMoneyMin.Enabled = False
            tbTradeMoneyMax.Enabled = False
            tbProductMoneyMax.Enabled = False
            tbCustCountMax.Enabled = False
            tbCustMoneyMax.Enabled = False
            tbCustMoneyDayMax.Enabled = False
            tbCustProductMoneyMax.Enabled = False
            tbCashInMoneyMin.Enabled = False
            tbCashInMoneyDayMin.Enabled = False
            tbCashOutMoneyMax.Enabled = False
            tbCashOutMoneyDayMax.Enabled = False
            tbRateEnableTime.Enabled = False
            tbAlertDayPAndL.Enabled = False
            tbAlertDayPAndLCust.Enabled = False
        End If

        readData()
        serviceRead = New SysSettingsService
        SysSettingsService.Read()
    End Sub

    Private Sub SysSettingsForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormSysSettingsForm = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        If UserSettings.getInstance().DataSaved.SysSettingsForm_FormLocation <> New System.Drawing.Point(Integer.MinValue, Integer.MinValue) Then
            Me.Location = UserSettings.getInstance().DataSaved.SysSettingsForm_FormLocation
        End If
        [clsUtil].GuardSubFormLocation(Me)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        UserSettings.getInstance().DataSaved.SysSettingsForm_FormLocation = [clsUtil].GetFormLocation(Me)
    End Sub

    ''' <summary>
    ''' [内容確認]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSetSysSettingsAdminChk_Click(sender As System.Object, e As System.EventArgs) Handles btnSetSysSettingsAdminChk.Click
        Dim ErrorText As String = ""
        If Not checkInput(ErrorText) Then
            MessageBox.Show(Me, ErrorText, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        setWindowLayout(SettingWindowLayout.Confirm)
    End Sub

    ''' <summary>
    ''' [キャンセル]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnCancelChk_Click(sender As System.Object, e As System.EventArgs) Handles btnCancelChk.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' [戻る]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        setWindowLayout(SettingWindowLayout.Input)
    End Sub

    ''' <summary>
    ''' [登録]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSetSysSettingsAdmin_Click(sender As System.Object, e As System.EventArgs) Handles btnSetSysSettingsAdmin.Click
        writeData()
    End Sub

    ''' <summary>ウィンドウレイアウトの切り替え</summary>
    Private Sub setWindowLayout(ByVal LayoutType As Integer)
        Select Case LayoutType
            Case SettingWindowLayout.Confirm
                '確認・キャンセルボタンを非表示にする
                btnSetSysSettingsAdminChk.Visible = False
                btnCancelChk.Visible = False

                '登録・戻るボタンを表示する
                btnSetSysSettingsAdmin.Visible = True
                btnCancel.Visible = True

                '入力項目を入力不可能にする
                tbTradeMoneyMin.Enabled = False
                tbTradeMoneyMax.Enabled = False
                tbProductMoneyMax.Enabled = False
                tbCustCountMax.Enabled = False
                tbCustMoneyMax.Enabled = False
                tbCustMoneyDayMax.Enabled = False
                tbCustProductMoneyMax.Enabled = False
                tbCashInMoneyMin.Enabled = False
                tbCashInMoneyDayMin.Enabled = False
                tbCashOutMoneyMax.Enabled = False
                tbCashOutMoneyDayMax.Enabled = False
                tbRateEnableTime.Enabled = False
                tbAlertDayPAndL.Enabled = False
                tbAlertDayPAndLCust.Enabled = False

            Case SettingWindowLayout.Input
                '確認・キャンセルボタンを表示する
                btnSetSysSettingsAdminChk.Visible = True
                btnCancelChk.Visible = True

                '登録・戻るボタン非表示にする
                btnSetSysSettingsAdmin.Visible = False
                btnCancel.Visible = False

                '入力項目を入力可能にする
                tbTradeMoneyMin.Enabled = True
                tbTradeMoneyMax.Enabled = True
                tbProductMoneyMax.Enabled = True
                tbCustCountMax.Enabled = True
                tbCustMoneyMax.Enabled = True
                tbCustMoneyDayMax.Enabled = True
                tbCustProductMoneyMax.Enabled = True
                tbCashInMoneyMin.Enabled = True
                tbCashInMoneyDayMin.Enabled = True
                tbCashOutMoneyMax.Enabled = True
                tbCashOutMoneyDayMax.Enabled = True
                tbRateEnableTime.Enabled = True
                tbAlertDayPAndL.Enabled = True
                tbAlertDayPAndLCust.Enabled = True
        End Select

    End Sub

    Private Function checkInput(ByRef ErrorText As String) As Boolean

        Dim TradeMoneyMin As Decimal
        If Not checkInputMoney("最少取引額(1回)銘柄", tbTradeMoneyMin.Text, TradeMoneyMin, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最少取引額(1回)銘柄", TradeMoneyMin, 1, 100, ErrorText) Then
            Return False
        End If

        Dim TradeMoneyMax As Decimal
        If Not checkInputMoney("最大取引額(1回)銘柄", tbTradeMoneyMax.Text, TradeMoneyMax, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大取引額(1回)銘柄", TradeMoneyMax, 100, 10000, ErrorText) Then
            Return False
        End If

        Dim ProductMoneyMax As Decimal
        If Not checkInputMoney("最大購入可能額(銘柄)", tbProductMoneyMax.Text, ProductMoneyMax, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大購入可能額(銘柄)", ProductMoneyMax, 10000, 100000, ErrorText) Then
            Return False
        End If

        Dim RateEnableTime As Integer
        If Not checkInputInteger("レート有効時間(秒)", tbRateEnableTime.Text, RateEnableTime, ErrorText) Then
            Return False
        End If
        If Not checkInputIntRange("レート有効時間(秒)", RateEnableTime, 1, 100, ErrorText) Then
            Return False
        End If

        Dim CustCountMax As Integer
        If Not checkInputInteger("最大保有建玉数(顧客)", tbCustCountMax.Text, CustCountMax, ErrorText) Then
            Return False
        End If
        If Not checkInputIntRange("最大保有建玉数(顧客)", CustCountMax, 1, 1000, ErrorText) Then
            Return False
        End If

        Dim CustMoneyMax As Decimal
        If Not checkInputMoney("最大購入可能額(顧客)", tbCustMoneyMax.Text, CustMoneyMax, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大購入可能額(顧客)", CustMoneyMax, 0, 10000, ErrorText) Then
            Return False
        End If

        Dim CustMoneyDayMax As Decimal
        If Not checkInputMoney("最大購入可能額(1日)(顧客)", tbCustMoneyDayMax.Text, CustMoneyDayMax, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大購入可能額(1日)(顧客)", CustMoneyDayMax, 0, 100000, ErrorText) Then
            Return False
        End If

        Dim CustProductMoneyMax As Decimal
        If Not checkInputMoney("最大購入可能額(1銘柄)(顧客)", tbCustProductMoneyMax.Text, CustProductMoneyMax, ErrorText) Then
            Return False
        End If

        Dim CashInMoneyMin As Decimal
        If Not checkInputMoney("最小入金可能額(1回)", tbCashInMoneyMin.Text, CashInMoneyMin, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最小入金可能額(1回)", CashInMoneyMin, 0.01, 100, ErrorText) Then
            Return False
        End If

        Dim CashInMoneyDayMin As Decimal
        If Not checkInputMoney("最大入金可能額(1日)", tbCashInMoneyDayMin.Text, CashInMoneyDayMin, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大入金可能額(1日)", CashInMoneyDayMin, 0, 10000000000, ErrorText) Then
            Return False
        End If

        Dim CashOutMoneyMax As Decimal
        If Not checkInputMoney("最大出金可能額(1回)", tbCashOutMoneyMax.Text, CashOutMoneyMax, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大出金可能額(1回)", CashOutMoneyMax, 0, 10000000000, ErrorText) Then
            Return False
        End If

        Dim CashOutMoneyDayMax As Decimal
        If Not checkInputMoney("最大出金可能額(1日)", tbCashOutMoneyDayMax.Text, CashOutMoneyDayMax, ErrorText) Then
            Return False
        End If
        If Not checkInputDobleRange("最大出金可能額(1日)", CashOutMoneyDayMax, 0, 10000000001, ErrorText) Then
            Return False
        End If

        Dim AlertDayPAndL As Decimal
        If Not checkInputMoney("アラート損益", tbAlertDayPAndL.Text, AlertDayPAndL, ErrorText) Then
            Return False
        End If

        Dim AlertDayPAndLCust As Decimal
        If Not checkInputMoney("アラート損益(顧客)", tbAlertDayPAndLCust.Text, AlertDayPAndLCust, ErrorText) Then
            Return False
        End If

        Return True
    End Function

    Private Function checkInputMoney(ItemName As String, InputValue As String, ByRef OutputValue As Decimal, ByRef ErrorText As String) As Boolean
        If InputValue.Length = 0 Then
            ErrorText = ItemName & "が未入力です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        If Not CheckUtil.RegExMoney.IsMatch(InputValue) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        Dim valueDecimal As Decimal
        If Not Decimal.TryParse(InputValue, valueDecimal) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        OutputValue = valueDecimal
        Return True
    End Function

    Private Function checkInputMinutes(ItemName As String, InputValue As String, ByRef OutputValue As Integer, ByRef ErrorText As String) As Boolean
        If InputValue.Length = 0 Then
            ErrorText = ItemName & "が未入力です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        If Not CheckUtil.RegExInt.IsMatch(InputValue) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        Dim valueInteger As Integer
        If Not Integer.TryParse(InputValue, valueInteger) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        OutputValue = valueInteger
        Return True
    End Function

    Private Function checkInputPercent(ItemName As String, InputValue As String, ByRef OutputValue As Decimal, ByRef ErrorText As String) As Boolean
        If InputValue.Length = 0 Then
            ErrorText = ItemName & "が未入力です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        If Not CheckUtil.RegExPercent.IsMatch(InputValue) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        Dim valueInteger As Decimal
        If Not Decimal.TryParse(InputValue, valueInteger) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        OutputValue = valueInteger
        Return True
    End Function

    Private Function checkInputInteger(ItemName As String, InputValue As String, ByRef OutputValue As Integer, ByRef ErrorText As String) As Boolean
        If InputValue.Length = 0 Then
            ErrorText = ItemName & "が未入力です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        If Not CheckUtil.RegExInt.IsMatch(InputValue) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        Dim valueInteger As Integer
        If Not Integer.TryParse(InputValue, valueInteger) Then
            ErrorText = ItemName & "の入力内容が不正です。" & vbCrLf & "入力値を確認して下さい。"
            Return False
        End If
        OutputValue = valueInteger
        Return True
    End Function

    Private Function checkInputIntRange(ItemName As String, InputValue As Integer, MinValue As Integer, MaxValue As Integer, ByRef ErrorText As String) As Boolean
        If InputValue < MinValue Or InputValue > MaxValue Then
            ErrorText = ItemName & "には" & MinValue & "以上かつ" & MaxValue & "以下の適切な数値を入力してください。"
            Return False
        End If
        Return True
    End Function

    Private Function checkInputDobleRange(ItemName As String, InputValue As Double, MinValue As Double, MaxValue As Double, ByRef ErrorText As String) As Boolean
        If InputValue < MinValue Or InputValue > MaxValue Then
            ErrorText = ItemName & "には" & MinValue & "以上かつ" & MaxValue & "以下の適切な数値を入力してください。"
            Return False
        End If
        Return True
    End Function

    Private Sub readData()
        Dim data As SysSettingsData = SysSettingsService.GetData()

        tbTradeMoneyMin.Text = data.TradeMoneyMin.ToString(clsUtil.GetMoneyFormatEdit())
        tbTradeMoneyMax.Text = data.TradeMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbProductMoneyMax.Text = data.ProductMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbCustCountMax.Text = data.CustCountMax
        tbCustMoneyMax.Text = data.CustMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbCustMoneyDayMax.Text = data.CustMoneyDayMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbCustProductMoneyMax.Text = data.CustProductMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbCashInMoneyMin.Text = data.CashInMoneyMin.ToString(clsUtil.GetMoneyFormatEdit())
        tbCashInMoneyDayMin.Text = data.CashInMoneyDayMin.ToString(clsUtil.GetMoneyFormatEdit())
        tbCashOutMoneyMax.Text = data.CashOutMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbCashOutMoneyDayMax.Text = data.CashOutMoneyDayMax.ToString(clsUtil.GetMoneyFormatEdit())
        tbRateEnableTime.Text = data.RateEnableTime
        tbAlertDayPAndL.Text = data.AlertDayPAndL.ToString(clsUtil.GetMoneyFormatEdit())
        tbAlertDayPAndLCust.Text = data.AlertDayPAndLCust.ToString(clsUtil.GetMoneyFormatEdit())

        ProductStartPreTime = data.ProductStartPreTime
        ProductEndLossTime = data.ProductEndLossTime
    End Sub

    Private Sub writeData()
        Dim data As New SysSettingsData

        data.Commission = 0
        data.TradeMoneyMin = Me.tbTradeMoneyMin.Text
        data.TradeMoneyMax = Me.tbTradeMoneyMax.Text
        data.ProductMoneyMax = Me.tbProductMoneyMax.Text
        data.CustCountMax = Me.tbCustCountMax.Text
        data.CustMoneyMax = Me.tbCustMoneyMax.Text
        data.CustMoneyDayMax = Me.tbCustMoneyDayMax.Text
        data.CustProductMoneyMax = Me.tbCustProductMoneyMax.Text
        data.CashInMoneyMin = Me.tbCashInMoneyMin.Text
        data.CashInMoneyDayMin = Me.tbCashInMoneyDayMin.Text
        data.CashOutMoneyMax = Me.tbCashOutMoneyMax.Text
        data.CashOutMoneyDayMax = Me.tbCashOutMoneyDayMax.Text
        data.ProductStartPreTime = ProductStartPreTime
        data.ProductEndLossTime = ProductEndLossTime
        data.RateEnableTime = Me.tbRateEnableTime.Text
        data.AlertDayPAndL = Me.tbAlertDayPAndL.Text
        data.AlertDayPAndLCust = Me.tbAlertDayPAndLCust.Text

        service = New SysSettingsService
        SysSettingsService.Regist(data)
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        service = Nothing
        serviceRead = New SysSettingsService
        SysSettingsService.Read()
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setWindowLayout(SettingWindowLayout.Input)
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        service = Nothing
        serviceRead = New SysSettingsService
        SysSettingsService.Read()
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setWindowLayout(SettingWindowLayout.Input)
    End Sub

    Private Sub service_RegistSuccess() Handles service.RegistSuccess
        service = Nothing
        serviceRead = New SysSettingsService
        SysSettingsService.Read()
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK)
        setWindowLayout(SettingWindowLayout.Input)
    End Sub

    Private Sub serviceRead_ReadCancel() Handles serviceRead.ReadCancel
        serviceRead = Nothing
        readData()
    End Sub

    Private Sub serviceRead_ReadError(ErrorMessage As String) Handles serviceRead.ReadError
        serviceRead = Nothing
        readData()
    End Sub

    Private Sub serviceRead_ReadSuccess(Data As SysSettingsData) Handles serviceRead.ReadSuccess
        serviceRead = Nothing
        readData()
    End Sub

End Class