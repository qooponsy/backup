﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.cbEnabled = New System.Windows.Forms.ComboBox()
        Me.lblEnabled = New System.Windows.Forms.Label()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.cbUserType = New System.Windows.Forms.ComboBox()
        Me.lblCmpCode = New System.Windows.Forms.Label()
        Me.lblUserType = New System.Windows.Forms.Label()
        Me.tbPassword = New System.Windows.Forms.TextBox()
        Me.tbUserName = New System.Windows.Forms.TextBox()
        Me.tbUserID = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.lblUserID = New System.Windows.Forms.Label()
        Me.lblAccountLock = New System.Windows.Forms.Label()
        Me.cbAccountLockFlag = New System.Windows.Forms.ComboBox()
        Me.lblPasswordUpdTime = New System.Windows.Forms.Label()
        Me.tbPasswordUpdTime = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(197, 235)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(98, 29)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(44, 235)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(98, 29)
        Me.btnOK.TabIndex = 6
        Me.btnOK.Text = "内容確認"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'cbEnabled
        '
        Me.cbEnabled.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbEnabled.FormattingEnabled = True
        Me.cbEnabled.Location = New System.Drawing.Point(135, 42)
        Me.cbEnabled.Name = "cbEnabled"
        Me.cbEnabled.Size = New System.Drawing.Size(200, 20)
        Me.cbEnabled.TabIndex = 1
        '
        'lblEnabled
        '
        Me.lblEnabled.AutoSize = True
        Me.lblEnabled.Location = New System.Drawing.Point(25, 46)
        Me.lblEnabled.Name = "lblEnabled"
        Me.lblEnabled.Size = New System.Drawing.Size(54, 12)
        Me.lblEnabled.TabIndex = 24
        Me.lblEnabled.Text = "有効フラグ"
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(135, 175)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(200, 20)
        Me.cbCmpCode.TabIndex = 5
        '
        'cbUserType
        '
        Me.cbUserType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbUserType.FormattingEnabled = True
        Me.cbUserType.Location = New System.Drawing.Point(135, 148)
        Me.cbUserType.Name = "cbUserType"
        Me.cbUserType.Size = New System.Drawing.Size(200, 20)
        Me.cbUserType.TabIndex = 4
        '
        'lblCmpCode
        '
        Me.lblCmpCode.AutoSize = True
        Me.lblCmpCode.Location = New System.Drawing.Point(25, 178)
        Me.lblCmpCode.Name = "lblCmpCode"
        Me.lblCmpCode.Size = New System.Drawing.Size(29, 12)
        Me.lblCmpCode.TabIndex = 32
        Me.lblCmpCode.Text = "会社"
        '
        'lblUserType
        '
        Me.lblUserType.AutoSize = True
        Me.lblUserType.Location = New System.Drawing.Point(25, 152)
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(69, 12)
        Me.lblUserType.TabIndex = 30
        Me.lblUserType.Text = "ユーザー種別"
        '
        'tbPassword
        '
        Me.tbPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.tbPassword.Location = New System.Drawing.Point(135, 122)
        Me.tbPassword.MaxLength = 16
        Me.tbPassword.Name = "tbPassword"
        Me.tbPassword.Size = New System.Drawing.Size(200, 19)
        Me.tbPassword.TabIndex = 3
        '
        'tbUserName
        '
        Me.tbUserName.Location = New System.Drawing.Point(135, 96)
        Me.tbUserName.MaxLength = 128
        Me.tbUserName.Name = "tbUserName"
        Me.tbUserName.Size = New System.Drawing.Size(200, 19)
        Me.tbUserName.TabIndex = 2
        '
        'tbUserID
        '
        Me.tbUserID.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.tbUserID.Location = New System.Drawing.Point(135, 17)
        Me.tbUserID.MaxLength = 32
        Me.tbUserID.Name = "tbUserID"
        Me.tbUserID.Size = New System.Drawing.Size(200, 19)
        Me.tbUserID.TabIndex = 0
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(25, 125)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(52, 12)
        Me.lblPassword.TabIndex = 28
        Me.lblPassword.Text = "パスワード"
        '
        'lblUserName
        '
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Location = New System.Drawing.Point(25, 99)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(57, 12)
        Me.lblUserName.TabIndex = 26
        Me.lblUserName.Text = "ユーザー名"
        '
        'lblUserID
        '
        Me.lblUserID.AutoSize = True
        Me.lblUserID.Location = New System.Drawing.Point(25, 20)
        Me.lblUserID.Name = "lblUserID"
        Me.lblUserID.Size = New System.Drawing.Size(56, 12)
        Me.lblUserID.TabIndex = 22
        Me.lblUserID.Text = "ユーザーID"
        '
        'lblAccountLock
        '
        Me.lblAccountLock.AutoSize = True
        Me.lblAccountLock.Location = New System.Drawing.Point(25, 72)
        Me.lblAccountLock.Name = "lblAccountLock"
        Me.lblAccountLock.Size = New System.Drawing.Size(73, 12)
        Me.lblAccountLock.TabIndex = 33
        Me.lblAccountLock.Text = "アカウントロック"
        '
        'cbAccountLockFlag
        '
        Me.cbAccountLockFlag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbAccountLockFlag.FormattingEnabled = True
        Me.cbAccountLockFlag.Location = New System.Drawing.Point(135, 69)
        Me.cbAccountLockFlag.Name = "cbAccountLockFlag"
        Me.cbAccountLockFlag.Size = New System.Drawing.Size(200, 20)
        Me.cbAccountLockFlag.TabIndex = 34
        '
        'lblPasswordUpdTime
        '
        Me.lblPasswordUpdTime.AutoSize = True
        Me.lblPasswordUpdTime.Location = New System.Drawing.Point(25, 207)
        Me.lblPasswordUpdTime.Name = "lblPasswordUpdTime"
        Me.lblPasswordUpdTime.Size = New System.Drawing.Size(100, 12)
        Me.lblPasswordUpdTime.TabIndex = 35
        Me.lblPasswordUpdTime.Text = "パスワード変更日付"
        '
        'tbPasswordUpdTime
        '
        Me.tbPasswordUpdTime.Enabled = False
        Me.tbPasswordUpdTime.Location = New System.Drawing.Point(135, 204)
        Me.tbPasswordUpdTime.Name = "tbPasswordUpdTime"
        Me.tbPasswordUpdTime.Size = New System.Drawing.Size(200, 19)
        Me.tbPasswordUpdTime.TabIndex = 37
        '
        'UserForm
        '
        Me.AcceptButton = Me.btnOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(353, 280)
        Me.Controls.Add(Me.tbPasswordUpdTime)
        Me.Controls.Add(Me.lblPasswordUpdTime)
        Me.Controls.Add(Me.cbAccountLockFlag)
        Me.Controls.Add(Me.lblAccountLock)
        Me.Controls.Add(Me.cbEnabled)
        Me.Controls.Add(Me.lblEnabled)
        Me.Controls.Add(Me.cbCmpCode)
        Me.Controls.Add(Me.cbUserType)
        Me.Controls.Add(Me.lblCmpCode)
        Me.Controls.Add(Me.lblUserType)
        Me.Controls.Add(Me.tbPassword)
        Me.Controls.Add(Me.tbUserName)
        Me.Controls.Add(Me.tbUserID)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblUserName)
        Me.Controls.Add(Me.lblUserID)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "UserForm"
        Me.Text = "ユーザー登録"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents cbEnabled As System.Windows.Forms.ComboBox
    Friend WithEvents lblEnabled As System.Windows.Forms.Label
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbUserType As System.Windows.Forms.ComboBox
    Friend WithEvents lblCmpCode As System.Windows.Forms.Label
    Friend WithEvents lblUserType As System.Windows.Forms.Label
    Friend WithEvents tbPassword As System.Windows.Forms.TextBox
    Friend WithEvents tbUserName As System.Windows.Forms.TextBox
    Friend WithEvents tbUserID As System.Windows.Forms.TextBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents lblUserID As System.Windows.Forms.Label
    Friend WithEvents lblAccountLock As System.Windows.Forms.Label
    Friend WithEvents cbAccountLockFlag As System.Windows.Forms.ComboBox
    Friend WithEvents lblPasswordUpdTime As System.Windows.Forms.Label
    Friend WithEvents tbPasswordUpdTime As System.Windows.Forms.TextBox
End Class
