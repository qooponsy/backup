﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductBaseList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.btnTradeMoneyChange = New System.Windows.Forms.Button()
        Me.btnSpreadChange = New System.Windows.Forms.Button()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnReflesh = New System.Windows.Forms.Button()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.miCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.ProductBaseCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpTypeCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OpType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OptionTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CreateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartSummerTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExercSummerTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PayoutRate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Spread = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductBaseEnabledCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StopTradeTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandMargine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VolatilityAdjust = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProductBaseEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SpreadUpdateTarget = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.SpreadUpdate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeMoneyMinUpdate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeMoneyMaxUpdate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartAbandTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbandPriceDiff = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeMoneyMin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TradeMoneyMax = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmGrid.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbOpType)
        Me.Panel1.Controls.Add(Me.btnTradeMoneyChange)
        Me.Panel1.Controls.Add(Me.btnSpreadChange)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnReflesh)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(841, 78)
        Me.Panel1.TabIndex = 4
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Location = New System.Drawing.Point(139, 12)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(121, 20)
        Me.cbOpType.TabIndex = 19
        '
        'btnTradeMoneyChange
        '
        Me.btnTradeMoneyChange.Location = New System.Drawing.Point(669, 38)
        Me.btnTradeMoneyChange.Name = "btnTradeMoneyChange"
        Me.btnTradeMoneyChange.Size = New System.Drawing.Size(149, 29)
        Me.btnTradeMoneyChange.TabIndex = 18
        Me.btnTradeMoneyChange.Text = "最小最大取引額一括変更"
        Me.btnTradeMoneyChange.UseVisualStyleBackColor = True
        '
        'btnSpreadChange
        '
        Me.btnSpreadChange.Location = New System.Drawing.Point(531, 38)
        Me.btnSpreadChange.Name = "btnSpreadChange"
        Me.btnSpreadChange.Size = New System.Drawing.Size(132, 29)
        Me.btnSpreadChange.TabIndex = 17
        Me.btnSpreadChange.Text = "スプレッド一括変更"
        Me.btnSpreadChange.UseVisualStyleBackColor = True
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(420, 38)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 3
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnReflesh
        '
        Me.btnReflesh.Location = New System.Drawing.Point(331, 38)
        Me.btnReflesh.Name = "btnReflesh"
        Me.btnReflesh.Size = New System.Drawing.Size(89, 29)
        Me.btnReflesh.TabIndex = 2
        Me.btnReflesh.Text = "更新"
        Me.btnReflesh.UseVisualStyleBackColor = True
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(266, 14)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 1
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(12, 12)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 0
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ProductBaseCode, Me.ComCode, Me.ComName, Me.OpTypeCode, Me.OpType, Me.OptionTime, Me.CreateTime, Me.StartTime, Me.ExercTime, Me.StartSummerTime, Me.ExercSummerTime, Me.PayoutRate, Me.Spread, Me.ProductBaseEnabledCode, Me.StopTradeTime, Me.AbandMargine, Me.VolatilityAdjust, Me.ProductBaseEnabled, Me.SpreadUpdateTarget, Me.SpreadUpdate, Me.TradeMoneyMinUpdate, Me.TradeMoneyMaxUpdate, Me.StartAbandTime, Me.AbandPriceDiff, Me.TradeMoneyMin, Me.TradeMoneyMax})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 78)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle26.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle26
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(841, 159)
        Me.grid.TabIndex = 5
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit, Me.miCopy})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(113, 48)
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(112, 22)
        Me.miEdit.Text = "編集"
        '
        'miCopy
        '
        Me.miCopy.Name = "miCopy"
        Me.miCopy.Size = New System.Drawing.Size(112, 22)
        Me.miCopy.Text = "コピー"
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(293, 134)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(203, 63)
        Me.lblNoData.TabIndex = 16
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProductBaseCode
        '
        Me.ProductBaseCode.DataPropertyName = "ProductBaseCode"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseCode.DefaultCellStyle = DataGridViewCellStyle2
        Me.ProductBaseCode.HeaderText = "銘柄設定コード"
        Me.ProductBaseCode.Name = "ProductBaseCode"
        Me.ProductBaseCode.ReadOnly = True
        Me.ProductBaseCode.Width = 108
        '
        'ComCode
        '
        Me.ComCode.DataPropertyName = "ComCode"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.ComCode.HeaderText = "通貨ペア(code)"
        Me.ComCode.Name = "ComCode"
        Me.ComCode.ReadOnly = True
        Me.ComCode.Visible = False
        Me.ComCode.Width = 80
        '
        'ComName
        '
        Me.ComName.DataPropertyName = "ComName"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ComName.DefaultCellStyle = DataGridViewCellStyle4
        Me.ComName.HeaderText = "通貨ペア"
        Me.ComName.Name = "ComName"
        Me.ComName.ReadOnly = True
        Me.ComName.Width = 73
        '
        'OpTypeCode
        '
        Me.OpTypeCode.HeaderText = "オプション種別(code)"
        Me.OpTypeCode.Name = "OpTypeCode"
        Me.OpTypeCode.Visible = False
        '
        'OpType
        '
        Me.OpType.DataPropertyName = "OpType"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.OpType.DefaultCellStyle = DataGridViewCellStyle5
        Me.OpType.HeaderText = "オプション種別"
        Me.OpType.Name = "OpType"
        Me.OpType.ReadOnly = True
        Me.OpType.Width = 97
        '
        'OptionTime
        '
        Me.OptionTime.DataPropertyName = "OptionTime"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.NullValue = Nothing
        Me.OptionTime.DefaultCellStyle = DataGridViewCellStyle6
        Me.OptionTime.HeaderText = "オプション期間"
        Me.OptionTime.Name = "OptionTime"
        Me.OptionTime.ReadOnly = True
        Me.OptionTime.Width = 97
        '
        'CreateTime
        '
        Me.CreateTime.DataPropertyName = "CreateTime"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.NullValue = Nothing
        Me.CreateTime.DefaultCellStyle = DataGridViewCellStyle7
        Me.CreateTime.HeaderText = "生成間隔"
        Me.CreateTime.Name = "CreateTime"
        Me.CreateTime.ReadOnly = True
        Me.CreateTime.Width = 78
        '
        'StartTime
        '
        Me.StartTime.DataPropertyName = "StartTime"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.NullValue = Nothing
        Me.StartTime.DefaultCellStyle = DataGridViewCellStyle8
        Me.StartTime.HeaderText = "生成開始時間"
        Me.StartTime.Name = "StartTime"
        Me.StartTime.ReadOnly = True
        Me.StartTime.Width = 102
        '
        'ExercTime
        '
        Me.ExercTime.DataPropertyName = "ExercTime"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.NullValue = Nothing
        Me.ExercTime.DefaultCellStyle = DataGridViewCellStyle9
        Me.ExercTime.HeaderText = "最終行使期日"
        Me.ExercTime.Name = "ExercTime"
        Me.ExercTime.ReadOnly = True
        Me.ExercTime.Width = 102
        '
        'StartSummerTime
        '
        Me.StartSummerTime.DataPropertyName = "StartSummerTime"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.StartSummerTime.DefaultCellStyle = DataGridViewCellStyle10
        Me.StartSummerTime.HeaderText = "生成開始時間（夏時間）"
        Me.StartSummerTime.Name = "StartSummerTime"
        Me.StartSummerTime.ReadOnly = True
        Me.StartSummerTime.Width = 102
        '
        'ExercSummerTime
        '
        Me.ExercSummerTime.DataPropertyName = "ExercSummerTime"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ExercSummerTime.DefaultCellStyle = DataGridViewCellStyle11
        Me.ExercSummerTime.HeaderText = "最終行使期日（夏時間）"
        Me.ExercSummerTime.Name = "ExercSummerTime"
        Me.ExercSummerTime.ReadOnly = True
        Me.ExercSummerTime.Width = 102
        '
        'PayoutRate
        '
        Me.PayoutRate.DataPropertyName = "PayoutRate"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle12.Format = "######0.00######"
        DataGridViewCellStyle12.NullValue = Nothing
        Me.PayoutRate.DefaultCellStyle = DataGridViewCellStyle12
        Me.PayoutRate.HeaderText = "ペイアウト率"
        Me.PayoutRate.Name = "PayoutRate"
        Me.PayoutRate.ReadOnly = True
        Me.PayoutRate.Width = 85
        '
        'Spread
        '
        Me.Spread.DataPropertyName = "Spread"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Spread.DefaultCellStyle = DataGridViewCellStyle13
        Me.Spread.HeaderText = "スプレッド"
        Me.Spread.Name = "Spread"
        Me.Spread.ReadOnly = True
        Me.Spread.Width = 80
        '
        'ProductBaseEnabledCode
        '
        Me.ProductBaseEnabledCode.DataPropertyName = "ProductBaseEnabledCode"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseEnabledCode.DefaultCellStyle = DataGridViewCellStyle14
        Me.ProductBaseEnabledCode.HeaderText = "有効フラグ(Code)"
        Me.ProductBaseEnabledCode.Name = "ProductBaseEnabledCode"
        Me.ProductBaseEnabledCode.ReadOnly = True
        Me.ProductBaseEnabledCode.Visible = False
        '
        'StopTradeTime
        '
        Me.StopTradeTime.DataPropertyName = "StopTradeTime"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle15.Format = "####秒"
        Me.StopTradeTime.DefaultCellStyle = DataGridViewCellStyle15
        Me.StopTradeTime.HeaderText = "取引停止時間(秒)"
        Me.StopTradeTime.Name = "StopTradeTime"
        Me.StopTradeTime.ReadOnly = True
        Me.StopTradeTime.Width = 85
        '
        'AbandMargine
        '
        Me.AbandMargine.DataPropertyName = "AbandMargine"
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle16.Format = "######0.########"
        Me.AbandMargine.DefaultCellStyle = DataGridViewCellStyle16
        Me.AbandMargine.HeaderText = "権利放棄手数料(%)"
        Me.AbandMargine.Name = "AbandMargine"
        Me.AbandMargine.Width = 90
        '
        'VolatilityAdjust
        '
        Me.VolatilityAdjust.DataPropertyName = "VolatilityAdjust"
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle17.Format = "######0.########"
        Me.VolatilityAdjust.DefaultCellStyle = DataGridViewCellStyle17
        Me.VolatilityAdjust.HeaderText = "ボラティリティレシオ(%)"
        Me.VolatilityAdjust.Name = "VolatilityAdjust"
        Me.VolatilityAdjust.ReadOnly = True
        Me.VolatilityAdjust.Width = 95
        '
        'ProductBaseEnabled
        '
        Me.ProductBaseEnabled.DataPropertyName = "ProductBaseEnabled"
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ProductBaseEnabled.DefaultCellStyle = DataGridViewCellStyle18
        Me.ProductBaseEnabled.HeaderText = "有効フラグ"
        Me.ProductBaseEnabled.Name = "ProductBaseEnabled"
        Me.ProductBaseEnabled.ReadOnly = True
        Me.ProductBaseEnabled.Width = 79
        '
        'SpreadUpdateTarget
        '
        Me.SpreadUpdateTarget.DataPropertyName = "SpreadUpdateTarget"
        Me.SpreadUpdateTarget.HeaderText = "変更"
        Me.SpreadUpdateTarget.Name = "SpreadUpdateTarget"
        Me.SpreadUpdateTarget.Width = 40
        '
        'SpreadUpdate
        '
        Me.SpreadUpdate.DataPropertyName = "SpreadUpdate"
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.SpreadUpdate.DefaultCellStyle = DataGridViewCellStyle19
        Me.SpreadUpdate.HeaderText = "変更スプレッド"
        Me.SpreadUpdate.Name = "SpreadUpdate"
        Me.SpreadUpdate.ReadOnly = True
        Me.SpreadUpdate.Width = 80
        '
        'TradeMoneyMinUpdate
        '
        Me.TradeMoneyMinUpdate.DataPropertyName = "TradeMoneyMinUpdate"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.TradeMoneyMinUpdate.DefaultCellStyle = DataGridViewCellStyle20
        Me.TradeMoneyMinUpdate.HeaderText = "変更最小取引額"
        Me.TradeMoneyMinUpdate.Name = "TradeMoneyMinUpdate"
        Me.TradeMoneyMinUpdate.ReadOnly = True
        Me.TradeMoneyMinUpdate.Width = 80
        '
        'TradeMoneyMaxUpdate
        '
        Me.TradeMoneyMaxUpdate.DataPropertyName = "TradeMoneyMaxUpdate"
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.TradeMoneyMaxUpdate.DefaultCellStyle = DataGridViewCellStyle21
        Me.TradeMoneyMaxUpdate.HeaderText = "変更最大取引額"
        Me.TradeMoneyMaxUpdate.Name = "TradeMoneyMaxUpdate"
        Me.TradeMoneyMaxUpdate.ReadOnly = True
        Me.TradeMoneyMaxUpdate.Width = 80
        '
        'StartAbandTime
        '
        Me.StartAbandTime.DataPropertyName = "StartAbandTime"
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle22.Format = "####秒"
        Me.StartAbandTime.DefaultCellStyle = DataGridViewCellStyle22
        Me.StartAbandTime.HeaderText = "権利放棄可能時間(秒)"
        Me.StartAbandTime.Name = "StartAbandTime"
        Me.StartAbandTime.Width = 110
        '
        'AbandPriceDiff
        '
        Me.AbandPriceDiff.DataPropertyName = "AbandPriceDiff"
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.AbandPriceDiff.DefaultCellStyle = DataGridViewCellStyle23
        Me.AbandPriceDiff.HeaderText = "権利放棄可能価格差(pips)"
        Me.AbandPriceDiff.Name = "AbandPriceDiff"
        Me.AbandPriceDiff.Width = 110
        '
        'TradeMoneyMin
        '
        Me.TradeMoneyMin.DataPropertyName = "TradeMoneyMin"
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.TradeMoneyMin.DefaultCellStyle = DataGridViewCellStyle24
        Me.TradeMoneyMin.HeaderText = "最小取引額(1回)銘柄"
        Me.TradeMoneyMin.Name = "TradeMoneyMin"
        '
        'TradeMoneyMax
        '
        Me.TradeMoneyMax.DataPropertyName = "TradeMoneyMax"
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.TradeMoneyMax.DefaultCellStyle = DataGridViewCellStyle25
        Me.TradeMoneyMax.HeaderText = "最大取引額(1回)銘柄"
        Me.TradeMoneyMax.Name = "TradeMoneyMax"
        '
        'ProductBaseList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(841, 237)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "ProductBaseList"
        Me.Text = "銘柄設定一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmGrid.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents btnReflesh As System.Windows.Forms.Button
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents btnSpreadChange As System.Windows.Forms.Button
    Friend WithEvents miCopy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnTradeMoneyChange As System.Windows.Forms.Button
    Friend WithEvents cbOpType As ComboBox
    Friend WithEvents ProductBaseCode As DataGridViewTextBoxColumn
    Friend WithEvents ComCode As DataGridViewTextBoxColumn
    Friend WithEvents ComName As DataGridViewTextBoxColumn
    Friend WithEvents OpTypeCode As DataGridViewTextBoxColumn
    Friend WithEvents OpType As DataGridViewTextBoxColumn
    Friend WithEvents OptionTime As DataGridViewTextBoxColumn
    Friend WithEvents CreateTime As DataGridViewTextBoxColumn
    Friend WithEvents StartTime As DataGridViewTextBoxColumn
    Friend WithEvents ExercTime As DataGridViewTextBoxColumn
    Friend WithEvents StartSummerTime As DataGridViewTextBoxColumn
    Friend WithEvents ExercSummerTime As DataGridViewTextBoxColumn
    Friend WithEvents PayoutRate As DataGridViewTextBoxColumn
    Friend WithEvents Spread As DataGridViewTextBoxColumn
    Friend WithEvents ProductBaseEnabledCode As DataGridViewTextBoxColumn
    Friend WithEvents StopTradeTime As DataGridViewTextBoxColumn
    Friend WithEvents AbandMargine As DataGridViewTextBoxColumn
    Friend WithEvents VolatilityAdjust As DataGridViewTextBoxColumn
    Friend WithEvents ProductBaseEnabled As DataGridViewTextBoxColumn
    Friend WithEvents SpreadUpdateTarget As DataGridViewCheckBoxColumn
    Friend WithEvents SpreadUpdate As DataGridViewTextBoxColumn
    Friend WithEvents TradeMoneyMinUpdate As DataGridViewTextBoxColumn
    Friend WithEvents TradeMoneyMaxUpdate As DataGridViewTextBoxColumn
    Friend WithEvents StartAbandTime As DataGridViewTextBoxColumn
    Friend WithEvents AbandPriceDiff As DataGridViewTextBoxColumn
    Friend WithEvents TradeMoneyMin As DataGridViewTextBoxColumn
    Friend WithEvents TradeMoneyMax As DataGridViewTextBoxColumn
End Class
