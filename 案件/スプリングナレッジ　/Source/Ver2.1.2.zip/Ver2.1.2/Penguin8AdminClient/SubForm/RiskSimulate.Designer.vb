﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RiskSimulate
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim StripLine2 As System.Windows.Forms.DataVisualization.Charting.StripLine = New System.Windows.Forms.DataVisualization.Charting.StripLine()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series4 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCurCode = New System.Windows.Forms.ComboBox()
        Me.chkAutoReCalc = New System.Windows.Forms.CheckBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.lblRate = New System.Windows.Forms.Label()
        Me.lblComCode = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbExercTime = New System.Windows.Forms.ComboBox()
        Me.btnRun = New System.Windows.Forms.Button()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PAndL = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PAndLR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.chart = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.TimerRefresh = New System.Windows.Forms.Timer(Me.components)
        Me.cbOpType = New System.Windows.Forms.ComboBox()
        Me.Panel1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbOpType)
        Me.Panel1.Controls.Add(Me.cbCurCode)
        Me.Panel1.Controls.Add(Me.chkAutoReCalc)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.lblRate)
        Me.Panel1.Controls.Add(Me.lblComCode)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.lblTime)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.cbExercTime)
        Me.Panel1.Controls.Add(Me.btnRun)
        Me.Panel1.Controls.Add(Me.cbComCode)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(926, 62)
        Me.Panel1.TabIndex = 0
        '
        'cbCurCode
        '
        Me.cbCurCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCurCode.FormattingEnabled = True
        Me.cbCurCode.Location = New System.Drawing.Point(133, 3)
        Me.cbCurCode.Name = "cbCurCode"
        Me.cbCurCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCurCode.TabIndex = 1
        '
        'chkAutoReCalc
        '
        Me.chkAutoReCalc.AutoSize = True
        Me.chkAutoReCalc.Location = New System.Drawing.Point(511, 37)
        Me.chkAutoReCalc.Name = "chkAutoReCalc"
        Me.chkAutoReCalc.Size = New System.Drawing.Size(126, 16)
        Me.chkAutoReCalc.TabIndex = 10
        Me.chkAutoReCalc.Text = "自動更新（5秒間隔）"
        Me.chkAutoReCalc.UseVisualStyleBackColor = True
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(6, 4)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 0
        '
        'lblRate
        '
        Me.lblRate.BackColor = System.Drawing.Color.White
        Me.lblRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRate.Location = New System.Drawing.Point(286, 33)
        Me.lblRate.Name = "lblRate"
        Me.lblRate.Size = New System.Drawing.Size(78, 22)
        Me.lblRate.TabIndex = 8
        Me.lblRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblComCode
        '
        Me.lblComCode.BackColor = System.Drawing.Color.White
        Me.lblComCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblComCode.Location = New System.Drawing.Point(213, 33)
        Me.lblComCode.Name = "lblComCode"
        Me.lblComCode.Size = New System.Drawing.Size(67, 22)
        Me.lblComCode.TabIndex = 7
        Me.lblComCode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(151, 38)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 12)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "現在レート"
        '
        'lblTime
        '
        Me.lblTime.BackColor = System.Drawing.Color.White
        Me.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTime.Location = New System.Drawing.Point(71, 33)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(62, 22)
        Me.lblTime.TabIndex = 5
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 12)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "現在時刻"
        '
        'cbExercTime
        '
        Me.cbExercTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbExercTime.FormattingEnabled = True
        Me.cbExercTime.Location = New System.Drawing.Point(514, 4)
        Me.cbExercTime.Name = "cbExercTime"
        Me.cbExercTime.Size = New System.Drawing.Size(220, 20)
        Me.cbExercTime.TabIndex = 3
        '
        'btnRun
        '
        Me.btnRun.Location = New System.Drawing.Point(402, 28)
        Me.btnRun.Name = "btnRun"
        Me.btnRun.Size = New System.Drawing.Size(89, 29)
        Me.btnRun.TabIndex = 9
        Me.btnRun.Text = "実行"
        Me.btnRun.UseVisualStyleBackColor = True
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Location = New System.Drawing.Point(387, 4)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(121, 20)
        Me.cbComCode.TabIndex = 2
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 62)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblNoData)
        Me.SplitContainer1.Panel1.Controls.Add(Me.grid)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.chart)
        Me.SplitContainer1.Size = New System.Drawing.Size(926, 385)
        Me.SplitContainer1.SplitterDistance = 304
        Me.SplitContainer1.TabIndex = 1
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(28, 161)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(219, 63)
        Me.lblNoData.TabIndex = 19
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Rate, Me.PAndL, Me.PAndLR})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 0)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(304, 385)
        Me.grid.TabIndex = 0
        '
        'Rate
        '
        Me.Rate.DataPropertyName = "Rate"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle7.Format = "######0.000#####"
        Me.Rate.DefaultCellStyle = DataGridViewCellStyle7
        Me.Rate.HeaderText = "レート"
        Me.Rate.Name = "Rate"
        Me.Rate.ReadOnly = True
        Me.Rate.Width = 80
        '
        'PAndL
        '
        Me.PAndL.DataPropertyName = "PAndL"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Format = "#,###,###,##0"
        Me.PAndL.DefaultCellStyle = DataGridViewCellStyle8
        Me.PAndL.HeaderText = "P/L"
        Me.PAndL.Name = "PAndL"
        Me.PAndL.ReadOnly = True
        '
        'PAndLR
        '
        Me.PAndLR.DataPropertyName = "PAndLR"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "#,###,###,##0"
        Me.PAndLR.DefaultCellStyle = DataGridViewCellStyle9
        Me.PAndLR.HeaderText = "P/L(理論)"
        Me.PAndLR.Name = "PAndLR"
        Me.PAndLR.ReadOnly = True
        '
        'chart
        '
        ChartArea2.AxisX.IsMarginVisible = False
        ChartArea2.AxisX.IsStartedFromZero = False
        ChartArea2.AxisX.LabelAutoFitStyle = CType(((System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.StaggeredLabels Or System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.LabelsAngleStep30) _
            Or System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles.WordWrap), System.Windows.Forms.DataVisualization.Charting.LabelAutoFitStyles)
        ChartArea2.AxisX.LabelStyle.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        ChartArea2.AxisX.MajorGrid.Enabled = False
        StripLine2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        StripLine2.BorderWidth = 2
        StripLine2.IntervalOffset = 5.5R
        StripLine2.Text = "5.5"
        StripLine2.TextAlignment = System.Drawing.StringAlignment.Center
        StripLine2.TextOrientation = System.Windows.Forms.DataVisualization.Charting.TextOrientation.Horizontal
        ChartArea2.AxisX.StripLines.Add(StripLine2)
        ChartArea2.AxisY.IsLabelAutoFit = False
        ChartArea2.AxisY.LabelStyle.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        ChartArea2.AxisY.LabelStyle.Format = "###,###,###,###,##0"
        ChartArea2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        ChartArea2.Name = "ChartArea1"
        Me.chart.ChartAreas.Add(ChartArea2)
        Me.chart.Dock = System.Windows.Forms.DockStyle.Fill
        Legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top
        Legend2.Name = "Legend1"
        Me.chart.Legends.Add(Legend2)
        Me.chart.Location = New System.Drawing.Point(0, 0)
        Me.chart.Name = "chart"
        Series3.BorderWidth = 2
        Series3.ChartArea = "ChartArea1"
        Series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series3.Legend = "Legend1"
        Series3.Name = "P/L"
        Series4.BorderWidth = 2
        Series4.ChartArea = "ChartArea1"
        Series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line
        Series4.Color = System.Drawing.Color.Red
        Series4.Legend = "Legend1"
        Series4.Name = "P/L(理論)"
        Me.chart.Series.Add(Series3)
        Me.chart.Series.Add(Series4)
        Me.chart.Size = New System.Drawing.Size(618, 385)
        Me.chart.TabIndex = 1
        Me.chart.Text = "Chart1"
        '
        'TimerRefresh
        '
        Me.TimerRefresh.Interval = 5000
        '
        'cbOpType
        '
        Me.cbOpType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbOpType.FormattingEnabled = True
        Me.cbOpType.Location = New System.Drawing.Point(260, 4)
        Me.cbOpType.Name = "cbOpType"
        Me.cbOpType.Size = New System.Drawing.Size(121, 20)
        Me.cbOpType.TabIndex = 22
        '
        'RiskSimulate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(926, 447)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "RiskSimulate"
        Me.Text = "リスクシミュレーション"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnRun As System.Windows.Forms.Button
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents chart As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents cbExercTime As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblRate As System.Windows.Forms.Label
    Friend WithEvents lblComCode As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents Rate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PAndL As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PAndLR As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents TimerRefresh As System.Windows.Forms.Timer
    Friend WithEvents chkAutoReCalc As System.Windows.Forms.CheckBox
    Friend WithEvents cbCurCode As System.Windows.Forms.ComboBox
    Friend WithEvents cbOpType As ComboBox
End Class
