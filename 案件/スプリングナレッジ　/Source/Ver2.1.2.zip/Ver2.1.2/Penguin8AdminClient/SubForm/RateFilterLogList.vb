﻿Imports System.Net
Imports System.Collections.Specialized

Public Class RateFilterLogList
    Private WithEvents service As RateFilterLogService
    Private WithEvents serviceRateTick As RateTickService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private realMode As Boolean = False

    Private formModeStatus As FormMode = FormMode.INIT

    Private RateFilterUpdateSeq As Int64 = 0

    Private Table As DataTable
    Private View As DataView
    Private Start As Integer = 1

    Private Sub RateFilterLogList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        cbDataType.DisplayMember = "Name"
        cbDataType.ValueMember = "Code"
        cbDataType.DataSource = RateFilterLogTypeManager.GetDataTypeList()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        cbLogType.DisplayMember = "Name"
        cbLogType.ValueMember = "Code"
        cbLogType.DataSource = RateFilterLogTypeManager.GetLogTypeList()

        grid.AutoGenerateColumns = False

        '初期値の設定
        dtpFromDateTime.Value = SysSettingsService.GetStartDate()
        dtpFromDateTime.Checked = False
        dtpToDateTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone)
        dtpToDateTime.Checked = False

        MainWindow.SubFormRateFilterLogList = True

        chkAlertRateFilterSettings.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterSettings
        chkAlertRateFilter.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_RateFilter
        chkAlertRateFilterCounterClear.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterCounterClear
        chkAlertRateChanged.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_RateChanged
        chkAlertAnomalyRate.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRate
        chkAlertAnomalyRateClear.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRateClear
        chkAlertRateTimeDiff.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiff
        chkAlertRateTimeDiffClear.Checked = UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiffClear

        LoadSettings()

        initGrid()

        If cbDataType.SelectedValue = "0" Then
            realMode = True
            requestReal()
        Else
            realMode = False
            formModeStatus = FormMode.NORMAL
        End If
        setWindowLayout(False)

        serviceRateTick = New RateTickService
    End Sub

    Private Sub RateFilterLogList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceRateTick = Nothing
        SaveSettings()
        MainWindow.SubFormRateFilterLogList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RateFilterLogList_FormMaximized, _
            UserSettings.getInstance().DataSaved.RateFilterLogList_FormSize, _
            UserSettings.getInstance().DataSaved.RateFilterLogList_FormLocation)
        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RateFilterLogList_Columns)
        cbDataType.SelectedValue = UserSettings.getInstance().DataSaved.RateFilterLogList_DataType
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.RateFilterLogList_ComCode
        cbLogType.SelectedValue = UserSettings.getInstance().DataSaved.RateFilterLogList_LogType
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.RateFilterLogList_FormMaximized, _
            UserSettings.getInstance().DataSaved.RateFilterLogList_FormSize, _
            UserSettings.getInstance().DataSaved.RateFilterLogList_FormLocation)
        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.RateFilterLogList_Columns)
        UserSettings.getInstance().DataSaved.RateFilterLogList_DataType = cbDataType.SelectedValue
        UserSettings.getInstance().DataSaved.RateFilterLogList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.RateFilterLogList_LogType = cbLogType.SelectedValue
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("LogTime", GetType(DateTime))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("LogType", GetType(String))
        Table.Columns.Add("LogText", GetType(String))
        View = New DataView(Table)
        grid.DataSource = View
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of RateFilterLogData))
        For Each item As RateFilterLogData In list
            Dim row As DataRow = Table.NewRow()
            row("LogTime") = item.LogTime
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("LogType") = item.LogTypeName
            row("LogText") = item.LogText
            Table.Rows.Add(row)
        Next
    End Sub

    Private Sub setGridReal(list As List(Of RateFilterLogData))
        Dim DispTopRowIndex As Integer = grid.FirstDisplayedScrollingRowIndex

        Dim index As Integer = 0
        For Each item As RateFilterLogData In list
            Dim row As DataRow = Table.NewRow()
            row("LogTime") = item.LogTime
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("LogType") = item.LogTypeName
            row("LogText") = item.LogText
            Table.Rows.InsertAt(row, index)
            index += 1
        Next
        For fa As Integer = 100 To Table.Rows.Count - 1
            Table.Rows.RemoveAt(100)
        Next

        If DispTopRowIndex >= 0 Then
            grid.FirstDisplayedScrollingRowIndex = DispTopRowIndex
        End If
    End Sub

    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                setWindowLayout(False)

                If cbDataType.SelectedValue = "0" Then
                    realMode = True
                    RateFilterUpdateSeq = 0
                    requestReal()
                Else
                    realMode = False
                    request()
                End If
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        Dim DataType As String = Me.cbDataType.SelectedValue
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim LogType As String = Me.cbLogType.SelectedValue
        Dim FromDateTime As String = IIf(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = IIf(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")

        service = New RateFilterLogService
        service.ReadList(ComCode, LogType, FromDateTime, ToDateTime, "", Start)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestReal()
        If Me.RateFilterUpdateSeq < RateTickService.RateFilterUpdateSeq Then
            service = New RateFilterLogService
            service.Read(RateFilterUpdateSeq)
            formModeStatus = FormMode.READ
            btnSearch.Text = "キャンセル"
        End If
    End Sub

    Private Sub requestEnd()
        service = Nothing
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of RateFilterLogData), existNextFlag As Boolean, RateFilterUpdateSeq As Int64) Handles service.ReadSuccess
        If realMode Then
            If Me.RateFilterUpdateSeq = 0 Then
                Table.Rows.Clear()
            End If
            setGridReal(list)

            lblNoData.Visible = False
        Else
            If Start = 1 Then
                Table.Rows.Clear()
            End If
            setGrid(list)

            lblNoData.Visible = (Start = 1 And list.Count = 0)
        End If
        Me.RateFilterUpdateSeq = RateFilterUpdateSeq
        requestEnd()
        setWindowLayout(existNextFlag)
        If realMode Then
            requestReal()
        End If


    End Sub

    Private Sub cbListType_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbDataType.SelectedIndexChanged
        cbComCode.Enabled = (cbDataType.SelectedValue = "1")
        cbLogType.Enabled = (cbDataType.SelectedValue = "1")
        dtpFromDateTime.Enabled = (cbDataType.SelectedValue = "1")
        dtpToDateTime.Enabled = (cbDataType.SelectedValue = "1")
    End Sub

    Private Sub serviceRateTick_NewTick() Handles serviceRateTick.NewTick
        If realMode Then
            requestReal()
        End If
    End Sub

    Private Sub chkAlertRateFilterSettings_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertRateFilterSettings.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterSettings = chkAlertRateFilterSettings.Checked
    End Sub

    Private Sub chkAlertRateFilter_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertRateFilter.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_RateFilter = chkAlertRateFilter.Checked
    End Sub

    Private Sub chkAlertRateFilterCounterClear_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertRateFilterCounterClear.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_RateFilterCounterClear = chkAlertRateFilterCounterClear.Checked
    End Sub

    Private Sub chkAlertRateChanged_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertRateChanged.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_RateChanged = chkAlertRateChanged.Checked
    End Sub

    Private Sub chkAlertAnomalyRate_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertAnomalyRate.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRate = chkAlertAnomalyRate.Checked
    End Sub

    Private Sub chkAlertAnomalyRateClear_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertAnomalyRateClear.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_AnomalyRateClear = chkAlertAnomalyRateClear.Checked
    End Sub

    Private Sub chkAlertRateTimeDiff_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertRateTimeDiff.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiff = chkAlertRateTimeDiff.Checked
    End Sub

    Private Sub chkAlertRateTimeDiffClear_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlertRateTimeDiffClear.CheckedChanged
        UserSettings.getInstance().DataSaved.RateLogAlert_RateTimeDiffClear = chkAlertRateTimeDiffClear.Checked
    End Sub

End Class