﻿Public Class SysControlForm
    Private WithEvents service As SysStatusService

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub SysControlForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        'レートプロバイダ一覧取得
        'メインフォームの初期処理で呼び出したので不要
        'If Not RateProviderService.Init() Then
        '    MessageBox.Show(SysStatusService.ErrorText, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    Return
        'End If

        MainWindow.SubFormSysControlForm = True

        LoadSettings()

        If UserTypeManager.IsAdmin(SessionService.UserType) Then
        Else
            btnSystemStop.Enabled = False
            btnSysSuspend.Enabled = False
            btnSysOperation.Enabled = False
            btnAbandSuspend.Enabled = False
            btnAbandOperation.Enabled = False
            btnCashOutSuspend.Enabled = False
            btnCashOutOperation.Enabled = False
            btnCashInSuspend.Enabled = False
            btnCashInOperation.Enabled = False
        End If

        'システム状態、レートプロバイダ一覧取得、ボタン設定
        setForm()

        service = New SysStatusService
        SysStatusService.Read()
    End Sub

    Private Sub SysControlForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        service = Nothing
        SaveSettings()
        MainWindow.SubFormSysControlForm = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        If UserSettings.getInstance().DataSaved.SysControlForm_FormLocation <> New System.Drawing.Point(Integer.MinValue, Integer.MinValue) Then
            Me.Location = UserSettings.getInstance().DataSaved.SysControlForm_FormLocation
        End If
        [clsUtil].GuardSubFormLocation(Me)
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        UserSettings.getInstance().DataSaved.SysControlForm_FormLocation = [clsUtil].GetFormLocation(Me)
    End Sub


    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="RateProviderDataList"></param>
    ''' <remarks></remarks>
    Private Sub MakeDataGridView(RateProviderDataList As List(Of RateProviderData))

        dgRateProvider.Rows.Clear()

        'セルの高さ
        dgRateProvider.RowTemplate.Height = 30

        If Not RateProviderDataList Is Nothing Then
            Dim AdminMode As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
            dgRateProvider.Columns(0).Visible = AdminMode
            For i As Integer = 0 To RateProviderDataList.Count - 1
                Dim Checked As Boolean = False
                If RateProviderDataList(i).ProviderID = SysStatusService.GetData().RateProviderID Then
                    Checked = True
                End If
                Dim newIndex As Integer = dgRateProvider.Rows.Add({("採用"), (RateProviderDataList(i).ProviderName), (Checked), RateProviderDataList(i).ProviderID})
            Next
        End If

    End Sub

    Private Sub setForm()
        'システム営業日
        lblSysDate.Text = SysStatusService.GetData.SysDate.ToString("yyyy/MM/dd")
        'システム停止
        If SysStatusService.GetData().SysEnabled = 1 Then
            btnSysSuspend.Visible = False
            btnSysOperation.Visible = True
        Else
            btnSysOperation.Visible = False
            btnSysSuspend.Visible = True
        End If
        '放棄処理停止
        If SysStatusService.GetData().AbandEnabled = 1 Then
            btnAbandSuspend.Visible = False
            btnAbandOperation.Visible = True
        Else
            btnAbandOperation.Visible = False
            btnAbandSuspend.Visible = True
        End If
        '出金振替
        If SysStatusService.GetData().CashOutEnabled = 1 Then
            btnCashOutSuspend.Visible = False
            btnCashOutOperation.Visible = True
        Else
            btnCashOutOperation.Visible = False
            btnCashOutSuspend.Visible = True
        End If
        '入金振替
        If SysStatusService.GetData().CashInEnabled = 1 Then
            btnCashInSuspend.Visible = False
            btnCashInOperation.Visible = True
        Else
            btnCashInOperation.Visible = False
            btnCashInSuspend.Visible = True
        End If

        MakeDataGridView(RateProviderService.GetList())
    End Sub

    Private Sub dgRateProvider_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgRateProvider.CellContentClick
        '採用ボタンを押下
        If e.ColumnIndex = 0 Then
            'システムステータスの採用レートプロバイダの更新
            MsgBox.Message = "採用レートプロバイダーを変更します。"
            If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                SysStatusService.Regist("", "", "", "", dgRateProvider.Rows(e.RowIndex).Cells(3).Value)
            End If
        End If
    End Sub

    Private Sub service_DataChanged() Handles service.DataChanged
        setForm()
    End Sub

    Private Sub service_RegistSuccess() Handles service.RegistSuccess
        SysStatusService.Read()
    End Sub

    Private Sub btnSysOperation_Click(sender As System.Object, e As System.EventArgs) Handles btnSysOperation.Click
        'システムステータスの新規取引ステータスの更新
        MsgBox.Message = "新規取引の受付を停止します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("0", "", "", "", "")
        End If
    End Sub

    Private Sub btnSysSuspend_Click(sender As System.Object, e As System.EventArgs) Handles btnSysSuspend.Click
        'システムステータスの新規取引ステータスの更新
        MsgBox.Message = "新規取引の受付を開始します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("1", "", "", "", "")
        End If
    End Sub

    Private Sub btnAbandOperation_Click(sender As System.Object, e As System.EventArgs) Handles btnAbandOperation.Click
        'システムステータスの放棄処理ステータスの更新
        MsgBox.Message = "権利放棄の受付を停止します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("", "0", "", "", "")
        End If
    End Sub

    Private Sub btnAbandSuspend_Click(sender As System.Object, e As System.EventArgs) Handles btnAbandSuspend.Click
        'システムステータスの放棄処理ステータスの更新
        MsgBox.Message = "権利放棄の受付を開始します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("", "1", "", "", "")
        End If
    End Sub

    Private Sub btnCashOutOperation_Click(sender As System.Object, e As System.EventArgs) Handles btnCashOutOperation.Click
        'システムステータスの出金振替ステータスの更新
        MsgBox.Message = "出金振替の受付を停止します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("", "", "0", "", "")
        End If
    End Sub

    Private Sub btnCashOutSuspend_Click(sender As System.Object, e As System.EventArgs) Handles btnCashOutSuspend.Click
        'システムステータスの出金振替ステータスの更新
        MsgBox.Message = "出金振替の受付を開始します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("", "", "1", "", "")
        End If
    End Sub

    Private Sub btnCashInOperation_Click(sender As System.Object, e As System.EventArgs) Handles btnCashInOperation.Click
        'システムステータスの入金振替ステータスの更新
        MsgBox.Message = "入金振替の受付を停止します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("", "", "", "0", "")
        End If
    End Sub

    Private Sub btnCashInSuspend_Click(sender As System.Object, e As System.EventArgs) Handles btnCashInSuspend.Click
        'システムステータスの入金振替ステータスの更新
        MsgBox.Message = "入金振替の受付を開始します。"
        If MsgBox.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
            SysStatusService.Regist("", "", "", "1", "")
        End If
    End Sub

    Private Sub btnSystemStop_Click(sender As System.Object, e As System.EventArgs) Handles btnSystemStop.Click
        Dim dlg As New SystemStop
        dlg.ShowDialog(Me)
    End Sub

End Class