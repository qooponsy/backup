﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SysControlForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.dgRateProvider = New System.Windows.Forms.DataGridView()
        Me.ProviderID = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.ProviderName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Checked = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.ProvideID2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnSystemStop = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblSysDate = New System.Windows.Forms.Label()
        Me.btnCashInOperation = New Penguin8AdminClient.ImageButton()
        Me.btnCashInSuspend = New Penguin8AdminClient.ImageButton()
        Me.btnCashOutOperation = New Penguin8AdminClient.ImageButton()
        Me.btnCashOutSuspend = New Penguin8AdminClient.ImageButton()
        Me.btnAbandOperation = New Penguin8AdminClient.ImageButton()
        Me.btnAbandSuspend = New Penguin8AdminClient.ImageButton()
        Me.btnSysOperation = New Penguin8AdminClient.ImageButton()
        Me.btnSysSuspend = New Penguin8AdminClient.ImageButton()
        CType(Me.dgRateProvider, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCashInOperation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCashInSuspend, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCashOutOperation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCashOutSuspend, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAbandOperation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAbandSuspend, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSysOperation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSysSuspend, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "[システム制御]"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 189)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "[入出金振替制御]"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(24, 307)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 12)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "[採用レート]"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(38, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 12)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "新規取引"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(38, 145)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 12)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "権利放棄"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label6.Location = New System.Drawing.Point(38, 222)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 12)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "出金振替"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label7.Location = New System.Drawing.Point(38, 264)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 12)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "入金振替"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(119, 474)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(123, 30)
        Me.btnClose.TabIndex = 8
        Me.btnClose.Text = "閉じる"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'dgRateProvider
        '
        Me.dgRateProvider.AllowUserToAddRows = False
        Me.dgRateProvider.AllowUserToDeleteRows = False
        Me.dgRateProvider.AllowUserToResizeColumns = False
        Me.dgRateProvider.AllowUserToResizeRows = False
        Me.dgRateProvider.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.dgRateProvider.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgRateProvider.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgRateProvider.ColumnHeadersVisible = False
        Me.dgRateProvider.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ProviderID, Me.ProviderName, Me.Checked, Me.ProvideID2})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.Padding = New System.Windows.Forms.Padding(5)
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgRateProvider.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgRateProvider.Location = New System.Drawing.Point(40, 331)
        Me.dgRateProvider.MultiSelect = False
        Me.dgRateProvider.Name = "dgRateProvider"
        Me.dgRateProvider.ReadOnly = True
        Me.dgRateProvider.RowHeadersVisible = False
        Me.dgRateProvider.RowTemplate.Height = 21
        Me.dgRateProvider.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.dgRateProvider.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgRateProvider.ShowCellToolTips = False
        Me.dgRateProvider.Size = New System.Drawing.Size(336, 122)
        Me.dgRateProvider.StandardTab = True
        Me.dgRateProvider.TabIndex = 11
        '
        'ProviderID
        '
        Me.ProviderID.HeaderText = "ProviderID"
        Me.ProviderID.Name = "ProviderID"
        Me.ProviderID.ReadOnly = True
        '
        'ProviderName
        '
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ProviderName.DefaultCellStyle = DataGridViewCellStyle1
        Me.ProviderName.HeaderText = "ProviderName"
        Me.ProviderName.Name = "ProviderName"
        Me.ProviderName.ReadOnly = True
        Me.ProviderName.Width = 150
        '
        'Checked
        '
        Me.Checked.HeaderText = "Checked"
        Me.Checked.Name = "Checked"
        Me.Checked.ReadOnly = True
        Me.Checked.Width = 40
        '
        'ProvideID2
        '
        Me.ProvideID2.HeaderText = "ProviderID"
        Me.ProvideID2.Name = "ProvideID2"
        Me.ProvideID2.ReadOnly = True
        Me.ProvideID2.Visible = False
        '
        'btnSystemStop
        '
        Me.btnSystemStop.Location = New System.Drawing.Point(192, 13)
        Me.btnSystemStop.Name = "btnSystemStop"
        Me.btnSystemStop.Size = New System.Drawing.Size(136, 36)
        Me.btnSystemStop.TabIndex = 0
        Me.btnSystemStop.Text = "システム停止"
        Me.btnSystemStop.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label8.Location = New System.Drawing.Point(24, 13)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 12)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "[システム営業日]"
        '
        'lblSysDate
        '
        Me.lblSysDate.BackColor = System.Drawing.Color.White
        Me.lblSysDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSysDate.Location = New System.Drawing.Point(40, 33)
        Me.lblSysDate.Name = "lblSysDate"
        Me.lblSysDate.Size = New System.Drawing.Size(109, 20)
        Me.lblSysDate.TabIndex = 24
        Me.lblSysDate.Text = "2012/06/07"
        Me.lblSysDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCashInOperation
        '
        Me.btnCashInOperation.Image = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnCashInOperation.Location = New System.Drawing.Point(139, 253)
        Me.btnCashInOperation.Name = "btnCashInOperation"
        Me.btnCashInOperation.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnCashInOperation.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_on
        Me.btnCashInOperation.Size = New System.Drawing.Size(117, 32)
        Me.btnCashInOperation.TabIndex = 22
        Me.btnCashInOperation.TabStop = False
        Me.btnCashInOperation.Visible = False
        '
        'btnCashInSuspend
        '
        Me.btnCashInSuspend.Image = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnCashInSuspend.Location = New System.Drawing.Point(139, 253)
        Me.btnCashInSuspend.Name = "btnCashInSuspend"
        Me.btnCashInSuspend.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnCashInSuspend.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_on
        Me.btnCashInSuspend.Size = New System.Drawing.Size(117, 32)
        Me.btnCashInSuspend.TabIndex = 21
        Me.btnCashInSuspend.TabStop = False
        Me.btnCashInSuspend.Visible = False
        '
        'btnCashOutOperation
        '
        Me.btnCashOutOperation.Image = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnCashOutOperation.Location = New System.Drawing.Point(139, 211)
        Me.btnCashOutOperation.Name = "btnCashOutOperation"
        Me.btnCashOutOperation.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnCashOutOperation.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_on
        Me.btnCashOutOperation.Size = New System.Drawing.Size(117, 32)
        Me.btnCashOutOperation.TabIndex = 20
        Me.btnCashOutOperation.TabStop = False
        Me.btnCashOutOperation.Visible = False
        '
        'btnCashOutSuspend
        '
        Me.btnCashOutSuspend.Image = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnCashOutSuspend.Location = New System.Drawing.Point(139, 211)
        Me.btnCashOutSuspend.Name = "btnCashOutSuspend"
        Me.btnCashOutSuspend.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnCashOutSuspend.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_on
        Me.btnCashOutSuspend.Size = New System.Drawing.Size(117, 32)
        Me.btnCashOutSuspend.TabIndex = 19
        Me.btnCashOutSuspend.TabStop = False
        Me.btnCashOutSuspend.Visible = False
        '
        'btnAbandOperation
        '
        Me.btnAbandOperation.Image = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnAbandOperation.Location = New System.Drawing.Point(139, 134)
        Me.btnAbandOperation.Name = "btnAbandOperation"
        Me.btnAbandOperation.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnAbandOperation.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_on
        Me.btnAbandOperation.Size = New System.Drawing.Size(117, 32)
        Me.btnAbandOperation.TabIndex = 18
        Me.btnAbandOperation.TabStop = False
        Me.btnAbandOperation.Visible = False
        '
        'btnAbandSuspend
        '
        Me.btnAbandSuspend.Image = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnAbandSuspend.Location = New System.Drawing.Point(139, 134)
        Me.btnAbandSuspend.Name = "btnAbandSuspend"
        Me.btnAbandSuspend.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnAbandSuspend.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_on
        Me.btnAbandSuspend.Size = New System.Drawing.Size(117, 32)
        Me.btnAbandSuspend.TabIndex = 17
        Me.btnAbandSuspend.TabStop = False
        Me.btnAbandSuspend.Visible = False
        '
        'btnSysOperation
        '
        Me.btnSysOperation.Image = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnSysOperation.Location = New System.Drawing.Point(139, 91)
        Me.btnSysOperation.Name = "btnSysOperation"
        Me.btnSysOperation.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_off
        Me.btnSysOperation.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.operationwork_on
        Me.btnSysOperation.Size = New System.Drawing.Size(117, 32)
        Me.btnSysOperation.TabIndex = 16
        Me.btnSysOperation.TabStop = False
        Me.btnSysOperation.Visible = False
        '
        'btnSysSuspend
        '
        Me.btnSysSuspend.Image = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnSysSuspend.Location = New System.Drawing.Point(139, 91)
        Me.btnSysSuspend.Name = "btnSysSuspend"
        Me.btnSysSuspend.OffImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_off
        Me.btnSysSuspend.OnImage = Global.Penguin8AdminClient.My.Resources.Resources.stop_on
        Me.btnSysSuspend.Size = New System.Drawing.Size(117, 32)
        Me.btnSysSuspend.TabIndex = 15
        Me.btnSysSuspend.TabStop = False
        Me.btnSysSuspend.Visible = False
        '
        'SysControlForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(362, 516)
        Me.Controls.Add(Me.lblSysDate)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnSystemStop)
        Me.Controls.Add(Me.btnCashInOperation)
        Me.Controls.Add(Me.btnCashInSuspend)
        Me.Controls.Add(Me.btnCashOutOperation)
        Me.Controls.Add(Me.btnCashOutSuspend)
        Me.Controls.Add(Me.btnAbandOperation)
        Me.Controls.Add(Me.btnAbandSuspend)
        Me.Controls.Add(Me.btnSysOperation)
        Me.Controls.Add(Me.btnSysSuspend)
        Me.Controls.Add(Me.dgRateProvider)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "SysControlForm"
        Me.Text = "システム制御"
        CType(Me.dgRateProvider, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCashInOperation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCashInSuspend, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCashOutOperation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCashOutSuspend, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAbandOperation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAbandSuspend, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSysOperation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSysSuspend, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents dgRateProvider As System.Windows.Forms.DataGridView
    Friend WithEvents ProviderID As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents ProviderName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Checked As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents ProvideID2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnSysSuspend As Penguin8AdminClient.ImageButton
    Friend WithEvents btnSysOperation As Penguin8AdminClient.ImageButton
    Friend WithEvents btnAbandSuspend As Penguin8AdminClient.ImageButton
    Friend WithEvents btnAbandOperation As Penguin8AdminClient.ImageButton
    Friend WithEvents btnCashOutSuspend As Penguin8AdminClient.ImageButton
    Friend WithEvents btnCashOutOperation As Penguin8AdminClient.ImageButton
    Friend WithEvents btnCashInSuspend As Penguin8AdminClient.ImageButton
    Friend WithEvents btnCashInOperation As Penguin8AdminClient.ImageButton
    Friend WithEvents btnSystemStop As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblSysDate As System.Windows.Forms.Label
End Class
