﻿Public Class UserList

    Private WithEvents service As New UserService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As New DataTable
    Private view As New DataView

    Private Sub UserList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

		Dim admin As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
		Dim whitelabel As Boolean = UserTypeManager.IsWL(SessionService.UserType)
		' 2014/12 WhiteLabelに登録・更新権限付与
		Dim editable As Boolean = (admin Or whitelabel)

		btnRegist.Enabled = editable
        miEdit.Text = IIf(editable, "編集", "参照")
        miChangePassword.Visible = editable

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

		MainWindow.SubFormUser = True
        grid.AutoGenerateColumns = False
        LoadSettings()

        request()
    End Sub

    Private Sub UserList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormUser = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        clsUtil.LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.UserList_FormMaximized, _
            UserSettings.getInstance().DataSaved.UserList_FormSize, _
            UserSettings.getInstance().DataSaved.UserList_FormLocation)

		clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.UserList_Columns)
		' 2014/12 WhiteLabelは自社分のみに限定
		If UserTypeManager.IsAdminView(SessionService.UserType) Then
			cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.UserList_CmpCode
		Else
			cbCmpCode.SelectedValue = SessionService.CmpCode
			cbCmpCode.Enabled = False
		End If

		chkEnabled.Checked = UserSettings.getInstance().DataSaved.UserList_Enabled
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        clsUtil.SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.UserList_FormMaximized, _
            UserSettings.getInstance().DataSaved.UserList_FormSize, _
            UserSettings.getInstance().DataSaved.UserList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.UserList_Columns)
        UserSettings.getInstance().DataSaved.UserList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.UserList_Enabled = chkEnabled.Checked
    End Sub

    Private Sub setGrid(list As List(Of UserData))
        Table = New DataTable

        Table.Columns.Add("UserID", GetType(String))
        Table.Columns.Add("Enabled", GetType(String))
        Table.Columns.Add("EnabledCode", GetType(String))
        Table.Columns.Add("AccountLock", GetType(String))
        Table.Columns.Add("AccountLockCode", GetType(String))
        Table.Columns.Add("UserName", GetType(String))
        Table.Columns.Add("UserType", GetType(String))
        Table.Columns.Add("CmpName", GetType(String))
        Table.Columns.Add("CmpCode", GetType(String))
        Table.Columns.Add("LastAuthTime", GetType(DateTime))
        Table.Columns.Add("InsTime", GetType(DateTime))
        Table.Columns.Add("InsUser", GetType(String))
        Table.Columns.Add("UpdTime", GetType(DateTime))
        Table.Columns.Add("UpdUser", GetType(String))
        If Not list Is Nothing Then
            For i As Integer = 0 To list.Count - 1
                Dim row As DataRow = Table.NewRow()
                row("UserID") = list(i).UserID
                row("Enabled") = list(i).EnabledName()
                row("EnabledCode") = list(i).Enabled
                row("AccountLock") = IIf(list(i).AccountLock = AccountLockFlagManager.AccountLock.Lock, list(i).AccountLockName(), "")
                row("AccountLockCode") = list(i).AccountLock
                row("UserName") = list(i).UserName
                row("UserType") = list(i).UserTypeName
                row("CmpName") = CompanyService.GetName(list(i).CmpCode)
                row("CmpCode") = list(i).CmpCode
                row("LastAuthTime") = IIf(list(i).LastAuthTimeEnabled, list(i).LastAuthTime, DBNull.Value)
                row("InsTime") = list(i).InsTime
                row("InsUser") = list(i).InsUser
                row("UpdTime") = list(i).UpdTime
                row("UpdUser") = list(i).UpdUser

                Table.Rows.Add(row)
            Next
        End If

        view = New DataView(Table)
        grid.DataSource = view
        setGridFilter()
    End Sub

    Private Sub cbCmpCode_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cbCmpCode.SelectedIndexChanged
        setGridFilter()
    End Sub

    Private Sub chkEnabled_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkEnabled.CheckedChanged
        setGridFilter()
    End Sub

    Private Sub btnReflesh_Click(sender As System.Object, e As System.EventArgs) Handles btnReflesh.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                request()
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("UserID").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("UserID").Value
        edit(code)
    End Sub

    Private Sub miChangePassword_Click(sender As System.Object, e As System.EventArgs) Handles miChangePassword.Click
        Dim code As String = grid.SelectedRows(0).Cells("UserID").Value
        changepw(code)
    End Sub

    Private Sub request()
        service.ReadList()
        formModeStatus = FormMode.READ
        btnReflesh.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnReflesh.Text = "更新"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of UserData)) Handles service.ReadSuccess
        setGrid(list)
        requestEnd()
    End Sub

    Private Sub setGridFilter()
        Dim strFilter As String = ""
        '通貨ペア
        If cbCmpCode.SelectedValue <> "" Then
            strFilter = "CmpCode = '" & cbCmpCode.SelectedValue & "'"
        End If
        '有効フラグ
        If chkEnabled.Checked Then
            If strFilter <> "" Then
                strFilter = strFilter & " AND "
            End If
            strFilter = strFilter & "EnabledCode = '" & UserData.EnabledCode.Enabled & "'"
        End If
        view.RowFilter = strFilter
        grid.DataSource = view
        lblNoData.Visible = (grid.RowCount = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormUserForm Then
            UserForm.Close()
        End If
        UserForm.MdiParent = MainWindow
        UserForm.Code = ""
        UserForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormUserForm Then
            UserForm.Close()
        End If
        UserForm.MdiParent = MainWindow
        UserForm.Code = code
        UserForm.Show()
    End Sub

    Private Sub changepw(code As String)
        If MainWindow.SubFormUserChangePasswordForm Then
            UserChangePasswordForm.Close()
        End If
        UserChangePasswordForm.MdiParent = MainWindow
        UserChangePasswordForm.Code = code
        UserChangePasswordForm.Show()
    End Sub

End Class