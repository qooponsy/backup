﻿Public Class ProductList

    Private WithEvents service As New ProductService
    Private WithEvents serviceRateTick As RateTickService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable

    Private Start As Integer = 1

    Private Sub ProductList_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.DoubleBuffered = True

        Premium.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()
        PAndL.DefaultCellStyle.Format = clsUtil.GetMoneyFormatDisp()

        For Each cur As CurrencyData In CurrencyService.GetList()
            Dim tmpPremium As DataGridViewTextBoxColumn = Premium.Clone()
            tmpPremium.Name &= cur.CurCode
            tmpPremium.DataPropertyName &= cur.CurCode
            tmpPremium.HeaderText &= vbCrLf & cur.CurName
            tmpPremium.Visible = True
            grid.Columns.Add(tmpPremium)

            Dim tmpPAndL As DataGridViewTextBoxColumn = PAndL.Clone()
            tmpPAndL.Name &= cur.CurCode
            tmpPAndL.DataPropertyName &= cur.CurCode
            tmpPAndL.HeaderText &= vbCrLf & cur.CurName
            tmpPAndL.Visible = True
            grid.Columns.Add(tmpPAndL)
        Next

        clsUtil.SetGridDoubleBuffered(grid)

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        Dim editable As Boolean = UserTypeManager.IsAdmin(SessionService.UserType)
        btnRegist.Enabled = False
        miEdit.Text = IIf(editable, "編集", "参照")

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        '通貨ペアドロップダウンリストの作成
        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Me.cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        Me.cbExercState.DisplayMember = "Name"
        Me.cbExercState.ValueMember = "Code"
        Me.cbExercState.DataSource = ExercStatusManager.GetListWithAll()

        Me.cbOpType.DisplayMember = "Name"
        Me.cbOpType.ValueMember = "Code"
        Me.cbOpType.DataSource = OptionTypeManager.GetListWithAll()

        '初期値の設定
        dtpFromDateTime.Value = SysSettingsService.GetStartDate()
        dtpFromDateTime.Checked = False
        dtpToDateTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone)
        dtpToDateTime.Checked = False

        MainWindow.SubFormProduct = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)

        serviceRateTick = New RateTickService
    End Sub

    Private Sub ProductList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        serviceRateTick = Nothing

        SaveSettings()
        MainWindow.SubFormProduct = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_CmpCode
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_ComCode
        cbOpType.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_OpType
        cbExercState.SelectedValue = UserSettings.getInstance().DataSaved.ProductList_ExercStatus
        chkEnabled.Checked = UserSettings.getInstance().DataSaved.ProductList_Enabled
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.ProductList_FormMaximized, _
            UserSettings.getInstance().DataSaved.ProductList_FormSize, _
            UserSettings.getInstance().DataSaved.ProductList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ProductList_Columns)
        UserSettings.getInstance().DataSaved.ProductList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_OpType = cbOpType.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_ExercStatus = cbExercState.SelectedValue
        UserSettings.getInstance().DataSaved.ProductList_Enabled = chkEnabled.Checked
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("ResidualTime", GetType(String))
        Table.Columns.Add("PayoutRate", GetType(Decimal))
        Table.Columns.Add("Spread", GetType(Integer))
        Table.Columns.Add("Rate", GetType(Decimal))
        Table.Columns.Add("RateArrowCount", GetType(Integer))
        Table.Columns.Add("ProductCode", GetType(String))
        Table.Columns.Add("OpTypeCode", GetType(String))
        Table.Columns.Add("OpType", GetType(String))
        Table.Columns.Add("OptionTime", GetType(String))
        Table.Columns.Add("SysDate", GetType(DateTime))
        Table.Columns.Add("StartTime", GetType(DateTime))
        Table.Columns.Add("TradeLimitTime", GetType(DateTime))
        Table.Columns.Add("LastExercTime", GetType(DateTime))
        Table.Columns.Add("ProductEnabled", GetType(String))
        Table.Columns.Add("ExercStatusCode", GetType(String))
        Table.Columns.Add("ExercStatus", GetType(String))
        Table.Columns.Add("ProductBaseCode", GetType(String))
        Table.Columns.Add("ExercRateSeq", GetType(String))
        Table.Columns.Add("ExercRate", GetType(Decimal))
        Table.Columns.Add("Premium", GetType(Decimal))
        Table.Columns.Add("PAndL", GetType(Decimal))
        For Each cur As CurrencyData In CurrencyService.GetList()
            Table.Columns.Add("Premium" & cur.CurCode, GetType(Decimal))
            Table.Columns.Add("PAndL" & cur.CurCode, GetType(Decimal))
        Next
        grid.DataSource = Table
    End Sub

    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of ProductData))

        For Each item As ProductData In list
            Dim row As DataRow = Table.NewRow()
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName

            Select Case item.OpType
                Case OptionTypeManager.OpType.Binary
                    row("ExercTime") = item.ExercTime
                    row("TradeLimitTime") = item.TradeLimitTime
                    row("ResidualTime") = DateTimeUtil.TimeSpanText(item.ExercTime, RateTickService.ServerTime)
                Case OptionTypeManager.OpType.AnyTime
                    row("LastExercTime") = item.ExercTime
                    row("TradeLimitTime") = DBNull.Value
                    row("ResidualTime") = DBNull.Value
            End Select


            row("PayoutRate") = item.PayoutRate
            row("Spread") = item.Spread
            If item.ExercStatus = "0" And item.ProductEnabled = "1" Then
                row("Rate") = RateTickService.GetLastRate(item.ComCode).Rate
                row("RateArrowCount") = RateTickService.GetLastRate(item.ComCode).RateArrowCount
            End If
            row("ProductCode") = item.ProductCode
            row("OpTypeCode") = item.OpType
            row("OpType") = OptionTypeManager.GetOptionTypeName(item.OpType)
            row("OptionTime") = DateTimeUtil.TimeConvView(item.OptionTime)
            row("SysDate") = item.SysDate
            row("StartTime") = item.StartTime
            row("ProductEnabled") = item.ProductEnabledName
            row("ProductBaseCode") = item.ProductBaseCode
            row("ExercStatusCode") = item.ExercStatus
            row("ExercStatus") = item.ExercStatusName
            row("ExercRateSeq") = item.ExercRateSeq
            row("ExercRate") = IIf(item.ExercRateEnabled, item.ExercRate, DBNull.Value)

            For Each cur As CurrencyData In CurrencyService.GetList()
                row("Premium" & cur.CurCode) = item.PAndL(cur.CurCode).Premium
                row("PAndL" & cur.CurCode) = item.PAndL(cur.CurCode).PAndL
            Next

            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSarchAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    ''' <summary>
    '''  [新規]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        regist()
    End Sub

    Private Sub grid_RowContextMenuStripNeeded(sender As Object, e As System.Windows.Forms.DataGridViewRowContextMenuStripNeededEventArgs) Handles grid.RowContextMenuStripNeeded
        e.ContextMenuStrip = cmGrid
    End Sub

    Private Sub grid_CellMouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles grid.CellMouseDown
        If e.RowIndex >= 0 Then
            If e.Button = Windows.Forms.MouseButtons.Right Then
                grid.ClearSelection()
                grid.Rows(e.RowIndex).Selected = True
            End If
        End If
    End Sub

    Private Sub grid_CellDoubleClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grid.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub
        Dim code As String = grid.SelectedRows(0).Cells("ProductCode").Value
        edit(code)
    End Sub

    Private Sub miEdit_Click(sender As System.Object, e As System.EventArgs) Handles miEdit.Click
        Dim code As String = grid.SelectedRows(0).Cells("ProductCode").Value
        edit(code)
    End Sub

    Private Sub request()
        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim OpType As String = Me.cbOpType.SelectedValue
        Dim Exerc As String = Me.cbExercState.SelectedValue
        Dim EnabledFlg As String = IIf(Me.chkEnabled.Checked, "1", "")
        Dim NowProductFlg As String = IIf(Me.chkNowProduct.Checked, "1", "")
        Dim SysDate As String = If(chkNowProduct.Checked, "", dtpSysDate.Value.ToString("yyyyMMdd"))
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim SortKey As String = ""
        If grid.SortedColumn IsNot Nothing Then
            SortKey = convSortKeyName(grid.SortedColumn.Name)
            If SortKey <> "" Then
                If grid.SortedColumn.Name = "ResidualTime" Then
                    If grid.SortOrder <> SortOrder.Descending Then
                        SortKey &= " DESC"
                    End If
                Else
                    If grid.SortOrder = SortOrder.Descending Then
                        SortKey &= " DESC"
                    End If
                End If
            End If
        End If

        service.ReadList(CmpCode, ComCode, OpType, Exerc, EnabledFlg, NowProductFlg, SysDate, FromDateTime, ToDateTime, "", Start, SortKey)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of ProductData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

    Private Sub regist()
        If MainWindow.SubFormProductForm Then
            ProductForm.Close()
        End If
        ProductForm.MdiParent = MainWindow
        ProductForm.Code = ""
        ProductForm.Show()
    End Sub

    Private Sub edit(code As String)
        If MainWindow.SubFormProductForm Then
            ProductForm.Close()
        End If
        ProductForm.MdiParent = MainWindow
        ProductForm.Code = code
        ProductForm.Show()
    End Sub

    Private Sub serviceRateTick_NewTick() Handles serviceRateTick.NewTick
        For Each row As DataRow In Table.Rows

            Dim ExercStatusCode As String = ""
            Dim ProductEnabled As String = ""

            ExercStatusCode = row("ExercStatusCode")
            ProductEnabled = row("ProductEnabled")

            Select Case row("OpTypeCode")
                Case OptionTypeManager.OpType.Binary

                    'High/Lowの場合
                    ExercStatusCode = row("ExercStatusCode")
                    ProductEnabled = row("ProductEnabled")
                    If ExercStatusCode = "0" And ProductEnabled = "有効" Then
                        row("ResidualTime") = DateTimeUtil.TimeSpanText(row("ExercTime"), RateTickService.ServerTime)
                        row("Rate") = RateTickService.GetLastRate(row("ComCode")).Rate
                        row("RateArrowCount") = RateTickService.GetLastRate(row("ComCode")).RateArrowCount
                    End If

                Case OptionTypeManager.OpType.AnyTime

                    'AnyTimeの場合
                    ProductEnabled = row("ProductEnabled")
                    If ExercStatusCode = "0" And ProductEnabled = "有効" Then
                        row("Rate") = RateTickService.GetLastRate(row("ComCode")).Rate
                        row("RateArrowCount") = RateTickService.GetLastRate(row("ComCode")).RateArrowCount
                    End If

            End Select

        Next
    End Sub

    Private Function convSortKeyName(columnName As String) As String
        Dim ret As String = ""
        Select Case columnName
            Case "ComName"
                ret = "COMCODE"
            Case "ExercTime"
                ret = "EXERCTIME"
            Case "ResidualTime"
                ret = "EXERCTIME"
            Case "PayoutRate"
                ret = "PAYOUTRATE"
            Case "ProductCode"
                ret = "PRODUCTCODE"
            Case "OpType"
                ret = "OPTYPE"
            Case "StartTime"
                ret = "STARTTIME"
            Case "TradeLimitTime"
                ret = "TRADELIMITTIME"
            Case "ProductEnabled"
                ret = "ENABLED"
            Case "ExercStatus"
                ret = "EXERCSTATUS"
            Case "ProductBaseCode"
                ret = "PRODUCTBASECODE"
            Case "ExercRateSeq"
                ret = "EXERCRATESEQ"
            Case "ExercRate"
                ret = "EXERCRATE"
        End Select
        Return ret
    End Function

    Private Sub grid_CellFormatting(sender As Object, e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles grid.CellFormatting
        If e.RowIndex >= 0 Then
            If grid.Columns(e.ColumnIndex).DataPropertyName = "Rate" Then
                Dim ComCode As String = grid.Rows(e.RowIndex).Cells("ComCode").Value
                Dim Com As CurrencyPairData = CurrencyPairService.GetData(ComCode)
                e.CellStyle.Format = clsUtil.GetRateDPFormat(Com.DecimalPlaces)
            End If
        End If
    End Sub

    Private Sub grid_CellPainting(sender As Object, e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles grid.CellPainting
        If e.RowIndex >= 0 Then
            If (e.PaintParts And DataGridViewPaintParts.ContentForeground) <> 0 Then
                Dim ColName As String = grid.Columns(e.ColumnIndex).Name
                If ColName = "Rate" Then

                    Dim ExercStatusCode As String = ""
                    Dim ProductEnabled As String = ""
                    Dim viewFlg As Boolean = False

                    ExercStatusCode = grid.Rows(e.RowIndex).Cells("ExercStatusCode").Value
                    ProductEnabled = grid.Rows(e.RowIndex).Cells("ProductEnabled").Value

                    If ExercStatusCode = "0" And ProductEnabled = "有効" Then
                        '有効銘柄はレートを更新
                        Dim ArrowCount As Integer = grid.Rows(e.RowIndex).Cells("RateArrowCount").Value
                        If ArrowCount <> 0 Then
                            e.Paint(e.CellBounds, e.PaintParts)
                            Dim ArrowChar As String
                            Dim ArrowColor As Color
                            If ArrowCount > 0 Then
                                ArrowChar = "▲"
                                ArrowColor = Color.Red
                            Else
                                ArrowChar = "▼"
                                ArrowColor = Color.Blue
                            End If
                            e.Paint(e.CellBounds, e.PaintParts)
                            TextRenderer.DrawText(e.Graphics, ArrowChar, e.CellStyle.Font, e.CellBounds, ArrowColor, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                            e.Handled = True
                        End If
                    End If

                ElseIf ColName = "Premium" Or ColName = "PAndL" Then
                    If Not IsDBNull(e.Value) AndAlso e.Value < 0 Then
                        e.Paint(e.CellBounds, e.PaintParts And Not DataGridViewPaintParts.ContentForeground)
                        TextRenderer.DrawText(e.Graphics, e.FormattedValue, e.CellStyle.Font, e.CellBounds, Color.Red, TextFormatFlags.Right Or TextFormatFlags.VerticalCenter)
                        e.Handled = True
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btnCSV_Click(sender As System.Object, e As System.EventArgs) Handles btnCSV.Click
        Dim strFileName As String
        Dim columnList As List(Of List(Of String))

        Me.sfdCsvFile.FileName = "dlproduct"

        If Me.sfdCsvFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.Update()

            strFileName = sfdCsvFile.FileName

            Dim CursorOrg As Cursor = Cursor.Current
            Try
                Cursor.Current = Cursors.WaitCursor
                columnList = [clsUtil].GetCsvColumnList(grid)

                '不要な項目を取り除く
                For Each col As List(Of String) In columnList
                    '矢印を取り除く
                    If col(0) = "RateArrowCount" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next
                For Each col As List(Of String) In columnList
                    '残存期間を取り除く
                    If col(0) = "ResidualTime" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next
                For Each col As List(Of String) In columnList
                    'レートを取り除く
                    If col(0) = "Rate" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next
                For Each col As List(Of String) In columnList
                    '取引金額を取り除く
                    If col(0) = "Premium" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next
                For Each col As List(Of String) In columnList
                    '損益を取り除く
                    If col(0) = "PAndL" Then
                        columnList.Remove(col)
                        Exit For
                    End If
                Next

                'CSV作成
                [clsUtil].SaveToCsv(grid, columnList, 0, -1, strFileName)
                MessageBox.Show(Me, "CSVファイルに保存しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Finally
                sfdCsvFile.FileName = Nothing
                Cursor.Current = CursorOrg
            End Try
        End If
    End Sub

    Private Sub chkNowProduct_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkNowProduct.CheckedChanged
        If dtpSysDate.Enabled = True Then
            dtpSysDate.Enabled = False
        Else
            dtpSysDate.Enabled = True
        End If
    End Sub
End Class