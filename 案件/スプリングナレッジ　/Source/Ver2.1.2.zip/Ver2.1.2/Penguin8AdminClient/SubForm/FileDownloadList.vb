﻿Imports System.Threading
Imports System.Threading.Tasks

Public Class FileDownloadList

    Private WithEvents service As New FileDownloadService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private View As DataView
    Private SavePath As String
    Private pbForm As DownloadProgressStatus

    Private Sub FileDownloadList_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        cbCmpCode.DisplayMember = "CmpName"
        cbCmpCode.ValueMember = "CmpCode"
        cbCmpCode.DataSource = CompanyService.GetListWithAll()

        cbFileType.DisplayMember = "FileTypeName"
        cbFileType.ValueMember = "FileType"
        cbFileType.DataSource = FileTypeService.GetList()

        '初期値の設定
        Dim SysDate As DateTime = SysStatusService.GetData().SysDate
        Dim SysDatePrev As DateTime = clsUtil.GetPrevWorkDay(SysDate)
        dtpFromDateTime.Value = New DateTime(SysDatePrev.Year, SysDatePrev.Month, SysDatePrev.Day)
        dtpToDateTime.Value = New DateTime(SysDate.Year, SysDate.Month, SysDate.Day)
        dtpToDateTime.Checked = False
        cbFileType.SelectedIndex = 0

        MainWindow.SubFormFileDownloadList = True
        LoadSettings()

        If UserTypeManager.IsAdminView(SessionService.UserType) Then
        Else
            cbCmpCode.SelectedValue = SessionService.CmpCode
            cbCmpCode.Enabled = False
        End If

        initGrid()
        formModeStatus = FormMode.NORMAL

    End Sub

    Private Sub FileDownloadList_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormFileDownloadList = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me, _
            UserSettings.getInstance().DataSaved.FileDownloadList_FormMaximized, _
            UserSettings.getInstance().DataSaved.FileDownloadList_FormSize, _
            UserSettings.getInstance().DataSaved.FileDownloadList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.FileDownloadList_Columns)
        cbCmpCode.SelectedValue = UserSettings.getInstance().DataSaved.FileDownloadList_CmpCode
        cbFileType.SelectedIndex = UserSettings.getInstance().DataSaved.FileDownloadList_FileType

    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me, _
            UserSettings.getInstance().DataSaved.FileDownloadList_FormMaximized, _
            UserSettings.getInstance().DataSaved.FileDownloadList_FormSize, _
            UserSettings.getInstance().DataSaved.FileDownloadList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.FileDownloadList_Columns)
        UserSettings.getInstance().DataSaved.FileDownloadList_CmpCode = cbCmpCode.SelectedValue
        UserSettings.getInstance().DataSaved.FileDownloadList_FileType = cbFileType.SelectedIndex
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("FileType", GetType(String))
        Table.Columns.Add("SysDateView", GetType(DateTime))
        Table.Columns.Add("SysDate", GetType(String))
        Table.Columns.Add("CmpName", GetType(String))
        Table.Columns.Add("CmpCode", GetType(String))
        Table.Columns.Add("FileName", GetType(String))
        Table.Columns.Add("FileSize", GetType(Integer))

        View = New DataView(Table)
        View.ApplyDefaultSort = False
        grid.DataSource = View
        grid.Columns("SysDate").HeaderCell.SortGlyphDirection = SortOrder.Descending
        View.Sort = "SysDate desc"
    End Sub


    ''' <summary>
    ''' DataGridViewの内容を作成
    ''' </summary>
    ''' <param name="list"></param>
    ''' <remarks></remarks>
    Private Sub setGrid(list As List(Of FileDownloadData))

        For Each item As FileDownloadData In list
            Dim row As DataRow = Table.NewRow()
            Dim sysDateView As Date
            DateTimeUtil.ConvToDate(item.SysDate, DateTimeUtil.ComplementMode.fromTime, sysDateView)

            row("FileType") = item.FileType
            row("SysDateView") = sysDateView
            row("SysDate") = item.SysDate
            row("CmpName") = CompanyService.GetName(item.CmpCode)
            row("CmpCode") = item.CmpCode
            row("FileName") = item.FileName
            row("FileSize") = item.FileSize

            Table.Rows.Add(row)
        Next
    End Sub

    ''' <summary>
    ''' [検索]ボタン押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click

        Select Case formModeStatus
            Case FormMode.NORMAL
                'Me.Start = 1
                request()
            Case FormMode.READ
                service.CancelRead()
        End Select

    End Sub

    ''' <summary>
    ''' [ダウンロード]ボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnBulkDownload_Click(sender As System.Object, e As System.EventArgs) Handles btnBulkDownload.Click

        Dim DlTotalCount As Integer = 0

        For i As Integer = 0 To grid.RowCount - 1
            If grid("DownloadFlg", i).Value = True Then
                DlTotalCount += 1
            End If
        Next

        If DlTotalCount > 0 Then

            SavePath = ""

            Dim fbd As New FolderBrowserDialog
            fbd.Description = "保存先フォルダを指定してください。"

            If fbd.ShowDialog(Me) = DialogResult.OK Then
                ' 保存先が選択されたらダウンロード処理

                SavePath = fbd.SelectedPath

                pbForm = New DownloadProgressStatus
                pbForm.Init(DlTotalCount)
                pbForm.Service = service
                pbForm.MdiParent = Me.ParentForm
                pbForm.ParentSubForm = Me
                pbForm.Show()
                Me.Enabled = False

                downloadRequest()
            End If
        Else
            MessageBox.Show("ダウンロードするファイルをチェックしてください", _
                            "エラー", _
                            MessageBoxButtons.OK, _
                            MessageBoxIcon.Error)
        End If
    End Sub

    ''' <summary>
    ''' [全選択]ボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSelectAll_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectAll.Click

        For i As Integer = 0 To grid.RowCount - 1
            grid("DownloadFlg", i).Value = True
        Next

    End Sub

    ''' <summary>
    ''' [全解除]ボタン押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSelectClear_Click(sender As System.Object, e As System.EventArgs) Handles btnSelectClear.Click

        For i As Integer = 0 To grid.RowCount - 1
            grid("DownloadFlg", i).Value = False
        Next

    End Sub

    Private Sub request()

        Dim CmpCode As String = Me.cbCmpCode.SelectedValue
        Dim FileType As String = Me.cbFileType.SelectedValue
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")

        service.ReadList(CmpCode, FileType, FromDateTime, ToDateTime)

        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    Private Sub downloadRequest()
        Dim downloadExist As Boolean = False
        If pbForm.Cancel Then
            MessageBox.Show("ファイルのダウンロードを中断しました。", _
                            "エラー", _
                            MessageBoxButtons.OK, _
                            MessageBoxIcon.Error)
        Else
            For i As Integer = 0 To grid.RowCount - 1

                If grid("DownloadFlg", i).Value = True Then

                    Dim FileType As String = grid("FileType", i).Value
                    Dim SysDate As String = grid("SysDate", i).Value
                    Dim CmpCode As String = grid("CmpCode", i).Value
                    Dim FileName As String = grid("FileName", i).Value

                    service.FileDownload(FileType, SysDate, CmpCode, FileName, SavePath)
                    downloadExist = True
                    Exit For
                End If
            Next
        End If
        If Not downloadExist Then
            Me.Enabled = True
            pbForm.EndDownload()
            pbForm.Service = Nothing
            pbForm = Nothing
        End If
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of FileDownloadData)) Handles service.ReadSuccess
        Table.Rows.Clear()
        setGrid(list)
        requestEnd()
        lblNoData.Visible = (list.Count = 0)
    End Sub

    Private Sub service_DownloadCancel() Handles service.DownloadCancel
        downloadRequest()
    End Sub

    Private Sub service_DownloadError(ErrorMessage As String) Handles service.DownloadError
        Me.Enabled = True
        pbForm.EndDownload()
        pbForm.Service = Nothing
        pbForm.ParentSubForm = Nothing
        pbForm = Nothing
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Private Sub service_DownloadSuccess() Handles service.DownloadSuccess

        ' ダウンロード成功ファイルのチェックを外す
        For i As Integer = 0 To grid.RowCount - 1
            If grid("DownloadFlg", i).Value = True Then
                grid("DownloadFlg", i).Value = False
                Exit For
            End If
        Next

        pbForm.Progres()
        downloadRequest()
    End Sub

End Class