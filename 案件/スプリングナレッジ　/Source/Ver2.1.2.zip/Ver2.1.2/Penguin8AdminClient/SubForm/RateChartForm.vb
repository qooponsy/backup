﻿Imports Penguin8AdminClient

Public Class RateChartForm
    Public Property Code As String

    Private WithEvents service As New RateChartHistService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub RateChartForm_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbChartType.DisplayMember = "ChartTypeName"
        cbChartType.ValueMember = "ChartType"
        cbChartType.DataSource = ChartTypeService.GetList()

        MainWindow.SubFormRateChartForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        Else
            setFormMode(FormMode.READ)
            lblRateChartCode.Text = Code
            initEdit()
        End If
    End Sub

    Private Sub RateChartForm_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormRateHistForm = False
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "レートチャート登録"
        Else
            If UserTypeManager.IsEdit(SessionService.UserType) Then
                Me.Text = "レートチャート編集"
            Else
                Me.Text = "レートチャート参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbComCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpCloseTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpChartTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbChartTimeMilliseconds.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbOpenRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbHighRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbLowRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbCloseRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbChartType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)

        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        cbComCode.SelectedValue = ""
        dtpCloseTime.Value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        tbCloseTimeMilliseconds.Text = ""
        dtpChartTime.Value = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        tbChartTimeMilliseconds.Text = ""
        tbOpenRate.Text = ""
        tbHighRate.Text = ""
        tbLowRate.Text = ""
        tbCloseRate.Text = ""
        cbEnabled.SelectedValue = ""
        cbChartType.SelectedValue = ""
        lblRateCode.Text = ""
        lblRateChartCode.Text = ""
    End Sub

    Private Sub initEdit()
        cbComCode.SelectedValue = ""
        dtpCloseTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        dtpChartTime.Value = New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, 0)
        tbCloseTimeMilliseconds.Text = ""
        tbChartTimeMilliseconds.Text = ""
        tbOpenRate.Text = ""
        tbHighRate.Text = ""
        tbLowRate.Text = ""
        tbCloseRate.Text = ""
        cbEnabled.SelectedValue = ""
        cbChartType.SelectedValue = ""
        lblRateCode.Text = ""

        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of RateChartHistData), ExistNextFlag As Boolean) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "レートチャートデータの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).RateChartSeq <> Code Then
            MessageBox.Show(Me, "レートチャートデータの情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If UserTypeManager.IsEdit(SessionService.UserType) Then
                setFormMode(FormMode.EDIT)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As RateChartHistData)
        Me.lblRateChartCode.Text = data.RateChartSeq
        Me.cbEnabled.SelectedValue = data.gEnabled
        Me.cbComCode.SelectedValue = data.ComCode
        Me.cbChartType.SelectedValue = data.ChartType
        Me.dtpChartTime.Value = data.RateChartTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbChartTimeMilliseconds.Text = data.RateChartTime.ToString("fff")
        Me.tbOpenRate.Text = data.OpenRate.ToString("######0.########")
        Me.tbHighRate.Text = data.HighRate.ToString("######0.########")
        Me.tbLowRate.Text = data.LowRate.ToString("######0.########")
        Me.tbCloseRate.Text = data.CloseRate.ToString("######0.########")
        Me.lblRateCode.Text = data.RateSeq
        Me.dtpCloseTime.Value = data.CloseTime.ToString("yyyy/MM/dd HH:mm:ss")
        Me.tbCloseTimeMilliseconds.Text = data.CloseTime.ToString("fff")

    End Sub

    Private Function getDataFromControl() As RateChartHistData
        Dim ret As New RateChartHistData

        ret.RateChartSeq = Me.lblRateChartCode.Text
        ret.RateSeq = Me.lblRateCode.Text
        ret.ComCode = Me.cbComCode.SelectedValue
        ret.gEnabled = Me.cbEnabled.SelectedValue
        ret.ChartType = Me.cbChartType.SelectedValue
        ret.RateChartTime = dtpChartTime.Value
        If tbChartTimeMilliseconds.Text <> "" Then
            ret.RateChartTime = ret.RateChartTime.AddMilliseconds(Integer.Parse(tbChartTimeMilliseconds.Text))
        End If
        ret.CloseTime = dtpCloseTime.Value
        If tbCloseTimeMilliseconds.Text <> "" Then
            ret.CloseTime = ret.CloseTime.AddMilliseconds(Integer.Parse(tbCloseTimeMilliseconds.Text))
        End If
        ret.OpenRate = Decimal.Parse(Me.tbOpenRate.Text)
        ret.HighRate = Decimal.Parse(Me.tbHighRate.Text)
        ret.LowRate = Decimal.Parse(Me.tbLowRate.Text)
        ret.CloseRate = Decimal.Parse(Me.tbCloseRate.Text)

        Return ret
    End Function

    Private Function checkInput() As Boolean
        If cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If cbChartType.SelectedValue = "" Then
            MessageBox.Show(Me, "チャート種別を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbChartTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "チャート日時には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExMS.IsMatch(tbCloseTimeMilliseconds.Text) Then
            MessageBox.Show(Me, "レート日時には適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbOpenRate.Text = "" Then
            MessageBox.Show(Me, "Openには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbHighRate.Text = "" Then
            MessageBox.Show(Me, "Highには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbLowRate.Text = "" Then
            MessageBox.Show(Me, "Lowには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If tbCloseRate.Text = "" Then
            MessageBox.Show(Me, "Closeには適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As RateChartHistData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As RateChartHistData = getDataFromControl()

        service.Update(data)
    End Sub

End Class