﻿Public Class ExercRateHistList

    Private WithEvents service As New ExercRateHistService

    Private Enum FormMode
        INIT = 0
        READ = 1
        NORMAL = 2
    End Enum

    Private formModeStatus As FormMode = FormMode.INIT

    Private Table As DataTable
    Private Start As Integer = 1

    Private Sub ExercRateHistList_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        lblNoData.Parent = grid
        lblNoData.BackColor = Color.Transparent
        lblNoData.Dock = DockStyle.Fill
        lblNoData.Visible = False

        '通貨ペアドロップダウンリストの作成
        Me.cbComCode.DisplayMember = "ComName"
        Me.cbComCode.ValueMember = "ComCode"
        Me.cbComCode.DataSource = CurrencyPairService.GetListWithAll()

        'オプション種別ドロップダウンリストの作成
        cbOpType.DisplayMember = "Name"
        cbOpType.ValueMember = "Code"
        cbOpType.DataSource = OptionTypeManager.GetList()

        '初期値の設定
        dtpFromDateTime.Value = SysSettingsService.GetStartDate()
        dtpToDateTime.Value = DateTime.UtcNow.AddMinutes(SessionService.TimeZone)
        dtpToDateTime.Checked = False

        MainWindow.SubFormExercRateHist = True
        LoadSettings()

        initGrid()
        formModeStatus = FormMode.NORMAL
        setWindowLayout(False)
    End Sub

    Private Sub ExercRateHistList_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        SaveSettings()
        MainWindow.SubFormExercRateHist = False
    End Sub

    ''' <summary>
    ''' フォーム設定の読込
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub LoadSettings()
        [clsUtil].LoadSubFormSettings(Me,
            UserSettings.getInstance().DataSaved.ExercRateHistList_FormMaximized,
            UserSettings.getInstance().DataSaved.ExercRateHistList_FormSize,
            UserSettings.getInstance().DataSaved.ExercRateHistList_FormLocation)

        clsUtil.SetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ExercRateHistList_Columns)
        cbComCode.SelectedValue = UserSettings.getInstance().DataSaved.ExercRateHistList_ComCode
        cbOpType.SelectedValue = UserSettings.getInstance().DataSaved.ExercRateHistList_OpType
        tbCustCode.Text = UserSettings.getInstance().DataSaved.ExercRateHistList_CustCode
    End Sub

    ''' <summary>
    ''' フォーム設定の保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSettings()
        [clsUtil].SaveFormSettings(Me,
            UserSettings.getInstance().DataSaved.ExercRateHistList_FormMaximized,
            UserSettings.getInstance().DataSaved.ExercRateHistList_FormSize,
            UserSettings.getInstance().DataSaved.ExercRateHistList_FormLocation)

        clsUtil.GetDataGridColumnsWidth(grid, UserSettings.getInstance().DataSaved.ExercRateHistList_Columns)
        UserSettings.getInstance().DataSaved.ExercRateHistList_ComCode = cbComCode.SelectedValue
        UserSettings.getInstance().DataSaved.ExercRateHistList_OpType = cbOpType.SelectedValue
        UserSettings.getInstance().DataSaved.ExercRateHistList_CustCode = tbCustCode.Text
    End Sub

    ''' <summary>
    ''' さらに読み込む機能が有効かの切り替え
    ''' </summary>
    ''' <param name="existNextFlag">True：さらに読み込む機能が有効な画面、False：さらに読み込む機能が無効な画面</param>
    ''' <remarks></remarks>
    Private Sub setWindowLayout(ByVal existNextFlag As Boolean)
        pnlSearchAdd.Visible = existNextFlag
    End Sub

    Private Sub initGrid()
        grid.AutoGenerateColumns = False

        Table = New DataTable
        Table.Columns.Add("RateSeq", GetType(String))
        Table.Columns.Add("RateTime", GetType(DateTime))
        Table.Columns.Add("RateTimeSource", GetType(DateTime))
        Table.Columns.Add("ComCode", GetType(String))
        Table.Columns.Add("ComName", GetType(String))
        Table.Columns.Add("Rate", GetType(Decimal))
        Table.Columns.Add("ExercTime", GetType(DateTime))
        Table.Columns.Add("Enabled", GetType(String))
        Table.Columns.Add("ViewSeq", GetType(String))
        Table.Columns.Add("CustCode", GetType(String))
        grid.DataSource = Table
    End Sub

    Private Sub setGrid(list As List(Of RateHistData))
        For Each item As RateHistData In list
            Dim row As DataRow = Table.NewRow()
            row("RateSeq") = item.RateSeq
            row("RateTime") = item.RateTime
            row("RateTimeSource") = item.RateTimeSource
            row("ComCode") = item.ComCode
            row("ComName") = CurrencyPairService.GetData(item.ComCode).ComName
            row("Rate") = item.Rate
            row("ExercTime") = IIf(item.ExercTimeEnabled, item.ExercTime, DBNull.Value)
            row("Enabled") = item.EnabledName()
            row("ViewSeq") = item.ViewSeq
            row("CustCode") = item.CustCode
            Table.Rows.Add(row)
        Next
    End Sub

    Private Sub cbOpType_SelectedIndexChanged(sender As Object, e As EventArgs)
        Select Case cbOpType.SelectedValue
            Case OptionTypeManager.OpType.Binary
                tbCustCode.ReadOnly = True
            Case OptionTypeManager.OpType.AnyTime
                tbCustCode.ReadOnly = False
        End Select
    End Sub

    ''' <summary>
    '''  [検索]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Select Case formModeStatus
            Case FormMode.NORMAL
                Me.Start = 1
                request()
                setWindowLayout(False)
            Case FormMode.READ
                service.CancelRead()
        End Select
    End Sub

    ''' <summary>
    '''  [さらに読み込む]ボタン - 押下処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSearchAdd_Click(sender As Object, e As EventArgs) Handles btnSearchAdd.Click
        Me.Start = Table.Rows.Count + 1
        request()
    End Sub

    Private Sub request()
        Dim ComCode As String = Me.cbComCode.SelectedValue
        Dim OpType As String = Me.cbOpType.SelectedValue
        Dim CustCode As String = Me.tbCustCode.Text
        Dim FromDateTime As String = If(dtpFromDateTime.Checked, dtpFromDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim ToDateTime As String = If(dtpToDateTime.Checked, dtpToDateTime.Value.AddMinutes(-SessionService.TimeZone).ToString("yyyyMMddHHmm"), "")
        Dim SortKey As String = ""

        service.ReadList(ComCode, OpType, CustCode, FromDateTime, ToDateTime, "", Start, SortKey)
        formModeStatus = FormMode.READ
        btnSearch.Text = "キャンセル"
    End Sub

    Private Sub requestEnd()
        formModeStatus = FormMode.NORMAL
        btnSearch.Text = "検索"
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        requestEnd()
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        requestEnd()
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of RateHistData), existNextFlag As Boolean) Handles service.ReadSuccess
        If Start = 1 Then
            Table.Rows.Clear()
        End If
        setGrid(list)
        requestEnd()
        setWindowLayout(existNextFlag)
        lblNoData.Visible = (Start = 1 AndAlso list.Count = 0)
    End Sub

End Class