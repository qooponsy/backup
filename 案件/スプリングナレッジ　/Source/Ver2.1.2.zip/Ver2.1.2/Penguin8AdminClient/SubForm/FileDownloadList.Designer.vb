﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FileDownloadList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnSelectClear = New System.Windows.Forms.Button()
        Me.btnSelectAll = New System.Windows.Forms.Button()
        Me.btnBulkDownload = New System.Windows.Forms.Button()
        Me.cbFileType = New System.Windows.Forms.ComboBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.FileType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DownloadFlg = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.SysDateView = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SysDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileSize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnSelectClear)
        Me.Panel1.Controls.Add(Me.btnSelectAll)
        Me.Panel1.Controls.Add(Me.btnBulkDownload)
        Me.Panel1.Controls.Add(Me.cbFileType)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(595, 104)
        Me.Panel1.TabIndex = 21
        '
        'btnSelectClear
        '
        Me.btnSelectClear.Location = New System.Drawing.Point(93, 75)
        Me.btnSelectClear.Name = "btnSelectClear"
        Me.btnSelectClear.Size = New System.Drawing.Size(75, 23)
        Me.btnSelectClear.TabIndex = 15
        Me.btnSelectClear.Text = "全解除"
        Me.btnSelectClear.UseVisualStyleBackColor = True
        '
        'btnSelectAll
        '
        Me.btnSelectAll.Location = New System.Drawing.Point(12, 75)
        Me.btnSelectAll.Name = "btnSelectAll"
        Me.btnSelectAll.Size = New System.Drawing.Size(75, 23)
        Me.btnSelectAll.TabIndex = 14
        Me.btnSelectAll.Text = "全選択"
        Me.btnSelectAll.UseVisualStyleBackColor = True
        '
        'btnBulkDownload
        '
        Me.btnBulkDownload.Location = New System.Drawing.Point(278, 69)
        Me.btnBulkDownload.Name = "btnBulkDownload"
        Me.btnBulkDownload.Size = New System.Drawing.Size(88, 29)
        Me.btnBulkDownload.TabIndex = 12
        Me.btnBulkDownload.Text = "ダウンロード"
        Me.btnBulkDownload.UseVisualStyleBackColor = True
        '
        'cbFileType
        '
        Me.cbFileType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbFileType.FormattingEnabled = True
        Me.cbFileType.Items.AddRange(New Object() {"", "取引履歴"})
        Me.cbFileType.Location = New System.Drawing.Point(139, 12)
        Me.cbFileType.Name = "cbFileType"
        Me.cbFileType.Size = New System.Drawing.Size(133, 20)
        Me.cbFileType.TabIndex = 13
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 12)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 8
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(278, 12)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 12
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(158, 38)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(114, 19)
        Me.dtpToDateTime.TabIndex = 11
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 38)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(117, 19)
        Me.dtpFromDateTime.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(135, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "～"
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(117, 224)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(225, 63)
        Me.lblNoData.TabIndex = 23
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FileType, Me.DownloadFlg, Me.SysDateView, Me.SysDate, Me.CmpName, Me.CmpCode, Me.FileName, Me.FileSize})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 104)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.Size = New System.Drawing.Size(595, 359)
        Me.grid.TabIndex = 22
        '
        'FileType
        '
        Me.FileType.DataPropertyName = "FileType"
        Me.FileType.HeaderText = "ファイルタイプ"
        Me.FileType.Name = "FileType"
        Me.FileType.Visible = False
        '
        'DownloadFlg
        '
        Me.DownloadFlg.HeaderText = ""
        Me.DownloadFlg.Name = "DownloadFlg"
        Me.DownloadFlg.Width = 25
        '
        'SysDateView
        '
        Me.SysDateView.DataPropertyName = "SysDateView"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.Format = "d"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.SysDateView.DefaultCellStyle = DataGridViewCellStyle1
        Me.SysDateView.HeaderText = "システム日付"
        Me.SysDateView.Name = "SysDateView"
        Me.SysDateView.ReadOnly = True
        '
        'SysDate
        '
        Me.SysDate.DataPropertyName = "SysDate"
        Me.SysDate.HeaderText = "SysDate"
        Me.SysDate.Name = "SysDate"
        Me.SysDate.Visible = False
        '
        'CmpName
        '
        Me.CmpName.DataPropertyName = "CmpName"
        Me.CmpName.HeaderText = "会社"
        Me.CmpName.Name = "CmpName"
        Me.CmpName.ReadOnly = True
        '
        'CmpCode
        '
        Me.CmpCode.DataPropertyName = "CmpCode"
        Me.CmpCode.HeaderText = "会社コード"
        Me.CmpCode.Name = "CmpCode"
        Me.CmpCode.Visible = False
        '
        'FileName
        '
        Me.FileName.DataPropertyName = "FileName"
        Me.FileName.HeaderText = "ファイル名"
        Me.FileName.Name = "FileName"
        Me.FileName.ReadOnly = True
        Me.FileName.Width = 250
        '
        'FileSize
        '
        Me.FileSize.DataPropertyName = "FileSize"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.Format = "N0"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.FileSize.DefaultCellStyle = DataGridViewCellStyle2
        Me.FileSize.HeaderText = "サイズ"
        Me.FileSize.Name = "FileSize"
        Me.FileSize.ReadOnly = True
        '
        'FileDownloadList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(595, 463)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.lblNoData)
        Me.Name = "FileDownloadList"
        Me.Text = "ファイルダウンロード"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnSelectClear As System.Windows.Forms.Button
    Friend WithEvents btnSelectAll As System.Windows.Forms.Button
    Friend WithEvents btnBulkDownload As System.Windows.Forms.Button
    Friend WithEvents cbFileType As System.Windows.Forms.ComboBox
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents dtpToDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFromDateTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents FileType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DownloadFlg As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents SysDateView As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SysDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CmpName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CmpCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FileName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FileSize As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
