﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AlertHistList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpToDateTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpFromDateTime = New System.Windows.Forms.DateTimePicker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbAlertType = New System.Windows.Forms.ComboBox()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbCode = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.LogId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Code = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AlertType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AlertTypeName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogText = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.pnlSearchAdd = New System.Windows.Forms.Panel()
        Me.btnSearchAdd = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSearchAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 12)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "～"
        '
        'dtpToDateTime
        '
        Me.dtpToDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpToDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpToDateTime.Location = New System.Drawing.Point(190, 38)
        Me.dtpToDateTime.Name = "dtpToDateTime"
        Me.dtpToDateTime.ShowCheckBox = True
        Me.dtpToDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpToDateTime.TabIndex = 8
        '
        'dtpFromDateTime
        '
        Me.dtpFromDateTime.CustomFormat = "yyyy/MM/dd HH:mm"
        Me.dtpFromDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFromDateTime.Location = New System.Drawing.Point(12, 38)
        Me.dtpFromDateTime.Name = "dtpFromDateTime"
        Me.dtpFromDateTime.ShowCheckBox = True
        Me.dtpFromDateTime.Size = New System.Drawing.Size(149, 19)
        Me.dtpFromDateTime.TabIndex = 6
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbAlertType)
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.tbCode)
        Me.Panel1.Controls.Add(Me.btnSearch)
        Me.Panel1.Controls.Add(Me.dtpToDateTime)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.dtpFromDateTime)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(654, 64)
        Me.Panel1.TabIndex = 9
        '
        'cbAlertType
        '
        Me.cbAlertType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbAlertType.FormattingEnabled = True
        Me.cbAlertType.Location = New System.Drawing.Point(151, 12)
        Me.cbAlertType.Name = "cbAlertType"
        Me.cbAlertType.Size = New System.Drawing.Size(121, 20)
        Me.cbAlertType.TabIndex = 14
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 12)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(354, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 12)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "コード"
        '
        'tbCode
        '
        Me.tbCode.Location = New System.Drawing.Point(392, 39)
        Me.tbCode.Name = "tbCode"
        Me.tbCode.Size = New System.Drawing.Size(127, 19)
        Me.tbCode.TabIndex = 11
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(543, 28)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(89, 29)
        Me.btnSearch.TabIndex = 12
        Me.btnSearch.Text = "検索"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LogId, Me.LogTime, Me.CmpCode, Me.CmpName, Me.Code, Me.AlertType, Me.AlertTypeName, Me.LogText})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 64)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(654, 323)
        Me.grid.TabIndex = 10
        '
        'LogId
        '
        Me.LogId.DataPropertyName = "LogId"
        Me.LogId.HeaderText = "ログID"
        Me.LogId.Name = "LogId"
        Me.LogId.ReadOnly = True
        Me.LogId.Visible = False
        '
        'LogTime
        '
        Me.LogTime.DataPropertyName = "LogTime"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.Format = "yyyy/MM/dd HH:mm:ss"
        Me.LogTime.DefaultCellStyle = DataGridViewCellStyle2
        Me.LogTime.HeaderText = "日時"
        Me.LogTime.Name = "LogTime"
        Me.LogTime.ReadOnly = True
        Me.LogTime.Width = 120
        '
        'CmpCode
        '
        Me.CmpCode.DataPropertyName = "CmpCode"
        Me.CmpCode.HeaderText = "会社コード"
        Me.CmpCode.Name = "CmpCode"
        Me.CmpCode.ReadOnly = True
        Me.CmpCode.Visible = False
        '
        'CmpName
        '
        Me.CmpName.DataPropertyName = "CmpName"
        Me.CmpName.HeaderText = "会社"
        Me.CmpName.Name = "CmpName"
        Me.CmpName.ReadOnly = True
        '
        'Code
        '
        Me.Code.DataPropertyName = "Code"
        Me.Code.HeaderText = "コード"
        Me.Code.Name = "Code"
        Me.Code.ReadOnly = True
        Me.Code.Width = 120
        '
        'AlertType
        '
        Me.AlertType.DataPropertyName = "AlertType"
        Me.AlertType.HeaderText = "アラート種別コード"
        Me.AlertType.Name = "AlertType"
        Me.AlertType.ReadOnly = True
        Me.AlertType.Visible = False
        '
        'AlertTypeName
        '
        Me.AlertTypeName.DataPropertyName = "AlertTypeName"
        Me.AlertTypeName.HeaderText = "アラート種別"
        Me.AlertTypeName.Name = "AlertTypeName"
        Me.AlertTypeName.ReadOnly = True
        '
        'LogText
        '
        Me.LogText.DataPropertyName = "LogText"
        Me.LogText.HeaderText = "ログ"
        Me.LogText.Name = "LogText"
        Me.LogText.ReadOnly = True
        Me.LogText.Width = 410
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(208, 183)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(226, 63)
        Me.lblNoData.TabIndex = 25
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlSearchAdd
        '
        Me.pnlSearchAdd.Controls.Add(Me.btnSearchAdd)
        Me.pnlSearchAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlSearchAdd.Location = New System.Drawing.Point(0, 355)
        Me.pnlSearchAdd.Name = "pnlSearchAdd"
        Me.pnlSearchAdd.Size = New System.Drawing.Size(654, 32)
        Me.pnlSearchAdd.TabIndex = 26
        '
        'btnSearchAdd
        '
        Me.btnSearchAdd.Location = New System.Drawing.Point(4, 5)
        Me.btnSearchAdd.Name = "btnSearchAdd"
        Me.btnSearchAdd.Size = New System.Drawing.Size(129, 23)
        Me.btnSearchAdd.TabIndex = 11
        Me.btnSearchAdd.Text = "さらに読み込む"
        Me.btnSearchAdd.UseVisualStyleBackColor = True
        '
        'AlertHistList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(654, 387)
        Me.Controls.Add(Me.pnlSearchAdd)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "AlertHistList"
        Me.Text = "アラートログ一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSearchAdd.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents dtpToDateTime As DateTimePicker
    Friend WithEvents dtpFromDateTime As DateTimePicker
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents tbCode As TextBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents grid As DataGridView
    Friend WithEvents cbAlertType As ComboBox
    Friend WithEvents cbCmpCode As ComboBox
    Friend WithEvents lblNoData As Label
    Friend WithEvents pnlSearchAdd As Panel
    Friend WithEvents btnSearchAdd As Button
    Friend WithEvents LogId As DataGridViewTextBoxColumn
    Friend WithEvents LogTime As DataGridViewTextBoxColumn
    Friend WithEvents CmpCode As DataGridViewTextBoxColumn
    Friend WithEvents CmpName As DataGridViewTextBoxColumn
    Friend WithEvents Code As DataGridViewTextBoxColumn
    Friend WithEvents AlertType As DataGridViewTextBoxColumn
    Friend WithEvents AlertTypeName As DataGridViewTextBoxColumn
    Friend WithEvents LogText As DataGridViewTextBoxColumn
End Class
