﻿Public Class ProductBaseForm
    Public Property Code As String
    Public Property ModeCopyFlg As Boolean = False

    Private WithEvents service As New ProductBaseService

    Private Enum FormMode
        INIT = 0
        READ = 1
        REGIST = 2
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        REGISTRUN = 7
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub ProductBaseForm_Load(sender As System.Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        setTitle()

        cbComCode.DisplayMember = "ComName"
        cbComCode.ValueMember = "ComCode"
        cbComCode.DataSource = CurrencyPairService.GetList()

        cbEnabled.DisplayMember = "Name"
        cbEnabled.ValueMember = "Code"
        cbEnabled.DataSource = EnabledFlagManager.GetList()

        cbOpType.DisplayMember = "Name"
        cbOpType.ValueMember = "Code"
        cbOpType.DataSource = OptionTypeManager.GetList()

        MainWindow.SubFormProductBaseForm = True

        If Code = "" Then
            setFormMode(FormMode.REGIST)
            initRegist()
        ElseIf ((Code <> "") And (ModeCopyFlg)) Then
            setFormMode(FormMode.REGIST)
            initCopy()
            'lblCode.Text = ""  'service.ReadSuccessで消す
        Else
            setFormMode(FormMode.READ)
            lblCode.Text = Code
            initEdit()
        End If

    End Sub

    Private Sub ProductBaseForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormProductBaseForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.REGIST
                If checkInput() Then
                    setFormMode(FormMode.REGISTCONF)
                End If
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.REGISTCONF
                registData()
                setFormMode(FormMode.REGISTRUN)
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.REGISTCONF
                setFormMode(FormMode.REGIST)
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.REGISTRUN
                service.CancelRegist()
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setTitle()
        If Code = "" Then
            Me.Text = "銘柄設定登録"
        ElseIf ModeCopyFlg Then
            Me.Text = "銘柄設定登録(コピー)"
        Else
            If UserTypeManager.IsAdmin(SessionService.UserType) Then
                Me.Text = "銘柄設定編集"
            Else
                Me.Text = "銘柄設定参照"
            End If
        End If
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        cbComCode.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbOpType.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        pnlOpTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        nudOpTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        pnlCreateTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        nudCreateTerm.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpStartTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpStartSummerTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpEndTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        dtpEndSummerTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbPayoutRate.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbSpread.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbStopTradeTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbStartAbandTime.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAbandPriceDiff.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbAbandMargine.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbVolatilityAdjust.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTradeMoneyMin.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        tbTradeMoneyMax.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        cbEnabled.Enabled = (status = FormMode.REGIST Or status = FormMode.EDIT)
        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.REGISTRUN Or status = FormMode.EDITRUN)
        If cbOpType.Enabled = True Then
            setFormOpType()
        End If
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF, FormMode.REGISTRUN, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.REGISTCONF, FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initRegist()
        cbComCode.SelectedValue = ""
        cbOpType.SelectedIndex = 0
        rbOpTermHour.Checked = True
        nudOpTerm.Value = 0
        rbCreateTermHour.Checked = True
        nudCreateTerm.Value = 0
        dtpStartTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpStartSummerTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndSummerTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        cbEnabled.SelectedValue = ""
        tbTradeMoneyMin.Text = "0"
        tbTradeMoneyMax.Text = "0"
    End Sub

    Private Sub initEdit()
        cbComCode.SelectedValue = ""
        cbOpType.SelectedValue = ""
        dtpStartTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpStartSummerTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndSummerTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        cbEnabled.SelectedValue = ""

        service.Read(Code)
    End Sub

    Private Sub initCopy()
        cbComCode.SelectedValue = ""
        cbOpType.SelectedValue = ""
        dtpStartTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpStartSummerTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        dtpEndSummerTime.Value = New Date(2012, 1, 1, 0, 0, 0)
        cbEnabled.SelectedValue = ""

        service.Read(Code)
    End Sub

    Private Sub service_ReadCancel() Handles service.ReadCancel
        Me.Close()
    End Sub

    Private Sub service_RegistCancel() Handles service.RegistCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateCancel() Handles service.UpdateCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_RegistError(ErrorMessage As String) Handles service.RegistError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_UpdateError(ErrorMessage As String) Handles service.UpdateError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_ReadSuccess(list As List(Of ProductBaseData)) Handles service.ReadSuccess
        If list.Count <> 1 Then
            MessageBox.Show(Me, "銘柄設定の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        ElseIf list(0).ProductBaseCode <> Code Then
            MessageBox.Show(Me, "銘柄設定の情報が取得できませんでした。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Close()
        Else
            setControlFromData(list(0))
            If (UserTypeManager.IsAdmin(SessionService.UserType)) And (Not ModeCopyFlg) Then
                setFormMode(FormMode.EDIT)
            ElseIf (UserTypeManager.IsAdmin(SessionService.UserType)) And (ModeCopyFlg) Then
                lblCode.Text = ""
                setFormMode(FormMode.REGIST)
            Else
                setFormMode(FormMode.REFERENCE)
            End If
        End If
    End Sub

    Private Sub service_RegistSuccess(code As String) Handles service.RegistSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub service_UpdateSuccess() Handles service.UpdateSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As ProductBaseData)
        cbComCode.SelectedValue = data.ComCode
        cbOpType.SelectedValue = data.OpType
        If (data.OptionTime / 60) Mod 60 = 0 Then
            rbOpTermHour.Checked = True
            nudOpTerm.Value = data.OptionTime / 60 / 60
        ElseIf data.OptionTime Mod 60 = 0 Then
            rbOpTermMinutes.Checked = True
            nudOpTerm.Value = data.OptionTime / 60
        Else
            rbOpTermSeconds.Checked = True
            nudOpTerm.Value = data.OptionTime
        End If
        If (data.CreateTime / 60) Mod 60 = 0 Then
            rbCreateTermHour.Checked = True
            nudCreateTerm.Value = data.CreateTime / 60 / 60
        ElseIf data.OptionTime Mod 60 = 0 Then
            rbCreateTermMinutes.Checked = True
            nudCreateTerm.Value = data.CreateTime / 60
        Else
            rbCreateTermSeconds.Checked = True
            nudCreateTerm.Value = data.CreateTime
        End If
        dtpStartTime.Value = New Date(2012, 1, 1, data.StartTime.Hours, data.StartTime.Minutes, data.StartTime.Seconds)
        dtpStartSummerTime.Value = New Date(2012, 1, 1, data.StartSummerTime.Hours, data.StartSummerTime.Minutes, data.StartSummerTime.Seconds)
        dtpEndTime.Value = New Date(2012, 1, 1, data.ExercTime.Hours, data.ExercTime.Minutes, data.ExercTime.Seconds)
        dtpEndSummerTime.Value = New Date(2012, 1, 1, data.ExercSummerTime.Hours, data.ExercSummerTime.Minutes, data.ExercSummerTime.Seconds)
        tbPayoutRate.Text = data.PayoutRate.ToString("######0.########")
        tbSpread.Text = data.Spread
        tbStopTradeTime.Text = data.StopTradeTime
        tbStartAbandTime.Text = data.StartAbandTime
        tbAbandPriceDiff.Text = data.AbandPriceDiff
        tbAbandMargine.Text = (data.AbandMargine * 100).ToString("########0.######")
        tbVolatilityAdjust.Text = (data.VolatilityAdjust * 100).ToString("##0.############")
        tbTradeMoneyMin.Text = data.TradeMoneyMin.ToString(clsUtil.GetMoneyFormatEdit())
        tbTradeMoneyMax.Text = data.TradeMoneyMax.ToString(clsUtil.GetMoneyFormatEdit())
        cbEnabled.SelectedValue = data.ProductBaseEnabled
        setFormOpType()
    End Sub

    Private Function getDataFromControl() As ProductBaseData
        Dim ret As New ProductBaseData

        ret.ProductBaseCode = Code
        ret.ProductBaseEnabled = cbEnabled.SelectedValue
        ret.ComCode = cbComCode.SelectedValue
        ret.OpType = cbOpType.SelectedValue
        If rbOpTermHour.Checked Then
            ret.OptionTime = nudOpTerm.Value * 60 * 60
        ElseIf rbOpTermMinutes.Checked Then
            ret.OptionTime = nudOpTerm.Value * 60
        Else
            ret.OptionTime = nudOpTerm.Value
        End If
        Select Case ret.OpType
            Case OptionTypeManager.OpType.Binary
                ret.CreateTime = IIf(rbCreateTermHour.Checked, nudCreateTerm.Value * 60, nudCreateTerm.Value)
                If rbCreateTermHour.Checked Then
                    ret.CreateTime = nudCreateTerm.Value * 60 * 60
                ElseIf rbCreateTermMinutes.Checked Then
                    ret.CreateTime = nudCreateTerm.Value * 60
                Else
                    ret.CreateTime = nudCreateTerm.Value
                End If
            Case OptionTypeManager.OpType.AnyTime
                ret.CreateTime = tbCreateTerm.Text
        End Select
        ret.StartTime = New TimeSpan(dtpStartTime.Value.Hour, dtpStartTime.Value.Minute, dtpStartTime.Value.Second)
        ret.StartSummerTime = New TimeSpan(dtpStartSummerTime.Value.Hour, dtpStartSummerTime.Value.Minute, dtpStartSummerTime.Value.Second)
        ret.ExercTime = New TimeSpan(dtpEndTime.Value.Hour, dtpEndTime.Value.Minute, dtpEndTime.Value.Second)
        ret.ExercSummerTime = New TimeSpan(dtpEndSummerTime.Value.Hour, dtpEndSummerTime.Value.Minute, dtpEndSummerTime.Value.Second)
        ret.PayoutRate = Decimal.Parse(tbPayoutRate.Text)
        ret.Spread = Integer.Parse(tbSpread.Text)
        ret.StopTradeTime = Integer.Parse(tbStopTradeTime.Text)
        ret.StartAbandTime = Integer.Parse(tbStartAbandTime.Text)
        ret.AbandPriceDiff = Integer.Parse(tbAbandPriceDiff.Text)
        ret.AbandMargine = Decimal.Parse(tbAbandMargine.Text) / 100
        ret.VolatilityAdjust = Decimal.Parse(tbVolatilityAdjust.Text) / 100
        ret.TradeMoneyMin = Decimal.Parse(tbTradeMoneyMin.Text)
        ret.TradeMoneyMax = Decimal.Parse(tbTradeMoneyMax.Text)

        Return ret
    End Function


    Private Function checkInput() As Boolean
        If cbComCode.SelectedValue = "" Then
            MessageBox.Show(Me, "通貨ペアを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not rbOpTermHour.Checked And Not rbOpTermMinutes.Checked And Not rbOpTermSeconds.Checked Then
            MessageBox.Show(Me, "オプション期間を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If rbOpTermHour.Checked = True Then
            '時間が選択されている場合
            If nudOpTerm.Value < 1 Or nudOpTerm.Value > 12 Then
                MessageBox.Show(Me, "オプション期間には1以上かつ12以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        ElseIf rbOpTermMinutes.Checked = True Then
            '分が選択されている場合
            If nudOpTerm.Value < 1 Or nudOpTerm.Value > 720 Then
                MessageBox.Show(Me, "オプション期間には1以上かつ720以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        Else
            '秒が選択されている場合
            If nudOpTerm.Value < 1 Or nudOpTerm.Value > 43200 Then
                MessageBox.Show(Me, "オプション期間には1以上かつ720以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
        End If

        'バイナリオプションのみの確認
        If cbOpType.SelectedValue = OptionTypeManager.OpType.Binary Then
            If Not rbCreateTermHour.Checked And Not rbCreateTermMinutes.Checked And Not rbCreateTermSeconds.Checked Then
                MessageBox.Show(Me, "生成間隔を指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If rbCreateTermHour.Checked = True Then
                '時間が選択されている場合
                If nudCreateTerm.Value < 1 Or nudCreateTerm.Value > 12 Then
                    MessageBox.Show(Me, "生成間隔には1以上かつ12以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            ElseIf rbCreateTermMinutes.Checked = True Then
                '分が選択されている場合
                If nudCreateTerm.Value < 1 Or nudCreateTerm.Value > 720 Then
                    MessageBox.Show(Me, "生成間隔には1以上かつ720以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            Else
                '秒が選択されている場合
                If nudCreateTerm.Value < 1 Or nudCreateTerm.Value > 43200 Then
                    MessageBox.Show(Me, "生成間隔には1以上かつ43200以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
        End If

        'hh:mmフォーマットチェック
        If Not CheckUtil.IsTimeFormatCheck(dtpStartTime.Text) Then
            MessageBox.Show(Me, "生成開始時間にはhh:mm:ss形式を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        'hh:mmフォーマットチェック
        If Not CheckUtil.IsTimeFormatCheck(dtpStartSummerTime.Text) Then
            MessageBox.Show(Me, "生成開始時間(夏時間)にはhh:mm:ss形式を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        'hh:mmフォーマットチェック
        If Not CheckUtil.IsTimeFormatCheck(dtpEndTime.Text) Then
            MessageBox.Show(Me, "最終行使期日にはhh:mm:ss形式を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        'hh:mmフォーマットチェック
        If Not CheckUtil.IsTimeFormatCheck(dtpEndSummerTime.Text) Then
            MessageBox.Show(Me, "最終行使期日(夏時間)にはhh:mm:ss形式を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.RegExRate2.IsMatch(tbPayoutRate.Text) Then
            MessageBox.Show(Me, "ペイアウト率には0.5以上かつ1.2以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim payoutRate As Decimal
        If Not Decimal.TryParse(tbPayoutRate.Text, payoutRate) Then
            MessageBox.Show(Me, "ペイアウト率には0.5以上かつ1.2以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If payoutRate < 0.5 Or payoutRate > 1.2 Then
            MessageBox.Show(Me, "ペイアウト率には0.5以上かつ1.2以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim spread As Integer
        If Not Integer.TryParse(Me.tbSpread.Text, spread) Then
            MessageBox.Show(Me, "スプレッドには0以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If spread < 0 Or spread > 1000 Then
            MessageBox.Show(Me, "スプレッドには0以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim stopTradeTime As Integer
        If Not Integer.TryParse(Me.tbStopTradeTime.Text, stopTradeTime) Then
            MessageBox.Show(Me, "取引停止時間には5以上かつ21600以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If stopTradeTime < 5 Or stopTradeTime > 21600 Then
            MessageBox.Show(Me, "取引停止時間には5以上かつ21600以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim startAbandTime As Integer
        If Not Integer.TryParse(Me.tbStartAbandTime.Text, startAbandTime) Then
            MessageBox.Show(Me, "権利放棄可能時間には0以上かつ21600以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If startAbandTime < 0 Or startAbandTime > 21600 Then
            MessageBox.Show(Me, "権利放棄可能時間には0以上かつ21600以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim abandPriceDiff As Integer
        If Not Integer.TryParse(Me.tbAbandPriceDiff.Text, abandPriceDiff) Then
            MessageBox.Show(Me, "権利放棄可能価格差には0以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If abandPriceDiff < 0 Or abandPriceDiff > 100 Then
            MessageBox.Show(Me, "権利放棄可能価格差には0以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim abandMargine As Decimal
        If Not Decimal.TryParse(tbAbandMargine.Text, abandMargine) Then
            MessageBox.Show(Me, "権利放棄手数料には0以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If abandMargine < 0 Or abandMargine > 100 Then
            MessageBox.Show(Me, "権利放棄手数料には0以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim volatilityAdjust As Decimal
        If Not Decimal.TryParse(tbVolatilityAdjust.Text, volatilityAdjust) Then
            MessageBox.Show(Me, "ボラティリティレシオには1以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If volatilityAdjust < 1 Or volatilityAdjust > 100 Then
            MessageBox.Show(Me, "ボラティリティレシオには1以上かつ100以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim TradeMoneyMin As Decimal
        If Not Decimal.TryParse(tbTradeMoneyMin.Text, TradeMoneyMin) Then
            MessageBox.Show(Me, "最小取引額(1回)銘柄には0以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If TradeMoneyMin < 0 Or TradeMoneyMin > 1000 Then
            MessageBox.Show(Me, "最小取引額(1回)銘柄には0以上かつ1000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Dim TradeMoneyMax As Decimal
        If Not Decimal.TryParse(tbTradeMoneyMax.Text, TradeMoneyMax) Then
            MessageBox.Show(Me, "最大取引額(1回)銘柄には0以上かつ10000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If TradeMoneyMax < 0 Or TradeMoneyMax > 10000 Then
            MessageBox.Show(Me, "最大取引額(1回)銘柄には0以上かつ10000以下の適切な数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If cbEnabled.SelectedValue = "" Then
            MessageBox.Show(Me, "有効フラグを指定してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function

    Private Sub registData()
        Dim data As ProductBaseData = getDataFromControl()

        service.Regist(data)
    End Sub

    Private Sub updateData()
        Dim data As ProductBaseData = getDataFromControl()

        service.Update(data)
    End Sub

    Private Sub setFormOpType()
        Dim opType As String = cbOpType.SelectedValue

        Select Case opType
            Case OptionTypeManager.OpType.Binary
                formChangeBinary()
            Case OptionTypeManager.OpType.AnyTime
                formChangeAnyTime()
        End Select

    End Sub

    Private Sub formChangeBinary()
        rbCreateTermHour.Enabled = True
        rbCreateTermMinutes.Enabled = True
        nudCreateTerm.Visible = True
    End Sub

    Private Sub formChangeAnyTime()
        rbCreateTermHour.Enabled = False
        rbCreateTermMinutes.Enabled = False
        nudCreateTerm.Visible = False
    End Sub

    Private Sub cbOpType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbOpType.SelectedIndexChanged
        setFormOpType()
    End Sub

End Class