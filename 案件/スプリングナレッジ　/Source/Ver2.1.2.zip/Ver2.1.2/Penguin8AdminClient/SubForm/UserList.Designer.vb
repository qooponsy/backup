﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserList
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cbCmpCode = New System.Windows.Forms.ComboBox()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.btnReflesh = New System.Windows.Forms.Button()
        Me.chkEnabled = New System.Windows.Forms.CheckBox()
        Me.miEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.miChangePassword = New System.Windows.Forms.ToolStripMenuItem()
        Me.grid = New System.Windows.Forms.DataGridView()
        Me.lblNoData = New System.Windows.Forms.Label()
        Me.UserID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EnabledCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserEnabled = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountLockCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AccountLock = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UserType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CmpName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastAuthTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InsTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InsUser = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UpdTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UpdUser = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.cmGrid.SuspendLayout()
        CType(Me.grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbCmpCode)
        Me.Panel1.Controls.Add(Me.btnRegist)
        Me.Panel1.Controls.Add(Me.btnReflesh)
        Me.Panel1.Controls.Add(Me.chkEnabled)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(684, 40)
        Me.Panel1.TabIndex = 17
        '
        'cbCmpCode
        '
        Me.cbCmpCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbCmpCode.FormattingEnabled = True
        Me.cbCmpCode.Location = New System.Drawing.Point(12, 11)
        Me.cbCmpCode.Name = "cbCmpCode"
        Me.cbCmpCode.Size = New System.Drawing.Size(121, 20)
        Me.cbCmpCode.TabIndex = 11
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(385, 6)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(89, 29)
        Me.btnRegist.TabIndex = 3
        Me.btnRegist.Text = "新規"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'btnReflesh
        '
        Me.btnReflesh.Location = New System.Drawing.Point(296, 6)
        Me.btnReflesh.Name = "btnReflesh"
        Me.btnReflesh.Size = New System.Drawing.Size(89, 29)
        Me.btnReflesh.TabIndex = 2
        Me.btnReflesh.Text = "更新"
        Me.btnReflesh.UseVisualStyleBackColor = True
        '
        'chkEnabled
        '
        Me.chkEnabled.AutoSize = True
        Me.chkEnabled.Checked = True
        Me.chkEnabled.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkEnabled.Location = New System.Drawing.Point(144, 14)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(93, 16)
        Me.chkEnabled.TabIndex = 1
        Me.chkEnabled.Text = "有効のみ表示"
        Me.chkEnabled.UseVisualStyleBackColor = True
        '
        'miEdit
        '
        Me.miEdit.Name = "miEdit"
        Me.miEdit.Size = New System.Drawing.Size(160, 22)
        Me.miEdit.Text = "編集"
        '
        'cmGrid
        '
        Me.cmGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.miEdit, Me.miChangePassword})
        Me.cmGrid.Name = "cmGrid"
        Me.cmGrid.Size = New System.Drawing.Size(161, 48)
        '
        'miChangePassword
        '
        Me.miChangePassword.Name = "miChangePassword"
        Me.miChangePassword.Size = New System.Drawing.Size(160, 22)
        Me.miChangePassword.Text = "パスワード変更"
        '
        'grid
        '
        Me.grid.AllowUserToAddRows = False
        Me.grid.AllowUserToDeleteRows = False
        Me.grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.UserID, Me.EnabledCode, Me.UserEnabled, Me.AccountLockCode, Me.AccountLock, Me.UserName, Me.UserType, Me.CmpCode, Me.CmpName, Me.LastAuthTime, Me.InsTime, Me.InsUser, Me.UpdTime, Me.UpdUser})
        Me.grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grid.Location = New System.Drawing.Point(0, 40)
        Me.grid.MultiSelect = False
        Me.grid.Name = "grid"
        Me.grid.ReadOnly = True
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.grid.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.grid.RowHeadersVisible = False
        Me.grid.RowTemplate.Height = 21
        Me.grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grid.Size = New System.Drawing.Size(684, 422)
        Me.grid.TabIndex = 22
        '
        'lblNoData
        '
        Me.lblNoData.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.lblNoData.Font = New System.Drawing.Font("MS UI Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lblNoData.ForeColor = System.Drawing.Color.Red
        Me.lblNoData.Location = New System.Drawing.Point(216, 166)
        Me.lblNoData.Name = "lblNoData"
        Me.lblNoData.Padding = New System.Windows.Forms.Padding(0, 32, 0, 0)
        Me.lblNoData.Size = New System.Drawing.Size(203, 63)
        Me.lblNoData.TabIndex = 23
        Me.lblNoData.Text = "対象のデータはありませんでした"
        Me.lblNoData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'UserID
        '
        Me.UserID.DataPropertyName = "UserID"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.UserID.DefaultCellStyle = DataGridViewCellStyle2
        Me.UserID.HeaderText = "ユーザーID"
        Me.UserID.Name = "UserID"
        Me.UserID.ReadOnly = True
        Me.UserID.Width = 110
        '
        'EnabledCode
        '
        Me.EnabledCode.DataPropertyName = "EnabledCode"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.EnabledCode.DefaultCellStyle = DataGridViewCellStyle3
        Me.EnabledCode.HeaderText = "有効フラグ(Code)"
        Me.EnabledCode.Name = "EnabledCode"
        Me.EnabledCode.ReadOnly = True
        Me.EnabledCode.Visible = False
        '
        'UserEnabled
        '
        Me.UserEnabled.DataPropertyName = "Enabled"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.UserEnabled.DefaultCellStyle = DataGridViewCellStyle4
        Me.UserEnabled.HeaderText = "有効フラグ"
        Me.UserEnabled.Name = "UserEnabled"
        Me.UserEnabled.ReadOnly = True
        Me.UserEnabled.Width = 80
        '
        'AccountLockCode
        '
        Me.AccountLockCode.DataPropertyName = "AccountLockCode"
        Me.AccountLockCode.HeaderText = "アカウントロック(Code)"
        Me.AccountLockCode.Name = "AccountLockCode"
        Me.AccountLockCode.ReadOnly = True
        Me.AccountLockCode.Visible = False
        '
        'AccountLock
        '
        Me.AccountLock.DataPropertyName = "AccountLock"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.AccountLock.DefaultCellStyle = DataGridViewCellStyle5
        Me.AccountLock.HeaderText = "アカウントロック"
        Me.AccountLock.Name = "AccountLock"
        Me.AccountLock.ReadOnly = True
        Me.AccountLock.Width = 80
        '
        'UserName
        '
        Me.UserName.DataPropertyName = "UserName"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.NullValue = Nothing
        Me.UserName.DefaultCellStyle = DataGridViewCellStyle6
        Me.UserName.HeaderText = "ユーザー名"
        Me.UserName.Name = "UserName"
        Me.UserName.ReadOnly = True
        Me.UserName.Width = 125
        '
        'UserType
        '
        Me.UserType.DataPropertyName = "UserType"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.UserType.DefaultCellStyle = DataGridViewCellStyle7
        Me.UserType.HeaderText = "ユーザー種別"
        Me.UserType.Name = "UserType"
        Me.UserType.ReadOnly = True
        Me.UserType.Width = 120
        '
        'CmpCode
        '
        Me.CmpCode.DataPropertyName = "CmpCode"
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.CmpCode.DefaultCellStyle = DataGridViewCellStyle8
        Me.CmpCode.HeaderText = "会社(code)"
        Me.CmpCode.Name = "CmpCode"
        Me.CmpCode.ReadOnly = True
        Me.CmpCode.Visible = False
        Me.CmpCode.Width = 5
        '
        'CmpName
        '
        Me.CmpName.DataPropertyName = "CmpName"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.CmpName.DefaultCellStyle = DataGridViewCellStyle9
        Me.CmpName.HeaderText = "会社"
        Me.CmpName.Name = "CmpName"
        Me.CmpName.ReadOnly = True
        Me.CmpName.Width = 125
        '
        'LastAuthTime
        '
        Me.LastAuthTime.DataPropertyName = "LastAuthTime"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle10.NullValue = Nothing
        Me.LastAuthTime.DefaultCellStyle = DataGridViewCellStyle10
        Me.LastAuthTime.HeaderText = "最終認証日時"
        Me.LastAuthTime.Name = "LastAuthTime"
        Me.LastAuthTime.ReadOnly = True
        Me.LastAuthTime.Width = 130
        '
        'InsTime
        '
        Me.InsTime.DataPropertyName = "InsTime"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle11.NullValue = Nothing
        Me.InsTime.DefaultCellStyle = DataGridViewCellStyle11
        Me.InsTime.HeaderText = "登録日時"
        Me.InsTime.Name = "InsTime"
        Me.InsTime.ReadOnly = True
        Me.InsTime.Width = 130
        '
        'InsUser
        '
        Me.InsUser.DataPropertyName = "InsUser"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.InsUser.DefaultCellStyle = DataGridViewCellStyle12
        Me.InsUser.HeaderText = "登録ユーザー"
        Me.InsUser.Name = "InsUser"
        Me.InsUser.ReadOnly = True
        Me.InsUser.Width = 110
        '
        'UpdTime
        '
        Me.UpdTime.DataPropertyName = "UpdTime"
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle13.Format = "yyyy/MM/dd HH:mm:ss"
        DataGridViewCellStyle13.NullValue = Nothing
        Me.UpdTime.DefaultCellStyle = DataGridViewCellStyle13
        Me.UpdTime.HeaderText = "更新日時"
        Me.UpdTime.Name = "UpdTime"
        Me.UpdTime.ReadOnly = True
        Me.UpdTime.Width = 130
        '
        'UpdUser
        '
        Me.UpdUser.DataPropertyName = "UpdUser"
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.UpdUser.DefaultCellStyle = DataGridViewCellStyle14
        Me.UpdUser.HeaderText = "更新ユーザー"
        Me.UpdUser.Name = "UpdUser"
        Me.UpdUser.ReadOnly = True
        Me.UpdUser.Width = 110
        '
        'UserList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(684, 462)
        Me.Controls.Add(Me.lblNoData)
        Me.Controls.Add(Me.grid)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "UserList"
        Me.Text = "ユーザー一覧"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.cmGrid.ResumeLayout(False)
        CType(Me.grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents btnReflesh As System.Windows.Forms.Button
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents miEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents miChangePassword As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbCmpCode As System.Windows.Forms.ComboBox
    Private WithEvents grid As System.Windows.Forms.DataGridView
    Friend WithEvents lblNoData As System.Windows.Forms.Label
    Friend WithEvents UserID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EnabledCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UserEnabled As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountLockCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AccountLock As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UserName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UserType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CmpCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CmpName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LastAuthTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InsTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents InsUser As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UpdTime As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents UpdUser As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
