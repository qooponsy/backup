﻿Imports System.Globalization

Public Class UserChangePasswordForm

    Public Property Code As String

    Private WithEvents service As New UserService

    Private Enum FormMode
        INIT = 0
        READ = 1
        EDIT = 3
        REFERENCE = 4
        REGISTCONF = 5
        EDITCONF = 6
        EDITRUN = 8
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub UserChangePasswordForm_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Me.DoubleBuffered = True

        MainWindow.SubFormUserChangePasswordForm = True

        setFormMode(FormMode.READ)
        initEdit()
    End Sub

    Private Sub UserChangePasswordForm_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainWindow.SubFormUserChangePasswordForm = False
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Select Case FormModeStatus
            Case FormMode.EDIT
                If checkInput() Then
                    setFormMode(FormMode.EDITCONF)
                End If
            Case FormMode.EDITCONF
                updateData()
                setFormMode(FormMode.EDITRUN)
        End Select
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.READ
                service.CancelRead()
            Case FormMode.EDITCONF
                setFormMode(FormMode.EDIT)
            Case FormMode.EDITRUN
                service.CancelUpdate()
            Case Else
                Me.Close()
        End Select
    End Sub

    Private Sub setFormMode(status As FormMode)
        FormModeStatus = status

        tbPassword.Enabled = (status = FormMode.EDIT)
        btnOK.Enabled = Not (status = FormMode.READ Or status = FormMode.REFERENCE Or status = FormMode.EDITRUN)
        Select Case status
            Case FormMode.EDITCONF, FormMode.EDITRUN
                btnOK.Text = "登録"
            Case Else
                btnOK.Text = "内容確認"
        End Select
        btnCancel.Enabled = True
        Select Case status
            Case FormMode.EDITCONF
                btnCancel.Text = "戻る"
            Case Else
                btnCancel.Text = "キャンセル"
        End Select
    End Sub

    Private Sub initEdit()
        service.Read(Code)
    End Sub

    Private Sub service_ReadSuccess(list As System.Collections.Generic.List(Of UserData)) Handles service.ReadSuccess
        setControlFromData(list(0))

        If UserTypeManager.IsAdmin(SessionService.UserType) Then
            setFormMode(FormMode.EDIT)
        Else
            setFormMode(FormMode.REFERENCE)
        End If
    End Sub

    Private Sub service_UpdatePasswordCancel() Handles service.UpdatePasswordCancel
        MessageBox.Show(Me, "登録をキャンセルしましたが、サーバー側では登録を完了している可能性があります。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.REGISTCONF)
    End Sub

    Private Sub service_ReadError(ErrorMessage As String) Handles service.ReadError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Me.Close()
    End Sub

    Private Sub service_UpdatePasswordError(ErrorMessage As String) Handles service.UpdatePasswordError
        MessageBox.Show(Me, ErrorMessage, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
        setFormMode(FormMode.EDITCONF)
    End Sub

    Private Sub service_UpdatePasswordSuccess() Handles service.UpdatePasswordSuccess
        MessageBox.Show(Me, "登録しました。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.Close()
    End Sub

    Private Sub setControlFromData(data As UserData)
        lblUserID.Text = data.UserID
        lblUserName.Text = data.UserName
    End Sub

    Private Function checkInput() As Boolean
        If Me.tbPassword.Text.Length = 0 Then
            MessageBox.Show(Me, "パスワードを入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.IsMatchPasswordPolicy(Me.tbPassword.Text) Then
            MessageBox.Show(Me, "パスワードポリシーを満たしていません。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Return True
    End Function

    Private Sub updateData()
        service.UpdatePassword(lblUserID.Text, tbPassword.Text)
    End Sub

End Class