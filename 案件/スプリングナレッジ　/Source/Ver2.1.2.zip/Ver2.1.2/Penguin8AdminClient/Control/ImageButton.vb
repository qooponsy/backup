﻿Public Class ImageButton
    Inherits PictureBox

    Public Property OffImage As Image
    Public Property OnImage As Image

    Protected ButtonMode As Boolean = False

    Protected Overrides Sub InitLayout()
        MyBase.InitLayout()
        ButtonMode = False
        Me.Image = OffImage
    End Sub

    Protected Overrides Sub OnMouseDown(e As MouseEventArgs)
        If Not ButtonMode Then
            ButtonMode = True
            Me.Image = OnImage
        End If
        MyBase.OnMouseDown(e)
    End Sub

    Protected Overrides Sub OnMouseUp(e As MouseEventArgs)
        If ButtonMode Then
            ButtonMode = False
            Me.Image = OffImage
        End If

        MyBase.OnMouseUp(e)
    End Sub
End Class
