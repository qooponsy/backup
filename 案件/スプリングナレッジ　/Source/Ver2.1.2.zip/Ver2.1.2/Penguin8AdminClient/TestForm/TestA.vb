﻿Public Class TestA

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim hash As HashSet(Of String) = New HashSet(Of String)("10000001,10000002,10000101,10000102,10000103,10000104,10000111,10000112,10000113".Split(","))

        DataGridView1.Rows.Add(New Object() {"1", "TEST1", "3"})
        DataGridView1.Rows.Add(New Object() {"2", "TEST2", "3"})
        DataGridView1.Rows.Add(New Object() {"3", "TEST3", "3"})

    End Sub
End Class