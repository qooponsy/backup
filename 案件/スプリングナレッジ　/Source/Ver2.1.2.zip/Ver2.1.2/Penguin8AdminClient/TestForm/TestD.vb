﻿Imports System.Net
Imports System.Collections.Specialized

Public Class TestD

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        CompanyService.Init()
        Me.ComboBox1.DataSource = CompanyService.GetListWithAll()
        Me.ComboBox1.DisplayMember = "CmpCodeName"
        Me.ComboBox1.ValueMember = "CmpCodeID"
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        CompanyService.Init()
        Me.ComboBox2.DataSource = CompanyService.GetListWithAll()
        Me.ComboBox2.DisplayMember = "CmpCodeAnotherName"
        Me.ComboBox2.ValueMember = "CmpCodeID"
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        CurrencyPairService.Init()
        Me.ComboBox3.DataSource = CurrencyPairService.GetList()
        Me.ComboBox3.DisplayMember = "ComName"
        Me.ComboBox3.ValueMember = "ComCode"
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        CurrencyPairService.Init()
        Me.ComboBox4.DataSource = CurrencyPairService.GetListWithAll()
        Me.ComboBox4.DisplayMember = "ComName"
        Me.ComboBox4.ValueMember = "ComCode"
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        CalcParamService.Init()
        Dim calc As CalcParamData = CalcParamService.getData(TextBox1.Text)
        Label1.Text = "ComCode：" & calc.ComCode & vbCrLf _
                    & "DeltaVariation：" & calc.DeltaVariation & vbCrLf _
                    & "GammaVariation：" & calc.GammaVariation & vbCrLf _
                    & "InterestRate：" & calc.InterestRate & vbCrLf _
                    & "RhoVariation：" & calc.RhoVariation & vbCrLf _
                    & "ThetaVariation：" & calc.ThetaVariation & vbCrLf _
                    & "VegaVariation：" & calc.VegaVariation & vbCrLf _
                    & "Volatility：" & calc.Volatility
    End Sub
End Class