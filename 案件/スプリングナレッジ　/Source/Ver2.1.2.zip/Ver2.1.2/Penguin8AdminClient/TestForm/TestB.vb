﻿Imports System.Net
Imports System.Collections.Specialized
Imports System.Text

Public Class TestB

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        OperationHistList.MdiParent = Me.MdiParent
        OperationHistList.Show()
        Me.Close()
    End Sub

End Class