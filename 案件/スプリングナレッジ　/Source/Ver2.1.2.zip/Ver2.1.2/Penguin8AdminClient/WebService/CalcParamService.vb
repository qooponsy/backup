﻿Imports System.Net
Imports System.Collections.Specialized

Public Class CalcParamService
    Private Const URL_READ As String = "getcalcparamadmin.aspx"

    Public Shared Event Initialized()
    Public Shared Event DataChanged()
    Public Shared Event ReadError(ErrorMessage As String)

    Private Shared WithEvents webServiceClientRead As WebClient
    Private Shared WithEvents tickService As RateTickService

    Private Shared InitFlag As Boolean
    Private Shared PublicUpdateSeq As Integer = 0
    Private Shared DataDic As New Dictionary(Of String, CalcParamData)

    Public Shared Sub Init()
        InitFlag = True
        Request()
    End Sub

    Public Shared Function GetData(ByVal Code As String) As CalcParamData
        Return DataDic(Code)
    End Function

    Private Shared Sub Request()
        webServiceClientRead = New WebClient
        Dim values As New NameValueCollection
        values.Add("key", SessionService.SessionKey)
        webServiceClientRead.UploadValuesAsync(SessionService.CreateURL(URL_READ), Nothing, values, Nothing)
    End Sub

    Private Shared Sub webServiceClientRead_UploadValuesCompleted(sender As Object, e As System.Net.UploadValuesCompletedEventArgs) Handles webServiceClientRead.UploadValuesCompleted
        webServiceClientRead = Nothing
        Do
            Dim list As New List(Of CalcParamData)

            'キャンセル
            If e.Cancelled Then
                RaiseEvent ReadError(e.Error.Message)
                Exit Do
            End If

            'エラー
            If e.Error IsNot Nothing Then
                RaiseEvent ReadError(e.Error.Message)
                Exit Do
            End If

            Dim resdata As Byte() = e.Result

            Dim res As New ResParser
            Dim reslines As String() = res.parseResponse(resdata)
            If res.ResultCode <> "" Then
                RaiseEvent ReadError(res.ResultText)
                Exit Do
            End If

            If UBound(reslines) < 1 Then
                RaiseEvent ReadError("サーバからの応答が異常です。")
                Exit Do
            End If

            Dim lineindex As Integer = 1
            PublicUpdateSeq = reslines(lineindex)
            lineindex += 1
            Dim count As Integer = reslines(lineindex)
            lineindex += 1
            If UBound(reslines) < lineindex + count - 1 Then
                RaiseEvent ReadError("サーバからの応答が異常です。")
                Exit Do
            End If

            For i As Integer = 1 To count
                Dim ColumnArray() As String = reslines(lineindex).Split(",")
                lineindex += 1
                Dim item As New CalcParamData
                item.ComCode = ColumnArray(0)
                item.InterestRate = Decimal.Parse(ColumnArray(1))
                item.SwapRate = Decimal.Parse(ColumnArray(2))
                item.VolatilityAdjust = Decimal.Parse(ColumnArray(3))
                item.Volatility = Decimal.Parse(ColumnArray(4))
                item.DeltaVariation = Decimal.Parse(ColumnArray(5))
                item.GammaVariation = Decimal.Parse(ColumnArray(6))
                item.VegaVariation = Decimal.Parse(ColumnArray(7))
                item.ThetaVariation = Decimal.Parse(ColumnArray(8))
                item.RhoVariation = Decimal.Parse(ColumnArray(9))
                list.Add(item)
            Next

            If InitFlag Then
                InitFlag = False
                SetList(list)
                RaiseEvent Initialized()
                tickService = New RateTickService
            Else
                Dim changed As Boolean = False
                If list.Count <> DataDic.Count Then
                    changed = True
                Else
                    For Each item As CalcParamData In list
                        If DataDic.ContainsKey(item.ComCode) Then
                            Dim oldItem As CalcParamData = DataDic(item.ComCode)
                            If Not oldItem.IsMatch(item) Then
                                changed = True
                                Exit For
                            End If
                        Else
                            changed = True
                            Exit For
                        End If
                    Next
                End If
                If changed Then
                    SetList(list)
                    RaiseEvent DataChanged()
                End If
            End If
        Loop While False
    End Sub

    Private Shared Sub SetList(list As List(Of CalcParamData))
        DataDic.Clear()
        For Each item As CalcParamData In list
            DataDic.Add(item.ComCode, item)
        Next
    End Sub

    Private Shared Sub tickService_NewTick() Handles tickService.NewTick
        If PublicUpdateSeq >= RateTickService.PublicUpdateSeq Then
            Exit Sub
        End If

        Request()
    End Sub
End Class
