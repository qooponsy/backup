﻿Imports System.Net
Imports System.Collections.Specialized

Public Class BulkTaskService

    Private Const URL_READ As String = "getbulktaskstatus.aspx"

    Public Event ReadSuccess(item As BulkTaskData)
    Public Event ReadCancel()
    Public Event ReadError(ErrorMessage As String)

    Private WithEvents webServiceClientRead As WebClient

    Public Sub Read(Code As String)
        webServiceClientRead = New WebClient
        Dim values As New NameValueCollection
        values.Add("key", SessionService.SessionKey)
        values.Add("seq", Code)
        webServiceClientRead.UploadValuesAsync(SessionService.CreateURL(URL_READ), Nothing, values, Nothing)
    End Sub

    Public Sub CancelRead()
        If webServiceClientRead IsNot Nothing Then
            webServiceClientRead.CancelAsync()
        End If
    End Sub

    Private Sub webServiceClientRead_UploadValuesCompleted(sender As Object, e As System.Net.UploadValuesCompletedEventArgs) Handles webServiceClientRead.UploadValuesCompleted
        webServiceClientRead = Nothing
        Do

            If e.Cancelled Then
                RaiseEvent ReadCancel()
                Exit Do
            End If
            If e.Error IsNot Nothing Then
                RaiseEvent ReadError(e.Error.Message)
                Exit Do
            End If

            Dim resdata As Byte() = e.Result

            Dim res As New ResParser
            Dim reslines As String() = res.parseResponse(resdata)
            If res.ResultCode <> "" Then
                RaiseEvent ReadError(res.ResultText)
                Exit Do
            End If

            If UBound(reslines) < 2 Then
                RaiseEvent ReadError("サーバからの応答が異常です。")
                Exit Do
            End If

            Dim lineindex As Integer = 1
            Dim count As Integer = reslines(lineindex)
            lineindex += 1
            If UBound(reslines) < lineindex + count - 1 Then
                RaiseEvent ReadError("サーバからの応答が異常です。")
                Exit Do
            End If

            Dim item = New BulkTaskData
            For i As Integer = 1 To count
                Dim ColumnArray() As String = reslines(lineindex).Split(",")
                lineindex += 1
                item.TaskSeq = ColumnArray(0)
                item.TaskStatus = ColumnArray(1)
                item.TaskType = ColumnArray(2)
                item.TaskParam = ColumnArray(3)
                item.LastStep = Integer.Parse(ColumnArray(4))
                item.ExecStep = Integer.Parse(ColumnArray(5))
                If ColumnArray(6) = "" Then
                    item.ExecStartTimeEnabled = False
                Else
                    item.ExecStartTimeEnabled = True
                    DateTimeUtil.ConvToDate(ColumnArray(6), DateTimeUtil.ComplementMode.fromTime, item.ExecStartTime)
                End If
                If ColumnArray(7) = "" Then
                    item.ExecEndTimeEnabled = False
                Else
                    item.ExecEndTimeEnabled = True
                    DateTimeUtil.ConvToDate(ColumnArray(7), DateTimeUtil.ComplementMode.fromTime, item.ExecEndTime)
                End If
                item.TaskResult = ColumnArray(8)
                Exit For
            Next

            RaiseEvent ReadSuccess(item)
        Loop While False
    End Sub

End Class
