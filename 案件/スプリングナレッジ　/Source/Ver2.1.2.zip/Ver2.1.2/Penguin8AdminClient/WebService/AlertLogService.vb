﻿Imports System.Collections.Specialized
Imports System.Net

Public Class AlertLogService
    Private Const URL_READ As String = "getalertlog.aspx"

    Public Event ReadSuccess(list As List(Of AlertLogData), ExistNextFlag As Boolean, RateFilterUpdateSeq As Int64)
    Public Event ReadCancel()
    Public Event ReadError(ErrorMessage As String)

    Private WithEvents webServiceClientRead As WebClient

    Public Sub Read(RateFilterUpdateSeq As Int64)
        webServiceClientRead = New WebClient
        Dim values As New NameValueCollection
        values.Add("key", SessionService.SessionKey)
        values.Add("lastid", RateFilterUpdateSeq)
        webServiceClientRead.UploadValuesAsync(SessionService.CreateURL(URL_READ), Nothing, values, Nothing)
    End Sub

    Public Sub ReadList(ByVal CmpCode As String,
                        ByVal AlertType As String,
                        ByVal FromDateTime As String,
                        ByVal ToDateTime As String,
                        ByVal Code As String,
                        ByVal Count As String,
                        ByVal Start As String)
        webServiceClientRead = New WebClient
        Dim values As New NameValueCollection
        values.Add("key", SessionService.SessionKey)
        values.Add("cmpcode", CmpCode)
        values.Add("alerttype", AlertType)
        values.Add("from", FromDateTime)
        values.Add("to", ToDateTime)
        values.Add("code", Code)
        values.Add("count", Count)
        values.Add("start", Start)

        webServiceClientRead.UploadValuesAsync(New Uri(SessionService.BaseAddress, URL_READ), Nothing, values, Nothing)

    End Sub

    Public Sub CancelRead()
        If webServiceClientRead IsNot Nothing Then
            webServiceClientRead.CancelAsync()
        End If
    End Sub

    Private Sub webServiceClientRead_UploadValuesCompleted(sender As Object, e As UploadValuesCompletedEventArgs) Handles webServiceClientRead.UploadValuesCompleted
        webServiceClientRead = Nothing

        Do
            If e.Cancelled Then
                RaiseEvent ReadCancel()
                Exit Do
            End If

            If e.Error IsNot Nothing Then
                RaiseEvent ReadError(e.Error.Message)
                Exit Do
            End If

            Dim resdata As Byte() = e.Result

            Dim res As New ResParser
            Dim reslines As String() = res.parseResponse(resdata)
            If res.ResultCode <> "" Then
                RaiseEvent ReadError(res.ResultText)
                Exit Do
            End If

            If UBound(reslines) < 1 Then
                RaiseEvent ReadError("サーバからの応答が異常です。")
                Exit Do
            End If

            Dim lineindex As Integer = 1
            Dim AlertLogUpdateSeq As Int64 = reslines(lineindex)
            Dim existNextFlag = IIf(reslines(lineindex + 1) = "1", True, False) 'さらに読み込むボタンを表示するかのフラグ
            lineindex += 1
            Dim count As Integer = reslines(lineindex + 1)
            lineindex += 1
            If UBound(reslines) < lineindex + count - 1 Then
                RaiseEvent ReadError("サーバからの応答が異常です。")
                Exit Do
            End If
            lineindex += 1

            Dim list As New List(Of AlertLogData)
            For i As Integer = 1 To count
                Dim ColumnArray() As String = reslines(lineindex).Split(",")
                lineindex += 1
                Dim item As AlertLogData = New AlertLogData
                item.LogID = ColumnArray(0)
                DateTimeUtil.ConvToDateTime(ColumnArray(1), DateTimeUtil.ComplementMode.fromTime, item.LogTime)
                item.AlertType = ColumnArray(2)
                item.CmpCode = ColumnArray(3)
                item.Code = ColumnArray(4)
                item.LogText = ResParser.unescapeString(ColumnArray(5))
                list.Add(item)
            Next

            RaiseEvent ReadSuccess(list, existNextFlag, AlertLogUpdateSeq)
        Loop While False
    End Sub

End Class
