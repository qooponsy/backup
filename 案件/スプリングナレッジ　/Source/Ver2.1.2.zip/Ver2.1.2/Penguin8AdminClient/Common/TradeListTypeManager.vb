﻿Public Class TradeListTypeManager

    Private Shared List As New List(Of TradeListTypeManager)

    Public Shared Sub Init()
        List.Add(New TradeListTypeManager With {.Code = "0", .Name = "取引一覧"})
        List.Add(New TradeListTypeManager With {.Code = "1", .Name = "取引履歴"})
    End Sub

    Public Shared Function GetList() As List(Of TradeListTypeManager)
        Return List.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
