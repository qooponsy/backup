﻿Public Class TradeStatusManager

    Public Shared List As New List(Of TradeStatusManager)
    Private Shared ListWithAll As New List(Of TradeStatusManager)

    Public Shared Sub Init()
        List.Add(New TradeStatusManager With {.Code = "01", .Name = "注文中"})
        List.Add(New TradeStatusManager With {.Code = "02", .Name = "成立"})
        List.Add(New TradeStatusManager With {.Code = "03", .Name = "不成立"})
        List.Add(New TradeStatusManager With {.Code = "05", .Name = "キャンセル"})
        List.Add(New TradeStatusManager With {.Code = "10", .Name = "行使"})
        List.Add(New TradeStatusManager With {.Code = "11", .Name = "放棄(期限前)"})
        List.Add(New TradeStatusManager With {.Code = "12", .Name = "消滅(期限)"})
        List.Add(New TradeStatusManager With {.Code = "13", .Name = "ATM"})
        List.Add(New TradeStatusManager With {.Code = "20", .Name = "削除"})

        ListWithAll.Add(New TradeStatusManager With {.Code = "", .Name = "全て"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "01", .Name = "注文中"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "02", .Name = "成立"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "03", .Name = "不成立"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "05", .Name = "キャンセル"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "10", .Name = "行使"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "11", .Name = "放棄(期限前)"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "12", .Name = "消滅(期限)"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "13", .Name = "ATM"})
        ListWithAll.Add(New TradeStatusManager With {.Code = "20", .Name = "削除"})
    End Sub

    Public Shared Function GetList() As List(Of TradeStatusManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of TradeStatusManager)
        Return ListWithAll.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
