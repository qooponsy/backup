﻿Public Class AccountLockFlagManager

    Public Class AccountLock
        Public Const Lock As String = "1"
        Public Const UnLock As String = "0"
    End Class

    Public Shared List As New List(Of AccountLockFlagManager)

    Public Shared Sub Init()
        List.Add(New AccountLockFlagManager With {.Code = AccountLock.UnLock, .Name = "なし"})
        List.Add(New AccountLockFlagManager With {.Code = AccountLock.Lock, .Name = "ロック"})
    End Sub

    Public Shared Function GetList() As List(Of AccountLockFlagManager)
        Return List.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
