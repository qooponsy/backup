﻿Public Class UserTypeManager

    Public Class UserTypeCode
        ''' <summary>
        ''' 管理者
        ''' </summary>
        ''' <remarks></remarks>
        Public Const Admin As String = "01"
        ''' <summary>
        ''' 管理者（参照）
        ''' </summary>
        ''' <remarks></remarks>
        Public Const AdminRef As String = "02"
        ''' <summary>
        ''' 一般ユーザ
        ''' </summary>
        ''' <remarks></remarks>
        Public Const Normal As String = "03"
        ''' <summary>
        ''' 参照者
        ''' </summary>
        ''' <remarks></remarks>
        Public Const Referrer As String = "04"
        ''' <summary>
        ''' ホワイトラベル
        ''' </summary>
        ''' <remarks></remarks>
        Public Const WhiteLabel As String = "05"
		''' <summary>
		''' ホワイトラベル（参照）
		''' </summary>
		''' <remarks></remarks>
		Public Const WhiteLabelReferrer As String = "06"
	End Class

    Public Shared List As New List(Of UserTypeManager)

    Public Shared Sub Init()
		If UserTypeManager.IsEdit(SessionService.UserType) Or UserTypeManager.IsReferrer(SessionService.UserType) Then
			'WL以外
			List.Add(New UserTypeManager With {.Code = UserTypeCode.Admin, .Name = "管理者"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.AdminRef, .Name = "管理者（参照）"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.Normal, .Name = "一般ユーザー"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.Referrer, .Name = "参照者"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.WhiteLabel, .Name = "ホワイトラベル"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.WhiteLabelReferrer, .Name = "ホワイトラベル（参照）"})
		Else
			'WL用
			'List.Add(New UserTypeManager With {.Code = UserTypeCode.Admin, .Name = "管理者"})
			'List.Add(New UserTypeManager With {.Code = UserTypeCode.AdminRef, .Name = "管理者（参照）"})
			'List.Add(New UserTypeManager With {.Code = UserTypeCode.Normal, .Name = "一般ユーザー"})
			'List.Add(New UserTypeManager With {.Code = UserTypeCode.Referrer, .Name = "参照者"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.WhiteLabel, .Name = "ホワイトラベル"})
			List.Add(New UserTypeManager With {.Code = UserTypeCode.WhiteLabelReferrer, .Name = "ホワイトラベル（参照）"})
		End If
	End Sub

	''' <summary>
	''' o：管理者、
	''' x：一般ユーザー、
	''' x：参照者、
	''' x：ホワイトラベル、
	''' x：ホワイトラベル参照者、
	''' </summary>
	''' <param name="UserType"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Shared Function IsAdmin(UserType As String) As Boolean
		Return UserType = UserTypeCode.Admin
	End Function

	''' <summary>
	''' データ取得系に利用
	''' 、の管理者用
	''' </summary>
	''' <param name="UserType"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Shared Function IsAdminView(UserType As String) As Boolean
		Return UserType = UserTypeCode.Admin Or UserType = UserTypeCode.AdminRef
	End Function

	''' <summary>
	''' o：管理者、
	''' o：一般ユーザー、
	''' x：参照者、
	''' x：ホワイトラベル、
	''' x：ホワイトラベル（参照）、
	''' </summary>
	''' <param name="UserType"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Shared Function IsEdit(UserType As String) As Boolean
		Return UserType = UserTypeCode.Admin Or UserType = UserTypeCode.Normal
	End Function

	''' <summary>
	''' x：管理者、
	''' x：一般ユーザー、
	''' o：参照者、
	''' x：ホワイトラベル、
	''' x：ホワイトラベル（参照）、
	''' 2014/12 ADD
	''' </summary>
	''' <param name="UserType"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Shared Function IsReferrer(UserType As String) As Boolean
		Return UserType = UserTypeCode.Referrer
	End Function

	''' <summary>
	''' x：管理者、
	''' x：一般ユーザー、
	''' x：参照者、
	''' x：ホワイトラベル、
	''' o：ホワイトラベル（参照）、
	''' 2014/12 ADD
	''' </summary>
	''' <param name="UserType"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Shared Function IsWLReferrer(UserType As String) As Boolean
		Return UserType = UserTypeCode.WhiteLabelReferrer
	End Function

	''' <summary>
	''' x：管理者、
	''' x：一般ユーザー、
	''' x：参照者、
	''' o：ホワイトラベル、
	''' x：ホワイトラベル（参照）、
	''' </summary>
	''' <param name="UserType"></param>
	''' <returns></returns>
	''' <remarks></remarks>
	Public Shared Function IsWL(UserType As String) As Boolean
		Return UserType = UserTypeCode.WhiteLabel
	End Function

	Public Shared Function GetList() As List(Of UserTypeManager)
		Return List.ToList()
	End Function

	Public Property Code As String
	Public Property Name As String

End Class
