﻿Public Class CashTypeManager

    Public Shared List As New List(Of CashTypeManager)
    Private Shared ListWithAll As New List(Of CashTypeManager)

    Public Shared Sub Init()
        List.Add(New CashTypeManager With {.Code = "00", .Name = "口座開設"})
        List.Add(New CashTypeManager With {.Code = "01", .Name = "入金"})
        List.Add(New CashTypeManager With {.Code = "02", .Name = "出金"})
        List.Add(New CashTypeManager With {.Code = "03", .Name = "購入"})
        List.Add(New CashTypeManager With {.Code = "04", .Name = "ペイアウト(期限前)"})
        List.Add(New CashTypeManager With {.Code = "05", .Name = "ペイアウト(期日ITM)"})
        List.Add(New CashTypeManager With {.Code = "06", .Name = "ペイアウト(期日OTM)"})
        List.Add(New CashTypeManager With {.Code = "07", .Name = "ペイアウト(期日ATM)"})
        List.Add(New CashTypeManager With {.Code = "08", .Name = "キャンセル"})

        ListWithAll.Add(New CashTypeManager With {.Code = "", .Name = "全て"})
        ListWithAll.Add(New CashTypeManager With {.Code = "00", .Name = "口座開設"})
        ListWithAll.Add(New CashTypeManager With {.Code = "01", .Name = "入金"})
        ListWithAll.Add(New CashTypeManager With {.Code = "02", .Name = "出金"})
        ListWithAll.Add(New CashTypeManager With {.Code = "03", .Name = "購入"})
        ListWithAll.Add(New CashTypeManager With {.Code = "04", .Name = "ペイアウト(期限前)"})
        ListWithAll.Add(New CashTypeManager With {.Code = "05", .Name = "ペイアウト(期日ITM)"})
        ListWithAll.Add(New CashTypeManager With {.Code = "06", .Name = "ペイアウト(期日OTM)"})
        ListWithAll.Add(New CashTypeManager With {.Code = "07", .Name = "ペイアウト(期日ATM)"})
        ListWithAll.Add(New CashTypeManager With {.Code = "08", .Name = "キャンセル"})
    End Sub

    Public Shared Function GetList() As List(Of CashTypeManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of CashTypeManager)
        Return ListWithAll.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
