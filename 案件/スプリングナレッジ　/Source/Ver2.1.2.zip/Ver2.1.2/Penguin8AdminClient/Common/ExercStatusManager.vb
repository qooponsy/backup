﻿Public Class ExercStatusManager

    Private Shared List As New List(Of ExercStatusManager)
    Private Shared ListWithAll As New List(Of ExercStatusManager)

    Public Shared Sub Init()
        List.Add(New ExercStatusManager With {.Code = "0", .Name = "未行使"})
        List.Add(New ExercStatusManager With {.Code = "1", .Name = "行使処理中"})
        List.Add(New ExercStatusManager With {.Code = "2", .Name = "行使済み"})
        List.Add(New ExercStatusManager With {.Code = "3", .Name = "行使処理失敗"})

        ListWithAll.Add(New ExercStatusManager With {.Code = "0", .Name = "未行使"})
        ListWithAll.Add(New ExercStatusManager With {.Code = "1", .Name = "行使処理中"})
        ListWithAll.Add(New ExercStatusManager With {.Code = "2", .Name = "行使済み"})
        ListWithAll.Add(New ExercStatusManager With {.Code = "3", .Name = "行使処理失敗"})
        ListWithAll.Add(New ExercStatusManager With {.Code = "", .Name = "全て"})
    End Sub

    Public Shared Function GetList() As List(Of ExercStatusManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of ExercStatusManager)
        Return ListWithAll.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
