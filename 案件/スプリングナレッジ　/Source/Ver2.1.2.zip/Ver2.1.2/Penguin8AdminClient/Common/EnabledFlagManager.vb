﻿Public Class EnabledFlagManager

    Public Shared List As New List(Of EnabledFlagManager)

    Public Shared Sub Init()
        List.Add(New EnabledFlagManager With {.Code = "1", .Name = "有効"})
        List.Add(New EnabledFlagManager With {.Code = "0", .Name = "無効"})
    End Sub

    Public Shared Function GetList() As List(Of EnabledFlagManager)
        Return List.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
