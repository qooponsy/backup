﻿Public Class DateTypeManager

    Private Shared TradeList As New List(Of DateTypeManager)
    Private Shared CashList As New List(Of DateTypeManager)

    Public Shared Sub Init()
        TradeList.Add(New DateTypeManager With {.Code = "1", .Name = "取引日"})
        TradeList.Add(New DateTypeManager With {.Code = "2", .Name = "行使期日"})
        TradeList.Add(New DateTypeManager With {.Code = "3", .Name = "注文時間"})
        TradeList.Add(New DateTypeManager With {.Code = "4", .Name = "放棄時間"})
        TradeList.Add(New DateTypeManager With {.Code = "5", .Name = "約定時間"})
        TradeList.Add(New DateTypeManager With {.Code = "6", .Name = "行使処理時間"})

        CashList.Add(New DateTypeManager With {.Code = "1", .Name = "処理日時"})
        CashList.Add(New DateTypeManager With {.Code = "2", .Name = "取引日"})
    End Sub

    Public Shared Function GetTradeList() As List(Of DateTypeManager)
        Return TradeList.ToList()
    End Function

    Public Shared Function GetCashList() As List(Of DateTypeManager)
        Return CashList.ToList()
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
