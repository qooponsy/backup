﻿Public Class UserSettingsFlash

    'コンストラクタ
    Public Sub New()
    End Sub

    '初期化
    Public Sub Init()
    End Sub

End Class
