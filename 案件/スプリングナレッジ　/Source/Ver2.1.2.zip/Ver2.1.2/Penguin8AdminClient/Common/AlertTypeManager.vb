﻿Public Class AlertTypeManager

    Private Shared AlertTypeList As New List(Of AlertTypeManager)
    Private Shared AlertTypeListWithAll As New List(Of AlertTypeManager)

    Public Shared Sub Init()
        AlertTypeList.Add(New AlertTypeManager With {.Code = "01", .Name = "アラート損益"})
        AlertTypeList.Add(New AlertTypeManager With {.Code = "02", .Name = "アラート損益(顧客)"})

        AlertTypeListWithAll.Add(New AlertTypeManager With {.Code = "01", .Name = "アラート損益"})
        AlertTypeListWithAll.Add(New AlertTypeManager With {.Code = "02", .Name = "アラート損益(顧客)"})
        AlertTypeListWithAll.Add(New AlertTypeManager With {.Code = "", .Name = "全て"})
    End Sub

    Public Shared Function GetList() As List(Of AlertTypeManager)
        Return AlertTypeList.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of AlertTypeManager)
        Return AlertTypeListWithAll.ToList()
    End Function

    Public Shared Function GetAlertTypeName(AlertType As String) As String
        Dim ret As String = ""
        For Each item As AlertTypeManager In AlertTypeList
            If item.Code = AlertType Then
                ret = item.Name
            End If
        Next
        Return ret
    End Function

    Public Property Code As String
    Public Property Name As String
End Class
