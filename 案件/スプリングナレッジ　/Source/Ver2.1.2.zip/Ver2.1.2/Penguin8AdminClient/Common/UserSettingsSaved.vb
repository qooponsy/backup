﻿Imports System.Xml.Serialization
Imports System.Runtime.Serialization

<Serializable()> _
Public Class KeyValue
    Public Sub New()
    End Sub

    Public Sub New(ByVal _key As String, ByVal _value As Integer)
        key = _key
        Value = _value
    End Sub
    Public Key As String
    Public Value As Integer
End Class

<Serializable()> _
Public Class UserSettingsSaved

    'ウィンドウ
    <OptionalField()> Public MainWindow_FormMaximized As Boolean = False
    <OptionalField()> Public MainWindow_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public MainWindow_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public MainWindow_SubFormProductBase As Boolean = False
    <OptionalField()> Public MainWindow_SubFormProduct As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormExercRateHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormCust As Boolean = False
    <OptionalField()> Public MainWindow_SubFormTrade As Boolean = False
    <OptionalField()> Public MainWindow_SubFormCash As Boolean = False
    <OptionalField()> Public MainWindow_SubFormSysSettingsForm As Boolean = False
    <OptionalField()> Public MainWindow_SubFormSysControlForm As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRiskMonitor As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRiskSimulate As Boolean = False
    <OptionalField()> Public MainWindow_SubFormSalesPerformance As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateMonitor As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateChartHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormRateFilterLogList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormNowStatus As Boolean = False
    <OptionalField()> Public MainWindow_SubFormUser As Boolean = False
    <OptionalField()> Public MainWindow_SubFormOperationHist As Boolean = False
    <OptionalField()> Public MainWindow_SubFormOperationHistClient As Boolean = False
    <OptionalField()> Public MainWindow_SubFormFileDownloadList As Boolean = False
    <OptionalField()> Public MainWindow_SubFormAlertHistList As Boolean = False

    '銘柄設定一覧
    <OptionalField()> Public ProductBaseList_FormMaximized As Boolean = False
    <OptionalField()> Public ProductBaseList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ProductBaseList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ProductBaseList_Columns As New List(Of KeyValue)
    <OptionalField()> Public ProductBaseList_ComCode As String = ""
    <OptionalField()> Public ProductBaseList_OpType As String = ""
    <OptionalField()> Public ProductBaseList_Enabled As Boolean = True

    '銘柄一覧
    <OptionalField()> Public ProductList_FormMaximized As Boolean = False
    <OptionalField()> Public ProductList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ProductList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ProductList_Columns As New List(Of KeyValue)
    <OptionalField()> Public ProductList_CmpCode As String = ""
    <OptionalField()> Public ProductList_ComCode As String = ""
    <OptionalField()> Public ProductList_OpType As String = ""
    <OptionalField()> Public ProductList_ExercStatus As String = "0"
    <OptionalField()> Public ProductList_Enabled As Boolean = True

    'レート一覧
    <OptionalField()> Public RateHistList_FormMaximized As Boolean = False
    <OptionalField()> Public RateHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public RateHistList_ComCode As String = ""
    <OptionalField()> Public RateHistList_Enabled As Boolean = True

    '行使レート一覧
    <OptionalField()> Public ExercRateHistList_FormMaximized As Boolean = False
    <OptionalField()> Public ExercRateHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ExercRateHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ExercRateHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public ExercRateHistList_ComCode As String = ""
    <OptionalField()> Public ExercRateHistList_OpType As String = "01"
    <OptionalField()> Public ExercRateHistList_CustCode As String = ""

    '委託者一覧
    <OptionalField()> Public CustList_FormMaximized As Boolean = False
    <OptionalField()> Public CustList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public CustList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public CustList_Columns As New List(Of KeyValue)
    <OptionalField()> Public CustList_CmpCode As String = ""
    <OptionalField()> Public CustList_CurCode As String = ""
    <OptionalField()> Public CustList_EnableCust As Boolean = False
    <OptionalField()> Public CustList_StopCust As Boolean = False
    <OptionalField()> Public CustList_TestAccount As Boolean = False
    <OptionalField()> Public CustList_FromCustCode As String = ""
    <OptionalField()> Public CustList_ToCustCode As String = ""
    <OptionalField()> Public CustList_CountryCode As String = ""

    '取引データ一覧
    <OptionalField()> Public TradeList_FormMaximized As Boolean = False
    <OptionalField()> Public TradeList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public TradeList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public TradeList_Columns As New List(Of KeyValue)
    <OptionalField()> Public TradeList_CmpCode As String = ""
    <OptionalField()> Public TradeList_CurCode As String = ""
    <OptionalField()> Public TradeList_ListType As String = "1"
    <OptionalField()> Public TradeList_ComCode As String = ""
    <OptionalField()> Public TradeList_OpType As String = ""
    <OptionalField()> Public TradeList_TradeType As String = ""
    <OptionalField()> Public TradeList_TradeStatus As String = ""
    <OptionalField()> Public TradeList_DateType As String = "0"
    <OptionalField()> Public TradeList_ProductCode As String = ""
    <OptionalField()> Public TradeList_CustCode As String = ""
    <OptionalField()> Public TradeList_CountryCode As String = ""

    '残高データ一覧
    <OptionalField()> Public CashList_FormMaximized As Boolean = False
    <OptionalField()> Public CashList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public CashList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public CashList_Columns As New List(Of KeyValue)
    <OptionalField()> Public CashList_CmpCode As String = ""
    <OptionalField()> Public CashList_CurCode As String = ""
    <OptionalField()> Public CashList_CashType As String = ""
    <OptionalField()> Public CashList_DateType As String = "0"
    <OptionalField()> Public CashList_CustCode As String = ""

    'システム設定
    <OptionalField()> Public SysSettingsForm_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    'システム制御
    <OptionalField()> Public SysControlForm_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    'リスクモニタ
    <OptionalField()> Public RiskMonitor_FormMaximized As Boolean = False
    <OptionalField()> Public RiskMonitor_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RiskMonitor_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RiskMonitor_SplitterDistance As Integer = 0
    <OptionalField()> Public RiskMonitor_SumColumns As New List(Of KeyValue)
    <OptionalField()> Public RiskMonitor_DetailColumns As New List(Of KeyValue)
    <OptionalField()> Public RiskMonitor_CmpCode As String = ""
    <OptionalField()> Public RiskMonitor_CurCode As String = "USD"

    'リスクシミュレーション
    <OptionalField()> Public RiskSimulate_FormMaximized As Boolean = False
    <OptionalField()> Public RiskSimulate_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RiskSimulate_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RiskSimulate_SplitterDistance As Integer = 0
    <OptionalField()> Public RiskSimulate_Columns As New List(Of KeyValue)
    <OptionalField()> Public RiskSimulate_ComCode As String = "USDJPY"
    <OptionalField()> Public RiskSimulate_OpType As String = "01"
    <OptionalField()> Public RiskSimulate_CurCode As String = "USD"
    <OptionalField()> Public RiskSimulate_CmpCode As String = ""
    <OptionalField()> Public RiskSimulate_AutoReCalc As Boolean = False

    '営業実績表
    <OptionalField()> Public SalesPerformanceList_FormMaximized As Boolean = False
    <OptionalField()> Public SalesPerformanceList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public SalesPerformanceList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public SalesPerformanceList_Columns As New List(Of KeyValue)
    <OptionalField()> Public SalesPerformanceList_CmpCode As String = ""
    <OptionalField()> Public SalesPerformanceList_CurCode As String = ""

    'レートフィルターログ
    <OptionalField()> Public RateFilterLogList_FormMaximized As Boolean = False
    <OptionalField()> Public RateFilterLogList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateFilterLogList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateFilterLogList_Columns As New List(Of KeyValue)
    <OptionalField()> Public RateFilterLogList_DataType As String = "0"
    <OptionalField()> Public RateFilterLogList_ComCode As String = ""
    <OptionalField()> Public RateFilterLogList_CurCode As String = ""
    <OptionalField()> Public RateFilterLogList_LogType As String = ""

    'レートモニター
    <OptionalField()> Public RateMonitor_FormMaximized As Boolean = False
    <OptionalField()> Public RateMonitor_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateMonitor_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateMonitorList_Columns As New List(Of KeyValue)

    'レートチャート一覧
    <OptionalField()> Public RateChartHistList_FormMaximized As Boolean = False
    <OptionalField()> Public RateChartHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public RateChartHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public RateChartHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public RateChartHistList_ComCode As String = ""
    <OptionalField()> Public RateChartHistList_Enabled As Boolean = True
    <OptionalField()> Public RateChartHistList_ChartType As String = ""

    'レートログアラート
    <OptionalField()> Public RateLogAlert_RateFilterSettings As Boolean = False
    <OptionalField()> Public RateLogAlert_RateFilter As Boolean = False
    <OptionalField()> Public RateLogAlert_RateFilterCounterClear As Boolean = False
    <OptionalField()> Public RateLogAlert_RateChanged As Boolean = False
    <OptionalField()> Public RateLogAlert_AnomalyRate As Boolean = False
    <OptionalField()> Public RateLogAlert_AnomalyRateClear As Boolean = False
    <OptionalField()> Public RateLogAlert_RateTimeDiff As Boolean = False
    <OptionalField()> Public RateLogAlert_RateTimeDiffClear As Boolean = False

    '稼働ステータス
    <OptionalField()> Public NowStatusForm_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public NowStatusForm_CmpCode As String = ""

    'ユーザー一覧
    <OptionalField()> Public UserList_FormMaximized As Boolean = False
    <OptionalField()> Public UserList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public UserList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public UserList_Columns As New List(Of KeyValue)
    <OptionalField()> Public UserList_CmpCode As String = ""
    <OptionalField()> Public UserList_Enabled As Boolean = True

    '管理者操作ログ
    <OptionalField()> Public OperationHistList_FormMaximized As Boolean = False
    <OptionalField()> Public OperationHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public OperationHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public OperationHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public OperationHistList_UserName As String = ""
    <OptionalField()> Public OperationHistList_DataType As Integer = 0
    <OptionalField()> Public OperationHistList_Code As String = ""

    '委託者操作ログ
    <OptionalField()> Public OperationHistClientList_FormMaximized As Boolean = False
    <OptionalField()> Public OperationHistClientList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public OperationHistClientList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public OperationHistClientList_Columns As New List(Of KeyValue)
    <OptionalField()> Public OperationHistClientList_CustCode As String = ""
    <OptionalField()> Public OperationHistClientList_DataType As Integer = 0
    <OptionalField()> Public OperationHistClientList_Code As String = ""

    'ファイルダウンロード
    <OptionalField()> Public FileDownloadList_FormMaximized As Boolean = False
    <OptionalField()> Public FileDownloadList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public FileDownloadList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public FileDownloadList_Columns As New List(Of KeyValue)
    <OptionalField()> Public FileDownloadList_CmpCode As String = ""
    <OptionalField()> Public FileDownloadList_FileType As Integer = 0

    '報告書データ
    <OptionalField()> Public ReportDownload_FormMaximized As Boolean = False
    <OptionalField()> Public ReportDownload_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public ReportDownload_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public ReportDownload_CmpCode As String = "0002"

    '取引口座集計
    <OptionalField()> Public TradeAccountSummaryDownload_FormMaximized As Boolean = False
    <OptionalField()> Public TradeAccountSummaryDownload_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public TradeAccountSummaryDownload_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public TradeAccountSummaryDownload_CmpCode As String = "0002"

    'アラートログ
    <OptionalField()> Public AlertHistList_FormMaximized As Boolean = False
    <OptionalField()> Public AlertHistList_FormSize As Size = New Size(Integer.MinValue, Integer.MinValue)
    <OptionalField()> Public AlertHistList_FormLocation As Point = New Point(Integer.MinValue, Integer.MinValue)

    <OptionalField()> Public AlertHistList_Columns As New List(Of KeyValue)
    <OptionalField()> Public AlertHistList_CmpCode As String = ""
    <OptionalField()> Public AlertHistList_AlertType As String = ""
    <OptionalField()> Public AlertHistList_Code As String = ""

End Class
