﻿Public Class OptionTypeManager

    Public Class OpType
        Public Const Binary As String = "01"
        Public Const AnyTime As String = "02"
    End Class

    Public Shared List As New List(Of OptionTypeManager)
    Private Shared ListWithAll As New List(Of OptionTypeManager)

    Public Shared Sub Init()
        List.Add(New OptionTypeManager With {.Code = OpType.Binary, .Name = "バイナリー"})
        List.Add(New OptionTypeManager With {.Code = OpType.AnyTime, .Name = "AnyTime"})

        ListWithAll.Add(New OptionTypeManager With {.Code = OpType.Binary, .Name = "バイナリー"})
        ListWithAll.Add(New OptionTypeManager With {.Code = OpType.AnyTime, .Name = "AnyTime"})
        ListWithAll.Add(New OptionTypeManager With {.Code = "", .Name = "全て"})
    End Sub

    Public Shared Function GetList() As List(Of OptionTypeManager)
        Return List.ToList()
    End Function

    Public Shared Function GetListWithAll() As List(Of OptionTypeManager)
        Return ListWithAll.ToList()
    End Function

    Public Shared Function GetOptionTypeName(OptionTypeCode As String) As String
        Dim ret As String = ""
        For Each item As OptionTypeManager In List
            If item.Code = OptionTypeCode Then
                ret = item.Name
            End If
        Next
        Return ret
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
