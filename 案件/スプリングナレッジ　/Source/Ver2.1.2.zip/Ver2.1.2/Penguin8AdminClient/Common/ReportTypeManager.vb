﻿Public Class ReportTypeManager

    Public Class ReportType
        Public Const MB4_7 As String = "01"
        Public Const MB4_8 As String = "02"
    End Class

    Public Shared List As New List(Of ReportTypeManager)

    Public Shared Sub Init()
        List.Add(New ReportTypeManager With {.Code = ReportType.MB4_7, .Name = "MB4_7"})
        List.Add(New ReportTypeManager With {.Code = ReportType.MB4_8, .Name = "MB4_8"})
    End Sub

    Public Shared Function GetReportTypeName(Code As String) As String
        Dim ret As String = ""
        For Each item As ReportTypeManager In List
            If item.Code = Code Then
                ret = item.Name
            End If
        Next
        Return ret
    End Function

    Public Property Code As String
    Public Property Name As String

End Class
