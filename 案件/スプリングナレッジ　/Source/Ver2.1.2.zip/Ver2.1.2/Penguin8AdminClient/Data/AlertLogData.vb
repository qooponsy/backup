﻿Public Class AlertLogData
    Public LogID As Integer
    Public LogTime As DateTime
    Public AlertType As String
    Public CmpCode As String
    Public Code As String
    Public LogText As String

    Public ReadOnly Property GetAlertType() As String
        Get
            Dim ret As String = ""
            Select Case AlertType
                Case "01"
                    ret = "アラート損益"
                    Exit Select
                Case "02"
                    ret = "アラート損益(顧客)"
                    Exit Select
            End Select

            Return ret
        End Get
    End Property
End Class
