﻿Public Class OperationHistData

    Public LogTime As DateTime '操作日時
    Public SysDate As Date     'システム日時
    Public OperationUser As String    '操作ユーザ
    Public DataType As String  'データタイプ
    Public LogType As String   'ログタイプ
    Public Code As String      'コード
    Public LogText As String   'ログ

    Public ReadOnly Property GetDataType() As String
        Get
            Dim ret As String = ""
            Select Case DataType
                Case "01"
                    ret = "システム設定"
                    Exit Select
                Case "02"
                    ret = "銘柄データ"
                    Exit Select
                Case "03"
                    ret = "銘柄設定"
                    Exit Select
                Case "04"
                    ret = "計算パラメータ"
                    Exit Select
                Case "05"
                    ret = "ログイン"
                    Exit Select
                Case "06"
                    ret = "ログアウト"
                    Exit Select
                Case "07"
                    ret = "パスワード変更"
                    Exit Select
                Case "08"
                    ret = "強制パスワード変更"
                    Exit Select
                Case "09"
                    ret = "ユーザー管理"
                    Exit Select
                Case "10"
                    ret = "委託者"
                    Exit Select
            End Select

            Return ret
        End Get
    End Property

    Public ReadOnly Property GetLogType() As String
        Get
            Dim ret As String = ""
            Select Case LogType
                Case "01"
                    ret = "新規"
                    Exit Select
                Case "02"
                    ret = "更新"
                    Exit Select
                Case "03"
                    ret = "有効"
                    Exit Select
                Case "04"
                    ret = "無効"
                    Exit Select
                Case "05"
                    ret = "一括更新"
                Case "06"
                    ret = "成功"
                Case "07"
                    ret = "失敗"
            End Select

            Return ret
        End Get
    End Property

End Class
