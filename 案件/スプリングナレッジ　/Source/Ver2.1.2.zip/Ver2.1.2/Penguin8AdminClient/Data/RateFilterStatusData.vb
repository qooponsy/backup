﻿Public Class RateFilterStatusData
    Public ComCode As String
    Public Status As String
    Public RateFilterCounter As Integer
    Public LastFilteringRateEnabled As Boolean
    Public LastFilteringRate As Decimal
    Public LastFilteringTimeEnabled As Boolean
    Public LastFilteringTime As DateTime
    Public LastAnomalyRateEnabled As Boolean
    Public LastAnomalyRate As Decimal
    Public LastAnomalyTimeEnabled As Boolean
    Public LastAnomalyTime As DateTime

    Public Function IsMatch(item As RateFilterStatusData) As Boolean
        If ComCode <> item.ComCode Then Return False
        If Status <> item.Status Then Return False
        If RateFilterCounter <> item.RateFilterCounter Then Return False
        If LastFilteringRateEnabled <> item.LastFilteringRateEnabled Then Return False
        If LastFilteringRateEnabled AndAlso LastFilteringRate <> item.LastFilteringRate Then Return False
        If LastFilteringTimeEnabled <> item.LastFilteringTimeEnabled Then Return False
        If LastFilteringTimeEnabled AndAlso LastFilteringTime <> item.LastFilteringTime Then Return False
        If LastAnomalyRateEnabled <> item.LastAnomalyRateEnabled Then Return False
        If LastAnomalyRateEnabled AndAlso LastAnomalyRate <> item.LastAnomalyRate Then Return False
        If LastAnomalyTimeEnabled <> item.LastAnomalyTimeEnabled Then Return False
        If LastAnomalyTimeEnabled AndAlso LastAnomalyTime <> item.LastAnomalyTime Then Return False
        Return True
    End Function

End Class
