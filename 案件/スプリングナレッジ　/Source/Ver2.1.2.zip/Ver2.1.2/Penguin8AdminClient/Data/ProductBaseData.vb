﻿Public Class ProductBaseData

    Public Class EnabledCode
        Public Const Enabled As String = "1"
        Public Const Visible As String = "0"
    End Class

    Public ProductBaseCode As String            '銘柄設定コード
    Public ComCode As String                    '通貨ペア
    Public OpType As String                     'オプション種別
    Public OptionTime As Integer                'オプション期間
    Public CreateTime As Integer                '生成間隔
    Public StartTime As TimeSpan                '生成開始時間
    Public StartSummerTime As TimeSpan          '生成開始時間（夏時間）
    Public ExercTime As TimeSpan                '最終行使期日
    Public ExercSummerTime As TimeSpan          '最終行使期日（夏時間）
    Public PayoutRate As Decimal                'ペイアウト率
    Public Spread As Integer                    'スプレッド
    Public StopTradeTime As Integer             '取引停止時間
    Public StartAbandTime As Integer            '権利放棄可能時間
    Public AbandPriceDiff As Integer            '権利放棄可能価格差
    Public AbandMargine As Decimal              '権利放棄手数料
    Public VolatilityAdjust As Decimal          'ボラティリティレシオ
    Public ProductBaseEnabled As String         '有効フラグ
    Public SpreadUpdateEnabled As Boolean       '変更スプレッド
    Public SpreadUpdate As Integer              '変更スプレッド
    Public TradeMoneyMin As Decimal             '最小取引額(1回)銘柄
    Public TradeMoneyMax As Decimal             '最大取引額(1回)銘柄
    Public TradeMoneyMinUpdateEnabled As String '変更最小取引額
    Public TradeMoneyMinUpdate As Integer       '変更最小取引額
    Public TradeMoneyMaxUpdateEnabled As String '変更最大取引額
    Public TradeMoneyMaxUpdate As Integer       '変更最大取引額

    Public Shared Function cnvOpType(ByVal OpType As String) As String
        Dim ret As String = ""
        Select Case OpType
            Case "01" : ret = "バイナリ"
            Case Else
        End Select

        Return ret
    End Function

    Public Function EnabledName() As String
        Dim ret As String = ""
        Select Case Me.ProductBaseEnabled
            Case EnabledCode.Enabled : ret = "有効"
            Case Else
        End Select

        Return ret
    End Function

End Class
