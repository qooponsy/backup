﻿Public Class ChartTypeData
    Public Property ChartType As String
    Public Property ChartTypeName As String

    Public Function IsMatch(item As ChartTypeData)
        If ChartType <> ChartType Then Return False
        If ChartTypeName <> ChartTypeName Then Return False

        Return True
    End Function
End Class
