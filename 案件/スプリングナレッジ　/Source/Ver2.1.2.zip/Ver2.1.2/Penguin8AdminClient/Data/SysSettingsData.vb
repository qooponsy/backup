﻿Public Class SysSettingsData

    Public Commission As Decimal
    Public TradeMoneyMin As Decimal
    Public TradeMoneyMax As Decimal
    Public ProductMoneyMax As Decimal
    Public CustCountMax As Integer
    Public CustMoneyMax As Decimal
    Public CustMoneyDayMax As Decimal
    Public CustProductMoneyMax As Decimal
    Public CashInMoneyMin As Decimal
    Public CashInMoneyDayMin As Decimal
    Public CashOutMoneyMax As Decimal
    Public CashOutMoneyDayMax As Decimal
    Public ProductStartPreTime As Integer
    Public ProductEndLossTime As Integer
    Public RateEnableTime As Integer
    Public TimeZone As Integer
    Public SysDateTimeZone As Integer
    Public AlertDayPAndL As Decimal
    Public AlertDayPAndLCust As Decimal

    Public Function IsMatch(item As SysSettingsData) As Boolean
        If Commission <> item.Commission Then Return False
        If TradeMoneyMin <> item.TradeMoneyMin Then Return False
        If TradeMoneyMax <> item.TradeMoneyMax Then Return False
        If ProductMoneyMax <> item.ProductMoneyMax Then Return False
        If CustCountMax <> item.CustCountMax Then Return False
        If CustMoneyMax <> item.CustMoneyMax Then Return False
        If CustMoneyDayMax <> item.CustMoneyDayMax Then Return False
        If CustProductMoneyMax <> item.CustProductMoneyMax Then Return False
        If CashInMoneyMin <> item.CashInMoneyMin Then Return False
        If CashInMoneyDayMin <> item.CashInMoneyDayMin Then Return False
        If CashOutMoneyMax <> item.CashOutMoneyMax Then Return False
        If CashOutMoneyDayMax <> item.CashOutMoneyDayMax Then Return False
        If ProductStartPreTime <> item.ProductStartPreTime Then Return False
        If ProductEndLossTime <> item.ProductEndLossTime Then Return False
        If RateEnableTime <> item.RateEnableTime Then Return False
        If AlertDayPAndL <> item.AlertDayPAndL Then Return False
        If AlertDayPAndLCust <> item.AlertDayPAndLCust Then Return False
        Return True
    End Function

End Class
