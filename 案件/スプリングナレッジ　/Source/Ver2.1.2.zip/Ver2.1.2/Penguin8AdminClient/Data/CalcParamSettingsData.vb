﻿Public Class CalcParamSettingsData
    Public ComCode As String            '通貨ペアコード
    Public InterestRate As Decimal      '短期金利
    Public SwapRate As Decimal          'スワップ金利
    Public VolatilityAdjust As Decimal  'ボラティリティレシオ
End Class
