﻿Public Class CustData

    Public Property CmpCode As String
    Public Property CustCode As String
    Public Property RegTime As DateTime
    Public Property CurCode As String
    Public Property CurName As String
    Public Property TotalMoney As Decimal
    Public Property DealDisabled As String
    Public Property CashDisabled As String
    Public Property TestAccount As String
    Public Property CountryCode As String

    Public ReadOnly Property CountryTypeName()
        Get
            For Each item As CountryTypeManager In CountryTypeManager.List
                If item.Code = CountryCode Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property
End Class
