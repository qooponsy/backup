﻿Public Class SysStatusData
    Public SysDate As Date                  'システム営業日
    Public SysEnabled As String             '稼働ステータス
    Public AbandEnabled As String           '放棄処理ステータス
    Public CashOutEnabled As String         '出金振替ステータス
    Public CashInEnabled As String          '入金振替ステータス
    Public RateProviderID As Integer        '採用レートプロバイダーID

    Public Function IsMatch(item As SysStatusData) As Boolean
        If SysDate <> item.SysDate Then Return False
        If SysEnabled <> item.SysEnabled Then Return False
        If AbandEnabled <> item.AbandEnabled Then Return False
        If CashOutEnabled <> item.CashOutEnabled Then Return False
        If CashInEnabled <> item.CashInEnabled Then Return False
        If RateProviderID <> item.RateProviderID Then Return False
        Return True
    End Function

End Class