﻿Public Class TradeRiskData

    Public TradeSeq As String = ""
    Public ProductCode As String = ""
    Public ComCode As String = ""
    Public ExercTime As DateTime
    Public PayoutRate As Decimal = 0
    Public Rate As Decimal = 0
    Public RateArrowCount As Integer = 0
    Public PAndL As Decimal = 0
    Public Premium As Decimal = 0
    Public Delta As Decimal = 0
    Public GammaU As Decimal = 0
    Public GammaD As Decimal = 0
    Public Vega As Decimal = 0
    Public Theta As Decimal = 0
    Public Rho As Decimal = 0
    Public Count As Integer = 0

    Public sr As Decimal = 0
    Public SwapRate As Decimal = 0
    Public VolatilityAdjust As Decimal = 0
    Public sigma As Decimal = 0
    Public DeltaVariation As Decimal = 0
    Public GammaVariation As Decimal = 0
    Public VegaVariation As Decimal = 0
    Public ThetaVariation As Decimal = 0
    Public RhoVariation As Decimal = 0

    Public ExcgComCode As String = ""
    Public ExcgRate As Decimal = 0

    Public OpType As String = ""
    Public OptionTime As Integer = 0

End Class
