﻿Public Class UserData

    Public Class EnabledCode
        Public Const Enabled As String = "1"
        Public Const Visible As String = "0"
    End Class

    Public UserID As String
    Public Enabled As String
    Public UserName As String
    Public UserType As String
    Public CmpCode As String
    Public LastAuthTimeEnabled As Boolean
    Public LastAuthTime As DateTime
    Public InsTime As DateTime
    Public InsUser As String
    Public UpdTime As DateTime
    Public UpdUser As String
    Public AccountLock As String
    Public PasswordUpdTime As DateTime
    Public NowDateTime As DateTime

    Public Function EnabledName() As String
        Dim ret As String = ""
        Select Case Me.Enabled
            Case EnabledCode.Enabled : ret = "有効"
            Case Else
        End Select

        Return ret
    End Function

    Public ReadOnly Property UserTypeName()
        Get
            For Each item As UserTypeManager In UserTypeManager.List
                If item.Code = UserType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

    Public ReadOnly Property AccountLockName()
        Get
            For Each item As AccountLockFlagManager In AccountLockFlagManager.List
                If item.Code = AccountLock Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
