﻿Public Class RateHistData

    Public RateSeq As String    'レートSeq
    Public RateTime As DateTime     'レート時間
    Public RateTimeSource As DateTime   'レート時間(ソース)
    Public ComCode As String    '通貨ペアコード
    Public Rate As Decimal      'レート
    Public Exerc As String      '行使フラグ
    Public ExercTimeEnabled As Boolean    '行使期日フラグ
    Public ExercTime As DateTime    '行使期日
    Public Enabled As String    '有効フラグ
    Public ViewSeq As String    '表示採番Seq
    Public CustCode As String   '委託者コード

    Public ReadOnly Property EnabledName() As String
        Get
            Return IIf(Enabled = "1", "有効", "無効")
        End Get
    End Property

End Class
