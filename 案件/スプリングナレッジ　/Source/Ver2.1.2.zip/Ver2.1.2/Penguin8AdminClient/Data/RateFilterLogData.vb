﻿Public Class RateFilterLogData
    Public LogID As Integer
    Public LogTime As DateTime
    Public ComCode As String
    Public LogType As String
    Public LogText As String

    Public ReadOnly Property LogTypeName()
        Get
            For Each item As RateFilterLogTypeManager In RateFilterLogTypeManager.GetLogTypeList
                If item.Code = LogType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
