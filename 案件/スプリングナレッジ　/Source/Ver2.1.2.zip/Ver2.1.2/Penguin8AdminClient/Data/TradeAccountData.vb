﻿Public Class TradeAccountData
    Public Property CustCode As String
    Public Property RegTime As DateTime
    Public Property CurName As String
    Public Property TotalMoney As Decimal
    Public Property Email As String
    Public Property Country As String
    Public Property Group As String
    Public Property Test As String = TestFlag.Disable

    Public Enum TestFlag
        Enable = 0
        Disable = 1
    End Enum

    Public Sub SetTestEnable()
        Test = TestFlag.Enable
    End Sub

End Class
