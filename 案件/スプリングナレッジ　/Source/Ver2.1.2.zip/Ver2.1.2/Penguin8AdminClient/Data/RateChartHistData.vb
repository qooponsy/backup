﻿Public Class RateChartHistData
    Public RateChartSeq As String   'レートチャートSeq
    Public gEnabled As String    '有効フラグ
    Public ComCode As String    '通貨ペアコード
    Public ChartType As String  'チャート種別
    Public RateSeq As String    'レートSeq
    Public RateChartTime As DateTime     'レートチャート日時
    Public OpenRate As Decimal      '開始レート
    Public HighRate As Decimal      '最高レート
    Public LowRate As Decimal      '最低レート
    Public CloseRate As Decimal      '終了レート
    Public CloseTime As DateTime   '終了日時

    Public ReadOnly Property EnabledName() As String
        Get
            Return IIf(gEnabled = "1", "有効", "無効")
        End Get
    End Property

End Class
