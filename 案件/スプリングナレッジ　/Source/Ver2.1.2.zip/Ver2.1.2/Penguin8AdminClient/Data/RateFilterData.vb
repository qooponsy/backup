﻿Public Class RateFilterData
    Public ComCode As String
    Public RateFilterDiff As Decimal
    Public RateFilterCountMax As Integer
    Public AnomalyRateDiff As Decimal

    Public Function IsMatch(item As RateFilterData) As Boolean
        If ComCode <> item.ComCode Then Return False
        If RateFilterDiff <> item.RateFilterDiff Then Return False
        If RateFilterCountMax <> item.RateFilterCountMax Then Return False
        If AnomalyRateDiff <> item.AnomalyRateDiff Then Return False
        Return True
    End Function

End Class
