﻿Public Class OperationHistClientData

    Public LogTime As DateTime '操作日時
    Public SysDate As Date     'システム日時
    Public CmpCode As String   '会社コード
    Public CustCode As String  '委託者コード
    Public DataType As String  'データタイプ
    Public LogType As String   'ログタイプ
    Public Code As String      'コード
    Public LogText As String   'ログ

    Public ReadOnly Property GetDataType() As String
        Get
            Dim ret As String = ""
            Select Case DataType
                Case "01"
                    ret = "ログイン"
                    Exit Select
                Case "02"
                    ret = "ログアウト"
                    Exit Select
            End Select

            Return ret
        End Get
    End Property

    Public ReadOnly Property GetLogType() As String
        Get
            Dim ret As String = ""
            Select Case LogType
                Case "01"
                    ret = "成功"
                Case "02"
                    ret = "失敗"
            End Select

            Return ret
        End Get
    End Property

End Class
