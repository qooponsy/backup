﻿Public Class ProductData

    Public Class PAndLSummary
        Public PAndL As Decimal
        Public Premium As Decimal
    End Class

    Public Property ProductCode As String        '銘柄コード
    Public ProductEnabled As String     '有効フラグ
    Public ProductBaseCode As String    '銘柄設定コード
    Public SysDateEnabled As Boolean    'システム営業日フラグ
    Public SysDate As DateTime          'システム営業日
    Public ComCode As String            '通貨ペア
    Public OpType As String             'オプション種別
    Public OptionTime As Integer        'オプション期間
    Public StartTime As DateTime        '取引開始時間
    Public ExercTime As DateTime        '行使期日
    Public TradeLimitTimeEnabled As Boolean   '取引可能期日有効フラグ
    Public TradeLimitTime As DateTime   '取引可能期日
    Public PayoutRate As Decimal        'ペイアウト率
    Public Spread As Integer            'スプレッド
    Public StopTradeTime As Integer?    '取引停止時間
    Public StartAbandTime As Integer?   '権利放棄可能時間
    Public AbandPriceDiff As Integer?   '権利放棄可能価格差
    Public AbandMargine As Decimal?     '権利放棄手数料
    Public VolatilityAdjust As Decimal? 'ボラティリティレシオ
    Public Volatility As Decimal?       'ボラティリティレシオ
    Public TradeMoneyMin As Decimal?    '最小取引額(1回)銘柄
    Public TradeMoneyMax As Decimal?    '最大取引額(1回)銘柄
    Public ExercStatus As String        '行使フラグ
    Public ExercRateSeq As String       '行使時レートSeq
    Public ExercRateEnabled As Boolean  '行使時レート有効フラグ
    Public ExercRate As Decimal         '行使時レート
    Public PAndL As Dictionary(Of String, PAndLSummary)      '損益(通貨別リスト)

    ''' <summary>[T_RateHistTick]からレートを取得するらしいが、とりあえず0.0を戻すだけ</summary>
    Public Shared Function getRate() As Decimal
        Dim ret As Decimal = 0.0

        Return ret
    End Function

    'T_RateHistTickの日付を利用するが、とりあえずNowで作成
    ''' <summary>「hhhh時間mm分ss秒」形式で残存期間文字列の作成</summary>
    Public Shared Function getResidualTime(ByVal DateDiffSecond As Long) As String
        Dim ret As String = ""

        Dim secondLong As Long = 0
        Dim minutesLong As Long = 0
        Dim hourLong As Long = 0

        If DateDiffSecond > 0 Then
            '秒の算出
            secondLong = DateDiffSecond Mod (60 * 60)   '時の除去
            secondLong = secondLong Mod 60              '分の除去

            '分の算出
            minutesLong = DateDiffSecond - secondLong   '秒の除去
            minutesLong = minutesLong Mod (60 * 60)     '時の除去
            minutesLong = minutesLong / 60              '分の算出

            '時の算出
            hourLong = DateDiffSecond - secondLong - (minutesLong * 60) '分・秒の除去
            hourLong = hourLong / (60 * 60)                             '時の算出
        End If

        ret = Right(Space(4) & CStr(hourLong), 4) & "時間" & Right("00" & CStr(minutesLong), 2) & "分" & Right("00" & CStr(secondLong), 2) & "秒"

        Return ret
    End Function

    Public ReadOnly Property ProductEnabledName() As String
        Get
            Return IIf(ProductEnabled = "1", "有効", "無効")
        End Get
    End Property

    Public ReadOnly Property OpTypeName() As String
        Get
            Dim ret As String = ""
            Select Case OpType
                Case "01" : ret = "バイナリ"
                Case "02" : ret = "AnyTime"
                Case Else
            End Select
            Return ret
        End Get
    End Property

    Public ReadOnly Property ExercStatusName() As String
        Get
            Dim ret As String = ""
            Select Case ExercStatus
                Case "0" : ret = "未行使"
                Case "1" : ret = "行使処理中"
                Case "2" : ret = "行使済み"
                Case "3" : ret = "行使処理失敗"
                Case Else
            End Select
            Return ret
        End Get
    End Property

    Public ReadOnly Property ExercTimeDisp() As String
        Get
            Return String.Format("{0:HH:mm} - {1:HH:mm} ({2:hh\:mm}) Payout {3:######0.########}", StartTime, ExercTime, ExercTime - StartTime, PayoutRate)
        End Get
    End Property

End Class
