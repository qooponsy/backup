﻿Public Class CurrencyData
    Public Property CurCode As String
    Public Property CurName As String
    Public Property DecimalPlaces As Integer
    Public Property SortOrder As Integer

    Public Function IsMatch(item As CurrencyData)
        If CurCode <> item.CurCode Then Return False
        If CurName <> item.CurName Then Return False
        If DecimalPlaces <> item.DecimalPlaces Then Return False
        If SortOrder <> item.SortOrder Then Return False

        Return True
    End Function

End Class
