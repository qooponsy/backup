﻿Public Class FileTypeData
    Public Property FileType As String
    Public Property FileTypeName As String

    Public Function IsMatch(item As FileTypeData) As Boolean
        If FileType <> item.FileType Then Return False
        If FileTypeName <> item.FileTypeName Then Return False
        Return True
    End Function

End Class
