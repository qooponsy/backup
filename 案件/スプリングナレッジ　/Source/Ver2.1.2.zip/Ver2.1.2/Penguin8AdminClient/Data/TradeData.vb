﻿Public Class TradeData
    Public TradeSeq As String
    Public SysDate As DateTime
    Public ProductCode As String
    Public ComCode As String
    Public OpType As String
    Public OptionTime As Integer
    Public PayoutRate As Decimal
    Public Spread As Integer
    Public StartAbandTime As Integer
    Public AbandPriceDiff As Integer
    Public AbandMargine As Decimal
    Public Volatility As Decimal
    Public CurCode As String
    Public CurName As String
    Public TradeType As String
    Public Premium As Decimal
    Public Commission As Decimal
    Public CustCode As String
    Public CmpCode As String
    Public TradeStatus As String
    Public OrderReqTimeEnabled As Boolean
    Public OrderReqTime As DateTime
    Public OrderClientRateSeq As String
    Public OrderClientRateTimeEnabled As Boolean
    Public OrderClientRateTime As DateTime
    Public OrderClientRateEnabled As Boolean
    Public OrderClientRate As Decimal
    Public AbandReqTimeEnabled As Boolean
    Public AbandReqTime As DateTime
    Public AbandClientRateSeq As String
    Public AbandClientRateTimeEnabled As Boolean
    Public AbandClientRateTime As DateTime
    Public AbandClientRateEnabled As Boolean
    Public AbandClientRate As Decimal
    Public TradeTimeEnabled As Boolean
    Public TradeTime As DateTime
    Public TradeRateSeq As String
    Public TradeRateTimeEnabled As Boolean
    Public TradeRateTime As DateTime
    Public TradeRateEnabled As Boolean
    Public TradeRate As Decimal
    Public ExercPriceEnabled As Boolean
    Public ExercPrice As Decimal
    Public ExercTimeEnabled As Boolean
    Public ExercTime As DateTime
    Public ExercProcTimeEnabled As Boolean
    Public ExercProcTime As DateTime
    Public ExercRateSeq As String
    Public ExercRateTimeEnabled As Boolean
    Public ExercRateTime As DateTime
    Public ExercRateTimeSourceEnabled As Boolean
    Public ExercRateTimeSource As DateTime
    Public ExercRateEnabled As Boolean
    Public ExercRate As Decimal
    Public ExercPayoutRateEnabled As Boolean
    Public ExercPayoutRate As Decimal
    Public ExercStatus As String
    Public ViewSeq As String
    Public TradeLimitTime As DateTime
    Public PayoutEnabled As Boolean
    Public Payout As Decimal
    Public PAndLEnabled As Decimal
    Public PAndL As Decimal
    Public Memo As String
    Public InfoTitle As String
    Public Info As String
    Public CountryCode As String
    'Public AbandMargine As Decimal?
    'Public Volatility As Decimal?

    Public ReadOnly Property TradeTypeName()
        Get
            For Each item As TradeTypeManager In TradeTypeManager.list
                If item.Code = TradeType Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

    Public ReadOnly Property TradeStatusName()
        Get
            For Each item As TradeStatusManager In TradeStatusManager.List
                If item.Code = TradeStatus Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

    Public ReadOnly Property CountryTypeName()
        Get
            For Each item As CountryTypeManager In CountryTypeManager.List
                If item.Code = CountryCode Then
                    Return item.Name
                End If
            Next
            Return ""
        End Get
    End Property

End Class
