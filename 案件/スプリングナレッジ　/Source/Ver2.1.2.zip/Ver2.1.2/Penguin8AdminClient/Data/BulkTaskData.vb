﻿Public Class BulkTaskData

    Public TaskSeq As String
    Public TaskStatus As String
    Public TaskType As String
    Public TaskParam As String
    Public LastStep As Integer
    Public ExecStep As Integer
    Public ExecStartTimeEnabled As Boolean
    Public ExecStartTime As DateTime
    Public ExecEndTimeEnabled As Boolean
    Public ExecEndTime As DateTime
    Public TaskResult As String

End Class
