﻿Imports System.Net
Imports System.Net.Security
Imports System.Security.Cryptography.X509Certificates

Public Class SSLUtil

    Public Shared Sub Init()
        ServicePointManager.ServerCertificateValidationCallback =
          New RemoteCertificateValidationCallback(
            AddressOf OnRemoteCertificateValidationCallback)

        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol Or SecurityProtocolType.Tls12
    End Sub

    Private Shared Function OnRemoteCertificateValidationCallback( _
      ByVal sender As Object, _
      ByVal certificate As X509Certificate, _
      ByVal chain As X509Chain, _
      ByVal sslPolicyErrors As SslPolicyErrors _
    ) As Boolean
        If sslPolicyErrors = sslPolicyErrors.None Then
            Return True
        End If

        '独自証明書の許可
        Select Case certificate.Subject
            Case "CN=WMSvc-PENGUIN8-SERVER"
            Case "CN=Penguin8Web1"
            Case "CN=Penguin8Web2"
            Case Else
                Return False
        End Select

        Return True
    End Function

End Class
