'*******************************************************************************
'
'
'
'
'
'*******************************************************************************

Imports System.Text
Imports System.Security.Cryptography

''' <summary>
''' ���[�e�B���e�B
''' </summary>
''' <remarks></remarks>
Public Class clsUtil

    ''' <summary>
    ''' DBNull��Nothing�ɕϊ�
    ''' </summary>
    ''' <param name="TargetObject"></param>
    ''' <remarks></remarks>
    Public Shared Sub ConvertDBNullToNothing(ByRef TargetObject As Object)
        If IsDBNull(TargetObject) Then
            TargetObject = Nothing
        End If
    End Sub

    ''' <summary>
    ''' �ϊ��F���t�^
    ''' </summary>
    ''' <param name="InputValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ConvertDate(ByVal InputValue As Object) As Object
        If IsDBNull(InputValue) Then
            Return Nothing
        End If
        Dim OutputValue As Date
        If Date.TryParse(InputValue, OutputValue) Then
            Return OutputValue.Date
        End If
        Return Nothing
    End Function

    ''' <summary>
    ''' �ϊ��FInteger
    ''' </summary>
    ''' <param name="InputValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ConvertInteger(ByVal InputValue As Object) As Object
        If IsDBNull(InputValue) Then
            Return Nothing
        End If
        Dim OutputValue As Integer
        If Integer.TryParse(InputValue, OutputValue) Then
            Return OutputValue
        End If
        Return Nothing
    End Function

    ''' <summary>
    ''' �ϊ��FDecimal
    ''' </summary>
    ''' <param name="InputValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ConvertDecimal(ByVal InputValue As Object) As Object
        If IsDBNull(InputValue) Then
            Return Nothing
        End If
        Dim OutputValue As Decimal
        If Decimal.TryParse(InputValue, OutputValue) Then
            Return OutputValue
        End If
        Return Nothing
    End Function

    ''' <summary>
    ''' ���l������Ƃ��ď����ݒ�
    ''' </summary>
    ''' <param name="NumericFormat"></param>
    ''' <param name="InputData"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function FormattedNumericString(ByVal InputData As Object, Optional ByVal NumericFormat As String = "#,##0.#########") As String
        If (InputData Is Nothing) Then
            Return Nothing
        End If
        Dim TargetData As Object = Nothing
        If TypeOf (InputData) Is Integer Then
            TargetData = InputData
        End If
        If TypeOf (InputData) Is Decimal Then
            TargetData = InputData
        End If
        If TypeOf (InputData) Is Double Then
            TargetData = InputData
        End If
        If TypeOf (InputData) Is String Then
            Dim ConvertData As Decimal = Nothing
            If Not Decimal.TryParse( _
                                InputData, _
                                System.Globalization.NumberStyles.Number, _
                                System.Globalization.NumberFormatInfo.InvariantInfo, _
                                ConvertData) _
            Then
                Return InputData
            End If
            TargetData = ConvertData
        End If
        If TargetData Is Nothing Then
            Return Nothing
        End If
        Return String.Format("{0:" & NumericFormat & "}", TargetData)
    End Function

    ''' <summary>
    ''' ������𐔒l�^�Ƃ��ĕϊ�
    ''' </summary>
    ''' <param name="InputData"></param>
    ''' <param name="OutputNumeric"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function ConvertStringToNumeric(ByVal InputData As String, ByRef OutputNumeric As Object) As Boolean
        If TypeOf (OutputNumeric) Is Integer Then
            Return Integer.TryParse( _
                                InputData, _
                                System.Globalization.NumberStyles.Number, _
                                System.Globalization.NumberFormatInfo.InvariantInfo, _
                                OutputNumeric)
        End If
        If TypeOf (OutputNumeric) Is Decimal Then
            Return Decimal.TryParse( _
                                InputData, _
                                System.Globalization.NumberStyles.Number, _
                                System.Globalization.NumberFormatInfo.InvariantInfo, _
                                OutputNumeric)
        End If
        If TypeOf (OutputNumeric) Is Double Then
            Return Double.TryParse( _
                                InputData, _
                                System.Globalization.NumberStyles.Number, _
                                System.Globalization.NumberFormatInfo.InvariantInfo, _
                                OutputNumeric)
        End If
        Return False
    End Function

    ''' <summary>
    ''' ��ʊO�Ƀt�H�[�����ʒu�Â�����̂�h��
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <remarks>�t�H�[���̒��S�_����ʂ̒��Ɋ܂܂�Ă���̂��𔻒肵�A�ʒu�����߂�</remarks>
    Public Shared Sub GuardFormLocation(ByVal Form As Form)
        Dim Point As New Point(Form.Location.X + (Form.Size.Width / 2), Form.Location.Y + (Form.Size.Height / 2))
        Dim Rect As Rectangle
        Dim PScreen As Screen
        Dim bCheck As Boolean = False

        For Each AScreen As Screen In Screen.AllScreens
            Rect = AScreen.Bounds
            If Rect.Contains(Point) Then
                bCheck = True
                Exit For
            End If
        Next

        If Not bCheck Then
            PScreen = Screen.PrimaryScreen
            Form.Location = PScreen.Bounds.Location
        End If
    End Sub

    ''' <summary>
    ''' MDI��ʊO�Ƀt�H�[�����ʒu�Â�����̂�h��
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <remarks>�t�H�[���̒��S�_����ʂ̒��Ɋ܂܂�Ă���̂��𔻒肵�A�ʒu�����߂�</remarks>
    Public Shared Sub GuardSubFormLocation(ByVal Form As Form)
        Dim Point As New Point(Form.Location.X + (Form.Size.Width / 2), Form.Location.Y + (Form.Size.Height / 2))
        Dim Rect As Rectangle
        Dim bCheck As Boolean = False

        If Form.MdiParent IsNot Nothing Then
	        Rect = Form.MdiParent.ClientRectangle
	        If Rect.Contains(Point) Then
	            bCheck = True
	        End If
        Else
            bCheck = True
        End If

        If Not bCheck Then
            Form.Location = Form.MdiParent.Bounds.Location
        End If
    End Sub

    ''' <summary>
    ''' �t�H�[���ۑ��ݒ�̕���
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <param name="maximized"></param>
    ''' <param name="size"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Public Shared Sub LoadFormSettings(ByVal Form As Form, ByVal maximized As Boolean, ByVal size As Size, ByVal location As Point)
        If size <> New System.Drawing.Size(Integer.MinValue, Integer.MinValue) Then Form.Size = size
        If location <> New System.Drawing.Point(Integer.MinValue, Integer.MinValue) Then Form.Location = location
        GuardFormLocation(Form)
        If maximized Then Form.WindowState = FormWindowState.Maximized
    End Sub

    ''' <summary>
    ''' �T�u�t�H�[���ۑ��ݒ�̕���
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <param name="maximized"></param>
    ''' <param name="size"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Public Shared Sub LoadSubFormSettings(ByVal Form As Form, ByVal maximized As Boolean, ByVal size As Size, ByVal location As Point)
        If size <> New System.Drawing.Size(Integer.MinValue, Integer.MinValue) Then Form.Size = size
        If location <> New System.Drawing.Point(Integer.MinValue, Integer.MinValue) Then Form.Location = location
        GuardSubFormLocation(Form)
        If maximized Then Form.WindowState = FormWindowState.Maximized
    End Sub

    ''' <summary>
    ''' �t�H�[���ݒ�̕ۑ�
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <param name="maximized"></param>
    ''' <param name="size"></param>
    ''' <param name="location"></param>
    ''' <remarks></remarks>
    Public Shared Sub SaveFormSettings(ByVal Form As Form, ByRef maximized As Boolean, ByRef size As Size, ByRef location As Point)
        maximized = (Form.WindowState = FormWindowState.Maximized)
        Select Case Form.WindowState
            Case FormWindowState.Normal
                size = Form.Size
                location = Form.Location
            Case Else
                size = Form.RestoreBounds.Size
                location = Form.RestoreBounds.Location
        End Select
    End Sub

    ''' <summary>
    ''' �ʏ펞�̃t�H�[���T�C�Y���擾����
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <returns></returns>
    ''' <remarks>�t�H�[���̏�Ԃ𔻒肵�A�ʒu�����擾����</remarks>
    Public Shared Function GetFormSize(ByVal Form As Form)
        Select Case Form.WindowState
            Case FormWindowState.Normal
                Return Form.Size
            Case Else
                Return Form.RestoreBounds.Size
        End Select
    End Function

    ''' <summary>
    ''' �ʏ펞�̃t�H�[���ʒu���擾����
    ''' </summary>
    ''' <param name="Form"></param>
    ''' <returns></returns>
    ''' <remarks>�t�H�[���̏�Ԃ𔻒肵�A�ʒu�����擾����</remarks>
    Public Shared Function GetFormLocation(ByVal Form As Form)
        Select Case Form.WindowState
            Case FormWindowState.Normal
                Return Form.Location
            Case Else
                Return Form.RestoreBounds.Location
        End Select
    End Function

    ''' <summary>
    ''' �f�[�^�O���b�h�r���[�̃J�����ɐݒ�l���X�g���畝��ݒ�
    ''' </summary>
    ''' <param name="dgv"></param>
    ''' <param name="settingList"></param>
    ''' <remarks></remarks>
    Public Shared Sub SetDataGridColumnsWidth(ByVal dgv As DataGridView, ByVal settingList As List(Of KeyValue))
        For Each col As KeyValue In settingList
            If dgv.Columns.Contains(col.Key) Then
                dgv.Columns(col.Key).Width = col.Value
            End If
        Next
    End Sub

    ''' <summary>
    ''' �f�[�^�O���b�h�r���[�̃J��������ݒ�l���X�g�ɕۑ�
    ''' </summary>
    ''' <param name="dgv"></param>
    ''' <param name="settingList"></param>
    ''' <remarks></remarks>
    Public Shared Sub GetDataGridColumnsWidth(ByVal dgv As DataGridView, ByVal settingList As List(Of KeyValue))
        settingList.Clear()
        For Each col As DataGridViewColumn In dgv.Columns
            settingList.Add(New KeyValue(col.Name, col.Width))
        Next
    End Sub

    Public Shared Sub DataGridViewCellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs)

        '�w�b�_�[�̂�
        If e.RowIndex = -1 Then

            If (e.PaintParts And DataGridViewPaintParts.Border) <> 0 Then
                Using linePen As New Pen(Color.FromArgb(160, 160, 160), 3)
                    '�w�b�_�[�̋��E����`��
                    e.Graphics.DrawLine(linePen, e.CellBounds.Left, e.CellBounds.Top, e.CellBounds.Left, e.CellBounds.Bottom)
                End Using
            End If

            If (e.PaintParts And DataGridViewPaintParts.Background) <> 0 Then
                '�O���f�[�V�����u���V���쐬
                Using b As New System.Drawing.Drawing2D.LinearGradientBrush( _
                    e.CellBounds, Color.FromArgb(255, 255, 255), Color.FromArgb(213, 213, 213), _
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical)

                    '�Z����h��Ԃ�
                    e.Graphics.FillRectangle(b, e.CellBounds)
                End Using
            End If

            '�w�i�ȊO��`��
            Dim SelfPaintParts As DataGridViewPaintParts = Not (DataGridViewPaintParts.Background Or DataGridViewPaintParts.Border)
            e.Paint(e.CellBounds, e.PaintParts And SelfPaintParts)

            '�㏑���h�~
            e.Handled = True
        Else
            '�Z���̏㉺�̋��E�����u���E���Ȃ��v�ɐݒ�
            e.AdvancedBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.None
            e.AdvancedBorderStyle.Bottom = DataGridViewAdvancedCellBorderStyle.None
        End If

    End Sub

    Public Shared Sub SetDataGridViewStyle(ByVal grid As DataGridView)
        '�w�i�F�A���E����`�悷��
        AddHandler grid.CellPainting, AddressOf DataGridViewCellPainting

        '�S�Ă̗�̔w�i�F�𔒐F�ɂ���
        grid.RowsDefaultCellStyle.BackColor = Color.FromArgb(255, 255, 255)

        '��s�̔w�i�F��ݒ�
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(239, 243, 250)

        '�I���s�̔w�i�F��ݒ�
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(168, 198, 238)

        grid.ColumnHeadersDefaultCellStyle.Padding = New Padding(0, 4, 0, 4)

        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None

        grid.AdvancedColumnHeadersBorderStyle.All = DataGridViewAdvancedCellBorderStyle.None

        '�Z���̋��E���̐F���w�肷��
        grid.GridColor = Color.FromArgb(160, 160, 160)
    End Sub

    ''' <summary>
    ''' ��O��������Exception��EventLog�o�͏��擾
    ''' </summary>
    ''' <param name="ex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetExceptionMessage(ByVal ex As Exception) As String
        Dim ret As String = ""
        Dim tmpEx As Exception = ex
        Dim sepa As String = ""
        Dim count As Integer = 0
        While tmpEx IsNot Nothing
            If count >= 10 Then Exit While
            ret += sepa + tmpEx.ToString()
            sepa = "\n"

            tmpEx = tmpEx.InnerException
            count += 1
        End While
        Return ret
    End Function

    ''' <summary>
    ''' �T�J�n��
    ''' </summary>
    ''' <param name="DataDate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetWeekStartDate(ByVal DataDate As Date) As Date
        Select Case DataDate.DayOfWeek
            Case System.DayOfWeek.Monday
                Return DataDate
            Case System.DayOfWeek.Tuesday
                Return DataDate.AddDays(-1)
            Case System.DayOfWeek.Wednesday
                Return DataDate.AddDays(-2)
            Case System.DayOfWeek.Thursday
                Return DataDate.AddDays(-3)
            Case System.DayOfWeek.Friday
                Return DataDate.AddDays(-4)
            Case System.DayOfWeek.Saturday
                Return DataDate.AddDays(-5)
            Case System.DayOfWeek.Sunday
                Return DataDate.AddDays(-6)
        End Select
        Return DataDate
    End Function

    ''' <summary>
    ''' �����J�n��
    ''' </summary>
    ''' <param name="DataDate"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetTermStartDate(ByVal DataDate As Date) As Date
        Select Case DataDate.Month
            Case 4, 5, 6, 7, 8, 9
                Return New Date(DataDate.Year, 4, 1)
            Case 10, 11, 12, 1, 2, 3
                Return New Date(DataDate.Year, 10, 1)
        End Select
        Return New Date(DataDate.Year, 4, 1)
    End Function

    Public Shared Sub SaveToCsv(ByVal tempDgv As DataGridView, ByVal CSVColumnList As List(Of List(Of String)), ByVal StartRow As Integer, ByVal EndRow As Integer, ByVal strFileName As String)

        '���̒l���w�肵���ꍇ�A�ŏI�s�܂ł̏o�͂Ƃ���
        If EndRow < 0 Then
            EndRow = tempDgv.Rows.Count - 1
        End If

        Dim CellValue As String
        Dim i As Integer
        Dim j As Integer
        Dim pgMax As Integer = (((EndRow + 1) - StartRow) + 1) / 0.9
        Dim pgCount As Integer = 0
        Dim pgRate As Integer
        Dim strResult As New System.Text.StringBuilder

        'CSVColumnList��nothing�̏ꍇ�A�S���ڏo��
        If CSVColumnList Is Nothing Then
            CSVColumnList = GetCsvColumnList(tempDgv)
        End If

        '�J�����w�b�_��1�s�ڂɗ�L
        For i = 0 To CSVColumnList.Count - 1
            Select Case i
                Case 0
                    strResult.Append("""" & CSVColumnList(i)(1).Replace(vbCrLf, " ") & """")
                Case CSVColumnList.Count - 1
                    strResult.Append("," & """" & CSVColumnList(i)(1).Replace(vbCrLf, " ") & """" & vbCrLf)
                Case Else
                    strResult.Append("," & """" & CSVColumnList(i)(1).Replace(vbCrLf, " ") & """")
            End Select
        Next

        pgCount += 1

        '�f�[�^��ۑ�
        For i = StartRow To EndRow
            For j = 0 To CSVColumnList.Count - 1
                CellValue = tempDgv.Rows(i).Cells(CSVColumnList(j)(0)).GetEditedFormattedValue(i, DataGridViewDataErrorContexts.Formatting)

                CellValue = CellValue.Replace("""", """""")

                Select Case j
                    Case 0
                        strResult.Append("""" & CellValue & """")
                    Case CSVColumnList.Count - 1
                        strResult.Append("," & """" & CellValue & """" & vbCrLf)
                    Case Else
                        strResult.Append("," & """" & CellValue & """")
                End Select
            Next
            pgCount += 1

            pgRate = pgCount / pgMax * 100
        Next

        Dim swText As New System.IO.StreamWriter(strFileName, False, System.Text.Encoding.GetEncoding("shift_jis"))
        swText.Write(strResult.ToString)
        swText.Dispose()
    End Sub

    Public Shared Sub SaveToZandakaBrowserCsv(ByVal tempDgv As DataGridView, ByVal CSVColumnList As List(Of List(Of String)), ByVal StartRow As Integer, ByVal EndRow As Integer, ByVal ProgressBar As ToolStripProgressBar, ByVal strFileName As String, ByVal StatusLabel As ToolStripStatusLabel)

        '���̒l���w�肵���ꍇ�A�ŏI�s�܂ł̏o�͂Ƃ���
        If EndRow < 0 Then
            EndRow = tempDgv.Rows.Count - 1
        End If

        Dim CellValue As String
        Dim i As Integer
        Dim j As Integer
        Dim pgMax As Integer = (((EndRow + 1) - StartRow) + 1) / 0.9
        Dim pgCount As Integer = 0
        Dim pgRate As Integer
        Dim strResult As New System.Text.StringBuilder

        ProgressBar.Minimum = 0
        ProgressBar.Maximum = 100
        ProgressBar.Value = 0

        'CSVColumnList��nothing�̏ꍇ�A�S���ڏo��
        If CSVColumnList Is Nothing Then
            CSVColumnList = GetCsvColumnList(tempDgv)
        End If

        '�J�����w�b�_��1�s�ڂɗ�L
        For i = 0 To CSVColumnList.Count - 1
            Select Case i
                Case 0
                    strResult.Append("""" & CSVColumnList(i)(1).Replace(vbCrLf, " ") & """")
                Case CSVColumnList.Count - 1
                    strResult.Append("," & """" & CSVColumnList(i)(1).Replace(vbCrLf, " ") & """" & vbCrLf)
                Case Else
                    strResult.Append("," & """" & CSVColumnList(i)(1).Replace(vbCrLf, " ") & """")
            End Select
        Next

        pgCount += 1

        '�f�[�^��ۑ�
        For i = StartRow To EndRow
            For j = 0 To CSVColumnList.Count - 1
                '�S�Ă̍s�́u���i���v�̗�̒l���o�͂���
                If CSVColumnList(j)(0) = "GroupProductName" Then
                    CellValue = tempDgv.Rows(i).Cells(CSVColumnList(j)(0)).Value.ToString
                Else
                    CellValue = tempDgv.Rows(i).Cells(CSVColumnList(j)(0)).GetEditedFormattedValue(i, DataGridViewDataErrorContexts.Formatting)
                End If

                CellValue = CellValue.Replace("""", """""")

                Select Case j
                    Case 0
                        strResult.Append("""" & CellValue & """")
                    Case CSVColumnList.Count - 1
                        strResult.Append("," & """" & CellValue & """" & vbCrLf)
                    Case Else
                        strResult.Append("," & """" & CellValue & """")
                End Select
            Next
            pgCount += 1

            pgRate = pgCount / pgMax * 100

            If pgRate > ProgressBar.Value Then
                ProgressBar.Value = pgRate
            End If
        Next

        'UTF-8�Ńt�@�C���ۑ�
        Dim swText As New System.IO.StreamWriter(strFileName, False, System.Text.Encoding.UTF8)
        swText.Write(strResult.ToString)
        swText.Dispose()

        ProgressBar.Value = ProgressBar.Maximum
        SetStatusLabelText("CSV�o�͂��܂����B", StatusLabel)
        ProgressBar.Value = ProgressBar.Minimum
    End Sub

    Public Shared Function GetCsvColumnList(ByVal tempDgv As DataGridView) As List(Of List(Of String))
        Dim ret As New List(Of List(Of String))
        Dim i As Integer

        For i = 0 To tempDgv.Columns.Count - 1
            ret.Add(New List(Of String))
            ret(i).Add(tempDgv.Columns(i).Name)
            ret(i).Add(tempDgv.Columns(i).HeaderText)
        Next

        Return ret
    End Function

    Public Shared Sub ClearStatusLabel(ByVal slResultMessage As System.Windows.Forms.ToolStripStatusLabel)
        slResultMessage.Text = Nothing
    End Sub

    Public Shared Sub SetStatusLabelText(ByVal Message As String, ByVal slResultMessage As System.Windows.Forms.ToolStripStatusLabel)
        slResultMessage.Text = DateTime.UtcNow.AddMinutes(SessionService.TimeZone).ToString("HH:mm:ss") + " " + Message
    End Sub

    Public Shared Function GetRateDPFormat(DecimalPlaces As Integer) As String
        If DecimalPlaces <= 0 Then
            Return "######0.########"
        End If
        Select Case DecimalPlaces
            Case 0 : Return "######0.########"
            Case 1 : Return "######0.0#######"
            Case 2 : Return "######0.00######"
            Case 3 : Return "######0.000#####"
            Case 4 : Return "######0.0000####"
            Case 5 : Return "######0.00000###"
            Case 6 : Return "######0.000000##"
            Case 7 : Return "######0.0000000#"
        End Select
        Return "######0.00000000"
    End Function

    Public Shared Function GetPrevWorkDay(SysDate As DateTime) As DateTime
        Dim PrevDay As DateTime = SysDate.AddDays(-1)
        While PrevDay.DayOfWeek = DayOfWeek.Sunday Or PrevDay.DayOfWeek = DayOfWeek.Saturday
            PrevDay = PrevDay.AddDays(-1)
        End While
        Return PrevDay
    End Function

    Public Shared Sub SetGridDoubleBuffered(grid As DataGridView)
        Dim myType As Type = GetType(DataGridView)
        Dim myPropertyInfo As System.Reflection.PropertyInfo = myType.GetProperty("DoubleBuffered",
                System.Reflection.BindingFlags.Instance Or System.Reflection.BindingFlags.NonPublic)
        myPropertyInfo.SetValue(grid, True, Nothing)
    End Sub

    Public Shared Function GetVersionString() As String
        Dim ver = My.Application.Info.Version  '�A�Z���u�����Ver
        Return String.Format("{0}.{1}.{2}", ver.Major, ver.Minor, ver.Build)
    End Function

    Public Shared Function GetEnvTitle()
        Dim WebServiceURL As String = My.Settings.WebService1
        Select Case WebServiceURL
            Case "https://lionboadmin01.hiroseuk.com/WebService/Admin/"
                '�{�Ԋ�
                Return ""
            Case "https://stg-lionboadmin.hirose-fx.co.jp/WebServiceDemo/Admin/"
                '�f����
                Return "�f��"
            Case "https://stg-lionboadmin.hirose-fx.co.jp/WebService/Admin/"
                '�X�e�[�W���O��
                Return "Staging"
            Case "https://dev.fate-i.com/WebService/", "http://dev.fate-i.com/WebService/"
                '�J����
                Return "�J��"
            Case "https://dev.fate-i.com/WebServiceNext/", "http://dev.fate-i.com/WebServiceNext/"
                '������
                Return "����"
            Case "http://localhost:59000/WebService/", "http://penguin8web2.fate-i.lo/WebService/", "http://penguin8web1.fate-i.lo/WebService/"
                '�Г���
                Return "�Г�"
            Case "https://lionboadmin01.hiroseuk.com/WebService/Admin/", "https://lionboadmin02.hiroseuk.com/WebService/Admin/"
                'UK�{�Ԋ�
                Return "UK"
            Case "https://staging.lionboadmin.hiroseuk.com/WebServiceDemo/Admin/"
                'UK�{�Ԋ�
                Return "UK�f��"
            Case "https://staging.lionboadmin.hiroseuk.com/WebService/Admin/"
                'UK�{�Ԋ�
                Return "UK STG"
            Case "https://dev.fate-i.com/WebServiceUK/Admin/", "http://dev.fate-i.com/WebServiceUK/Admin/"
                'UK�J����
                Return "UK�J��"
            Case "https://dev.fate-i.com/WebServiceMT4/Admin/", "http://dev.fate-i.com/WebServiceMT4/Admin/"
                'UK�J��MT4�A�g��
                Return "UK MT4"
            Case "http://192.168.53.154/WebService/Admin/", "http://192.168.53.155/WebService/Admin/"
                'UK�Г���
                Return "UK�Г�"
            Case Else
                Return "���̑�"
        End Select
    End Function

    Private Const SecretKey As String = "]*@=g\!Cwh'QFVz!"

    Public Shared Function EncryptPassword(UserID As String, Password As String) As String
        Dim passbin As Byte() = Encoding.UTF8.GetBytes(UserID & SecretKey & Password)
        Dim md5 As New MD5CryptoServiceProvider()
        Dim passhash As Byte() = md5.ComputeHash(passbin)
        Dim passhashtext As String = BitConverter.ToString(passhash).ToLower().Replace("-", "")
        Return passhashtext
    End Function

    Public Shared Function GetMoneyFormatDisp() As String
        Dim ret = "###,###,###,###,###,##0.####"
        Select Case SessionService.DecimalPlaces
            Case 1 : ret = "###,###,###,###,###,##0.0###"
            Case 2 : ret = "###,###,###,###,###,##0.00##"
            Case 3 : ret = "###,###,###,###,###,##0.000#"
            Case 4 : ret = "###,###,###,###,###,##0.0000"
        End Select
        Return ret
    End Function

    Public Shared Function GetMoneyFormatEdit() As String
        Dim ret = "##########0.####"
        Select Case SessionService.DecimalPlaces
            Case 1 : ret = "##########0.0###"
            Case 2 : ret = "##########0.00##"
            Case 3 : ret = "##########0.000#"
            Case 4 : ret = "##########0.0000"
        End Select
        Return ret
    End Function


End Class
