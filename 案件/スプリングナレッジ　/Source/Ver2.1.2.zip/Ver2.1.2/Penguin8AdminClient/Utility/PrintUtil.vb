﻿Imports System.Drawing.Printing

'--------------------------------------------------------------------------
' 印刷制御クラス
'--------------------------------------------------------------------------
Public Class PrintUtil
	Private PrtDoc As PrintDocument							' 印刷 DocumentObject
	Private PrtFont_Title As Font							' タイトル用フォント
	Private PrtFont_Data As Font							' データ明細用フォント

	Private TextSizeXP As Integer							' １文字当たりのX-Pixel
	Private TextSizeYP As Integer							' １文字当たりのY-Pixel
	Private TextSizeW As Integer							' 描画可能域の字数
	Private TextSizeH As Integer							' 描画可能域の行数
	Private HeaderLines As Integer							' ヘッダー部行サイズ
	Private DetailLines As Integer							' データ行数（１明細）
	Private ReportRowCount As Integer						' GRIDデータ数
	Private ReportRowIndex As Integer						' GRIDデータインデックス
	Private ReportLineMax As Integer						' 印刷可能域内の明細最大数（１ページ）
	Private ReportLineLimit As Integer						' 明細最大数制限値（１ページ）

	Private ReportHeader As List(Of ReportItems)			' ヘッダー項目定義リスト
	Private ReportDetail As List(Of ReportItems)			' 明細項目定義リスト

	Private ReportDate As String							' 印刷開始日時文字列
	Private ReportPage As Integer							' 印刷中ページ
	Private ReportMaxPage As Integer						' 印刷中全ページ数
	Private ReportGrid As DataGridView						' データグリッド

	Private Const ITEM_ALIGNMENT_RIGHT As Integer = -1		' 配置：右詰
	Private Const ITEM_ALIGNMENT_CENTER As Integer = -2		' 配置：中央揃え

    Private marginsHard As Margins = New Margins()
    Private marginsPrintDocument As Margins = New Margins()

	'--------------------------------------------------------------------------
	' 印刷項目クラス
	'--------------------------------------------------------------------------
	Private Class ReportItems
		Public ItemType As ItemTypes						' 項目種別
		Public LineType As LineTypes						' 罫線種別
		Public ItemName As String							' 項目名
		Public ItemLabel As String							' 項目値／固定値
		Public ItemPosition As Point						' 配置(Left/Topのテキスト座標)
		Public ItemSize As Point							' 項目枠サイズ(X-Width/Y-Heightのテキスト座標)
		Public ItemOffset As Point							' 表示位置Offset(X/Yのテキスト座標)  X=-1:Right -2:Center

		'----------------------------------------------------------------------
		' コンストラクタ
		'----------------------------------------------------------------------
		Public Sub New(ByVal pItemType As ItemTypes, ByVal pItemX As Integer, ByVal pItemY As Integer, ByVal pItemLabel As String, ByVal pLineType As LineTypes, ByVal pLineWidth As Integer, ByVal pLineHeight As Integer, ByVal pLabelOffsetX As Integer, ByVal pLabelOffsetY As Integer)
			ItemType = pItemType
			LineType = pLineType
			ItemName = pItemLabel
			ItemLabel = pItemLabel
			ItemPosition.X = pItemX
			ItemPosition.Y = pItemY
			ItemSize.X = pLineWidth
			ItemSize.Y = pLineHeight
			ItemOffset.X = pLabelOffsetX
			ItemOffset.Y = pLabelOffsetY
		End Sub

	End Class

	'--------------------------------------------------------------------------
	' 印刷項目種別
	'--------------------------------------------------------------------------
	Public Enum ItemTypes
		TitleText = 0				' タイトル項目 大フォントで固定値表示
		LabelText					' 固定値
		GridItem					' GRID項目
	End Enum

	'--------------------------------------------------------------------------
	' 罫線種別
	'--------------------------------------------------------------------------
	Public Enum LineTypes
		None = 0					' 罫線なし
		Standard					' 囲み罫線
		DoubleLine					' 囲み罫線:上のみ二重線
	End Enum

	'--------------------------------------------------------------------------
	' 帳票種別
	'--------------------------------------------------------------------------
	Public Enum Reports As Integer
		SalesPerformanceList = 0
		CashList
		TradeList
	End Enum

	'--------------------------------------------------------------------------
	' コンストラクタ
	'--------------------------------------------------------------------------
	Public Sub New()
		ReportHeader = New List(Of ReportItems)
		ReportDetail = New List(Of ReportItems)
	End Sub

	'--------------------------------------------------------------------------
	' 文字列描画
	'--------------------------------------------------------------------------
	Private Sub DrawText(ByVal e As PrintPageEventArgs, ByVal DrawFont As Font, ByVal PosX As Integer, ByVal PosY As Integer, ByVal TextData As String, ByVal ItemOffset As Point, ByVal ItemSize As Point)
		Dim PixelDrawX As Integer
		Dim PixelDrawY As Integer
		Dim LineOffset As Integer
		Dim TextList() As String
		Dim TextLine As String
		Dim DrawRect As Rectangle
		Dim DrawFormat As StringFormat

		TextList = TextData.Split(vbTab)
		LineOffset = 0
		For Each TextLine In TextList
			PixelDrawX = e.MarginBounds.Left + (PosX * TextSizeXP)
			PixelDrawY = e.MarginBounds.Top + (PosY * TextSizeYP) + (LineOffset * TextSizeYP) + 3			' 上罫線部を残す

			DrawFormat = New StringFormat()
			'------------------------------------------------------------------
			' OffsetからAlignment決定
			'------------------------------------------------------------------
			Select Case ItemOffset.X
				Case ITEM_ALIGNMENT_RIGHT
					DrawFormat.Alignment = StringAlignment.Far
				Case ITEM_ALIGNMENT_CENTER
					DrawFormat.Alignment = StringAlignment.Center
				Case Else
					DrawFormat.Alignment = StringAlignment.Near
					PixelDrawX = PixelDrawX + (ItemOffset.X * TextSizeXP)
			End Select

			DrawFormat.FormatFlags = StringFormatFlags.NoWrap
			DrawRect.Location = New Point(PixelDrawX, PixelDrawY)
			If ItemSize.X = 0 Then
				DrawRect.Size = New Point(0, ItemSize.Y * TextSizeYP)
			Else
				DrawRect.Size = New Point((ItemSize.X * TextSizeXP) + (TextSizeXP / 2), ItemSize.Y * TextSizeYP)
			End If
			e.Graphics.DrawString(TextLine, DrawFont, Brushes.Black, DrawRect, DrawFormat)
			LineOffset = LineOffset + 1
		Next
	End Sub

	'--------------------------------------------------------------------------
	' 文字列座標の罫線描画
	'--------------------------------------------------------------------------
	Private Sub DrawLine(ByVal e As PrintPageEventArgs, ByVal TextX As Integer, ByVal TextY As Integer, ByVal TextW As Integer, ByVal TextH As Integer, ByVal LineType As LineTypes)
		Dim PixelDrawX As Integer
		Dim PixelDrawY As Integer
		Dim PointStart As Point
		Dim PointEnd As Point

		PixelDrawX = e.MarginBounds.Left + (TextSizeXP * TextX)
		PixelDrawY = e.MarginBounds.Top + (TextSizeYP * TextY)
		' 開始点の縦罫線
		PointStart.X = PixelDrawX + (TextSizeXP / 2)
		PointStart.Y = PixelDrawY
		PointEnd.X = PointStart.X
		PointEnd.Y = PointStart.Y + (TextSizeYP * TextH)
		e.Graphics.DrawLine(Pens.Black, PointStart, PointEnd)
		' 終了点の縦罫線
		PointStart.X = PixelDrawX + (TextSizeXP * TextW) + (TextSizeXP / 2)
		PointEnd.X = PointStart.X
		e.Graphics.DrawLine(Pens.Black, PointStart, PointEnd)

		' 開始点の横罫線
		PointStart.X = PixelDrawX + (TextSizeXP / 2)
		PointStart.Y = PixelDrawY
		PointEnd.X = PointStart.X + (TextSizeXP * TextW)
		PointEnd.Y = PointStart.Y
		e.Graphics.DrawLine(Pens.Black, PointStart, PointEnd)
		If LineType = LineTypes.DoubleLine Then
			PointStart.Y = PixelDrawY + 2
			PointEnd.Y = PointStart.Y
			e.Graphics.DrawLine(Pens.Black, PointStart, PointEnd)
		End If

		' 終了点の横罫線
		PointStart.Y = PixelDrawY + (TextSizeYP * TextH)
		PointEnd.Y = PointStart.Y
		e.Graphics.DrawLine(Pens.Black, PointStart, PointEnd)
	End Sub

	'--------------------------------------------------------------------------
	' 印刷定義項目の印字
	'--------------------------------------------------------------------------
	Private Sub PrintReportItem(ByVal e As PrintPageEventArgs, ByVal ReportItem As ReportItems, ByVal DetailLineOffset As Integer)
		Dim PosX As Integer
		Dim PosY As Integer
		Dim LineW As Integer
		Dim LineH As Integer
		Dim ItemText As String
		Dim PageString As String
		Dim DrawFont As Font

		PosX = ReportItem.ItemPosition.X
		PosY = ReportItem.ItemPosition.Y + (DetailLineOffset * DetailLines)

		Select Case ReportItem.ItemType
			Case ItemTypes.LabelText
				ItemText = ReportItem.ItemLabel
				DrawFont = PrtFont_Data
			Case ItemTypes.TitleText
				ItemText = ReportItem.ItemLabel
				DrawFont = PrtFont_Title
			Case ItemTypes.GridItem
				ItemText = ReportItem.ItemLabel
				DrawFont = PrtFont_Data
			Case Else
				ItemText = "???"
				DrawFont = PrtFont_Data
		End Select

		If ItemText.IndexOf("%DATE%") >= 0 Then
			ItemText = ItemText.Replace("%DATE%", ReportDate)
		End If
		If ItemText.IndexOf("%PAGE%") >= 0 Then
			PageString = ReportPage.ToString() & "/" & ReportMaxPage.ToString()
			ItemText = ItemText.Replace("%PAGE%", PageString)
		End If

		DrawText(e, DrawFont, PosX, PosY, ItemText, ReportItem.ItemOffset, ReportItem.ItemSize)

		Select Case ReportItem.LineType
			Case LineTypes.Standard, LineTypes.DoubleLine
				LineW = ReportItem.ItemSize.X
				LineH = ReportItem.ItemSize.Y
				DrawLine(e, PosX, PosY, LineW, LineH, ReportItem.LineType)
		End Select

	End Sub

	'--------------------------------------------------------------------------
	' ヘッダー印刷定義項目の印字
	'--------------------------------------------------------------------------
	Private Sub PrintReportHeader(ByVal e As PrintPageEventArgs)
		Dim ReportItem As ReportItems

		For Each ReportItem In ReportHeader
			PrintReportItem(e, ReportItem, 0)
		Next
		ReportPage = ReportPage + 1
	End Sub

	'--------------------------------------------------------------------------
	' 明細印刷定義項目の印字
	'--------------------------------------------------------------------------
	Private Sub PrintReportDetail(ByVal e As PrintPageEventArgs, ByVal RowIndex As Integer, ByVal DetailLineOffset As Integer)
		Dim ReportItem As ReportItems
		Dim ColName As String
		Dim CellValue As String

		For Each ReportItem In ReportDetail
			If ReportItem.ItemType = ItemTypes.GridItem Then
				ColName = ReportItem.ItemName
                CellValue = ReportGrid.Rows(RowIndex).Cells(ColName).GetEditedFormattedValue(RowIndex, DataGridViewDataErrorContexts.Formatting)
                CellValue = CellValue.Replace(vbCrLf, " ")
				ReportItem.ItemLabel = CellValue
			End If
			PrintReportItem(e, ReportItem, DetailLineOffset)
		Next
	End Sub

	'--------------------------------------------------------------------------
	' 帳票印刷
	'--------------------------------------------------------------------------
	Public Sub PrintReport(ByVal Grid As DataGridView, ByVal ReportType As Reports, ByVal ReportCondition As String)
#If DEBUG Then
		Dim PrtDlg As PrintPreviewDialog
#Else
		Dim PrtDlg As PrintDialog
#End If
		Dim DocumentTitle As String
		Dim DetailMaxLine As Integer
		Dim Landscape As Boolean
		Dim Conditions() As String
		Dim TextY As Integer

		ReportGrid = Grid
		DocumentTitle = ""
		Landscape = False
		Select Case ReportType
			Case Reports.SalesPerformanceList
				HeaderLines = 7
				DetailLines = 1
                DetailMaxLine = 68
				DocumentTitle = "営業実績表"
				ReportHeader.Add(New ReportItems(ItemTypes.TitleText, 60, 1, "営業実績表", LineTypes.None, 0, 0, 0, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 96, 2, "印刷日時:%DATE%", LineTypes.None, 0, 0, 0, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 132, 2, "PAGE:%PAGE%", LineTypes.None, 0, 0, 0, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, 3, "抽出条件:" & ReportCondition, LineTypes.None, 0, 0, 0, 0))

				TextY = 5
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, TextY, "取引日", LineTypes.Standard, 12, 2, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 14, TextY, "登録" & vbTab & "口座数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 22, TextY, "有効" & vbTab & "口座数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 30, TextY, "新規" & vbTab & "口座数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 38, TextY, "取引" & vbTab & "口座数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 46, TextY, "取引" & vbTab & "件数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 54, TextY, "取引金額", LineTypes.Standard, 14, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 68, TextY, "残高合計", LineTypes.Standard, 16, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 84, TextY, "Net損益", LineTypes.Standard, 14, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 98, TextY, "入金" & vbTab & "件数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 106, TextY, "入金額合計", LineTypes.Standard, 14, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 120, TextY, "出金" & vbTab & "件数", LineTypes.Standard, 8, 2, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 128, TextY, "出金額合計", LineTypes.Standard, 14, 2, ITEM_ALIGNMENT_CENTER, 0))

				TextY = TextY + 2
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 2, TextY, "SysDate", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 14, TextY, "AccountCount", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 22, TextY, "AccountCountEnabled", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 30, TextY, "NewAccountCount", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 38, TextY, "TradeAccountCount", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 46, TextY, "TradeCount", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 54, TextY, "TradeAmount", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 68, TextY, "TotalMoney", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 84, TextY, "TotalPAndL", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 98, TextY, "CashInCount", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 106, TextY, "CashInMoney", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 120, TextY, "CashOutCount", LineTypes.Standard, 8, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 128, TextY, "CashOutMoney", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
			Case Reports.CashList
				HeaderLines = 6
				DetailLines = 1
                DetailMaxLine = 68
				DocumentTitle = "残高一覧"
				Conditions = ReportCondition.Split(vbTab)
				ReportHeader.Add(New ReportItems(ItemTypes.TitleText, 60, 1, "残高一覧", LineTypes.None, 0, 0, 0, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 96, 2, "印刷日時:%DATE%", LineTypes.None, 0, 0, 0, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 132, 2, "PAGE:%PAGE%", LineTypes.None, 0, 0, 0, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, 3, "抽出条件:" & Conditions(0), LineTypes.None, 0, 0, 0, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, 4, Conditions(1), LineTypes.None, 0, 0, 0, 0))

				TextY = 6
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, TextY, "処理Seq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 22, TextY, "有効フラグ", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 34, TextY, "処理日時", LineTypes.Standard, 22, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 56, TextY, "取引日", LineTypes.Standard, 13, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 69, TextY, "取引種別", LineTypes.Standard, 27, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 96, TextY, "金額", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 112, TextY, "取引後残高", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 128, TextY, "委託者コード", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_CENTER, 0))
				TextY = TextY + 1
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 2, TextY, "CashCode", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 22, TextY, "CashEnabledName", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 34, TextY, "ExecTime", LineTypes.Standard, 22, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 56, TextY, "SysDate", LineTypes.Standard, 13, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 69, TextY, "CashTypeName", LineTypes.Standard, 27, 1, 1, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 96, TextY, "Money", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 112, TextY, "TotalMoney", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 128, TextY, "CustCode", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_CENTER, 0))
			Case Reports.TradeList
				HeaderLines = 9
				DetailLines = 4
                DetailMaxLine = 16
				DocumentTitle = "取引一覧"
				Conditions = ReportCondition.Split(vbTab)
				ReportHeader.Add(New ReportItems(ItemTypes.TitleText, 60, 1, "取引一覧", LineTypes.None, 0, 0, 0, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 102, 2, "印刷日時:%DATE%", LineTypes.None, 0, 0, 0, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 138, 2, "PAGE:%PAGE%", LineTypes.None, 0, 0, 0, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, 3, "抽出条件:" & Conditions(0), LineTypes.None, 0, 0, 0, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, 4, Conditions(1), LineTypes.None, 0, 0, 0, 0))

				TextY = 6
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, TextY, "注文番号", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 21, TextY, "銘柄コード", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 40, TextY, "通貨ペア", LineTypes.Standard, 10, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 50, TextY, "種別", LineTypes.Standard, 6, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 56, TextY, "銘柄ﾍﾟｲｱｳﾄ率", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 70, TextY, "注文時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 91, TextY, "注文時価格Seq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 111, TextY, "注文時価格時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 132, TextY, "注文時価格", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))
				TextY = TextY + 1
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, TextY, "取引日", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 21, TextY, "行使期日", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 40, TextY, "金額", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 56, TextY, "ﾍﾟｲｱｳﾄ率", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 70, TextY, "放棄時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 91, TextY, "放棄時価格Seq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 111, TextY, "放棄時価格時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 132, TextY, "放棄時価格", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))
				TextY = TextY + 1
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, TextY, "委託者コード", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 21, TextY, "取引ステータス", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 40, TextY, "ﾍﾟｲｱｳﾄ額", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 56, TextY, "損益", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 70, TextY, "約定時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 91, TextY, "約定時価格Seq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 111, TextY, "約定時価格時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 132, TextY, "行使価格", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))
                TextY = TextY + 1
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 2, TextY, "オプション種別", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 21, TextY, "メモ", LineTypes.Standard, 35, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 56, TextY, "国", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 70, TextY, "行使処理時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 91, TextY, "行使時価格Seq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 111, TextY, "行使時価格時間", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportHeader.Add(New ReportItems(ItemTypes.LabelText, 132, TextY, "行使時価格", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_CENTER, 0))

				TextY = TextY + 1
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 2, TextY, "TradeSeq", LineTypes.DoubleLine, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 21, TextY, "ProductCode", LineTypes.DoubleLine, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 40, TextY, "ComName", LineTypes.DoubleLine, 10, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 50, TextY, "TradeTypeName", LineTypes.DoubleLine, 6, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 56, TextY, "PayoutRate", LineTypes.DoubleLine, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 70, TextY, "OrderReqTime", LineTypes.DoubleLine, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 91, TextY, "OrderClientRateSeq", LineTypes.DoubleLine, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 111, TextY, "OrderClientRateTime", LineTypes.DoubleLine, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 132, TextY, "OrderClientRate", LineTypes.DoubleLine, 12, 1, ITEM_ALIGNMENT_RIGHT, 0))
				TextY = TextY + 1
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 2, TextY, "SysDate", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 21, TextY, "ExercTime", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 40, TextY, "Premium", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 56, TextY, "ExercPayoutRate", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 70, TextY, "AbandReqTime", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 91, TextY, "AbandClientRateSeq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 111, TextY, "AbandClientRateTime", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 132, TextY, "AbandClientRate", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_RIGHT, 0))
				TextY = TextY + 1
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 2, TextY, "CustCode", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 21, TextY, "TradeStatusName", LineTypes.Standard, 19, 1, 1, 0))
				ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 40, TextY, "Payout", LineTypes.Standard, 16, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 56, TextY, "NetPAndL", LineTypes.Standard, 14, 1, ITEM_ALIGNMENT_RIGHT, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 70, TextY, "TradeTime", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 91, TextY, "TradeRateSeq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 111, TextY, "TradeRateTime", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 132, TextY, "TradeRate", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_RIGHT, 0))
                TextY = TextY + 1
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 2, TextY, "OpTypeName", LineTypes.Standard, 19, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 21, TextY, "Memo", LineTypes.Standard, 35, 1, 1, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 56, TextY, "CountryName", LineTypes.Standard, 14, 1, 1, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 70, TextY, "ExercProcTime", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 91, TextY, "ExercRateSeq", LineTypes.Standard, 20, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 111, TextY, "ExercRateTime", LineTypes.Standard, 21, 1, ITEM_ALIGNMENT_CENTER, 0))
                ReportDetail.Add(New ReportItems(ItemTypes.GridItem, 132, TextY, "ExercRate", LineTypes.Standard, 12, 1, ITEM_ALIGNMENT_RIGHT, 0))
		End Select

		ReportRowCount = ReportGrid.Rows.Count()

		InitPrint(DocumentTitle, DetailMaxLine, Landscape)

#If DEBUG Then
		PrtDlg = New PrintPreviewDialog
		PrtDlg.Document = PrtDoc
		PrtDlg.SetBounds(0, 0, 1200, 800)
		PrtDlg.ShowDialog()
#Else
		PrtDlg = New PrintDialog
		PrtDlg.Document = PrtDoc
		If PrtDlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
			PrtDoc.Print()
		End If
#End If
	End Sub

	'--------------------------------------------------------------------------
	' 座標系の基準値算出
	'--------------------------------------------------------------------------
	Private Sub StartPrint(ByVal e As PrintPageEventArgs)
		Dim MeasureW As Single
		Dim LineBuff As String

		If ReportPage = 1 Then
			'----------------------------------------------------------------------
			' 明細描画用Fontでの印刷可能文字数＆１文字当たりのPixelの算出
			'----------------------------------------------------------------------
			LineBuff = ""
			While True
                LineBuff += "X"
                Dim MeasureWidth As Single = e.Graphics.MeasureString(LineBuff, PrtFont_Data).Width
                If MeasureWidth > e.MarginBounds.Width Then
                    '印刷幅を超えたため、折り返す
                    LineBuff = LineBuff.Substring(0, LineBuff.Length - 1)
                    Exit While
                End If
			End While
			MeasureW = e.Graphics.MeasureString(LineBuff, PrtFont_Data).Width
			TextSizeW = LineBuff.Length
			TextSizeXP = MeasureW / TextSizeW
			TextSizeYP = PrtFont_Data.GetHeight(e.Graphics) + 4			' 上:3 pixel, 下:1 pixel を罫線用とする
			TextSizeH = e.MarginBounds.Height / TextSizeYP

			ReportLineMax = (TextSizeH - HeaderLines) \ DetailLines		' １ページ当たりの最大明細数の算出
			If ReportLineMax > ReportLineLimit Then
				ReportLineMax = ReportLineLimit
			End If
			ReportMaxPage = ((ReportGrid.Rows.Count() - 1) \ ReportLineMax) + 1
		End If

#If DEBUG Then
        'e.Graphics.DrawRectangle(Pens.Red, 0, 0, e.MarginBounds.Width, e.MarginBounds.Height)
        'e.Graphics.DrawRectangle(Pens.Blue, e.MarginBounds)
#End If
	End Sub

	'--------------------------------------------------------------------------
	' 印刷前環境初期化
	'--------------------------------------------------------------------------
	Private Sub InitPrint(ByVal DocumentTitile As String, ByVal DetailMaxLine As Integer, ByVal Landscape As Boolean)
		ReportDate = Format(Now, "yyyy/MM/dd HH:mm:ss")
		ReportPage = 0
		ReportMaxPage = 0
		ReportLineLimit = DetailMaxLine

		PrtDoc = New PrintDocument
        PrtDoc.DocumentName = DocumentTitile
        'PrtDoc.OriginAtMargins = True
        PrtDoc.DefaultPageSettings.Landscape = Landscape
        PrtDoc.DefaultPageSettings.Margins.Left = 30
        PrtDoc.DefaultPageSettings.Margins.Top = 30
        PrtDoc.DefaultPageSettings.Margins.Right = 30
        PrtDoc.DefaultPageSettings.Margins.Bottom = 30
        'フォント指定
		PrtFont_Title = New Font("ＭＳ ゴシック", 14)
		PrtFont_Data = New Font("ＭＳ ゴシック", 7.5)
		'印刷イベントハンドラ登録
		AddHandler PrtDoc.BeginPrint, AddressOf OnBeginPrint
        AddHandler PrtDoc.PrintPage, AddressOf OnPrintPage
        AddHandler PrtDoc.EndPrint, AddressOf OnEndPrint

        'プリンタのハードマージンの計算（プリンタで定義されている用紙サイズの場合） 
        Dim defaultPaperWidth As Integer = PrtDoc.DefaultPageSettings.PaperSize.Width
        Dim defaultPaperHeight As Integer = PrtDoc.DefaultPageSettings.PaperSize.Height
        Dim defaultPrintableWidth As Integer = PrtDoc.DefaultPageSettings.PrintableArea.Width
        Dim defaultPrintableHeight As Integer = PrtDoc.DefaultPageSettings.PrintableArea.Height
        marginsHard.Left = PrtDoc.DefaultPageSettings.HardMarginX
        marginsHard.Top = PrtDoc.DefaultPageSettings.HardMarginY
        marginsHard.Right = defaultPaperWidth - marginsHard.Left - defaultPrintableWidth
        marginsHard.Bottom = defaultPaperHeight - marginsHard.Top - defaultPrintableHeight
    End Sub

	'--------------------------------------------------------------------------
	' 印刷実行イベント
	'--------------------------------------------------------------------------
	Private Sub OnPrintPage(ByVal sender As Object, ByVal e As PrintPageEventArgs)
		Dim ReportLineIndex As Integer

		StartPrint(e)

		PrintReportHeader(e)

		ReportLineIndex = 0
		For ReportLineIndex = 0 To ReportLineMax - 1
			If ReportRowIndex < ReportRowCount Then
				PrintReportDetail(e, ReportRowIndex, ReportLineIndex)
				ReportRowIndex = ReportRowIndex + 1
			End If
		Next

		'次ページ有無
		If ReportRowIndex < ReportRowCount Then
			e.HasMorePages = True
		Else
			e.HasMorePages = False
		End If

	End Sub

	'--------------------------------------------------------------------------
	' 印刷前処理
	'--------------------------------------------------------------------------
	Private Sub OnBeginPrint(ByVal sender As Object, ByVal e As PrintEventArgs)
		ReportPage = 1
		ReportRowIndex = 0

        If e.PrintAction = PrintAction.PrintToPreview Then
            ' プレビュー表示位置補正のため PrintDocument のマージン値を退避する 
            marginsPrintDocument = PrtDoc.DefaultPageSettings.Margins.Clone()

            ' 印刷プレビュー画面で表示位置がハードマージン分ずれるので補正する 
            ' ※ printDocument.OriginAtMargins = true; 余白に印刷しない場合の設定 
            'PrtDoc.DefaultPageSettings.Margins.Left += marginsHard.Left
            'PrtDoc.DefaultPageSettings.Margins.Right -= marginsHard.Left
            'PrtDoc.DefaultPageSettings.Margins.Top += marginsHard.Top
            'PrtDoc.DefaultPageSettings.Margins.Bottom -= marginsHard.Top
        End If

    End Sub

    Private Sub OnEndPrint(ByVal sender As Object, ByVal e As PrintEventArgs)
        If e.PrintAction = PrintAction.PrintToPreview Then
            ' 印刷プレビュー画面のハードマージン分の表示位置の補正を元に戻す 
            ' プレビュー表示位置補正のため退避した PrintDocument のマージン値を復帰する 
            PrtDoc.DefaultPageSettings.Margins = marginsPrintDocument.Clone()
        End If
    End Sub

End Class
