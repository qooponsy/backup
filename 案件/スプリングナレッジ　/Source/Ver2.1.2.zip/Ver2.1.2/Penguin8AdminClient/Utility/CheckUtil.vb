﻿Imports System.Text.RegularExpressions

Public Class CheckUtil

    Public Shared RegExCustCode As New Regex("[0-9a-zA-Z]{1,32}")
    Public Shared RegExUserIDPassword As New Regex("^[0-9a-zA-Z]{8,16}$")
    Public Shared RegExCustPassword As New Regex("[0-9a-zA-Z]{1,256}")
    Public Shared RegExInt As New Regex("^\d{1,10}$")
    Public Shared RegExRate As New Regex("^\d{1,7}(\.\d{1,8}){0,1}$")
    Public Shared RegExPercent As New Regex("^\d{1,9}(\.\d{1,6}){0,1}$")
    Public Shared RegExMoney As New Regex("^\d{1,11}(\.\d{1,4}){0,1}$")
    Public Shared RegExSignInt As New Regex("^-{0,1}\d{1,10}$")
    Public Shared RegExSignRate As New Regex("^-{0,1}\d{1,7}(\.\d{1,8}){0,1}$")
    Public Shared RegExSignRate12 As New Regex("^-{0,1}\d{1,3}(\.\d{1,12}){0,1}$")
    Public Shared RegExRate12 As New Regex("^\d{1,3}(\.\d{1,12}){0,1}$")
    Public Shared RegExRate14 As New Regex("^\d{1,1}(\.\d{1,14}){0,1}$")

    Public Shared RegExSignPercent As New Regex("^-{0,1}\d{1,9}(\.\d{1,6}){0,1}$")
    Public Shared RegExSignMoney As New Regex("^-{0,1}\d{1,11}(\.\d{1,4}){0,1}$")

    Public Shared RegExMS As New Regex("^\d{0,3}$")

    Public Shared RegExRate0 As New Regex("^\d{1,7}$")
    Public Shared RegExRate1 As New Regex("^\d{1,7}(\.\d{1,1}){0,1}$")
    Public Shared RegExRate2 As New Regex("^\d{1,7}(\.\d{1,2}){0,1}$")
    Public Shared RegExRate3 As New Regex("^\d{1,7}(\.\d{1,3}){0,1}$")
    Public Shared RegExRate4 As New Regex("^\d{1,7}(\.\d{1,4}){0,1}$")
    Public Shared RegExRate5 As New Regex("^\d{1,7}(\.\d{1,5}){0,1}$")
    Public Shared RegExRate6 As New Regex("^\d{1,7}(\.\d{1,6}){0,1}$")
    Public Shared RegExRate7 As New Regex("^\d{1,7}(\.\d{1,7}){0,1}$")
    Public Shared RegExRate8 As New Regex("^\d{1,7}(\.\d{1,8}){0,1}$")

    Public Shared RegExSignRate3 As New Regex("^[+-]{0,1}\d{1,7}(\.\d{1,8}){0,1}$")

    Public Shared RegExNum As New Regex("[0-9]{1,}")    '数字が含まれているか
    Public Shared RegExEng As New Regex("[a-zA-Z]{1,}") '英字が含まれているか

    Public Shared RegTimeFormat1 As New Regex("^([0-1][0-9]|[2][0-3]):[0-5][0-9]$") 'hh:mm
    Public Shared RegTimeFormat2 As New Regex("^([0-1][0-9]|[2][0-3]):[0-5][0-9]:[0-5][0-9]$") 'hh:mm:ss

    Public Shared Function GetRegRateDecimalPlaces(DecimalPlaces As Integer) As Regex
        Select Case DecimalPlaces
            Case 0 : Return RegExRate0
            Case 1 : Return RegExRate1
            Case 2 : Return RegExRate2
            Case 3 : Return RegExRate3
            Case 4 : Return RegExRate4
            Case 5 : Return RegExRate5
            Case 6 : Return RegExRate6
            Case 7 : Return RegExRate7
            Case 8 : Return RegExRate8
            Case Else : Return Nothing
        End Select
    End Function

    Public Shared Function IsMatchPasswordPolicy(Passord As String) As Boolean
        If Not CheckUtil.RegExUserIDPassword.IsMatch(Passord) Then Return False
        If Not CheckUtil.RegExEng.IsMatch(Passord) Then Return False
        If Not CheckUtil.RegExNum.IsMatch(Passord) Then Return False
        Return True
    End Function

    Public Shared Function IsTimeFormatCheck(time As String) As Boolean
        If Not CheckUtil.RegTimeFormat2.IsMatch(time) Then Return False
        Return True
    End Function


End Class
