﻿Imports System.Text.RegularExpressions

Public Class DateTimeUtil

    Public Enum ComplementMode
        fromTime = 0
        toTime = 1
    End Enum

    Private Shared DB_MIN_DATETIME As DateTime = New DateTime(1753, 1, 1, 0, 0, 0, 0)
    Private Shared DB_MAX_DATETIME As DateTime = New DateTime(9999, 12, 31, 0, 0, 0, 0)

    Private Shared REGEX_YYYYMMDD As Regex = New Regex("^\d{8}")
    Private Shared REGEX_YYYYMMDDHH As Regex = New Regex("^\d{10}")
    Private Shared REGEX_YYYYMMDDHHMM As Regex = New Regex("^\d{12}")
    Private Shared REGEX_YYYYMMDDHHMMSS As Regex = New Regex("^\d{14}")
    Private Shared REGEX_YYYYMMDDHHMMSSFFF As Regex = New Regex("^\d{17}")
    Private Shared REGEX_HHMMSS As Regex = New Regex("^\d{2}[0-5]\d[0-5]\d")

    Public Shared Function ConvToDate(ByVal FromString As String, ByVal CompMode As ComplementMode, ByRef ToDate As DateTime) As Boolean
        Dim ret As Boolean = False

        If REGEX_YYYYMMDD.IsMatch(FromString) Then
            Dim yearString As String = FromString.Substring(0, 4)
            Dim monthString As String = FromString.Substring(4, 2)
            Dim dayString As String = FromString.Substring(6, 2)

            If DateTime.TryParse(yearString & "/" & monthString & "/" & dayString, ToDate) Then
                If CompMode = ComplementMode.toTime Then
                    ToDate = ToDate.AddDays(1)
                End If
                ret = True
            End If
        End If

        Return ret
    End Function

    Public Shared Function ConvToDateTime(ByVal FromString As String, ByVal CompMode As ComplementMode, ByRef ToDateTime As DateTime) As Boolean
        Dim ret As Boolean = False

        Dim yearString As String
        Dim monthString As String
        Dim dayString As String
        Dim hourString As String = "00"
        Dim minutesString As String = "00"
        Dim secondString As String = "00"
        Dim msString As String = "000"

        Dim ToType As Integer = 0
        If REGEX_YYYYMMDD.IsMatch(FromString) Then
            yearString = FromString.Substring(0, 4)
            monthString = FromString.Substring(4, 2)
            dayString = FromString.Substring(6, 2)

            If REGEX_YYYYMMDDHH.IsMatch(FromString) Then
                hourString = FromString.Substring(8, 2)
                ToType = 1
            End If
            If REGEX_YYYYMMDDHHMM.IsMatch(FromString) Then
                minutesString = FromString.Substring(10, 2)
                ToType = 2
            End If
            If REGEX_YYYYMMDDHHMMSS.IsMatch(FromString) Then
                secondString = FromString.Substring(12, 2)
                ToType = 3
            End If
            If REGEX_YYYYMMDDHHMMSSFFF.IsMatch(FromString) Then
                msString = FromString.Substring(14, 3)
                ToType = 4
            End If

            If DateTime.TryParse(yearString & "/" & monthString & "/" & dayString & " " & hourString & ":" & minutesString & ":" & secondString & "." & msString, ToDateTime) Then
                If CompMode = ComplementMode.toTime Then
                    Select Case ToType
                        Case 0
                            ToDateTime = ToDateTime.AddDays(1)
                        Case 1
                            ToDateTime = ToDateTime.AddHours(1)
                        Case 2
                            ToDateTime = ToDateTime.AddMinutes(1)
                        Case 3
                            ToDateTime = ToDateTime.AddSeconds(1)
                        Case 4
                            ToDateTime = ToDateTime.AddMilliseconds(1)
                    End Select
                End If

                Select Case ToType
                    Case 1, 2, 3, 4
                        If ToDateTime > DateTime.MinValue Then
                            ToDateTime = ToDateTime.AddMinutes(SessionService.TimeZone)
                        End If
                End Select

                ret = True
            End If
        End If

        Return ret
    End Function

    Public Shared Function ConvToServerDateTime(src As DateTime, fmt As String) As String
        Return src.AddMinutes(-SessionService.TimeZone).ToString(fmt)
    End Function

    Public Shared Function ConvToTimeSpan(ByVal FromString As String, ByVal CompMode As ComplementMode, ByRef ToTime As TimeSpan) As Boolean
        Dim ret As Boolean = False

        If REGEX_HHMMSS.IsMatch(FromString) Then
            Dim hourString As String = FromString.Substring(0, 2)
            Dim minutesString As String = FromString.Substring(2, 2)
            Dim secondString As String = FromString.Substring(4, 2)

            If TimeSpan.TryParse(hourString & ":" & minutesString & ":" & secondString, ToTime) Then
                If CompMode = ComplementMode.toTime Then
                    ToTime = ToTime.Add(New TimeSpan(0, 0, 1))
                End If
                ret = True
            End If
        End If

        Return ret
    End Function

    Public Shared Function IsDBDate(ByVal CheckTarget As DateTime) As Boolean
        Dim ret As Boolean = False

        If DB_MIN_DATETIME <= CheckTarget Then
            If DB_MAX_DATETIME > CheckTarget Then
                ret = True
            End If
        End If

        Return ret
    End Function

    ''' <summary>時間の値が正しいかの判定</summary>
    ''' <param name="DateTimeString">10文字以上のyyyymmddhhMM形式の日付</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function IsDateTimeHour(ByVal DateTimeString As String) As Boolean
        Dim iTemp As Integer = 0

        If Len(DateTimeString) >= 10 Then

            If Not Integer.TryParse(Mid(DateTimeString, 8, 2), iTemp) Then
                Return False
            End If

            If iTemp < 0 Or iTemp > 23 Then
                Return False
            End If

        End If
        Return True
    End Function

    ''' <summary>分の値が正しいかの判定</summary>
    ''' <param name="DateTimeString">12文字以上のyyyymmddhhMM形式の日付</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function IsDateTimeMinute(ByVal DateTimeString As String) As Boolean
        Dim iTemp As Integer = 0

        If Len(DateTimeString) >= 12 Then

            If Not Integer.TryParse(Mid(DateTimeString, 10, 2), iTemp) Then
                Return False
            End If

            If iTemp < 0 Or iTemp > 59 Then
                Return False
            End If

        End If
        Return True
    End Function

    Public Shared Function TimeSpanText(targetTime As DateTime, baseTime As DateTime) As String
        If targetTime < baseTime Then
            Return ""
        End If
        Dim span As TimeSpan = targetTime - baseTime
        Dim hours As Integer = Math.Floor(span.TotalHours)
        Return Right(Space(2) & CStr(hours), 3) & "時間" & Right("00" & CStr(span.Minutes), 2) & "分" & Right("00" & CStr(span.Seconds), 2) & "秒"
    End Function

    ''' <summary>
    ''' 秒Int値を時間に変換
    ''' </summary>
    ''' <param name="time">時間(秒)</param>
    ''' <returns></returns>
    Public Shared Function TimeConvView(time As Integer) As String
        Dim timeView As String = ""

        If time = 0 Then
            '0であれば空文字
        Else
            If (time / 60) Mod 60 = 0 Then
                '時間に変換
                timeView = (time / 60) / 60 & "時間"
            ElseIf time Mod 60 = 0 Then
                '分に変換
                timeView = time / 60 & "分"
            Else
                '秒に変換
                timeView = time & "秒"
            End If
        End If


        Return timeView
    End Function

End Class
