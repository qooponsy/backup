﻿Public Class ProductSpreadBulkChange

    Private Const TARGET_FORMAT As String = "スプレッド変更対象銘柄処理状況： {0} / {1}"

    Private WithEvents service As ProductSpreadUpdateService
    Private WithEvents serviceStatus As BulkTaskService

    Private Enum FormMode
        INIT = 0
        RUN = 1
        RESULT = 2
    End Enum

    Public ProductBaseCodeList As String

    Private FormModeStatus As FormMode = FormMode.INIT
    Private TaskSeq As String = ""

    Private Sub ProductSpreadBulkChange_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        lblMessage.Text = ""
        lblTarget.Text = ""
        txtChangeSpread.Text = ""
        txtMargineTime.Text = Math.Ceiling(SysSettingsService.GetData().ProductStartPreTime / 60D)
    End Sub

    Private Sub ProductSpreadBulkChange_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        service = Nothing
        serviceStatus = Nothing
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Dim ChangeSpread As Integer
        If Not Integer.TryParse(txtChangeSpread.Text, ChangeSpread) Then
            MessageBox.Show(Me, "変更スプレッドは0以上の数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        If ChangeSpread < 0 Then
            MessageBox.Show(Me, "変更スプレッドは0以上の数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim MargineTime As Integer
        If Not Integer.TryParse(txtMargineTime.Text, MargineTime) Then
            MessageBox.Show(Me, "取引開始前時間は0以上の数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        If MargineTime < 0 Then
            MessageBox.Show(Me, "取引開始前時間は0以上の数値を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        service = New ProductSpreadUpdateService
        service.Request(ChangeSpread, MargineTime * 60, ProductBaseCodeList)
        FormModeStatus = FormMode.RUN
        btnOK.Enabled = False
        txtChangeSpread.Enabled = False
        txtMargineTime.Enabled = False
        btnCancel.Text = "キャンセル"
        TaskSeq = ""
        lblMessage.Text = ""
        lblTarget.Text = ""
    End Sub

    Private Sub service_RequestCancel() Handles service.RequestCancel
        lblMessage.Text = "銘柄スプレッド一括変更処理をキャンセルしましたが、サーバー側では処理が完了している可能性があります。" + vbCrLf + "操作ログを確認してください。"
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
        txtChangeSpread.Enabled = True
        txtMargineTime.Enabled = True
        btnCancel.Text = "閉じる"
    End Sub

    Private Sub service_RequestError(ErrorMessage As String) Handles service.RequestError
        lblMessage.Text = ErrorMessage
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
        txtChangeSpread.Enabled = True
        txtMargineTime.Enabled = True
        btnCancel.Text = "閉じる"
    End Sub

    Private Sub service_RequestSuccess(code As String) Handles service.RequestSuccess
        lblMessage.Text = "銘柄スプレッド一括変更を実行中です。"
        FormModeStatus = FormMode.RESULT
        btnCancel.Text = "閉じる"

        TaskSeq = code
        timerStatus.Enabled = True
        timerStatus.Start()
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.INIT, FormMode.RESULT
                Me.Close()
            Case FormMode.RUN
                service.CancelRequest()
        End Select
    End Sub

    Private Sub timerStatus_Tick(sender As System.Object, e As System.EventArgs) Handles timerStatus.Tick
        timerStatus.Stop()
        If TaskSeq = "" Then
            Exit Sub
        End If

        serviceStatus = New BulkTaskService()
        serviceStatus.Read(TaskSeq)
    End Sub

    Private Sub serviceStatus_ReadCancel() Handles serviceStatus.ReadCancel
        serviceStatus = Nothing
        lblMessage.Text = "銘柄スプレッド一括変更の処理状況が確認できませんでした。" + vbCrLf + "操作ログを確認してください。"
        If TaskSeq = "" Then
            Exit Sub
        End If
        timerStatus.Start()
    End Sub

    Private Sub serviceStatus_ReadError(ErrorMessage As String) Handles serviceStatus.ReadError
        serviceStatus = Nothing
        lblMessage.Text = "銘柄スプレッド一括変更の処理状況が確認できませんでした。" + vbCrLf + "操作ログを確認してください。"
        If TaskSeq = "" Then
            Exit Sub
        End If
        timerStatus.Start()
    End Sub

    Private Sub serviceStatus_ReadSuccess(item As BulkTaskData) Handles serviceStatus.ReadSuccess
        timerStatus.Start()
        Select Case item.TaskStatus
            Case "0"
                lblTarget.Text = ""
            Case "1"
                lblTarget.Text = String.Format(TARGET_FORMAT, item.ExecStep, item.LastStep)
            Case "2"
                timerStatus.Stop()
                timerStatus.Enabled = False
                lblMessage.Text = "銘柄スプレッド一括変更処理が完了しました。"
                lblTarget.Text = String.Format(TARGET_FORMAT, item.ExecStep, item.LastStep)
            Case "3"
                timerStatus.Stop()
                timerStatus.Enabled = False
                lblMessage.Text = "銘柄スプレッド一括変更処理がエラーで中断しました。" + vbCrLf + "操作ログを確認してください。"
                lblTarget.Text = String.Format(TARGET_FORMAT, item.ExecStep, item.LastStep)
        End Select
    End Sub

End Class
