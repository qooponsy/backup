﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductSpreadBulkChange
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.lblTarget = New System.Windows.Forms.Label()
        Me.txtChangeSpread = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtMargineTime = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.timerStatus = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(18, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(381, 43)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "銘柄設定一覧画面にて「変更」欄で選択した銘柄設定に対応する銘柄の内、取引開始されていない銘柄のスプレッドを一括で更新します。対象となる銘柄の数が多い場合、処理の完" & _
    "了までに時間がかかる場合があります。"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(291, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "取引開始されていない銘柄のスプレッドを一括で変更します。"
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(226, 193)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(95, 29)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(96, 193)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(94, 29)
        Me.btnOK.TabIndex = 4
        Me.btnOK.Text = "実行"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'lblMessage
        '
        Me.lblMessage.Location = New System.Drawing.Point(24, 144)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(369, 36)
        Me.lblMessage.TabIndex = 8
        '
        'lblTarget
        '
        Me.lblTarget.Location = New System.Drawing.Point(62, 115)
        Me.lblTarget.Name = "lblTarget"
        Me.lblTarget.Size = New System.Drawing.Size(293, 26)
        Me.lblTarget.TabIndex = 10
        Me.lblTarget.Text = "スプレッド変更対象銘柄処理状況： 52 / 200"
        Me.lblTarget.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtChangeSpread
        '
        Me.txtChangeSpread.Location = New System.Drawing.Point(118, 81)
        Me.txtChangeSpread.MaxLength = 16
        Me.txtChangeSpread.Name = "txtChangeSpread"
        Me.txtChangeSpread.Size = New System.Drawing.Size(58, 19)
        Me.txtChangeSpread.TabIndex = 12
        Me.txtChangeSpread.Text = "5"
        Me.txtChangeSpread.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblPassword
        '
        Me.lblPassword.Location = New System.Drawing.Point(32, 80)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(93, 21)
        Me.lblPassword.TabIndex = 11
        Me.lblPassword.Text = "変更スプレッド"
        Me.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtMargineTime
        '
        Me.txtMargineTime.Location = New System.Drawing.Point(299, 81)
        Me.txtMargineTime.MaxLength = 16
        Me.txtMargineTime.Name = "txtMargineTime"
        Me.txtMargineTime.Size = New System.Drawing.Size(40, 19)
        Me.txtMargineTime.TabIndex = 14
        Me.txtMargineTime.Text = "1"
        Me.txtMargineTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(200, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 21)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "取引開始前時間"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(345, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 21)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "分"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'timerStatus
        '
        Me.timerStatus.Interval = 1000
        '
        'ProductSpreadBulkChange
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(417, 240)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtMargineTime)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtChangeSpread)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblTarget)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ProductSpreadBulkChange"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "銘柄スプレッド一括変更"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents lblTarget As System.Windows.Forms.Label
    Friend WithEvents txtChangeSpread As System.Windows.Forms.TextBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents txtMargineTime As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents timerStatus As System.Windows.Forms.Timer
End Class
