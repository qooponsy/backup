﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductTradeMoneyBulkChange
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtTradeMoneyMax = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtTradeMoneyMin = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblTarget = New System.Windows.Forms.Label()
        Me.lblMessage = New System.Windows.Forms.Label()
        Me.timerStatus = New System.Windows.Forms.Timer(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.chkChangeProductBase = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'txtTradeMoneyMax
        '
        Me.txtTradeMoneyMax.Location = New System.Drawing.Point(230, 153)
        Me.txtTradeMoneyMax.MaxLength = 16
        Me.txtTradeMoneyMax.Name = "txtTradeMoneyMax"
        Me.txtTradeMoneyMax.Size = New System.Drawing.Size(58, 19)
        Me.txtTradeMoneyMax.TabIndex = 25
        Me.txtTradeMoneyMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(144, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 21)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "最大取引額"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtTradeMoneyMin
        '
        Me.txtTradeMoneyMin.Location = New System.Drawing.Point(230, 130)
        Me.txtTradeMoneyMin.MaxLength = 16
        Me.txtTradeMoneyMin.Name = "txtTradeMoneyMin"
        Me.txtTradeMoneyMin.Size = New System.Drawing.Size(58, 19)
        Me.txtTradeMoneyMin.TabIndex = 23
        Me.txtTradeMoneyMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblPassword
        '
        Me.lblPassword.Location = New System.Drawing.Point(144, 129)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(93, 21)
        Me.lblPassword.TabIndex = 22
        Me.lblPassword.Text = "最小取引額"
        Me.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTarget
        '
        Me.lblTarget.Location = New System.Drawing.Point(66, 220)
        Me.lblTarget.Name = "lblTarget"
        Me.lblTarget.Size = New System.Drawing.Size(293, 26)
        Me.lblTarget.TabIndex = 21
        Me.lblTarget.Text = "最小最大取引額変更対象銘柄処理状況： 52 / 200"
        Me.lblTarget.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMessage
        '
        Me.lblMessage.Location = New System.Drawing.Point(28, 249)
        Me.lblMessage.Name = "lblMessage"
        Me.lblMessage.Size = New System.Drawing.Size(369, 36)
        Me.lblMessage.TabIndex = 20
        '
        'timerStatus
        '
        Me.timerStatus.Interval = 1000
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(22, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(381, 59)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "銘柄設定一覧画面にて「変更」欄で選択した銘柄設定とその設定より作成された銘柄データの内、取引が完了されていない有効銘柄の最小最大取引額を一括で更新します。対象とな" & _
    "る銘柄の数が多い場合、処理の完了までに時間がかかる場合があります。"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(22, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(375, 34)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "銘柄設定とその設定より作成された銘柄データの最大取引額と最小取引額を一括で変更します。"
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(230, 298)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(95, 29)
        Me.btnCancel.TabIndex = 17
        Me.btnCancel.Text = "キャンセル"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(100, 298)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(94, 29)
        Me.btnOK.TabIndex = 16
        Me.btnOK.Text = "実行"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'chkChangeProductBase
        '
        Me.chkChangeProductBase.AutoSize = True
        Me.chkChangeProductBase.Location = New System.Drawing.Point(146, 183)
        Me.chkChangeProductBase.Name = "chkChangeProductBase"
        Me.chkChangeProductBase.Size = New System.Drawing.Size(166, 16)
        Me.chkChangeProductBase.TabIndex = 26
        Me.chkChangeProductBase.Text = "変更を銘柄設定にも反映する"
        Me.chkChangeProductBase.UseVisualStyleBackColor = True
        '
        'ProductTradeMoneyBulkChange
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(425, 340)
        Me.Controls.Add(Me.chkChangeProductBase)
        Me.Controls.Add(Me.txtTradeMoneyMax)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtTradeMoneyMin)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.lblTarget)
        Me.Controls.Add(Me.lblMessage)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.Name = "ProductTradeMoneyBulkChange"
        Me.Text = "最小最大取引額一括変更"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtTradeMoneyMax As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtTradeMoneyMin As System.Windows.Forms.TextBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblTarget As System.Windows.Forms.Label
    Friend WithEvents lblMessage As System.Windows.Forms.Label
    Friend WithEvents timerStatus As System.Windows.Forms.Timer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents chkChangeProductBase As System.Windows.Forms.CheckBox
End Class
