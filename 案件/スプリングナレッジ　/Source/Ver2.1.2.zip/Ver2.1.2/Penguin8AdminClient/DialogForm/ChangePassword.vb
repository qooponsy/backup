﻿Public Class ChangePassword

    Private WithEvents service As UserService

    Private id As String
    Private password As String
    Private passwordExpiredFlg As Boolean = False

    Public ChangeSuccess As Boolean = False
    Public NewPassword As String

    Private Enum FormMode
        INIT = 0
        RUN = 1
        RESULT = 2
    End Enum

    Private FormModeStatus As FormMode = FormMode.INIT

    Private Sub ChangePassword_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If passwordExpiredFlg Then
            txtPassword.Text = password
        End If
    End Sub

    Private Sub ChangePassword_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        service = Nothing
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        If Not checkInput() Then Exit Sub

        service = New UserService
        If passwordExpiredFlg Then
            ' パスワード有効期限切れ後のパスワード変更
            service.ChangeExpiredPassword(id, txtPassword.Text, txtPasswordNew.Text)
            FormModeStatus = FormMode.RUN
            btnOK.Enabled = False
        Else
            ' ログイン後のパスワード変更
            service.ChangePassword(txtPassword.Text, txtPasswordNew.Text)
            FormModeStatus = FormMode.RUN
            btnOK.Enabled = False
        End If
        
    End Sub

    Private Sub service_ChangeExpiredPasswordCancel() Handles service.ChangeExpiredPasswordCancel
        service = Nothing
        lblMessage.Text = "パスワード変更をキャンセルしましたが、サーバー側では処理が完了している可能性があります。"
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_ChangeExpiredPasswordError(ErrorMessage As String) Handles service.ChangeExpiredPasswordError
        service = Nothing
        lblMessage.Text = ErrorMessage
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_ChangeExpiredPasswordSuccess() Handles service.ChangeExpiredPasswordSuccess
        service = Nothing
        ChangeSuccess = True
        NewPassword = txtPasswordNew.Text
        Me.Close()
    End Sub

    Private Sub service_ChangePasswordCancel() Handles service.ChangePasswordCancel
        service = Nothing
        lblMessage.Text = "パスワード変更をキャンセルしましたが、サーバー側では処理が完了している可能性があります。"
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_ChangePasswordError(ErrorMessage As String) Handles service.ChangePasswordError
        service = Nothing
        lblMessage.Text = ErrorMessage
        FormModeStatus = FormMode.INIT
        btnOK.Enabled = True
    End Sub

    Private Sub service_ChangePasswordSuccess() Handles service.ChangePasswordSuccess
        service = Nothing
        lblMessage.Text = "パスワードを変更しました。"
        FormModeStatus = FormMode.RESULT
        btnCancel.Text = "閉じる"
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Select Case FormModeStatus
            Case FormMode.INIT, FormMode.RESULT
                service = Nothing
                Me.Close()
            Case FormMode.RUN
                If service IsNot Nothing Then
                    service.CancelRegist()
                End If
        End Select
    End Sub

    Private Function checkInput() As Boolean
        If Me.txtPassword.Text.Length = 0 Then
            MessageBox.Show(Me, "現在のパスワードを入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        '--
        If Me.txtPasswordNew.Text.Length = 0 Then
            MessageBox.Show(Me, "新しいパスワードを入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.IsMatchPasswordPolicy(Me.txtPasswordNew.Text) Then
            MessageBox.Show(Me, "新しいパスワードはパスワードポリシーを満たしていません。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        '--
        If Me.txtPasswordVerify.Text.Length = 0 Then
            MessageBox.Show(Me, "新しいパスワードの確認を入力してください。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        If Not CheckUtil.IsMatchPasswordPolicy(Me.txtPasswordVerify.Text) Then
            MessageBox.Show(Me, "新しいパスワードの確認はパスワードポリシーを満たしていません。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        '--
        If txtPasswordNew.Text <> txtPasswordVerify.Text Then
            MessageBox.Show(Me, "新しいパスワードと新しいパスワードの確認が一致しません。", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
        Return True
    End Function

    Public Sub SetUserData(ByVal userId As String, ByVal userPass As String)
        id = userId
        password = userPass
        passwordExpiredFlg = True
    End Sub

End Class