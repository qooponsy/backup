﻿Public Class DownloadReportProgressStatus
    Public Property Message As String
    Public Property Total As Integer
    Public Property Count As Integer
    Public Property Service As ReportDownloadService
    Public Property Cancel As Boolean = False
    Public Property ParentSubForm As Form

    Private Sub Progress()
        Count += 1
    End Sub

    Private Sub SetStatus(text As String)
        Invoke(
            Sub()
                lblStatus.Text = Count & " / " & Total & "件"
            End Sub)
    End Sub

    Public Sub Init(total As Integer)
        pbStatus.Maximum = total
        pbStatus.Minimum = 0
        Me.Total = total
        Me.Count = 0
        lblStatus.Text = Count & " / " & total & "件"
    End Sub

    Public Sub Progres()
        Count += 1
        lblStatus.Text = Count & " / " & Total & "件"
        pbStatus.Value = Count

        FormRefresh()
    End Sub

    Public Sub EndDownload()
        'MessageBox.Show(Me, "ダウンロードが完了しました", My.Application.Info.Title, MessageBoxButtons.OK)
        Me.Close()
    End Sub

    Private Sub FormRefresh()
        lblStatus.Refresh()
        pbStatus.Refresh()
    End Sub

    Private Sub DownloadReportProgressStatus_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.Location = New Point(ParentSubForm.Location.X + (ParentSubForm.Size.Width - Me.Size.Width) / 2, ParentSubForm.Location.Y + (ParentSubForm.Size.Height - Me.Size.Height) / 2)
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        btnCancel.Enabled = False
        Cancel = True
        Service.CancelDownload()
    End Sub

    Private Sub DownloadProgressStatus_FormClosed(sender As Object, e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        If Not Cancel Then
            Cancel = True
            Service.CancelDownload()
        End If
    End Sub

End Class