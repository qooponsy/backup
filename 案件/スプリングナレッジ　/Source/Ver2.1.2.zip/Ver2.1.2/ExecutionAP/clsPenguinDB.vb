﻿Imports System.IO
Imports System.Text
Imports System.Data.SqlClient

'------------------------------------------------------------------------------
'
'------------------------------------------------------------------------------
Public Class clsPenguinDB
    Private ConnDB As SqlConnection
    Private strError As String
    Private blnError As Boolean

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Class SeqCounterCode
        Public Const Rate As String = "01"
        Public Const Chart As String = "02"
        Public Const ProductBase As String = "03"
        Public Const Product As String = "04"
        Public Const Trade As String = "05"
        Public Const Cash As String = "06"
        Public Const Task As String = "07"
    End Class

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetSqlConnection(ByVal sConnectString As String) As Boolean
        Dim Result As Boolean

        strError = ""
        Result = True
        blnError = False
        Try
            ConnDB = New SqlConnection(sConnectString)
            ConnDB.Open()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSqlConnection," & ex.Message
            ConnDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function EndSqlConnection() As Boolean
        Dim Result As Boolean

        Result = True
        Try
            ConnDB.Close()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "EndSqlConnection," & ex.Message
            blnError = True
            Result = False
        End Try
        ConnDB = Nothing

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetSysDate() As Date
        Dim SysDate As Date
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        strSQL = ""
        strSQL = strSQL & "Select SysDate from S_SysStatus where SysCode='0'"

        SysDate = Nothing
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            SysDate = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSysDate," & ex.Message
            blnError = True
            CmdDB = Nothing
        End Try

        Return SysDate
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetSeqCounterSysDate(ByVal CounterCode As String) As String
        Dim NewCounter As String
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        strSQL = "declare @Counter int" & vbCrLf
        strSQL = strSQL & "begin tran" & vbCrLf
        strSQL = strSQL & "select @Counter = [Counter] from [S_Counter] with (updlock) where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "update [S_Counter] set [Counter] = @Counter + 1 where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "select convert(char(8), [SysDate], 112) + replicate('0' ,9 - len(@Counter)) + convert(varchar(9),@Counter) from [S_SysStatus] where [SysCode] = '0'" & vbCrLf
        strSQL = strSQL & "commit tran"

        NewCounter = ""
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@CounterCode", SqlDbType.Char, 2).Value = CounterCode
            NewCounter = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSeqCounterSysDate," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return NewCounter
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetRateViewSeq(ByVal CounterCode As String, ByVal ComCode As String) As Integer
        Dim NewCounter As Integer
        Dim CmdDB As SqlCommand
        Dim strSQL As New StringBuilder

        strSQL.AppendLine("begin tran")
        strSQL.AppendLine("select @Counter = [Counter] from [S_CounterComCode] with (updlock) where [CounterCode] = @CounterCode and [ComCode] = @ComCode")
        strSQL.AppendLine("update [S_CounterComCode] set [Counter] = @Counter + 1 where [CounterCode] = @CounterCode and [ComCode] = @ComCode")
        strSQL.AppendLine("commit tran")

        NewCounter = -1
        Try
            CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            Dim param As SqlParameter
            param = CmdDB.Parameters.Add("@Counter", SqlDbType.Int)
            param.Direction = ParameterDirection.Output
            CmdDB.Parameters.Add("@CounterCode", SqlDbType.Char, 2).Value = CounterCode
            CmdDB.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ComCode
            CmdDB.ExecuteNonQuery()

            NewCounter = CmdDB.Parameters("@Counter").Value

            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetRateViewSeq," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return NewCounter
    End Function

    '--------------------------------------------------------------------------
    ' 通貨ペアリスト取得　※未使用　AnyTime対応
    '--------------------------------------------------------------------------
    Public Function GetCurrencyPairList(ByRef ListData As DataTable) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String
        Dim ListRow As DataRow

        ListData = Nothing

        Result = True
        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("ComCode"))
            ListData.Columns.Add(New DataColumn("ComName"))
            ListData.Columns.Add(New DataColumn("DecimalPlaces"))
            ListData.Columns.Add(New DataColumn("EnableTime"))

            strSQL = "SELECT * From M_CurrencyPair"
            strSQL = strSQL & " Order by SortOrder"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                ListRow = ListData.NewRow()
                ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                ListRow.Item("ComName") = GetDbString(Reader.Item("ComName"))
                ListRow.Item("DecimalPlaces") = GetDbInt(Reader.Item("DecimalPlaces"))
                ListRow.Item("EnableTime") = GetDbInt(Reader.Item("EnableTime"))
                ListData.Rows.Add(ListRow)
                ListRow = Nothing
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetCurrencyPairList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 行使対象銘柄の抽出（銘柄リスト作成）
    '--------------------------------------------------------------------------
    Public Function GetExecutionProductList(ByRef ListData As DataTable) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String
        Dim ListRow As DataRow

        ListData = Nothing

        Result = True
        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("ProductCode"))
            ListData.Columns.Add(New DataColumn("ComCode"))
            ListData.Columns.Add(New DataColumn("ExercTime"))
            ListData.Columns.Add(New DataColumn("ExercStatus"))

            strSQL = "Select * From M_Product with (nolock) Where ExercTime <= SYSUTCDATETIME() And Enabled='1' And ExercStatus In ('0','1')"
            strSQL = strSQL & " Order by ExercTime"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                ListRow = ListData.NewRow()
                ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                ListRow.Item("ProductCode") = GetDbString(Reader.Item("ProductCode"))
                ListRow.Item("ExercStatus") = GetDbString(Reader.Item("ExercStatus"))
                ListRow.Item("ExercTime") = Reader.Item("ExercTime")
                ListData.Rows.Add(ListRow)
                ListRow = Nothing
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetExecutionProductList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 行使時レートの確定
    '--------------------------------------------------------------------------
    Public Function GetExecutionRate(ByVal sComCode As String, ByVal ExercTime As Date, ByRef ListData As DataTable) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim ListRow As DataRow = Nothing
        Dim bExecRate As Boolean
        Dim oRateSeq As Object

        ListData = Nothing
        oRateSeq = Nothing

        Result = True
        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("ComCode"))
            ListData.Columns.Add(New DataColumn("RateSeq"))
            ListData.Columns.Add(New DataColumn("RateTime"))
            ListData.Columns.Add(New DataColumn("RateTimeSource"))
            ListData.Columns.Add(New DataColumn("Rate"))

            bExecRate = False

            Dim SQL As New StringBuilder
            SQL.AppendLine("Select Top 1 * From T_RateHist")
            SQL.AppendLine("Where ComCode=@ComCode And RateTime = @ExercTime And Enabled='1'")
            SQL.AppendLine("Order By RateSeq")
            SQL.AppendLine("If @@ROWCOUNT = 0")
            SQL.AppendLine("Begin")
            SQL.AppendLine("    Select Top 1 * From T_RateHist")
            SQL.AppendLine("    Where ComCode=@ComCode And RateTime > @ExercTime And Enabled='1'")
            SQL.AppendLine("    Order By RateTime,RateSeq")
            SQL.AppendLine("    If @@ROWCOUNT = 1")
            SQL.AppendLine("    Begin")
            SQL.AppendLine("        Select Top 1 * From T_RateHist")
            SQL.AppendLine("        Where ComCode=@ComCode And RateTime < @ExercTime And Enabled='1'")
            SQL.AppendLine("        Order By RateTime Desc,RateSeq Desc")
            SQL.AppendLine("    End")
            SQL.AppendLine("End")

            CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = sComCode
            CmdDB.Parameters.Add("@ExercTime", SqlDbType.DateTime2, 7).Value = ExercTime
            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            If Reader.Read = True Then
                ListRow = ListData.NewRow()
                ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                ListRow.Item("RateSeq") = GetDbString(Reader.Item("RateSeq"))
                ListRow.Item("RateTime") = Reader.Item("RateTime")
                ListRow.Item("RateTimeSource") = Reader.Item("RateTimeSource")
                ListRow.Item("Rate") = Reader.Item("Rate")
                bExecRate = True
            Else
                If Reader.NextResult() Then
                    If Reader.Read = True Then
                        ListRow = ListData.NewRow()
                        ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                        ListRow.Item("RateSeq") = GetDbString(Reader.Item("RateSeq"))
                        ListRow.Item("RateTime") = Reader.Item("RateTime")
                        ListRow.Item("RateTimeSource") = Reader.Item("RateTimeSource")
                        ListRow.Item("Rate") = Reader.Item("Rate")
                        bExecRate = True
                    End If
                End If

                If bExecRate = True Then
                    If Reader.NextResult() Then
                        If Reader.Read = True Then
                            ListRow = ListData.NewRow()
                            ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                            ListRow.Item("RateSeq") = GetDbString(Reader.Item("RateSeq"))
                            ListRow.Item("RateTime") = Reader.Item("RateTime")
                            ListRow.Item("RateTimeSource") = Reader.Item("RateTimeSource")
                            ListRow.Item("Rate") = Reader.Item("Rate")
                        End If
                    End If
                End If
            End If

            If bExecRate = True Then
                ListData.Rows.Add(ListRow)
            End If

            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing

            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetExecutionRate," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 行使時レートの更新
    '--------------------------------------------------------------------------
    Public Function UpdateExecutionRate(ByVal sComCode As String, ByVal sRateSeq As String, ByVal ExercTime As Date, ByVal sViewSeq As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "Update T_RateHist Set Exerc='1',ExercTime=@ExercTime, ViewSeq=@ViewSeq, UpdTime=SYSUTCDATETIME(), UpdUser=@UpdUser Where RateSeq=@RateSeq" & vbCrLf
        strSQL = strSQL & "Insert Into T_RateHistExerc Select * from T_RateHist Where RateSeq=@RateSeq" & vbCrLf

        If Not IsError() Then

            Try
                Try
                    CmdDB = New SqlCommand(strSQL, ConnDB)
                    CmdDB.CommandTimeout = My.Settings.CommandTimeout
                    CmdDB.CommandType = CommandType.Text
                    CmdDB.Parameters.Add("@RateSeq", SqlDbType.Char, 17).Value = sRateSeq
                    CmdDB.Parameters.Add("@ExercTime", SqlDbType.DateTime2, 7).Value = ExercTime
                    CmdDB.Parameters.Add("@ViewSeq", SqlDbType.VarChar, 25).Value = sViewSeq
                    CmdDB.Parameters.Add("@UpdUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                    CmdDB.ExecuteNonQuery()
                Catch ex As SqlException
                    ' UniqueKEY違反(2627)以外をエラーとする
                    If ex.Number <> 2627 Then
                        Throw
                    End If
                End Try
                CmdDB = Nothing
                SystemLog.DBSuccess()
            Catch ex As Exception
                SystemLog.DBError(ex)
                strError = "UpdateExecutionRate," & ex.Message
                bUpdate = False
                CmdDB = Nothing
                blnError = True
            End Try
        End If

        Return bUpdate
    End Function

    '--------------------------------------------------------------------------
    ' 銘柄の行使ステータスの更新 ※未使用　AnyTime対応
    '--------------------------------------------------------------------------
    Public Function UpdateExecutionStatus(ByVal sProductCode As String, ByVal sRateSeq As String, ByVal ExercRate As Decimal) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "Update [M_Product] Set [ExercStatus]='1',[ExercRateSeq]=@RateSeq,[ExercRate]=@ExercRate, [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@UpdUser Where [ProductCode]=@ProductCode" & vbCrLf
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = sProductCode
            CmdDB.Parameters.Add("@RateSeq", SqlDbType.Char, 17).Value = sRateSeq
            CmdDB.Parameters.Add("@ExercRate", SqlDbType.Decimal).Value = ExercRate
            CmdDB.Parameters.Add("@UpdUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateExecutionStatus," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    '--------------------------------------------------------------------------
    ' 取引の行使ステータスの更新(行使失敗)
    '--------------------------------------------------------------------------
    Public Function UpdateTradeExecutionStatusError(ByVal sTradeSeq As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "Update [T_Trade] Set [ExercStatus]='3', [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@UpdUser Where [TradeSeq]=@TradeSeq" & vbCrLf
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@TradeSeq", SqlDbType.Char, 17).Value = sTradeSeq
            CmdDB.Parameters.Add("@UpdUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateExecutionStatusError," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    '--------------------------------------------------------------------------
    ' 銘柄の行使ステータスの更新(行使失敗)
    '--------------------------------------------------------------------------
    Public Function UpdateProductExecutionStatusError(ByVal sProductCode As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "Update [M_Product] Set [ExercStatus]='3', [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@UpdUser Where [ProductCode]=@ProductCode" & vbCrLf
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = sProductCode
            CmdDB.Parameters.Add("@UpdUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateExecutionStatusError," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    '--------------------------------------------------------------------------
    ' 銘柄の行使終了ステータスの更新
    '--------------------------------------------------------------------------
    Public Function EndExecutionProduct(ByVal sProductCode As String, ByVal sRateSeq As String, ByVal ExercRate As Decimal) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = My.Resources.SQL_Product_ExercEnd
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = sProductCode
            CmdDB.Parameters.Add("@ExercStatus", SqlDbType.Char, 1).Value = "2"
            CmdDB.Parameters.Add("@TradeStatusITM", SqlDbType.Char, 2).Value = "10"
            CmdDB.Parameters.Add("@TradeStatusATM", SqlDbType.Char, 2).Value = "13"
            CmdDB.Parameters.Add("@TradeStatusOTM", SqlDbType.Char, 2).Value = "12"
            CmdDB.Parameters.Add("@RateSeq", SqlDbType.Char, 17).Value = sRateSeq
            CmdDB.Parameters.Add("@ExercRate", SqlDbType.Decimal).Value = ExercRate
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "EndExecutionProduct," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    '--------------------------------------------------------------------------
    ' 取引明細リスト作成　※未使用　AnyTime対応
    '--------------------------------------------------------------------------
    Public Function GetTradeList(ByVal sProductCode As String, ByRef ListData As DataTable) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String
        Dim ListRow As DataRow

        ListData = Nothing

        Result = True
        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("TradeSeq"))
            ListData.Columns.Add(New DataColumn("TradeSubSeq"))
            ListData.Columns.Add(New DataColumn("TradeType"))
            ListData.Columns.Add(New DataColumn("ExercPrice"))
            ListData.Columns.Add(New DataColumn("CurCode"))
            ListData.Columns.Add(New DataColumn("Premium"))
            ListData.Columns.Add(New DataColumn("PayoutRate"))
            ListData.Columns.Add(New DataColumn("CustCode"))
            ListData.Columns.Add(New DataColumn("CmpCode"))

            strSQL = "Select * From T_Trade Where ProductCode=@ProductCode and TradeStatus='02'"
            strSQL = strSQL & " Order by TradeSeq,TradeSubSeq"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.VarChar, 17).Value = sProductCode

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                ListRow = ListData.NewRow()
                ListRow.Item("TradeSeq") = GetDbString(Reader.Item("TradeSeq"))
                ListRow.Item("TradeSubSeq") = GetDbInt(Reader.Item("TradeSubSeq"))
                ListRow.Item("TradeType") = GetDbString(Reader.Item("TradeType"))
                ListRow.Item("ExercPrice") = Reader.Item("ExercPrice")
                ListRow.Item("CurCode") = Reader.Item("CurCode")
                ListRow.Item("Premium") = Reader.Item("Premium")
                ListRow.Item("PayoutRate") = Reader.Item("PayoutRate")
                ListRow.Item("CustCode") = GetDbString(Reader.Item("CustCode"))
                ListRow.Item("CmpCode") = GetDbString(Reader.Item("CmpCode"))
                ListData.Rows.Add(ListRow)
                ListRow = Nothing
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetTradeList," & ex.Message
            blnError = True
            Reader = Nothing
            CmdDB = Nothing
            Result = False
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 行使のＤＢ更新
    '--------------------------------------------------------------------------
    Public Function UpdateExecution(ByRef ExecData As clsExecutionData) As Boolean
        Dim bExec As Boolean = False

        Dim CashCode As String = GetSeqCounterSysDate(SeqCounterCode.Cash)
        If Not IsError() Then
            Try
                Using cmd As SqlCommand = ConnDB.CreateCommand()
                    cmd.CommandTimeout = My.Settings.CommandTimeout
                    cmd.CommandText = My.Resources.SQL_Trade_Exerc

                    Dim param As SqlParameter
                    param = cmd.Parameters.Add("@ErrorCode", SqlDbType.Int)
                    param.Direction = ParameterDirection.Output
                    cmd.Parameters.Add("@TradeSeq", SqlDbType.Char, 17).Value = ExecData.TradeSeq
                    cmd.Parameters.Add("@TradeStatus", SqlDbType.Char, 2).Value = ExecData.TradeStatus
                    param = cmd.Parameters.Add("@ExercPayoutRate", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 8
                    param.Value = ExecData.ExercPayoutRate
                    param = cmd.Parameters.Add("@PAndL", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 4
                    param.Value = ExecData.PAndL
                    cmd.Parameters.Add("@TradeStatusPrev", SqlDbType.Char, 2).Value = "02"
                    cmd.Parameters.Add("@ExercRateSeq", SqlDbType.Char, 17).Value = ExecData.ExercRateSeq
                    cmd.Parameters.Add("@ExercRateTime", SqlDbType.DateTime2, 7).Value = ExecData.ExercRateTime
                    cmd.Parameters.Add("@ExercRateTimeSource", SqlDbType.DateTime2, 7).Value = ExecData.ExercRateTimeSource
                    param = cmd.Parameters.Add("@ExercRate", SqlDbType.Decimal)
                    param.Precision = 15
                    param.Scale = 8
                    param.Value = ExecData.ExercRate
                    cmd.Parameters.Add("@ExercStatus", SqlDbType.Char, 1).Value = "2"   '行使済み
                    cmd.Parameters.Add("@ViewSeq", SqlDbType.VarChar, 25).Value = ExecData.ViewSeq
                    cmd.Parameters.Add("@CashCode", SqlDbType.Char, 17).Value = CashCode
                    cmd.Parameters.Add("@CashType", SqlDbType.Char, 2).Value = ExecData.CashType
                    cmd.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = ExecData.UserID

                    cmd.ExecuteNonQuery()

                    Dim retValue As Integer = cmd.Parameters("@ErrorCode").Value
                    Select Case retValue
                        Case 0
                        Case 1
                            strError = "UpdateExecution,無効な取引番号"
                            blnError = True
                        Case 2
                            strError = "UpdateExecution,行使処理済み"
                            blnError = True
                        Case 3
                            strError = "UpdateExecution,行使処理済み取引ステータス異常"
                            blnError = True
                        Case Else
                            strError = "UpdateExecution,その他エラー"
                            blnError = True
                    End Select
                    bExec = True
                End Using
                SystemLog.DBSuccess()
            Catch ex As Exception
                SystemLog.DBError(ex)
                strError = "UpdateExecution," & ex.Message
                blnError = True
                bExec = False
            End Try
        End If

        Return bExec
    End Function

    '--------------------------------------------------------------------------
    '　※未使用
    '--------------------------------------------------------------------------
    Public Function CheckWorkDay(ByVal WorkDate As DateTime) As Boolean
        Dim CmdDB As SqlCommand
        Dim Result As Boolean = False
        Dim strSQL As New StringBuilder

        Result = False
        Try
            strSQL.AppendLine("declare @work char(1)")
            strSQL.AppendLine("declare @holiday date")
            strSQL.AppendLine("select @work = [Work] from [M_Weekday] where [WeekDay] = DATEPART(weekday, @workdate)")
            strSQL.AppendLine("if @work = '1'")
            strSQL.AppendLine("begin")
            strSQL.AppendLine("    select @holiday = [Holiday] from [M_Holiday] where [Holiday] = @workdate")
            strSQL.AppendLine("    if @@ROWCOUNT <> 0")
            strSQL.AppendLine("        set @work = '0'")
            strSQL.AppendLine("end")
            strSQL.AppendLine("select @work")
            CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@workdate", SqlDbType.Date).Value = WorkDate
            CmdDB.Prepare()
            Dim work As String = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            If work = "1" Then
                Result = True
            End If
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "CheckWorkDay," & ex.Message
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '　※未使用
    '--------------------------------------------------------------------------
    Public Function GetNextDate(ByVal WorkDate As DateTime) As DateTime
        Dim CmdDB As SqlCommand
        Dim Result As DateTime
        Dim strSQL As New StringBuilder

        Try
            strSQL.AppendLine("declare @work char(1)")
            strSQL.AppendLine("declare @holiday date")
            strSQL.AppendLine("while 1=1")
            strSQL.AppendLine("begin")
            strSQL.AppendLine("    select @work = [Work] from [M_Weekday] where [WeekDay] = DATEPART(weekday, @workdate)")
            strSQL.AppendLine("    if @work = '1'")
            strSQL.AppendLine("    begin")
            strSQL.AppendLine("        select @holiday = [Holiday] from [M_Holiday] where [Holiday] = @workdate")
            strSQL.AppendLine("        if @@ROWCOUNT = 0")
            strSQL.AppendLine("            break")
            strSQL.AppendLine("    end")
            strSQL.AppendLine("    set @workdate = DATEADD(day, 1, @workdate)")
            strSQL.AppendLine("end")
            strSQL.AppendLine("select @workdate")
            CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@workdate", SqlDbType.Date).Value = WorkDate
            CmdDB.Prepare()
            Result = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetNextDate," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetCurrency() As Dictionary(Of String, Integer)
        Dim ret As New Dictionary(Of String, Integer)
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        strSQL = ""
        strSQL = strSQL & "Select * from [M_Currency] with ( nolock )"

        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            Using reader As SqlDataReader = CmdDB.ExecuteReader()
                While reader.Read
                    ret.Add(reader("CurCode"), reader("DecimalPlaces"))
                End While
                reader.Close()
            End Using
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetCurrency," & ex.Message
            blnError = True
            CmdDB = Nothing
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetCurrencyPair() As Dictionary(Of String, DataTable)
        Dim ret As New Dictionary(Of String, DataTable)
        Dim CmdDB As SqlCommand
        Dim strSQL As String
        Dim ListData As DataTable
        Dim ListRow As DataRow
        Dim Reader As SqlDataReader

        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("ComCode"))
            ListData.Columns.Add(New DataColumn("ComName"))
            ListData.Columns.Add(New DataColumn("DecimalPlaces"))
            ListData.Columns.Add(New DataColumn("EnableTime"))

            strSQL = "SELECT * From M_CurrencyPair"
            strSQL = strSQL & " Order by SortOrder"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                ListRow = ListData.NewRow()
                Dim comCode As String = GetDbString(Reader.Item("ComCode"))
                ListRow.Item("ComCode") = comCode
                ListRow.Item("ComName") = GetDbString(Reader.Item("ComName"))
                ListRow.Item("DecimalPlaces") = GetDbInt(Reader.Item("DecimalPlaces"))
                ListRow.Item("EnableTime") = GetDbInt(Reader.Item("EnableTime"))
                ListData.Rows.Add(ListRow)
                ListRow = Nothing

                ret.Add(comCode, ListData)
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetCurrencyPair," & ex.Message
            blnError = True
            CmdDB = Nothing
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 行使対象取引の抽出（取引リスト作成）
    '--------------------------------------------------------------------------
    Public Function GetExecutionTradeList(ByRef ListData As DataTable) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String
        Dim ListRow As DataRow

        ListData = Nothing

        Result = True
        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("TradeSeq"))
            ListData.Columns.Add(New DataColumn("TradeSubSeq"))
            ListData.Columns.Add(New DataColumn("TradeType"))
            ListData.Columns.Add(New DataColumn("ExercPrice"))
            ListData.Columns.Add(New DataColumn("CurCode"))
            ListData.Columns.Add(New DataColumn("Premium"))
            ListData.Columns.Add(New DataColumn("PayoutRate"))
            ListData.Columns.Add(New DataColumn("CustCode"))
            ListData.Columns.Add(New DataColumn("CmpCode"))

            ListData.Columns.Add(New DataColumn("ProductCode"))
            ListData.Columns.Add(New DataColumn("ComCode"))
            ListData.Columns.Add(New DataColumn("ExercTime"))
            ListData.Columns.Add(New DataColumn("ExercStatus"))

            strSQL = "Select * From T_Trade with (nolock)" &
                     " Where TradeStatus In ('02') And ExercTime <= SYSUTCDATETIME()"

            strSQL = strSQL & " Order by ExercTime"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read

                Dim ExercStatus As String = GetDbString(Reader.Item("ExercStatus"))

                If ExercStatus = "3" Then
                    '行使失敗処理データであれば次のデータへ
                    Continue While
                End If

                ListRow = ListData.NewRow()
                ListRow.Item("TradeSeq") = GetDbString(Reader.Item("TradeSeq"))
                ListRow.Item("TradeSubSeq") = GetDbInt(Reader.Item("TradeSubSeq"))
                ListRow.Item("TradeType") = GetDbString(Reader.Item("TradeType"))
                ListRow.Item("ExercPrice") = Reader.Item("ExercPrice")
                ListRow.Item("CurCode") = Reader.Item("CurCode")
                ListRow.Item("Premium") = Reader.Item("Premium")
                ListRow.Item("PayoutRate") = Reader.Item("PayoutRate")
                ListRow.Item("CustCode") = GetDbString(Reader.Item("CustCode"))
                ListRow.Item("CmpCode") = GetDbString(Reader.Item("CmpCode"))

                ListRow.Item("ComCode") = GetDbString(Reader.Item("ComCode"))
                ListRow.Item("ProductCode") = GetDbString(Reader.Item("ProductCode"))
                ListRow.Item("ExercStatus") = ExercStatus
                ListRow.Item("ExercTime") = Reader.Item("ExercTime")
                ListData.Rows.Add(ListRow)
                ListRow = Nothing
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetExecutionTradeList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ文字列項目の取得
    '--------------------------------------------------------------------------
    Public Function GetDbString(ByVal obj As Object) As String
        Dim RetVal As String

        If IsDBNull(obj) Then
            RetVal = [String].Empty
        Else
            RetVal = CStr(obj)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ数値（Ｉｎｔ）項目の取得
    '--------------------------------------------------------------------------
    Public Function GetDbInt(ByVal obj As Object) As Integer
        Dim RetVal As Integer

        If IsDBNull(obj) Then
            RetVal = 0
        Else
            RetVal = CInt(obj)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsError() As Boolean
        Return blnError
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetErrorMessage() As String
        Dim sErrMsg As String

        blnError = False
        sErrMsg = "DataBase Error:" & strError
        Return sErrMsg

    End Function

End Class
