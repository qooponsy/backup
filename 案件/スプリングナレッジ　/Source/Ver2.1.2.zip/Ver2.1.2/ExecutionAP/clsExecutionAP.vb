﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics

'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsExecutionAP
    Private intThreadNum As Integer
    Private strServiceName As String
    Private blnServiceStopFlag As Boolean
    Private blnMasterMode As Boolean
    Private WorkerStopSignal As New ManualResetEvent(False)

    Private WorkerClass() As clsWorkerExecution
    Private WorkerWaitHandles() As WaitHandle

    Private MasterHB() As Byte
    Private SlaveHB() As Byte
    Private HeartBeatUDP As UdpClient
    Private MasterWatch As Stopwatch
    Private SocketErrMsg As String

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub New()
        intThreadNum = 0
        blnServiceStopFlag = False
        strServiceName = "ExecutionAP"
#If REL_DEMO Then
        strServiceName = "ExecutionAPDemoUK"
#End If
#If REL_ST Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_UK Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_MT4 Then
        strServiceName = "ExecutionAPMT4"
#End If
        blnMasterMode = False
    End Sub

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsMasterMode() As Boolean
        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッドの初期設定
    '--------------------------------------------------------------------------
    Public Function InitializeServiceThread() As Boolean
        Dim bInitRes As Boolean

        bInitRes = True

        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        intThreadNum = 0

        Return bInitRes
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッド
    '--------------------------------------------------------------------------
    Public Sub ServiceThread()
        Dim IntervalStopWatch As Stopwatch
        Dim HeartBeatWatch As Stopwatch
        Dim iInterval As Integer
        Dim iHeartBeatCycle As Integer

        Logging("ServiceThread Start.", EventLogEntryType.Information)

        'StartExecutionThread()

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew

        iInterval = 0
        iHeartBeatCycle = My.Settings.HeartBeatCycle

        OnSlaveMode()
        IntervalStopWatch = Stopwatch.StartNew()
        HeartBeatWatch = Stopwatch.StartNew

        RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTime)
        Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)

        While blnServiceStopFlag = False
            If HeartBeatWatch.ElapsedMilliseconds() >= iHeartBeatCycle Then
                CheckMasterAlive()
                HeartBeatWatch.Stop()
                HeartBeatWatch.Reset()
                HeartBeatWatch.Start()
            End If

            If RunningContoroller.check() Then
                Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
            End If
            If RunningContoroller.Running Then
                If blnMasterMode Then
                    Try
                        '-----------------------------------------------------
                        ' ワーカースレッド作成
                        '-----------------------------------------------------
                        Logging("WorkerThread Start.", EventLogEntryType.Information)
                        WorkerStopSignal.Reset()
                        Dim Worker As New clsWorkerExecution
                        Dim WorkerThread As New Thread(AddressOf Worker.WorkerThread)
                        Worker.InitializeWorkerThread(WorkerStopSignal)
                        Dim WorkerEndSignal As New ManualResetEvent(False)
                        WorkerThread.Start(WorkerEndSignal)
                        '-----------------------------------------------------
                        ' ワーカースレッド停止待機
                        '-----------------------------------------------------
                        While Not WorkerEndSignal.WaitOne(My.Settings.HeartBeatCycle)
                            CheckMasterAlive()
                            If RunningContoroller.check() Then
                                Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
                            End If
                            If Not RunningContoroller.Running Then
                                WorkerStopSignal.Set()
                            End If
                        End While
                        If Not WorkerThread.Join(3000) Then
                            Logging("WorkerThread Stop Alert.", EventLogEntryType.Warning)
                        End If
                        Logging("WorkerThread Stop.", EventLogEntryType.Information)
                    Catch ex As Exception
                        Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
                    End Try
                End If
            End If

            Thread.Sleep(500)

        End While

        MasterWatch.Stop()
        HeartBeatUDP.Close()

        'StopExecutionThread()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド、及びワーカースレッドの停止要求
    '--------------------------------------------------------------------------
    Public Sub StopService()
        blnServiceStopFlag = True
        WorkerStopSignal.Set()
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnMasterMode()
        Dim IndexWorker As Integer

        For IndexWorker = 0 To intThreadNum - 1
            WorkerClass(IndexWorker).OnWorkerMasterMode()
        Next

        Logging("Master Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnSlaveMode()
        Dim IndexWorker As Integer

        For IndexWorker = 0 To intThreadNum - 1
            WorkerClass(IndexWorker).OnWorkerSlaveMode()
        Next

        Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        bMasterRecv = False
        bSlaveRecv = False
        iHeartBeatPriority = 9
        If HeartBeatUDP.Available() > 0 Then
            Dim sDataHB As String
            Dim DataHB() As Byte

            RemoteEP = Nothing
            Try
                DataHB = Nothing
                While HeartBeatUDP.Available() > 0
                    DataHB = HeartBeatUDP.Receive(RemoteEP)
                End While
                sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                Do
                    Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                    If NextIndex = -1 Then Exit Do
                    If sDataHB.Length - NextIndex < 3 Then Exit Do
                    sDataHB = sDataHB.Substring(NextIndex)
                Loop While True
                If My.Settings.HeartBeatLog Then SystemLog.Information(sDataHB)
                If sDataHB.Length >= 3 Then
                    sHeartBeatMode = sDataHB.Substring(1, 1)
                    iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                    If sHeartBeatMode.Equals("M") = True Then
                        bMasterRecv = True
                        MasterWatch.Reset()
                        MasterWatch.Start()
                    End If
                    If sHeartBeatMode.Equals("S") = True Then
                        bSlaveRecv = True
                    End If
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
            End Try
        End If

        If blnMasterMode = True Then
            If bMasterRecv = True Then
                ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                If iHeartBeatPriority < My.Settings.MasterPriority Then
                    OnSlaveMode()
                    blnMasterMode = False
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        Else
            If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                OnMasterMode()
                blnMasterMode = True
                MasterWatch.Reset()
                MasterWatch.Start()
            ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                If SystemLog.GetDBErrorCount() > 0 Then
                    If My.Settings.HeartBeatLog Then SystemLog.Information("DB Error Now.")
                Else
                    OnMasterMode()
                    blnMasterMode = True
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        End If

        Try
            If blnMasterMode Then
                HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            Else
                HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            End If
        Catch ex As Exception
            If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
        End Try

        Return blnMasterMode
    End Function

    Private Function IsStartEndTimeReverse() As Boolean
        Return My.Settings.StartTime > My.Settings.EndTime
    End Function

    Private Function GetDateAjust(ByRef RunnableTime As Boolean) As DateTime
        Dim nowDateTime As DateTime = DateTime.Now
        Dim now As New TimeSpan(0, nowDateTime.Hour, nowDateTime.Minute, nowDateTime.Second, nowDateTime.Millisecond)
        If IsStartEndTimeReverse() Then
            RunnableTime = (My.Settings.StartTime < now) Or (My.Settings.EndTime > now)
            If My.Settings.EndTime < now Then
                Return nowDateTime.Date
            Else
                Return nowDateTime.AddDays(-1).Date
            End If
        Else
            RunnableTime = (My.Settings.StartTime < now) And (My.Settings.EndTime > now)
            If My.Settings.EndTime < now Then
                Return nowDateTime.AddDays(1).Date
            Else
                Return nowDateTime.Date
            End If
        End If
    End Function

    Private Function GetStopTime(ByVal WorkDate As DateTime) As DateTime
        Dim endTime As TimeSpan = My.Settings.EndTime
        Dim stopTime As New DateTime(WorkDate.Year, WorkDate.Month, WorkDate.Day, endTime.Hours, endTime.Minutes, endTime.Seconds)
        If IsStartEndTimeReverse() Then
            stopTime = stopTime.AddDays(1)
        End If
        Return stopTime
    End Function

    Private Function GetNextStartTime(ByVal NextDate As DateTime) As DateTime
        Dim startTime As TimeSpan = My.Settings.StartTime
        Dim nextStartTime As New DateTime(NextDate.Year, NextDate.Month, NextDate.Day, startTime.Hours, startTime.Minutes, startTime.Seconds)
        Return nextStartTime
    End Function

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog

        Try
            Debug.Print(sMessage)
            eLog = New EventLog()
            eLog.Source = strServiceName
            eLog.WriteEntry(sMessage, entryType)
            eLog = Nothing
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
    End Sub

End Class
