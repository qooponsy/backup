﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
Imports System.Threading.Tasks
'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsWorkerExecution
    Private blnAbortRequest As Boolean
    Private strServiceName As String
	Private strProductComCode As String
	Private strProductCode As String
    Private StopSignal As ManualResetEvent

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub New()
        blnAbortRequest = False
        strServiceName = "ExecutionAP"
#If REL_DEMO Then
        strServiceName = "ExecutionAPDemoUK"
#End If
#If REL_ST Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_UK Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_MT4 Then
        strServiceName = "ExecutionAPMT4"
#End If
        strProductComCode = ""
        strProductCode = ""
    End Sub

    '--------------------------------------------------------------------------
    ' ワーカースレッドの初期設定
    '--------------------------------------------------------------------------
    Public Sub InitializeWorkerThread(pStopSignal As ManualResetEvent)
        StopSignal = pStopSignal
    End Sub

    '--------------------------------------------------------------------------
    ' ワーカースレッドからのサービス中断要求
    '--------------------------------------------------------------------------
    Public Function IsAbortRequest() As Boolean
		Return blnAbortRequest
	End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub WorkerThread(ByVal State As Object)
        Dim EndSignal As ManualResetEvent = CType(State, ManualResetEvent)

        Try
            While Not StopSignal.WaitOne(My.Settings.ExecutionInterval)
                ExecutionWorkerProc(StopSignal)
            End While
        Catch ex As Exception
            SystemLog.AppError(ex)
            SystemLog.Warning("WorkerThread Exception")
        Finally
            EndSignal.Set()
        End Try
    End Sub

    '--------------------------------------------------------------------------
    ' 定期行使チェック処理
    ' ※実行、周期はWorkerThreadにより制御
    '--------------------------------------------------------------------------
    Private Sub ExecutionWorkerProc(StopSignal As ManualResetEvent)
        Dim DataBase As clsPenguinDB
        Dim ExecRateTable As DataTable = Nothing
        Dim TradeList As DataTable = Nothing
        Dim TradeRow As DataRow
        Dim TradeListCount As Integer
        Dim ProductList As DataTable
        Dim ProductRow As DataRow
        Dim ProductListCount As Integer
        Dim ComDic As Dictionary(Of String, DataTable)
        Dim ExercRateDic As Dictionary(Of String, DataTable)
        Dim ViewSeqDic As Dictionary(Of String, String)
        Dim intRateEnableTime As Integer
        Dim bResultDB As Boolean
        Dim ExecData As clsExecutionData

        ExecData = New clsExecutionData
        DataBase = New clsPenguinDB
        bResultDB = DataBase.GetSqlConnection(My.Settings.DB)
        If bResultDB = True Then

            '行使対象該当取引の取得
            If DataBase.GetExecutionTradeList(TradeList) = True Then
                TradeListCount = TradeList.Rows.Count
            Else
                TradeListCount = 0
            End If

            ExercRateDic = New Dictionary(Of String, DataTable)
            ViewSeqDic = New Dictionary(Of String, String)
            ComDic = New Dictionary(Of String, DataTable)
            ComDic = DataBase.GetCurrencyPair()

            '行使対象取引があれば行使処理
            If TradeListCount > 0 Then

                '行使用スレッド生成
                Dim ExecutionThread() As Thread = Nothing
                Dim ExecutionListQueue As New Queue(Of ExecutionQueueItem)
                StartExecutionThread(ExecutionThread, ExecutionListQueue)

                Try
                    ExecData.UserID = "P:" & My.Settings.ProcessID
                    ExecData.SysDate = DataBase.GetSysDate()
                    ExecData.CurrencyDecimalPlaces = DataBase.GetCurrency()

                    If DataBase.IsError() = True Then
                        bResultDB = False
                    End If

                    If bResultDB = True Then

                        '取引の数だけ行使データ作成
                        For Each TradeRow In TradeList.Rows
                            Dim comCode As String = TradeRow.Item("ComCode").ToString()
                            Dim exercTime As DateTime = CDate(TradeRow.Item("ExercTime"))

                            Dim key As String = comCode & "_" & exercTime.ToString()

                            ' 行使レート情報取得
                            If ExercRateDic.ContainsKey(key) = False Then
                                ' 行使レートがキャッシュになければ取得
                                If DataBase.GetExecutionRate(comCode, exercTime, ExecRateTable) Then
                                    ExercRateDic.Add(key, ExecRateTable)
                                Else
                                    bResultDB = False
                                End If
                            Else
                                '取得済であればキャッシュより引用
                                ExecRateTable = ExercRateDic(key)
                            End If

                            If bResultDB = True Then

                                ExecData.ProductCode = TradeRow.Item("ProductCode")
                                ExecData.ExercTime = exercTime

                                If ExecRateTable.Rows.Count() > 0 Then

                                    ExecData.ExercRateSeq = ExecRateTable.Rows(0).Item("RateSeq").ToString()
                                    ExecData.ExercRateTime = CDate(ExecRateTable.Rows(0).Item("RateTime"))
                                    ExecData.ExercRateTimeSource = CDate(ExecRateTable.Rows(0).Item("RateTimeSource"))
                                    ExecData.ExercRate = CDec(ExecRateTable.Rows(0).Item("Rate"))

                                    Debug.Print("ExercRate Seq:" & ExecData.ExercRateSeq & ",Rate:" & ExecData.ExercRate.ToString())

                                    intRateEnableTime = ComDic(comCode).Rows(0).Item("EnableTime")
                                    If intRateEnableTime <= exercTime.Subtract(ExecData.ExercRateTime).TotalSeconds Then
                                        'レート有効期限切れ
                                        Dim TradeSeq As String = TradeRow.Item("TradeSeq").ToString()
                                        Logging(String.Format("レート有効期限切れ 取引Seq:{0},レートSeq:{1}", TradeSeq, ExecData.ExercRateSeq), EventLogEntryType.Error)
                                        bResultDB = DataBase.UpdateTradeExecutionStatusError(TradeSeq)
                                    Else
                                        '表示用レートSeq生成
                                        If bResultDB = True Then
                                            If ViewSeqDic.ContainsKey(comCode) = False Then
                                                Dim iViewSeqCount As Integer = DataBase.GetRateViewSeq(clsPenguinDB.SeqCounterCode.Rate, comCode)
                                                If bResultDB = True Then
                                                    Dim sViewSeqCount As String = String.Format("{0:yyyyMMddHHmm}{1}{2:000}", exercTime, comCode, iViewSeqCount)

                                                    ExecData.ViewSeq = sViewSeqCount
                                                    ViewSeqDic.Add(comCode, sViewSeqCount)
                                                End If
                                            Else
                                                ExecData.ViewSeq = ViewSeqDic(comCode)
                                            End If
                                        End If

                                        '行使データを行使スレッドへ送信
                                        If bResultDB = True Then
                                            ExecData.TradeType = TradeRow.Item("TradeType").ToString()
                                            ExecData.TradeSeq = TradeRow.Item("TradeSeq").ToString()
                                            ExecData.ExercPrice = CDec(TradeRow.Item("ExercPrice"))
                                            ExecData.CurCode = TradeRow.Item("CurCode").ToString()
                                            ExecData.Premium = CDec(TradeRow.Item("Premium"))
                                            ExecData.PayoutRate = CDec(TradeRow.Item("PayoutRate"))

                                            Dim TaskExecData As New clsExecutionData
                                            TaskExecData.Copy(ExecData)
                                            ' 行使データキューにAdd
                                            Dim item As New ExecutionQueueItem
                                            item.ExecutionData = TaskExecData
                                            item.EndFlg = False
                                            SyncLock ExecutionListQueue
                                                ExecutionListQueue.Enqueue(item)
                                            End SyncLock
                                        End If
                                    End If

                                End If
                            End If
                        Next
                    End If
                Finally
                    '必ず行使スレッドを終わらせる
                    StopExecutionThread(ExecutionThread, ExecutionListQueue)
                End Try
            End If

            '取引の行使完了後に銘柄を行使
            ProductList = Nothing
            If bResultDB = True Then
                If DataBase.GetExecutionProductList(ProductList) = True Then
                    ProductListCount = ProductList.Rows.Count
                Else
                    ProductListCount = 0
                End If

                If ProductListCount > 0 Then

                    ExecData.UserID = "P:" & My.Settings.ProcessID
                    ExecData.SysDate = DataBase.GetSysDate()
                    ExecData.CurrencyDecimalPlaces = DataBase.GetCurrency()

                    If DataBase.IsError() = True Then
                        bResultDB = False
                    End If

                    If bResultDB = True Then
                        '取引の数だけ行使データ作成
                        For Each ProductRow In ProductList.Rows

                            Dim comCode As String = ProductRow.Item("ComCode").ToString()
                            Dim exercTime As DateTime = CDate(ProductRow.Item("ExercTime"))

                            Dim key As String = comCode & "_" & exercTime.ToString()

                            ' 行使レート情報取得
                            If ExercRateDic.ContainsKey(key) = False Then
                                ' 行使レートがキャッシュになければ取得
                                If DataBase.GetExecutionRate(comCode, exercTime, ExecRateTable) Then
                                    ExercRateDic.Add(key, ExecRateTable)
                                Else
                                    bResultDB = False
                                End If
                            Else
                                '取得済であればキャッシュより引用
                                ExecRateTable = ExercRateDic(key)
                            End If

                            If bResultDB = True Then
                                ExecData.ProductCode = ProductRow.Item("ProductCode")
                                ExecData.ExercTime = exercTime

                                If ExecRateTable.Rows.Count() > 0 Then
                                    ExecData.ExercRateSeq = ExecRateTable.Rows(0).Item("RateSeq").ToString()
                                    ExecData.ExercRateTime = CDate(ExecRateTable.Rows(0).Item("RateTime"))
                                    ExecData.ExercRateTimeSource = CDate(ExecRateTable.Rows(0).Item("RateTimeSource"))
                                    ExecData.ExercRate = CDec(ExecRateTable.Rows(0).Item("Rate"))

                                    Debug.Print("ExercRate Seq:" & ExecData.ExercRateSeq & ",Rate:" & ExecData.ExercRate.ToString())

                                    intRateEnableTime = ComDic(comCode).Rows(0).Item("EnableTime")
                                    If intRateEnableTime <= exercTime.Subtract(ExecData.ExercRateTime).TotalSeconds Then
                                        'レート有効期限切れ
                                        Logging(String.Format("レート有効期限切れ 銘柄コード:{0},レートSeq:{1}", strProductCode, ExecData.ExercRateSeq), EventLogEntryType.Error)
                                        bResultDB = DataBase.UpdateProductExecutionStatusError(ExecData.ProductCode)
                                        If Not bResultDB Then
                                            'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)        ' Error:UpdateExecutionStatusErrot
                                        End If
                                    Else
                                        '表示用レートSeq生成
                                        If bResultDB = True Then
                                            If ViewSeqDic.ContainsKey(comCode) = False Then
                                                Dim iViewSeqCount As Integer = DataBase.GetRateViewSeq(clsPenguinDB.SeqCounterCode.Rate, comCode)
                                                If bResultDB = True Then
                                                    Dim sViewSeqCount As String = String.Format("{0:yyyyMMddHHmm}{1}{2:000}", exercTime, comCode, iViewSeqCount)

                                                    ExecData.ViewSeq = sViewSeqCount
                                                    ViewSeqDic.Add(comCode, sViewSeqCount)
                                                End If
                                            Else
                                                ExecData.ViewSeq = ViewSeqDic(comCode)
                                            End If
                                        End If

                                        '行使時レートの更新
                                        bResultDB = DataBase.UpdateExecutionRate(comCode, ExecData.ExercRateSeq, ExecData.ExercTime, ExecData.ViewSeq)
                                        If bResultDB = True Then
                                            '銘柄の行使
                                            DataBase.EndExecutionProduct(ExecData.ProductCode, ExecData.ExercRateSeq, ExecData.ExercRate)
                                        End If
                                    End If
                                End If
                            End If
                        Next
                    End If
                End If
            End If


            DataBase.EndSqlConnection()
        Else
            'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)    ' Error:GetSqlConnection
        End If
        DataBase = Nothing
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行
    '--------------------------------------------------------------------------
    Public Sub OnWorkerMasterMode()
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行
    '--------------------------------------------------------------------------
    Public Sub OnWorkerSlaveMode()
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog
        Dim sWorkerMsg As String

        If strProductCode <> "" Then
            Try
                sWorkerMsg = "(" & strProductComCode & ":" & strProductCode & ")-" & sMessage
                eLog = New EventLog()
                eLog.Source = strServiceName
                eLog.WriteEntry(sWorkerMsg, entryType)
                eLog = Nothing
                Debug.Print(sWorkerMsg)
            Catch ex As Exception
                Debug.Print(ex.Message)
            End Try
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' 行使・消滅実行スレッドプール
    '--------------------------------------------------------------------------
    Public Class ExecutionQueueItem
        Public ExecutionData As New clsExecutionData
        Public EndFlg As Boolean = False
    End Class


    '--------------------------------------------------------------------------
    ' 行使用スレッド生成
    '--------------------------------------------------------------------------
    Private Shared Sub StartExecutionThread(ByRef ExecutionThread() As Thread, ByRef ExecutionListQueue As Queue(Of ExecutionQueueItem))
        ReDim ExecutionThread(My.Settings.ExecutionThreadCount)
        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
            ExecutionThread(fa) = New Thread(AddressOf ExecutionThreadProc)
            ExecutionThread(fa).Start(ExecutionListQueue)
        Next
    End Sub

    '--------------------------------------------------------------------------
    ' 行使用スレッド停止
    '--------------------------------------------------------------------------
    Private Shared Sub StopExecutionThread(ByRef ExecutionThread() As Thread, ByRef ExecutionListQueue As Queue(Of ExecutionQueueItem))
        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
            '停止用キューをAdd
            Dim item As New ExecutionQueueItem
            item.EndFlg = True
            SyncLock ExecutionListQueue
                ExecutionListQueue.Enqueue(item)
            End SyncLock
        Next

        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
            Dim threadEndFlg As Boolean = True
            '行使スレッド終了待ち
            threadEndFlg = ExecutionThread(fa).Join(30000) '30秒

            If threadEndFlg = False Then
                'スレッド終了待ちがタイムアウトしたらログ出力
                SystemLog.ErrorTEL("StopExecutionThread", "行使スレッド終了待ちタイムアウト")
            End If
        Next
    End Sub

    Private Shared Sub ExecutionThreadProc(Queue As Object)
        Dim ExecutionListQueue As Queue(Of ExecutionQueueItem) = CType(Queue, Queue(Of ExecutionQueueItem))

        Dim DataBase As New clsPenguinDB
        Dim bResultDB As Boolean = False
        bResultDB = DataBase.GetSqlConnection(My.Settings.DB)

        While True
            Try
                Dim item As ExecutionQueueItem = Nothing
                SyncLock ExecutionListQueue
                    Try
                        item = ExecutionListQueue.Dequeue()
                    Catch ex As InvalidOperationException
                        '空だった
                        item = Nothing
                    End Try
                End SyncLock

                If item IsNot Nothing Then
                    'スレッド終了判定
                    Dim EndFlg As Boolean = item.EndFlg
                    If EndFlg = True Then
                        Exit While
                    End If

                    Dim ExecData As clsExecutionData = item.ExecutionData

                    ' 接続失敗していれば再度接続
                    If bResultDB = False Then
                        DataBase = New clsPenguinDB
                        bResultDB = DataBase.GetSqlConnection(My.Settings.DB)
                    End If

                    If bResultDB Then

                        If ExecData.IsExecutionATM() = True Then
                            Debug.Print("Exec  ATM:" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                            ExecData.SetExecutionATM()
                        ElseIf ExecData.IsExecutionUP() = True Then
                            Debug.Print("Exec   UP:" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                            ExecData.SetExecution()
                        ElseIf ExecData.IsExecutionDOWN() = True Then
                            Debug.Print("Exec DOWN:" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                            ExecData.SetExecution()
                        Else
                            Debug.Print("Extinct  :" & ExecData.ProductCode & ",TradeSeq:" & ExecData.TradeSeq)
                            ExecData.SetExtinction()
                        End If

                        Dim bResultDBUnit As Boolean = DataBase.UpdateExecution(ExecData)
                        If bResultDB And Not bResultDBUnit Then
                            bResultDB = False
                        End If

                    End If
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
            End Try
        End While

        DataBase.EndSqlConnection()
    End Sub

End Class
