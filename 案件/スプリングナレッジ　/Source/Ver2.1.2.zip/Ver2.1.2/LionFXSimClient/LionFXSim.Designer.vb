﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LionFXSim
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbURL = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbComCode = New System.Windows.Forms.ComboBox()
        Me.btnGet = New System.Windows.Forms.Button()
        Me.nudLines = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbID0 = New System.Windows.Forms.TextBox()
        Me.tbBid0 = New System.Windows.Forms.TextBox()
        Me.tbAsk0 = New System.Windows.Forms.TextBox()
        Me.dtpTime0 = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnRegist = New System.Windows.Forms.Button()
        Me.dtpTime1 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk1 = New System.Windows.Forms.TextBox()
        Me.tbBid1 = New System.Windows.Forms.TextBox()
        Me.tbID1 = New System.Windows.Forms.TextBox()
        Me.dtpTime2 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk2 = New System.Windows.Forms.TextBox()
        Me.tbBid2 = New System.Windows.Forms.TextBox()
        Me.tbID2 = New System.Windows.Forms.TextBox()
        Me.dtpTime3 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk3 = New System.Windows.Forms.TextBox()
        Me.tbBid3 = New System.Windows.Forms.TextBox()
        Me.tbID3 = New System.Windows.Forms.TextBox()
        Me.dtpTime4 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk4 = New System.Windows.Forms.TextBox()
        Me.tbBid4 = New System.Windows.Forms.TextBox()
        Me.tbID4 = New System.Windows.Forms.TextBox()
        Me.dtpTime5 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk5 = New System.Windows.Forms.TextBox()
        Me.tbBid5 = New System.Windows.Forms.TextBox()
        Me.tbID5 = New System.Windows.Forms.TextBox()
        Me.dtpTime6 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk6 = New System.Windows.Forms.TextBox()
        Me.tbBid6 = New System.Windows.Forms.TextBox()
        Me.tbID6 = New System.Windows.Forms.TextBox()
        Me.dtpTime7 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk7 = New System.Windows.Forms.TextBox()
        Me.tbBid7 = New System.Windows.Forms.TextBox()
        Me.tbID7 = New System.Windows.Forms.TextBox()
        Me.dtpTime8 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk8 = New System.Windows.Forms.TextBox()
        Me.tbBid8 = New System.Windows.Forms.TextBox()
        Me.tbID8 = New System.Windows.Forms.TextBox()
        Me.dtpTime9 = New System.Windows.Forms.DateTimePicker()
        Me.tbAsk9 = New System.Windows.Forms.TextBox()
        Me.tbBid9 = New System.Windows.Forms.TextBox()
        Me.tbID9 = New System.Windows.Forms.TextBox()
        Me.btnNowTime = New System.Windows.Forms.Button()
        Me.btnNewID = New System.Windows.Forms.Button()
        CType(Me.nudLines, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "URL"
        '
        'cbURL
        '
        Me.cbURL.FormattingEnabled = True
        Me.cbURL.Items.AddRange(New Object() {"", "http://localhost:59001/LionFXSim/", "http://192.168.0.107/LionFXSim/", "http://fate-i.ddo.jp/LionFXSim/"})
        Me.cbURL.Location = New System.Drawing.Point(69, 10)
        Me.cbURL.Name = "cbURL"
        Me.cbURL.Size = New System.Drawing.Size(394, 20)
        Me.cbURL.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "通貨ペア"
        '
        'cbComCode
        '
        Me.cbComCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbComCode.FormattingEnabled = True
        Me.cbComCode.Items.AddRange(New Object() {"USDJPY", "EURJPY", "EURUSD", "GBPJPY", "GBPUSD", "AUDJPY"})
        Me.cbComCode.Location = New System.Drawing.Point(69, 42)
        Me.cbComCode.Name = "cbComCode"
        Me.cbComCode.Size = New System.Drawing.Size(85, 20)
        Me.cbComCode.TabIndex = 3
        '
        'btnGet
        '
        Me.btnGet.Location = New System.Drawing.Point(160, 40)
        Me.btnGet.Name = "btnGet"
        Me.btnGet.Size = New System.Drawing.Size(75, 23)
        Me.btnGet.TabIndex = 4
        Me.btnGet.Text = "取得"
        Me.btnGet.UseVisualStyleBackColor = True
        '
        'nudLines
        '
        Me.nudLines.Location = New System.Drawing.Point(326, 43)
        Me.nudLines.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.nudLines.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudLines.Name = "nudLines"
        Me.nudLines.Size = New System.Drawing.Size(42, 19)
        Me.nudLines.TabIndex = 5
        Me.nudLines.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nudLines.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(251, 45)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 12)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "編集データ数"
        '
        'tbID0
        '
        Me.tbID0.Location = New System.Drawing.Point(24, 97)
        Me.tbID0.Name = "tbID0"
        Me.tbID0.Size = New System.Drawing.Size(87, 19)
        Me.tbID0.TabIndex = 7
        Me.tbID0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid0
        '
        Me.tbBid0.Location = New System.Drawing.Point(117, 97)
        Me.tbBid0.Name = "tbBid0"
        Me.tbBid0.Size = New System.Drawing.Size(100, 19)
        Me.tbBid0.TabIndex = 8
        Me.tbBid0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbAsk0
        '
        Me.tbAsk0.Location = New System.Drawing.Point(223, 97)
        Me.tbAsk0.Name = "tbAsk0"
        Me.tbAsk0.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk0.TabIndex = 9
        Me.tbAsk0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime0
        '
        Me.dtpTime0.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime0.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime0.Location = New System.Drawing.Point(329, 97)
        Me.dtpTime0.Name = "dtpTime0"
        Me.dtpTime0.ShowUpDown = True
        Me.dtpTime0.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime0.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(22, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(16, 12)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(117, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(22, 12)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Bid"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(221, 82)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(25, 12)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Ask"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(327, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(30, 12)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Time"
        '
        'btnRegist
        '
        Me.btnRegist.Location = New System.Drawing.Point(388, 40)
        Me.btnRegist.Name = "btnRegist"
        Me.btnRegist.Size = New System.Drawing.Size(75, 23)
        Me.btnRegist.TabIndex = 15
        Me.btnRegist.Text = "登録"
        Me.btnRegist.UseVisualStyleBackColor = True
        '
        'dtpTime1
        '
        Me.dtpTime1.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime1.Location = New System.Drawing.Point(329, 122)
        Me.dtpTime1.Name = "dtpTime1"
        Me.dtpTime1.ShowUpDown = True
        Me.dtpTime1.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime1.TabIndex = 19
        '
        'tbAsk1
        '
        Me.tbAsk1.Location = New System.Drawing.Point(223, 122)
        Me.tbAsk1.Name = "tbAsk1"
        Me.tbAsk1.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk1.TabIndex = 18
        Me.tbAsk1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid1
        '
        Me.tbBid1.Location = New System.Drawing.Point(117, 122)
        Me.tbBid1.Name = "tbBid1"
        Me.tbBid1.Size = New System.Drawing.Size(100, 19)
        Me.tbBid1.TabIndex = 17
        Me.tbBid1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID1
        '
        Me.tbID1.Location = New System.Drawing.Point(24, 122)
        Me.tbID1.Name = "tbID1"
        Me.tbID1.Size = New System.Drawing.Size(87, 19)
        Me.tbID1.TabIndex = 16
        Me.tbID1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime2
        '
        Me.dtpTime2.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime2.Location = New System.Drawing.Point(329, 147)
        Me.dtpTime2.Name = "dtpTime2"
        Me.dtpTime2.ShowUpDown = True
        Me.dtpTime2.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime2.TabIndex = 23
        '
        'tbAsk2
        '
        Me.tbAsk2.Location = New System.Drawing.Point(223, 147)
        Me.tbAsk2.Name = "tbAsk2"
        Me.tbAsk2.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk2.TabIndex = 22
        Me.tbAsk2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid2
        '
        Me.tbBid2.Location = New System.Drawing.Point(117, 147)
        Me.tbBid2.Name = "tbBid2"
        Me.tbBid2.Size = New System.Drawing.Size(100, 19)
        Me.tbBid2.TabIndex = 21
        Me.tbBid2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID2
        '
        Me.tbID2.Location = New System.Drawing.Point(24, 147)
        Me.tbID2.Name = "tbID2"
        Me.tbID2.Size = New System.Drawing.Size(87, 19)
        Me.tbID2.TabIndex = 20
        Me.tbID2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime3
        '
        Me.dtpTime3.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime3.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime3.Location = New System.Drawing.Point(329, 172)
        Me.dtpTime3.Name = "dtpTime3"
        Me.dtpTime3.ShowUpDown = True
        Me.dtpTime3.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime3.TabIndex = 27
        '
        'tbAsk3
        '
        Me.tbAsk3.Location = New System.Drawing.Point(223, 172)
        Me.tbAsk3.Name = "tbAsk3"
        Me.tbAsk3.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk3.TabIndex = 26
        Me.tbAsk3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid3
        '
        Me.tbBid3.Location = New System.Drawing.Point(117, 172)
        Me.tbBid3.Name = "tbBid3"
        Me.tbBid3.Size = New System.Drawing.Size(100, 19)
        Me.tbBid3.TabIndex = 25
        Me.tbBid3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID3
        '
        Me.tbID3.Location = New System.Drawing.Point(24, 172)
        Me.tbID3.Name = "tbID3"
        Me.tbID3.Size = New System.Drawing.Size(87, 19)
        Me.tbID3.TabIndex = 24
        Me.tbID3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime4
        '
        Me.dtpTime4.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime4.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime4.Location = New System.Drawing.Point(329, 197)
        Me.dtpTime4.Name = "dtpTime4"
        Me.dtpTime4.ShowUpDown = True
        Me.dtpTime4.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime4.TabIndex = 31
        '
        'tbAsk4
        '
        Me.tbAsk4.Location = New System.Drawing.Point(223, 197)
        Me.tbAsk4.Name = "tbAsk4"
        Me.tbAsk4.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk4.TabIndex = 30
        Me.tbAsk4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid4
        '
        Me.tbBid4.Location = New System.Drawing.Point(117, 197)
        Me.tbBid4.Name = "tbBid4"
        Me.tbBid4.Size = New System.Drawing.Size(100, 19)
        Me.tbBid4.TabIndex = 29
        Me.tbBid4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID4
        '
        Me.tbID4.Location = New System.Drawing.Point(24, 197)
        Me.tbID4.Name = "tbID4"
        Me.tbID4.Size = New System.Drawing.Size(87, 19)
        Me.tbID4.TabIndex = 28
        Me.tbID4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime5
        '
        Me.dtpTime5.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime5.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime5.Location = New System.Drawing.Point(329, 222)
        Me.dtpTime5.Name = "dtpTime5"
        Me.dtpTime5.ShowUpDown = True
        Me.dtpTime5.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime5.TabIndex = 35
        '
        'tbAsk5
        '
        Me.tbAsk5.Location = New System.Drawing.Point(223, 222)
        Me.tbAsk5.Name = "tbAsk5"
        Me.tbAsk5.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk5.TabIndex = 34
        Me.tbAsk5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid5
        '
        Me.tbBid5.Location = New System.Drawing.Point(117, 222)
        Me.tbBid5.Name = "tbBid5"
        Me.tbBid5.Size = New System.Drawing.Size(100, 19)
        Me.tbBid5.TabIndex = 33
        Me.tbBid5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID5
        '
        Me.tbID5.Location = New System.Drawing.Point(24, 222)
        Me.tbID5.Name = "tbID5"
        Me.tbID5.Size = New System.Drawing.Size(87, 19)
        Me.tbID5.TabIndex = 32
        Me.tbID5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime6
        '
        Me.dtpTime6.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime6.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime6.Location = New System.Drawing.Point(329, 247)
        Me.dtpTime6.Name = "dtpTime6"
        Me.dtpTime6.ShowUpDown = True
        Me.dtpTime6.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime6.TabIndex = 39
        '
        'tbAsk6
        '
        Me.tbAsk6.Location = New System.Drawing.Point(223, 247)
        Me.tbAsk6.Name = "tbAsk6"
        Me.tbAsk6.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk6.TabIndex = 38
        Me.tbAsk6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid6
        '
        Me.tbBid6.Location = New System.Drawing.Point(117, 247)
        Me.tbBid6.Name = "tbBid6"
        Me.tbBid6.Size = New System.Drawing.Size(100, 19)
        Me.tbBid6.TabIndex = 37
        Me.tbBid6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID6
        '
        Me.tbID6.Location = New System.Drawing.Point(24, 247)
        Me.tbID6.Name = "tbID6"
        Me.tbID6.Size = New System.Drawing.Size(87, 19)
        Me.tbID6.TabIndex = 36
        Me.tbID6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime7
        '
        Me.dtpTime7.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime7.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime7.Location = New System.Drawing.Point(329, 272)
        Me.dtpTime7.Name = "dtpTime7"
        Me.dtpTime7.ShowUpDown = True
        Me.dtpTime7.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime7.TabIndex = 43
        '
        'tbAsk7
        '
        Me.tbAsk7.Location = New System.Drawing.Point(223, 272)
        Me.tbAsk7.Name = "tbAsk7"
        Me.tbAsk7.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk7.TabIndex = 42
        Me.tbAsk7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid7
        '
        Me.tbBid7.Location = New System.Drawing.Point(117, 272)
        Me.tbBid7.Name = "tbBid7"
        Me.tbBid7.Size = New System.Drawing.Size(100, 19)
        Me.tbBid7.TabIndex = 41
        Me.tbBid7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID7
        '
        Me.tbID7.Location = New System.Drawing.Point(24, 272)
        Me.tbID7.Name = "tbID7"
        Me.tbID7.Size = New System.Drawing.Size(87, 19)
        Me.tbID7.TabIndex = 40
        Me.tbID7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime8
        '
        Me.dtpTime8.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime8.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime8.Location = New System.Drawing.Point(329, 297)
        Me.dtpTime8.Name = "dtpTime8"
        Me.dtpTime8.ShowUpDown = True
        Me.dtpTime8.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime8.TabIndex = 47
        '
        'tbAsk8
        '
        Me.tbAsk8.Location = New System.Drawing.Point(223, 297)
        Me.tbAsk8.Name = "tbAsk8"
        Me.tbAsk8.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk8.TabIndex = 46
        Me.tbAsk8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid8
        '
        Me.tbBid8.Location = New System.Drawing.Point(117, 297)
        Me.tbBid8.Name = "tbBid8"
        Me.tbBid8.Size = New System.Drawing.Size(100, 19)
        Me.tbBid8.TabIndex = 45
        Me.tbBid8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID8
        '
        Me.tbID8.Location = New System.Drawing.Point(24, 297)
        Me.tbID8.Name = "tbID8"
        Me.tbID8.Size = New System.Drawing.Size(87, 19)
        Me.tbID8.TabIndex = 44
        Me.tbID8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpTime9
        '
        Me.dtpTime9.CustomFormat = "yyyy/MM/dd HH:mm:ss"
        Me.dtpTime9.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTime9.Location = New System.Drawing.Point(329, 322)
        Me.dtpTime9.Name = "dtpTime9"
        Me.dtpTime9.ShowUpDown = True
        Me.dtpTime9.Size = New System.Drawing.Size(130, 19)
        Me.dtpTime9.TabIndex = 51
        '
        'tbAsk9
        '
        Me.tbAsk9.Location = New System.Drawing.Point(223, 322)
        Me.tbAsk9.Name = "tbAsk9"
        Me.tbAsk9.Size = New System.Drawing.Size(100, 19)
        Me.tbAsk9.TabIndex = 50
        Me.tbAsk9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbBid9
        '
        Me.tbBid9.Location = New System.Drawing.Point(117, 322)
        Me.tbBid9.Name = "tbBid9"
        Me.tbBid9.Size = New System.Drawing.Size(100, 19)
        Me.tbBid9.TabIndex = 49
        Me.tbBid9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbID9
        '
        Me.tbID9.Location = New System.Drawing.Point(24, 322)
        Me.tbID9.Name = "tbID9"
        Me.tbID9.Size = New System.Drawing.Size(87, 19)
        Me.tbID9.TabIndex = 48
        Me.tbID9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnNowTime
        '
        Me.btnNowTime.Location = New System.Drawing.Point(375, 69)
        Me.btnNowTime.Name = "btnNowTime"
        Me.btnNowTime.Size = New System.Drawing.Size(75, 23)
        Me.btnNowTime.TabIndex = 52
        Me.btnNowTime.Text = "現在時刻"
        Me.btnNowTime.UseVisualStyleBackColor = True
        '
        'btnNewID
        '
        Me.btnNewID.Location = New System.Drawing.Point(44, 69)
        Me.btnNewID.Name = "btnNewID"
        Me.btnNewID.Size = New System.Drawing.Size(54, 23)
        Me.btnNewID.TabIndex = 53
        Me.btnNewID.Text = "採番"
        Me.btnNewID.UseVisualStyleBackColor = True
        '
        'LionFXSim
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(481, 354)
        Me.Controls.Add(Me.btnNewID)
        Me.Controls.Add(Me.btnNowTime)
        Me.Controls.Add(Me.dtpTime9)
        Me.Controls.Add(Me.tbAsk9)
        Me.Controls.Add(Me.tbBid9)
        Me.Controls.Add(Me.tbID9)
        Me.Controls.Add(Me.dtpTime8)
        Me.Controls.Add(Me.tbAsk8)
        Me.Controls.Add(Me.tbBid8)
        Me.Controls.Add(Me.tbID8)
        Me.Controls.Add(Me.dtpTime7)
        Me.Controls.Add(Me.tbAsk7)
        Me.Controls.Add(Me.tbBid7)
        Me.Controls.Add(Me.tbID7)
        Me.Controls.Add(Me.dtpTime6)
        Me.Controls.Add(Me.tbAsk6)
        Me.Controls.Add(Me.tbBid6)
        Me.Controls.Add(Me.tbID6)
        Me.Controls.Add(Me.dtpTime5)
        Me.Controls.Add(Me.tbAsk5)
        Me.Controls.Add(Me.tbBid5)
        Me.Controls.Add(Me.tbID5)
        Me.Controls.Add(Me.dtpTime4)
        Me.Controls.Add(Me.tbAsk4)
        Me.Controls.Add(Me.tbBid4)
        Me.Controls.Add(Me.tbID4)
        Me.Controls.Add(Me.dtpTime3)
        Me.Controls.Add(Me.tbAsk3)
        Me.Controls.Add(Me.tbBid3)
        Me.Controls.Add(Me.tbID3)
        Me.Controls.Add(Me.dtpTime2)
        Me.Controls.Add(Me.tbAsk2)
        Me.Controls.Add(Me.tbBid2)
        Me.Controls.Add(Me.tbID2)
        Me.Controls.Add(Me.dtpTime1)
        Me.Controls.Add(Me.tbAsk1)
        Me.Controls.Add(Me.tbBid1)
        Me.Controls.Add(Me.tbID1)
        Me.Controls.Add(Me.btnRegist)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.dtpTime0)
        Me.Controls.Add(Me.tbAsk0)
        Me.Controls.Add(Me.tbBid0)
        Me.Controls.Add(Me.tbID0)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.nudLines)
        Me.Controls.Add(Me.btnGet)
        Me.Controls.Add(Me.cbComCode)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cbURL)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "LionFXSim"
        Me.Text = "LionFX Rate Tick Simulator"
        CType(Me.nudLines, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbURL As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbComCode As System.Windows.Forms.ComboBox
    Friend WithEvents btnGet As System.Windows.Forms.Button
    Friend WithEvents nudLines As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbID0 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid0 As System.Windows.Forms.TextBox
    Friend WithEvents tbAsk0 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime0 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnRegist As System.Windows.Forms.Button
    Friend WithEvents dtpTime1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk1 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid1 As System.Windows.Forms.TextBox
    Friend WithEvents tbID1 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk2 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid2 As System.Windows.Forms.TextBox
    Friend WithEvents tbID2 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime3 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk3 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid3 As System.Windows.Forms.TextBox
    Friend WithEvents tbID3 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime4 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk4 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid4 As System.Windows.Forms.TextBox
    Friend WithEvents tbID4 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime5 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk5 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid5 As System.Windows.Forms.TextBox
    Friend WithEvents tbID5 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime6 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk6 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid6 As System.Windows.Forms.TextBox
    Friend WithEvents tbID6 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime7 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk7 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid7 As System.Windows.Forms.TextBox
    Friend WithEvents tbID7 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime8 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk8 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid8 As System.Windows.Forms.TextBox
    Friend WithEvents tbID8 As System.Windows.Forms.TextBox
    Friend WithEvents dtpTime9 As System.Windows.Forms.DateTimePicker
    Friend WithEvents tbAsk9 As System.Windows.Forms.TextBox
    Friend WithEvents tbBid9 As System.Windows.Forms.TextBox
    Friend WithEvents tbID9 As System.Windows.Forms.TextBox
    Friend WithEvents btnNowTime As System.Windows.Forms.Button
    Friend WithEvents btnNewID As System.Windows.Forms.Button

End Class
