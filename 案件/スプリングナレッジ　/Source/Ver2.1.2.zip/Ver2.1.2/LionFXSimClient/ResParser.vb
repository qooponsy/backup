﻿Imports System.Text

Public Class ResParser

    Public ResultCode As String
    Public ResultText As String

    Public Function parseResponse(ByVal resdata As Byte()) As String()
        Dim resstr As String = Encoding.UTF8.GetString(resdata)
        Dim lines As String() = resstr.Split(vbLf)
        If lines.Length > 0 Then
            Dim resultCols As String() = lines(0).Split(",")
            If resultCols.Length > 0 Then ResultCode = resultCols(0)
            If resultCols.Length > 1 Then ResultText = unescapeString(resultCols(1))
        End If
        Return lines
    End Function

    Public Shared Function unescapeString(ByVal src As String) As String
        Dim dest As String = src
        dest = Replace(dest, "\3", vbLf)
        dest = Replace(dest, "\2", vbCr)
        dest = Replace(dest, "\1", ",")
        dest = Replace(dest, "\0", "\")
        Return dest
    End Function

End Class
