﻿Imports System.Text
Imports System.Net
Imports System.Collections.Specialized

Public Class LionFXSim

    Private Sub LionFXSim_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        cbURL.Text = My.Settings.URL
        cbComCode.SelectedIndex = 0

        SetNowTime(10)
    End Sub

    Private Sub nudLines_ValueChanged(sender As System.Object, e As System.EventArgs) Handles nudLines.ValueChanged
        SetLineEnable(nudLines.Value)
    End Sub

    Private Sub SetLineEnable(Lines As Integer)
        tbID0.Enabled = (Lines > 0)
        tbID1.Enabled = (Lines > 1)
        tbID2.Enabled = (Lines > 2)
        tbID3.Enabled = (Lines > 3)
        tbID4.Enabled = (Lines > 4)
        tbID5.Enabled = (Lines > 5)
        tbID6.Enabled = (Lines > 6)
        tbID7.Enabled = (Lines > 7)
        tbID8.Enabled = (Lines > 8)
        tbID9.Enabled = (Lines > 9)

        tbBid0.Enabled = (Lines > 0)
        tbBid1.Enabled = (Lines > 1)
        tbBid2.Enabled = (Lines > 2)
        tbBid3.Enabled = (Lines > 3)
        tbBid4.Enabled = (Lines > 4)
        tbBid5.Enabled = (Lines > 5)
        tbBid6.Enabled = (Lines > 6)
        tbBid7.Enabled = (Lines > 7)
        tbBid8.Enabled = (Lines > 8)
        tbBid9.Enabled = (Lines > 9)

        tbAsk0.Enabled = (Lines > 0)
        tbAsk1.Enabled = (Lines > 1)
        tbAsk2.Enabled = (Lines > 2)
        tbAsk3.Enabled = (Lines > 3)
        tbAsk4.Enabled = (Lines > 4)
        tbAsk5.Enabled = (Lines > 5)
        tbAsk6.Enabled = (Lines > 6)
        tbAsk7.Enabled = (Lines > 7)
        tbAsk8.Enabled = (Lines > 8)
        tbAsk9.Enabled = (Lines > 9)

        dtpTime0.Enabled = (Lines > 0)
        dtpTime1.Enabled = (Lines > 1)
        dtpTime2.Enabled = (Lines > 2)
        dtpTime3.Enabled = (Lines > 3)
        dtpTime4.Enabled = (Lines > 4)
        dtpTime5.Enabled = (Lines > 5)
        dtpTime6.Enabled = (Lines > 6)
        dtpTime7.Enabled = (Lines > 7)
        dtpTime8.Enabled = (Lines > 8)
        dtpTime9.Enabled = (Lines > 9)

    End Sub

    Private Sub btnNowTime_Click(sender As System.Object, e As System.EventArgs) Handles btnNowTime.Click
        SetNowTime(nudLines.Value)
    End Sub

    Private Sub SetNowTime(Lines As Integer)
        Dim NowTime As DateTime = DateTime.Now
        Dim InitTime As New DateTime(NowTime.Year, NowTime.Month, NowTime.Day, NowTime.Hour, NowTime.Minute, NowTime.Second)
        If Lines > 0 Then dtpTime0.Value = InitTime
        If Lines > 1 Then dtpTime1.Value = InitTime.AddSeconds(-1)
        If Lines > 2 Then dtpTime2.Value = InitTime.AddSeconds(-2)
        If Lines > 3 Then dtpTime3.Value = InitTime.AddSeconds(-3)
        If Lines > 4 Then dtpTime4.Value = InitTime.AddSeconds(-4)
        If Lines > 5 Then dtpTime5.Value = InitTime.AddSeconds(-5)
        If Lines > 6 Then dtpTime6.Value = InitTime.AddSeconds(-6)
        If Lines > 7 Then dtpTime7.Value = InitTime.AddSeconds(-7)
        If Lines > 8 Then dtpTime8.Value = InitTime.AddSeconds(-8)
        If Lines > 9 Then dtpTime9.Value = InitTime.AddSeconds(-9)
    End Sub

    Private Sub btnNewID_Click(sender As System.Object, e As System.EventArgs) Handles btnNewID.Click
        Dim NowID As Integer
        If Not Integer.TryParse(tbID0.Text, NowID) Then
            Exit Sub
        End If
        Dim Lines As Integer = nudLines.Value

        If Lines > 0 Then tbID0.Text = NowID + Lines - 0
        If Lines > 1 Then tbID1.Text = NowID + Lines - 1
        If Lines > 2 Then tbID2.Text = NowID + Lines - 2
        If Lines > 3 Then tbID3.Text = NowID + Lines - 3
        If Lines > 4 Then tbID4.Text = NowID + Lines - 4
        If Lines > 5 Then tbID5.Text = NowID + Lines - 5
        If Lines > 6 Then tbID6.Text = NowID + Lines - 6
        If Lines > 7 Then tbID7.Text = NowID + Lines - 7
        If Lines > 8 Then tbID8.Text = NowID + Lines - 8
        If Lines > 9 Then tbID9.Text = NowID + Lines - 9
    End Sub

    Private Sub btnGet_Click(sender As System.Object, e As System.EventArgs) Handles btnGet.Click
        Read()
    End Sub

    Private Sub Read()
        Dim client As New WebClient
        client.BaseAddress = cbURL.Text
        Dim values As New NameValueCollection
        Dim ComCode As String = cbComCode.Text
        values.Add("comcode", ComCode)
        Dim resdata As Byte() = client.UploadValues("RateTickList.aspx", values)

        Dim res As New ResParser
        Dim reslines As String() = res.parseResponse(resdata)
        If res.ResultCode <> "" Then
            Exit Sub
        End If

        Dim lineindex As Integer = 1
        Dim count As Integer = reslines(lineindex)
        lineindex += 1
        If UBound(reslines) < lineindex + count - 1 Then
            Exit Sub
        End If

        For i As Integer = 0 To count - 1
            Dim ColumnArray() As String = reslines(lineindex).Split(",")
            lineindex += 1

            SetID(i, ColumnArray(1))
            SetBid(ComCode, i, ColumnArray(2))
            SetAsk(ComCode, i, ColumnArray(3))
            SetTime(i, ColumnArray(4))
        Next
    End Sub

    Private Sub SetID(Index As Integer, ID As String)
        Select Case Index
            Case 0 : tbID0.Text = ID
            Case 1 : tbID1.Text = ID
            Case 2 : tbID2.Text = ID
            Case 3 : tbID3.Text = ID
            Case 4 : tbID4.Text = ID
            Case 5 : tbID5.Text = ID
            Case 6 : tbID6.Text = ID
            Case 7 : tbID7.Text = ID
            Case 8 : tbID8.Text = ID
            Case 9 : tbID9.Text = ID
        End Select
    End Sub

    Private Sub SetBid(ComCode As String, Index As Integer, Bid As String)
        Dim FormatString As String
        If ComCode.Substring(3) = "JPY" Then
            FormatString = "######0.000#####"
        Else
            FormatString = "######0.00000###"
        End If
        Dim Rate As Decimal
        If Not Decimal.TryParse(Bid, Rate) Then
            Exit Sub
        End If
        Dim RateText As String = Rate.ToString(FormatString)
        Select Case Index
            Case 0 : tbBid0.Text = RateText
            Case 1 : tbBid1.Text = RateText
            Case 2 : tbBid2.Text = RateText
            Case 3 : tbBid3.Text = RateText
            Case 4 : tbBid4.Text = RateText
            Case 5 : tbBid5.Text = RateText
            Case 6 : tbBid6.Text = RateText
            Case 7 : tbBid7.Text = RateText
            Case 8 : tbBid8.Text = RateText
            Case 9 : tbBid9.Text = RateText
        End Select
    End Sub

    Private Sub SetAsk(ComCode As String, Index As Integer, Ask As String)
        Dim FormatString As String
        If ComCode.Substring(3) = "JPY" Then
            FormatString = "######0.000#####"
        Else
            FormatString = "######0.00000###"
        End If
        Dim Rate As Decimal
        If Not Decimal.TryParse(Ask, Rate) Then
            Exit Sub
        End If
        Dim RateText As String = Rate.ToString(FormatString)
        Select Case Index
            Case 0 : tbAsk0.Text = RateText
            Case 1 : tbAsk1.Text = RateText
            Case 2 : tbAsk2.Text = RateText
            Case 3 : tbAsk3.Text = RateText
            Case 4 : tbAsk4.Text = RateText
            Case 5 : tbAsk5.Text = RateText
            Case 6 : tbAsk6.Text = RateText
            Case 7 : tbAsk7.Text = RateText
            Case 8 : tbAsk8.Text = RateText
            Case 9 : tbAsk9.Text = RateText
        End Select
    End Sub

    Private Sub SetTime(Index As Integer, TimeText As String)
        Dim RateTime As DateTime
        If Not DateTimeUtil.ConvToDateTime(TimeText, DateTimeUtil.ComplementMode.fromTime, RateTime) Then
            Exit Sub
        End If

        Select Case Index
            Case 0 : dtpTime0.Value = RateTime
            Case 1 : dtpTime1.Value = RateTime
            Case 2 : dtpTime2.Value = RateTime
            Case 3 : dtpTime3.Value = RateTime
            Case 4 : dtpTime4.Value = RateTime
            Case 5 : dtpTime5.Value = RateTime
            Case 6 : dtpTime6.Value = RateTime
            Case 7 : dtpTime7.Value = RateTime
            Case 8 : dtpTime8.Value = RateTime
            Case 9 : dtpTime9.Value = RateTime
        End Select
    End Sub

    Private Sub btnRegist_Click(sender As System.Object, e As System.EventArgs) Handles btnRegist.Click
        Dim client As New WebClient
        client.BaseAddress = cbURL.Text
        Dim values As New NameValueCollection
        Dim ComCode As String = cbComCode.Text
        values.Add("comcode", ComCode)

        If nudLines.Value > 0 Then
            values.Add("id0", tbID0.Text)
            values.Add("bid0", tbBid0.Text)
            values.Add("ask0", tbAsk0.Text)
            values.Add("time0", dtpTime0.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 1 Then
            values.Add("id1", tbID1.Text)
            values.Add("bid1", tbBid1.Text)
            values.Add("ask1", tbAsk1.Text)
            values.Add("time1", dtpTime1.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 2 Then
            values.Add("id2", tbID2.Text)
            values.Add("bid2", tbBid2.Text)
            values.Add("ask2", tbAsk2.Text)
            values.Add("time2", dtpTime2.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 3 Then
            values.Add("id3", tbID3.Text)
            values.Add("bid3", tbBid3.Text)
            values.Add("ask3", tbAsk3.Text)
            values.Add("time3", dtpTime3.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 4 Then
            values.Add("id4", tbID4.Text)
            values.Add("bid4", tbBid4.Text)
            values.Add("ask4", tbAsk4.Text)
            values.Add("time4", dtpTime4.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 5 Then
            values.Add("id5", tbID5.Text)
            values.Add("bid5", tbBid5.Text)
            values.Add("ask5", tbAsk5.Text)
            values.Add("time5", dtpTime5.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 6 Then
            values.Add("id6", tbID6.Text)
            values.Add("bid6", tbBid6.Text)
            values.Add("ask6", tbAsk6.Text)
            values.Add("time6", dtpTime6.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 7 Then
            values.Add("id7", tbID7.Text)
            values.Add("bid7", tbBid7.Text)
            values.Add("ask7", tbAsk7.Text)
            values.Add("time7", dtpTime7.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 8 Then
            values.Add("id8", tbID8.Text)
            values.Add("bid8", tbBid8.Text)
            values.Add("ask8", tbAsk8.Text)
            values.Add("time8", dtpTime8.Value.ToString("yyyyMMddHHmmss"))
        End If
        If nudLines.Value > 9 Then
            values.Add("id9", tbID9.Text)
            values.Add("bid9", tbBid9.Text)
            values.Add("ask9", tbAsk9.Text)
            values.Add("time9", dtpTime9.Value.ToString("yyyyMMddHHmmss"))
        End If

        Dim resdata As Byte() = client.UploadValues("RateTickEdit.aspx", values)

        Dim res As New ResParser
        Dim reslines As String() = res.parseResponse(resdata)
        If res.ResultCode <> "" Then
            Exit Sub
        End If

        Read()
    End Sub
End Class
