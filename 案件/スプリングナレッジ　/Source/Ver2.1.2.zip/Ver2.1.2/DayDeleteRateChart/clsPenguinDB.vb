﻿Imports System.Data.SqlClient
Imports System.Text

Public Class clsPenguinDB

    Public Function InitCurrencyPair(ByRef list As List(Of CurrencyPair)) As Boolean
        Dim ret As Boolean = True

        '通貨ペアを取得
        Dim DBSuccess As Boolean = False
        Dim DBConnStr As String = My.Settings.DB
        Try
            Using con As New SqlConnection(DBConnStr)
                con.Open()
                Using cmd As SqlCommand = con.CreateCommand
                    cmd.CommandText = "select * from [M_CurrencyPair] with ( nolock ) order by [SortOrder]"
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            Dim item As New CurrencyPair
                            item.ComCode = reader("ComCode")
                            item.ComName = reader("ComName")
                            item.DecimalPlaces = reader("DecimalPlaces")
                            item.SortOrder = reader("SortOrder")
                            item.ExcgComCode = reader("ExcgComCode")

                            list.Add(item)
                        End While
                    End Using
                End Using
            End Using

            SystemLog.DBSuccess()
            DBSuccess = True
        Catch ex As Exception
            SystemLog.DBError(ex)
        End Try

        If DBSuccess Then
            If list.Count = 0 Then
                SystemLog.Information("通貨ペアマスタ取得失敗")
            End If
        End If

        Return ret
    End Function

    Public Function DayDelete(ByVal rateChartData As RateChartHist) As Boolean
        Dim Result As Boolean = True

        Try
            Using con As New SqlConnection(My.Settings.DB)
                con.Open()

                Using cmd As SqlCommand = con.CreateCommand
                    Dim sql As New StringBuilder
                    sql.AppendLine("delete from [T_RateChartHist] ")
                    sql.AppendLine(" where [ChartType] = @ChartType and [RateChartTime] < DATEADD(DAY, -@DeleteDay, SYSUTCDATETIME())")

                    cmd.CommandText = sql.ToString
                    cmd.Parameters.Add("@ChartType", SqlDbType.Int).Value = rateChartData.ChartType
                    cmd.Parameters.Add("@DeleteDay", SqlDbType.Int).Value = rateChartData.DeleteDay

                    cmd.Prepare()
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            Result = False
        End Try

        Return Result
    End Function

    Public Function CountDelete(ByVal rateChartData As RateChartHist, ByVal cpList As List(Of CurrencyPair)) As Boolean
        Dim Result As Boolean = True

        Try
            Using con As New SqlConnection(My.Settings.DB)
                con.Open()

                Dim LastSeq As String = ""

                For Each cp In cpList
                    ' 通貨ペアごとに削除
                    Using cmd As SqlCommand = con.CreateCommand

                        'データ指定件数の最後のSeqを取得
                        Dim sql As New StringBuilder
                        sql.AppendLine("with [RateChart] As ( ")
                        sql.AppendLine("  select ROW_NUMBER() over (")
                        sql.AppendLine("    order by rc.RateChartSeq desc")
                        sql.AppendLine("  ) RowNumber, rc.RateChartSeq ")
                        sql.AppendLine("  from T_RateChartHist rc with ( nolock )")
                        sql.AppendLine("  where ComCode = @ComCode and ChartType = @ChartType")
                        sql.AppendLine("  ) select RateChartSeq from [RateChart]")
                        sql.AppendLine("    Where RowNumber = @DeleteCount ")

                        cmd.CommandText = sql.ToString
                        cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = cp.ComCode
                        cmd.Parameters.Add("@ChartType", SqlDbType.Int).Value = rateChartData.ChartType
                        cmd.Parameters.Add("@DeleteCount", SqlDbType.Int).Value = rateChartData.DeleteCount

                        Dim obj As Object = cmd.ExecuteScalar()
                        If IsDBNull(obj) Then
                            LastSeq = ""
                        Else
                            LastSeq = Convert.ToString(obj)
                        End If

                    End Using

                    If LastSeq IsNot Nothing AndAlso LastSeq.Length > 0 Then
                        Using cmd As SqlCommand = con.CreateCommand

                            'データ指定件数以降を削除
                            Dim sql As New StringBuilder
                            sql.AppendLine("delete [T_RateChartHist]")
                            sql.AppendLine(" where ComCode = @ComCode and ChartType = @ChartType and  RateChartSeq < @LastSeq")

                            cmd.CommandText = sql.ToString
                            cmd.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = cp.ComCode
                            cmd.Parameters.Add("@ChartType", SqlDbType.Int).Value = rateChartData.ChartType
                            cmd.Parameters.Add("@LastSeq", SqlDbType.Char, 17).Value = LastSeq

                            cmd.ExecuteNonQuery()
                        End Using
                    Else
                        Result = False
                    End If
                Next

            End Using

            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            Result = False
        End Try

        Return Result
    End Function

End Class
