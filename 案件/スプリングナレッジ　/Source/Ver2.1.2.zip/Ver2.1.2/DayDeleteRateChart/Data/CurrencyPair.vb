﻿Imports System.Data.SqlClient

Public Class CurrencyPair

    Public ComCode As String
    Public ComName As String
    Public DecimalPlaces As Integer
    Public SortOrder As Integer
    Public ExcgComCode As String

End Class
