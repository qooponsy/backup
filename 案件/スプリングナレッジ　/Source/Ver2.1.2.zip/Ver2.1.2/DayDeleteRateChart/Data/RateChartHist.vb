﻿Public Class RateChartHist

    Private Shared list As New List(Of RateChartHist)

    Public Shared Sub Init()

        SetChartType(10, 6, 1000)
        SetChartType(60, 6, 1000)
        SetChartType(300, 10, 0)
        SetChartType(600, 14, 0)
        SetChartType(1800, 34, 0)
        SetChartType(3600, 63, 0)

    End Sub

    Private Shared Sub SetChartType(ByVal chartType As Integer, ByVal deleteDay As Integer, ByVal deleteCnt As Integer)

        Dim rt As New RateChartHist
        rt.ChartType = chartType
        rt.DeleteDay = deleteDay
        rt.DeleteCount = deleteCnt

        list.Add(rt)

    End Sub

    Public Shared Function GetList() As List(Of RateChartHist)
        Return list.ToList()
    End Function

    Public ChartType As Integer
    Public DeleteDay As Integer
    Public DeleteCount As Integer

End Class
