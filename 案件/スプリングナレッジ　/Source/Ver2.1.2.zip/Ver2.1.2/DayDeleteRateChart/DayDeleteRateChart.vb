﻿Imports System.IO
Imports System.Text

Module DayDeleteRateChart

    Private DataBase As clsPenguinDB
    Public ErrorMessage As String = ""

    Private Const MAX_STOP_INTERVAL As Integer = 86400  '最大再実行間隔：86400秒(1日)
    Private Const ErrorLogFileName As String = "DayDeleteRateChart.log"

    Function Main(CmdArgs() As String) As Integer
        SystemLog.InitConsoleApp()

        '　初期処理
        Dim bResult As Boolean = True
        DataBase = New clsPenguinDB

        RateChartHist.Init()
        Dim cpList As New List(Of CurrencyPair)
        bResult = DataBase.InitCurrencyPair(cpList)

        If bResult = False Then
            ErrorMessage = "InitCurrencyPair Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
        Else

            '　全足種分の削除
            For Each obj In RateChartHist.GetList
                If obj.DeleteCount <> 0 Then
                    ' 件数で削除
                    bResult = DataBase.CountDelete(obj, cpList)
                    If bResult = False Then
                        ErrorMessage = "DayDelete Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
                        Exit For
                    End If
                Else
                    ' 日数で削除
                    bResult = DataBase.DayDelete(obj)
                    If bResult = False Then
                        ErrorMessage = "CountDelete Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
                        Exit For
                    End If
                End If
            Next

        End If

        DataBase = Nothing

        If bResult = True Then
            Return 0
        Else
            If ErrorMessage.Length = 0 Then
                ErrorMessage = "Other Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
            End If
            ErrorLogOut(ErrorMessage)
            Return -1
        End If

    End Function

    Public Sub ErrorLogOut(ByVal OutMessage As String)
        Dim StreamErrorLog As StreamWriter

        StreamErrorLog = New StreamWriter(My.Application.Info.DirectoryPath & "\" & ErrorLogFileName, True, Encoding.ASCII)
        StreamErrorLog.Write(OutMessage)
        StreamErrorLog.Close()
        StreamErrorLog = Nothing
    End Sub

End Module
