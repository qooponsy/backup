﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
Imports System.Threading.Tasks
'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsWorkerExecution
	Private blnWorkerStopFlag As Boolean
	Private blnAbortRequest As Boolean
	Private strServiceName As String
	Private strProductComCode As String
	Private strProductCode As String
    Private ProductExercTime As Date
    Private intRateEnableTime As Integer
	Private blnMasterMode As Boolean

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub New()
		blnWorkerStopFlag = False
		blnAbortRequest = False
		strServiceName = "ExecutionAP"
#If REL_DEMO Then
        strServiceName = "ExecutionAPDemoUK"
#End If
#If REL_ST Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_UK Then
        strServiceName = "ExecutionAPUK"
#End If
#If REL_MT4 Then
        strServiceName = "ExecutionAPMT4"
#End If
        strProductComCode = ""
		strProductCode = ""
		ProductExercTime = Nothing
		blnMasterMode = False
	End Sub

	'--------------------------------------------------------------------------
	' ワーカースレッドの初期設定
	'--------------------------------------------------------------------------
    Public Sub InitializeWorkerThread(ByVal ComCode As String, ByVal ProductCode As String, ByVal ExercTime As Date, ByVal bMasterMode As Boolean, ByVal RateEnableTime As Integer)
        blnWorkerStopFlag = False
        blnMasterMode = bMasterMode
        strProductComCode = ComCode
        strProductCode = ProductCode
        ProductExercTime = ExercTime
        intRateEnableTime = RateEnableTime
    End Sub

	'--------------------------------------------------------------------------
	' ワーカースレッドからのサービス中断要求
	'--------------------------------------------------------------------------
	Public Function IsAbortRequest() As Boolean
		Return blnAbortRequest
	End Function

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub WorkerThread(ByVal State As Object)
		Dim ARE As AutoResetEvent = CType(State, AutoResetEvent)

		If strProductCode <> "" And blnMasterMode = True Then
			'Try
			WorkerProc()
			'Catch ex As Exception
			'Logging("WorkerThread Exception:" & ex.Message, EventLogEntryType.Error)
			'End Try
		End If

		ARE.Set()
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Private Sub WorkerProc()
		Dim DataBase As clsPenguinDB
		Dim ExecRateTable As DataTable
		Dim TradeList As DataTable
		Dim TradeRow As DataRow
		Dim bResultDB As Boolean
		Dim ExecData As clsExecutionData

		ExecData = New clsExecutionData
		DataBase = New clsPenguinDB
        bResultDB = DataBase.GetSqlConnection(My.Settings.DB)
		If bResultDB = True Then
			ExecRateTable = Nothing
			TradeList = Nothing
            ExecData.UserID = "P:" & My.Settings.ProcessID
            ExecData.SysDate = DataBase.GetSysDate()
            ExecData.CurrencyDecimalPlaces = DataBase.GetCurrency()
			If DataBase.IsError() = True Then
                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
				bResultDB = False
			End If

			If bResultDB = True Then
				ExecData.ProductCode = strProductCode
				ExecData.ExercTime = ProductExercTime

				bResultDB = DataBase.GetExecutionRate(strProductComCode, ExecData.ExercTime, ExecRateTable)
				If bResultDB = False Then
                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)					' Error:GetExecutionRate
				End If

				If bResultDB = True Then
					If ExecRateTable.Rows.Count() > 0 Then
						ExecData.ExercRateSeq = ExecRateTable.Rows(0).Item("RateSeq").ToString()
                        ExecData.ExercRateTime = CDate(ExecRateTable.Rows(0).Item("RateTime"))
						ExecData.ExercRate = CDec(ExecRateTable.Rows(0).Item("Rate"))

                        Debug.Print("ExercRate Seq:" & ExecData.ExercRateSeq & ",Rate:" & ExecData.ExercRate.ToString())

                        If intRateEnableTime <= ProductExercTime.Subtract(ExecData.ExercRateTime).TotalSeconds Then
                            'レート有効期限切れ
                            Logging(String.Format("レート有効期限切れ 銘柄コード:{0},レートSeq:{1}", strProductCode, ExecData.ExercRateSeq), EventLogEntryType.Error)
                            bResultDB = DataBase.UpdateExecutionStatusError(ExecData.ProductCode)
                            If Not bResultDB Then
                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)        ' Error:UpdateExecutionStatusErrot
                            End If
                        Else
                            bResultDB = DataBase.UpdateExecutionRate(strProductComCode, ExecData.ExercRateSeq, ExecData.ExercTime)
                            If bResultDB = True Then
                                bResultDB = DataBase.UpdateExecutionStatus(ExecData.ProductCode, ExecData.ExercRateSeq, ExecData.ExercRate)
                                If bResultDB = True Then
                                    bResultDB = DataBase.GetTradeList(ExecData.ProductCode, TradeList)
                                    If bResultDB = True Then
                                        Dim ExecutionListQueueItemList(My.Settings.ExecutionThreadCount) As ExecutionQueueItem
                                        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
                                            ExecutionListQueueItemList(fa) = New ExecutionQueueItem
                                        Next
                                        Dim QueueIndex As Integer = 0
                                        For Each TradeRow In TradeList.Rows
                                            Try
                                                ExecData.TradeType = TradeRow.Item("TradeType").ToString()
                                                ExecData.TradeSeq = TradeRow.Item("TradeSeq").ToString()
                                                ExecData.ExercPrice = CDec(TradeRow.Item("ExercPrice"))
                                                ExecData.CurCode = TradeRow.Item("CurCode").ToString()
                                                ExecData.Premium = CDec(TradeRow.Item("Premium"))
                                                ExecData.PayoutRate = CDec(TradeRow.Item("PayoutRate"))
                                            Catch ex As Exception
                                                Logging("WorkerProc Exception:Invalid TradeData," & ex.Message, EventLogEntryType.Error)
                                                bResultDB = False
                                            End Try

                                            If bResultDB = True Then
                                                Dim TaskExecData As New clsExecutionData
                                                TaskExecData.Copy(ExecData)
                                                ExecutionListQueueItemList(QueueIndex Mod My.Settings.ExecutionThreadCount).ExecutionList.Add(TaskExecData)
                                                QueueIndex += 1
                                            End If
                                        Next
                                        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
                                            clsExecutionAP.AddExecutionQueue(ExecutionListQueueItemList(fa))
                                        Next

                                        For fa As Integer = 0 To My.Settings.ExecutionThreadCount - 1
                                            ExecutionListQueueItemList(fa).Signal.WaitOne()
                                            If Not ExecutionListQueueItemList(fa).Result Then
                                                bResultDB = False
                                            End If
                                        Next

                                        If bResultDB = True Then
                                            bResultDB = DataBase.EndExecutionProduct(ExecData.ProductCode)
                                            If bResultDB = True Then
                                                Debug.Print("End Execution Product:" & ExecData.ProductCode)
                                            Else
                                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)    ' Error:EndExecutionProduct
                                            End If
                                        End If
                                    Else
                                        'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)    ' Error:GetTradeList
                                    End If
                                Else
                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)        ' Error:UpdateExecutionStatus
                                End If
                            Else
                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)            ' Error:UpdateExecutionRate
                            End If

                        End If

                    End If
                End If
            End If
            DataBase.EndSqlConnection()
        Else
            'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)    ' Error:GetSqlConnection
        End If

        DataBase = Nothing
	End Sub

    '--------------------------------------------------------------------------
    ' ワーカースレッドの停止要求
    '--------------------------------------------------------------------------
    Public Sub StopWorker()
        blnWorkerStopFlag = True
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行
    '--------------------------------------------------------------------------
    Public Sub OnWorkerMasterMode()
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行
    '--------------------------------------------------------------------------
    Public Sub OnWorkerSlaveMode()
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog
        Dim sWorkerMsg As String

        If strProductCode <> "" Then
            Try
                sWorkerMsg = "(" & strProductComCode & ":" & strProductCode & ")-" & sMessage
                eLog = New EventLog()
                eLog.Source = strServiceName
                eLog.WriteEntry(sWorkerMsg, entryType)
                eLog = Nothing
                Debug.Print(sWorkerMsg)
            Catch ex As Exception
                Debug.Print(ex.Message)
            End Try
        End If
    End Sub

End Class
