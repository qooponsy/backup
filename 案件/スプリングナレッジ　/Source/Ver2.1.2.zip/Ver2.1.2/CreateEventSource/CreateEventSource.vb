﻿Module CreateEventSource

    Sub Main(ByVal CmdArgs() As String)
        Const sLog As String = "Application"
        Dim eventSourceName As String

        If CmdArgs.Length = 0 Then
            Console.WriteLine("イベントソース名を指定してください")
            Exit Sub
        Else
            eventSourceName = CmdArgs(0)
            If EventLog.SourceExists(eventSourceName) Then
                Console.WriteLine("イベントソースは既に作成されています:{0}", New Object() {eventSourceName})
                Exit Sub
            End If
            EventLog.CreateEventSource(eventSourceName, sLog)
            Console.WriteLine("イベントソース作成:{0}", New Object() {eventSourceName})
        End If
    End Sub

End Module
