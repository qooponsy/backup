﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsDataDelivery
	Private intThreadNum As Integer
	Private strServiceName As String
    Private ServiceStopSignal As ManualResetEvent
	Private blnMasterMode As Boolean
    Private ServerDateTime As Date
    Private HolidayCheckMinutesList As List(Of Integer)

    Private WorkerClass() As clsWorkerDeliver

	Private MasterHB() As Byte
	Private SlaveHB() As Byte
	Private HeartBeatUDP As UdpClient
	Private HeartBeatWatch As Stopwatch		' HeartBeat間隔用
	Private MasterWatch As Stopwatch		' Master/Slave切替時間用
	Private RunmodeWatch As Stopwatch		' RunMode判定間隔用
	Private DeliveryWatch1 As Stopwatch		' 配信データ検査間隔用(早い周期)
	Private DeliveryWatch2 As Stopwatch		' 配信データ検査間隔用(遅い周期)

	'--------------------------------------------------------------------------
	' 配信用データテーブル
	'--------------------------------------------------------------------------
	Private DataSession As clsDeliveryObject
	Private DataProduct As clsDeliveryObject
	Private DataProductBase As clsDeliveryObject
	Private DataSysSettings As clsDeliveryObject
	Private DataSysStatus As clsDeliveryObject
	Private DataCalcParam As clsDeliveryObject
	'--------------------------------------------------------------------------
	' クラスコンストラクタ
	'--------------------------------------------------------------------------
	Public Sub New()
        intThreadNum = 0
		strServiceName = "DataDelivery"
#If REL_DEMO Then
        strServiceName = "DataDeliveryDemoUK"
#End If
#If REL_ST Then
        strServiceName = "DataDeliveryUK"
#End If
#If REL_UK Then
        strServiceName = "DataDeliveryUK"
#End If
#If REL_MT4 Then
        strServiceName = "DataDeliveryMT4"
#End If
        blnMasterMode = False

		DataSession = New clsDeliveryObject(clsDeliveryTelegram.TYPE_INIT_SESSION)
		DataProduct = New clsDeliveryObject(clsDeliveryTelegram.TYPE_INIT_PRODUCT)
		DataProductBase = New clsDeliveryObject(clsDeliveryTelegram.TYPE_PRODUCT_BASE)
		DataSysSettings = New clsDeliveryObject(clsDeliveryTelegram.TYPE_SYS_SETTINGS)
		DataSysStatus = New clsDeliveryObject(clsDeliveryTelegram.TYPE_SYS_STATUS)
		DataCalcParam = New clsDeliveryObject(clsDeliveryTelegram.TYPE_CALC_PARAM)

	End Sub

	'--------------------------------------------------------------------------
	' マスターモード稼動判定
	'--------------------------------------------------------------------------
	Public Function IsMasterMode() As Boolean
		Return blnMasterMode
    End Function

    Public Function GetMasterPriority() As Integer
        Return My.Settings.MasterPriority
    End Function

    Public Function GetProcessID() As String
        Return My.Settings.ProcessID
    End Function

	'--------------------------------------------------------------------------
	' Service制御スレッドの初期設定
	'--------------------------------------------------------------------------
    Public Function InitializeServiceThread() As Boolean
        Dim bInitRes As Boolean

        bInitRes = True

        ServiceStopSignal = New ManualResetEvent(False)

        '----------------------------------------------------------------------
        ' ハートビート電文の編集
        '----------------------------------------------------------------------
        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)

        Dim HolidayCheckMinutes() As String = My.Settings.HolidayCheckMinutes.Split(",")
        HolidayCheckMinutesList = New List(Of Integer)
        For Each CheckMinutes As String In HolidayCheckMinutes
            HolidayCheckMinutesList.Add(Integer.Parse(CheckMinutes))
        Next

        Return bInitRes
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッド
    '--------------------------------------------------------------------------
    Public Sub ServiceThread()
        Logging("ServiceThread Start.", EventLogEntryType.Information)

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew
        RunmodeWatch = Stopwatch.StartNew
        DeliveryWatch1 = Stopwatch.StartNew
        DeliveryWatch2 = Stopwatch.StartNew

        If Not ServiceStopSignal.WaitOne(0) Then

            '-----------------------------------------------------------------
            ' 初期状態としてSlaveモードに設定
            '-----------------------------------------------------------------
            OnSlaveMode()

            '-----------------------------------------------------------------
            ' 生存確認のStopWatch開始
            '-----------------------------------------------------------------
            HeartBeatWatch = Stopwatch.StartNew

            '-----------------------------------------------------------------
            ' 実行制御初期化
            '-----------------------------------------------------------------
            RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTime)
            Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)

            '-----------------------------------------------------------------
            ' 停止フラグ=Trueになるまでサービス処理をLoop
            '-----------------------------------------------------------------
            While True
                CheckMasterAlive()
                CheckRunMode()

                If blnMasterMode Then
                    'Master Mode
                    MasterLoop()
                Else
                    'Slave Mode
                End If

                If ServiceStopSignal.WaitOne(500) Then Exit While
            End While
        End If

        DeliveryWatch2.Stop()
        DeliveryWatch1.Stop()
        RunmodeWatch.Stop()
        MasterWatch.Stop()
        HeartBeatUDP.Close()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master Mode Loop
    '--------------------------------------------------------------------------
    Public Sub MasterLoop()
        Dim IndexWorker As Integer
        Dim DeliverList As DataTable = Nothing
        Dim WorkerWaitHandles() As WaitHandle

        intThreadNum = 0
        Dim DataBase As clsPenguinDB
        DataBase = New clsPenguinDB
        If DataBase.GetSqlConnection(My.Settings.DB) = True Then
            If DataBase.GetDeliveryList(DeliverList) = True Then
                intThreadNum = DeliverList.Rows.Count
            End If
            DataBase.EndSqlConnection()
        End If
        DataBase = Nothing

        If intThreadNum > 0 AndAlso GetInitialDeliveryData() = True Then
            Dim CheckTimePrev As DateTime = DateTime.Now

            '-----------------------------------------------------
            ' スレッド生成、初期設定
            '-----------------------------------------------------
            ReDim WorkerClass(intThreadNum - 1)
            ReDim WorkerWaitHandles(intThreadNum - 1)
            For IndexWorker = 0 To intThreadNum - 1
                WorkerClass(IndexWorker) = New clsWorkerDeliver
                WorkerWaitHandles(IndexWorker) = New ManualResetEvent(False)

                WorkerClass(IndexWorker).InitializeWorkerThread(DeliverList.Rows(IndexWorker).Item("ServerIP"), DeliverList.Rows(IndexWorker).Item("ServerPort"))
                WorkerClass(IndexWorker).SetInitialDeliveryData(DataSession.DeliveryData, DataProduct.DeliveryData, DataProductBase.DeliveryData, DataSysSettings.DeliveryData, DataSysStatus.DeliveryData, DataCalcParam.DeliveryData)
            Next

            '-----------------------------------------------------
            ' スレッド実行
            '-----------------------------------------------------
            For IndexWorker = 0 To intThreadNum - 1
                ThreadPool.QueueUserWorkItem(AddressOf WorkerClass(IndexWorker).WorkerThread, WorkerWaitHandles(IndexWorker))
            Next

            '-----------------------------------------------------
            ' ワーカースレッド停止待機
            '-----------------------------------------------------
            Logging("Master Loop Start.", EventLogEntryType.Information)

            Dim TermMaster As Boolean = False
            While True
                Dim RetWaitHandle As Integer = WaitHandle.WaitAny(WorkerWaitHandles, My.Settings.WatchInterval)
                If RetWaitHandle <> WaitHandle.WaitTimeout Then
                    If Not TermMaster AndAlso Not ServiceStopSignal.WaitOne(0) Then
                        Dim mre As ManualResetEvent = WorkerWaitHandles(RetWaitHandle)
                        mre.Reset()
                        ThreadPool.QueueUserWorkItem(AddressOf WorkerClass(RetWaitHandle).WorkerThread, WorkerWaitHandles(RetWaitHandle))
                    Else
                        If WaitHandle.WaitAll(WorkerWaitHandles, 0) Then Exit While
                    End If
                End If
                If Not CheckMasterAlive() Then
                    TermMaster = True
                End If
                CheckRunMode()
                Dim HolidayDBAccess As Boolean = False
                Dim CheckTimeNew As DateTime = DateTime.Now
                For Each CheckMinutes As Integer In HolidayCheckMinutesList
                    If CheckTimePrev.Minute < CheckMinutes And CheckTimeNew.Minute >= CheckMinutes Then
                        HolidayDBAccess = True
                        Exit For
                    End If
                Next
                CheckTimePrev = CheckTimeNew
                If Not TermMaster AndAlso (RunningContoroller.Running OrElse HolidayDBAccess) Then
                    CheckDeliveryData(HolidayDBAccess)
                End If
            End While
            Logging("Master Loop Stop.", EventLogEntryType.Information)

            '-----------------------------------------------------------------
            ' Workerスレッドのクリア処理
            '-----------------------------------------------------------------
            For IndexWorker = 0 To intThreadNum - 1
                WorkerWaitHandles(IndexWorker) = Nothing
                WorkerClass(IndexWorker) = Nothing
            Next
        Else
            Logging("ServiceThread Error:GetInitialDeliveryData()", EventLogEntryType.Error)
        End If

    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド、及びワーカースレッドの停止要求
    '--------------------------------------------------------------------------
	Public Sub StopService()
		Dim IndexWorker As Integer

        ServiceStopSignal.Set()
        If intThreadNum > 0 Then
            For IndexWorker = 0 To intThreadNum - 1
                If WorkerClass(IndexWorker) IsNot Nothing Then
                    WorkerClass(IndexWorker).StopWorker()
                End If
            Next
        End If
	End Sub

	'--------------------------------------------------------------------------
	' Slave->Master移行イベント
	'--------------------------------------------------------------------------
	Public Sub OnMasterMode()
        blnMasterMode = True

		Logging("Master Mode Start.", EventLogEntryType.Information)
	End Sub

	'--------------------------------------------------------------------------
	' Master->Slave移行イベント
	'--------------------------------------------------------------------------
	Public Sub OnSlaveMode()
		Dim IndexWorker As Integer

		blnMasterMode = False
		For IndexWorker = 0 To intThreadNum - 1
            WorkerClass(IndexWorker).StopWorker()
        Next

		Logging("Slave Mode Start.", EventLogEntryType.Information)
	End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
	Public Function GetInitialDeliveryData() As Boolean
		Dim DataBase As clsPenguinDB
		Dim bResult As Boolean
		Dim ListData As DataTable

		Try
			DataBase = New clsPenguinDB
            If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                ListData = Nothing
                bResult = DataBase.GetServerDateTime(ListData)
                If bResult = True Then
                    ServerDateTime = CDate(ListData.Rows(0).Item("ServerDateTime").ToString())
                End If
                If bResult = True Then
                    bResult = DataBase.GetSessionList(ListData)
                    If bResult = True Then
                        DataSession.SetDeliveryData(ListData, True)
                    End If
                End If
                If bResult = True Then
                    bResult = DataBase.GetProductList(ListData)
                    If bResult = True Then
                        DataProduct.SetDeliveryData(ListData, True)
                    End If
                End If
                If bResult = True Then
                    bResult = DataBase.GetProductBaseList(ListData)
                    If bResult = True Then
                        DataProductBase.SetDeliveryData(ListData, True)
                    End If
                End If
                If bResult = True Then
                    bResult = DataBase.GetSysSettingsList(ListData)
                    If bResult = True Then
                        DataSysSettings.SetDeliveryData(ListData, True)
                    End If
                End If
                If bResult = True Then
                    bResult = DataBase.GetSysStatusList(ListData)
                    If bResult = True Then
                        DataSysStatus.SetDeliveryData(ListData, True)
                    End If
                End If
                If bResult = True Then
                    bResult = DataBase.GetCalcParamList(ListData)
                    If bResult = True Then
                        DataCalcParam.SetDeliveryData(ListData, True)
                    End If
                End If
                DataBase.EndSqlConnection()
            End If
		Catch ex As Exception
			SystemLog.AppError(ex)
		End Try
		DataBase = Nothing

		Return bResult
	End Function

	'--------------------------------------------------------------------------
	' ハートビート送受信による、生存確認とモードの切替(Master/Slave)
	'--------------------------------------------------------------------------
	Public Function CheckMasterAlive() As Boolean
		Dim RemoteEP As IPEndPoint
		Dim bMasterRecv As Boolean
		Dim bSlaveRecv As Boolean
		Dim sHeartBeatMode As String
		Dim iHeartBeatPriority As Integer

        If HeartBeatWatch.ElapsedMilliseconds() >= My.Settings.HeartBeatCycle Then
            HeartBeatWatch.Restart()

            bMasterRecv = False
            bSlaveRecv = False
            iHeartBeatPriority = 9
            If HeartBeatUDP.Available() > 0 Then
                Dim sDataHB As String
                Dim DataHB() As Byte

                RemoteEP = Nothing
                Try
                    DataHB = Nothing
                    While HeartBeatUDP.Available() > 0
                        DataHB = HeartBeatUDP.Receive(RemoteEP)
                    End While
                    sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                    Do
                        Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                        If NextIndex = -1 Then Exit Do
                        If sDataHB.Length - NextIndex < 3 Then Exit Do
                        sDataHB = sDataHB.Substring(NextIndex)
                    Loop While True
                    If My.Settings.HeartBeatLog Then
                        SystemLog.Information(sDataHB)
                    End If
                    If sDataHB.Length >= 3 Then
                        sHeartBeatMode = sDataHB.Substring(1, 1)
                        iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                        If sHeartBeatMode.Equals("M") = True Then
                            bMasterRecv = True
                            MasterWatch.Restart()
                        End If
                        If sHeartBeatMode.Equals("S") = True Then
                            bSlaveRecv = True
                        End If
                    End If
                Catch ex As Exception
                    If My.Settings.HeartBeatLog Then
                        SystemLog.AppError(ex)
                    End If
                End Try
            End If

            If blnMasterMode = True Then
                If bMasterRecv = True Then
                    ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                    If iHeartBeatPriority < My.Settings.MasterPriority Then
                        OnSlaveMode()
                        MasterWatch.Restart()
                    End If
                End If
            Else
                If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                    OnMasterMode()
                    MasterWatch.Restart()
                ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                    If SystemLog.GetDBErrorCount() > 0 Then
                        If My.Settings.HeartBeatLog Then
                            SystemLog.Information("DB Error Now.")
                        End If
                    Else
                        OnMasterMode()
                        MasterWatch.Restart()
                    End If
                End If
            End If

            Try
                If blnMasterMode Then
                    HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
                Else
                    HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then
                    SystemLog.AppError(ex)
                End If
            End Try
        End If

		Return blnMasterMode
	End Function

	'--------------------------------------------------------------------------
	' 時間設定によるRunMode判定
    '--------------------------------------------------------------------------
    Private Sub CheckRunMode()
        If RunmodeWatch.ElapsedMilliseconds >= My.Settings.WatchRunMode Then
            RunmodeWatch.Restart()
            Try
                If RunningContoroller.check() Then
                    Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
                Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
            End Try
        End If
    End Sub

	'--------------------------------------------------------------------------
	' 時間設定による配信データ検査
	'--------------------------------------------------------------------------
    Private Sub CheckDeliveryData(Force As Boolean)
        Dim DataBase As clsPenguinDB
        Dim bResult As Boolean
        Dim DataList As DataTable
        Dim DeliverList As DataTable

        '----------------------------------------------------------
        ' 早い周期で検査が必要なグループ
        '----------------------------------------------------------
        If Force OrElse DeliveryWatch1.ElapsedMilliseconds >= My.Settings.WatchDelivery1 Then
            DeliveryWatch1.Restart()

            Try
                DataBase = New clsPenguinDB
                If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                    DataList = Nothing
                    DeliverList = Nothing

                    ''----------------------------------------------------------
                    '' ServerDateTime (HeartBeat用システム日付)
                    ''----------------------------------------------------------
                    'bResult = DataBase.GetServerDateTime(DataList)
                    'If bResult = True Then
                    '    ServerDateTime = CDate(DataList.Rows(0).Item("ServerDateTime").ToString())
                    '    AddDeliveryQueue(clsDeliveryTelegram.TYPE_HB_DELIVER, DataList)
                    'End If

                    '----------------------------------------------------------
                    ' Session
                    '----------------------------------------------------------
                    bResult = DataBase.GetSessionList(DataList)
                    If bResult = True Then
                        DataSession.CreateDiffSession(DataList, DeliverList)
                        If DeliverList.Rows.Count() > 0 Then
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_INIT_SESSION, DataSession.DeliveryData)
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_DIFF_SESSION, DeliverList)
                        End If
                    End If

                    '----------------------------------------------------------
                    ' SysStatus
                    '----------------------------------------------------------
                    bResult = DataBase.GetSysStatusList(DataList)
                    If bResult = True Then
                        DataSysStatus.CreateDeliverSysStatus(DataList, DeliverList)
                        If DeliverList.Rows.Count() > 0 Then
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_SYS_STATUS, DeliverList)
                        End If
                    End If
                    DataBase.EndSqlConnection()
                Else
                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
                Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
            End Try
            DataBase = Nothing

        End If

        '----------------------------------------------------------
        ' 早い周期で検査が不要なグループ
        '----------------------------------------------------------
        If Force OrElse DeliveryWatch2.ElapsedMilliseconds >= My.Settings.WatchDelivery2 Then
            DeliveryWatch2.Restart()

            Try
                DataBase = New clsPenguinDB
                If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                    DataList = Nothing
                    DeliverList = Nothing
                    '----------------------------------------------------------
                    ' Product
                    '----------------------------------------------------------
                    bResult = DataBase.GetProductList(DataList)
                    If bResult = True Then
                        DataProduct.CreateDiffProduct(DataList, DeliverList)
                        If DeliverList.Rows.Count() > 0 Then
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_INIT_PRODUCT, DataProduct.DeliveryData)
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_DIFF_PRODUCT, DeliverList)
                        End If
                    End If

                    '----------------------------------------------------------
                    ' ProductBase
                    '----------------------------------------------------------
                    bResult = DataBase.GetProductBaseList(DataList)
                    If bResult = True Then
                        bResult = DataProductBase.CreateDeliverProductBase(DataList, DeliverList)
                        If bResult Then
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_PRODUCT_BASE, DeliverList)
                        End If
                    End If

                    '----------------------------------------------------------
                    ' SysSetting
                    '----------------------------------------------------------
                    bResult = DataBase.GetSysSettingsList(DataList)
                    If bResult = True Then
                        DataSysSettings.CreateDeliverSysSettings(DataList, DeliverList)
                        If DeliverList.Rows.Count() > 0 Then
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_SYS_SETTINGS, DeliverList)
                        End If
                    End If

                    '----------------------------------------------------------
                    ' CalcParam
                    '----------------------------------------------------------
                    bResult = DataBase.GetCalcParamList(DataList)
                    If bResult = True Then
                        DataCalcParam.CreateDeliverCalcParam(DataList, DeliverList)
                        If DeliverList.Rows.Count() > 0 Then
                            AddDeliveryQueue(clsDeliveryTelegram.TYPE_CALC_PARAM, DeliverList)
                        End If
                    End If
                    DataBase.EndSqlConnection()
                Else
                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                End If
            Catch ex As Exception
                SystemLog.ExceptionError(ex)
                Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
            End Try
            DataBase = Nothing
        End If
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
	Private Sub AddDeliveryQueue(ByVal QueueType As String, ByVal DataList As DataTable)
		Dim IndexWorker As Integer

		For IndexWorker = 0 To intThreadNum - 1
			WorkerClass(IndexWorker).AddDeliveryQueue(QueueType, DataList)
		Next
	End Sub

    '--------------------------------------------------------------------------
    ' ログ出力
    '--------------------------------------------------------------------------
	Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
		Dim eLog As EventLog

		Try
			Debug.Print(sMessage)
			eLog = New EventLog()
			eLog.Source = strServiceName
			eLog.WriteEntry(sMessage, entryType)
			eLog = Nothing
		Catch ex As Exception
			Debug.Print(ex.Message)
		End Try
	End Sub

End Class
