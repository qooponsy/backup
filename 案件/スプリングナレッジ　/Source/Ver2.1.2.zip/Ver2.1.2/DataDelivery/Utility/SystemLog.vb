﻿Imports System.Threading

Public Class SystemLog
	Private Const EVENT_SOURCE As String = "LionBO"
	Private Const ALERT_MESSAGE_TEL As String = "LionBO ALERT TEL:"
	Private Const ALERT_MESSAGE_MAIL As String = "LionBO ALERT MAIL:"

	Public Shared Sub AppError(ByVal ex As Exception)
		EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """", EventLogEntryType.Error)
		ExceptionError(ex)
	End Sub

	Public Shared Sub Information(ByVal Msg As String)
		EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Information)
	End Sub

	Public Shared Sub ErrorTEL(ByVal AlertMsg As String, ByVal Msg As String)
		EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """ " & AlertMsg, EventLogEntryType.Error)
		EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Warning)
	End Sub

	Public Shared Sub ErrorMAIL(ByVal AlertMsg As String, ByVal Msg As String)
		EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_MAIL & "Error Process """ & My.Settings.ProcessID & """ " & AlertMsg, EventLogEntryType.Error)
		EventLog.WriteEntry(EVENT_SOURCE, "[" & My.Settings.ProcessID & "] " & Msg, EventLogEntryType.Warning)
	End Sub

	Private Shared DBErrorCounter As Integer = 0

	Public Shared Function GetDBErrorCount() As Integer
		Return DBErrorCounter
	End Function

	Public Shared Sub DBSuccess()
		Dim OldErrorCounter As Integer = Interlocked.Exchange(DBErrorCounter, 0)
		If OldErrorCounter > 0 Then
			Information(String.Format("Main DB Success (ErrorCount:{0})", OldErrorCounter))
		End If
	End Sub

	Public Shared Sub DBError(ByVal ex As Exception)
		Dim ErrorCount As Integer = 0
		ErrorCount = Interlocked.Increment(DBErrorCounter)
		If ErrorCount <= 3 Then
			EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """ Main DB Error", EventLogEntryType.Error)
		End If
		If ErrorCount <= 32 Then
			ExceptionError(ex)
		End If
	End Sub

	Private Shared RateRequestErrorCounter As Integer = 0

	Public Shared Sub RateRequestSuccess()
		Interlocked.Exchange(RateRequestErrorCounter, 0)
	End Sub

	Public Shared Sub RateRequestError(ByVal ex As Exception)
		Dim ErrorCount As Integer = 0
		ErrorCount = Interlocked.Increment(RateRequestErrorCounter)
		If ErrorCount = 9 Or ErrorCount = 21 Or ErrorCount = 45 Then
			EventLog.WriteEntry(EVENT_SOURCE, ALERT_MESSAGE_TEL & "Error Process """ & My.Settings.ProcessID & """ Rate Request Error(" & ErrorCount & ")", EventLogEntryType.Error)
		End If
		If ErrorCount <= 32 Then
			ExceptionError(ex)
		End If
	End Sub

	Public Shared Sub ExceptionError(ByVal ex As Exception)
		Dim objErr As Exception = ex
        While (objErr IsNot Nothing)
            Dim st As StackTrace = New StackTrace(3, True)
            EventLog.WriteEntry(EVENT_SOURCE,
                                "PROCESS:" & My.Settings.ProcessID & vbCrLf &
                                "SOURCE:" & objErr.Source & vbCrLf &
                                "MESSAGE:" & objErr.Message & vbCrLf &
                                "TARGET SITE:" & If(Not objErr.TargetSite Is Nothing, objErr.TargetSite.ToString(), "") & vbCrLf &
                                "STACK TRACE:" & If(Not objErr.StackTrace Is Nothing, vbCrLf & objErr.StackTrace.ToString(), "") & vbCrLf & st.ToString(),
                                EventLogEntryType.Warning)
			objErr = objErr.InnerException
		End While
	End Sub

End Class
