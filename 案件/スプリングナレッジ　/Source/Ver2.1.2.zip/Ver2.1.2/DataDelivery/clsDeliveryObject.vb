﻿'------------------------------------------------------------------------------
'
'------------------------------------------------------------------------------
Public Class clsDeliveryObject
	Private dtDelivery As DataTable
	Private blnModifiedFlag As Boolean
	Private strType As String

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Private Const DIFF_MODE_SKIP As Integer = 0
	Private Const DIFF_MODE_INS As Integer = 1
	Private Const DIFF_MODE_UPD As Integer = 2
	Private Const DIFF_MODE_DEL As Integer = 3

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub New(ByVal sType As String)
		dtDelivery = Nothing
		blnModifiedFlag = False
		strType = sType
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Sub SetDeliveryData(ByVal DataList As DataTable, ByVal bFlag As Boolean)
		dtDelivery = DataList.Copy()
		If bFlag = True Then
			blnModifiedFlag = True
		End If
	End Sub

	'--------------------------------------------------------------------------
	' INIT_SESSIONのデータと最新データを比較しDIFF_SESSIONデータを生成
	'--------------------------------------------------------------------------
	Public Sub CreateDiffSession(ByVal NewDataList As DataTable, ByRef DiffDataList As DataTable)
		Dim ListRow As DataRow
		Dim InitRow As DataRow
		Dim DiffRow As DataRow
		Dim iOrgCount As Integer
		Dim iNewCount As Integer
		Dim iOrgIndex As Integer
		Dim iNewIndex As Integer
		Dim sNewKey As String
		Dim sOrgKey As String
		Dim iCompare As Integer
		Dim iMode As Integer

		'----------------------------------------------------------------------
		' 差分DataTableに構造体をClone
		'----------------------------------------------------------------------
		DiffDataList = dtDelivery.Clone()

		iNewCount = NewDataList.Rows.Count
		iOrgCount = dtDelivery.Rows.Count
		iOrgIndex = 0
		iNewIndex = 0
		InitRow = Nothing
        While iNewIndex < iNewCount Or iOrgIndex < iOrgCount
            ListRow = Nothing
            InitRow = Nothing
            If iNewIndex < iNewCount And iOrgIndex < iOrgCount Then
                ListRow = NewDataList.Rows(iNewIndex)
                sNewKey = ListRow.Item("SessionKey").ToString()
                InitRow = dtDelivery.Rows(iOrgIndex)
                sOrgKey = InitRow.Item("SessionKey").ToString()
                iCompare = String.Compare(sNewKey, sOrgKey)
                If iCompare = 0 Then
                    If InitRow.Item("PrivateDataSeq").Equals(ListRow.Item("PrivateDataSeq")) = False OrElse _
                       InitRow.Item("LastCheckTime").Equals(ListRow.Item("LastCheckTime")) = False Then
                        iMode = DIFF_MODE_UPD
                    Else
                        iMode = DIFF_MODE_SKIP
                    End If
                ElseIf iCompare < 0 Then
                    iMode = DIFF_MODE_INS
                Else
                    iMode = DIFF_MODE_DEL
                End If
            ElseIf iNewIndex < iNewCount Then
                ListRow = NewDataList.Rows(iNewIndex)
                iMode = DIFF_MODE_INS
            Else
                InitRow = dtDelivery.Rows(iOrgIndex)
                iMode = DIFF_MODE_DEL
            End If

            Select Case iMode
                Case DIFF_MODE_INS
                    DiffRow = DiffDataList.NewRow()
                    DiffRow.Item("DeliveryType") = "I"
                    DiffRow.Item("SessionKey") = ListRow.Item("SessionKey")
                    DiffRow.Item("AuthType") = ListRow.Item("AuthType")
                    DiffRow.Item("UserID") = ListRow.Item("UserID")
                    DiffRow.Item("ClientType") = ListRow.Item("ClientType")
                    DiffRow.Item("ClientVersion") = ListRow.Item("ClientVersion")
                    DiffRow.Item("LastCheckTime") = ListRow.Item("LastCheckTime")
                    DiffRow.Item("PrivateDataSeq") = ListRow.Item("PrivateDataSeq")
                    DiffRow.Item("TimeMode") = ListRow.Item("TimeMode")
                    DiffRow.Item("LangCode") = ListRow.Item("LangCode")
                    DiffDataList.Rows.Add(DiffRow)
                    iNewIndex = iNewIndex + 1
                Case DIFF_MODE_UPD
                    DiffRow = DiffDataList.NewRow()
                    DiffRow.Item("DeliveryType") = "U"
                    DiffRow.Item("SessionKey") = ListRow.Item("SessionKey")
                    DiffRow.Item("AuthType") = ListRow.Item("AuthType")
                    DiffRow.Item("UserID") = ListRow.Item("UserID")
                    DiffRow.Item("ClientType") = ListRow.Item("ClientType")
                    DiffRow.Item("ClientVersion") = ListRow.Item("ClientVersion")
                    DiffRow.Item("LastCheckTime") = ListRow.Item("LastCheckTime")
                    DiffRow.Item("PrivateDataSeq") = ListRow.Item("PrivateDataSeq")
                    DiffRow.Item("TimeMode") = ListRow.Item("TimeMode")
                    DiffRow.Item("LangCode") = ListRow.Item("LangCode")
                    DiffDataList.Rows.Add(DiffRow)
                    iNewIndex = iNewIndex + 1
                    iOrgIndex = iOrgIndex + 1
                Case DIFF_MODE_SKIP
                    iNewIndex = iNewIndex + 1
                    iOrgIndex = iOrgIndex + 1
                Case DIFF_MODE_DEL
                    DiffRow = DiffDataList.NewRow()
                    DiffRow.Item("DeliveryType") = "D"
                    DiffRow.Item("SessionKey") = InitRow.Item("SessionKey")
                    DiffRow.Item("AuthType") = InitRow.Item("AuthType")
                    DiffRow.Item("UserID") = InitRow.Item("UserID")
                    DiffRow.Item("ClientType") = InitRow.Item("ClientType")
                    DiffRow.Item("ClientVersion") = InitRow.Item("ClientVersion")
                    DiffRow.Item("LastCheckTime") = InitRow.Item("LastCheckTime")
                    DiffRow.Item("PrivateDataSeq") = InitRow.Item("PrivateDataSeq")
                    DiffRow.Item("TimeMode") = InitRow.Item("TimeMode")
                    DiffRow.Item("LangCode") = InitRow.Item("LangCode")
                    DiffDataList.Rows.Add(DiffRow)
                    iOrgIndex = iOrgIndex + 1
            End Select
        End While

        dtDelivery = NewDataList.Copy()
	End Sub

	'--------------------------------------------------------------------------
	' INIT_PRODUCTのデータと最新データを比較しDIFF_PRODUCTデータを生成
	'--------------------------------------------------------------------------
	Public Sub CreateDiffProduct(ByVal NewDataList As DataTable, ByRef DiffDataList As DataTable)
		Dim ListRow As DataRow
		Dim InitRow As DataRow
		Dim DiffRow As DataRow
		Dim iOrgCount As Integer
		Dim iNewCount As Integer
		Dim iOrgIndex As Integer
		Dim iNewIndex As Integer
		Dim sNewKey As String
		Dim sOrgKey As String
		Dim iCompare As Integer
		Dim iMode As Integer

		'----------------------------------------------------------------------
		' 差分DataTableに構造体をClone
		'----------------------------------------------------------------------
		DiffDataList = dtDelivery.Clone()

		iNewCount = NewDataList.Rows.Count
		iOrgCount = dtDelivery.Rows.Count
		iOrgIndex = 0
		iNewIndex = 0
		InitRow = Nothing
        While iNewIndex < iNewCount Or iOrgIndex < iOrgCount
            ListRow = Nothing
            InitRow = Nothing
            If iNewIndex < iNewCount And iOrgIndex < iOrgCount Then
                ListRow = NewDataList.Rows(iNewIndex)
                sNewKey = ListRow.Item("ProductCode").ToString()
                InitRow = dtDelivery.Rows(iOrgIndex)
                sOrgKey = InitRow.Item("ProductCode").ToString()
                iCompare = String.Compare(sNewKey, sOrgKey)
                If iCompare = 0 Then
                    If InitRow.Item("ProductBaseCode").Equals(ListRow.Item("ProductBaseCode")) = False _
                     OrElse InitRow.Item("SysDate").Equals(ListRow.Item("SysDate")) = False _
                     OrElse InitRow.Item("ComCode").Equals(ListRow.Item("ComCode")) = False _
                     OrElse InitRow.Item("OpType").Equals(ListRow.Item("OpType")) = False _
                     OrElse InitRow.Item("OptionTime").Equals(ListRow.Item("OptionTime")) = False _
                     OrElse InitRow.Item("StartTime").Equals(ListRow.Item("StartTime")) = False _
                     OrElse InitRow.Item("ExercTime").Equals(ListRow.Item("ExercTime")) = False _
                     OrElse InitRow.Item("TradeLimitTime").Equals(ListRow.Item("TradeLimitTime")) = False _
                     OrElse InitRow.Item("PayoutRate").Equals(ListRow.Item("PayoutRate")) = False _
                     OrElse InitRow.Item("ExercRateSeq").Equals(ListRow.Item("ExercRateSeq")) = False _
                     OrElse InitRow.Item("ExercRate").Equals(ListRow.Item("ExercRate")) = False _
                     OrElse InitRow.Item("TradeMoneyMin").Equals(ListRow.Item("TradeMoneyMin")) = False _
                     OrElse InitRow.Item("TradeMoneyMax").Equals(ListRow.Item("TradeMoneyMax")) = False Then
                        iMode = DIFF_MODE_UPD
                    Else
                        iMode = DIFF_MODE_SKIP
                    End If
                ElseIf iCompare < 0 Then
                    iMode = DIFF_MODE_INS
                Else
                    iMode = DIFF_MODE_DEL
                End If
            ElseIf iNewIndex < iNewCount Then
                ListRow = NewDataList.Rows(iNewIndex)
                iMode = DIFF_MODE_INS
            Else
                InitRow = dtDelivery.Rows(iOrgIndex)
                iMode = DIFF_MODE_DEL
            End If

            Select Case iMode
                Case DIFF_MODE_INS
                    DiffRow = DiffDataList.NewRow()
                    DiffRow.Item("DeliveryType") = "I"
                    DiffRow.Item("ProductCode") = ListRow.Item("ProductCode")
                    DiffRow.Item("Enabled") = ListRow.Item("Enabled")
                    DiffRow.Item("ProductBaseCode") = ListRow.Item("ProductBaseCode")
                    DiffRow.Item("SysDate") = ListRow.Item("SysDate")
                    DiffRow.Item("ComCode") = ListRow.Item("ComCode")
                    DiffRow.Item("OpType") = ListRow.Item("OpType")
                    DiffRow.Item("OptionTime") = ListRow.Item("OptionTime")
                    DiffRow.Item("StartTime") = ListRow.Item("StartTime")
                    DiffRow.Item("ExercTime") = ListRow.Item("ExercTime")
                    DiffRow.Item("TradeLimitTime") = ListRow.Item("TradeLimitTime")
                    DiffRow.Item("PayoutRate") = ListRow.Item("PayoutRate")
                    DiffRow.Item("ExercStatus") = ListRow.Item("ExercStatus")
                    DiffRow.Item("ExercRateSeq") = ListRow.Item("ExercRateSeq")
                    DiffRow.Item("ExercRate") = ListRow.Item("ExercRate")
                    DiffRow.Item("TradeMoneyMin") = ListRow.Item("TradeMoneyMin")
                    DiffRow.Item("TradeMoneyMax") = ListRow.Item("TradeMoneyMax")
                    DiffDataList.Rows.Add(DiffRow)
                    iNewIndex = iNewIndex + 1
                Case DIFF_MODE_UPD
                    DiffRow = DiffDataList.NewRow()
                    DiffRow.Item("DeliveryType") = "U"
                    DiffRow.Item("ProductCode") = ListRow.Item("ProductCode")
                    DiffRow.Item("Enabled") = ListRow.Item("Enabled")
                    DiffRow.Item("ProductBaseCode") = ListRow.Item("ProductBaseCode")
                    DiffRow.Item("SysDate") = ListRow.Item("SysDate")
                    DiffRow.Item("ComCode") = ListRow.Item("ComCode")
                    DiffRow.Item("OpType") = ListRow.Item("OpType")
                    DiffRow.Item("OptionTime") = ListRow.Item("OptionTime")
                    DiffRow.Item("StartTime") = ListRow.Item("StartTime")
                    DiffRow.Item("ExercTime") = ListRow.Item("ExercTime")
                    DiffRow.Item("TradeLimitTime") = ListRow.Item("TradeLimitTime")
                    DiffRow.Item("PayoutRate") = ListRow.Item("PayoutRate")
                    DiffRow.Item("ExercStatus") = ListRow.Item("ExercStatus")
                    DiffRow.Item("ExercRateSeq") = ListRow.Item("ExercRateSeq")
                    DiffRow.Item("ExercRate") = ListRow.Item("ExercRate")
                    DiffRow.Item("TradeMoneyMin") = ListRow.Item("TradeMoneyMin")
                    DiffRow.Item("TradeMoneyMax") = ListRow.Item("TradeMoneyMax")
                    DiffDataList.Rows.Add(DiffRow)
                    iNewIndex = iNewIndex + 1
                    iOrgIndex = iOrgIndex + 1
                Case DIFF_MODE_SKIP
                    iNewIndex = iNewIndex + 1
                    iOrgIndex = iOrgIndex + 1
                Case DIFF_MODE_DEL
                    DiffRow = DiffDataList.NewRow()
                    DiffRow.Item("DeliveryType") = "D"
                    DiffRow.Item("ProductCode") = InitRow.Item("ProductCode")
                    DiffRow.Item("Enabled") = InitRow.Item("Enabled")
                    DiffRow.Item("ProductBaseCode") = InitRow.Item("ProductBaseCode")
                    DiffRow.Item("SysDate") = InitRow.Item("SysDate")
                    DiffRow.Item("ComCode") = InitRow.Item("ComCode")
                    DiffRow.Item("OpType") = InitRow.Item("OpType")
                    DiffRow.Item("OptionTime") = InitRow.Item("OptionTime")
                    DiffRow.Item("StartTime") = InitRow.Item("StartTime")
                    DiffRow.Item("ExercTime") = InitRow.Item("ExercTime")
                    DiffRow.Item("TradeLimitTime") = InitRow.Item("TradeLimitTime")
                    DiffRow.Item("PayoutRate") = InitRow.Item("PayoutRate")
                    DiffRow.Item("ExercStatus") = InitRow.Item("ExercStatus")
                    DiffRow.Item("ExercRateSeq") = InitRow.Item("ExercRateSeq")
                    DiffRow.Item("ExercRate") = InitRow.Item("ExercRate")
                    DiffRow.Item("TradeMoneyMin") = InitRow.Item("TradeMoneyMin")
                    DiffRow.Item("TradeMoneyMax") = InitRow.Item("TradeMoneyMax")
                    DiffDataList.Rows.Add(DiffRow)
                    iOrgIndex = iOrgIndex + 1
            End Select
        End While

		dtDelivery = NewDataList.Copy()

	End Sub

	'--------------------------------------------------------------------------
	' PRODUCT_BASEのデータと最新データを比較し変更が存在した場合に送信用データを生成
	'--------------------------------------------------------------------------
	Public Function CreateDeliverProductBase(ByVal NewDataList As DataTable, ByRef DeliverDataList As DataTable) As Boolean
		Dim ListRow As DataRow
		Dim InitRow As DataRow
		Dim bModify As Boolean
		Dim iOrgCount As Integer
		Dim iNewCount As Integer
		Dim iIndex As Integer

		iOrgCount = dtDelivery.Rows.Count()
		iNewCount = NewDataList.Rows.Count()
		If iOrgCount <> iNewCount Then
			bModify = True
		Else
			bModify = False
			For iIndex = 0 To iNewCount - 1
				InitRow = dtDelivery.Rows(iIndex)
				ListRow = NewDataList.Rows(iIndex)
				If InitRow.Item("ProductBaseCode").Equals(ListRow.Item("ProductBaseCode")) = False Then
					bModify = True
					Exit For
				End If

                If InitRow.Item("ComCode").Equals(ListRow.Item("ComCode")) = False _
                OrElse InitRow.Item("OpType").Equals(ListRow.Item("OpType")) = False _
                OrElse InitRow.Item("OptionTime").Equals(ListRow.Item("OptionTime")) = False _
                OrElse InitRow.Item("CreateTime").Equals(ListRow.Item("CreateTime")) = False _
                OrElse InitRow.Item("StartTime").Equals(ListRow.Item("StartTime")) = False _
                OrElse InitRow.Item("ExercTime").Equals(ListRow.Item("ExercTime")) = False _
                OrElse InitRow.Item("StartSummerTime").Equals(ListRow.Item("StartSummerTime")) = False _
                OrElse InitRow.Item("ExercSummerTime").Equals(ListRow.Item("ExercSummerTime")) = False _
                OrElse InitRow.Item("PayoutRate").Equals(ListRow.Item("PayoutRate")) = False _
                OrElse InitRow.Item("TradeMoneyMin").Equals(ListRow.Item("TradeMoneyMin")) = False _
                OrElse InitRow.Item("TradeMoneyMax").Equals(ListRow.Item("TradeMoneyMax")) = False Then
                    bModify = True
                    Exit For
                End If
            Next
		End If

		If bModify = True Then
			DeliverDataList = NewDataList.Copy()
			dtDelivery = NewDataList.Copy()
		Else
			DeliverDataList = New DataTable()
		End If

		Return bModify
	End Function

	'--------------------------------------------------------------------------
	' SYS_STATUSのデータと最新データを比較し変更が存在した場合に送信用データを生成
	'--------------------------------------------------------------------------
	Public Function CreateDeliverSysStatus(ByVal NewDataList As DataTable, ByRef DeliverDataList As DataTable) As Boolean
		Dim ListRow As DataRow
		Dim InitRow As DataRow
		Dim bModify As Boolean
		Dim iOrgCount As Integer
		Dim iNewCount As Integer
		Dim iIndex As Integer

		iOrgCount = dtDelivery.Rows.Count()
		iNewCount = NewDataList.Rows.Count()
		If iOrgCount <> iNewCount Then
			bModify = True
		Else
			bModify = False
			For iIndex = 0 To iNewCount - 1
				InitRow = dtDelivery.Rows(iIndex)
				ListRow = NewDataList.Rows(iIndex)
				If InitRow.Item("SysDate").Equals(ListRow.Item("SysDate")) = False _
				OrElse InitRow.Item("SysEnabled").Equals(ListRow.Item("SysEnabled")) = False _
				OrElse InitRow.Item("AbandEnabled").Equals(ListRow.Item("AbandEnabled")) = False _
				OrElse InitRow.Item("CashOutEnabled").Equals(ListRow.Item("CashOutEnabled")) = False _
				OrElse InitRow.Item("CashInEnabled").Equals(ListRow.Item("CashInEnabled")) = False _
				OrElse InitRow.Item("RateProviderID").Equals(ListRow.Item("RateProviderID")) = False _
				OrElse InitRow.Item("SysUpdateSeq").Equals(ListRow.Item("SysUpdateSeq")) = False Then
					bModify = True
					Exit For
				End If
			Next
		End If

		If bModify = True Then
			DeliverDataList = NewDataList.Copy()
			dtDelivery = NewDataList.Copy()
		Else
			DeliverDataList = New DataTable()
		End If

		Return bModify
	End Function

	'--------------------------------------------------------------------------
	' SYS_SETTINGSのデータと最新データを比較し変更が存在した場合に送信用データを生成
	'--------------------------------------------------------------------------
	Public Function CreateDeliverSysSettings(ByVal NewDataList As DataTable, ByRef DeliverDataList As DataTable) As Boolean
		Dim ListRow As DataRow
		Dim InitRow As DataRow
		Dim bModify As Boolean
		Dim iOrgCount As Integer
		Dim iNewCount As Integer
		Dim iIndex As Integer

		iOrgCount = dtDelivery.Rows.Count()
		iNewCount = NewDataList.Rows.Count()
		If iOrgCount <> iNewCount Then
			bModify = True
		Else
			bModify = False
			For iIndex = 0 To iNewCount - 1
				InitRow = dtDelivery.Rows(iIndex)
				ListRow = NewDataList.Rows(iIndex)
                If InitRow.Item("Commission").Equals(ListRow.Item("Commission")) = False _
                OrElse InitRow.Item("TradeMoneyMin").Equals(ListRow.Item("TradeMoneyMin")) = False _
                OrElse InitRow.Item("TradeMoneyMax").Equals(ListRow.Item("TradeMoneyMax")) = False _
                OrElse InitRow.Item("ProductMoneyMax").Equals(ListRow.Item("ProductMoneyMax")) = False _
                OrElse InitRow.Item("CustCountMax").Equals(ListRow.Item("CustCountMax")) = False _
                OrElse InitRow.Item("CustMoneyMax").Equals(ListRow.Item("CustMoneyMax")) = False _
                OrElse InitRow.Item("CustMoneyDayMax").Equals(ListRow.Item("CustMoneyDayMax")) = False _
                OrElse InitRow.Item("CustProductMoneyMax").Equals(ListRow.Item("CustProductMoneyMax")) = False _
                OrElse InitRow.Item("CashInMoneyMin").Equals(ListRow.Item("CashInMoneyMin")) = False _
                OrElse InitRow.Item("CashInMoneyDayMin").Equals(ListRow.Item("CashInMoneyDayMin")) = False _
                OrElse InitRow.Item("CashOutMoneyMax").Equals(ListRow.Item("CashOutMoneyMax")) = False _
                OrElse InitRow.Item("CashOutMoneyDayMax").Equals(ListRow.Item("CashOutMoneyDayMax")) = False _
                OrElse InitRow.Item("ProductStartPreTime").Equals(ListRow.Item("ProductStartPreTime")) = False _
                OrElse InitRow.Item("ProductEndLossTime").Equals(ListRow.Item("ProductEndLossTime")) = False _
                OrElse InitRow.Item("RateEnableTime").Equals(ListRow.Item("RateEnableTime")) = False _
                OrElse InitRow.Item("TimeZone").Equals(ListRow.Item("TimeZone")) = False _
                OrElse InitRow.Item("SysDateTimeZone").Equals(ListRow.Item("SysDateTimeZone")) = False _
                OrElse InitRow.Item("AlertDayPAndL").Equals(ListRow.Item("AlertDayPAndL")) = False _
                OrElse InitRow.Item("AlertDayPAndLCust").Equals(ListRow.Item("AlertDayPAndLCust")) = False Then
                    bModify = True
                    Exit For
                End If
            Next
		End If

		If bModify = True Then
			DeliverDataList = NewDataList.Copy()
			dtDelivery = NewDataList.Copy()
		Else
			DeliverDataList = New DataTable()
		End If

		Return bModify
	End Function

	'--------------------------------------------------------------------------
	' CALC_PARAMのデータと最新データを比較し変更が存在した場合に送信用データを生成
	'--------------------------------------------------------------------------
	Public Function CreateDeliverCalcParam(ByVal NewDataList As DataTable, ByRef DeliverDataList As DataTable) As Boolean
		Dim ListRow As DataRow
		Dim InitRow As DataRow
		Dim bModify As Boolean
		Dim iOrgCount As Integer
		Dim iNewCount As Integer
		Dim iIndex As Integer

		iOrgCount = dtDelivery.Rows.Count()
		iNewCount = NewDataList.Rows.Count()
		If iOrgCount <> iNewCount Then
			bModify = True
		Else
			bModify = False
			For iIndex = 0 To iNewCount - 1
				InitRow = dtDelivery.Rows(iIndex)
				ListRow = NewDataList.Rows(iIndex)
                If InitRow.Item("ComCode").Equals(ListRow.Item("ComCode")) = False _
                OrElse InitRow.Item("InterestRate").Equals(ListRow.Item("InterestRate")) = False _
                OrElse InitRow.Item("SwapRate").Equals(ListRow.Item("SwapRate")) = False _
                OrElse InitRow.Item("VolatilityAdjust").Equals(ListRow.Item("VolatilityAdjust")) = False _
                OrElse InitRow.Item("Volatility").Equals(ListRow.Item("Volatility")) = False _
                OrElse InitRow.Item("DeltaVariation").Equals(ListRow.Item("DeltaVariation")) = False _
                OrElse InitRow.Item("GammaVariation").Equals(ListRow.Item("GammaVariation")) = False _
                OrElse InitRow.Item("VegaVariation").Equals(ListRow.Item("VegaVariation")) = False _
                OrElse InitRow.Item("ThetaVariation").Equals(ListRow.Item("ThetaVariation")) = False _
                OrElse InitRow.Item("RhoVariation").Equals(ListRow.Item("RhoVariation")) = False Then
                    bModify = True
                    Exit For
                End If
            Next
		End If

		If bModify = True Then
			DeliverDataList = NewDataList.Copy()
			dtDelivery = NewDataList.Copy()
		Else
			DeliverDataList = New DataTable()
		End If

		Return bModify
	End Function

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Function Copy() As DataTable
		Return dtDelivery.Copy()
	End Function

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public Property ModifiedFlag As Boolean
		Get
			Return blnModifiedFlag
		End Get
		Set(ByVal bModifiedFlag As Boolean)
			blnModifiedFlag = bModifiedFlag
		End Set
	End Property

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public ReadOnly Property DeliveryData As DataTable
		Get
			Return dtDelivery
		End Get
	End Property

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Public ReadOnly Property DataType As String
		Get
			Return strType
		End Get
	End Property

End Class
