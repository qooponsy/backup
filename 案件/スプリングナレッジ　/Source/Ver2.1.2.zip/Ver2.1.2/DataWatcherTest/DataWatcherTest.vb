﻿Imports System
Imports System.Threading
Imports DataWatcher

'------------------------------------------------------------------------------
'
'------------------------------------------------------------------------------
Public Class DataWatcherTest
    Private svDelivery As clsWorkerDataWatcher
    Private thDelivery As Thread

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Private Sub DataWatcherAP_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        svDelivery = Nothing
        dtpTestTime.Value = DateTime.Now

        lblProcess.Text = ""
        btnStartService.Enabled = True
        btnStopService.Enabled = False
        timWatch.Interval = 300
        timWatch.Start()
    End Sub

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Private Sub DataWatcherAP_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs)
        StopService()
    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド実行
    '--------------------------------------------------------------------------
    Private Sub btnStartService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartService.Click
        StartService()
    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド停止
    '--------------------------------------------------------------------------
    Private Sub btnStopService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStopService.Click
        StopService()
    End Sub

    '--------------------------------------------------------------------------
    ' Start
    '--------------------------------------------------------------------------
    Private Sub StartService()
        ' 制御メインスレッド作成、実行
        svDelivery = New clsWorkerDataWatcher()
        thDelivery = New Thread(AddressOf svDelivery.ServiceThread)
        svDelivery.InitializeServiceThread()
		thDelivery.Start()
		btnStartService.Enabled = False
		btnStopService.Enabled = True
	End Sub

	'--------------------------------------------------------------------------
	' Stop
	'--------------------------------------------------------------------------
	Private Sub StopService()
		If Not IsNothing(thDelivery) Then
			If thDelivery.IsAlive Then
				svDelivery.StopService()
				thDelivery.Join()
			End If
			thDelivery = Nothing
			svDelivery = Nothing
		End If
		btnStartService.Enabled = True
		btnStopService.Enabled = False
	End Sub

	'--------------------------------------------------------------------------
	'
	'--------------------------------------------------------------------------
	Private Sub timWatch_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles timWatch.Tick
		Dim sMastSlave As String
		If IsNothing(svDelivery) = False Then
			If svDelivery.IsMasterMode Then
				sMastSlave = "Master"
			Else
				sMastSlave = "Slave"
			End If
            lblProcess.Text = sMastSlave & ":" & svDelivery.GetMasterPriority().ToString() & ":" & svDelivery.GetProcessID()
		Else
			lblProcess.Text = ""
		End If
	End Sub

    Private Sub tbTest_Click(sender As System.Object, e As System.EventArgs) Handles tbTest.Click
        RunningContoroller.TestTime = dtpTestTime.Value.AddMinutes(-nudTimeZone.Value)
    End Sub
End Class
