SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[T_CustHist](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[SysDate] [date] NOT NULL,
	[CustCode] [varchar](32) NOT NULL,
	[CmpCode] [varchar](10) NOT NULL,
	[CurCode] [varchar](3) NOT NULL,
	[TotalMoney] [decimal](15, 4) NOT NULL,
 CONSTRAINT [PK_T_CustHist] PRIMARY KEY CLUSTERED 
(
	[SysDate] ASC,
	[CustCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
