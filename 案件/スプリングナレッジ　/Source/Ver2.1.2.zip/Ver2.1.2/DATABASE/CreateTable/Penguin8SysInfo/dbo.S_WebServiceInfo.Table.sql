SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[S_WebServiceInfo](
	[NowDate] [date] NOT NULL,
	[ServerName] [nvarchar](255) NOT NULL,
	[ProcessID] [int] NOT NULL,
	[InitTime] [datetime2](7) NOT NULL,
	[LastUpdateTime] [datetime2](7) NOT NULL,
	[AdminUserCount] [int] NOT NULL,
	[AdminUserCountMax] [int] NOT NULL,
	[CustUserCount] [int] NOT NULL,
	[CustUserCountMax] [int] NOT NULL,
 CONSTRAINT [PK_S_WebServiceInfo] PRIMARY KEY CLUSTERED 
(
	[NowDate] ASC,
	[ServerName] ASC,
	[ProcessID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_S_WebServiceInfoA] ON [dbo].[S_WebServiceInfo] 
(
	[LastUpdateTime] DESC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
