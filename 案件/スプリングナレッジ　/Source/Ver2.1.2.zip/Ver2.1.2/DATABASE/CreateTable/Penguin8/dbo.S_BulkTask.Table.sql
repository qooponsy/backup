SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[S_BulkTask](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[TaskSeq] [char](17) NOT NULL,
	[TaskStatus] [char](1) NOT NULL,
	[TaskType] [char](2) NOT NULL,
	[TaskParam] [nvarchar](1024) NOT NULL,
	[LastStep] [int] NOT NULL,
	[ExecStep] [int] NOT NULL,
	[ExecStartTime] [datetime2](7) NULL,
	[ExecEndTime] [datetime2](7) NULL,
	[TaskResult] [ntext] NULL,
 CONSTRAINT [PK_S_BulkTask] PRIMARY KEY CLUSTERED 
(
	[TaskSeq] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_S_BulkTaskA] ON [dbo].[S_BulkTask] 
(
	[TaskStatus] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
