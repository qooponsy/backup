SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[S_SysText](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[MsgCode] [char](8) NOT NULL,
	[CmpCode] [varchar](10) NOT NULL,
	[LangCode] [varchar](2) NOT NULL,
	[Message] [ntext] NOT NULL,
 CONSTRAINT [PK_S_SysText] PRIMARY KEY CLUSTERED 
(
	[MsgCode] ASC,
	[CmpCode] ASC,
	[LangCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
