SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[M_SysStatics](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[SysCode] [char](1) NOT NULL,
	[SysDateStartTime] [time](7) NOT NULL,
	[CurCode] [varchar](3) NOT NULL,
 CONSTRAINT [PK_M_SysStatics] PRIMARY KEY CLUSTERED 
(
	[SysCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
