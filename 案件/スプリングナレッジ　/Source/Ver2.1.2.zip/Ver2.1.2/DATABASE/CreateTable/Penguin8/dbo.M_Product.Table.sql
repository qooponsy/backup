SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[M_Product](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[ProductCode] [char](17) NOT NULL,
	[Enabled] [char](1) NOT NULL,
	[ProductBaseCode] [char](17) NULL,
	[SysDate] [date] NULL,
	[ComCode] [varchar](10) NOT NULL,
	[OpType] [char](2) NOT NULL,
	[StartTime] [datetime2](7) NOT NULL,
	[ExercTime] [datetime2](7) NOT NULL,
	[TradeLimitTime] [datetime2](7) NOT NULL,
	[PayoutRate] [decimal](15, 8) NOT NULL,
	[Spread] [int] NOT NULL,
	[StopTradeTime] [int] NULL,
	[StartAbandTime] [int] NULL,
	[AbandPriceDiff] [int] NULL,
	[AbandMargine] [decimal](15, 8) NULL,
	[VolatilityAdjust] [decimal](15, 14) NULL,
	[Volatility] [decimal](15, 14) NULL,
	[ExercStatus] [char](1) NOT NULL,
	[ExercRateSeq] [char](17) NULL,
	[ExercRate] [decimal](15, 8) NULL,
 CONSTRAINT [PK_T_Product] PRIMARY KEY CLUSTERED 
(
	[ProductCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_M_ProductA] ON [dbo].[M_Product] 
(
	[ExercTime] ASC,
	[ExercStatus] ASC,
	[Enabled] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[M_Product] ADD  CONSTRAINT [DF_M_Product_Spread]  DEFAULT ((0)) FOR [Spread]
GO
