SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[M_SysSettings](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[SysCode] [char](1) NOT NULL,
	[Commission] [decimal](15, 8) NOT NULL,
	[TradeMoneyMin] [decimal](15, 4) NOT NULL,
	[TradeMoneyMax] [decimal](15, 4) NOT NULL,
	[ProductMoneyMax] [decimal](15, 4) NOT NULL,
	[CustCountMax] [int] NOT NULL,
	[CustMoneyMax] [decimal](15, 4) NOT NULL,
	[CustMoneyDayMax] [decimal](15, 4) NOT NULL,
	[CustProductMoneyMax] [decimal](15, 4) NOT NULL,
	[CashInMoneyMin] [decimal](15, 4) NOT NULL,
	[CashInMoneyDayMin] [decimal](15, 4) NOT NULL,
	[CashOutMoneyMax] [decimal](15, 4) NOT NULL,
	[CashOutMoneyDayMax] [decimal](15, 4) NOT NULL,
	[ProductStartPreTime] [int] NOT NULL,
	[ProductEndLossTime] [int] NOT NULL,
	[RateEnableTime] [int] NOT NULL,
	[TimeZone] [int] NOT NULL,
	[SysDateTimeZone] [int] NOT NULL,
 CONSTRAINT [PK_M_SysSettings] PRIMARY KEY CLUSTERED 
(
	[SysCode] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
