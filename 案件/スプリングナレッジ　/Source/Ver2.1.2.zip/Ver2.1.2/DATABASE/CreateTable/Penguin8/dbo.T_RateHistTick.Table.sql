SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[T_RateHistTick](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[RateSeq] [char](17) NOT NULL,
	[Enabled] [char](1) NOT NULL,
	[ComCode] [varchar](10) NOT NULL,
	[RateTime] [datetime2](7) NOT NULL,
	[RateTimeSource] [datetime2](7) NOT NULL,
	[Rate] [decimal](15, 8) NOT NULL,
	[Exerc] [char](1) NOT NULL,
	[ExercTime] [datetime2](7) NULL,
	[ViewSeq] [varchar](25) NULL,
	[RateProviderID] [int] NOT NULL,
	[RateProviderSeq] [varchar](32) NOT NULL,
 CONSTRAINT [PK_T_RateHistTick_1] PRIMARY KEY CLUSTERED 
(
	[RateSeq] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_T_RateHistTickA] ON [dbo].[T_RateHistTick] 
(
	[ComCode] ASC,
	[RateTime] DESC,
	[RateSeq] DESC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_T_RateHistTickB] ON [dbo].[T_RateHistTick] 
(
	[RateTime] DESC,
	[RateSeq] DESC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
