SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[T_Trade](
	[InsTime] [datetime2](7) NOT NULL,
	[InsUser] [varchar](34) NOT NULL,
	[UpdTime] [datetime2](7) NOT NULL,
	[UpdUser] [varchar](34) NOT NULL,
	[TradeSeq] [char](17) NOT NULL,
	[TradeSubSeq] [int] NOT NULL,
	[SysDate] [date] NOT NULL,
	[ProductCode] [char](17) NOT NULL,
	[ComCode] [varchar](10) NOT NULL,
	[OpType] [char](2) NOT NULL,
	[PayoutRate] [decimal](15, 8) NOT NULL,
	[CurCode] [varchar](3) NOT NULL,
	[TradeType] [char](2) NOT NULL,
	[Premium] [decimal](15, 4) NOT NULL,
	[Commission] [decimal](15, 4) NOT NULL,
	[CustCode] [varchar](32) NOT NULL,
	[CmpCode] [varchar](10) NOT NULL,
	[TradeStatus] [char](2) NOT NULL,
	[OrderReqTime] [datetime2](7) NOT NULL,
	[OrderClientRateSeq] [char](17) NOT NULL,
	[OrderClientRateTime] [datetime2](7) NOT NULL,
	[OrderClientRate] [decimal](15, 8) NOT NULL,
	[AbandReqTime] [datetime2](7) NULL,
	[AbandClientRateSeq] [char](17) NULL,
	[AbandClientRateTime] [datetime2](7) NULL,
	[AbandClientRate] [decimal](15, 8) NULL,
	[TradeTime] [datetime2](7) NULL,
	[TradeRateSeq] [char](17) NULL,
	[TradeRateTime] [datetime2](7) NULL,
	[TradeRate] [decimal](15, 8) NULL,
	[ExercPrice] [decimal](15, 8) NULL,
	[ExercTime] [datetime2](7) NULL,
	[ExercProcTime] [datetime2](7) NULL,
	[ExercRateSeq] [char](17) NULL,
	[ExercRateTime] [datetime2](7) NULL,
	[ExercRate] [decimal](15, 8) NULL,
	[ExercPayoutRate] [decimal](15, 8) NULL,
	[Payout] [decimal](15, 4) NULL,
	[PAndL] [decimal](15, 4) NULL,
	[Memo] [nvarchar](max) NOT NULL,
	[InfoTitle] [nvarchar](16) NULL,
	[Info] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_T_Trade] PRIMARY KEY CLUSTERED 
(
	[TradeSeq] ASC,
	[TradeSubSeq] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE NONCLUSTERED INDEX [IX_T_TradeA] ON [dbo].[T_Trade] 
(
	[SysDate] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_T_TradeB] ON [dbo].[T_Trade] 
(
	[ProductCode] ASC,
	[TradeStatus] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_T_TradeC] ON [dbo].[T_Trade] 
(
	[CustCode] ASC,
	[TradeStatus] ASC,
	[ProductCode] ASC,
	[Premium] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_T_TradeD] ON [dbo].[T_Trade] 
(
	[TradeStatus] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_T_TradeE] ON [dbo].[T_Trade] 
(
	[SysDate] ASC,
	[CustCode] ASC,
	[TradeStatus] ASC,
	[Premium] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
