﻿Imports System.IO
Imports System.Text
Imports System.Data.SqlClient

Public Class clsPenguinDB
	Private ConnDB As SqlConnection
	Private strError As String
	Private blnError As Boolean

    Private Const SQL_SELECT_ALL_M_CURRENCYPAIR As String = "select [ComCode] from M_CurrencyPair with (nolock) "

    Private Const SQL_SELECT_ALL_M_CHARTTYPE As String = "select [ChartType] from M_ChartType with (nolock) "

    Private Const SQL_SELECT_TIMEZONE As String = "select [TimeZone] from [M_SysSettings] where [SysCode]='0'"

    Private ReadOnly SQL_SELECT_RATEHIST As String = "declare @StartTime datetime2" & vbCrLf &
                                                     "select @StartTime=DATEADD(hour, -2, SYSUTCDATETIME());" & vbCrLf &
                                                     "select @StartTime=DATEADD(second, -DATEPART(second, @StartTime), @StartTime);" & vbCrLf &
                                                     "select @StartTime=DATEADD(millisecond, -DATEPART(millisecond, @StartTime), @StartTime);" & vbCrLf &
                                                     "select @StartTime=DATEADD(microsecond, -DATEPART(microsecond, @StartTime), @StartTime);" & vbCrLf &
                                                     "select @StartTime=DATEADD(nanosecond, -DATEPART(nanosecond, @StartTime), @StartTime);" & vbCrLf &
                                                     "select top 1000 [ComCode], [RateSeq], [RateTime], [Rate] " &
                                                     "from T_RateHist with (nolock) " &
                                                     "where " &
                                                     "[Enabled]='1' and " &
                                                     "[RateTime]>=@StartTime and " &
                                                     "[RateSeq]>@SertchRateSeq " &
                                                     "order by [RateSeq] asc"

    Private Const SQL_SELECT_LAST_T_RATECHARTHIST As String = "select top 1 [ComCode], [RateChartSeq], [RateSeq], [RateChartTime], [ChartType], [OpenRate], " &
                                                              "[HighRate], [LowRate], [CloseRate], [CloseTime] " &
                                                              "from T_RateChartHist with (nolock) " &
                                                              "where " &
                                                              "[Enabled]='1' and " &
                                                              "[ComCode]=@ComCode and " &
                                                              "[ChartType]=@ChartType " &
                                                              "order by " &
                                                              "[RateChartTime] desc"

    Private Const SQL_INSERT_T_RATECHARTHIST As String = "insert into [T_RateChartHist] " &
                                                         "values (" &
                                                         "SYSUTCDATETIME(), @InsUser, SYSUTCDATETIME(), @InsUser, @RateChartSeq, '1', " &
                                                         "@ComCode, @ChartType, @RateSeq, @RateChartTime, " &
                                                         "@OpenRate, @HighRate, @LowRate, @CloseRate, @CloseTime" &
                                                         ")"

    Private Const SQL_UPDATE_T_RATECHARTHIST As String = "update [T_RateChartHist] " &
                                                         "set " &
                                                         "[UpdTime]=SYSUTCDATETIME(), " &
                                                         "[UpdUser]=@InsUser, " &
                                                         "[RateSeq]=@RateSeq, " &
                                                         "[OpenRate]=@OpenRate, " &
                                                         "[HighRate]=@HighRate, " &
                                                         "[LowRate]=@LowRate, " &
                                                         "[CloseRate]=@CloseRate, " &
                                                         "[CloseTime]=@CloseTime " &
                                                         "where " &
                                                         "[RateChartSeq]=@RateChartSeq"

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Class SeqCounterCode
        Public Const Rate As String = "01"
        Public Const Chart As String = "02"
        Public Const ProductBase As String = "03"
        Public Const Product As String = "04"
        Public Const Trade As String = "05"
        Public Const Cash As String = "06"
        Public Const Task As String = "07"
        Public Const RateChart As String = "09"
        Public Const ProductSub As String = "11"
        Public Const PriceChart As String = "12"
    End Class

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetSqlConnection(ByVal sConnectString As String) As Boolean
        Dim Result As Boolean

        strError = ""
        blnError = False
        Result = True
        Try
            ConnDB = New SqlConnection(sConnectString)
            ConnDB.Open()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)

            strError = "GetSqlConnection," & ex.Message
            ConnDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsError() As Boolean
        Return blnError
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetErrorMessage() As String
        Dim sErrMsg As String

        blnError = False
        sErrMsg = "DataBase Error:" & strError
        Return sErrMsg

    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function EndSqlConnection() As Boolean
        Dim Result As Boolean

        Result = True
        Try
            ConnDB.Close()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "EndSqlConnection," & ex.Message
            Result = False
        End Try
        ConnDB = Nothing
        blnError = False

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 通貨ペア取得処理(起動時初回)
    '--------------------------------------------------------------------------
    Public Function GetComCode(ByRef ComCode As List(Of String), ByRef MaxComCodeCount As Integer) As Boolean
        Dim ret As Boolean = True

        MaxComCodeCount = 0
        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_ALL_M_CURRENCYPAIR, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read
                        ComCode.Add(Reader("ComCode").ToString())
                        MaxComCodeCount += 1
                    End While
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetComCode," & ex.Message
            blnError = True
            ret = False
        End Try
        If MaxComCodeCount = 0 Then
            ret = False
        End If

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' チャート種別取得処理(起動時初回)
    '--------------------------------------------------------------------------
    Public Function GetChartType(ByRef ChartTypeList As List(Of Integer), ByRef MaxCharTypeCount As Integer) As Boolean
        Dim ret As Boolean = True

        MaxCharTypeCount = 0
        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_ALL_M_CHARTTYPE, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read
                        ChartTypeList.Add(Reader("ChartType"))
                        MaxCharTypeCount += 1
                    End While
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetChartType," & ex.Message
            blnError = True
            ret = False
        End Try
        If MaxCharTypeCount = 0 Then
            ret = False
        End If

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' タイムゾーン取得処理(起動時初回)
    '--------------------------------------------------------------------------
    Public Function GetTimeZone(ByRef TimeZone As Integer) As Boolean
        Dim ret As Boolean = True

        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_TIMEZONE, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    If Reader.Read Then
                        TimeZone = Reader("TimeZone")
                    End If
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetTimeZone," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 通貨コード差分チェック
    '--------------------------------------------------------------------------
    Public Function ComCodeCheck(ByRef ComCode As List(Of String), ByRef MaxComCodeCount As Integer, ByRef RateChartData As List(Of clsRateChartData), ByVal ChartType As Integer) As Boolean
        Dim ret As Boolean = True
        Dim hComCode As New List(Of String)
        Dim hMaxComCodeCount = 0
        Dim i As Integer
        Dim j As Integer

        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_ALL_M_CURRENCYPAIR, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read
                        hComCode.Add(Reader("ComCode").ToString())
                        hMaxComCodeCount += 1
                    End While
                End Using
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetComCode," & ex.Message
            blnError = True
            ret = False
            hComCode.Clear()
            hComCode = Nothing
            Return ret
        End Try

        For i = MaxComCodeCount - 1 To 0 Step -1
            For j = 0 To hMaxComCodeCount - 1
                If ComCode(i) = hComCode(j) Then
                    Exit For
                End If
            Next
            If j >= hMaxComCodeCount Then
                ComCode.RemoveAt(i)
                RateChartData.RemoveAt(i)
                MaxComCodeCount -= 1
            End If
        Next

        For i = 0 To hMaxComCodeCount - 1
            For j = 0 To MaxComCodeCount - 1
                If hComCode(i) = ComCode(j) Then
                    Exit For
                End If
            Next
            If j >= MaxComCodeCount Then
                ComCode.Add(hComCode(i))
                Dim wRateChartData As New clsRateChartData
                wRateChartData.UpdFlg = DBUpdateFlg.NoUpdate
                wRateChartData.RateChartSeq = "00000000000000000"
                wRateChartData.ComCode = hComCode(i)
                wRateChartData.ChartType = ChartType
                wRateChartData.RateSeq = "00000000000000000"
                wRateChartData.RateChartTime = DateTime.MinValue
                wRateChartData.OpenRate = 0
                wRateChartData.HighRate = 0
                wRateChartData.LowRate = 0
                wRateChartData.CloseRate = 0
                wRateChartData.CloseTime = DateTime.MinValue
                RateChartData.Add(wRateChartData)
            End If
        Next
        MaxComCodeCount = ComCode.Count

        hComCode.Clear()
        hComCode = Nothing

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 最終レートチャートデータ取得処理(起動時初回処理)(1本足限定)
    '--------------------------------------------------------------------------
    Public Function GetLastRateChartData(ByVal ComCode As List(Of String), ByVal MaxComCodeCount As Integer, ByRef SertchRateSeq As String, ByRef RateChartData As List(Of clsRateChartData), ByVal ChartType As Integer) As Boolean
        Dim ret As Integer = True

        If MaxComCodeCount = 0 Then
            blnError = True
            ret = False
            Return ret
        End If

        SertchRateSeq = "99999999999999999"
        Try
            For i As Integer = 0 To MaxComCodeCount - 1
                Using CmdDB As New SqlCommand(SQL_SELECT_LAST_T_RATECHARTHIST, ConnDB)
                    CmdDB.CommandTimeout = My.Settings.CommandTimeout
                    CmdDB.CommandType = CommandType.Text
                    CmdDB.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ComCode(i)
                    CmdDB.Parameters.Add("@ChartType", SqlDbType.Int, 10).Value = ChartType
                    CmdDB.Prepare()
                    Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                        RateChartData.Add(New clsRateChartData)
                        RateChartData(i).UpdFlg = DBUpdateFlg.NoUpdate
                        If Reader.Read Then
                            RateChartData(i).RateChartSeq = Reader("RateChartSeq")
                            RateChartData(i).ComCode = Reader("ComCode")
                            RateChartData(i).ChartType = Reader("ChartType")
                            RateChartData(i).RateSeq = Reader("RateSeq")
                            RateChartData(i).RateChartTime = Reader("RateChartTime")
                            RateChartData(i).OpenRate = Reader("OpenRate")
                            RateChartData(i).HighRate = Reader("HighRate")
                            RateChartData(i).LowRate = Reader("LowRate")
                            RateChartData(i).CloseRate = Reader("CloseRate")
                            RateChartData(i).CloseTime = Reader("CloseTime")
                            If SertchRateSeq.CompareTo(RateChartData(i).RateSeq) > 0 Then
                                SertchRateSeq = RateChartData(i).RateSeq
                            End If
                        Else
                            RateChartData(i).ComCode = ComCode(i)
                            RateChartData(i).ChartType = ChartType
                            RateChartData(i).RateSeq = "00000000000000000"
                            RateChartData(i).RateChartTime = DateTime.MinValue
                            RateChartData(i).OpenRate = 0
                            RateChartData(i).HighRate = 0
                            RateChartData(i).LowRate = 0
                            RateChartData(i).CloseRate = 0
                            RateChartData(i).CloseTime = DateTime.MinValue
                            SertchRateSeq = RateChartData(i).RateSeq
                        End If
                    End Using
                End Using
            Next
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetLastRateChartData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 最終レートチャートデータ取得処理(起動時初回処理)（チャート種別対応）
    '--------------------------------------------------------------------------
    Public Function GetLastRateChartData(ByVal ComCode As List(Of String), ByVal MaxComCodeCount As Integer,
                                         ByVal ChartType As List(Of Integer), ByVal MaxChartTypeCount As Integer,
                                         ByRef SertchRateSeq As String, ByRef RateChartDataList As Dictionary(Of String, clsRateChartData)) As Boolean
        Dim ret As Integer = True

        If MaxComCodeCount = 0 Then
            blnError = True
            ret = False
            Return ret
        End If

        SertchRateSeq = "99999999999999999"
        Try
            For i As Integer = 0 To MaxComCodeCount - 1
                For j As Integer = 0 To MaxChartTypeCount - 1
                    Using CmdDB As New SqlCommand(SQL_SELECT_LAST_T_RATECHARTHIST, ConnDB)
                        CmdDB.CommandTimeout = My.Settings.CommandTimeout
                        CmdDB.CommandType = CommandType.Text
                        CmdDB.Parameters.Add("@ComCode", SqlDbType.VarChar, 10).Value = ComCode(i)
                        CmdDB.Parameters.Add("@ChartType", SqlDbType.Int, 10).Value = ChartType(j)
                        CmdDB.Prepare()
                        Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                            Dim RateChartData As New clsRateChartData
                            RateChartData.UpdFlg = DBUpdateFlg.NoUpdate
                            If Reader.Read Then
                                RateChartData.RateChartSeq = Reader("RateChartSeq")
                                RateChartData.ComCode = Reader("ComCode")
                                RateChartData.ChartType = Reader("ChartType")
                                RateChartData.RateSeq = Reader("RateSeq")
                                RateChartData.RateChartTime = Reader("RateChartTime")
                                RateChartData.OpenRate = Reader("OpenRate")
                                RateChartData.HighRate = Reader("HighRate")
                                RateChartData.LowRate = Reader("LowRate")
                                RateChartData.CloseRate = Reader("CloseRate")
                                RateChartData.CloseTime = Reader("CloseTime")
                                If SertchRateSeq.CompareTo(RateChartData.RateSeq) > 0 Then
                                    SertchRateSeq = RateChartData.RateSeq
                                End If
                            Else
                                RateChartData.ComCode = ComCode(i)
                                RateChartData.ChartType = ChartType(j)
                                RateChartData.RateSeq = "00000000000000000"
                                RateChartData.RateChartTime = DateTime.MinValue
                                RateChartData.OpenRate = 0
                                RateChartData.HighRate = 0
                                RateChartData.LowRate = 0
                                RateChartData.CloseRate = 0
                                RateChartData.CloseTime = DateTime.MinValue
                                SertchRateSeq = RateChartData.RateSeq
                            End If

                            Dim key As String = ComCode(i) & ":" & ChartType(j)
                            RateChartDataList.Add(key, RateChartData)

                        End Using
                    End Using
                Next
            Next
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetLastRateChartData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' レートチャートデータUpdate用パラメータ追加
    '--------------------------------------------------------------------------
    Private Sub UpdateParamAdd(ByRef CmdUpdDB As SqlCommand)
        CmdUpdDB.Parameters.Add("@InsUser", SqlDbType.VarChar, 34)
        CmdUpdDB.Parameters.Add("@RateChartSeq", SqlDbType.Char, 17)
        CmdUpdDB.Parameters.Add("@ComCode", SqlDbType.VarChar, 10)
        CmdUpdDB.Parameters.Add("@ChartType", SqlDbType.Int)
        CmdUpdDB.Parameters.Add("@RateSeq", SqlDbType.Char, 17)
        CmdUpdDB.Parameters.Add("@RateChartTime", SqlDbType.DateTime2)
        CmdUpdDB.Parameters.Add("@OpenRate", SqlDbType.Decimal)
        CmdUpdDB.Parameters.Add("@HighRate", SqlDbType.Decimal)
        CmdUpdDB.Parameters.Add("@LowRate", SqlDbType.Decimal)
        CmdUpdDB.Parameters.Add("@CloseRate", SqlDbType.Decimal)
        CmdUpdDB.Parameters.Add("@CloseTime", SqlDbType.DateTime2)
    End Sub

    '--------------------------------------------------------------------------
    ' レートチャートSeq取得
    '--------------------------------------------------------------------------
    Public Function GetSeqCounterSysDate(ByVal CounterCode As String) As String
        Dim NewCounter As String
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        strSQL = "declare @Counter int" & vbCrLf
        strSQL = strSQL & "begin tran" & vbCrLf
        strSQL = strSQL & "select @Counter = [Counter] from [S_Counter] with (updlock) where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "update [S_Counter] set [Counter] = @Counter + 1 where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "select convert(char(8), [SysDate], 112) + replicate('0' ,9 - len(@Counter)) + convert(varchar(9),@Counter) from [S_SysStatus] where [SysCode] = '0'" & vbCrLf
        strSQL = strSQL & "commit tran"

        NewCounter = ""
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@CounterCode", SqlDbType.Char, 2).Value = CounterCode
            NewCounter = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSeqCounterSysDate," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return NewCounter
    End Function

    '--------------------------------------------------------------------------
    ' レートチャートデータDBテーブル更新処理
    '--------------------------------------------------------------------------
    Public Function RegistRateChartData(ByVal RateChartList As List(Of clsRateChartData), ByVal sProcessID As String) As Boolean
        Dim ret As Boolean = True
        Dim newSeq As String

        Try
            Using CmdUpdDB As SqlCommand = New SqlCommand
                CmdUpdDB.Connection = ConnDB
                CmdUpdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdUpdDB.CommandType = CommandType.Text

                UpdateParamAdd(CmdUpdDB)

                For Each RateChartData As clsRateChartData In RateChartList
                    Select Case RateChartData.UpdFlg
                        Case DBUpdateFlg.Update
                            CmdUpdDB.CommandText = SQL_UPDATE_T_RATECHARTHIST
                            CmdUpdDB.Parameters("@RateChartSeq").Value = RateChartData.RateChartSeq
                        Case DBUpdateFlg.Insert
                            CmdUpdDB.CommandText = SQL_INSERT_T_RATECHARTHIST
                            newSeq = GetSeqCounterSysDate(clsPenguinDB.SeqCounterCode.RateChart)
                            If IsError() Then
                                ret = False
                                Exit For
                            End If
                            CmdUpdDB.Parameters("@RateChartSeq").Value = newSeq
                            RateChartData.RateChartSeq = newSeq
                        Case Else
                            SystemLog.Warning("レートチャートデータ更新フラグ異常。論理エラー ")
                            Continue For
                    End Select

                    CmdUpdDB.Parameters("@InsUser").Value = "P:" + sProcessID
                    CmdUpdDB.Parameters("@ComCode").Value = RateChartData.ComCode
                    CmdUpdDB.Parameters("@ChartType").Value = RateChartData.ChartType
                    CmdUpdDB.Parameters("@RateSeq").Value = RateChartData.RateSeq
                    CmdUpdDB.Parameters("@RateChartTime").Value = RateChartData.RateChartTime
                    CmdUpdDB.Parameters("@OpenRate").Value = RateChartData.OpenRate
                    CmdUpdDB.Parameters("@HighRate").Value = RateChartData.HighRate
                    CmdUpdDB.Parameters("@LowRate").Value = RateChartData.LowRate
                    CmdUpdDB.Parameters("@CloseRate").Value = RateChartData.CloseRate
                    CmdUpdDB.Parameters("@CloseTime").Value = RateChartData.CloseTime

                    CmdUpdDB.ExecuteNonQuery()
                Next
            End Using
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "RegistRateChartData," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' レートチャートリスト作成（1分足限定）
    '--------------------------------------------------------------------------
    Public Function CreateRegistRateChartList(ByVal ComCode As List(Of String), ByVal MaxComCodeCount As Integer, ByRef SertchRateSeq As String, ByRef RateChartData As List(Of clsRateChartData), ByVal ChartType As Integer, ByRef RateChartList As List(Of clsRateChartData)) As Boolean
        Dim ret As Boolean = True
        Dim RateChartTime As DateTime
        Dim i As Integer

        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_RATEHIST, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                CmdDB.Parameters.Add("@SertchRateSeq", SqlDbType.VarChar, 17).Value = SertchRateSeq
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read
                        i = ComCode.IndexOf(Reader("ComCode").ToString())
                        SertchRateSeq = Reader("RateSeq")
                        If i <> -1 Then
                            If RateChartData(i).RateSeq.CompareTo(SertchRateSeq) >= 0 Then
                                Continue While
                            End If
                            RateChartTime = ConvChartTime(Reader("RateTime"))
                            If RateChartData(i).RateChartTime < RateChartTime Then 'チャート日付が新しい場合DB更新データ追加
                                If RateChartData(i).UpdFlg <> DBUpdateFlg.NoUpdate Then
                                    RateChartList.Add(RateChartData(i))
                                End If

                                RateChartData(i) = New clsRateChartData

                                RateChartData(i).UpdFlg = DBUpdateFlg.Insert
                                RateChartData(i).ComCode = ComCode(i)
                                RateChartData(i).ChartType = ChartType
                                RateChartData(i).RateChartTime = RateChartTime
                                RateChartData(i).OpenRate = Reader("Rate")
                                RateChartData(i).HighRate = Reader("Rate")
                                RateChartData(i).LowRate = Reader("Rate")
                            ElseIf RateChartData(i).RateChartTime = RateChartTime Then 'チャート日付が同じ場合データ更新
                                If RateChartData(i).UpdFlg = DBUpdateFlg.NoUpdate Then
                                    RateChartData(i).UpdFlg = DBUpdateFlg.Update
                                End If
                                If RateChartData(i).HighRate < Reader("Rate") Then
                                    RateChartData(i).HighRate = Reader("Rate")
                                End If
                                If RateChartData(i).LowRate > Reader("Rate") Then
                                    RateChartData(i).LowRate = Reader("Rate")
                                End If
                            Else 'チャート日付が過去の場合
                                Continue While
                            End If
                            RateChartData(i).CloseRate = Reader("Rate")
                            RateChartData(i).RateSeq = Reader("RateSeq")
                            RateChartData(i).CloseTime = Reader("RateTime")
                        Else
                            SystemLog.Warning("通貨ペアの不整合が発生しました。RateSeq[" & SertchRateSeq & "]")
                        End If
                    End While
                End Using
            End Using

            For i = 0 To MaxComCodeCount - 1
                If RateChartData(i).UpdFlg <> DBUpdateFlg.NoUpdate Then
                    RateChartList.Add(RateChartData(i))
                End If
            Next
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "CreateRateChartList," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' レートチャートリスト作成（チャートタイプ対応）
    '--------------------------------------------------------------------------
    Public Function CreateRegistRateChartList(ByVal ComCode As List(Of String), ByVal MaxComCodeCount As Integer,
                                              ByVal ChartType As List(Of Integer), ByVal MaxChartTypeCount As Integer,
                                              ByRef SertchRateSeq As String, ByRef RateChartData As Dictionary(Of String, clsRateChartData),
                                              ByVal TimeZone As Integer, ByRef RateChartList As List(Of clsRateChartData)) As Boolean
        Dim ret As Boolean = True
        Dim RateChartTime As DateTime

        Try
            Using CmdDB As New SqlCommand(SQL_SELECT_RATEHIST, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                CmdDB.Parameters.Add("@SertchRateSeq", SqlDbType.VarChar, 17).Value = SertchRateSeq
                Using Reader As SqlDataReader = CmdDB.ExecuteReader()
                    While Reader.Read

                        For ChartTypeIndex As Integer = 0 To MaxChartTypeCount - 1

                            Dim key As String = Reader("ComCode") & ":" & ChartType(ChartTypeIndex)
                            SertchRateSeq = Reader("RateSeq")

                            If RateChartData.ContainsKey(key) Then
                                Dim RateChart As clsRateChartData = RateChartData(key)
                                If RateChartData(key).RateSeq.CompareTo(SertchRateSeq) >= 0 Then
                                    Continue For
                                End If

                                RateChartTime = ConvChartTypeTime(Reader("RateTime"), ChartType(ChartTypeIndex), TimeZone)

                                If RateChartData(key).RateChartTime < RateChartTime Then 'チャート日付が新しい場合DB更新データ追加
                                    If RateChartData(key).UpdFlg <> DBUpdateFlg.NoUpdate Then
                                        RateChartList.Add(RateChartData(key))
                                    End If

                                    RateChartData(key) = New clsRateChartData

                                    RateChartData(key).UpdFlg = DBUpdateFlg.Insert
                                    RateChartData(key).ComCode = Reader("ComCode")
                                    RateChartData(key).ChartType = ChartType(ChartTypeIndex)
                                    RateChartData(key).RateChartTime = RateChartTime
                                    RateChartData(key).OpenRate = Reader("Rate")
                                    RateChartData(key).HighRate = Reader("Rate")
                                    RateChartData(key).LowRate = Reader("Rate")
                                ElseIf RateChartData(key).RateChartTime = RateChartTime Then 'チャート日付が同じ場合データ更新
                                    If RateChartData(key).UpdFlg = DBUpdateFlg.NoUpdate Then
                                        RateChartData(key).UpdFlg = DBUpdateFlg.Update
                                    End If
                                    If RateChartData(key).HighRate < Reader("Rate") Then
                                        RateChartData(key).HighRate = Reader("Rate")
                                    End If
                                    If RateChartData(key).LowRate > Reader("Rate") Then
                                        RateChartData(key).LowRate = Reader("Rate")
                                    End If
                                Else 'チャート日付が過去の場合
                                    Continue While
                                End If
                                RateChartData(key).CloseRate = Reader("Rate")
                                RateChartData(key).RateSeq = Reader("RateSeq")
                                RateChartData(key).CloseTime = Reader("RateTime")
                            Else
                                SystemLog.Warning("通貨ペアの不整合が発生しました。RateSeq[" & SertchRateSeq & "]")
                            End If
                        Next

                    End While
                End Using
            End Using

            For i As Integer = 0 To MaxComCodeCount - 1
                For j As Integer = 0 To MaxChartTypeCount - 1
                    Dim key As String = ComCode(i) & ":" & ChartType(j)
                    If RateChartData(key).UpdFlg <> DBUpdateFlg.NoUpdate Then
                        RateChartList.Add(RateChartData(key))
                    End If
                Next
            Next
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "CreateRateChartList," & ex.Message
            blnError = True
            ret = False
        End Try

        Return ret
    End Function

    '--------------------------------------------------------------------------
    ' 日時をレートチャート日時に変換(分までの時刻)
    '--------------------------------------------------------------------------
    Public Function ConvChartTime(ByVal TimeData As DateTime) As DateTime
        Return DateTime.Parse(Format(TimeData, "yyyy/MM/dd HH:mm:00.000"))
        'Return TimeData.AddSeconds(-TimeData.Second).AddMilliseconds(-TimeData.Millisecond)
    End Function

    '--------------------------------------------------------------------------
    ' チャート種別に従って日時をレートチャート日時に変換(分までの時刻)
    '--------------------------------------------------------------------------
    Public Function ConvChartTypeTime(ByVal TimeData As DateTime, ByVal ChartType As Integer, ByVal TimeZone As Integer) As DateTime

        Dim tsChartTime As TimeSpan = TimeSpan.FromSeconds(ChartType)
        Dim tsTimeZone As TimeSpan = TimeSpan.FromMinutes(TimeZone)

        Dim times As String() = Split(My.Settings.GeneratStartTime, ":")
        Dim startTime As DateTime = New DateTime(Now.Year, Now.Month, Now.Day, Integer.Parse(times(0)), Integer.Parse(times(1)), Integer.Parse(times(2))).Add(-tsTimeZone)

        Dim ticksToday As Long = TimeData.Ticks - startTime.Ticks
        Dim ticksYesterdayUntil As Long = TimeData.Ticks - ticksToday

        Dim ChartTime As DateTime = CreateChartTime(ticksToday, ticksYesterdayUntil, tsChartTime)

        Return ChartTime
    End Function

    Private Function CreateChartTime(ByVal ticksToday As Long, ByVal ticksYesterdayUntil As Long, ByVal interval As TimeSpan) As DateTime

        Dim baseTicks As Long = ticksToday + interval.Ticks
        Dim chartMinute As Long = Math.Floor(baseTicks / interval.Ticks)
        chartMinute = chartMinute - 1 ' 一つ前のインターバルにいれるため-1
        Dim ChartTicks As Long = chartMinute * interval.Ticks

        Dim ChartTime As New DateTime(ChartTicks + ticksYesterdayUntil)

        Return ChartTime
    End Function


End Class
