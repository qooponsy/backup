﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics
'--------------------------------------------------------------------------
'
'--------------------------------------------------------------------------
Public Class clsService
    Private strServiceName As String
	Private blnServiceStopFlag As Boolean
	Private blnMasterMode As Boolean

    Private MasterHB() As Byte
	Private SlaveHB() As Byte
	Private HeartBeatUDP As UdpClient
	Private MasterWatch As Stopwatch

    'Private Const DefaultChartType As Integer = 1   'チャート種別 1分足

	'--------------------------------------------------------------------------
	' クラスコンストラクタ
	'--------------------------------------------------------------------------
	Public Sub New()
		blnServiceStopFlag = False
        strServiceName = "ChartGeneratorRate"
#If REL_DEMO Then
        strServiceName = "ChartGeneratorRateDemoUK"
#End If
#If REL_ST Then
        strServiceName = "ChartGeneratorRateUK"
#End If
#If REL_TEST Then
        strServiceName = "ChartGeneratorRateTest"
#End If
#If REL_DevMT4 Then
        strServiceName = "ChartGeneratorRateMT4"
#End If
#If REL_UK Then
        strServiceName = "ChartGeneratorRateUK"
#End If
        blnMasterMode = False
    End Sub

	'--------------------------------------------------------------------------
	' マスターモード稼動判定
	'--------------------------------------------------------------------------
	Public Function IsMasterMode() As Boolean
		Return blnMasterMode
	End Function

	'--------------------------------------------------------------------------
	' サービス制御スレッドの初期設定
	'--------------------------------------------------------------------------
    Public Function InitializeService() As Boolean
        Dim ret As Boolean = False

        ' ハートビート電文の編集
        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)

        ret = True

        Return ret
    End Function

	'--------------------------------------------------------------------------
	' サービス制御スレッド
	'--------------------------------------------------------------------------
	Public Sub ServiceThread()
        Dim HeartBeatWatch As Stopwatch

        Dim DataBase As clsPenguinDB = Nothing

        '最終レートチャートリスト
        Dim RateChartData As Dictionary(Of String, clsRateChartData) = Nothing

        '更新レートチャートリスト
        Dim RateChartUpDateList As List(Of clsRateChartData) = Nothing

        '通貨ペアコード
        Dim ComCode As List(Of String) = Nothing
        '通貨ペアコード数
        Dim MaxComCodeCount As Integer

        Dim TimeZone As Integer

        'チャート種別リスト
        Dim ChartType As List(Of Integer) = Nothing
        'チャート種別数
        Dim MaxChartTypeCount As Integer

        '開始レート通番
        Dim SertchRateSeq As String = ""
        Dim IniFlg As Boolean = True

        Logging("ServiceThread Start.", EventLogEntryType.Information)

        RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTimeWeekEnd)
        Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew

        Dim iHeartBeatCycle As Integer = My.Settings.HeartBeatCycle
        '-----------------------------------------------------------------
        ' 初期状態としてSlaveモードに設定
        '-----------------------------------------------------------------
        OnSlaveMode()

        '-----------------------------------------------------------------
        ' 生存確認のStopWatch開始
        '-----------------------------------------------------------------
        HeartBeatWatch = Stopwatch.StartNew

        '-----------------------------------------------------------------
        ' 停止フラグ=Trueになるまでサービス処理をLoop
        '-----------------------------------------------------------------
        While Not blnServiceStopFlag
            If HeartBeatWatch.ElapsedMilliseconds() >= iHeartBeatCycle Then
                CheckMasterAlive()
                HeartBeatWatch.Stop()
                HeartBeatWatch.Reset()
                HeartBeatWatch.Start()
            End If

            If RunningContoroller.check() Then
                Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime()), EventLogEntryType.Information)
            End If
            If RunningContoroller.Running Then
                If blnMasterMode Then
                    Try
                        DataBase = New clsPenguinDB

                        If Not DataBase.GetSqlConnection(My.Settings.DB) Then
                            IniFlg = True
                            Exit Try
                        End If

                        If IniFlg Then
                            '初期処理(初回・Master移行時・エラー発生時)
                            If Not IsNothing(ComCode) Then
                                ComCode.Clear()
                                ComCode = Nothing
                            End If
                            ComCode = New List(Of String)(6)

                            If Not IsNothing(ChartType) Then
                                ChartType.Clear()
                                ChartType = Nothing
                            End If
                            ChartType = New List(Of Integer)(8)

                            If Not IsNothing(RateChartData) Then
                                RateChartData.Clear()
                                RateChartData = Nothing
                            End If
                            RateChartData = New Dictionary(Of String, clsRateChartData)

                            If Not IsNothing(RateChartUpDateList) Then
                                RateChartUpDateList.Clear()
                                RateChartUpDateList = Nothing
                            End If
                            RateChartUpDateList = New List(Of clsRateChartData)(6 * 12)

                            If Not DataBase.GetComCode(ComCode, MaxComCodeCount) Then
                                Exit Try
                            End If

                            If Not DataBase.GetChartType(ChartType, MaxChartTypeCount) Then
                                Exit Try
                            End If

                            If Not DataBase.GetTimeZone(TimeZone) Then
                                Exit Try
                            End If

                            If Not DataBase.GetLastRateChartData(ComCode, MaxComCodeCount, ChartType, MaxChartTypeCount, SertchRateSeq, RateChartData) Then
                                Exit Try
                            End If
                        End If
                        IniFlg = True
                        If DataBase.CreateRegistRateChartList(ComCode, MaxComCodeCount, ChartType, MaxChartTypeCount, SertchRateSeq, RateChartData, TimeZone, RateChartUpDateList) Then
                            If DataBase.RegistRateChartData(RateChartUpDateList, My.Settings.ProcessID) Then
                                For i As Integer = 0 To MaxComCodeCount - 1
                                    For j As Integer = 0 To MaxChartTypeCount - 1
                                        Dim key As String = ComCode(i) & ":" & ChartType(j)
                                        RateChartData(key).UpdFlg = DBUpdateFlg.NoUpdate
                                    Next
                                Next
                                IniFlg = False
                            End If
                        End If

                    Catch ex As Exception
                        Logging("ServiceThread Exception:" & ex.Message, EventLogEntryType.Error)
                        IniFlg = True
                    Finally
                        If Not IsNothing(DataBase) Then
                            DataBase.EndSqlConnection()
                        End If
                        DataBase = Nothing
                        If Not IsNothing(RateChartUpDateList) Then
                            RateChartUpDateList.Clear()
                        End If
                    End Try
                Else
                    IniFlg = True
                End If
            Else
                IniFlg = True
            End If

            Thread.Sleep(My.Settings.ServiceInterval)
        End While
        If Not IsNothing(ComCode) Then
            ComCode.Clear()
            ComCode = Nothing
        End If
        If Not IsNothing(RateChartData) Then
            RateChartData.Clear()
            RateChartData = Nothing
        End If
        If Not IsNothing(RateChartUpDateList) Then
            RateChartUpDateList.Clear()
            RateChartUpDateList = Nothing
        End If

        MasterWatch.Stop()
        HeartBeatUDP.Close()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
	End Sub

	'--------------------------------------------------------------------------
	' サービス制御スレッド、及びワーカースレッドの停止要求
	'--------------------------------------------------------------------------
	Public Sub StopService()
        blnServiceStopFlag = True
    End Sub

	'--------------------------------------------------------------------------
	' Slave->Master移行イベント
	'--------------------------------------------------------------------------
	Public Sub OnMasterMode()
        blnMasterMode = True

		Logging("Master Mode Start.", EventLogEntryType.Information)
	End Sub

	'--------------------------------------------------------------------------
	' Master->Slave移行イベント
	'--------------------------------------------------------------------------
	Public Sub OnSlaveMode()
        blnMasterMode = False

		Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' ハートビート送受信による、生存確認とモードの切替(Master/Slave)
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        bMasterRecv = False
        bSlaveRecv = False
        iHeartBeatPriority = 9
        If HeartBeatUDP.Available() > 0 Then
            Dim sDataHB As String
            Dim DataHB() As Byte

            RemoteEP = Nothing
            Try
                DataHB = Nothing
                While HeartBeatUDP.Available() > 0
                    DataHB = HeartBeatUDP.Receive(RemoteEP)
                End While
                sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                Do
                    Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                    If NextIndex = -1 Then Exit Do
                    If sDataHB.Length - NextIndex < 3 Then Exit Do
                    sDataHB = sDataHB.Substring(NextIndex)
                Loop While True
                If My.Settings.HeartBeatLog Then SystemLog.Information(sDataHB)
                If sDataHB.Length >= 3 Then
                    sHeartBeatMode = sDataHB.Substring(1, 1)
                    iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                    If sHeartBeatMode.Equals("M") = True Then
                        bMasterRecv = True
                        MasterWatch.Reset()
                        MasterWatch.Start()
                    End If
                    If sHeartBeatMode.Equals("S") = True Then
                        bSlaveRecv = True
                    End If
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
            End Try
        End If

        If blnMasterMode = True Then
            If bMasterRecv = True Then
                ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                If iHeartBeatPriority < My.Settings.MasterPriority Then
                    OnSlaveMode()
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        Else
            If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                OnMasterMode()
                MasterWatch.Reset()
                MasterWatch.Start()
            ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                If SystemLog.GetDBErrorCount() > 0 Then
                    If My.Settings.HeartBeatLog Then SystemLog.Information("DB Error Now.")
                Else
                    OnMasterMode()
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        End If

        Try
            If blnMasterMode Then
                HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            Else
                HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            End If
        Catch ex As Exception
            If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
        End Try

        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' ログ出力
    '--------------------------------------------------------------------------
	Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
		Dim eLog As EventLog

		Try
			Debug.Print(sMessage)
			eLog = New EventLog()
			eLog.Source = strServiceName
			eLog.WriteEntry(sMessage, entryType)
			eLog = Nothing
		Catch ex As Exception
			Debug.Print(ex.Message)
		End Try
	End Sub
End Class
