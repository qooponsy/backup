﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'この呼び出しは、コンポーネント デザイナーで必要です。
        InitializeComponent()

        'InitializeComponent への呼び出し後、初期化コードを追加します

#If REL_DEMO Then
        Me.ServiceInstaller.Description = "ChartGeneratorRateDemoUK"
        Me.ServiceInstaller.ServiceName = "ChartGeneratorRateDemoUK"
#End If
#If REL_DevMT4 Then
        Me.ServiceInstaller.Description = "ChartGeneratorRateMT4"
        Me.ServiceInstaller.ServiceName = "ChartGeneratorRateMT4"
#End If
#If REL_UK Then
        Me.ServiceInstaller.Description = "ChartGeneratorRateUK"
        Me.ServiceInstaller.ServiceName = "ChartGeneratorRateUK"
#End If

    End Sub

End Class
