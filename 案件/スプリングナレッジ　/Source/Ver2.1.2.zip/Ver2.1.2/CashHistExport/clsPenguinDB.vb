﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Text

Public Class clsPenguinDB

    Private Const LINE_START As String = "," & """"
    Private Const LINE_END As String = """"

    Private ConnDB As SqlConnection
    Private strError As String
    Private blnError As Boolean

    'システムセッティングレコード取得SQL 
    Private SELECT_M_SYSSETTINGS As String = "select " &
                                             "[SysDateTimeZone], " &
                                             "SYSUTCDATETIME() As SysDate " &
                                             "from " &
                                             "[M_SysSettings] " &
                                             "where " &
                                             "[SysCode]='0'"

    '--------------------------------------------------------------------------
    ' ＤＢ接続
    '--------------------------------------------------------------------------
    Public Function GetSqlConnection(ByVal sConnectString As String) As Boolean
        Dim Result As Boolean

        strError = ""
        blnError = False
        Result = True
        Try
            ConnDB = New SqlConnection(sConnectString)
            ConnDB.Open()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)

            strError = "GetSqlConnection," & ex.Message
            ConnDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ切断
    '--------------------------------------------------------------------------
    Public Function EndSqlConnection() As Boolean
        Dim Result As Boolean

        Result = True
        Try
            ConnDB.Close()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "EndSqlConnection," & ex.Message
            Result = False
        End Try
        ConnDB = Nothing
        blnError = False

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' システム日付計算（DBサーバシステム時刻変換）
    '--------------------------------------------------------------------------
    Public Function CalcSysDate(ByVal SysDateTime As DateTime, ByVal SysTimeZone As Integer) As String
        Dim wDate As String
        Dim StartSysDateTime As DateTime = DateAdd(DateInterval.Minute, -SysTimeZone, SysDateTime.Date)
        Dim EndSysDateTime As DateTime = DateAdd(DateInterval.Day, 1, StartSysDateTime)

        If SysTimeZone = 0 Then
            wDate = Format(StartSysDateTime, "yyyy/MM/dd")
        ElseIf SysTimeZone > 0 Then
            If StartSysDateTime <= SysDateTime And EndSysDateTime > SysDateTime Then
                wDate = Format(EndSysDateTime, "yyyy/MM/dd")
            Else
                wDate = Format(DateAdd(DateInterval.Day, 1, EndSysDateTime), "yyyy/MM/dd")
            End If
        Else
            If StartSysDateTime <= SysDateTime And EndSysDateTime > SysDateTime Then
                wDate = Format(StartSysDateTime, "yyyy/MM/dd")
            Else
                wDate = Format(DateAdd(DateInterval.Day, -1, StartSysDateTime), "yyyy/MM/dd")
            End If
        End If

        Return wDate
    End Function

    '--------------------------------------------------------------------------
    ' システム設定取得
    '--------------------------------------------------------------------------
    Public Function GetSysSettings(ByRef ListData As DataTable) As Boolean
        Dim Result As Boolean
        Dim ListRow As DataRow

        ListData = Nothing

        Result = True
        Try
            ListData = New DataTable

            ListData.Columns.Add(New DataColumn("SysDateTimeZone"))
            ListData.Columns.Add(New DataColumn("SysDate"))

            Using CmdDB As New SqlCommand(SELECT_M_SYSSETTINGS, ConnDB)
                CmdDB.CommandType = CommandType.Text
                CmdDB.Prepare()
                Using Reader = CmdDB.ExecuteReader
                    While Reader.Read
                        ListRow = ListData.NewRow()
                        ListRow.Item("SysDateTimeZone") = GetDbInt(Reader("SysDateTimeZone"))
                        ListRow.Item("SysDate") = CalcSysDate(Reader("SysDate"), Reader("SysDateTimeZone"))
                        ListData.Rows.Add(ListRow)
                        ListRow = Nothing
                    End While
                End Using
            End Using

            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSysSettings," & ex.Message
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 前回のシステム日付を取得
    '--------------------------------------------------------------------------
    Public Function GetPrevSysDate(ByVal NowDate As DateTime, ByRef SysDate As DateTime) As Boolean

        Dim CmdDB As SqlCommand
        Dim Result As Boolean

        Result = True
        Try
            CmdDB = New SqlCommand(My.Resources.SQL_System_GetPrevSysDate, ConnDB)
            CmdDB.CommandType = CommandType.Text

            Dim param As SqlParameter
            param = CmdDB.Parameters.Add("@TempDate", SqlDbType.Date)
            param.Direction = ParameterDirection.InputOutput
            param.Value = NowDate

            CmdDB.ExecuteNonQuery()

            Dim sysDateValue As Object = CmdDB.Parameters("@TempDate").Value
            If IsDBNull(sysDateValue) Then
                SystemLog.ErrorTEL("getSysDate is null", "getPrevSysDate で営業日を取得できませんでした。")
            Else
                SysDate = sysDateValue
                Result = True
            End If

            Result = True
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetPrevSysDate," & ex.Message
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 会社情報取得
    '--------------------------------------------------------------------------
    Public Function GetCompanyList(ByRef ListData As DataTable) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim ListRow As DataRow

        ListData = Nothing

        Result = True
        Try
            ListData = New DataTable
            ListData.Columns.Add(New DataColumn("CmpCode"))
            ListData.Columns.Add(New DataColumn("CmpName"))

            Dim SQL As New StringBuilder
            SQL.AppendLine("select")
            SQL.AppendLine(" CMP.[CmpCode] [CmpCode],")
            SQL.AppendLine(" CMP.[CmpName] [CmpName]")
            SQL.AppendLine(" from M_Company CMP with (nolock)")
            SQL.AppendLine(" order by CMP.[CmpCode]")
            CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                ListRow = ListData.NewRow()
                ListRow.Item("CmpCode") = GetDbString(Reader.Item("CmpCode"))
                ListRow.Item("CmpName") = GetDbString(Reader.Item("CmpName"))
                ListData.Rows.Add(ListRow)
                ListRow = Nothing
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetCompanyList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' 通貨ペア情報取得
    '--------------------------------------------------------------------------
    Public Function GetCurrencyLsit(ByRef ListData As Dictionary(Of String, String)) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean

        ListData = Nothing

        Result = True
        Try
            ListData = New Dictionary(Of String, String)
            Dim SQL As New StringBuilder
            SQL.AppendLine("select")
            SQL.AppendLine(" CUR.[CurCode] [CurCode],")
            SQL.AppendLine(" CUR.[CurName] [CurName],")
            SQL.AppendLine(" CUR.[DecimalPlaces] [DecimalPlaces]")
            SQL.AppendLine(" from M_Currency CUR with (nolock)")
            CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read

                ListData.Add(GetDbString(Reader.Item("CurCode")), GetDbString(Reader.Item("CurName")) & "_" & GetDbInt(Reader.Item("DecimalPlaces")))

            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetCurrencyLsit," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function CreateCashHistCSV(ByVal csvFormat As String, ByVal systemDate As Date, ByVal cmpCode As String, ByVal cmpName As String _
                                      , ByVal CurrencyList As Dictionary(Of String, String)) As Boolean
        Dim result As Boolean
        Dim SQL As StringBuilder
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader

        result = True
        Try
            SQL = New StringBuilder
            SQL.AppendLine("select * from T_Cash C with (nolock)")
            SQL.AppendLine("where C.[SysDate] = @SysDate")
            SQL.AppendLine("  and C.[CmpCode] = @CmpCode")
            SQL.AppendLine("order by SysDate, CashCode desc")

            CmdDB = New SqlCommand(SQL.ToString(), ConnDB)
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@SysDate", SqlDbType.DateTime2, 7).Value = systemDate
            CmdDB.Parameters.Add("@CmpCode", SqlDbType.VarChar, 10).Value = cmpCode

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()

            Dim bInit As Boolean
            Dim sFolderNameCSV As String
            Dim sFileNameCSV As String
            Dim StreamCSV As StreamWriter
            Dim BufferCSV As String

            bInit = True
            sFolderNameCSV = My.Settings.OutputPathCSV & systemDate.ToString("yyyyMMdd") & "\"

            sFileNameCSV = sFolderNameCSV & String.Format(csvFormat, systemDate.ToString("yyyyMMdd"), cmpName.Replace(" ", "")) & ".csv"
            StreamCSV = Nothing

            ' 残高履歴がない場合でもヘッダーのみファイルを作成する
            If Directory.Exists(sFolderNameCSV) = False Then
                Directory.CreateDirectory(sFolderNameCSV)
            End If
            StreamCSV = New StreamWriter(sFileNameCSV, False, System.Text.Encoding.GetEncoding("shift_jis"))

            Dim header As String() = {"処理Seq", "有効フラグ(Code)", "有効フラグ", "処理日時", "取引日", "取引種別(Code)", "取引種別", "通貨種別", "金額", "取引後残高", "委託者コード"}

            BufferCSV = CreateCsvHeader(header)
            StreamCSV.Write(BufferCSV)

            While Reader.Read

                ' 通貨情報を取得(0:CurName, 1:DecimalPlaces)
                Dim CurData As String() = Split(CurrencyList(Reader.Item("CurCode")), "_")
                Dim CurName As String = CurData(0)
                Dim CurDecimalPlace As String = GetMoneyFormatDisp(CurData(1))

                Dim ExecTime As String = GetDBDateTime(Reader.Item("ExecTime"), "yyyy/MM/dd HH:mm:ss")

                BufferCSV = """" & Reader.Item("CashCode") & LINE_END
                BufferCSV = BufferCSV & LINE_START & Reader.Item("Enabled") & LINE_END
                BufferCSV = BufferCSV & LINE_START & EnableType.GetName(Reader.Item("Enabled")) & LINE_END
                BufferCSV = BufferCSV & LINE_START & ExecTime & LINE_END
                BufferCSV = BufferCSV & LINE_START & Reader.Item("SysDate") & LINE_END
                BufferCSV = BufferCSV & LINE_START & Reader.Item("CashType") & LINE_END
                BufferCSV = BufferCSV & LINE_START & CashType.GetName(Reader.Item("CashType")) & LINE_END
                BufferCSV = BufferCSV & LINE_START & CurName & LINE_END
                BufferCSV = BufferCSV & LINE_START & GetDBDecimal(Reader.Item("Money"), CurDecimalPlace) & LINE_END
                BufferCSV = BufferCSV & LINE_START & GetDBDecimal(Reader.Item("TotalMoney"), CurDecimalPlace) & LINE_END
                BufferCSV = BufferCSV & LINE_START & Reader.Item("CustCode") & LINE_END
                BufferCSV = BufferCSV & vbCrLf

                StreamCSV.Write(BufferCSV)

            End While

            If StreamCSV IsNot Nothing Then
                StreamCSV.Close()
            End If

            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "CreateCashHistCSV," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            result = False
            blnError = True
        End Try

        Return result
    End Function

    Private Function CreateCsvHeader(ByVal calm As String()) As String
        Dim Result As New StringBuilder

        Dim init As Boolean = False
        For Each head In calm
            If init = False Then
                Result.Append("""" & head & """")
                init = True
            Else
                Result.Append(LINE_START & head & LINE_END)
            End If

        Next
        Result.Append(vbCrLf)

        Return Result.ToString
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ項目取得（Ｉｎｔ）
    '--------------------------------------------------------------------------
    Public Function GetDbInt(ByVal obj As Object) As Integer
        Dim RetVal As Integer

        If IsDBNull(obj) Then
            RetVal = 0
        Else
            RetVal = CInt(obj)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ項目取得（文字列）
    '--------------------------------------------------------------------------
    Public Function GetDbString(ByVal obj As Object) As String
        Dim RetVal As String

        If IsDBNull(obj) Then
            RetVal = [String].Empty
        Else
            RetVal = CStr(obj)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ項目取得（Ｒａｔｅ：Ｄｅｃｉｍａｌ）
    '--------------------------------------------------------------------------
    Public Function GetDbRate(ByVal obj As Object, ByVal sFormat As String) As Decimal
        Dim RetVal As Decimal
        Dim sDec As String

        If IsDBNull(obj) Then
            RetVal = 0
        Else
            sDec = Format(CDec(obj), sFormat)
            RetVal = CDec(sDec)
        End If

        Return RetVal
    End Function

    Private Function GetDBDecimal(ByVal item As Object, ByVal viewFormt As String) As String
        Dim ret As String = ""

        If Not IsDBNull(item) Then
            Dim decimalTemp As Decimal = item
            ret = Format(decimalTemp, viewFormt)
        End If

        Return ret
    End Function

    Private Function GetDBDateTime(ByVal item As Object, ByVal viewFormt As String) As String
        Dim ret As String = ""

        If Not IsDBNull(item) Then
            Dim decimalTemp As DateTime = item
            ret = Format(decimalTemp, viewFormt)
        End If

        Return ret
    End Function

    Public Shared Function GetMoneyFormatDisp(ByVal decimalPlace As Integer) As String
        Dim ret = "###,###,###,###,###,##0.####"
        Select Case decimalPlace
            Case 1 : ret = "###,###,###,###,###,##0.0###"
            Case 2 : ret = "###,###,###,###,###,##0.00##"
            Case 3 : ret = "###,###,###,###,###,##0.000#"
            Case 4 : ret = "###,###,###,###,###,##0.0000"
        End Select
        Return ret
    End Function

    Public Shared Function GetRateDPFormat(DecimalPlaces As Integer) As String
        If DecimalPlaces <= 0 Then
            Return "######0.########"
        End If
        Select Case DecimalPlaces
            Case 0 : Return "######0.########"
            Case 1 : Return "######0.0#######"
            Case 2 : Return "######0.00######"
            Case 3 : Return "######0.000#####"
            Case 4 : Return "######0.0000####"
            Case 5 : Return "######0.00000###"
            Case 6 : Return "######0.000000##"
            Case 7 : Return "######0.0000000#"
        End Select
        Return "######0.00000000"
    End Function

End Class
