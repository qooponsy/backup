﻿Imports System.IO
Imports System.IO.Path

Public Class clsZipFileSystem
    Private objShellFS As Object

    Public Const ZipTimeOut As Integer = 20000  ' Zip圧縮最大待ち時間(1ファイル)：20000ミリ秒

    '--------------------------------------------------------------------------
    ' コンストラクタ
    '--------------------------------------------------------------------------
    Public Sub New()
        objShellFS = CreateObject("Shell.Application")
    End Sub

    '--------------------------------------------------------------------------
    ' 空のＺＩＰファイルを作成
    '--------------------------------------------------------------------------
    Public Function CreateZipFile(ByVal sZipFileName As String) As Boolean
        Dim bCreateZip As Boolean
        Dim fsZip As FileStream
        Dim b As Byte() = {&H50, &H4B, 5, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        bCreateZip = True
        Try
            fsZip = File.Create(sZipFileName)
            If IsNothing(fsZip) = False Then
                fsZip.Write(b, 0, b.Length)
                fsZip.Close()
            End If
        Catch ex As Exception
            bCreateZip = False
        End Try

        Return bCreateZip
    End Function

    '--------------------------------------------------------------------------
    ' ＺＩＰファイルにエントリーを追加
    '--------------------------------------------------------------------------
    Public Function AddZipEntry(ByVal sZipFileName As String, ByRef sFileName As String) As Boolean
        Dim bAddZip As Boolean
        Dim oSourceFolder As Object
        Dim oZipFolder As Object
        Dim oSourceItem As Object
        Dim ZCount As Integer
        Dim WaitTimeWatch As Stopwatch = Nothing

        bAddZip = True
        Try
            If File.Exists(sFileName) = True Then
                oSourceFolder = objShellFS.NameSpace(GetDirectoryName(sFileName))
                oZipFolder = objShellFS.NameSpace(GetFullPath(sZipFileName))
                oSourceItem = oSourceFolder.ParseName(GetFileName(sFileName))

                ZCount = oZipFolder.Items().Count
                oZipFolder.CopyHere(oSourceItem)
                WaitTimeWatch = Stopwatch.StartNew()
                Do While oZipFolder.Items().Count <= ZCount
                    Threading.Thread.Sleep(100)

                    ' Zip圧縮タイムアウト判定(20000ミリ秒)
                    If WaitTimeWatch.ElapsedMilliseconds >= ZipTimeOut Then
                        bAddZip = False
                        CashHistExport.ErrorMessage = "AddZipEntry TimeOut Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
                        'TODO: タイムアウトエラー
                        Exit Do
                    End If
                Loop
            End If
        Catch ex As Exception
            bAddZip = False
        Finally
            If Not IsNothing(WaitTimeWatch) Then
                WaitTimeWatch.Stop()
                WaitTimeWatch = Nothing
            End If
        End Try


        Return bAddZip
    End Function
End Class
