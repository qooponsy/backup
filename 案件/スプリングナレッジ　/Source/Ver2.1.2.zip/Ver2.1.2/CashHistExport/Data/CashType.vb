﻿Public Class CashType
    Public Shared List As New Dictionary(Of String, String)

    Public Shared Sub Init()
        List.Add("00", "口座開設")
        List.Add("01", "入金")
        List.Add("02", "出金")
        List.Add("03", "購入")
        List.Add("04", "ペイアウト(期限前)")
        List.Add("05", "ペイアウト(期日ITM)")
        List.Add("06", "ペイアウト(期日OTM)")
        List.Add("07", "ペイアウト(期日ATM)")
        List.Add("08", "キャンセル")
    End Sub

    Public Shared Function GetName(ByVal statusCode As String) As String
        Dim ret As String = Nothing
        ret = List(statusCode)

        Return ret
    End Function
End Class
