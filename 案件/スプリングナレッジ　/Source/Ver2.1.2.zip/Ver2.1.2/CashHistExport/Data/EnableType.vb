﻿Public Class EnableType
    Public Shared List As New Dictionary(Of String, String)

    Public Shared Sub Init()
        List.Add("1", "有効")
        List.Add("0", "無効")
    End Sub

    Public Shared Function GetName(ByVal statusCode As String) As String
        Dim ret As String = Nothing
        ret = List(statusCode)

        Return ret
    End Function
End Class
