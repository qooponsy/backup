﻿Imports System.IO
Imports System.Text

'------------------------------------------------------------------------------
' 残高履歴データＣＳＶ出力 バッチ
'   日次バッチの後に本バッチが実行されるため、前日の銘柄履歴ファイルを作成する
'   バッチは毎日実行され、取引データが0件でもファイルは作成される
'   
'------------------------------------------------------------------------------

Module CashHistExport
    Private DataBase As clsPenguinDB
    Public ErrorMessage As String = ""
    Private SystemDate As Date
    Private SysDateTimeZone As Integer

    Private Const MaxStopInterval As Integer = 86400    '最大再実行間隔：86400秒(1日)
    Private Const ErrorLogFileName As String = "CashHistExportError.log"

    Private Const FILE_TYPE As String = "02"
    Private Const ZIP_FORMAT As String = "{0}_{1}_{2}_{3}"
    Private Const CSV_FORMAT As String = "CashHist_{0}_{1}"

    '--------------------------------------------------------------------------
    ' Main
    '--------------------------------------------------------------------------
    Function Main(CmdArgs() As String) As Integer
        SystemLog.InitConsoleApp()

        SystemDate = Date.MinValue

        ' 再実行判定
        If CmdArgs.Count > 0 Then
            ' コマンドライン引数あり
            If IsNumeric(CmdArgs(0)) Then
                ' 秒指定あり
                Dim StopInterval As Integer = Integer.Parse(CmdArgs(0))
                If StopInterval > MaxStopInterval Then
                    StopInterval = MaxStopInterval
                End If
                System.Threading.Thread.Sleep(StopInterval * 1000)
            End If
        End If

        ' システム変数にてシステム日付の設定あり
        If CmdArgs.Count > 1 Then
            If IsDate(CmdArgs(1)) Then
                'コマンドラインでシステム日付を設定
                SystemDate = Date.Parse(CmdArgs(1))
            End If
        End If

        Dim DataList As DataTable
        Dim CmpList As DataTable
        Dim CurrencyList As Dictionary(Of String, String)
        Dim CashHistList As DataTable

        Dim bResult As Boolean

        DataList = Nothing
        CashHistList = Nothing
        DataBase = New clsPenguinDB
        If DataBase.GetSqlConnection(My.Settings.DB) = True Then
            bResult = DataBase.GetSysSettings(DataList)
            If bResult = True Then

                If Not SystemDate = Date.MinValue Then
                    ' コマンドライン引数を最優先
                ElseIf My.Settings.WorkDate <> "" Then
                    'Settings.WorkDateが設定されている場合は優先(Rerun対策)
                    SystemDate = Date.Parse(My.Settings.WorkDate)
                Else
                    Dim OldSysDate As DateTime
                    Dim NewSysDate As DateTime

                    NewSysDate = Date.Parse(DataList.Rows(0).Item("SysDate").ToString())
                    '前営業日の取得

                    bResult = DataBase.GetPrevSysDate(NewSysDate, OldSysDate)
                    If bResult Then
                        SystemDate = OldSysDate
                    End If
                End If

                '--------------------------------------------------------------
                ' 会社情報を取得
                '--------------------------------------------------------------
                CmpList = Nothing
                If bResult = True Then
                    bResult = DataBase.GetCompanyList(CmpList)
                End If

                '--------------------------------------------------------------
                ' 通貨情報を取得
                '--------------------------------------------------------------
                CurrencyList = Nothing
                If bResult = True Then
                    bResult = DataBase.GetCurrencyLsit(CurrencyList)
                End If

                '--------------------------------------------------------------
                ' ステータスリストを作成
                '--------------------------------------------------------------
                CashType.Init()
                EnableType.Init()

                '--------------------------------------------------------------
                ' 出力ファイルを作成
                '--------------------------------------------------------------
                If bResult = True Then
                    For Each ListRow In CmpList.Rows

                        ' CSVファイルを作成
                        bResult = DataBase.CreateCashHistCSV(CSV_FORMAT, SystemDate, ListRow.item("CmpCode"), ListRow.Item("CmpName"), CurrencyList)
                        If bResult = False Then
                            CashHistExport.ErrorMessage = "CreateCashHistCSV Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
                            Exit For
                        End If

                        ' 作成ファイルをzip圧縮
                        bResult = CreateZip(SystemDate, ListRow.item("CmpCode"), ListRow.Item("CmpName"))
                        If bResult = False Then
                            Exit For
                        End If
                    Next
                End If
                DataBase.EndSqlConnection()
            Else
                SystemLog.Information("DataBase Connect Error.")
            End If
        End If
        DataBase = Nothing

        '--------------------------------------------------------------
        ' CSVフォルダを削除
        '--------------------------------------------------------------
        If bResult = True Then
            bResult = DeleteCsvFolder(SystemDate)
        End If

        If bResult = True Then
            Return 0
        Else
            If ErrorMessage.Length = 0 Then
                ErrorMessage = "Other Error " & Format(Now, "yyyy/MM/dd HH:mm:ss") & vbCrLf
            End If
            ErrorLogOut(ErrorMessage)
            Return -1
        End If

    End Function

    '--------------------------------------------------------------------------
    ' 営業日単位にＣＳＶファイルをZIP圧縮する
    '--------------------------------------------------------------------------
    Private Function CreateZip(ByVal systemDate As Date, ByVal cmpCode As String, ByVal cmpName As String) As Boolean
        Dim bResult As Boolean
        Dim zipFS As clsZipFileSystem
        Dim sFileNameZip As String
        Dim FilesCSV() As String
        Dim sFileNameCSV As String
        Dim sFolderCSV As String

        bResult = True
        Try
            sFolderCSV = My.Settings.OutputPathCSV & systemDate.ToString("yyyyMMdd") & "\"
            If Directory.Exists(sFolderCSV) = True Then
                zipFS = New clsZipFileSystem

                Dim csvName As String = String.Format(CSV_FORMAT, systemDate.ToString("yyyyMMdd"), cmpName.Replace(" ", ""))
                sFileNameZip = My.Settings.OutputPathZIP & String.Format(ZIP_FORMAT, FILE_TYPE, systemDate.ToString("yyyyMMdd"), cmpCode, NameEncode(csvName)) & ".zip"
                'sFileNameZip = My.Settings.OutputPathZIP & systemDate.ToString("yyyyMMdd") & ".zip"

                bResult = zipFS.CreateZipFile(sFileNameZip)

                Dim SleepTime As Integer = My.Settings.SleepTime

                System.Threading.Thread.Sleep(SleepTime)
                If bResult = True Then
                    FilesCSV = Directory.GetFiles(sFolderCSV, csvName & ".csv")
                    For Each sFileNameCSV In FilesCSV
                        bResult = zipFS.AddZipEntry(sFileNameZip, sFileNameCSV)
                        If bResult = False Then
                            Exit For
                        End If
                    Next
                Else
                    'Logging("RateExport Error. Zip Create Error", EventLogEntryType.Error)
                End If
            End If
        Catch ex As Exception
            bResult = False
            SystemLog.AppError(ex)
        End Try

        Return bResult

    End Function

    '--------------------------------------------------------------------------
    'CSV保存フォルダを削除
    '--------------------------------------------------------------------------
    Private Function DeleteCsvFolder(ByVal systemDate As DateTime) As Boolean
        Dim ret As Boolean = True
        Dim strFolderNameCSV As String

        Try
            strFolderNameCSV = My.Settings.OutputPathCSV & systemDate.ToString("yyyyMMdd")
            If Directory.Exists(strFolderNameCSV) Then
                Directory.Delete(strFolderNameCSV, True)
            End If
        Catch ex As Exception
            ret = False
            SystemLog.AppError(ex)
        End Try

        Return ret
    End Function

    Private Function NameEncode(ByVal name As String) As String
        Dim dest As String = name
        dest = Replace(dest, "@", "@0")
        dest = Replace(dest, "_", "@1")

        Return dest
    End Function

    Public Sub ErrorLogOut(ByVal OutMessage As String)
        Dim StreamErrorLog As StreamWriter

        StreamErrorLog = New StreamWriter(My.Application.Info.DirectoryPath & "\" & ErrorLogFileName, True, Encoding.ASCII)
        StreamErrorLog.Write(OutMessage)
        StreamErrorLog.Close()
        StreamErrorLog = Nothing
    End Sub

End Module
