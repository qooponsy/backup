﻿Public Class BulkTaskData

    Public TaskSeq As String
    Public TaskStatus As String
    Public TaskType As String
    Public TaskParam As String
    Public ExecStep As Integer

End Class
