﻿Public Class ProductData
    Implements IComparable(Of ProductData)

    Public ProductCode As String
    Public StartTime As DateTime

    Public Function CompareTo(other As ProductData) As Integer Implements System.IComparable(Of ProductData).CompareTo
        If StartTime <> other.StartTime Then
            Return StartTime.CompareTo(other.StartTime)
        End If
        Return ProductCode.CompareTo(other.ProductCode)
    End Function
End Class
