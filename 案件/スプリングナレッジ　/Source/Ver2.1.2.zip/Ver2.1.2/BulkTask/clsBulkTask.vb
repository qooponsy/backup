﻿Imports System
Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports System.Threading
Imports System.Diagnostics

Public Class clsBulkTask

    Private strServiceName As String
    Private blnServiceStopFlag As Boolean
    Private blnMasterMode As Boolean

    Private MasterHB() As Byte
    Private SlaveHB() As Byte
    Private HeartBeatUDP As UdpClient
    Private MasterWatch As Stopwatch
    Private SocketErrMsg As String

    Public Class OpTypeCode
        Public Const BINARY As String = "01"
        Public Const ANYTIME As String = "02"
    End Class

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Sub New()
        blnServiceStopFlag = False
        strServiceName = "BulkTask"
#If REL_DEMO Then
        strServiceName = "BulkTaskDemoUK"
#End If
#If REL_ST Then
        strServiceName = "BulkTaskUK"
#End If
#If REL_UK Then
        strServiceName = "BulkTaskUK"
#End If
#If REL_MT4 Then
        strServiceName = "BulkTaskMT4"
#End If

        blnMasterMode = False
    End Sub

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsMasterMode() As Boolean
        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッドの初期設定
    '--------------------------------------------------------------------------
    Public Function InitializeServiceThread() As Boolean
        Dim bInitRes As Boolean

        bInitRes = True

        MasterHB = System.Text.Encoding.ASCII.GetBytes("!M" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)
        SlaveHB = System.Text.Encoding.ASCII.GetBytes("!S" & My.Settings.MasterPriority.ToString() & My.Settings.ProcessID)

        Return bInitRes
    End Function

    '--------------------------------------------------------------------------
    ' Service制御スレッド
    '--------------------------------------------------------------------------
    Public Sub ServiceThread()
        Dim DataBase As clsPenguinDB
        Dim IntervalStopWatch As Stopwatch
        Dim HeartBeatWatch As Stopwatch
        Dim iInterval As Integer
        Dim iHeartBeatCycle As Integer

        Logging("ServiceThread Start.", EventLogEntryType.Information)

        HeartBeatUDP = New UdpClient(My.Settings.HeartBeatPortR)
        MasterWatch = Stopwatch.StartNew

        iInterval = 0
        iHeartBeatCycle = My.Settings.HeartBeatCycle

        OnSlaveMode()
        IntervalStopWatch = Stopwatch.StartNew()
        HeartBeatWatch = Stopwatch.StartNew

        RunningContoroller.initialize(My.Settings.DB, My.Settings.StartTime, My.Settings.EndTime, My.Settings.EndTime)
        Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime), EventLogEntryType.Information)

        While blnServiceStopFlag = False
            If HeartBeatWatch.ElapsedMilliseconds() >= iHeartBeatCycle Then
                CheckMasterAlive()
                HeartBeatWatch.Stop()
                HeartBeatWatch.Reset()
                HeartBeatWatch.Start()
            End If

            If IntervalStopWatch.ElapsedMilliseconds() >= iInterval Then
                iInterval = My.Settings.ExecutionInterval
                IntervalStopWatch.Stop()

                If RunningContoroller.check() Then
                    Logging(String.Format("Mode={0} / Next Time={1:yyyy/MM/dd HH:mm:ss}", IIf(RunningContoroller.Running, "Run", "Stop"), RunningContoroller.NextTime.ToLocalTime), EventLogEntryType.Information)
                End If

                If RunningContoroller.Running Then
                    DataBase = New clsPenguinDB
                    If DataBase.GetSqlConnection(My.Settings.DB) = True Then
                        If blnMasterMode Then
                            Dim TaskList As List(Of BulkTaskData) = Nothing
                            If Not DataBase.GetBulkTaskList(TaskList) Then
                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                            Else
                                For Each item As BulkTaskData In TaskList
                                    Select Case item.TaskType
                                        Case "00"   '何もしない
                                            If item.TaskStatus = "0" Then
                                                DataBase.StartTask(item.TaskSeq, 0)
                                            End If
                                            DataBase.EndTask(item.TaskSeq, 0, "")

                                        Case "01"   '銘柄単位取引キャンセル
                                            If item.TaskStatus = "0" Then
                                                Dim count As Integer = 0
                                                If Not DataBase.GetTradeCancelCount(item.TaskParam, count) Then
                                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                    DataBase.ErrorTask(item.TaskSeq, "キャンセル件数取得失敗")
                                                    Continue For
                                                End If
                                                DataBase.StartTask(item.TaskSeq, count)
                                            End If

                                            Dim TradeList As List(Of TradeData) = Nothing
                                            If Not DataBase.GetTradeCancelList(item.TaskParam, TradeList) Then
                                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                Continue For
                                            End If

                                            Dim CancelError As Boolean = False
                                            Dim CancelCount As Integer = 0
                                            Dim HBCount As Integer = 0
                                            For Each trade As TradeData In TradeList
                                                If HBCount Mod 50 = 0 Then
                                                    CheckMasterAlive()
                                                End If
                                                HBCount += 1
                                                If Not DataBase.CancelTask(trade.TradeSeq) Then
                                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                    CancelError = True
                                                    Continue For
                                                End If
                                                CancelCount += 1
                                            Next

                                            If Not CancelError Then
                                                DataBase.EndTask(item.TaskSeq, item.ExecStep + CancelCount, "")
                                            Else

                                            End If

                                        Case "02"   'システム停止
                                            If item.TaskStatus = "0" Then
                                                Dim count As Integer = 0
                                                If Not DataBase.GetTradeCancelCount("", count) Then
                                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                    DataBase.ErrorTask(item.TaskSeq, "キャンセル件数取得失敗")
                                                    Continue For
                                                End If
                                                DataBase.StartTask(item.TaskSeq, count)
                                            End If

                                            Dim TradeList As List(Of TradeData) = Nothing
                                            If Not DataBase.GetTradeCancelList("", TradeList) Then
                                                'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                Continue For
                                            End If

                                            Dim CancelError As Boolean = False
                                            Dim CancelCount As Integer = 0
                                            Dim HBCount As Integer = 0
                                            For Each trade As TradeData In TradeList
                                                If HBCount Mod 50 = 0 Then
                                                    CheckMasterAlive()
                                                End If
                                                HBCount += 1
                                                If Not DataBase.CancelTask(trade.TradeSeq) Then
                                                    'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                                                    CancelError = True
                                                    Continue For
                                                End If
                                                CancelCount += 1
                                            Next

                                            If Not CancelError Then
                                                DataBase.EndTask(item.TaskSeq, item.ExecStep + CancelCount, "")
                                            Else

                                            End If

                                        Case "03"   '銘柄スプレッド変更
                                            Select item.TaskStatus
                                                Case "0"    '未実行
                                                    Dim ParamList As String() = item.TaskParam.Split(",")
                                                    If ParamList.Length < 2 Then
                                                        DataBase.ErrorTask(item.TaskSeq, "パラメータ不足エラー")
                                                        Continue For
                                                    End If
                                                    Dim UserID As String = ParamList(0).Replace("\1", ",").Replace("\0", "\")
                                                    Dim ChangeSpread As Integer
                                                    If Not Integer.TryParse(ParamList(1), ChangeSpread) Then
                                                        DataBase.ErrorTask(item.TaskSeq, "パラメータ不正エラー(変更スプレッド):" & ParamList(1))
                                                        Continue For
                                                    End If
                                                    Dim MargineTime As Integer
                                                    If Not Integer.TryParse(ParamList(2), MargineTime) Then
                                                        DataBase.ErrorTask(item.TaskSeq, "パラメータ不正エラー(取引開始前時間):" & ParamList(2))
                                                        Continue For
                                                    End If

                                                    Dim SysDate As DateTime
                                                    If Not DataBase.GetSysDate(SysDate) Then
                                                        DataBase.ErrorTask(item.TaskSeq, "システム営業日取得失敗")
                                                        Continue For
                                                    End If

                                                    Dim ProductBaseCodeList As New List(Of String)
                                                    Dim TargetList As New List(Of ProductData)
                                                    For fa As Integer = 3 To ParamList.Length - 1
                                                        Dim ProductBaseCode As String = ParamList(fa)
                                                        Dim opType As String = ""
                                                        If Not DataBase.GetProductOpType(ProductBaseCode, opType) Then
                                                            DataBase.ErrorTask(item.TaskSeq, "オプション種別取得失敗")
                                                            Continue For
                                                        End If

                                                        If ProductBaseCode IsNot Nothing AndAlso ProductBaseCode.Length > 0 Then
                                                            ProductBaseCodeList.Add(ProductBaseCode)

                                                            '銘柄リストを取得
                                                            Select Case opType
                                                                Case OpTypeCode.BINARY

                                                                    'High/Low銘柄取得
                                                                    DataBase.GetProductChangeSpreadList(SysDate, ProductBaseCode, MargineTime, TargetList)

                                                                Case OpTypeCode.ANYTIME

                                                                    'AnyTime銘柄取得
                                                                    DataBase.GetProductAnyTimeChangeSpreadList(SysDate, ProductBaseCode, MargineTime, TargetList)

                                                            End Select
                                                        End If
                                                    Next
                                                    DataBase.StartTask(item.TaskSeq, TargetList.Count)
                                                    DataBase.InsertOperationHist(SysDate, UserID, "02", "05", "", "スプレッド更新開始：" & item.TaskParam)

                                                    TargetList.Sort()
                                                    For Each Product As ProductData In TargetList
                                                        DataBase.UpdateProductSpread(SysDate, item.TaskSeq, UserID, Product.ProductCode, ChangeSpread)
                                                    Next

                                                    DataBase.InsertOperationHist(SysDate, UserID, "02", "05", "", "スプレッド更新終了：" & item.TaskParam)
                                                    DataBase.EndTask(item.TaskSeq, TargetList.Count, "")
                                                    DataBase.UpdateSysUpdateSeq()

                                                Case "1"    '実行中
                                                    Dim SysDate As DateTime
                                                    If Not DataBase.GetSysDate(SysDate) Then
                                                        DataBase.ErrorTask(item.TaskSeq, "システム営業日取得失敗")
                                                        Continue For
                                                    End If
                                                    Dim ParamList As String() = item.TaskParam.Split(",")
                                                    If ParamList.Length < 2 Then
                                                        DataBase.ErrorTask(item.TaskSeq, "パラメータ不足エラー")
                                                        Continue For
                                                    End If
                                                    Dim UserID As String = ParamList(0).Replace("\1", ",").Replace("\0", "\")
                                                    'エラーとして終了
                                                    'S_BulkTask UPDATE TaskStatus=3、ExecEndTime=現在日時
                                                    'T_OperationHist INSERT 銘柄データ、一括更新、エラー
                                                    DataBase.InsertOperationHist(SysDate, UserID, "02", "05", "", "スプレッド更新エラー終了：" & item.TaskParam)
                                                    DataBase.UpdateSysUpdateSeq()
                                                    DataBase.ErrorTask(item.TaskSeq, "中断エラー")
                                            End Select

                                        Case "04"   '銘柄最小最大取引額変更
                                            Select Case item.TaskStatus
                                                Case "0"    '未実行
                                                    Dim ParamList As String() = item.TaskParam.Split(",")
                                                    If ParamList.Length < 2 Then
                                                        DataBase.ErrorTask(item.TaskSeq, "パラメータ不足エラー")
                                                        Continue For
                                                    End If

                                                    Dim UserID As String = ParamList(0).Replace("\1", ",").Replace("\0", "\")

                                                    Dim TradeMoneyMin As Decimal = -1
                                                    If ParamList(1) > 0 Then
                                                        If Not Decimal.TryParse(ParamList(1), TradeMoneyMin) Then
                                                            DataBase.ErrorTask(item.TaskSeq, "パラメータ不正エラー（変更最小取引額):" & ParamList(1))
                                                            Continue For
                                                        End If
                                                    End If
                                                    
                                                    Dim TradeMoneyMax As Decimal = -1
                                                    If ParamList(2) > 0 Then
                                                        If Not Decimal.TryParse(ParamList(2), TradeMoneyMax) Then
                                                            DataBase.ErrorTask(item.TaskSeq, "パラメータ不正エラー（変更最大取引額):" & ParamList(2))
                                                            Continue For
                                                        End If
                                                    End If

                                                    Dim ProductBaseChangeFlg As Boolean = ParamList(3)

                                                    Dim SysDate As DateTime
                                                    If Not DataBase.GetSysDate(SysDate) Then
                                                        DataBase.ErrorTask(item.TaskSeq, "システム営業日取得失敗")
                                                        Continue For
                                                    End If

                                                    Dim ProductBaseCodeList As New List(Of String)
                                                    Dim TargetList As New List(Of ProductData)
                                                    For fa As Integer = 4 To ParamList.Length - 1
                                                        Dim ProductBaseCode As String = ParamList(fa)
                                                        If ProductBaseCode IsNot Nothing AndAlso ProductBaseCode.Length > 0 Then
                                                            ProductBaseCodeList.Add(ProductBaseCode)
                                                            DataBase.GetProductChangeTradeMoneyList(SysDate, ProductBaseCode, TargetList)
                                                        End If
                                                    Next
                                                    DataBase.StartTask(item.TaskSeq, TargetList.Count)

                                                    If ProductBaseChangeFlg Then
                                                        ' 銘柄設定を一括変更
                                                        DataBase.InsertOperationHist(SysDate, UserID, "03", "05", "", "銘柄設定最小最大取引額更新開始：" & item.TaskParam)

                                                        ProductBaseCodeList.Sort()
                                                        For Each ProductBaseCode In ProductBaseCodeList
                                                            DataBase.UpdateProductBaseTradeMoney(SysDate, item.TaskSeq, UserID, ProductBaseCode, TradeMoneyMin, TradeMoneyMax)
                                                        Next

                                                        DataBase.InsertOperationHist(SysDate, UserID, "03", "05", "", "銘柄設定最小最大取引額更新終了：" & item.TaskParam)
                                                    End If

                                                    ' 当日銘柄を一括変更
                                                    DataBase.InsertOperationHist(SysDate, UserID, "02", "05", "", "銘柄最小最大取引額更新開始：" & item.TaskParam)

                                                    TargetList.Sort()
                                                    For Each Product As ProductData In TargetList
                                                        DataBase.UpdateProductTradeMoney(SysDate, item.TaskSeq, UserID, Product.ProductCode, TradeMoneyMin, TradeMoneyMax)
                                                    Next

                                                    DataBase.InsertOperationHist(SysDate, UserID, "02", "05", "", "銘柄最小最大取引額更新終了：" & item.TaskParam)
                                                    DataBase.EndTask(item.TaskSeq, TargetList.Count, "")
                                                    DataBase.UpdateSysUpdateSeq()

                                                Case "1"    '実行中
                                                    Dim SysDate As DateTime
                                                    If Not DataBase.GetSysDate(SysDate) Then
                                                        DataBase.ErrorTask(item.TaskSeq, "システム営業日取得失敗")
                                                        Continue For
                                                    End If
                                                    Dim ParamList As String() = item.TaskParam.Split(",")
                                                    If ParamList.Length < 2 Then
                                                        DataBase.ErrorTask(item.TaskSeq, "パラメータ不足エラー")
                                                        Continue For
                                                    End If
                                                    Dim UserID As String = ParamList(0).Replace("\1", ",").Replace("\0", "\")
                                                    Dim ProductBaseChangeFlg As Boolean = ParamList(3)
                                                    'エラーとして終了
                                                    'S_BulkTask UPDATE TaskStatus=3、ExecEndTime=現在日時
                                                    'T_OperationHist INSERT 銘柄データ、一括更新、エラー
                                                    If ProductBaseChangeFlg Then
                                                        DataBase.InsertOperationHist(SysDate, UserID, "03", "05", "", "銘柄設定更新エラー終了：" & item.TaskParam)
                                                    End If
                                                    DataBase.InsertOperationHist(SysDate, UserID, "02", "05", "", "銘柄更新エラー終了：" & item.TaskParam)
                                                    DataBase.UpdateSysUpdateSeq()
                                                    DataBase.ErrorTask(item.TaskSeq, "中断エラー")
                                            End Select

                                    End Select
                                Next
                            End If

                        End If

                        DataBase.EndSqlConnection()
                    Else
                        'Logging(DataBase.GetErrorMessage(), EventLogEntryType.Error)
                    End If

                    DataBase = Nothing
                End If

                IntervalStopWatch.Reset()
                IntervalStopWatch.Start()
            End If
            Thread.Sleep(500)
        End While

        IntervalStopWatch.Stop()

        MasterWatch.Stop()
        HeartBeatUDP.Close()

        Logging("ServiceThread Stop.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Service制御スレッド、及びワーカースレッドの停止要求
    '--------------------------------------------------------------------------
    Public Sub StopService()
        blnServiceStopFlag = True
    End Sub

    '--------------------------------------------------------------------------
    ' Slave->Master移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnMasterMode()
        Logging("Master Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' Master->Slave移行イベント
    '--------------------------------------------------------------------------
    Public Sub OnSlaveMode()
        Logging("Slave Mode Start.", EventLogEntryType.Information)
    End Sub

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Public Function CheckMasterAlive() As Boolean
        Dim RemoteEP As IPEndPoint
        Dim bMasterRecv As Boolean
        Dim bSlaveRecv As Boolean
        Dim sHeartBeatMode As String
        Dim iHeartBeatPriority As Integer

        bMasterRecv = False
        bSlaveRecv = False
        iHeartBeatPriority = 9
        If HeartBeatUDP.Available() > 0 Then
            Dim sDataHB As String
            Dim DataHB() As Byte

            RemoteEP = Nothing
            Try
                DataHB = Nothing
                While HeartBeatUDP.Available() > 0
                    DataHB = HeartBeatUDP.Receive(RemoteEP)
                End While
                sDataHB = System.Text.Encoding.ASCII.GetString(DataHB)
                Do
                    Dim NextIndex As Integer = sDataHB.IndexOf("!", 1)
                    If NextIndex = -1 Then Exit Do
                    If sDataHB.Length - NextIndex < 3 Then Exit Do
                    sDataHB = sDataHB.Substring(NextIndex)
                Loop While True
                If My.Settings.HeartBeatLog Then SystemLog.Information(sDataHB)
                If sDataHB.Length >= 3 Then
                    sHeartBeatMode = sDataHB.Substring(1, 1)
                    iHeartBeatPriority = CInt(sDataHB.Substring(2, 1))
                    If sHeartBeatMode.Equals("M") = True Then
                        bMasterRecv = True
                        MasterWatch.Reset()
                        MasterWatch.Start()
                    End If
                    If sHeartBeatMode.Equals("S") = True Then
                        bSlaveRecv = True
                    End If
                End If
            Catch ex As Exception
                If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
            End Try
        End If

        If blnMasterMode = True Then
            If bMasterRecv = True Then
                ' MasterのHBを受信した場合自Priorityが低ければ(大きければ)Slaveへ移行
                If iHeartBeatPriority < My.Settings.MasterPriority Then
                    OnSlaveMode()
                    blnMasterMode = False
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        Else
            If bSlaveRecv AndAlso iHeartBeatPriority > My.Settings.MasterPriority Then
                OnMasterMode()
                blnMasterMode = True
                MasterWatch.Reset()
                MasterWatch.Start()
            ElseIf MasterWatch.ElapsedMilliseconds >= My.Settings.HeartBeatTimeout Then
                If SystemLog.GetDBErrorCount() > 0 Then
                    If My.Settings.HeartBeatLog Then SystemLog.Information("DB Error Now.")
                Else
                    OnMasterMode()
                    blnMasterMode = True
                    MasterWatch.Reset()
                    MasterWatch.Start()
                End If
            End If
        End If

        Try
            If blnMasterMode Then
                HeartBeatUDP.Send(MasterHB, MasterHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            Else
                HeartBeatUDP.Send(SlaveHB, SlaveHB.Length, My.Settings.HeartBeatAddress, My.Settings.HeartBeatPortS)
            End If
        Catch ex As Exception
            If My.Settings.HeartBeatLog Then SystemLog.AppError(ex)
        End Try

        Return blnMasterMode
    End Function

    '--------------------------------------------------------------------------
    ' 
    '--------------------------------------------------------------------------
    Private Sub Logging(ByVal sMessage As String, ByVal entryType As EventLogEntryType)
        Dim eLog As EventLog

        Try
            Debug.Print(sMessage)
            eLog = New EventLog()
            eLog.Source = strServiceName
            eLog.WriteEntry(sMessage, entryType)
            eLog = Nothing
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
    End Sub

End Class
