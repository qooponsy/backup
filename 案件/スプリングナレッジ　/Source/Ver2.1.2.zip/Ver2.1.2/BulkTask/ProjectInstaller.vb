﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'この呼び出しは、コンポーネント デザイナーで必要です。
        InitializeComponent()

        'InitializeComponent への呼び出し後、初期化コードを追加します
#If REL_DEMO Then
        Me.ServiceInstaller.Description = "BulkTaskDemoUK"
        Me.ServiceInstaller.ServiceName = "BulkTaskDemoUK"
#End If
#If REL_ST Then
        Me.ServiceInstaller.Description = "BulkTaskUK"
        Me.ServiceInstaller.ServiceName = "BulkTaskUK"
#End If
#If REL_UK Then
        Me.ServiceInstaller.Description = "BulkTaskUK"
        Me.ServiceInstaller.ServiceName = "BulkTaskUK"
#End If
#If REL_MT4 Then
        Me.ServiceInstaller.Description = "BulkTaskMT4"
        Me.ServiceInstaller.ServiceName = "BulkTaskMT4"
#End If

    End Sub

End Class
