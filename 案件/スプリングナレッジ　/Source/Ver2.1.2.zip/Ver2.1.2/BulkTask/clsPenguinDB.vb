﻿Imports System.IO
Imports System.Text
Imports System.Data.SqlClient

'------------------------------------------------------------------------------
'
'------------------------------------------------------------------------------
Public Class clsPenguinDB
    Private ConnDB As SqlConnection
    Private strError As String
    Private blnError As Boolean

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Class SeqCounterCode
        Public Const Rate As String = "01"
        Public Const Chart As String = "02"
        Public Const ProductBase As String = "03"
        Public Const Product As String = "04"
        Public Const Trade As String = "05"
        Public Const Cash As String = "06"
        Public Const Task As String = "07"
    End Class

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetSqlConnection(ByVal sConnectString As String) As Boolean
        Dim Result As Boolean

        strError = ""
        Result = True
        blnError = False
        Try
            ConnDB = New SqlConnection(sConnectString)
            ConnDB.Open()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSqlConnection," & ex.Message
            ConnDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function EndSqlConnection() As Boolean
        Dim Result As Boolean

        Result = True
        Try
            ConnDB.Close()
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "EndSqlConnection," & ex.Message
            blnError = True
            Result = False
        End Try
        ConnDB = Nothing

        Return Result
    End Function

    Public Function GetBulkTaskList(ByRef ListData As List(Of BulkTaskData)) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        ListData = Nothing

        Result = True
        Try
            ListData = New List(Of BulkTaskData)

            strSQL = "select * from [S_BulkTask] where [TaskStatus] in ('0', '1') order by [TaskSeq]"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text

            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                Dim item As New BulkTaskData
                item.TaskSeq = GetDbString(Reader.Item("TaskSeq"))
                item.TaskStatus = GetDbString(Reader.Item("TaskStatus"))
                item.TaskType = GetDbString(Reader.Item("TaskType"))
                item.TaskParam = GetDbString(Reader.Item("TaskParam"))
                item.ExecStep = GetDbInt(Reader.Item("ExecStep"))
                ListData.Add(item)
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetBulkTaskList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function


    Public Function StartTask(TaskSeq As String, LastStep As Integer) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "update [S_BulkTask] set [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@ProcUser" & vbCrLf
        strSQL = strSQL & "    ,[TaskStatus]='1',[LastStep]=@LastStep, [ExecStartTime]=SYSUTCDATETIME()" & vbCrLf
        strSQL = strSQL & "where [TaskSeq] = @TaskSeq" & vbCrLf
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@TaskSeq", SqlDbType.Char, 17).Value = TaskSeq
            CmdDB.Parameters.Add("@LastStep", SqlDbType.Int).Value = LastStep
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "StartTask," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function EndTask(TaskSeq As String, ExecStep As Integer, TaskResult As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "update [S_BulkTask] set [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@ProcUser" & vbCrLf
        strSQL = strSQL & "    ,[TaskStatus]='2',[ExecStep]=@ExecStep,[ExecEndTime]=SYSUTCDATETIME(),[TaskResult]=@TaskResult" & vbCrLf
        strSQL = strSQL & "where [TaskSeq] = @TaskSeq" & vbCrLf
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@TaskSeq", SqlDbType.Char, 17).Value = TaskSeq
            CmdDB.Parameters.Add("@ExecStep", SqlDbType.Int).Value = ExecStep
            CmdDB.Parameters.Add("@TaskResult", SqlDbType.Text).Value = TaskResult
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "StartTask," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function ErrorTask(TaskSeq As String, TaskResult As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = ""
        strSQL = strSQL & "update [S_BulkTask] set [UpdTime]=SYSUTCDATETIME(), [UpdUser]=@ProcUser" & vbCrLf
        strSQL = strSQL & "    ,[TaskStatus]='3',[ExecEndTime]=SYSUTCDATETIME(),[TaskResult]=@TaskResult" & vbCrLf
        strSQL = strSQL & "where [TaskSeq] = @TaskSeq" & vbCrLf
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@TaskSeq", SqlDbType.Char, 17).Value = TaskSeq
            CmdDB.Parameters.Add("@TaskResult", SqlDbType.Text).Value = TaskResult
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "StartTask," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function GetTradeCancelCount(ProductCode As String, ByRef Count As Integer) As Boolean
        Dim result As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        result = True

        Try
            If ProductCode = "" Then
                strSQL = "select count(*) from [T_Trade] with (nolock) where [TradeStatus]='02'"
            Else
                strSQL = "select count(*) from [T_Trade] with (nolock) where [ProductCode]=@ProductCode and [TradeStatus] in ('02', '10', '12', '13')"
            End If

            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = ProductCode
            Count = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetTradeCancelCount," & ex.Message
            result = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return result
    End Function

    Public Function GetTradeCancelList(ProductCode As String, ByRef ListData As List(Of TradeData)) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        ListData = Nothing

        Result = True
        Try
            ListData = New List(Of TradeData)

            If ProductCode = "" Then
                strSQL = "select * from [T_Trade] with (nolock) where [TradeStatus]='02'"
            Else
                strSQL = "select * from [T_Trade] with (nolock) where [ProductCode]=@ProductCode and [TradeStatus] in ('02', '10', '12', '13')"
            End If
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = ProductCode
            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                Dim item As New TradeData
                item.TradeSeq = GetDbString(Reader.Item("TradeSeq"))
                ListData.Add(item)
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetTradeCancelList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function GetSysDate(ByRef SysDate As DateTime) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        Result = True
        Try
            strSQL = "select SysDate from [S_SysStatus] with ( nolock ) where SysCode = '0'"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Prepare()
            SysDate = CmdDB.ExecuteScalar()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSysDate," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function GetProductOpType(ByVal ProductBaseCode As String, ByRef OpType As String) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        Result = True
        Try
            strSQL = "select OpType from [M_ProductBase] with ( nolock ) where ProductBaseCode = @ProductBaseCode"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = ProductBaseCode
            CmdDB.Prepare()
            OpType = CmdDB.ExecuteScalar()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetProductOpType," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function GetProductChangeSpreadList(SysDate As DateTime, ProductBaseCode As String, MargineTime As Integer, ListData As List(Of ProductData)) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        Result = True
        Try
            strSQL = "select * from M_Product with ( nolock ) where SysDate = @SysDate and ProductBaseCode = @ProductBaseCode and DATEDIFF(second, SYSUTCDATETIME(), StartTime) > @MargineTime order by StartTime"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = ProductBaseCode
            CmdDB.Parameters.Add("@MargineTime", SqlDbType.Int).Value = MargineTime
            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                Dim Product As New ProductData
                Product.ProductCode = Reader.Item("ProductCode")
                Product.StartTime = Reader.Item("StartTime")
                ListData.Add(Product)
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetProductChangeSpreadList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function GetProductAnyTimeChangeSpreadList(SysDate As DateTime, ProductBaseCode As String, MargineTime As Integer, ListData As List(Of ProductData)) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        Result = True
        Try
            strSQL = "select * from M_Product with ( nolock ) where SysDate = @SysDate and ProductBaseCode = @ProductBaseCode order by StartTime"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = ProductBaseCode
            CmdDB.Parameters.Add("@MargineTime", SqlDbType.Int).Value = MargineTime
            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                Dim Product As New ProductData
                Product.ProductCode = Reader.Item("ProductCode")
                Product.StartTime = Reader.Item("StartTime")
                ListData.Add(Product)
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetProductAnyTimeChangeSpreadList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function GetProductChangeTradeMoneyList(SysDate As DateTime, ProductBaseCode As String, ListData As List(Of ProductData)) As Boolean
        Dim CmdDB As SqlCommand
        Dim Reader As SqlDataReader
        Dim Result As Boolean
        Dim strSQL As String

        Result = True
        Try
            strSQL = "select * from M_Product with ( nolock ) where SysDate = @SysDate and ProductBaseCode = @ProductBaseCode order by StartTime"
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = ProductBaseCode
            CmdDB.Prepare()
            Reader = CmdDB.ExecuteReader()
            While Reader.Read
                Dim Product As New ProductData
                Product.ProductCode = Reader.Item("ProductCode")
                Product.StartTime = Reader.Item("StartTime")
                ListData.Add(Product)
            End While
            Reader.Close()
            Reader = Nothing
            CmdDB = Nothing
            Result = True
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetProductChangeSpreadList," & ex.Message
            Reader = Nothing
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    Public Function UpdateProductSpread(SysDate As DateTime, TaskSeq As String, UserID As String, ProductCode As String, ChangeSpread As Integer) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = My.Resources.SQL_Product_UpdateSpread
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@TaskSeq", SqlDbType.Char, 17).Value = TaskSeq
            CmdDB.Parameters.Add("@UserID", SqlDbType.VarChar, 32).Value = UserID
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = ProductCode
            CmdDB.Parameters.Add("@Spread", SqlDbType.Int).Value = ChangeSpread
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateProductSpread," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function UpdateProductBaseTradeMoney(SysDate As DateTime, TaskSeq As String, UserID As String, ProductBaseCode As String, TradeMoneyMin As Decimal, TradeMoneyMax As Decimal) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = My.Resources.SQL_ProductBase_UpdateTradeMoney
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@TaskSeq", SqlDbType.Char, 17).Value = TaskSeq
            CmdDB.Parameters.Add("@UserID", SqlDbType.VarChar, 32).Value = UserID
            CmdDB.Parameters.Add("@ProductBaseCode", SqlDbType.Char, 17).Value = ProductBaseCode
            CmdDB.Parameters.Add(New SqlParameter("@TradeMoneyMin", SqlDbType.Decimal) With {.Precision = 15, .Scale = 4}) _
                .Value = TradeMoneyMin
            CmdDB.Parameters.Add(New SqlParameter("@TradeMoneyMax", SqlDbType.Decimal) With {.Precision = 15, .Scale = 4}) _
                .Value = TradeMoneyMax
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateProductBaseTradeMoney," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function UpdateProductTradeMoney(SysDate As DateTime, TaskSeq As String, UserID As String, ProductCode As String, TradeMoneyMin As Decimal, TradeMoneyMax As Decimal) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = My.Resources.SQL_Product_UpdateTradeMoney
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@TaskSeq", SqlDbType.Char, 17).Value = TaskSeq
            CmdDB.Parameters.Add("@UserID", SqlDbType.VarChar, 32).Value = UserID
            CmdDB.Parameters.Add("@ProductCode", SqlDbType.Char, 17).Value = ProductCode
            CmdDB.Parameters.Add(New SqlParameter("@TradeMoneyMin", SqlDbType.Decimal) With {.Precision = 15, .Scale = 4}) _
                .Value = TradeMoneyMin
            CmdDB.Parameters.Add(New SqlParameter("@TradeMoneyMax", SqlDbType.Decimal) With {.Precision = 15, .Scale = 4}) _
                .Value = TradeMoneyMax
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateProductBaseTradeMoney," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function InsertOperationHist(SysDate As DateTime, UserID As String, DataType As String, LogType As String, Code As String, LogText As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = "insert into [T_OperationHist] values (SYSUTCDATETIME(), @ProcUser, SYSUTCDATETIME(), @ProcUser, SYSUTCDATETIME(), @SysDate, @UserID, @DataType, @LogType, @Code, @LogText)"
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
            CmdDB.Parameters.Add("@SysDate", SqlDbType.Date).Value = SysDate
            CmdDB.Parameters.Add("@UserID", SqlDbType.VarChar, 32).Value = UserID
            CmdDB.Parameters.Add("@DataType", SqlDbType.Char, 2).Value = DataType
            CmdDB.Parameters.Add("@LogType", SqlDbType.Char, 2).Value = LogType
            CmdDB.Parameters.Add("@Code", SqlDbType.VarChar, 17).Value = Code
            CmdDB.Parameters.Add("@LogText", SqlDbType.VarChar, 2048).Value = LogText
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateProductSpread," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function UpdateSysUpdateSeq() As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = "update [S_SysStatus] set [SysUpdateSeq]=[SysUpdateSeq]+1 where [SysCode]='0'"
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.ExecuteNonQuery()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "UpdateSysUpdateSeq," & ex.Message
            bUpdate = False
            blnError = True
            CmdDB = Nothing
        End Try

        Return bUpdate
    End Function

    Public Function CancelTask(TradeSeq As String) As Boolean
        Dim bUpdate As Boolean
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        bUpdate = True
        strSQL = My.Resources.SQL_Trade_Cancel

        Dim CashCode As String = GetSeqCounterSysDate(SeqCounterCode.Cash)
        Dim CashCode2 As String = GetSeqCounterSysDate(SeqCounterCode.Cash)
        If CashCode <> "" Then
            Try
                CmdDB = New SqlCommand(strSQL, ConnDB)
                CmdDB.CommandTimeout = My.Settings.CommandTimeout
                CmdDB.CommandType = CommandType.Text
                CmdDB.Parameters.Add("@TradeSeq", SqlDbType.Char, 17).Value = TradeSeq
                CmdDB.Parameters.Add("@CashCode", SqlDbType.Char, 17).Value = CashCode
                CmdDB.Parameters.Add("@CashCode2", SqlDbType.Char, 17).Value = CashCode2
                CmdDB.Parameters.Add("@ProcUser", SqlDbType.VarChar, 34).Value = "P:" + My.Settings.ProcessID
                CmdDB.ExecuteNonQuery()
                CmdDB = Nothing
                SystemLog.DBSuccess()
            Catch ex As Exception
                SystemLog.DBError(ex)
                strError = "CancelTask," & ex.Message
                bUpdate = False
                blnError = True
                CmdDB = Nothing
            End Try
        End If

        Return bUpdate
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetSeqCounterSysDate(ByVal CounterCode As String) As String
        Dim NewCounter As String
        Dim CmdDB As SqlCommand
        Dim strSQL As String

        strSQL = "declare @Counter int" & vbCrLf
        strSQL = strSQL & "begin tran" & vbCrLf
        strSQL = strSQL & "select @Counter = [Counter] from [S_Counter] with (updlock) where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "update [S_Counter] set [Counter] = @Counter + 1 where [CounterCode] = @CounterCode" & vbCrLf
        strSQL = strSQL & "select convert(char(8), [SysDate], 112) + replicate('0' ,9 - len(@Counter)) + convert(varchar(9),@Counter) from [S_SysStatus] where [SysCode] = '0'" & vbCrLf
        strSQL = strSQL & "commit tran"

        NewCounter = ""
        Try
            CmdDB = New SqlCommand(strSQL, ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@CounterCode", SqlDbType.Char, 2).Value = CounterCode
            NewCounter = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetSeqCounterSysDate," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return NewCounter
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function CheckWorkDay(ByVal WorkDate As DateTime) As Boolean
        Dim CmdDB As SqlCommand
        Dim Result As Boolean = False
        Dim strSQL As New StringBuilder

        Result = False
        Try
            strSQL.AppendLine("declare @work char(1)")
            strSQL.AppendLine("declare @holiday date")
            strSQL.AppendLine("select @work = [Work] from [M_Weekday] where [WeekDay] = DATEPART(weekday, @workdate)")
            strSQL.AppendLine("if @work = '1'")
            strSQL.AppendLine("begin")
            strSQL.AppendLine("    select @holiday = [Holiday] from [M_Holiday] where [Holiday] = @workdate")
            strSQL.AppendLine("    if @@ROWCOUNT <> 0")
            strSQL.AppendLine("        set @work = '0'")
            strSQL.AppendLine("end")
            strSQL.AppendLine("select @work")
            CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@workdate", SqlDbType.Date).Value = WorkDate
            CmdDB.Prepare()
            Dim work As String = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            If work = "1" Then
                Result = True
            End If
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "CheckWorkDay," & ex.Message
            CmdDB = Nothing
            Result = False
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetNextDate(ByVal WorkDate As DateTime) As DateTime
        Dim CmdDB As SqlCommand
        Dim Result As DateTime
        Dim strSQL As New StringBuilder

        Try
            strSQL.AppendLine("declare @work char(1)")
            strSQL.AppendLine("declare @holiday date")
            strSQL.AppendLine("while 1=1")
            strSQL.AppendLine("begin")
            strSQL.AppendLine("    select @work = [Work] from [M_Weekday] where [WeekDay] = DATEPART(weekday, @workdate)")
            strSQL.AppendLine("    if @work = '1'")
            strSQL.AppendLine("    begin")
            strSQL.AppendLine("        select @holiday = [Holiday] from [M_Holiday] where [Holiday] = @workdate")
            strSQL.AppendLine("        if @@ROWCOUNT = 0")
            strSQL.AppendLine("            break")
            strSQL.AppendLine("    end")
            strSQL.AppendLine("    set @workdate = DATEADD(day, 1, @workdate)")
            strSQL.AppendLine("end")
            strSQL.AppendLine("select @workdate")
            CmdDB = New SqlCommand(strSQL.ToString(), ConnDB)
            CmdDB.CommandTimeout = My.Settings.CommandTimeout
            CmdDB.CommandType = CommandType.Text
            CmdDB.Parameters.Add("@workdate", SqlDbType.Date).Value = WorkDate
            CmdDB.Prepare()
            Result = CmdDB.ExecuteScalar()
            CmdDB = Nothing
            SystemLog.DBSuccess()
        Catch ex As Exception
            SystemLog.DBError(ex)
            strError = "GetNextDate," & ex.Message
            CmdDB = Nothing
            blnError = True
        End Try

        Return Result
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ文字列項目の取得
    '--------------------------------------------------------------------------
    Public Function GetDbString(ByVal obj As Object) As String
        Dim RetVal As String

        If IsDBNull(obj) Then
            RetVal = [String].Empty
        Else
            RetVal = CStr(obj)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    ' ＤＢ数値（Ｉｎｔ）項目の取得
    '--------------------------------------------------------------------------
    Public Function GetDbInt(ByVal obj As Object) As Integer
        Dim RetVal As Integer

        If IsDBNull(obj) Then
            RetVal = 0
        Else
            RetVal = CInt(obj)
        End If

        Return RetVal
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function IsError() As Boolean
        Return blnError
    End Function

    '--------------------------------------------------------------------------
    '
    '--------------------------------------------------------------------------
    Public Function GetErrorMessage() As String
        Dim sErrMsg As String

        blnError = False
        sErrMsg = "DataBase Error:" & strError
        Return sErrMsg

    End Function

End Class
