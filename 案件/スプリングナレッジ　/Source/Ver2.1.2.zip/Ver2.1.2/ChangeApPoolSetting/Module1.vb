﻿Imports Microsoft.Web.Administration

Module Module1

    Sub Main(CmdArgs() As String)


        Dim appName As String = My.Settings.AppName
        Dim updTimeStr As String = ""

        If CmdArgs.Count > 0 Then
            updTimeStr = CmdArgs(0)
        Else
            Console.WriteLine("")
            Console.WriteLine("定期スケジュールの変更時間を第1引数に入力してください")
            Console.WriteLine("例）10:00:00")

            Exit Sub
        End If

        Dim UpdTime As TimeSpan
        Dim result As Boolean = TimeSpan.TryParse(updTimeStr, UpdTime)

        If result = False Then
            Console.WriteLine("")
            Console.WriteLine("第1引数のフォーマットが不正です。")
            Console.WriteLine("例）10:00:00")

            Exit Sub
        End If

        Dim serverManager As ServerManager = New ServerManager
        Dim config As Configuration = serverManager.GetApplicationHostConfiguration
        Dim applicationPoolsSection As ConfigurationSection = config.GetSection("system.applicationHost/applicationPools")

        'Clear
        Dim applicationPoolsCollection As ConfigurationElementCollection = applicationPoolsSection.GetCollection

        For Each element As ConfigurationElement In applicationPoolsCollection
            Dim appool As ConfigurationAttribute = element.GetAttribute("name")

            If appool.Value = appName Then

                ' 既存スケジュールのクリア
                Dim recyclingElement As ConfigurationElement = element.GetChildElement("recycling")
                Dim periodicRestartElement As ConfigurationElement = recyclingElement.GetChildElement("periodicRestart")
                Dim scheduleCollection As ConfigurationElementCollection = periodicRestartElement.GetCollection("schedule")
                scheduleCollection.Clear()

                ' 新スケジュールを設定
                Dim addElement As ConfigurationElement = scheduleCollection.CreateElement("add")
                addElement("value") = UpdTime
                scheduleCollection.Add(addElement)
                applicationPoolsCollection.Add(addElement)

                serverManager.CommitChanges()

                Exit For
            End If
        Next
    End Sub


    Private Sub DetailConsoleView(ByVal applicationPoolsSection As ConfigurationSection)

        Dim DelCollection As ConfigurationElementCollection = applicationPoolsSection.GetCollection

        Console.WriteLine("-----------------------------------")
        Console.WriteLine("test")
        Console.WriteLine("Section数:" & DelCollection.Count)

        For Each element As ConfigurationElement In DelCollection

            Console.WriteLine("↓↓　親　↓↓")
            Console.WriteLine(element.ToString())
            Console.WriteLine(element)

            Console.WriteLine("　　子Element数:" & element.ChildElements.Count)
            For Each cElement In element.ChildElements

                Console.WriteLine("　　↓↓　子　↓↓")
                Console.WriteLine("　　" & cElement.ToString)
                Console.WriteLine("　　↑↑　子　↑↑")

                Console.WriteLine("　　　　孫Element数:" & cElement.ChildElements.Count)
                For Each mElement In cElement.ChildElements
                    Console.WriteLine("　　　　↓↓　孫　↓↓")
                    Console.WriteLine("　　　　" & mElement.ToString)
                    Console.WriteLine("　　　　↑↑　孫　↑↑")
                Next

            Next

            Console.WriteLine("↑↑　親　↑↑")
        Next
    End Sub

End Module
