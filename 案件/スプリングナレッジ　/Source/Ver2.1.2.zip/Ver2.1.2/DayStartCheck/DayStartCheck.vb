﻿Module DayStartCheck

    Sub Main()
        SystemLog.InitConsoleApp()
        SystemLog.Information("Start")

        Dim WeekdayCheck As Boolean
        Dim HolidayCheck As Boolean

        '処理実行可否チェック
        If Not DayStart.SystemCheck(WeekdayCheck, HolidayCheck) Then
            Exit Sub
        End If
        If Not (WeekdayCheck And HolidayCheck) Then
            SystemLog.Information(String.Format("日次開始処理実行不可 曜日:{1} 休日:{2}", WeekdayCheck, HolidayCheck))
            Exit Sub
        End If

        'システム営業日開始チェック
        Dim Failed As Boolean = False
        Dim NowDate As DateTime
        Dim SysDate As DateTime
        Dim ProductCount As Integer
        If Not DayStart.DayStartCheck(NowDate, SysDate, ProductCount) Then
            Exit Sub
        End If

        If NowDate <> SysDate Then
            Failed = True
            SystemLog.Information(String.Format("システム営業日相違 現在日付:{0:yyyy/MM/dd} システム営業日:{1:yyyy/MM/dd}", NowDate, SysDate))
        End If
        If My.Settings.ProductCountCheck Then
            If ProductCount <= 0 Then
                Failed = True
                SystemLog.Information(String.Format("生成された銘柄がありません。 {0}", ProductCount))
            End If
        End If

        If Failed Then
            SystemLog.ErrorRETRY("Run DayStartBatch", "日次開始バッチの実行が必要")
        End If

        SystemLog.Information("End")
    End Sub

End Module
