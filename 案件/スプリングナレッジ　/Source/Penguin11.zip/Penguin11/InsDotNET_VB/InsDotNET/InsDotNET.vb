﻿Imports System.IO
Imports System.Windows.Forms
Imports Microsoft.Win32

Module InsDotNET

    Sub Main(CmdArgs() As String)

        Dim success As Integer = 0
        Try

            ' v4.5.2が入っているかチェック
            success = IsDotNetDetected("v4.5.2", 0)

            ' 入っていなければインストール処理
            If Not success Then
                ' カレントディレクトリを取得
                Dim stCurrentDir As String = System.IO.Directory.GetCurrentDirectory()

                ' .NETインストーラーの完全パスを作成
                Dim exePath As String = stCurrentDir & "\NDP452-KB2901907-x86-x64-AllOS-ENU.exe"

                ' インストールを別プロセスで実行
                Dim insProcess As Process = Process.Start(exePath)
                insProcess.WaitForExit()    ' プロセスの終了待ち

            End If

        Catch ex As Exception
            MessageBox.Show(".NET Framework4.5.2のインストールに失敗しました。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub


    Public Function IsDotNetDetected(ByVal version As String, ByVal service As String) As Boolean
        ' Indicates whether the specified version and service pack of the .NET Framework is installed.
        '
        ' version -- Specify one of these strings for the required .NET Framework version:
        '    "v1.1"          .NET Framework 1.1
        '    "v2.0"          .NET Framework 2.0
        '    "v3.0"          .NET Framework 3.0
        '    "v3.5"          .NET Framework 3.5
        '    "v4\Client"     .NET Framework 4.0 Client Profile
        '    "v4\Full"       .NET Framework 4.0 Full Installation
        '    "v4.5"          .NET Framework 4.5
        '    "v4.5.1"        .NET Framework 4.5.1
        '    "v4.5.2"        .NET Framework 4.5.2
        '    "v4.6"          .NET Framework 4.6
        '    "v4.6.1"        .NET Framework 4.6.1
        '    "v4.6.2"        .NET Framework 4.6.2
        '    "v4.7"          .NET Framework 4.7
        '    "v4.7.1"        .NET Framework 4.7.1
        '
        ' service -- Specify any non-negative integer for the required service pack level:
        '    0               No service packs required
        '    1, 2, etc.      Service pack 1, 2, etc. required

        Dim success As Boolean = False

        Dim versionKey As String = version
        Dim versionRelease As Integer = 0

        ' .NET 1.1 and 2.0 embed release number in version key
        If version = "v1.1" Then
            versionKey = "v1.1.4322"

        ElseIf version = "v2.0" Then
            versionKey = "v2.0.50727"


        ElseIf version.Contains("v4.") Then
            ' .NET 4.5 and newer install as update to .NET 4.0 Full

            versionKey = "v4\Full"

            Select Case version
                Case "v4.5"
                    versionRelease = 378389
                Case "v4.5.1"
                    versionRelease = 378675 ' 378758 on Windows 8 and older
                Case "v4.5.2"
                    versionRelease = 379893
                Case "v4.6"
                    versionRelease = 393295 ' 393297 on Windows 8.1 and older
                Case "v4.6.1"
                    versionRelease = 394254 ' 394271 before Win10 November Update
                Case "v4.6.2"
                    versionRelease = 394802 ' 394806 before Win10 Anniversary Update
                Case "v4.7"
                    versionRelease = 460798 ' 460805 before Win10 Creators Update
                Case "v4.7.1"
                    versionRelease = 461308 ' 461310 before Win10 Fall Creators Update
            End Select
        End If

        ' Installation key group for all .NET versions
        Dim key As String = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\" & versionKey

        ' .NET 3.0 uses value InstallSuccess in subkey Setup
        Dim installFlg As Object = Nothing
        If version.Contains("v3.0") Then
            success = GetRegValue(key & "\Setup", "InstallSuccess", installFlg)
        Else
            success = GetRegValue(key, "Install", installFlg)
        End If

        ' .NET 4.0 and newer use value Servicing of SP
        Dim serviceCount As Object = Nothing
        If version.Contains("v4") Then
            success = success And GetRegValue(key, "Servicing", serviceCount)
        Else
            success = success And GetRegValue(key, "SP", serviceCount)
        End If

        ' .NET 4.5 and newer use additional value Release
        If versionRelease > 0 Then
            Dim release As Object = Nothing
            success = success And GetRegValue(key, "Release", release)
            success = success And (release >= versionRelease)
        End If

        If success Then
            If installFlg Is Nothing Then
                success = False
            Else
                success = (Integer.Parse(installFlg) = 1)
            End If
        End If

        If success Then
            If serviceCount Is Nothing Then
                success = False
            Else
                success = (Integer.Parse(serviceCount) >= service)
            End If
        End If

        Return success
    End Function

    Public Function GetRegValue(ByVal key As String, ByVal valueName As String, ByRef regValue As Object) As Boolean
        Dim ret As Boolean = True

        regValue = Nothing
        regValue = Registry.GetValue(key, valueName, Nothing)
        If regValue Is Nothing Then
            ret = False
        End If

        Return ret
    End Function


End Module
