using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace ClickOnceRepairTool
{
    class RegConst
    {
        //���W�X�g���̃`�F�b�N
        public static Boolean RegCheck()
        {
            Microsoft.Win32.RegistryKey regkey =
                Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel", false);
            if (regkey == null)
            {
                return true;
            }
            else
            {
                string strInternet = (string)regkey.GetValue("internet","");
                string strTrustedSites = (string)regkey.GetValue("TrustedSites", "");

                regkey.Close();

                if (strInternet == "Enabled" & strTrustedSites == "Enabled" ^ strInternet == "" & strTrustedSites == "" )
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
        }

        //���W�X�g���̏�������
        public static Boolean RegRegist()
        {
            Microsoft.Win32.RegistryKey regkey =
                Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\MICROSOFT\.NETFramework\Security\TrustManager\PromptingLevel", true);

            regkey.SetValue("internet", "Enabled");
            regkey.SetValue("TrustedSites", "Enabled");

            regkey.Close();
           
            return true;
        }
    }
}
