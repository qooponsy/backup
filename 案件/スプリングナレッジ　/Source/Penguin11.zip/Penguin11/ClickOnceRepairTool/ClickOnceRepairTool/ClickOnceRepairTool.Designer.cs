﻿namespace ClickOnceRepairTool
{
    partial class ClickOnceRepairTool
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl2btnRepair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl2Repair = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.chkboxRepair = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl1Exit = new System.Windows.Forms.Panel();
            this.pnl1btnEnd = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pnl3Error = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.btnTbCopy = new System.Windows.Forms.Button();
            this.pnl3btnEnd = new System.Windows.Forms.Button();
            this.tbErrorMsg = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.pnl2Repair.SuspendLayout();
            this.pnl1Exit.SuspendLayout();
            this.pnl3Error.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl2btnRepair
            // 
            this.pnl2btnRepair.Enabled = false;
            this.pnl2btnRepair.Location = new System.Drawing.Point(352, 324);
            this.pnl2btnRepair.Name = "pnl2btnRepair";
            this.pnl2btnRepair.Size = new System.Drawing.Size(85, 35);
            this.pnl2btnRepair.TabIndex = 0;
            this.pnl2btnRepair.Text = "修復";
            this.pnl2btnRepair.UseVisualStyleBackColor = true;
            this.pnl2btnRepair.Click += new System.EventHandler(this.pnl2btnRepair_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "（注意事項）";
            // 
            // pnl2Repair
            // 
            this.pnl2Repair.Controls.Add(this.label19);
            this.pnl2Repair.Controls.Add(this.label17);
            this.pnl2Repair.Controls.Add(this.label16);
            this.pnl2Repair.Controls.Add(this.label15);
            this.pnl2Repair.Controls.Add(this.label14);
            this.pnl2Repair.Controls.Add(this.chkboxRepair);
            this.pnl2Repair.Controls.Add(this.label8);
            this.pnl2Repair.Controls.Add(this.label7);
            this.pnl2Repair.Controls.Add(this.label6);
            this.pnl2Repair.Controls.Add(this.label5);
            this.pnl2Repair.Controls.Add(this.label4);
            this.pnl2Repair.Controls.Add(this.label3);
            this.pnl2Repair.Controls.Add(this.label2);
            this.pnl2Repair.Controls.Add(this.label1);
            this.pnl2Repair.Controls.Add(this.pnl2btnRepair);
            this.pnl2Repair.Location = new System.Drawing.Point(1, 1);
            this.pnl2Repair.Name = "pnl2Repair";
            this.pnl2Repair.Size = new System.Drawing.Size(452, 371);
            this.pnl2Repair.TabIndex = 2;
            this.pnl2Repair.Visible = false;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(12, 272);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(425, 45);
            this.label19.TabIndex = 15;
            this.label19.Text = "このツールで修復を行うためには管理者として実行する必要があります。\r\n管理者として実行していない場合はツールを終了させ、ツールの実行ファイルの右クリックで表示され" +
                "るメニューから\"管理者として実行(A)\"をクリックしてください。";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 185);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(157, 12);
            this.label17.TabIndex = 13;
            this.label17.Text = "①重要なファイル等のバックアップ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(74, 125);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(115, 12);
            this.label16.TabIndex = 12;
            this.label16.Text = "Internet, TrustedSites";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 125);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "（サブキー）";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 80);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 12);
            this.label14.TabIndex = 10;
            this.label14.Text = "（キー）";
            // 
            // chkboxRepair
            // 
            this.chkboxRepair.AutoSize = true;
            this.chkboxRepair.Location = new System.Drawing.Point(29, 334);
            this.chkboxRepair.Name = "chkboxRepair";
            this.chkboxRepair.Size = new System.Drawing.Size(225, 16);
            this.chkboxRepair.TabIndex = 9;
            this.chkboxRepair.Text = "　上記対応を行い修復の準備ができました";
            this.chkboxRepair.UseVisualStyleBackColor = true;
            this.chkboxRepair.CheckedChanged += new System.EventHandler(this.chkboxRepair_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 248);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(258, 12);
            this.label8.TabIndex = 8;
            this.label8.Text = "④バッテリーで稼動している場合はACアダプターと接続";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 227);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 12);
            this.label7.TabIndex = 7;
            this.label7.Text = "③他のアプリケーションを全て閉じる";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 12);
            this.label6.TabIndex = 6;
            this.label6.Text = "②セキュリティソフトの検査を一時中止";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(12, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(425, 26);
            this.label5.TabIndex = 5;
            this.label5.Text = "レジストリ修復中に、給電停止などでツールの処理が中断する場合、Windowsが起動しなくなる可能性があります。修復ボタンを押す前に下記の対応をお願いします。";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(12, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(425, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "\\HKEY_LOCAL_MACHINE\\SOFTWARE\\MICROSOFT\\.NETFramework\\Security\\TrustManager\\Prompt" +
                "ingLevel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(293, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "修復では下記のレジストリのサブキーをEnabledに変更します。";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(425, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "このツールはWindows10のWindowsUpdateの不具合などで、ClickOnceアプリをインストールできなくなる状態を修復します（Windows10以" +
                "外では実行しないでください。）";
            // 
            // pnl1Exit
            // 
            this.pnl1Exit.Controls.Add(this.pnl1btnEnd);
            this.pnl1Exit.Controls.Add(this.label10);
            this.pnl1Exit.Controls.Add(this.label9);
            this.pnl1Exit.Location = new System.Drawing.Point(1, 1);
            this.pnl1Exit.Name = "pnl1Exit";
            this.pnl1Exit.Size = new System.Drawing.Size(452, 371);
            this.pnl1Exit.TabIndex = 3;
            this.pnl1Exit.Visible = false;
            // 
            // pnl1btnEnd
            // 
            this.pnl1btnEnd.Location = new System.Drawing.Point(352, 324);
            this.pnl1btnEnd.Name = "pnl1btnEnd";
            this.pnl1btnEnd.Size = new System.Drawing.Size(85, 35);
            this.pnl1btnEnd.TabIndex = 2;
            this.pnl1btnEnd.Text = "終了";
            this.pnl1btnEnd.UseVisualStyleBackColor = true;
            this.pnl1btnEnd.Click += new System.EventHandler(this.pnl1btnEnd_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(152, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "ツールの実行を終了してください";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(270, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "お使いの端末のClickOnce動作環境は問題ありません。";
            // 
            // pnl3Error
            // 
            this.pnl3Error.Controls.Add(this.label20);
            this.pnl3Error.Controls.Add(this.btnTbCopy);
            this.pnl3Error.Controls.Add(this.pnl3btnEnd);
            this.pnl3Error.Controls.Add(this.tbErrorMsg);
            this.pnl3Error.Controls.Add(this.label11);
            this.pnl3Error.Location = new System.Drawing.Point(1, 1);
            this.pnl3Error.Name = "pnl3Error";
            this.pnl3Error.Size = new System.Drawing.Size(452, 371);
            this.pnl3Error.TabIndex = 3;
            this.pnl3Error.Visible = false;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(12, 175);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(424, 45);
            this.label20.TabIndex = 4;
            this.label20.Text = "\"要求されたレジストリアクセスは許可されていません。\"と表示される場合は、\r\n管理者として実行されていない可能性があります。ツールを終了させた後に、ツールの実行フ" +
                "ァイルの右クリックで表示されるメニューから\"管理者として実行(A)\"をクリックしてください。";
            // 
            // btnTbCopy
            // 
            this.btnTbCopy.Location = new System.Drawing.Point(12, 223);
            this.btnTbCopy.Name = "btnTbCopy";
            this.btnTbCopy.Size = new System.Drawing.Size(178, 35);
            this.btnTbCopy.TabIndex = 3;
            this.btnTbCopy.Text = "失敗理由をコピー";
            this.btnTbCopy.UseVisualStyleBackColor = true;
            this.btnTbCopy.Click += new System.EventHandler(this.btnTbCopy_Click);
            // 
            // pnl3btnEnd
            // 
            this.pnl3btnEnd.Location = new System.Drawing.Point(352, 324);
            this.pnl3btnEnd.Name = "pnl3btnEnd";
            this.pnl3btnEnd.Size = new System.Drawing.Size(85, 35);
            this.pnl3btnEnd.TabIndex = 2;
            this.pnl3btnEnd.Text = "終了";
            this.pnl3btnEnd.UseVisualStyleBackColor = true;
            this.pnl3btnEnd.Click += new System.EventHandler(this.pnl3btnEnd_Click);
            // 
            // tbErrorMsg
            // 
            this.tbErrorMsg.BackColor = System.Drawing.Color.White;
            this.tbErrorMsg.Location = new System.Drawing.Point(12, 37);
            this.tbErrorMsg.Multiline = true;
            this.tbErrorMsg.Name = "tbErrorMsg";
            this.tbErrorMsg.ReadOnly = true;
            this.tbErrorMsg.Size = new System.Drawing.Size(424, 125);
            this.tbErrorMsg.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(376, 12);
            this.label11.TabIndex = 0;
            this.label11.Text = "ClickOnce動作環境の修復に失敗しました。修復失敗理由をメールしてください";
            // 
            // ClickOnceRepairTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 373);
            this.Controls.Add(this.pnl3Error);
            this.Controls.Add(this.pnl1Exit);
            this.Controls.Add(this.pnl2Repair);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ClickOnceRepairTool";
            this.Text = "ClickOnce動作環境修復ツール（Windows10用）";
            this.pnl2Repair.ResumeLayout(false);
            this.pnl2Repair.PerformLayout();
            this.pnl1Exit.ResumeLayout(false);
            this.pnl1Exit.PerformLayout();
            this.pnl3Error.ResumeLayout(false);
            this.pnl3Error.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pnl2btnRepair;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl2Repair;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox chkboxRepair;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnl1Exit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnl3Error;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnTbCopy;
        private System.Windows.Forms.Button pnl3btnEnd;
        private System.Windows.Forms.TextBox tbErrorMsg;
        private System.Windows.Forms.Button pnl1btnEnd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label20;

    }
}

