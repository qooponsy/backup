using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ClickOnceRepairTool
{
    public partial class ClickOnceRepairTool : Form
    {
        Boolean RegCheckFlg;
        Boolean RegRegistFlg;          

        public ClickOnceRepairTool()
        {
            InitializeComponent();

            RegCheckFlg = RegConst.RegCheck();

            if (RegCheckFlg == true)
            {
                //���Ȃ��̉�ʂ�\��
                pnl1Exit.Visible = true;
            }
            else
            {
                //�C���J�n��ʂ�\��
                pnl2Repair.Visible = true;
            }

        }

        //�C���J�n��ʂ�[�C��]�{�^��
        private void pnl2btnRepair_Click(object sender, EventArgs e)
        {
            try
            {
                RegRegistFlg = RegConst.RegRegist();
            }
            catch (System.Exception ex)
            {
                RegRegistFlg = false;
                tbErrorMsg.Text = ex.Message;
            }

            if (RegRegistFlg == true)            
            {
                //�C���J�n��ʂ��\��
                pnl2Repair.Visible = false;
                //���Ȃ��̉�ʂ̕\��
                pnl1Exit.Visible = true;
            }            
            else
            {
                //�C���J�n��ʂ��\��
                pnl2Repair.Visible = false;
                //�C�����s��ʂ̕\��
                pnl3Error.Visible = true;
            }            
        }
           
        //���Ȃ��̉�ʂ̏I���{�^��
        private void pnl1btnEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //�C�����s��ʂ̏I���{�^��
        private void pnl3btnEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //�C���J�n��ʂ̃`�F�b�N�{�b�N�X
        private void chkboxRepair_CheckedChanged(object sender, EventArgs e)
        {
            if (chkboxRepair.Checked == true)
            {
                pnl2btnRepair.Enabled = true;
            }
            else
            {
                pnl2btnRepair.Enabled = false;
            }

        }
        //���s���R�̃R�s�[
        private void btnTbCopy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(tbErrorMsg.Text);
        }
    }
}