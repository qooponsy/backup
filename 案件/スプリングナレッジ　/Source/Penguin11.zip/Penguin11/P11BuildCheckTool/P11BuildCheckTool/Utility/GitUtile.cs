﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    public class GitUtile
    {
        public static string GitPath;
        public static string RepositoryPath;

        public static string ErrMsg;

        public static bool Init()
        {
            var success = true;

            try
            {
                // git情報ファイルを読み込み
                success = GetGitConfigFile();
                if (success)
                {
                    // 取得した情報が正しいか確認
                    success = CheckGitConfig();
                }


            }
            catch
            {
                success = false;
            }

            if(!success)
            {
                ErrMsg = "git情報ファイルの読み込みに失敗しました。";
            }

            return success;
        }

        private static bool GetGitConfigFile()
        {
            var ret = true;

            var textList = new List<string>();

            using (var reader = new StreamReader(CommonItem.GIT_CONFIG_FILE, Encoding.GetEncoding("Shift_JIS")))
            {

                while (reader.Peek() >= 0)
                {
                    var line = reader.ReadLine();
                    var lines = line.Split('>');

                    switch (lines[0])
                    {
                        case "git.exeの絶対パス":
                            GitPath = lines[1];
                            break;
                        case "リポジトリーパス":
                            RepositoryPath = lines[1];
                            break;
                        default:
                            ret = false;
                            break;
                    }

                    if (!ret) break;
                }

            }

            return ret;
        }

        public static bool CheckGitConfig()
        {
            var success = true;

            try
            {
                gitCommand($@"-C {RepositoryPath} --version");
            }
            catch
            {
                success = false;
            }

            return success;

        }

        public static bool GetBranchName(ref string branchName)
        {
            var success = true;

            try
            {
                var fullName = gitCommand($@"-C {RepositoryPath} branch --contains");
                branchName = fullName.Substring(2);
            }
            catch(Exception ex)
            {
                success = false;
                ErrMsg = ex.Message;
            }

            return success;
        }

        public static bool GetBranchHashValue(ref string BranchHashValue)
        {
            var success = true;

            try
            {
                var full = gitCommand($@"-C {RepositoryPath} rev-parse HEAD");
                BranchHashValue = full.Substring(0, CommonItem.GIT_HASH_CHECK_LINGTH);
            }
            catch(Exception ex)
            {
                success = false;
                ErrMsg = ex.Message;
            }

            return success;
        }

        private static int ExecuteCommand(ref string result,string command, string arguments = "")
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo(command)
                {
                    Arguments = arguments,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                }
            };
            process.Start();
            result = process.StandardOutput.ReadToEnd();
            process.WaitForExit();

            return process.ExitCode;
        }

        static string gitCommand(string arguments)
        {
            var result = "";
            if (ExecuteCommand(ref result,GitPath, arguments) != 0)
            {
                throw new Exception("git command error");
            }

            return result;
        }


    }
}
