﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    class ZipFileUtile
    {

        public static string ErrMsg;

        public static bool Init()
        {
            var success = true;

            try
            {

            }
            catch
            {
                success = false;
            }

            if (!success)
            {
                ErrMsg = "デプロイ構成設定ファイルの読み込みに失敗しました。";
            }

            return success;
        }

        public static bool DecompressionZipFile(string zipFilePath)
        {
            var success = true;

            try
            {
                // 解凍先のフォルダを作成
                var folerName = CommonItem.DECOMPRESSION_FOLDER_NAME;
                if (Directory.Exists(folerName)){
                    // 前回のフォルダが残っていれば削除
                    DeleteFolder(folerName);
                }
                Directory.CreateDirectory(folerName);

                // 圧縮ファイルの解凍
                ZipFile.ExtractToDirectory(zipFilePath, folerName);

            }
            catch
            {
                success = false;
                ErrMsg = "zipファイルの解凍に失敗しました。";
            }

            return success;
        }
        
        public static void DeleteFolder(string deleteFolderPath)
        {
            // ディレクトリ内のフォルダを全て削除
            string[] filePaths = Directory.GetFiles(deleteFolderPath);
            foreach (string filePath in filePaths)
            {
                File.SetAttributes(filePath, FileAttributes.Normal);
                File.Delete(filePath);
            }

            // ディレクトリ内のディレクトリも再帰的に削除
            string[] dirPaths = Directory.GetDirectories(deleteFolderPath);
            foreach(string dirPath in dirPaths)
            {
                DeleteFolder(dirPath);
            }

            // 全て削除したらディレクトリ自身を削除
            Directory.Delete(deleteFolderPath);
        }

        public static string GetDecompressionFolderName()
        {
            var fName = "";

            var folders = Directory.GetDirectories(CommonItem.DECOMPRESSION_FOLDER_NAME);
            fName = folders[0];

            return fName;
        }

        private static string ReduceSpace(string value)
        {
            var newString = new StringBuilder();
            bool previousIsWhitespace = false;
            for (int i = 0; i < value.Length; i++)
            {
                if (Char.IsWhiteSpace(value[i]))
                {
                    if (previousIsWhitespace)
                    {
                        continue;
                    }

                    previousIsWhitespace = true;
                }
                else
                {
                    previousIsWhitespace = false;
                }

                newString.Append(value[i]);
            }

            return newString.ToString();
        }


    }
}
