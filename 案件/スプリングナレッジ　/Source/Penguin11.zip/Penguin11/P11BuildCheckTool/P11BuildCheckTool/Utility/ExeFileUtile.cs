﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    class ExeFileUtile
    {

        public static string ErrMsg;

        public string AppVersion;
        public long FileSize;
        public DateTime FileDateTime;

        public static bool RetrieveLinkerTimestamp(string exeFilePath, ref string fileVersionTime)
        {
            var success = true;

            const int c_PeHeaderOffset = 60;
            const int c_LinkerTimestampOffset = 8;
            byte[] b = new byte[2048];
            Stream s = null;

            try
            {
                using(s = new FileStream(exeFilePath,FileMode.Open, FileAccess.Read))
                {
                    s.Read(b, 0, 2048);
                }

                int i = System.BitConverter.ToInt32(b, c_PeHeaderOffset);
                int secondsSince1970 = System.BitConverter.ToInt32(b, i + c_LinkerTimestampOffset);
                var dt = new DateTime(1970, 1, 1, 0, 0, 0);
                dt = dt.AddSeconds(secondsSince1970);
                dt = dt.AddHours(TimeZone.CurrentTimeZone.GetUtcOffset(dt).Hours);

                fileVersionTime = dt.ToString(CommonItem.DISPLAY_DATETIME_FORMAT);
            }
            catch
            {
                success = false;
            }
            finally
            {
                if (s != null)
                {
                    s.Close();
                }
            }
            
            return success;
        }


        public static bool UnpackerInstaller(string installerPath, string unpackPath)
        {
            var success = true;

            try
            {

                var process = new Process();

                // 実行ファイル
                process.StartInfo.FileName = "innounp.exe";

                // 結果出力をtrueに
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardInput = false;

                // ウィンドウを非表示に
                process.StartInfo.CreateNoWindow = true;

                // コマンドラインを指定
                process.StartInfo.Arguments = $@"-e -d{unpackPath} {installerPath}";

                process.Start();

                // 終了まで待機
                process.WaitForExit();
                var a = process.ExitCode.ToString();

                process.Close();


            }
            catch
            {
                success = false;
                ErrMsg = "インストーラーの展開に失敗しました。";
            }

            return success;
        }

        public static bool GetFileInfo(string filePath, ref ExeFileUtile item)
        {
            var success = true;

            try
            {

                var vi = FileVersionInfo.GetVersionInfo(filePath);
                var fi = new FileInfo(filePath);

                // アプリケーションバージョン
                item.AppVersion = vi.FileVersion;

                // ファイルサイズ
                item.FileSize = fi.Length;

                // ファイル更新日時
                item.FileDateTime = fi.LastWriteTime;

            }
            catch
            {
                success = false;
            }

            return success;
        }

    }
}
