﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    class BuildFolderUtile
    {
        public static string ErrMsg;

        
        public static bool Init()
        {
            var success = true;

            try
            {

            }
            catch
            {
                success = false;
            }

            if (!success)
            {
                ErrMsg = "ビルドフォルダの参照でエラーが発生しました。";
            }

            return success;
        }

        public static void CheckLogTextFile(string logPath, ref CheckItem.CheckCode result, ref StringBuilder ErrMsg)
        {

            var success = true;

            try
            {
                string logText = "";
                string logFilePath = logPath + @"\" + CommonItem.BUILD_LOG_FILE_NAME;
                using (var reader = new StreamReader(logFilePath, Encoding.GetEncoding("shift_jis")))
                {
                    // ログ情報を全て取得
                    logText = reader.ReadToEnd();
                }

                // ログ内にエラー文字列が含まれているかチェック
                if (logText.Contains(CommonItem.LOG_FAILURE_TEXT))
                {
                    result = CheckItem.CheckCode.Failure;
                }
                else
                {
                    result = CheckItem.CheckCode.Success;
                }

            }
            catch
            {
                success = false;
            }

            if (!success)
            {
                ErrMsg.AppendLine("ログファイルの取得に失敗しました。");
            }

        }

        public static void CheckLogTimeFile(string filePath, ref DateTime buildTime ,ref StringBuilder ErrMsg)
        {
            var success = true;

            try
            {

                var buildTimeStr = "";
                var buildTimeFilePath = filePath + @"\" + CommonItem.BUILD_TIME_FILE_NAME;
                using(var reader = new StreamReader(buildTimeFilePath,Encoding.GetEncoding("shift_jis")))
                {
                    buildTimeStr = reader.ReadLine();
                }

                buildTime = DateTime.Parse(buildTimeStr);

            }
            catch
            {
                success = false;
            }

            if (!success)
            {
                ErrMsg.AppendLine("ビルド開始時刻の取得に失敗しました。");
            }
        }

        public static bool GetModuleFolderPath(ref string buildPath, CommonItem.VersionCode verCode)
        {
            var success = true;

            try
            {
                // バージョンフォルダ名を取得
                var versionFolder = "";
                success = GetVersionFolderName(buildPath, ref versionFolder, verCode);

                
                if (success)
                {
                    buildPath = buildPath + @"\" + versionFolder;
                }
                else
                {
                    success = false;
                }
            }
            catch
            {
                success = false;
            }

            if (!success)
            {
                ErrMsg = "ビルドフォルダの参照でエラーが発生しました。";
            }

            return success;
        }

        ////////////////////////
        // 未使用
        private static bool GetTrueVersionFolderName(string buildPath,ref string folderName)
        {
            var success = true;

            try
            {
                // バージョンが一番低いフォルダーを正とする
                var versionFolders = Directory.GetDirectories(buildPath);

                var list = new List<string[]>();
                foreach(var versionStr in versionFolders)
                {
                    var endFolder = Path.GetFileName(versionStr);
                    var versionArray = endFolder.Split('_');
                    list.Add(versionArray);
                }

                string[] trueVersion = null;
                foreach(var versionArray in list)
                {
                    if(trueVersion == null)
                    {
                        trueVersion = versionArray;
                        continue;
                    }

                    for(var i = 0; i < 4; i++)
                    {
                        var judge = string.Compare(trueVersion[i], versionArray[i]);
                        if (judge > 0)
                        {
                            trueVersion = versionArray;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }

                    var versionName = new StringBuilder();
                    var ub = "";
                    foreach(var v in trueVersion)
                    {
                        versionName.Append(ub);
                        versionName.Append(v.ToString());
                        ub = "_";
                    }

                    folderName = versionName.ToString();
                } 

            }
            catch
            {
                success = false;
                ErrMsg = "バージョンフォルダの参照でエラーが発生しました。";
            }

            return success;
        }

        private static bool GetVersionFolderName(string buildPath, ref string folderName, CommonItem.VersionCode verCode)
        {
            var success = true;

            try
            {
                var versionFolders = Directory.GetDirectories(buildPath);

                var list = new List<string[]>();
                foreach (var versionStr in versionFolders)
                {
                    var endFolder = Path.GetFileName(versionStr);
                    var versionArray = endFolder.Split('_');
                    list.Add(versionArray);
                }

                string[] tempArray1 = list[0];
                string[] tempArray2 = list[1];

                string[] trueVersion = null;

                if(verCode == CommonItem.VersionCode.Normal)
                {
                    // 通常の場合は低いバージョンを使用
                    for (var i = 0; i < 4; i++)
                    {
                        var judge = string.Compare(tempArray1[i], tempArray2[i]);
                        if (judge > 0)
                        {
                            trueVersion = tempArray2;
                            break;
                        }
                        else if(judge < 0)
                        {
                            trueVersion = tempArray1;
                            break;
                        }
                    }
                }
                else
                {
                    // 誤検知の場合は高いバージョンを使用
                    for (var i = 0; i < 4; i++)
                    {
                        var judge = string.Compare(tempArray1[i], tempArray2[i]);
                        if (judge > 0)
                        {
                            trueVersion = tempArray1;
                            break;
                        }
                        else if (judge < 0)
                        {
                            trueVersion = tempArray2;
                            break;
                        }
                    }
                }

                if(trueVersion == null)
                {
                    success = false;
                    ErrMsg = "バージョンフォルダの参照でエラーが発生しました。";
                }
                else
                {
                    var versionName = new StringBuilder();
                    var ub = "";
                    foreach (var v in trueVersion)
                    {
                        versionName.Append(ub);
                        versionName.Append(v.ToString());
                        ub = "_";
                    }

                    folderName = versionName.ToString();

                }

            }
            catch
            {
                success = false;
                ErrMsg = "バージョンフォルダの参照でエラーが発生しました。";
            }

            return success;
        }

    }
}
