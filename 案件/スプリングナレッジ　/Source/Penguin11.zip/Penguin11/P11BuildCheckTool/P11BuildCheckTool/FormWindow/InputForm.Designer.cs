﻿namespace P11BuildCheckTool
{
    partial class InputForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Label2 = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.Label5 = new System.Windows.Forms.Label();
            this.btnDeliveryFilePath = new System.Windows.Forms.Button();
            this.btnBuildFolderPath = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.rbEnvDemo = new System.Windows.Forms.RadioButton();
            this.rbEnvProduct = new System.Windows.Forms.RadioButton();
            this.tbBranchName = new System.Windows.Forms.TextBox();
            this.tbDeliveryFilePath = new System.Windows.Forms.TextBox();
            this.tbBuildFolderPath = new System.Windows.Forms.TextBox();
            this.tbBranchHashValue = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.ttHint = new System.Windows.Forms.ToolTip(this.components);
            this.rbEnvStaging = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbVerMissDetection = new System.Windows.Forms.RadioButton();
            this.rbVerNormal = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(53, 111);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(29, 12);
            this.Label2.TabIndex = 35;
            this.Label2.Text = "環境";
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(154, 167);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 34;
            this.btnRun.Text = "実行";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(19, 80);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(63, 12);
            this.Label5.TabIndex = 33;
            this.Label5.Text = "納品ファイル";
            // 
            // btnDeliveryFilePath
            // 
            this.btnDeliveryFilePath.Location = new System.Drawing.Point(305, 75);
            this.btnDeliveryFilePath.Name = "btnDeliveryFilePath";
            this.btnDeliveryFilePath.Size = new System.Drawing.Size(42, 23);
            this.btnDeliveryFilePath.TabIndex = 31;
            this.btnDeliveryFilePath.Text = "参照";
            this.btnDeliveryFilePath.UseVisualStyleBackColor = true;
            this.btnDeliveryFilePath.Click += new System.EventHandler(this.btnDeliveryFilePath_Click);
            // 
            // btnBuildFolderPath
            // 
            this.btnBuildFolderPath.Location = new System.Drawing.Point(305, 50);
            this.btnBuildFolderPath.Name = "btnBuildFolderPath";
            this.btnBuildFolderPath.Size = new System.Drawing.Size(42, 23);
            this.btnBuildFolderPath.TabIndex = 32;
            this.btnBuildFolderPath.Text = "参照";
            this.btnBuildFolderPath.UseVisualStyleBackColor = true;
            this.btnBuildFolderPath.Click += new System.EventHandler(this.btnBuildFolderPath_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(16, 55);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(67, 12);
            this.Label4.TabIndex = 30;
            this.Label4.Text = "ビルドフォルダ";
            // 
            // rbEnvDemo
            // 
            this.rbEnvDemo.AutoSize = true;
            this.rbEnvDemo.Location = new System.Drawing.Point(59, 11);
            this.rbEnvDemo.Name = "rbEnvDemo";
            this.rbEnvDemo.Size = new System.Drawing.Size(42, 16);
            this.rbEnvDemo.TabIndex = 28;
            this.rbEnvDemo.Text = "デモ";
            this.rbEnvDemo.UseVisualStyleBackColor = true;
            // 
            // rbEnvProduct
            // 
            this.rbEnvProduct.AutoSize = true;
            this.rbEnvProduct.Location = new System.Drawing.Point(6, 11);
            this.rbEnvProduct.Name = "rbEnvProduct";
            this.rbEnvProduct.Size = new System.Drawing.Size(47, 16);
            this.rbEnvProduct.TabIndex = 29;
            this.rbEnvProduct.Text = "本番";
            this.rbEnvProduct.UseVisualStyleBackColor = true;
            // 
            // tbBranchName
            // 
            this.tbBranchName.Location = new System.Drawing.Point(95, 6);
            this.tbBranchName.Name = "tbBranchName";
            this.tbBranchName.Size = new System.Drawing.Size(252, 19);
            this.tbBranchName.TabIndex = 24;
            // 
            // tbDeliveryFilePath
            // 
            this.tbDeliveryFilePath.Location = new System.Drawing.Point(95, 77);
            this.tbDeliveryFilePath.Name = "tbDeliveryFilePath";
            this.tbDeliveryFilePath.Size = new System.Drawing.Size(204, 19);
            this.tbDeliveryFilePath.TabIndex = 25;
            // 
            // tbBuildFolderPath
            // 
            this.tbBuildFolderPath.Location = new System.Drawing.Point(95, 52);
            this.tbBuildFolderPath.Name = "tbBuildFolderPath";
            this.tbBuildFolderPath.Size = new System.Drawing.Size(204, 19);
            this.tbBuildFolderPath.TabIndex = 26;
            // 
            // tbBranchHashValue
            // 
            this.tbBranchHashValue.Location = new System.Drawing.Point(95, 28);
            this.tbBranchHashValue.Name = "tbBranchHashValue";
            this.tbBranchHashValue.Size = new System.Drawing.Size(252, 19);
            this.tbBranchHashValue.TabIndex = 27;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(12, 9);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(71, 12);
            this.Label3.TabIndex = 22;
            this.Label3.Text = "Git ブランチ名";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(12, 31);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(71, 12);
            this.Label1.TabIndex = 23;
            this.Label1.Text = "Git ハッシュ値";
            // 
            // rbEnvStaging
            // 
            this.rbEnvStaging.AutoSize = true;
            this.rbEnvStaging.Location = new System.Drawing.Point(107, 11);
            this.rbEnvStaging.Name = "rbEnvStaging";
            this.rbEnvStaging.Size = new System.Drawing.Size(79, 16);
            this.rbEnvStaging.TabIndex = 36;
            this.rbEnvStaging.Text = "ステージング";
            this.rbEnvStaging.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 12);
            this.label6.TabIndex = 35;
            this.label6.Text = "バージョン";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbEnvProduct);
            this.groupBox1.Controls.Add(this.rbEnvStaging);
            this.groupBox1.Controls.Add(this.rbEnvDemo);
            this.groupBox1.Location = new System.Drawing.Point(94, 96);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(204, 32);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbVerMissDetection);
            this.groupBox2.Controls.Add(this.rbVerNormal);
            this.groupBox2.Location = new System.Drawing.Point(93, 128);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(204, 32);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            // 
            // rbVerMissDetection
            // 
            this.rbVerMissDetection.AutoSize = true;
            this.rbVerMissDetection.Location = new System.Drawing.Point(60, 10);
            this.rbVerMissDetection.Name = "rbVerMissDetection";
            this.rbVerMissDetection.Size = new System.Drawing.Size(59, 16);
            this.rbVerMissDetection.TabIndex = 29;
            this.rbVerMissDetection.Text = "誤検知";
            this.rbVerMissDetection.UseVisualStyleBackColor = true;
            // 
            // rbVerNormal
            // 
            this.rbVerNormal.AutoSize = true;
            this.rbVerNormal.Location = new System.Drawing.Point(7, 10);
            this.rbVerNormal.Name = "rbVerNormal";
            this.rbVerNormal.Size = new System.Drawing.Size(47, 16);
            this.rbVerNormal.TabIndex = 29;
            this.rbVerNormal.Text = "通常";
            this.rbVerNormal.UseVisualStyleBackColor = true;
            // 
            // InputForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 202);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.btnDeliveryFilePath);
            this.Controls.Add(this.btnBuildFolderPath);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.tbBranchName);
            this.Controls.Add(this.tbDeliveryFilePath);
            this.Controls.Add(this.tbBuildFolderPath);
            this.Controls.Add(this.tbBranchHashValue);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label1);
            this.Name = "InputForm";
            this.Text = "P11 ビルドチェックツール";
            this.Load += new System.EventHandler(this.InputForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button btnRun;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Button btnDeliveryFilePath;
        internal System.Windows.Forms.Button btnBuildFolderPath;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.RadioButton rbEnvDemo;
        internal System.Windows.Forms.RadioButton rbEnvProduct;
        internal System.Windows.Forms.TextBox tbBranchName;
        internal System.Windows.Forms.TextBox tbDeliveryFilePath;
        internal System.Windows.Forms.TextBox tbBuildFolderPath;
        internal System.Windows.Forms.TextBox tbBranchHashValue;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.ToolTip ttHint;
        private System.Windows.Forms.RadioButton rbEnvStaging;
        internal System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.RadioButton rbVerMissDetection;
        internal System.Windows.Forms.RadioButton rbVerNormal;
    }
}

