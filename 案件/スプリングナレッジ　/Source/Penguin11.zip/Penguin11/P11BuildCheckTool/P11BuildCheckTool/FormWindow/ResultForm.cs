﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P11BuildCheckTool.FormWindow
{
    public partial class ResultForm : Form
    {
        public InputItem check { get; set; }

        private CheckItem entire;
        private CheckItem hirose;
        private CheckItem jfx;
        private CheckItem activeFX;

        public ResultForm(InputItem item)
        {
            InitializeComponent();
            this.check = item;
        }

        private void ResultForm_Load(object sender, EventArgs e)
        {
            // ウィンドウ初期処理
            var nowDate = DateTime.Now;
            lblCheckDate.Text = "日付 ： " + nowDate;

            // 初期化処理
            Init();

            // メイン処理
            BuildCheck();

            // 一時フォルダの削除
            var folderName = CommonItem.DECOMPRESSION_FOLDER_NAME;
            if (Directory.Exists(folderName))
            {
                ZipFileUtile. DeleteFolder(folderName);
            }

        }

        private void Init()
        {

            // インプットデータ
            check.EnvName = CommonItem.ConvEnvString(check.Env);

            entire = new CheckItem();

            // ヒロセ初期化
            hirose = new CheckItem();
            hirose.Company = CommonItem.Companys.Hirose;
            InitCompany(ref hirose);

            // JFX初期化
            jfx = new CheckItem();
            jfx.Company = CommonItem.Companys.JFX;
            InitCompany(ref jfx);

            // アクティブFX初期化
            activeFX = new CheckItem();
            activeFX.Company = CommonItem.Companys.ActiveFX;
            InitCompany(ref activeFX);
        }

        private void InitCompany(ref CheckItem item)
        {
            item.CompFolderName = CommonItem.CompFolderList[item.Company];
            item.AppInstallerName = CommonItem.GetAppInstallerName(item.Company, check.Env);
            item.AppFileName = CommonItem.GetAppFileName(item.Company, check.Env);
            item.CompanyName = CommonItem.ConvCompString(item.Company);
        }

        private void BuildCheck()
        {
            var ErrMsg = new StringBuilder();

            // Gitから値を取得
            CheckGitParameter(ref entire, ref ErrMsg);

            // ビルドログの確認
            BuildFolderUtile.CheckLogTextFile(check.BuildFolderPath, ref entire.BuildLogCheck, ref ErrMsg);

            // ビルド時間の取得
            var buildTimeFilePath = check.BuildFolderPath + @"\" + CommonItem.LOG_FOLDER_NAME;
            BuildFolderUtile.CheckLogTimeFile(buildTimeFilePath, ref entire.BuildTime, ref ErrMsg);

            // binフォルダの確認
            CheckBuildFolder(check.BuildFolderPath, ref ErrMsg);

            // zipファイル情報取得
            //   ※解凍に時間がかかるためここまでにエラーがあれば解凍しない
            if (ErrMsg.ToString() == "")
            {
                CheckZipFile(check.DeliveryFolderPath, ref ErrMsg);
            }

            if(ErrMsg.ToString() != "")
            {
                MessageBox.Show(ErrMsg.ToString(),
                    "ビルドチェックエラー",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                    );

            }
            else
            {
                // 入力値のセット
                entire.BranchNameInput = check.BranchName;
                entire.BranchHashValueInput = check.BranchHashValue;

                // 最終結果判定
                entire.JudgeResult();
                hirose.JudgeResult();
                jfx.JudgeResult();
                activeFX.JudgeResult();

                if(entire.result && hirose.result && jfx.result && activeFX.result)
                {
                    MessageBox.Show("全てのチェックが成功となりました。",
                        "ビルドチェック完了",
                        MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("一部または全てのチェックで失敗しました。\n入力値と選択ファイル/フォルダを確認してください。",
                        "ビルドチェック完了",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                }

            }

            // フォームに値をセット
            SetForm();

        }

        private void CheckGitParameter(ref CheckItem entire, ref StringBuilder ErrMsg)
        {
            var success = false;

            // Gitブランチ名
            var BranchName = "";
            success = GitUtile.GetBranchName(ref BranchName);
            if (!success)
            {
                ErrMsg.AppendLine(GitUtile.ErrMsg);
            }

            // Gitハッシュ値
            var BranchHashValue = "";
            success = GitUtile.GetBranchHashValue(ref BranchHashValue);
            if (!success)
            {
                ErrMsg.AppendLine(GitUtile.ErrMsg);
            }

            if (ErrMsg.ToString() == "")
            {
                entire.BranchNameDiff = BranchName.Replace("\n","");    // 改行削除
                entire.BranchHashValueDiff = BranchHashValue;
            }
        }

        private void CheckBuildFolder(string workPath, ref StringBuilder ErrMsg)
        {
            var success = true;

            // exeファイルのパスを取得
            var buildModulePath = workPath + @"\" + CommonItem.BUILD_FOLDER_NAME;
            success = BuildFolderUtile.GetModuleFolderPath(ref buildModulePath, check.Version);
            if (!success)
            {
                ErrMsg.AppendLine(BuildFolderUtile.ErrMsg);
            }

            // ファイルバージョンの取得
            if (success)
            {
                success = GetFileVersionBuild(buildModulePath, ref ErrMsg);
            }

            // ファイル情報の取得
            if (success)
            {
                GetFileInfoBuild(buildModulePath, ref ErrMsg);
            }

        }

        private void CheckZipFile(string zipPath ,ref StringBuilder ErrMsg)
        {
            var success = false;

            // zipファイルの解凍
            success = ZipFileUtile.DecompressionZipFile(zipPath);
            if (!success)
            {
                ErrMsg.AppendLine(ZipFileUtile.ErrMsg);
            }

            // 解凍フォルダ名の取得
            //var decompressionFolderName = "";
            var moduleFolder = "";
            if (success)
            {
                var decompressionFolderName = ZipFileUtile.GetDecompressionFolderName();
                moduleFolder = decompressionFolderName + @"\" + CommonItem.IIJ_DEPLOY_FOLDER;
            }
            
            // ファイルバージョンの取得
            if (success)
            {
                success = GetFileVersionZip(moduleFolder, ref ErrMsg);
            }

            // ファイル情報の取得
            if (success)
            {
                var unpackPath = CommonItem.DECOMPRESSION_FOLDER_NAME + @"\" + CommonItem.UNPACKER_FOLDER;
                GetFileInfoZip(unpackPath, ref ErrMsg);
            }

        }

        private bool GetFileVersionZip(string moduleFolderPath, ref StringBuilder ErrMsg)
        {
            var success = true;
            
            var exePath = "";
            var unpackPath = "";

            ////ヒロセ
            // インストーラーを解凍
            exePath = moduleFolderPath + @"\" + GetExeFileCompPath(hirose.Company, check.Env);
            unpackPath = CommonItem.DECOMPRESSION_FOLDER_NAME + @"\" + CommonItem.UNPACKER_FOLDER + @"\" + hirose.CompFolderName;
            success = ExeFileUtile.UnpackerInstaller(exePath, unpackPath);
            if (success)
            {
                // バージョン情報取得
                exePath = unpackPath + @"\" + hirose.AppFileName;
                success = ExeFileUtile.RetrieveLinkerTimestamp(exePath, ref hirose.FileVersionZip);
            }
            if (!success)
            {
                ErrMsg.AppendLine("Hiroseの納品用のexeファイルの情報取得に失敗しました。");
            }


            // JFX
            // インストーラーを解凍
            exePath = moduleFolderPath + @"\" + GetExeFileCompPath(jfx.Company, check.Env);
            unpackPath = CommonItem.DECOMPRESSION_FOLDER_NAME + @"\" + CommonItem.UNPACKER_FOLDER + @"\" + jfx.CompFolderName;
            success = ExeFileUtile.UnpackerInstaller(exePath, unpackPath);
            if (success)
            {
                // バージョン情報取得
                exePath = unpackPath + @"\" + jfx.AppFileName;
                success = ExeFileUtile.RetrieveLinkerTimestamp(exePath, ref jfx.FileVersionZip);
            }
            if (!success)
            {
                ErrMsg.AppendLine("JFXの納品用のexeファイルの読み込みに失敗しました。");
            }

            // アクティブFX
            // インストーラーを解凍
            exePath = moduleFolderPath + @"\" + GetExeFileCompPath(activeFX.Company, check.Env);
            unpackPath = CommonItem.DECOMPRESSION_FOLDER_NAME + @"\" + CommonItem.UNPACKER_FOLDER + @"\" + activeFX.CompFolderName;
            success = ExeFileUtile.UnpackerInstaller(exePath, unpackPath);
            if (success)
            {
                // バージョン情報取得
                exePath = unpackPath + @"\" + activeFX.AppFileName;
                success = ExeFileUtile.RetrieveLinkerTimestamp(exePath, ref activeFX.FileVersionZip);
            }
            if (!success)
            {
                ErrMsg.AppendLine("ActiveFXの納品用のexeファイルの読み込みに失敗しました。");
            }

            return success;
        }

        private bool GetFileVersionBuild(string moduleFolderPath, ref StringBuilder ErrMsg)
        {
            var success = true;

            var exePath = "";
            var envFolder = "";

            ////ヒロセ
            // インストーラーを解凍
            envFolder = check.EnvName + @"_" + hirose.CompanyName;
            exePath = moduleFolderPath + @"\" + envFolder + @"\" + hirose.AppFileName;
            success = ExeFileUtile.RetrieveLinkerTimestamp(exePath, ref hirose.FileVersionBuild);
            if (!success)
            {
                ErrMsg.AppendLine("Hiroseのビルドexeファイルの情報取得に失敗しました。");
            }

            // JFX
            // インストーラーを解凍
            envFolder = check.EnvName + @"_" + jfx.CompanyName;
            exePath = moduleFolderPath + @"\" + envFolder + @"\" + jfx.AppFileName;
            success = ExeFileUtile.RetrieveLinkerTimestamp(exePath, ref jfx.FileVersionBuild);
            if (!success)
            {
                ErrMsg.AppendLine("JFXのビルドexeファイルの情報取得に失敗しました。");
            }

            // アクティブFX
            // インストーラーを解凍
            envFolder = check.EnvName + @"_" + activeFX.CompanyName;
            exePath = moduleFolderPath + @"\" + envFolder + @"\" + activeFX.AppFileName;
            success = ExeFileUtile.RetrieveLinkerTimestamp(exePath, ref activeFX.FileVersionBuild);
            if (!success)
            {
                ErrMsg.AppendLine("ActiveFXのビルドexeファイルの情報取得に失敗しました。");
            }

            return success;
        }

        private void GetFileInfoZip(string unpackPath, ref StringBuilder ErrMsg)
        {
            var success = true;

            var temp = new ExeFileUtile();
            var exePath = "";

            // ヒロセ
            exePath = unpackPath + @"\" + hirose.CompFolderName + @"\" + hirose.AppFileName;
            success = ExeFileUtile.GetFileInfo(exePath, ref temp);
            if (success)
            {
                hirose.AppVersionZip = temp.AppVersion;
                hirose.FileSizeZip = temp.FileSize.ToString();
                hirose.FileDateTimeZip = temp.FileDateTime;
            }
            else
            {
                ErrMsg.AppendLine("Hiroseの納品用のexeファイルの情報取得に失敗しました。");
            }

            // JFX
            exePath = unpackPath + @"\" + jfx.CompFolderName + @"\" + jfx.AppFileName;
            success = ExeFileUtile.GetFileInfo(exePath, ref temp);
            if (success)
            {
                jfx.AppVersionZip = temp.AppVersion;
                jfx.FileSizeZip = temp.FileSize.ToString();
                jfx.FileDateTimeZip = temp.FileDateTime;
            }
            else
            {
                ErrMsg.AppendLine("JFXの納品用のexeファイルの情報取得に失敗しました。");
            }

            // アクティブFX
            exePath = unpackPath + @"\" + activeFX.CompFolderName + @"\" + activeFX.AppFileName;
            success = ExeFileUtile.GetFileInfo(exePath, ref temp);
            if (success)
            {
                activeFX.AppVersionZip = temp.AppVersion;
                activeFX.FileSizeZip = temp.FileSize.ToString();
                activeFX.FileDateTimeZip = temp.FileDateTime;
            }
            else
            {
                ErrMsg.AppendLine("アクティブFXの納品用のexeファイルの情報取得に失敗しました。");
            }

        }

        private void GetFileInfoBuild(string buildFolderPath, ref StringBuilder ErrMsg)
        {
            var success = true;

            var temp = new ExeFileUtile();
            var exePath = "";
            var envFolder = "";

            // ヒロセ
            envFolder = check.EnvName + @"_" + hirose.CompanyName;
            exePath = buildFolderPath + @"\" + envFolder + @"\" + hirose.AppFileName;
            success = ExeFileUtile.GetFileInfo(exePath, ref temp);
            if (success)
            {
                hirose.AppVersionBuild = temp.AppVersion;
                hirose.FileSizeBuild = temp.FileSize.ToString();
                hirose.FileDateTimeBuild = temp.FileDateTime;
            }
            else
            {
                ErrMsg.AppendLine("Hiroseのビルドexeファイルの情報取得に失敗しました。");
            }

            // JFX
            envFolder = check.EnvName + @"_" + jfx.CompanyName;
            exePath = buildFolderPath + @"\" + envFolder + @"\" + jfx.AppFileName;
            success = ExeFileUtile.GetFileInfo(exePath, ref temp);
            if (success)
            {
                jfx.AppVersionBuild = temp.AppVersion;
                jfx.FileSizeBuild = temp.FileSize.ToString();
                jfx.FileDateTimeBuild = temp.FileDateTime;
            }
            else
            {
                ErrMsg.AppendLine("JFXのビルドexeファイルの情報取得に失敗しました。");
            }

            // アクティブFX
            envFolder = check.EnvName + @"_" + activeFX.CompanyName;
            exePath = buildFolderPath + @"\" + envFolder + @"\" + activeFX.AppFileName;
            success = ExeFileUtile.GetFileInfo(exePath, ref temp);
            if (success)
            {
                activeFX.AppVersionBuild = temp.AppVersion;
                activeFX.FileSizeBuild = temp.FileSize.ToString();
                activeFX.FileDateTimeBuild = temp.FileDateTime;
            }
            else
            {
                ErrMsg.AppendLine("ActiveFXのビルドexeファイルの情報取得に失敗しました。");
            }

        }

        private string GetExeFileCompPath(CommonItem.Companys comp, CommonItem.Environment env)
        {
            var compFolder = CommonItem.CompFolderList[comp];
            var exeFileName = CommonItem.GetAppInstallerName(comp, env);

            var path = compFolder + @"\" + exeFileName;

            return path;
        }

        ///////////////////
        // 未使用
        private void SetCommonItems(string BranchName, string BranchHashValue)
        {

            // ブランチ名
            hirose.BranchNameInput = check.BranchName;
            hirose.BranchNameDiff = BranchName;

            jfx.BranchNameInput = check.BranchName;
            jfx.BranchNameDiff = BranchName;

            activeFX.BranchNameInput = check.BranchName;
            activeFX.BranchNameDiff = BranchName;

            // ブランチハッシュ値
            hirose.BranchHashValueInput = check.BranchHashValue;
            hirose.BranchHashValueDiff = BranchHashValue;

            jfx.BranchHashValueInput = check.BranchHashValue;
            jfx.BranchHashValueDiff = BranchHashValue;

            activeFX.BranchHashValueInput = check.BranchHashValue;
            activeFX.BranchHashValueDiff = BranchHashValue;

        }

        private void SetForm()
        {
            // チェック条件
            tbSrcBranchName.Text = check.BranchName;
            tbSrcBranchHashValue.Text = check.BranchHashValue;
            tbSrcEnv.Text = CommonItem.GetEnvName(check.Env);
            tbSrcBuildeFolderPath.Text = check.BuildFolderPath;
            tbSrcDeliveryFolderPath.Text = check.DeliveryFolderPath;

            // 共通項目
            SetResultTextBox(entire.result, ref tbResult);

            tbBranchNameInput.Text = entire.BranchNameInput;
            tbBranchNameDiff.Text = entire.BranchNameDiff;
            tbBranchHashValueInput.Text = entire.BranchHashValueInput;
            tbBranchHashValueDiff.Text = entire.BranchHashValueDiff;
            SetDateTimeTextBox(entire.BuildTime, ref tbBuildTime);
            tbBuildLogCheck.Text = CheckItem.ResultName(entire.GetBuildLogCheck());

            // LIONFX
            SetResultTextBox(hirose.result, ref tbResultLF);

            tbFileVersionZipLF.Text = hirose.FileVersionZip;
            tbFileVersionBuildLF.Text = hirose.FileVersionBuild;
            tbAppVersionZipLF.Text = hirose.AppVersionZip;
            tbAppVersionBuildLF.Text = hirose.AppVersionBuild;
            tbFileSizeZipLF.Text = hirose.FileSizeZip;
            tbFileSizeBuildLF.Text = hirose.FileSizeBuild;
            SetDateTimeTextBox(hirose.FileDateTimeZip, ref tbFileDateTimeZipLF);
            SetDateTimeTextBox(hirose.FileDateTimeBuild, ref tbFileDateTimeBuildLF);

            // JFX
            SetResultTextBox(jfx.result, ref tbResultMT);

            tbFileVersionZipMT.Text = jfx.FileVersionZip;
            tbFileVersionBuildMT.Text = jfx.FileVersionBuild;
            tbAppVersionZipMT.Text = jfx.AppVersionZip;
            tbAppVersionBuildMT.Text = jfx.AppVersionBuild;
            tbFileSizeZipMT.Text = jfx.FileSizeZip;
            tbFileSizeBuildMT.Text = jfx.FileSizeBuild;
            SetDateTimeTextBox(jfx.FileDateTimeZip, ref tbFileDateTimeZipMT);
            SetDateTimeTextBox(jfx.FileDateTimeBuild, ref tbFileDateTimeBuildMT);

            // ActiveFX
            SetResultTextBox(activeFX.result, ref tbResultAF);

            tbFileVersionZipAF.Text = activeFX.FileVersionZip;
            tbFileVersionBuildAF.Text = activeFX.FileVersionBuild;
            tbAppVersionZipAF.Text = activeFX.AppVersionZip;
            tbAppVersionBuildAF.Text = activeFX.AppVersionBuild;
            tbFileSizeZipAF.Text = activeFX.FileSizeZip;
            tbFileSizeBuildAF.Text = activeFX.FileSizeBuild;
            SetDateTimeTextBox(activeFX.FileDateTimeZip, ref tbFileDateTimeZipAF);
            SetDateTimeTextBox(activeFX.FileDateTimeBuild, ref tbFileDateTimeBuildAF);

        }

        private void SetResultTextBox(bool result, ref TextBox tb)
        {
            if (result)
            {
                tb.ForeColor = Color.Black;
            }
            else
            {
                tb.ForeColor = Color.Red;
            }
            tb.BackColor = SystemColors.Control;
            tb.Text = CheckItem.ResultName(result);
        }

        private void SetDateTimeTextBox(DateTime dt, ref TextBox tb)
        {
            if(dt == DateTime.MinValue)
            {
                tb.Text = "失敗";
            }else
            {
                tb.Text = dt.ToString(CommonItem.DISPLAY_DATETIME_FORMAT);
            }
        }

        private String ConvViewAppVerion(String version, CommonItem.VersionCode verCode)
        {
            var ret = "";

            switch (verCode)
            {
                case CommonItem.VersionCode.Normal:
                    ret = version;
                    break;
                case CommonItem.VersionCode.MissDetection:
                    // 誤検知バージョンはバージョン+2
                    var nowVersionArray = version.Split('.');
                    nowVersionArray[2] = (int.Parse(nowVersionArray[2]) + 2).ToString();

                    var versionStr = new StringBuilder();
                    var comma = "";
                    foreach(String item in nowVersionArray)
                    {
                        versionStr.Append(comma + item);
                        comma = ".";
                    }
                    ret = versionStr.ToString();
                    break;
            }

            return ret;
        }

    }
}
