﻿namespace P11BuildCheckTool.FormWindow
{
    partial class ResultForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbSrcBuildeFolderPath = new System.Windows.Forms.TextBox();
            this.tbFileDateTimeBuildLF = new System.Windows.Forms.TextBox();
            this.tbFileDateTimeZipLF = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbFileSizeBuildLF = new System.Windows.Forms.TextBox();
            this.tbFileSizeZipLF = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbAppVersionBuildLF = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.tbSrcBranchHashValue = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.tbResultLF = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.tbAppVersionZipLF = new System.Windows.Forms.TextBox();
            this.tbSrcDeliveryFolderPath = new System.Windows.Forms.TextBox();
            this.tbFileVersionBuildLF = new System.Windows.Forms.TextBox();
            this.tbSrcEnv = new System.Windows.Forms.TextBox();
            this.tbBranchHashValueDiff = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.tbBranchNameDiff = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbSrcBranchName = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.tbBranchHashValueInput = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbResultAF = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.tbFileVersionBuildAF = new System.Windows.Forms.TextBox();
            this.tbFileDateTimeBuildAF = new System.Windows.Forms.TextBox();
            this.tbAppVersionZipAF = new System.Windows.Forms.TextBox();
            this.tbFileDateTimeZipAF = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.tbFileVersionZipAF = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tbAppVersionBuildAF = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tbFileSizeBuildAF = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tbFileSizeZipAF = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tbResultMT = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbFileDateTimeBuildMT = new System.Windows.Forms.TextBox();
            this.tbFileDateTimeZipMT = new System.Windows.Forms.TextBox();
            this.tbFileVersionZipMT = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbFileSizeBuildMT = new System.Windows.Forms.TextBox();
            this.tbFileSizeZipMT = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tbAppVersionBuildMT = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbAppVersionZipMT = new System.Windows.Forms.TextBox();
            this.tbFileVersionBuildMT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbFileVersionZipLF = new System.Windows.Forms.TextBox();
            this.tbBuildLogCheck = new System.Windows.Forms.TextBox();
            this.tbBranchNameInput = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblCheckDate = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbBuildTime = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tbResult = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbSrcBuildeFolderPath
            // 
            this.tbSrcBuildeFolderPath.Location = new System.Drawing.Point(93, 36);
            this.tbSrcBuildeFolderPath.Name = "tbSrcBuildeFolderPath";
            this.tbSrcBuildeFolderPath.ReadOnly = true;
            this.tbSrcBuildeFolderPath.Size = new System.Drawing.Size(1113, 19);
            this.tbSrcBuildeFolderPath.TabIndex = 11;
            this.tbSrcBuildeFolderPath.Text = "入力値";
            // 
            // tbFileDateTimeBuildLF
            // 
            this.tbFileDateTimeBuildLF.Location = new System.Drawing.Point(161, 232);
            this.tbFileDateTimeBuildLF.Name = "tbFileDateTimeBuildLF";
            this.tbFileDateTimeBuildLF.ReadOnly = true;
            this.tbFileDateTimeBuildLF.Size = new System.Drawing.Size(208, 19);
            this.tbFileDateTimeBuildLF.TabIndex = 21;
            this.tbFileDateTimeBuildLF.Text = "ビルド環境のBINのEXE";
            // 
            // tbFileDateTimeZipLF
            // 
            this.tbFileDateTimeZipLF.Location = new System.Drawing.Point(161, 207);
            this.tbFileDateTimeZipLF.Name = "tbFileDateTimeZipLF";
            this.tbFileDateTimeZipLF.ReadOnly = true;
            this.tbFileDateTimeZipLF.Size = new System.Drawing.Size(208, 19);
            this.tbFileDateTimeZipLF.TabIndex = 20;
            this.tbFileDateTimeZipLF.Text = "デプロイZIPの中のEXE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(35, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 12);
            this.label8.TabIndex = 19;
            this.label8.Text = "File DateTime";
            // 
            // tbFileSizeBuildLF
            // 
            this.tbFileSizeBuildLF.Location = new System.Drawing.Point(161, 182);
            this.tbFileSizeBuildLF.Name = "tbFileSizeBuildLF";
            this.tbFileSizeBuildLF.ReadOnly = true;
            this.tbFileSizeBuildLF.Size = new System.Drawing.Size(208, 19);
            this.tbFileSizeBuildLF.TabIndex = 18;
            this.tbFileSizeBuildLF.Text = "ビルド環境のBINのEXE";
            // 
            // tbFileSizeZipLF
            // 
            this.tbFileSizeZipLF.Location = new System.Drawing.Point(161, 157);
            this.tbFileSizeZipLF.Name = "tbFileSizeZipLF";
            this.tbFileSizeZipLF.ReadOnly = true;
            this.tbFileSizeZipLF.Size = new System.Drawing.Size(208, 19);
            this.tbFileSizeZipLF.TabIndex = 17;
            this.tbFileSizeZipLF.Text = "デプロイZIPの中のEXE";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(35, 160);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 12);
            this.label7.TabIndex = 16;
            this.label7.Text = "File Size";
            // 
            // tbAppVersionBuildLF
            // 
            this.tbAppVersionBuildLF.Location = new System.Drawing.Point(161, 128);
            this.tbAppVersionBuildLF.Name = "tbAppVersionBuildLF";
            this.tbAppVersionBuildLF.ReadOnly = true;
            this.tbAppVersionBuildLF.Size = new System.Drawing.Size(208, 19);
            this.tbAppVersionBuildLF.TabIndex = 15;
            this.tbAppVersionBuildLF.Text = "ビルド環境のBINのEXE";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "Application Version";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(655, 15);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(29, 12);
            this.Label11.TabIndex = 12;
            this.Label11.Text = "環境";
            // 
            // tbSrcBranchHashValue
            // 
            this.tbSrcBranchHashValue.Location = new System.Drawing.Point(406, 12);
            this.tbSrcBranchHashValue.Name = "tbSrcBranchHashValue";
            this.tbSrcBranchHashValue.ReadOnly = true;
            this.tbSrcBranchHashValue.Size = new System.Drawing.Size(225, 19);
            this.tbSrcBranchHashValue.TabIndex = 14;
            this.tbSrcBranchHashValue.Text = "入力値";
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(338, 15);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(62, 12);
            this.Label10.TabIndex = 12;
            this.Label10.Text = "Git Hash値";
            // 
            // tbResultLF
            // 
            this.tbResultLF.Location = new System.Drawing.Point(128, 26);
            this.tbResultLF.Name = "tbResultLF";
            this.tbResultLF.ReadOnly = true;
            this.tbResultLF.Size = new System.Drawing.Size(74, 19);
            this.tbResultLF.TabIndex = 23;
            this.tbResultLF.Text = "成功／失敗";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(69, 29);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(53, 12);
            this.Label14.TabIndex = 22;
            this.Label14.Text = "確認結果";
            // 
            // tbAppVersionZipLF
            // 
            this.tbAppVersionZipLF.Location = new System.Drawing.Point(161, 103);
            this.tbAppVersionZipLF.Name = "tbAppVersionZipLF";
            this.tbAppVersionZipLF.ReadOnly = true;
            this.tbAppVersionZipLF.Size = new System.Drawing.Size(208, 19);
            this.tbAppVersionZipLF.TabIndex = 13;
            this.tbAppVersionZipLF.Text = "デプロイZIPの中のEXE";
            // 
            // tbSrcDeliveryFolderPath
            // 
            this.tbSrcDeliveryFolderPath.Location = new System.Drawing.Point(94, 58);
            this.tbSrcDeliveryFolderPath.Name = "tbSrcDeliveryFolderPath";
            this.tbSrcDeliveryFolderPath.ReadOnly = true;
            this.tbSrcDeliveryFolderPath.Size = new System.Drawing.Size(1113, 19);
            this.tbSrcDeliveryFolderPath.TabIndex = 11;
            this.tbSrcDeliveryFolderPath.Text = "入力値";
            // 
            // tbFileVersionBuildLF
            // 
            this.tbFileVersionBuildLF.Location = new System.Drawing.Point(161, 77);
            this.tbFileVersionBuildLF.Name = "tbFileVersionBuildLF";
            this.tbFileVersionBuildLF.ReadOnly = true;
            this.tbFileVersionBuildLF.Size = new System.Drawing.Size(208, 19);
            this.tbFileVersionBuildLF.TabIndex = 10;
            this.tbFileVersionBuildLF.Text = "ビルド環境のBINのEXE";
            // 
            // tbSrcEnv
            // 
            this.tbSrcEnv.Location = new System.Drawing.Point(723, 12);
            this.tbSrcEnv.Name = "tbSrcEnv";
            this.tbSrcEnv.ReadOnly = true;
            this.tbSrcEnv.Size = new System.Drawing.Size(225, 19);
            this.tbSrcEnv.TabIndex = 14;
            this.tbSrcEnv.Text = "入力値";
            // 
            // tbBranchHashValueDiff
            // 
            this.tbBranchHashValueDiff.Location = new System.Drawing.Point(136, 130);
            this.tbBranchHashValueDiff.Name = "tbBranchHashValueDiff";
            this.tbBranchHashValueDiff.ReadOnly = true;
            this.tbBranchHashValueDiff.Size = new System.Drawing.Size(971, 19);
            this.tbBranchHashValueDiff.TabIndex = 9;
            this.tbBranchHashValueDiff.Text = "ビルド環境のGITの情報";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(17, 61);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(63, 12);
            this.Label13.TabIndex = 0;
            this.Label13.Text = "納品ファイル";
            // 
            // tbBranchNameDiff
            // 
            this.tbBranchNameDiff.Location = new System.Drawing.Point(136, 77);
            this.tbBranchNameDiff.Name = "tbBranchNameDiff";
            this.tbBranchNameDiff.ReadOnly = true;
            this.tbBranchNameDiff.Size = new System.Drawing.Size(971, 19);
            this.tbBranchNameDiff.TabIndex = 8;
            this.tbBranchNameDiff.Text = "ビルド環境のGITの情報";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "File Version";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "Build Log Check";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "GIT Commit Hash";
            // 
            // tbSrcBranchName
            // 
            this.tbSrcBranchName.Location = new System.Drawing.Point(93, 12);
            this.tbSrcBranchName.Name = "tbSrcBranchName";
            this.tbSrcBranchName.ReadOnly = true;
            this.tbSrcBranchName.Size = new System.Drawing.Size(225, 19);
            this.tbSrcBranchName.TabIndex = 11;
            this.tbSrcBranchName.Text = "入力値";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(16, 15);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(71, 12);
            this.Label9.TabIndex = 0;
            this.Label9.Text = "Git ブランチ名";
            // 
            // tbBranchHashValueInput
            // 
            this.tbBranchHashValueInput.Location = new System.Drawing.Point(136, 105);
            this.tbBranchHashValueInput.Name = "tbBranchHashValueInput";
            this.tbBranchHashValueInput.ReadOnly = true;
            this.tbBranchHashValueInput.Size = new System.Drawing.Size(971, 19);
            this.tbBranchHashValueInput.TabIndex = 4;
            this.tbBranchHashValueInput.Text = "入力値";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbResultAF);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.tbFileVersionBuildAF);
            this.groupBox3.Controls.Add(this.tbFileDateTimeBuildAF);
            this.groupBox3.Controls.Add(this.tbAppVersionZipAF);
            this.groupBox3.Controls.Add(this.tbFileDateTimeZipAF);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.tbFileVersionZipAF);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.tbAppVersionBuildAF);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.tbFileSizeBuildAF);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.tbFileSizeZipAF);
            this.groupBox3.Location = new System.Drawing.Point(827, 355);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(400, 259);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ActiveFX";
            // 
            // tbResultAF
            // 
            this.tbResultAF.Location = new System.Drawing.Point(152, 26);
            this.tbResultAF.Name = "tbResultAF";
            this.tbResultAF.ReadOnly = true;
            this.tbResultAF.Size = new System.Drawing.Size(74, 19);
            this.tbResultAF.TabIndex = 23;
            this.tbResultAF.Text = "成功／失敗";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(93, 29);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 12);
            this.label32.TabIndex = 22;
            this.label32.Text = "確認結果";
            // 
            // tbFileVersionBuildAF
            // 
            this.tbFileVersionBuildAF.Location = new System.Drawing.Point(170, 77);
            this.tbFileVersionBuildAF.Name = "tbFileVersionBuildAF";
            this.tbFileVersionBuildAF.ReadOnly = true;
            this.tbFileVersionBuildAF.Size = new System.Drawing.Size(208, 19);
            this.tbFileVersionBuildAF.TabIndex = 10;
            this.tbFileVersionBuildAF.Text = "ビルド環境のBINのEXE";
            // 
            // tbFileDateTimeBuildAF
            // 
            this.tbFileDateTimeBuildAF.Location = new System.Drawing.Point(170, 235);
            this.tbFileDateTimeBuildAF.Name = "tbFileDateTimeBuildAF";
            this.tbFileDateTimeBuildAF.ReadOnly = true;
            this.tbFileDateTimeBuildAF.Size = new System.Drawing.Size(208, 19);
            this.tbFileDateTimeBuildAF.TabIndex = 21;
            this.tbFileDateTimeBuildAF.Text = "ビルド環境のBINのEXE";
            // 
            // tbAppVersionZipAF
            // 
            this.tbAppVersionZipAF.Location = new System.Drawing.Point(170, 103);
            this.tbAppVersionZipAF.Name = "tbAppVersionZipAF";
            this.tbAppVersionZipAF.ReadOnly = true;
            this.tbAppVersionZipAF.Size = new System.Drawing.Size(208, 19);
            this.tbAppVersionZipAF.TabIndex = 13;
            this.tbAppVersionZipAF.Text = "デプロイZIPの中のEXE";
            // 
            // tbFileDateTimeZipAF
            // 
            this.tbFileDateTimeZipAF.Location = new System.Drawing.Point(170, 210);
            this.tbFileDateTimeZipAF.Name = "tbFileDateTimeZipAF";
            this.tbFileDateTimeZipAF.ReadOnly = true;
            this.tbFileDateTimeZipAF.Size = new System.Drawing.Size(208, 19);
            this.tbFileDateTimeZipAF.TabIndex = 20;
            this.tbFileDateTimeZipAF.Text = "デプロイZIPの中のEXE";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(41, 106);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(105, 12);
            this.label25.TabIndex = 14;
            this.label25.Text = "Application Version";
            // 
            // tbFileVersionZipAF
            // 
            this.tbFileVersionZipAF.Location = new System.Drawing.Point(170, 52);
            this.tbFileVersionZipAF.Name = "tbFileVersionZipAF";
            this.tbFileVersionZipAF.ReadOnly = true;
            this.tbFileVersionZipAF.Size = new System.Drawing.Size(208, 19);
            this.tbFileVersionZipAF.TabIndex = 2;
            this.tbFileVersionZipAF.Text = "デプロイZIPの中のEXE";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(44, 213);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(77, 12);
            this.label31.TabIndex = 19;
            this.label31.Text = "File DateTime";
            // 
            // tbAppVersionBuildAF
            // 
            this.tbAppVersionBuildAF.Location = new System.Drawing.Point(170, 128);
            this.tbAppVersionBuildAF.Name = "tbAppVersionBuildAF";
            this.tbAppVersionBuildAF.ReadOnly = true;
            this.tbAppVersionBuildAF.Size = new System.Drawing.Size(208, 19);
            this.tbAppVersionBuildAF.TabIndex = 15;
            this.tbAppVersionBuildAF.Text = "ビルド環境のBINのEXE";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(41, 55);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 12);
            this.label26.TabIndex = 7;
            this.label26.Text = "File Version";
            // 
            // tbFileSizeBuildAF
            // 
            this.tbFileSizeBuildAF.Location = new System.Drawing.Point(170, 185);
            this.tbFileSizeBuildAF.Name = "tbFileSizeBuildAF";
            this.tbFileSizeBuildAF.ReadOnly = true;
            this.tbFileSizeBuildAF.Size = new System.Drawing.Size(208, 19);
            this.tbFileSizeBuildAF.TabIndex = 18;
            this.tbFileSizeBuildAF.Text = "ビルド環境のBINのEXE";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(44, 163);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(49, 12);
            this.label27.TabIndex = 16;
            this.label27.Text = "File Size";
            // 
            // tbFileSizeZipAF
            // 
            this.tbFileSizeZipAF.Location = new System.Drawing.Point(170, 160);
            this.tbFileSizeZipAF.Name = "tbFileSizeZipAF";
            this.tbFileSizeZipAF.ReadOnly = true;
            this.tbFileSizeZipAF.Size = new System.Drawing.Size(208, 19);
            this.tbFileSizeZipAF.TabIndex = 17;
            this.tbFileSizeZipAF.Text = "デプロイZIPの中のEXE";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.tbResultMT);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.tbFileDateTimeBuildMT);
            this.groupBox5.Controls.Add(this.tbFileDateTimeZipMT);
            this.groupBox5.Controls.Add(this.tbFileVersionZipMT);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.tbFileSizeBuildMT);
            this.groupBox5.Controls.Add(this.tbFileSizeZipMT);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.tbAppVersionBuildMT);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.tbAppVersionZipMT);
            this.groupBox5.Controls.Add(this.tbFileVersionBuildMT);
            this.groupBox5.Location = new System.Drawing.Point(421, 355);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(400, 259);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "MatrixTrader";
            // 
            // tbResultMT
            // 
            this.tbResultMT.Location = new System.Drawing.Point(139, 26);
            this.tbResultMT.Name = "tbResultMT";
            this.tbResultMT.ReadOnly = true;
            this.tbResultMT.Size = new System.Drawing.Size(74, 19);
            this.tbResultMT.TabIndex = 23;
            this.tbResultMT.Text = "成功／失敗";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(80, 29);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 22;
            this.label23.Text = "確認結果";
            // 
            // tbFileDateTimeBuildMT
            // 
            this.tbFileDateTimeBuildMT.Location = new System.Drawing.Point(157, 235);
            this.tbFileDateTimeBuildMT.Name = "tbFileDateTimeBuildMT";
            this.tbFileDateTimeBuildMT.ReadOnly = true;
            this.tbFileDateTimeBuildMT.Size = new System.Drawing.Size(208, 19);
            this.tbFileDateTimeBuildMT.TabIndex = 21;
            this.tbFileDateTimeBuildMT.Text = "ビルド環境のBINのEXE";
            // 
            // tbFileDateTimeZipMT
            // 
            this.tbFileDateTimeZipMT.Location = new System.Drawing.Point(157, 210);
            this.tbFileDateTimeZipMT.Name = "tbFileDateTimeZipMT";
            this.tbFileDateTimeZipMT.ReadOnly = true;
            this.tbFileDateTimeZipMT.Size = new System.Drawing.Size(208, 19);
            this.tbFileDateTimeZipMT.TabIndex = 20;
            this.tbFileDateTimeZipMT.Text = "デプロイZIPの中のEXE";
            // 
            // tbFileVersionZipMT
            // 
            this.tbFileVersionZipMT.Location = new System.Drawing.Point(157, 52);
            this.tbFileVersionZipMT.Name = "tbFileVersionZipMT";
            this.tbFileVersionZipMT.ReadOnly = true;
            this.tbFileVersionZipMT.Size = new System.Drawing.Size(208, 19);
            this.tbFileVersionZipMT.TabIndex = 2;
            this.tbFileVersionZipMT.Text = "デプロイZIPの中のEXE";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(31, 213);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 12);
            this.label22.TabIndex = 19;
            this.label22.Text = "File DateTime";
            // 
            // tbFileSizeBuildMT
            // 
            this.tbFileSizeBuildMT.Location = new System.Drawing.Point(157, 185);
            this.tbFileSizeBuildMT.Name = "tbFileSizeBuildMT";
            this.tbFileSizeBuildMT.ReadOnly = true;
            this.tbFileSizeBuildMT.Size = new System.Drawing.Size(208, 19);
            this.tbFileSizeBuildMT.TabIndex = 18;
            this.tbFileSizeBuildMT.Text = "ビルド環境のBINのEXE";
            // 
            // tbFileSizeZipMT
            // 
            this.tbFileSizeZipMT.Location = new System.Drawing.Point(157, 160);
            this.tbFileSizeZipMT.Name = "tbFileSizeZipMT";
            this.tbFileSizeZipMT.ReadOnly = true;
            this.tbFileSizeZipMT.Size = new System.Drawing.Size(208, 19);
            this.tbFileSizeZipMT.TabIndex = 17;
            this.tbFileSizeZipMT.Text = "デプロイZIPの中のEXE";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(31, 163);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 12);
            this.label21.TabIndex = 16;
            this.label21.Text = "File Size";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(28, 55);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 12);
            this.label18.TabIndex = 7;
            this.label18.Text = "File Version";
            // 
            // tbAppVersionBuildMT
            // 
            this.tbAppVersionBuildMT.Location = new System.Drawing.Point(157, 128);
            this.tbAppVersionBuildMT.Name = "tbAppVersionBuildMT";
            this.tbAppVersionBuildMT.ReadOnly = true;
            this.tbAppVersionBuildMT.Size = new System.Drawing.Size(208, 19);
            this.tbAppVersionBuildMT.TabIndex = 15;
            this.tbAppVersionBuildMT.Text = "ビルド環境のBINのEXE";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(28, 106);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 12);
            this.label20.TabIndex = 14;
            this.label20.Text = "Application Version";
            // 
            // tbAppVersionZipMT
            // 
            this.tbAppVersionZipMT.Location = new System.Drawing.Point(157, 103);
            this.tbAppVersionZipMT.Name = "tbAppVersionZipMT";
            this.tbAppVersionZipMT.ReadOnly = true;
            this.tbAppVersionZipMT.Size = new System.Drawing.Size(208, 19);
            this.tbAppVersionZipMT.TabIndex = 13;
            this.tbAppVersionZipMT.Text = "デプロイZIPの中のEXE";
            // 
            // tbFileVersionBuildMT
            // 
            this.tbFileVersionBuildMT.Location = new System.Drawing.Point(157, 77);
            this.tbFileVersionBuildMT.Name = "tbFileVersionBuildMT";
            this.tbFileVersionBuildMT.ReadOnly = true;
            this.tbFileVersionBuildMT.Size = new System.Drawing.Size(208, 19);
            this.tbFileVersionBuildMT.TabIndex = 10;
            this.tbFileVersionBuildMT.Text = "ビルド環境のBINのEXE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "GIT Branch";
            // 
            // tbFileVersionZipLF
            // 
            this.tbFileVersionZipLF.Location = new System.Drawing.Point(161, 52);
            this.tbFileVersionZipLF.Name = "tbFileVersionZipLF";
            this.tbFileVersionZipLF.ReadOnly = true;
            this.tbFileVersionZipLF.Size = new System.Drawing.Size(208, 19);
            this.tbFileVersionZipLF.TabIndex = 2;
            this.tbFileVersionZipLF.Text = "デプロイZIPの中のEXE";
            // 
            // tbBuildLogCheck
            // 
            this.tbBuildLogCheck.Location = new System.Drawing.Point(136, 178);
            this.tbBuildLogCheck.Name = "tbBuildLogCheck";
            this.tbBuildLogCheck.ReadOnly = true;
            this.tbBuildLogCheck.Size = new System.Drawing.Size(208, 19);
            this.tbBuildLogCheck.TabIndex = 10;
            this.tbBuildLogCheck.Text = "成功／失敗";
            // 
            // tbBranchNameInput
            // 
            this.tbBranchNameInput.Location = new System.Drawing.Point(136, 52);
            this.tbBranchNameInput.Name = "tbBranchNameInput";
            this.tbBranchNameInput.ReadOnly = true;
            this.tbBranchNameInput.Size = new System.Drawing.Size(971, 19);
            this.tbBranchNameInput.TabIndex = 0;
            this.tbBranchNameInput.Text = "入力値";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(16, 39);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(67, 12);
            this.Label12.TabIndex = 0;
            this.Label12.Text = "ビルドフォルダ";
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.tbSrcEnv);
            this.GroupBox4.Controls.Add(this.Label11);
            this.GroupBox4.Controls.Add(this.tbSrcBranchHashValue);
            this.GroupBox4.Controls.Add(this.Label10);
            this.GroupBox4.Controls.Add(this.tbSrcDeliveryFolderPath);
            this.GroupBox4.Controls.Add(this.tbSrcBuildeFolderPath);
            this.GroupBox4.Controls.Add(this.tbSrcBranchName);
            this.GroupBox4.Controls.Add(this.Label13);
            this.GroupBox4.Controls.Add(this.Label12);
            this.GroupBox4.Controls.Add(this.Label9);
            this.GroupBox4.Location = new System.Drawing.Point(14, 51);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(1212, 84);
            this.GroupBox4.TabIndex = 10;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "チェック条件";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbResultLF);
            this.groupBox1.Controls.Add(this.Label14);
            this.groupBox1.Controls.Add(this.tbFileDateTimeBuildLF);
            this.groupBox1.Controls.Add(this.tbFileDateTimeZipLF);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbFileSizeBuildLF);
            this.groupBox1.Controls.Add(this.tbFileSizeZipLF);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbAppVersionBuildLF);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbAppVersionZipLF);
            this.groupBox1.Controls.Add(this.tbFileVersionBuildLF);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbFileVersionZipLF);
            this.groupBox1.Location = new System.Drawing.Point(12, 355);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 259);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LionFX";
            // 
            // lblCheckDate
            // 
            this.lblCheckDate.AutoSize = true;
            this.lblCheckDate.Location = new System.Drawing.Point(12, 18);
            this.lblCheckDate.Name = "lblCheckDate";
            this.lblCheckDate.Size = new System.Drawing.Size(66, 12);
            this.lblCheckDate.TabIndex = 1;
            this.lblCheckDate.Text = "チェック日付：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbResult);
            this.groupBox2.Controls.Add(this.tbBuildTime);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tbBranchNameInput);
            this.groupBox2.Controls.Add(this.tbBuildLogCheck);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.tbBranchHashValueInput);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.tbBranchNameDiff);
            this.groupBox2.Controls.Add(this.tbBranchHashValueDiff);
            this.groupBox2.Location = new System.Drawing.Point(14, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1210, 207);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "共通項目";
            // 
            // tbBuildTime
            // 
            this.tbBuildTime.Location = new System.Drawing.Point(136, 154);
            this.tbBuildTime.Name = "tbBuildTime";
            this.tbBuildTime.ReadOnly = true;
            this.tbBuildTime.Size = new System.Drawing.Size(208, 19);
            this.tbBuildTime.TabIndex = 14;
            this.tbBuildTime.Text = "ビルド環境に記録されたビルド開始日時";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 12);
            this.label5.TabIndex = 13;
            this.label5.Text = "Build Time";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(44, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 22;
            this.label15.Text = "確認結果";
            // 
            // tbResult
            // 
            this.tbResult.Location = new System.Drawing.Point(103, 22);
            this.tbResult.Name = "tbResult";
            this.tbResult.ReadOnly = true;
            this.tbResult.Size = new System.Drawing.Size(74, 19);
            this.tbResult.TabIndex = 23;
            this.tbResult.Text = "成功／失敗";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1090, 116);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(12, 19);
            this.textBox1.TabIndex = 1;
            // 
            // ResultForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1238, 624);
            this.Controls.Add(this.lblCheckDate);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.GroupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "ResultForm";
            this.Text = "ResultForm";
            this.Load += new System.EventHandler(this.ResultForm_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox tbSrcBuildeFolderPath;
        private System.Windows.Forms.TextBox tbFileDateTimeBuildLF;
        private System.Windows.Forms.TextBox tbFileDateTimeZipLF;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbFileSizeBuildLF;
        private System.Windows.Forms.TextBox tbFileSizeZipLF;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbAppVersionBuildLF;
        private System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox tbSrcBranchHashValue;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label14;
        private System.Windows.Forms.TextBox tbAppVersionZipLF;
        internal System.Windows.Forms.TextBox tbSrcDeliveryFolderPath;
        private System.Windows.Forms.TextBox tbFileVersionBuildLF;
        internal System.Windows.Forms.TextBox tbSrcEnv;
        private System.Windows.Forms.TextBox tbBranchHashValueDiff;
        internal System.Windows.Forms.Label Label13;
        private System.Windows.Forms.TextBox tbBranchNameDiff;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.TextBox tbSrcBranchName;
        internal System.Windows.Forms.Label Label9;
        private System.Windows.Forms.TextBox tbBranchHashValueInput;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbFileVersionZipLF;
        private System.Windows.Forms.TextBox tbBuildLogCheck;
        private System.Windows.Forms.TextBox tbBranchNameInput;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.GroupBox GroupBox4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblCheckDate;
        internal System.Windows.Forms.TextBox tbResultAF;
        internal System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox tbFileVersionBuildAF;
        private System.Windows.Forms.TextBox tbFileDateTimeBuildAF;
        private System.Windows.Forms.TextBox tbAppVersionZipAF;
        private System.Windows.Forms.TextBox tbFileDateTimeZipAF;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbFileVersionZipAF;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox tbAppVersionBuildAF;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbFileSizeBuildAF;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbFileSizeZipAF;
        internal System.Windows.Forms.TextBox tbResultMT;
        internal System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbFileDateTimeBuildMT;
        private System.Windows.Forms.TextBox tbFileDateTimeZipMT;
        private System.Windows.Forms.TextBox tbFileVersionZipMT;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbFileSizeBuildMT;
        private System.Windows.Forms.TextBox tbFileSizeZipMT;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbAppVersionBuildMT;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbAppVersionZipMT;
        private System.Windows.Forms.TextBox tbFileVersionBuildMT;
        private System.Windows.Forms.TextBox tbResultLF;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbBuildTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbResult;
        internal System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox1;
    }
}