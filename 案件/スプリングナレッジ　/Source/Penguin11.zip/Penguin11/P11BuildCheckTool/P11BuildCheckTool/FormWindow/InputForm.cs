﻿using P11BuildCheckTool.FormWindow;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P11BuildCheckTool
{
    public partial class InputForm : Form
    {
        public InputForm()
        {
            InitializeComponent();
        }

        private void InputForm_Load(object sender, EventArgs e)
        {
            // ヒント文字設定
            ttHint.SetToolTip(tbBranchName, "例) release/Ph3.36");
            ttHint.SetToolTip(tbBranchHashValue, "gitハッシュ値の頭7桁を入力");
            ttHint.SetToolTip(tbBuildFolderPath, @"例）C:\P11\test\20181107_1328");
            ttHint.SetToolTip(tbDeliveryFilePath, @"例）C:\P11\test\20181107SKC_prd.zip");
        }

        private void btnRun_Click(object sender, EventArgs e)
        {

            var item = GetInput();

            var errMsg = new StringBuilder();
            var success = checkInputData(item, ref errMsg);

            if(success)
            {
                var result = new ResultForm(item);
                result.ShowDialog();
            }
            else
            {
                MessageBox.Show(errMsg.ToString(),
                    "入力エラー",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

        }

        private InputItem GetInput()
        {
            var item = new InputItem();

            item.BranchName = tbBranchName.Text;
            item.BranchHashValue = tbBranchHashValue.Text;
            item.BuildFolderPath = tbBuildFolderPath.Text;
            item.DeliveryFolderPath = tbDeliveryFilePath.Text;


            // 環境データ取得
            if (rbEnvProduct.Checked)
            {
                item.Env = CommonItem.Environment.Product;
            }
            else if (rbEnvDemo.Checked)
            {
                item.Env = CommonItem.Environment.Demo;
            }
            else if (rbEnvStaging.Checked)
            {
                item.Env = CommonItem.Environment.Staging;
            };

            // バージョンデータ取得
            if (rbVerNormal.Checked)
            {
                item.Version = CommonItem.VersionCode.Normal;
            }
            else if (rbVerMissDetection.Checked)
            {
                item.Version = CommonItem.VersionCode.MissDetection;
            }

            return item;
        }

        private bool checkInputData(InputItem item, ref StringBuilder errMsg)
        {
            var success = true;

            // ブランチ名
            if(item.BranchName == "")
            {
                success = false;
                errMsg.AppendLine("Gitブランチ名を入力してください。");
            }

            // ブランチHash値
            if(item.BranchHashValue == "" 
                || item.BranchHashValue.Length != 7)
            {
                success = false;
                errMsg.AppendLine("ブランチHash値は頭7桁を入力してください。");
            }

            // ビルドフォルダ
            if(item.BuildFolderPath == "" 
                || !Directory.Exists(item.BuildFolderPath))
            {
                success = false;
                errMsg.AppendLine("ビルドフォルダは存在するフォルダを指定してください。");
            }
            
            // 納品フォルダ
            if(item.DeliveryFolderPath == "" 
                || !File.Exists(item.DeliveryFolderPath) 
                || Path.GetExtension(item.DeliveryFolderPath) != ".zip")
            {
                success = false;
                errMsg.AppendLine("納品ファイルは存在するzipファイルを指定してください。");
            }

            // 環境
            if (!CommonItem.CheckEnvValue(item.Env))
            {
                success = false;
                errMsg.AppendLine("環境を選択してください。");
            }

            // バージョン
            if (!CommonItem.CheckVersionValue(item.Version))
            {
                success = false;
                errMsg.AppendLine("バージョンを選択してください。");
            }

            return success;
        }

        private void btnBuildFolderPath_Click(object sender, EventArgs e)
        {
            var fbd = new FolderBrowserDialog();

            // 説明
            fbd.Description = "ビルド用フォルダを指定してください。";

            // ルートフォルダ
            fbd.RootFolder = Environment.SpecialFolder.Desktop;

            // ダイヤログ表示
            if(fbd.ShowDialog(this) == DialogResult.OK)
            {

                // 選択フォルダをセット
                tbBuildFolderPath.Text = fbd.SelectedPath;

            }

        }

        private void btnDeliveryFilePath_Click(object sender, EventArgs e)
        {
            var ofd = new OpenFileDialog();

            // デフォルトフォルダパス
            ofd.InitialDirectory = @"C:\";

            // [ファイルの種類]を指定
            //ofd.Filter = "Zipファイル(*.zip)|*.zip;すべてのファイル(*.*)|*.*";
            ofd.Filter = "Zipファイル(*.zip)|*.zip|すべてのファイル(*.*)|*.*";

            // タイトル
            ofd.Title = "IIJ納品用zipファイルを選択してください。";

            if(ofd.ShowDialog() == DialogResult.OK)
            {
                // 選択ファイルのパスをセット
                tbDeliveryFilePath.Text = ofd.FileName;
            }
        }

    }
}
