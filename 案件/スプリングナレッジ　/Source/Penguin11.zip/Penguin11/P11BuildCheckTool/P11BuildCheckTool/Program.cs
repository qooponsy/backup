﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P11BuildCheckTool
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {

            // アプリケーション初期化処理
            var success = Init();

            if (success)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new InputForm());
            }
        }

        static bool Init()
        {
            var success = true;
            var ErrMsg = new StringBuilder();

            // 共通クラスの初期化
            success = CommonItem.Init();
            if (!success)
            {
                ErrMsg.AppendLine(CommonItem.ErrMsg);
            }

            // Gitクラスの初期化
            success = GitUtile.Init();
            if (!success)
            {
                ErrMsg.AppendLine(GitUtile.ErrMsg);
            }

            // BuildFolderクラスの初期化
            success = BuildFolderUtile.Init();
            if (!success)
            {
                ErrMsg.AppendLine(BuildFolderUtile.ErrMsg);
            }

            // Zipファイルクラスの初期化
            success = ZipFileUtile.Init();
            if (!success)
            {
                ErrMsg.AppendLine(ZipFileUtile.ErrMsg);
            }


            if(ErrMsg.ToString() != "")
            {
                success = false;

                MessageBox.Show(ErrMsg.ToString(),
                    "エラー",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

            return success;
        }
    }
}
