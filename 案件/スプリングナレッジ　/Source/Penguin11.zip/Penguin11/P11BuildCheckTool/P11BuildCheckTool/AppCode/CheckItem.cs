﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    class CheckItem
    {
        // 会社
        public CommonItem.Companys Company;

        // 最終結果
        public bool result;

        // Gitブランチ
        public string BranchNameInput;
        public string BranchNameDiff;

        // Gitハッシュ値
        public string BranchHashValueInput;
        public string BranchHashValueDiff;

        // ビルドログチェック結果
        public CheckCode BuildLogCheck;

        // ファイルバージョン
        public string FileVersionZip;
        public string FileVersionBuild;

        // ビルド時間
        public DateTime BuildTime;

        // アプリケーションバージョン
        public string AppVersionZip;
        public string AppVersionBuild;

        // ファイルサイズ
        public string FileSizeZip;
        public string FileSizeBuild;

        // ファイル更新時間
        public DateTime FileDateTimeZip;
        public DateTime FileDateTimeBuild;


        // 参照用
        public string CompFolderName;
        public string AppInstallerName;
        public string AppFileName;
        public string CompanyName;

        public enum CheckCode
        {
            None,       // 未チェック
            Success,    // 成功
            Failure     // 失敗
        }

        public static string ResultName(bool result)
        {
            var ret = "";

            if(result == true)
            {
                ret = "成功";
            }
            else
            {
                ret = "失敗";
            }

            return ret;
        }

        public bool GetBuildLogCheck()
        {
            var ret = false;

            switch (BuildLogCheck)
            {
                case CheckCode.Success:
                    ret = true;
                    break;

                case CheckCode.Failure:
                    ret = false;
                    break; 
            }

            return ret;
        }

        public void JudgeResult()
        {
            var success = true;

            // Gitブランチ
            if(BranchNameDiff != null)
            {

                if (BranchNameInput != BranchNameDiff)
                {
                    success = false;
                }
            }

            // Gitハッシュ値
            if(BranchHashValueDiff != null)
            {
                if(BranchHashValueInput != BranchHashValueDiff)
                {
                    success = false;
                }
            }

            // ビルドログチェック結果
            if(BuildLogCheck != CheckCode.None)
            {
                if (BuildLogCheck == CheckCode.Failure)
                {
                    success = false;
                }
            }

            // ファイルバージョン
            if(FileVersionZip != null || FileVersionBuild != null)
            {
                if(FileVersionZip != FileVersionBuild)
                {
                    success = false;
                }
            }

            // ビルド時間
            //// なにもしない

            // アプリケーションバージョン
            if (AppVersionZip != null || AppVersionBuild != null)
            {
                if (AppVersionZip != AppVersionBuild)
                {
                    success = false;
                }
            }

            // ファイルサイズ
            if (FileSizeZip != null || FileSizeBuild != null)
            {
                if (FileSizeZip != FileSizeBuild)
                {
                    success = false;
                }
            }

            // ファイル更新時間
            if (FileDateTimeZip != DateTime.MinValue || FileDateTimeBuild != DateTime.MinValue)
            {
                // zipのファイルフォーマット仕様で1秒までの更新時刻であれば可とする

                var diff = FileDateTimeZip - FileDateTimeBuild;

                if (!CheckFileDateTime(FileDateTimeZip, FileDateTimeBuild))
                {
                    success = false;
                }
            }

            result = success;
        }

        private bool CheckFileDateTime(DateTime dt1, DateTime dt2)
        {
            var ret = true;

            var diffDateTime = dt1 - dt2;
            var diff = Math.Abs(diffDateTime.TotalMilliseconds);

            if(diff >= CommonItem.SAFE_DIFF_TIME_MS)
            {
                ret = false;
            }

            return ret;
        }

    }
}
