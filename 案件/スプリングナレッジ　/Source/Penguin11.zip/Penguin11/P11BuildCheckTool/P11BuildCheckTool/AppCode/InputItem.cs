﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    public class InputItem
    {

        public string BranchName;
        public string BranchHashValue;
        public string BuildFolderPath;
        public string DeliveryFolderPath;
        public CommonItem.Environment Env = CommonItem.Environment.None;
        public CommonItem.VersionCode Version = CommonItem.VersionCode.None;

        // 参照用
        public string EnvName;
    }
}
