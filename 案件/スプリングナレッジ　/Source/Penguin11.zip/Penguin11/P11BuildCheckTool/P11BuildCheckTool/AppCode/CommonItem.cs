﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11BuildCheckTool
{
    public class CommonItem
    {
        public static string ErrMsg;

        // 表示用
        public const string DISPLAY_DATETIME_FORMAT = "yyyy/MM/dd HH:mm:ss";

        // git系
        public const string GIT_CONFIG_FILE = "git情報.txt";
        public const int GIT_HASH_CHECK_LINGTH = 7;

        // zipファイル系
        public const string DEPLOY_FOLDER_FILE_NAME = "デプロイ構成設定ファイル.txt";
        public const string DECOMPRESSION_FOLDER_NAME = "_temp";
        public const string IIJ_DEPLOY_FOLDER = @"fx-hrs-cweb\richwin2";

        // buildフォルダ系
        public const string BUILD_FOLDER_NAME = "_build";
        public const string LOG_FOLDER_NAME = "_log";
        public const string BUILD_LOG_FILE_NAME = "InstallerCreate.log";
        public const string BUILD_TIME_FILE_NAME = "BuildTime.txt";
        public const string LOG_FAILURE_TEXT = "ERROR";

        // exeファイル系
        public const string UNPACKER_FOLDER = "_unpack";

        // チェック用
        public const int SAFE_DIFF_TIME_MS = 2000;  // 2秒未満

        // 会社リスト
        public enum Companys
        {
            Hirose,
            JFX,
            ActiveFX
        }

        // 環境リスト
        public enum Environment
        {
            None,       // なにも選択していない
            Product,    // 本番環境
            Demo,       // デモ環境
            Staging,    // ステージング環境
        }

        // バージョンリスト
        public enum VersionCode
        {
            None,           // なにも選択していない
            Normal,         // 通常
            MissDetection,  // 誤検知
        }

        // 会社ごとのフォルダ名
        public static Dictionary<Companys, string> CompFolderList;

        // 会社ごと、環境ごとのアプリ名
        public static Dictionary<Companys, Dictionary<Environment, string>> AppNameList;

        public static bool Init()
        {
            var success = true;

            try
            {
                // 会社ごとのフォルダ名
                CompFolderList = new Dictionary<Companys, string>();
                CompFolderList.Add(Companys.Hirose, "lionfx");
                CompFolderList.Add(Companys.JFX, "matrix");
                CompFolderList.Add(Companys.ActiveFX, "activefx");

                ///// アプリ名
                // ヒロセ
                var hirose = new Dictionary<Environment, string>();
                hirose.Add(Environment.Product, "LionFXWin");
                hirose.Add(Environment.Demo, "LionFXWinDemo");
                hirose.Add(Environment.Staging, "LionFXWinStg");
                // JFX
                var jfx = new Dictionary<Environment, string>();
                jfx.Add(Environment.Product, "MatrixTraderWin");
                jfx.Add(Environment.Demo, "MatrixTraderWinDemo");
                jfx.Add(Environment.Staging, "MatrixTraderWinStg");
                // アクティブFX
                var activeFX = new Dictionary<Environment, string>();
                activeFX.Add(Environment.Product, "ActiveFXWin");
                activeFX.Add(Environment.Demo, "ActiveFXWinDemo");
                activeFX.Add(Environment.Staging, "ActiveFXWinStg");
                // ADD
                AppNameList = new Dictionary<Companys, Dictionary<Environment, string>>();
                AppNameList.Add(Companys.Hirose, hirose);
                AppNameList.Add(Companys.JFX, jfx);
                AppNameList.Add(Companys.ActiveFX, activeFX);
            }
            catch
            {
                success = false;
                ErrMsg = "初期化処理に失敗しました。";
            }

            return success;
        }

        public static string GetEnvName(Environment env)
        {
            var ret = "";

            switch (env)
            {
                case Environment.Product:
                    ret = "本番環境";
                    break;
                case Environment.Demo:
                    ret = "デモ環境";
                    break;
                case Environment.Staging:
                    ret = "ステージング環境";
                    break;
            }

            return ret;
        }

        public static bool ConvEnvString(string envStr, ref Environment env)
        {
            var success = true;

            switch (envStr)
            {
                case "prd":
                    env = Environment.Product;
                    break;

                case "demo":
                    env = Environment.Demo;
                    break;

                case "stg":
                    env = Environment.Staging;
                    break;
                default:
                    success = false;
                    break;
            }

            return success;
        }

        public static bool CheckEnvValue(Environment env)
        {
            var ret = false;

            switch (env)
            {
                case Environment.Product:
                case Environment.Demo:
                case Environment.Staging:
                    ret = true;
                    break;
                default:
                    ret = false;
                    break;
            }

            return ret;
        }

        public static bool CheckVersionValue(VersionCode ver)
        {
            var ret = false;

            switch (ver)
            {
                case VersionCode.Normal:
                case VersionCode.MissDetection:
                    ret = true;
                    break;
                default:
                    ret = false;
                    break;
            }

            return ret;
        }

        public static string GetAppInstallerName(Companys comp, Environment env)
        {
            var envList = AppNameList[comp];
            var appName = envList[env];

            var InstallerName = appName + "2.Install.exe";

            return InstallerName;
        }

        public static string GetAppFileName(Companys comp, Environment env)
        {
            var envList = AppNameList[comp];
            var appName = envList[env];

            var InstallerName = appName + "2.exe";

            return InstallerName;
        }

        public static string ConvCompString(Companys comp)
        {
            var ret = "";

            switch (comp)
            {
                case Companys.Hirose:
                    ret = "Hirose";
                    break;

                case Companys.JFX:
                    ret = "JFX";
                    break;

                case Companys.ActiveFX:
                    ret = "ActiveFX";
                    break;
            }

            return ret;
        }

        public static string ConvEnvString(Environment env)
        {
            var ret = "";

            switch (env)
            {
                case Environment.Product:
                    ret = "PRD";
                    break;

                case Environment.Demo:
                    ret = "DEMOPRD";
                    break;

                case Environment.Staging:
                    ret = "STG";
                    break;
            }

            return ret;
        }

    }
}
