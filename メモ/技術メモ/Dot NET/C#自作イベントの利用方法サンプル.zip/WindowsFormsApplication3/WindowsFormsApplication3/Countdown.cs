﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication3
{
    class Countdown
    {
        public int internalCounter = 0;
        // ...

        public event EventHandler CountdownCompleted;

        protected virtual void OnCountdownCompleted(EventArgs e)
        {
            if (CountdownCompleted != null)
                CountdownCompleted(this, e);
        }

        public void Decrement()
        {
            internalCounter--;
            if (internalCounter == 0)
                OnCountdownCompleted(new EventArgs());
        }
    }
}
