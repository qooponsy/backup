﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AutoUpdaterDotNET;

namespace WindowsFormsApplication4
{
    static class Program
    {

        private static bool RunAutoUpdate = false;
        private static bool EndUpdate = false;

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            AutoUpdater.ShowSkipButton = false;
            AutoUpdater.ShowRemindLaterButton = false;
            AutoUpdater.Mandatory = true;
            AutoUpdater.ReportErrors = false;
            AutoUpdater.RunUpdateAsAdmin = false;

            AutoUpdater.CheckForUpdateEvent += AutoUpdaterOnCheckForUpdateEvent;

            AutoUpdater.Start("https://dev.fate-i.com/p11_2_ut/lionfx/autoupdater.xml");

            while (!EndUpdate)
            {
                Application.DoEvents();
            }

            Application.Run(new Form1());
        }

        static void test()
        {

        }

        public static void AutoUpdaterOnCheckForUpdateEvent(UpdateInfoEventArgs args)
        {
            if (args != null)
            {
                args.IsUpdateAvailable = false;
                if (args.IsUpdateAvailable)
                {
                    DialogResult dialogResult;

                    if (args.Mandatory)
                    {
                        // update is required
                        var autoUpdateForm = new AutoUpdateForm();
                        //autoUpdateForm.CurrentVersion = args.CurrentVersion.ToString();
                        //autoUpdateForm.InstalledVersion = args.InstalledVersion.ToString();

                        dialogResult = autoUpdateForm.ShowDialog();

                        if (dialogResult == DialogResult.OK)
                        {
                            try
                            {
                                if (AutoUpdater.DownloadUpdate())
                                {
                                    Application.Exit();
                                }
                                else
                                {
                                    MessageBox.Show("ERRMSG",
                                        "Error!!",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                                    Application.Exit();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString() + "\n" + ex.StackTrace);

                                // ↓ Actually use ResourceManager
                                MessageBox.Show("ERRMSG",
                                    "Error!!",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            Application.Exit();
                        }


                    }
                    else
                    {
                        // No update required
                        RunAutoUpdate = false;
                    };

                }
                else
                {
                    // Update unavailable
                    RunAutoUpdate = false;
                }
            }
            else
            {
                // AutoUpdate failure
                RunAutoUpdate = false;
            }


            if (RunAutoUpdate == false)
            {
                EndUpdate = true;
            }

        }

    }

}
